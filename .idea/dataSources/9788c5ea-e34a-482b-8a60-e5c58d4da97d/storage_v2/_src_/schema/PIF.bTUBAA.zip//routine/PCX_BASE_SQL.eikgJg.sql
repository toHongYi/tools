create PROCEDURE PCX_BASE_SQL( O_CODE        OUT NUMBER,
                                          O_NOTE        OUT VARCHAR2,
                                          O_VALUE       OUT VARCHAR2,
                                          I_SQL         IN VARCHAR2 --操作人
                                       
                                          ) AS
  /*****************************************************************************
   *创建人员：chenglin
   *创建日期：2019-11-26
   *功能说明：获取内部对象，可根据名称搜索
   *-----------------------------------------------------------------------------
   * 修改者         版本号          修改日期         说明
   * chenglin           1.0.0          2019-11-26        新增
   ------------------------------------------------------------------------------
  I_DXMC='TJG_DQDM' --地区代码，省份城市
    I_DXMC='TJG_HYFL' --行业分类
   *****************************************************************************/


BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '成功';


  --CHECK
  IF I_SQL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参查询sql不允许为空!';
    RETURN;
  END IF;
  
  EXECUTE IMMEDIATE REPLACE(REPLACE(I_SQL,'@',''''),'''''','''') INTO O_VALUE ;
 
  
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败！';
    O_VALUE := null ;
END ;
/

