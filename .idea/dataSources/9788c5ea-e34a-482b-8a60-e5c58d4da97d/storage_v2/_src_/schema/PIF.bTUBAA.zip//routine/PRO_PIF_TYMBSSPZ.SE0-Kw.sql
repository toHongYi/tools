create PROCEDURE PRO_PIF_TYMBSSPZ(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_USER IN INTEGER, --操作人
                                                 I_IP   IN VARCHAR2, --操作IP
                                                 I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;6|上移;7|下移;
                                                 I_ID   IN INTEGER --操作ID
                                                 ) IS
  /*
  **功能说明：通用模板搜索配置管理
  **创建人：戴文生
  **创建日期：2014-12-01
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **戴文生              2014-12-01    创建
  */
  V_COUNT   INTEGER; --计数变量
  V_ZHID    INTEGER; --显示排序置换ID
  V_XSSX    INTEGER; --显示排序
  V_OBJ     TPIF_TYMBSSPZ%ROWTYPE; --表单记录
  V_MBZT    INTEGER;
  V_TYPE    INTEGER;
  V_REFCODE VARCHAR2(200);
  V_SQL     VARCHAR2(8000);
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_TYMBSSPZ WHERE ID = I_ID;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  SELECT NVL(MBZT, 0) INTO V_MBZT FROM TPIF_TYMBDY WHERE ID = V_OBJ.TYMB;
  --check
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --//:新增-----------------------------------------------------------------------
    IF V_OBJ.XSMC IS NULL THEN
      O_NOTE := '[显示名称]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX IS NULL THEN
      O_NOTE := '[属性类型]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 AND V_OBJ.YWDX IS NULL THEN
      O_NOTE := '[业务对象]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 AND V_OBJ.CPSX IS NULL THEN
      O_NOTE := '[产品属性]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 2 AND V_OBJ.TJQJZB IS NULL THEN
      O_NOTE := '[条件区间指标]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.XSMS IS NULL THEN
      O_NOTE := '[显示模式]不允许为空!';
      RETURN;
    END IF;
    IF (V_OBJ.MS IS NOT NULL AND V_OBJ.IDBZ IS NULL) OR
       (V_OBJ.MS IS NULL AND V_OBJ.IDBZ IS NOT NULL) THEN
      O_NOTE := '[描述标识]与[主键标识]需同时存在!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND YWDX = V_OBJ.YWDX
         AND CPSX = V_OBJ.CPSX;
      IF V_COUNT > 1 THEN
        SELECT '不允许存在重复的[产品属性]--' || DESCRIBE || '!'
          INTO O_NOTE
          FROM PIF.TPIF_FIELD
         WHERE ID = V_OBJ.CPSX;
        RETURN; --//..:此处可允许
      END IF;
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE TABLENAME = ''' ||
               V_OBJ.YWDX || ''' AND INSTR('';''||''' || V_OBJ.CPSX ||
               '''||'';'','';''||ID||'';'') > 0';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF INSTR(V_OBJ.CPSX, ';') > 0 THEN
        IF V_COUNT !=
           (LENGTH(V_OBJ.CPSX) - LENGTH(REPLACE(V_OBJ.CPSX, ';', ''))+1) THEN
          O_NOTE := '业务对象[' || V_OBJ.YWDX || ']配置的产品属性[' || V_OBJ.CPSX ||
                    ']异常!';
          RETURN;
        END IF;
      ELSE
        IF V_COUNT = 0 THEN
          O_NOTE := '业务对象[' || V_OBJ.YWDX || ']不存在产品属性[' || V_OBJ.CPSX || ']!';
          RETURN;
        END IF;
      END IF;
    ELSIF V_OBJ.SXLX = 2 THEN
       null;
      /*SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND TJQJZB = V_OBJ.TJQJZB;
      IF V_COUNT > 1 THEN
        SELECT '不允许存在重复的[条件区间指标]--' || ZBMC || '!'
          INTO O_NOTE
          FROM PIF.TPIF_MBTJZB
         WHERE ID = V_OBJ.TJQJZB;
        RETURN;
      END IF;*/
    ELSIF V_OBJ.SXLX = 3 THEN
      --集合
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND SXLX = 3
         AND NVL(SSTJ, 0) = NVL(V_OBJ.SSTJ, 0);
      IF V_COUNT > 1 THEN
        O_NOTE := '不允许存在相同[限制条件]的集合!';
        RETURN;
      END IF;
    END IF;
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND XSSX = V_OBJ.XSSX;
    IF V_COUNT > 1 THEN
      O_NOTE := '不允许存在重复的[显示顺序]--' || V_OBJ.XSSX || '!';
      RETURN;
    END IF;
    BEGIN
      SELECT TYPE, REFCODE
        INTO V_TYPE, V_REFCODE
        FROM PIF.TPIF_FIELD
       WHERE ID = V_OBJ.CPSX;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF V_OBJ.MS IS NOT NULL THEN
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE ID = ''' ||
               V_REFCODE || '.' || V_OBJ.MS || ''' AND TABLENAME = ''' ||
               V_REFCODE || '''';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT = 0 THEN
        O_NOTE := '业务对象[' || V_REFCODE || ']不存在描述标识[' || V_OBJ.MS || ']!';
        RETURN;
      END IF;
    END IF;
    IF V_OBJ.IDBZ IS NOT NULL THEN
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE ID = ''' ||
               V_REFCODE || '.' || V_OBJ.IDBZ || ''' AND TABLENAME = ''' ||
               V_REFCODE || '''';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT = 0 THEN
        O_NOTE := '业务对象[' || V_REFCODE || ']不存在主键标识[' || V_OBJ.IDBZ || ']!';
        RETURN;
      END IF;
    END IF;
    IF V_OBJ.SSTJ IS NOT NULL THEN
      IF V_OBJ.SXLX = 1 THEN
        --属性字段
        --内部对象
        IF V_TYPE IN (6, 16) THEN
          V_SQL := 'SELECT COUNT(1) FROM PIF.' || V_REFCODE ||
                   ' WHERE 1 = 1 AND ' || V_OBJ.SSTJ;
          --字典型
        ELSIF V_TYPE IN (7, 15) THEN
          V_SQL := 'SELECT COUNT(1) FROM CRMII.TXTDM T WHERE T.FLDM = ''' ||
                   V_REFCODE || ''' AND ' || V_OBJ.SSTJ;
        END IF;
      ELSIF V_OBJ.SXLX = 2 THEN
        --条件区间
        V_SQL := 'SELECT COUNT(1)
                        FROM PIF.TPIF_MBTJZB, PIF.TPIF_MBTJZBQJ
                        WHERE TPIF_MBTJZB.ID = TPIF_MBTJZBQJ.GJZB AND TPIF_MBTJZB.ID = ' ||
                 V_OBJ.TJQJZB || ' AND ' || V_OBJ.SSTJ;
      ELSIF V_OBJ.SXLX = 3 THEN
        --集合
        V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPJH WHERE 1=1 AND ' ||
                 V_OBJ.SSTJ;
      END IF;
      BEGIN
        EXECUTE IMMEDIATE V_SQL
          INTO V_COUNT;
      EXCEPTION
        WHEN OTHERS THEN
          O_NOTE := '[限制条件]配置异常!';
          RETURN;
      END;
    END IF;
    IF V_OBJ.XSSX IS NULL THEN
      UPDATE TPIF_TYMBSSPZ
         SET XSSX =
             (SELECT NVL(MAX(T.XSSX), 0) + 1
                FROM TPIF_TYMBSSPZ T
               WHERE T.TYMB = V_OBJ.TYMB)
       WHERE ID = I_ID;
    END IF;
  END IF;
  IF I_OPER = 1 THEN
    --修改-----------------------------------------------------------------------
    IF V_OBJ.ZT = 1 AND V_MBZT = 1 THEN
      O_NOTE := '当前记录及模板已启用,不允许执行[修改]操作!';
      RETURN;
    END IF;
    IF I_IP = '[check]' THEN
      O_CODE := 1;
      O_NOTE := '';
      RETURN;
    END IF;
    IF V_OBJ.XSMC IS NULL THEN
      O_NOTE := '[显示名称]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX IS NULL THEN
      O_NOTE := '[属性类型]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 AND V_OBJ.YWDX IS NULL THEN
      O_NOTE := '[业务对象]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 AND V_OBJ.CPSX IS NULL THEN
      O_NOTE := '[产品属性]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 2 AND V_OBJ.TJQJZB IS NULL THEN
      O_NOTE := '[条件区间指标]不允许为空!';
      RETURN;
    END IF;
    IF V_OBJ.XSMS IS NULL THEN
      O_NOTE := '[显示模式]不允许为空!';
      RETURN;
    END IF;
    IF (V_OBJ.MS IS NOT NULL AND V_OBJ.IDBZ IS NULL) OR
       (V_OBJ.MS IS NULL AND V_OBJ.IDBZ IS NOT NULL) THEN
      O_NOTE := '[描述标识]与[主键标识]需同时存在!';
      RETURN;
    END IF;
    IF V_OBJ.SXLX = 1 THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND YWDX = V_OBJ.YWDX
         AND CPSX = V_OBJ.CPSX;
      IF V_COUNT > 1 THEN
        SELECT '不允许存在重复的[产品属性]--' || DESCRIBE || '!'
          INTO O_NOTE
          FROM PIF.TPIF_FIELD
         WHERE ID = V_OBJ.CPSX;
        RETURN; --//..:此处可允许
      END IF;
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE TABLENAME = ''' ||
               V_OBJ.YWDX || ''' AND INSTR('';''||''' || V_OBJ.CPSX ||
               '''||'';'','';''||ID||'';'') > 0';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF INSTR(V_OBJ.CPSX, ';') > 0 THEN
        IF V_COUNT !=
           (LENGTH(V_OBJ.CPSX) - LENGTH(REPLACE(V_OBJ.CPSX, ';', ''))+1) THEN
          O_NOTE := '业务对象[' || V_OBJ.YWDX || ']配置的产品属性[' || V_OBJ.CPSX ||
                    ']异常!';
          RETURN;
        END IF;
      ELSE
        IF V_COUNT = 0 THEN
          O_NOTE := '业务对象[' || V_OBJ.YWDX || ']不存在产品属性[' || V_OBJ.CPSX || ']!';
          RETURN;
        END IF;
      END IF;
    ELSIF V_OBJ.SXLX = 2 THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND TJQJZB = V_OBJ.TJQJZB;
      IF V_COUNT > 1 THEN
        SELECT '不允许存在重复的[条件区间指标]--' || ZBMC || '!'
          INTO O_NOTE
          FROM PIF.TPIF_MBTJZB
         WHERE ID = V_OBJ.TJQJZB;
        RETURN;
      END IF;
    ELSIF V_OBJ.SXLX = 3 THEN
      --集合
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_TYMBSSPZ
       WHERE TYMB = V_OBJ.TYMB
         AND SXLX = 3
         AND NVL(SSTJ, 0) = NVL(V_OBJ.SSTJ, 0);
      IF V_COUNT > 1 THEN
        O_NOTE := '不允许存在相同[限制条件]的集合!';
        RETURN;
      END IF;
    END IF;
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND XSSX = V_OBJ.XSSX;
    IF V_COUNT > 1 THEN
      O_NOTE := '不允许存在重复的[显示顺序]--' || V_OBJ.XSSX || '!';
      RETURN;
    END IF;
    BEGIN
      SELECT TYPE, REFCODE
        INTO V_TYPE, V_REFCODE
        FROM PIF.TPIF_FIELD
       WHERE ID = V_OBJ.CPSX;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF V_OBJ.MS IS NOT NULL THEN
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE ID = ''' ||
               V_REFCODE || '.' || V_OBJ.MS || ''' AND TABLENAME = ''' ||
               V_REFCODE || '''';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT = 0 THEN
        O_NOTE := '业务对象[' || V_REFCODE || ']不存在描述标识[' || V_OBJ.MS || ']!';
        RETURN;
      END IF;
    END IF;
    IF V_OBJ.IDBZ IS NOT NULL THEN
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_Field WHERE ID = ''' ||
               V_REFCODE || '.' || V_OBJ.IDBZ || ''' AND TABLENAME = ''' ||
               V_REFCODE || '''';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT = 0 THEN
        O_NOTE := '业务对象[' || V_REFCODE || ']不存在主键标识[' || V_OBJ.IDBZ || ']!';
        RETURN;
      END IF;
    END IF;
    IF V_OBJ.SSTJ IS NOT NULL THEN
     IF V_OBJ.SXLX = 1 THEN
        --属性字段
        --内部对象
        IF V_TYPE IN (6, 16) THEN
          V_SQL := 'SELECT COUNT(1) FROM PIF.' || V_REFCODE ||
                   ' WHERE 1 = 1 AND ' || V_OBJ.SSTJ;
          --字典型
        ELSIF V_TYPE IN (7, 15) THEN
          V_SQL := 'SELECT COUNT(1) FROM CRMII.TXTDM T WHERE T.FLDM = ''' ||
                   V_REFCODE || ''' AND ' || V_OBJ.SSTJ;
        END IF;
      ELSIF V_OBJ.SXLX = 2 THEN
        --条件区间
        V_SQL := 'SELECT COUNT(1)
                        FROM PIF.TPIF_MBTJZB, PIF.TPIF_MBTJZBQJ
                        WHERE TPIF_MBTJZB.ID = TPIF_MBTJZBQJ.GJZB AND TPIF_MBTJZB.ID = ' ||
                 V_OBJ.TJQJZB || ' AND ' || V_OBJ.SSTJ;
      ELSIF V_OBJ.SXLX = 3 THEN
        --集合
        V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPJH WHERE 1=1 AND ' ||
                 V_OBJ.SSTJ;
      END IF;
      BEGIN
        EXECUTE IMMEDIATE V_SQL
          INTO V_COUNT;
      EXCEPTION
        WHEN OTHERS THEN
          O_NOTE := '[限制条件]配置异常!';
          RETURN;
      END;
    END IF;
    IF V_OBJ.XSSX IS NULL THEN
      UPDATE TPIF_TYMBSSPZ
         SET XSSX =
             (SELECT NVL(MAX(T.XSSX), 0) + 1
                FROM TPIF_TYMBSSPZ T
               WHERE T.TYMB = V_OBJ.TYMB)
       WHERE ID = I_ID;
    END IF;
  END IF;
  IF I_OPER = 2 THEN
    --删除-----------------------------------------------------------------------
    IF V_OBJ.ZT = 1 AND V_MBZT = 1 THEN
      O_NOTE := '当前记录及模板已启用,不允许执行[删除]操作!';
      RETURN;
    END IF;
    SELECT FUNC_PIF_JYSFYY('TPIF_TYMBSSPZ', I_ID) INTO V_COUNT FROM DUAL;
    IF V_COUNT = 1 THEN
      O_NOTE := '当前配置已存在引用记录!';
      RETURN;
    END IF;
    IF I_IP = '[check]' THEN
      O_CODE := 1;
      O_NOTE := '';
      RETURN;
    END IF;
    DELETE TPIF_TYMBSSPZ WHERE ID = I_ID;
  END IF;
  IF I_OPER = 3 THEN
    --启用-----------------------------------------------------------------
    IF V_OBJ.ZT = 1 THEN
      O_NOTE := '当前记录已[启用]!';
      RETURN;
    END IF;
    UPDATE TPIF_TYMBSSPZ SET ZT = 1 WHERE ID = I_ID;
  END IF;
  IF I_OPER = 4 THEN
    --禁用-----------------------------------------------------------------
    IF V_OBJ.ZT = -1 THEN
      O_NOTE := '当前记录已[禁用]!';
      RETURN;
    END IF;
    IF V_MBZT = 1 THEN
      O_NOTE := '当前主模板定义记录已[启用]!';
      RETURN;
    END IF;
    UPDATE TPIF_TYMBSSPZ SET ZT = -1 WHERE ID = I_ID;
  END IF;
  IF I_OPER = 6 THEN
    --上移-----------------------------------------------------------------------
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND ID != I_ID;
    IF V_COUNT = 0 THEN
      O_NOTE := '当前模板范围内不存在其他数据!';
      RETURN;
    END IF;
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND ID != I_ID
       AND XSSX < V_OBJ.XSSX;
    IF V_COUNT = 0 THEN
      O_NOTE := '当前记录已处于允许的最高排序!';
      RETURN;
    END IF;
    SELECT T.ID, T.XSSX
      INTO V_ZHID, V_XSSX
      FROM TPIF_TYMBSSPZ T
     WHERE T.TYMB = V_OBJ.TYMB
       AND T.ID != I_ID
       AND T.XSSX = (SELECT MAX(A.XSSX)
                       FROM TPIF_TYMBSSPZ A
                      WHERE A.TYMB = V_OBJ.TYMB
                        AND A.ID != I_ID
                        AND A.XSSX < V_OBJ.XSSX)
       AND ROWNUM = 1;
    UPDATE TPIF_TYMBSSPZ SET XSSX = V_XSSX WHERE ID = I_ID;
    UPDATE TPIF_TYMBSSPZ SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
  END IF;
  IF I_OPER = 7 THEN
    --下移-----------------------------------------------------------------------
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND ID != I_ID;
    IF V_COUNT = 0 THEN
      O_NOTE := '当前模板范围内不存在其他数据!';
      RETURN;
    END IF;
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_TYMBSSPZ
     WHERE TYMB = V_OBJ.TYMB
       AND ID != I_ID
       AND XSSX > V_OBJ.XSSX;
    IF V_COUNT = 0 THEN
      O_NOTE := '当前记录已处于允许的最低排序!';
      RETURN;
    END IF;
    SELECT T.ID, T.XSSX
      INTO V_ZHID, V_XSSX
      FROM TPIF_TYMBSSPZ T
     WHERE T.TYMB = V_OBJ.TYMB
       AND T.ID != I_ID
       AND T.XSSX = (SELECT MIN(A.XSSX)
                       FROM TPIF_TYMBSSPZ A
                      WHERE A.TYMB = V_OBJ.TYMB
                        AND A.ID != I_ID
                        AND A.XSSX > V_OBJ.XSSX)
       AND ROWNUM = 1;
    UPDATE TPIF_TYMBSSPZ SET XSSX = V_XSSX WHERE ID = I_ID;
    UPDATE TPIF_TYMBSSPZ SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
  END IF;
  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '启用',
                         4,
                         '禁用',
                         6,
                         '上移',
                         '下移') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_TYMBSSPZ;

/

