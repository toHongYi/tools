create PROCEDURE PRO_PIF_ZGCPYSLR(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_USER IN INTEGER, --操作人
                                             I_IP   IN VARCHAR2, --操作IP
                                             I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|提交复核;4|复核确认
                                             I_ID   IN INTEGER, --操作ID
                                             I_IDS  IN VARCHAR2 --批量操作ID串
                                             ) IS

  /******************************************************************
      项目名称：资管产品要素录入后台处理逻辑
      所属用户：PIF
      功能说明：产品要素录入相关操作
      语法信息：
           输入参数：   I_USER  操作人
                        I_IP    操作IP
                        I_OPER  操作类型0|新增;1|修改;2|删除;3|提交复核;4|复核确认
                        I_ID    操作ID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-09-3     1.0   WUJINFENG                创建
  ***********************************************************************/

  V_IDS VARCHAR2(2000);
  V_ROW NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --复核确认
  IF I_OPER = 4 THEN

    SELECT REPLACE(REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''),
                           ']',
                           ''),
                   ',',
                   ';')
      INTO V_IDS
      FROM DUAL;

    INSERT INTO TPIF_CPDM
      (ID,
       CPID,
       CPJD, --  产品阶段
       CPnbzt, --  产品状态标志
       RKSJ, -- 入库时间
       RKCZR, -- 入库操作人
       --sjsj,
       --sjczr,
       PT, -- 柜台
       CPDM, --产品代码
       CPjc, --产品名称
       CPMC, --产品全称
       HBZL, --货币种类
       MJKSRQ, --认购起始日期
       MJJSRQ, --认购结束日期
       CLRQ, --成立日期
       DQRQ, --到期日期
       CPQX, --产品期限
       --DFRQ, --兑付日期
       CPZDMJJE, --产品规模下限
       CPZGMJJE, --产品规模上限
       CPXL, --产品系列
       JRCPFL, --金融产品分类
      -- CPFL_PZLB, --配置类别
      
       CPFXDJ, --风险等级
       SYLX, --收益特征
       --CPFL_GGBD, --挂钩标的
       TZLB, --投资品种
       CPTZQX, --投资期限
       CPGLRID, --管理人
       CPTGR, --托管人
       CPTAMC, --登记机构
       CPJL, --产品经理
       CPZGBM--供给部门
      

       )

      SELECT livebos.FUNC_NEXTID('TPIF_CPDM'),
             null,
             (CASE
               WHEN RGJSRQ >= TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
                2
               ELSE
                3
             END), --  产品阶段
             1, -- 上架  产品状态标志
             SYSDATE, -- 入库时间
             I_USER, -- 入库操作人
             --TO_CHAR(SYSDATE, 'YYYYMMDD'), -- 上架时间
             --I_USER, -- 上架操作人
             3, --  柜台
             CPDM,
             CPMC,
             CPQC,
             HBZL,
             RGQSRQ,
             RGJSRQ,
             CLRQ,
             DQRQ,
             CPQX,
             --DFRQ,
             CPGMXX,
             CPGMSX,
             CPXL,
             JRCPFL,
            -- CPFL_PZLB,
             CPFL_FXDJ,
             CPFL_SYTZ,
             --CPFL_GGBD,
             CPFL_TZPZ,
             CPFL_TZQX,
             CPGLRid,
             CPTGRID,
             ZCDJJG,
             CPJL,
             GJBM 
        FROM TPIF_ZGCPYSLR A
       WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0
         AND NOT EXISTS
       (SELECT 1 FROM TPIF_CPDM B WHERE B.CPDM = A.CPDM);

    V_ROW := SQL%ROWCOUNT;

    --更新id为cpid
    UPDATE TPIF_CPDM A
       SET A.CPID = A.ID
     WHERE trunc(RKSJ) =  trunc(SYSDATE) -- 入库时间
       AND RKCZR = I_USER
       AND A.CPID  is null ;

    --更改记录状态为 2
    UPDATE TPIF_ZGCPYSLR A
       SET A.ZT = 2
     WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0;

    O_NOTE := '复核成功,共入库 ' || V_ROW || ' 只产品';
  END IF;
  O_CODE := 199;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -99;
    O_NOTE := '复核确认失败:' || SQLERRM;
END;
/

