create PROCEDURE PRO_PIF_JHSX(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2, --返回消息
                                              I_USER IN INTEGER, --操作人
                                              I_IP   IN VARCHAR2, --操作IP
                                              I_OPER IN INTEGER, --操作类型0|集合刷新;1|标签刷新;2|专题刷新;
                                              I_ID   IN INTEGER --操作ID
                                              ) IS
    /*
    **功能说明：集合刷新
    **创建人：戴文生
    **创建日期：2014-12-01
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生              2014-12-01    创建
    */
    V_COUNT INTEGER; --计数变量
    V_I INTEGER; --计数变量
    V_BQ INTEGER; --计数变量
    V_ZT INTEGER; --计数变量
    V_ID INTEGER;
    V_CPJH  VARCHAR2(2000);
    --V_SCBZ    INTEGER; --日志删除标识
    --V_OPER    VARCHAR2(200); --操作方法
    --V_FDETAIL VARCHAR2(2000); --日志操作明细
    V_NOTE VARCHAR2(8000);
    V_SQL VARCHAR2(8000);
    V_YSLY INTEGER;
    V_CID     INTEGER;
    TYPE TYPE_CUR IS REF CURSOR;
    CURSOR_CPID TYPE_CUR;
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        V_BQ := 0;
        V_ZT := 0;
        --//:集合刷新-----------------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPJH WHERE ID = I_ID OR NVL(I_ID,0) = 0) LOOP
            --BQ->CP
            FOR CUR_BQ IN (SELECT * FROM TPIF_CPBQMX WHERE INSTR(';'||CPJH||';',';'||CUR.ID||';') > 0 AND NVL(YSLY,0) = 0) LOOP
                V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE CPNBZT >= 8 AND TPIF_CPDM.ID = '||CUR_BQ.CPID||' AND '||CUR.SQLWHERE;
                EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                IF V_COUNT = 0 THEN
                    V_CPJH := SUBSTR(REPLACE(';'||CUR_BQ.CPJH||';',CUR.ID||';',''),2);
                    IF V_CPJH IS NULL THEN
                        DELETE TPIF_CPBQMX WHERE ID = CUR_BQ.ID;
                    ELSE
                        UPDATE TPIF_CPBQMX SET CPJH = V_CPJH;
                    END IF;
                    V_BQ := V_BQ + 1;
                END IF;
            END LOOP;
            --CP->BQ
            FOR CUR_BQ IN (SELECT * FROM TPIF_CPBQ WHERE YSFS = 1 AND INSTR(';'||CPJH||';',';'||CUR.ID||';') > 0) LOOP
                FOR CUR_CP IN (SELECT ID FROM TPIF_CPDM WHERE CPNBZT >= 8) LOOP
                    V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE TPIF_CPDM.ID = '||CUR_CP.ID||' AND '||CUR.SQLWHERE;
                    EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                    IF V_COUNT > 0 THEN
                        SELECT COUNT(1) INTO V_I FROM TPIF_CPBQMX WHERE CPBQ = CUR_BQ.ID AND CPID = CUR_CP.ID;
                        IF V_I = 0 THEN
                            livebos.PNEXTID('TPIF_CPBQMX', V_ID);
                            INSERT INTO TPIF_CPBQMX (ID, CPBQ, CPID, YSLY, CPJH , CZSJ)
                            VALUES (V_ID, CUR_BQ.ID, CUR_CP.ID, 0, CUR.ID, SYSDATE);
                            UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID), 0) FROM TPIF_CPBQMX) WHERE NAME = 'TPIF_CPBQMX';
                            V_BQ := V_BQ + 1;
                        ELSE
                            SELECT ID, NVL(YSLY,0), CPJH
                              INTO V_ID, V_YSLY, V_CPJH
                              FROM TPIF_CPBQMX WHERE CPBQ = CUR_BQ.ID AND CPID = CUR_CP.ID;
                            IF V_YSLY = 0 THEN
                                IF V_CPJH IS NULL THEN
                                    UPDATE TPIF_CPBQMX SET CPJH = CUR.ID WHERE ID = V_ID;
                                    V_BQ := V_BQ + 1;
                                ELSE
                                    IF INSTR(';'||V_CPJH||';',';'||CUR.ID||';') = 0 THEN
                                        UPDATE TPIF_CPBQMX SET CPJH = CPJH||';'||CUR.ID WHERE ID = V_ID;
                                        V_BQ := V_BQ + 1;
                                    END IF;
                                END IF;
                            END IF;
                        END IF;
                    END IF;
                END LOOP;
            END LOOP;
            --ZT->CP
            FOR CUR_ZT IN (SELECT * FROM TPIF_CPZTMX WHERE INSTR(';'||CPJH||';',';'||CUR.ID||';') > 0 AND NVL(YSLY,0) = 0) LOOP
                V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE CPNBZT >= 8 AND TPIF_CPDM.ID = '||CUR_ZT.CPID||' AND '||CUR.SQLWHERE;
                EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                IF V_COUNT = 0 THEN
                    V_CPJH := SUBSTR(REPLACE(';'||CUR_ZT.CPJH||';',CUR.ID||';',''),2);
                    IF V_CPJH IS NULL THEN
                        DELETE TPIF_CPZTMX WHERE ID = CUR_ZT.ID;
                    ELSE
                        UPDATE TPIF_CPZTMX SET CPJH = V_CPJH;
                    END IF;
                    V_ZT := V_ZT + 1;
                END IF;
            END LOOP;
            --CP->ZT
            FOR CUR_ZT IN (SELECT * FROM TPIF_CPZT WHERE YSFS = 1 AND INSTR(';'||CPJH||';',';'||CUR.ID||';') > 0) LOOP
                FOR CUR_CP IN (SELECT ID FROM TPIF_CPDM WHERE CPNBZT >= 6) LOOP
                    V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE TPIF_CPDM.ID = '||CUR_CP.ID||' AND '||CUR.SQLWHERE;
                    EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                    IF V_COUNT > 0 THEN
                        SELECT COUNT(1) INTO V_I FROM TPIF_CPZTMX WHERE CPZT = CUR_ZT.ID AND CPID = CUR_CP.ID;
                        IF V_I = 0 THEN
                            livebos.PNEXTID('TPIF_CPZTMX', V_ID);
                            INSERT INTO TPIF_CPZTMX (ID, CPZT, CPID, YSLY, CPJH, CZSJ)
                            VALUES (V_ID, CUR_ZT.ID, CUR_CP.ID, 0, CUR.ID, SYSDATE);
                            UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID), 0) FROM TPIF_CPZTMX) WHERE NAME = 'TPIF_CPZTMX';
                            V_ZT := V_ZT + 1;
                        ELSE
                            SELECT ID, NVL(YSLY,0), CPJH
                              INTO V_ID, V_YSLY, V_CPJH
                              FROM TPIF_CPZTMX WHERE CPZT = CUR_ZT.ID AND CPID = CUR_CP.ID;
                            IF V_YSLY = 0 THEN
                                IF V_CPJH IS NULL THEN
                                    UPDATE TPIF_CPZTMX SET CPJH = CUR.ID WHERE ID = V_ID;
                                    V_ZT := V_ZT + 1;
                                ELSE
                                    IF INSTR(';'||V_CPJH||';',';'||CUR.ID||';') = 0 THEN
                                        UPDATE TPIF_CPZTMX SET CPJH = CPJH||';'||CUR.ID WHERE ID = V_ID;
                                        V_ZT := V_ZT + 1;
                                    END IF;
                                END IF;
                            END IF;
                        END IF;
                    END IF;
                END LOOP;
            END LOOP;
        END LOOP;
        IF NVL(I_ID,0) = 0 THEN
            livebos.PNEXTID('TPIF_XJRZ', V_ID);
            V_NOTE := '巡检正常!';
            IF V_BQ > 0 THEN
                V_NOTE := V_NOTE||'处理标签关联产品['||V_BQ||']个;';
            END IF;
            IF V_ZT > 0 THEN
                V_NOTE := V_NOTE||'处理专题关联产品['||V_ZT||']个;';
            END IF;
            INSERT INTO TPIF_XJRZ (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_004'
                           AND ROWNUM = 1),
                       '<font color=green>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --//:标签刷新-----------------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPBQ WHERE NVL(YSFS, 0) = 1 AND (ID = I_ID OR NVL(I_ID,0) = 0)) LOOP
            DELETE TPIF_CPBQMX WHERE CPBQ = CUR.ID AND NVL(YSLY,0) = 0;
            FOR CUR_JH IN (SELECT *
                            FROM TPIF_CPJH
                           WHERE INSTR(';' || CUR.CPJH || ';', ';' || ID || ';') > 0) LOOP
                V_SQL := 'SELECT ID FROM PIF.TPIF_CPDM WHERE CPNBZT >= 8 AND ' || CUR_JH.SQLWHERE;
                OPEN CURSOR_CPID FOR V_SQL;
                LOOP
                    EXIT WHEN CURSOR_CPID%NOTFOUND;
                    FETCH CURSOR_CPID
                        INTO V_CID;
                    IF CURSOR_CPID%FOUND THEN
                        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_CPBQMX WHERE CPBQ = CUR.ID AND CPID = V_CID;
                        IF V_COUNT = 0 THEN
                            livebos.PNEXTID('TPIF_CPBQMX', V_ID);
                            INSERT INTO PIF.TPIF_CPBQMX
                                (ID, CPBQ, CPID, YSLY, CPJH, CZSJ)
                            VALUES
                                (V_ID, CUR.ID, V_CID, 0,CUR_JH.ID , SYSDATE);
                            UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID), 0) FROM TPIF_CPBQMX) WHERE NAME = 'TPIF_CPBQMX';
                        ELSE
                            SELECT ID,NVL(YSLY,0) INTO V_ID,V_YSLY FROM TPIF_CPBQMX WHERE CPBQ = CUR.ID AND CPID = V_CID;
                            IF V_YSLY = 0 THEN
                                UPDATE TPIF_CPBQMX SET CPJH = SUBSTR(';'||CPJH||';'||CUR_JH.ID,2) WHERE ID = V_ID;
                            END IF;
                        END IF;
                    END IF;
                END LOOP;
                CLOSE CURSOR_CPID;
            END LOOP;
        END LOOP;
    END IF;
    IF I_OPER = 2 THEN
        --//:专区刷新-----------------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPZT WHERE TYPE = 2 AND NVL(YSFS, 0) = 1 AND (ID = I_ID OR NVL(I_ID,0) = 0)) LOOP
            DELETE TPIF_CPZTMX WHERE CPZT = CUR.ID AND NVL(YSLY,0) = 0;
            FOR CUR_JH IN (SELECT *
                            FROM TPIF_CPJH
                           WHERE INSTR(';' || CUR.CPJH || ';', ';' || ID || ';') > 0) LOOP
                V_SQL := 'SELECT ID FROM PIF.TPIF_CPDM WHERE CPNBZT >= 8 AND ' || CUR_JH.SQLWHERE;
                OPEN CURSOR_CPID FOR V_SQL;
                LOOP
                    EXIT WHEN CURSOR_CPID%NOTFOUND;
                    FETCH CURSOR_CPID
                        INTO V_CID;
                    IF CURSOR_CPID%FOUND THEN
                        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_CPZTMX WHERE CPZT = CUR.ID AND CPID = V_CID;
                        IF V_COUNT = 0 THEN
                            livebos.PNEXTID('TPIF_CPZTMX', V_ID);
                            INSERT INTO PIF.TPIF_CPZTMX
                                (ID, CPZT, CPID, YSLY, CPJH, CZSJ)
                            VALUES
                                (V_ID, CUR.ID, V_CID, 0, CUR_JH.ID, SYSDATE);
                            UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID), 0) FROM TPIF_CPZTMX) WHERE NAME = 'TPIF_CPZTMX';
                        ELSE
                            SELECT ID,NVL(YSLY,0) INTO V_ID,V_YSLY FROM TPIF_CPZTMX WHERE CPZT = CUR.ID AND CPID = V_CID;
                            IF V_YSLY = 0 THEN
                                UPDATE TPIF_CPZTMX SET CPJH = SUBSTR(';'||CPJH||';'||CUR_JH.ID,2) WHERE ID = V_ID;
                            END IF;
                        END IF;
                    END IF;
                END LOOP;
                CLOSE CURSOR_CPID;
            END LOOP;
        END LOOP;
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '集合刷新', 1, '标签刷新', '专题刷新') || ']成功!' INTO O_NOTE FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JHSX;
/

