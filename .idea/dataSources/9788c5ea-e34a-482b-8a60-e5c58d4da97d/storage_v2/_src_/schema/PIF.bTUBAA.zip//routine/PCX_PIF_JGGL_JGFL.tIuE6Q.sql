create PROCEDURE PCX_PIF_JGGL_JGFL(O_CODE   OUT NUMBER,
                                                  O_NOTE   OUT VARCHAR2,
                                                  O_RESULT OUT SYS_REFCURSOR
                                                  
                                                  ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 机构管理-机构分类查询 
  
      语法信息：
           输入参数：     
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  --ORG_TYPE  机构分类ID
  --ORG_TYPE_DESC 机构分类描述
  OPEN O_RESULT FOR
    SELECT GSFL AS ORG_TYPE,
           (SELECT NOTE
              FROM LIVEBOS.TXTDM
             WHERE FLDM = 'PIF_GLR_GSFL'
               AND IBM = A.GSFL) AS ORG_TYPE_DESC
    -- COUNT(*)
    
      FROM TPIF_JGDM A
     GROUP BY GSFL
     ORDER BY COUNT(*) DESC ;
     
     
EXCEPTION WHEN OTHERS THEN
  O_CODE := -1;
  O_NOTE := '失败:' || SQLERRM;
  OPEN O_RESULT FOR
            SELECT O_NOTE FROM DUAL;

END;
/

