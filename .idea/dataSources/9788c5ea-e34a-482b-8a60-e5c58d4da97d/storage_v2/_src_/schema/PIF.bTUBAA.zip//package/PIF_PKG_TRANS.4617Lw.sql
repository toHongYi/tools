create PACKAGE PIF_PKG_TRANS IS

  --清洗程序主调度
  PROCEDURE PRO_PIF_TRANS_MAIN(O_CODE OUT NUMBER,
                               O_NOTE OUT VARCHAR2,
                               I_BID  IN NUMBER); --清洗表ID

  --清洗程序开始日志
  PROCEDURE PRO_PIF_TRANS_BEGIN(O_CODE OUT NUMBER,
                                O_NOTE OUT VARCHAR2,
                                O_RZID OUT NUMBER, --日志ID
                                I_BID  IN NUMBER --清洗表ID
                                );

  --清洗程序结束日志
  PROCEDURE PRO_PIF_TRANS_END(O_CODE OUT NUMBER,
                              O_NOTE OUT VARCHAR2,
                              I_BID  IN NUMBER --清洗表ID
                              );

  --记录清洗日志
  PROCEDURE PRO_PIF_TRANS_LOG(I_RZID IN NUMBER, --ID
                              I_SJL  IN NUMBER,
                              I_ZT   IN NUMBER,
                              I_BZ   IN VARCHAR2);

  --产品代码表清洗逻辑
  PROCEDURE PRO_TPIF_CPDM(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品开发属性
  PROCEDURE PRO_TPIF_CPDM_P_GT(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER);

  --集中柜台-销售控制
  PROCEDURE PRO_TPIF_CPDM_P_GT_XSKZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品业务设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_YWSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品额度设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_EDSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品延迟交收设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_YCJS(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品折扣设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_ZKSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品限额设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_XESZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品报送代码设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_BSDMSZ(O_CODE     OUT NUMBER,
                                      O_NOTE     OUT VARCHAR2,
                                      O_ROWCOUNT OUT NUMBER,
                                      I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品控制串
  PROCEDURE PRO_TPIF_CPDM_P_GT_KZC(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER);

  --集中柜台-产品TA信息
  PROCEDURE PRO_TPIF_TADM(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER);

  --产品净值 TPIF_CPJZ
  PROCEDURE PRO_TPIF_CPJZ(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER);

  --公募基金扩展属性 TPIF_CPDM_N_GMJJ
  PROCEDURE PRO_TPIF_CPDM_N_GMJJ(O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER);

  --产品销售费率 TPIF_CPDM_GL_XSFL
  PROCEDURE PRO_TPIF_CPDM_GL_XSFL(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --基金分红信息-TPIF_CPDM_GL_JJFH                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJFH(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --基金拆分信息-TPIF_CPDM_GL_JJCF                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJCF(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --基金行业投资-TPIF_CPDM_GL_JJHYTZ                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJHYTZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --基金资产配置-TPIF_CPDM_GL_JJZCPZ                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZCPZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --基金重仓股票-TPIF_CPDM_GL_JJZCGP                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZCGP(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --基金债券组合明细 TPIF_CPDM_GL_JJZQZH                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZQZH(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);
                                    
  --公募基金经理 TPIF_GMJJJL                  
  PROCEDURE PRO_TPIF_GMJJJL(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);
                                    
  --产品收益指标 TPIF_CPDM_GL_JJZQZH                  
  PROCEDURE PRO_TPIF_ZB_CP_SYZB(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);
                                    

                                    
END;
/

