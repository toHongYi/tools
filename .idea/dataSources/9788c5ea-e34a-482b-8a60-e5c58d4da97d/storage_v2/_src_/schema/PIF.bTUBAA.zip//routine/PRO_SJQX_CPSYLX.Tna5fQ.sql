create PROCEDURE PRO_SJQX_CPSYLX(O_CODE OUT NUMBER, --返回值
                                            O_NOTE OUT VARCHAR2 --返回消息
                                            ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品收益类型表 TPIF_CPSYLX 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-09-14     1.0       韩乔楠              创建

  ***********************************************************************/
  V_COUNT NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  MERGE INTO TPIF_CPSYLX T1
  USING (SELECT T.CPID,
                CASE
                  WHEN EXISTS (SELECT 1
                          FROM TPIF_CPDM   A,
                               TPIF_CPBQ   B,
                               TPIF_CPBQMX C,
                               TPIF_BQLX   D
                         WHERE A.CPID = C.CPID
                           AND B.ID = C.CPBQ
                           AND B.BQLX = D.ID
                           AND D.BQLXBM = 'CPXS_GSL'
                           AND A.CPID = T.CPID) THEN 1
                  WHEN EXISTS (SELECT 1
                          FROM TPIF_CPDM   A,
                               TPIF_CPBQ   B,
                               TPIF_CPBQMX C,
                               TPIF_BQLX   D
                         WHERE A.CPID = C.CPID
                           AND B.ID = C.CPBQ
                           AND B.BQLX = D.ID
                           AND D.BQLXBM = 'CPXS_QYL'
                           AND A.CPID = T.CPID) THEN 2
                  WHEN EXISTS (SELECT 1
                          FROM TPIF_CPDM   A,
                               TPIF_CPBQ   B,
                               TPIF_CPBQMX C,
                               TPIF_BQLX   D
                         WHERE A.CPID = C.CPID
                           AND B.ID = C.CPBQ
                           AND B.BQLX = D.ID
                           AND D.BQLXBM = 'CPXS_HBL'
                           AND A.CPID = T.CPID) THEN 3
                  ELSE
                   NULL
                END AS SYLX
           FROM TPIF_CPDM T) T2
  ON (T1.CPID = T2.CPID)
  WHEN MATCHED THEN
    UPDATE SET T1.SYLX = T2.SYLX
  WHEN NOT MATCHED THEN
    INSERT (T1.ID,T1.CPID, T1.SYLX) VALUES (LIVEBOS.FUNC_NEXTID('TPIF_CPSYLX'),T2.CPID, T2.SYLX);

  COMMIT;

  O_CODE := 1;
  O_NOTE := 'TPIF_CPSYLX 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPSYLX 表清洗,未知错误'
                ELSE
                 'TPIF_CPSYLX 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

