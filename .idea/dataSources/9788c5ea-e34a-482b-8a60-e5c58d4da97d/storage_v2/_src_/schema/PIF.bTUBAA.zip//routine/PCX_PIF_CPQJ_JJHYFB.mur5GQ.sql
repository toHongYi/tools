create PROCEDURE PCX_PIF_CPQJ_JJHYFB(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                O_RESULT  OUT SYS_REFCURSOR,
                                                I_USERID  IN NUMBER,
                                                I_PROD_ID IN NUMBER --产品专区ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询基金行业分布
  所属用户：PIF
  概要说明：查询基金行业分布.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金行业分布.
        
        最多展示前5条，多了页面会不展示
        
        公募取聚源的数据，私募数据太少且旧，不要
        
        取 证监会行业分类2012版
                
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/29     1.0.0.1   TUMENG             新增.
      2021-12-10     1.0.0.2   GAOKUN            根据财通的表进行修改
  *********************************************************************************************************************/
  V_SQL      VARCHAR2(4000);
  V_COUNT    NUMBER;
  V_CPLX     NUMBER; --产品类型
  V_CPDM     VARCHAR2(200); --根据入参 CPID 从产品代码表获取产品代码
  V_MAINCODE VARCHAR2(200); --公募基金概况表的主代码
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  BEGIN
    --获取产品类型，产品代码
    SELECT CPXL, TRIM(CPDM)
      INTO V_CPLX, V_CPDM
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
      V_CPDM := '0';
  END;

  IF V_CPLX = 1 THEN
    --公募
    SELECT COUNT(1) --先根据SECUCODE判断是否有记录
      INTO V_COUNT
      FROM INFO.TINFO_JJGK
     WHERE SECUCODE = V_CPDM;
  
    IF V_COUNT > 0 THEN
      --有则取主代码
      SELECT MAINCODE
        INTO V_MAINCODE
        FROM INFO.TINFO_JJGK
       WHERE SECUCODE = V_CPDM;
    
    ELSE
      --没有则根据后端代码取
      BEGIN
        SELECT MAINCODE
          INTO V_MAINCODE
          FROM INFO.TINFO_JJGK
         WHERE APPLYINGCODEBACK = V_CPDM;
      EXCEPTION
        WHEN OTHERS THEN
          V_MAINCODE := '0';
      END;
    END IF;
  
    V_SQL := ' SELECT A.INDUSTRYCODE AS INDUSTRY_CODE,
                      A.INDUSTRYNAME AS INDUSTRY_NAME,
                      TO_CHAR(A.MARKETVALUE/10000,''FM99999990.0999'') AS INDUSTRY_MKTVALUE,
                      TO_CHAR(A.RATIOINNV*100,''FM9990.00'') AS OCCUPY_NAV_RATIO
                 FROM INFO.TINFO_JJHYTZ A
                WHERE A.SECUCODE = ''' || V_MAINCODE || '''
                  AND A.INDUSTANDARD = 22 --证监会行业分类2012版
                  AND A.INDUSTRYCODE != 10001 --去除 行业投资合计
                  AND A.REPORTDATE = (SELECT MAX(B.REPORTDATE)
                                       FROM INFO.TINFO_JJHYTZ B
                                      WHERE B.SECUCODE = ''' || V_MAINCODE || ''')
                  AND ROWNUM <=5
             ORDER BY A.RATIOINNV DESC';
  
  ELSE
    V_SQL := 'SELECT NULL AS INDUSTRY_CODE,
                   NULL AS INDUSTRY_NAME,
                   NULL AS INDUSTRY_MKTVALUE,
                   NULL AS OCCUPY_NAV_RATIO
              FROM DUAL
             WHERE 1=0';
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_JJHYFB;
/

