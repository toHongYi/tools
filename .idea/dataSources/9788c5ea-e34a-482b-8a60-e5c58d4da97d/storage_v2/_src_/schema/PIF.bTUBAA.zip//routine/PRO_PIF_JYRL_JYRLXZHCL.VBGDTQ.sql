create PROCEDURE PRO_PIF_JYRL_JYRLXZHCL(O_CODE OUT NUMBER, --返回值
                                                       O_NOTE OUT VARCHAR2, --返回消息
                                                       I_RLID IN NUMBER, --产品日历ID
                                                       I_BWL  IN VARCHAR2 DEFAULT '') IS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：交易日历手动同时新增多个日期

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-07-13     V1.0      谢莉莉             创建
        2016-10-26     V2.0      王大一             托管系统迁移改造接入产品中心
     *********************************************************************************************************************/

    V_COUNT NUMBER; --判断
    V_CPID  NUMBER; --产品ID
    V_YXJYR NUMBER; --运行交易日
    V_YWLX  VARCHAR2(300); --业务类型ID串
    I_CZR   NUMBER; --操作人或备份人
    I_CZRQ  DATE; --操作日期或备份日期
    I_GZLX  NUMBER; --规则类型[1|正常;2|特殊]
    I_GZJL  NUMBER; --规则记录ID
    I_SHZT  NUMBER; --审核状态
    V_CZR   NUMBER;
    V_JJNF  NUMBER; --节假年份

BEGIN
    O_CODE := 1;
    O_NOTE := '操作成功';

    --取得产品ID，运行交易日，业务类型
    SELECT CPID, JYRLX, GZJL, CZR
      INTO V_CPID, V_YXJYR, V_YWLX, V_CZR
      FROM TPIF_JYRL
     WHERE ID = I_RLID;
    --判断该产品是否存在特殊业务规则
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL_GZJL
     WHERE CPID = V_CPID
       AND GZJLLX = 2;
    IF (V_COUNT = 0) THEN
        PRO_PIF_JYRL_DDGZSZ(O_CODE,
                            O_NOTE,
                            I_GZJL,
                            V_CPID,
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            2,
                            I_BWL);
    ELSE
        SELECT ID, SHZT
          INTO I_GZJL, I_SHZT
          FROM TPIF_JYRL_GZJL
         WHERE CPID = V_CPID
           AND GZJLLX = 2;
        /*IF(I_SHZT = 1)THEN
        --审核通过的，不让新增
            O_CODE := -1;
            O_NOTE := '该产品特殊规则已审核通过!';
            RETURN;
        END IF;*/
        UPDATE TPIF_JYRL_GZJL
           SET BWL = I_BWL
         WHERE CPID = V_CPID
           AND GZJLLX = 2;
    END IF;
    --日期
    FOR JYRL IN (SELECT YWFQRQ
                   FROM (SELECT YWFQRQ
                           FROM TPIF_JYRL_YWFQRQ
                          WHERE TPIF_JYRL_ID = I_RLID
                         UNION
                         SELECT RQ
                           FROM TPIF_JYRL
                          WHERE ID = I_RLID
                            AND GZJL IS NOT NULL
                            AND RQ IS NOT NULL) C
                  ORDER BY YWFQRQ) LOOP
        --判断工作日表是否包含该日期
        --业务类型
        FOR YWLX IN (SELECT REGEXP_SUBSTR(V_YWLX, '[^;]+', 1, ROWNUM) ID
                       FROM DUAL
                     CONNECT BY ROWNUM <= LENGTH(REGEXP_REPLACE(V_YWLX, '[^;]', NULL)) + 1) LOOP
            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                    O_NOTE,
                                    JYRL.YWFQRQ,
                                    I_GZJL,
                                    YWLX.ID,
                                    V_YXJYR,
                                    V_CZR);
        END LOOP;

    END LOOP;
    --对未配置节假日的年份插入节假日处理规则
    --取得配置的最新节假日年份
    SELECT MAX(NF) INTO V_JJNF FROM LIVEBOS.TJRXX;
    UPDATE TPIF_JYRL
       SET JJRCLGZ =
           (SELECT JJRCLGZ FROM TPIF_JYRL WHERE ID = I_RLID)
     WHERE INSTR(';' || GZJL || ';', ';' || I_GZJL || ';') > 0
       AND SUBSTR(TO_CHAR(RQ, 'YYYYMMDD'), 0, 4) > V_JJNF
       AND JJRCLGZ IS NULL;

    DELETE FROM TPIF_JYRL WHERE ID = I_RLID;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JYRL_JYRLXZHCL;
/

