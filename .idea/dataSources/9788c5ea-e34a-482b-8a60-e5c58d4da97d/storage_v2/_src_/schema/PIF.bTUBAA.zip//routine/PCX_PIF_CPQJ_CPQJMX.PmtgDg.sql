create PROCEDURE PCX_PIF_CPQJ_CPQJMX(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                O_RESULT  OUT SYS_REFCURSOR,
                                                I_USER_ID IN NUMBER, --用户ID
                                                I_MBID    IN NUMBER, --模版ID
                                                I_PROD_ID IN NUMBER --产品ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-产品详细信息
  所属用户：PIF
  概要说明：查询产品概要信息，
  
            涉及后台管理-内部管理-全景模板定义、产品建模对象、产品集合
  
  语法信息：
       输入参数：
          I_USER_ID       用户ID
          I_MBID          模版ID
          I_PROD_ID       产品ID
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品详细信息.
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2021-12-6     1.0.1     GAOKUN             修改优化格式，注释
  *********************************************************************************************************************/
  V_SQL     VARCHAR2(32767);
  V_ERRMSG  VARCHAR2(300); --错误信息
  V_COUNT   NUMBER(12);
  V_TYPE    NUMBER(12);
  V_CPSX    VARCHAR2(241); --产品属性
  V_REFCODE VARCHAR2(2000); --关联对象名称/字典的FLDM
  --V_CXZD      VARCHAR2(5000); --查询字段
  V_TABLENAME VARCHAR2(2000);
  V_ZDSX      VARCHAR2(5000); --字段属性
  V_FZID      NUMBER(10); --分组ID
  V_FZMC      VARCHAR(200); --分组名称
  V_NBDXIDS   VARCHAR(1000); --内部对象IDS
  V_LENGTH    VARCHAR2(500); --长度
  V_CONTROL   NUMBER;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_MBID IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入必填参数【模版ID】';
    RETURN;
  END IF;
  IF I_PROD_ID IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入必填参数【产品ID】';
    RETURN;
  END IF;

  --验证是否存在通用模版
  SELECT COUNT(1)
    INTO V_COUNT
    FROM TPIF_CPQJMBDY MB --产品全景模板定义
   WHERE MB.ID = I_MBID
     AND MB.MBZT = 1; --启用状态

  IF V_COUNT = 0 THEN
    O_CODE := -2;
    O_NOTE := '错误：没有此全景模版！';
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA_BIG';

  --根据模版得到展示字段
  FOR V2 IN (SELECT T.ID,
                    T.FZ,
                    T.XSMC,
                    T.XSSX,
                    T.YWDX, --业务对象,=表名，内部对象，存的ID
                    T.CPSX, --产品属性
                    T.MS,
                    T.IDBZ,
                    T.SFDHXS
               FROM PIF.TPIF_QJFZXSZD T --全景分组显示字段
              WHERE T.QJMB = I_MBID
                AND T.ZT = 1
              ORDER BY XSSX ASC) LOOP
  
    --取字段
    SELECT T1.TYPE,
           T1.NAME,
           T1.REFCODE,
           T1.TABLENAME,
           T1.LENGTH,
           T1.CONTROL
      INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME, V_LENGTH, V_CONTROL
      FROM PIF.TPIF_FIELD T1 --PIF字段列表
     WHERE T1.TABLENAME = V2.YWDX --表名 ID
       AND T1.ID = V2.CPSX; --字段 ID
  
    --取分组
    SELECT T.ID, T.FZMC
      INTO V_FZID, V_FZMC
      FROM TPIF_QJYQXSFZ T --全景模板显示分组
     WHERE T.ID = V2.FZ;
  
    --时间类型，进行格式化
    BEGIN
      IF V_TYPE = 13 THEN
        --数值型日期
        V_SQL := 'SELECT TO_CHAR(TO_DATE(' || V2.CPSX ||
                 ',''YYYYMMDD''),''YYYY-MM-DD'') FROM ' || V_TABLENAME ||
                 ' WHERE CPID = ' || I_PROD_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSIF V_TYPE = 3 THEN
        --日期
        V_SQL := 'SELECT TO_CHAR(' || V2.CPSX || ',''YYYY-MM-DD'')  FROM ' ||
                 V_TABLENAME || ' WHERE CPID = ' || I_PROD_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSIF V_TYPE = 6 THEN
        --内部对象
        V_SQL := 'SELECT ' || V2.MS || ' FROM PIF.' || V_REFCODE ||
                 ' WHERE ' || V2.IDBZ || ' = (SELECT ' || V2.CPSX ||
                 ' FROM ' || V_TABLENAME || ' WHERE CPID = ' || I_PROD_ID || ')';
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSIF V_TYPE = 16 THEN
        --多指对象
        V_SQL := 'SELECT ' || V2.CPSX || ' FROM ' || V_TABLENAME ||
                 ' WHERE CPID = ' || I_PROD_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_NBDXIDS;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
        V_SQL := 'SELECT WM_CONCAT(' || V2.MS || ') FROM PIF.' ||
                 V_TABLENAME || '  WHERE INSTR('';''||' || V_NBDXIDS ||
                 '||'';'','';''||' || V2.IDBZ || '||'';'') >0';
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSIF V_TYPE = 7 THEN
        --字典型
        V_SQL := 'SELECT ' || V2.CPSX || ' FROM ' || V_TABLENAME ||
                 ' WHERE CPID = ' || I_PROD_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_NBDXIDS;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
        V_SQL := 'SELECT  T.NOTE  FROM LIVEBOS.TXTDM T WHERE T.FLDM = ''' ||
                 V_REFCODE || ''' AND T.IBM = ' || V_NBDXIDS;
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSIF V_TYPE = 15 THEN
        --多值选择项
        V_SQL := 'SELECT ' || V2.CPSX || ' FROM ' || V_TABLENAME ||
                 ' WHERE CPID = ' || I_PROD_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_NBDXIDS;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
        V_SQL := 'SELECT  WM_CONCAT(NOTE)  FROM LIVEBOS.TXTDM T WHERE T.FLDM = ''' ||
                 V_REFCODE || ''' AND INSTR('';''||' || V_NBDXIDS ||
                 '||'';'','';''||T.IBM||'';'') >0 ';
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
        --星级控件处理  
      ELSIF V_TYPE = 1 AND V_CONTROL = 31 THEN
      
        --V_CONTROL  
        V_SQL := 'SELECT  DECODE(' || V2.CPSX ||
                 ',1,''★☆☆☆☆'',2,''★★☆☆☆'',3,''★★★☆☆'',4,''★★★★☆'',5,''★★★★★'',''☆☆☆☆☆'')  FROM ' ||
                 V_TABLENAME || ' WHERE CPID = ' || I_PROD_ID;
      
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      ELSE
        IF INSTR(V_LENGTH, '.') > 0 THEN
          V_SQL := 'SELECT TO_CHAR(' || V2.CPSX ||
                   ',''FM999,999,999,999,990.009999'') FROM ' ||
                   V_TABLENAME || ' WHERE CPID = ' || I_PROD_ID;
        
        ELSE
          V_SQL := 'SELECT ' || V2.CPSX || ' FROM ' || V_TABLENAME ||
                   ' WHERE CPID = ' || I_PROD_ID;
        
        END IF;
        EXECUTE IMMEDIATE V_SQL
          INTO V_ZDSX;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
      
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        V_ZDSX := '';
    END;
  
    INSERT INTO TEMPDATA_BIG
      (N1, C1, C2, N2, C3, N3)
      SELECT V2.XSSX, V_ZDSX, V2.XSMC, V_FZID, V_FZMC, V2.SFDHXS FROM DUAL;
  END LOOP;

  --组装查询SQL
  V_SQL := 'SELECT N2 AS GROUP_ID,--分组ID
                   C3 AS GROUP_NAME,--分组名称
                   C2 AS DISPLAY_NAME,--显示名称
                   C1 AS DISPLAY_VALUE,--显示值
                   N3 AS IS_SINGLE_ROW--是否单列
              FROM TEMPDATA_BIG 
          ORDER BY N1';

  OPEN O_RESULT FOR V_SQL;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || V_ERRMSG FROM DUAL;
  
  
END PCX_PIF_CPQJ_CPQJMX;
/

