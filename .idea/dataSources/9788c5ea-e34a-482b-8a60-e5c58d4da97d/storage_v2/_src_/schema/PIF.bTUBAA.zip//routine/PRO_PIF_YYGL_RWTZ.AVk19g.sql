create PROCEDURE PRO_PIF_YYGL_RWTZ(O_CODE            OUT NUMBER,
                                              O_NOTE            OUT VARCHAR2,
                                              I_USERID          IN NUMBER, --登录人ID,
                                              I_IP              IN VARCHAR2, --登录IP,
                                              i_task_id         IN NUMBER, --调整任务ID
                                              i_task_content    IN VARCHAR2, --任务内容
                                              i_prod_event_type IN NUMBER, --产品事件类型
                                              i_important_level IN NUMBER, --重要程度
                                              i_task_exec       IN VARCHAR2, --执行人
                                              i_exec_begin_time IN VARCHAR2, --执行开始时间
                                              i_exec_end_time   IN VARCHAR2, --执行结束时间
                                              i_operate_desc    IN VARCHAR2 --操作说明
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：海通证券产品中心
  
         功能说明：任务调整
             参数说明：
                  入参：
                       I_USERID       IN  NUMBER,     --系统登录人ID
                       I_IP           IN  VARCHAR2，   --登录人IP
                       i_task_id         IN  NUMBER,     --调整任务ID
                       i_task_content         IN  VARCHAR2,   --任务内容
                       i_important_level         IN  NUMBER,     --重要程度
                       I_ZXR          IN  VARCHAR2,   --执行人
                       i_exec_begin_time     IN VARCHAR2,    --执行开始时间
                       I_YJZXJSSJ     IN VARCHAR2     --执行结束时间
  
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
  
  
        ----------------------------------------------------------
        操作人    版本号          时间                    操作
        刘浪浪    1.0.1      2014/11/17                  新增
        刘浪浪    1.0.2      2014/11/21                  增加产品事件类型入参
  
  -------------------------------------------------------------------------------------------------*/
  V_SJLX NUMBER;
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF i_task_id IS NULL THEN
    O_CODE := -1;
    O_NOTE := '运营任务ID不能为空!';
    RETURN;
  END IF;

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '系统登录人ID不能为空!';
    RETURN;
  END IF;

  IF I_IP IS NULL THEN
    O_CODE := -1;
    O_NOTE := '系统登录人IP不能为空!';
    RETURN;
  END IF;

  UPDATE TPIF_CPYYRW
     SET (RWNR, ZYCD, ZXRY, CPSJLX, YJZXKSSJ, YJZXWCSJ) =
         (SELECT i_task_content,
                 i_important_level,
                 i_task_exec,
                 i_prod_event_type,
                 TO_DATE(i_exec_begin_time, 'YYYY-MM-DD HH24:MI:SS'),
                 TO_DATE(i_exec_end_time, 'YYYY-MM-DD HH24:MI:SS')
            FROM DUAL)
   WHERE ID = i_task_id;

  SELECT CPSJLX INTO V_SJLX FROM TPIF_CPYYRW WHERE ID = i_task_id;
  /*IF V_SJLX = 10 THEN
  
    UPDATE TPIF_LSSJDJ
       SET (NR, ZYCD, ZXRY) =
           (SELECT i_task_content, i_important_level, i_task_exec FROM DUAL)
     WHERE ID = i_task_id;
  
  END IF;*/

  INSERT INTO TPIF_CPYYRWZXMX
    (ID, CPYYRW, ZXRY, CZLX, ZXSJ, ZXRWSM) --记录调整说明
    SELECT livebos.FUNC_NEXTID('TPIF_CPYYRWZXMX'),
           i_task_id,
           I_USERID,
           2,
           SYSDATE,
           i_operate_desc
      FROM DUAL;

  /* livebos.PRO_CZRZDJ(O_CODE, --登记操作日志
  O_NOTE,
  I_USERID,
  'TPIF_CPYYRW',
  'UPDATE',
  i_task_id,
  '修改',
  I_IP,
  '28009',
  '');*/
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    ROLLBACK;
  
END PRO_PIF_YYGL_RWTZ;
/

