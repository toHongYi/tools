create PROCEDURE PRO_PIF_YXFALCDWJSC(O_CODE  OUT NUMBER, --返回值
                                                O_NOTE  OUT VARCHAR2, --返回消息
                                                I_RY    IN NUMBER, --操作人
                                                I_ID    IN NUMBER, --流程ID
                                                I_CPID  IN NUMBER, --产品ID
                                                I_FJSTR IN VARCHAR2, --附件json字符串
                                                I_WDLX  IN NUMBER --文档类型：1|普通营销方案；2|专项营销方案；3|其他
                                                ) IS

  /******************************************************************
        项目名称：产品中心
        所属用户：PIF
       功能说明：多文件上传到文档库
      语法信息：
           输入参数：I_RY   IN  NUMBER    --操作人
                             I_ID IN NUMBER       --所属机构服务ID
                             I_FJSTR IN VARCHAR2       --附件json字符串
          逻辑说明：切割得到item部分，循环遍历arr[i]
          修订记录：
        修订日期              版本号   修订人      修改内容简要说明
        2021-08-013     1.0.0         WWH       新增附件转移
        2021-08-03      1.0.1         LTX       新增评审流程多文档‘其他’    
  ***********************************************************************/

  V_SUBFJSTR    VARCHAR2(2000); --切割的items部分
  V_FJID        VARCHAR2(2000); --拿到数组中每一个FJID
  V_FJNAME1     VARCHAR2(2000); --切割拿到的部分附件名称
  V_FJNAME      VARCHAR2(2000); --完整的附件名称
  V_COUNT       NUMBER; --循环中的次数
  V_CHECK_FJSTR VARCHAR2(2000); --循环终止的条件
  V_FJSTR       VARCHAR2(2000); --拿到的表单中附件的json字符串
  V_CPID        NUMBER; --产品ID
  V_CPGLR       NUMBER; --产品管理人ID
  V_CPXL        NUMBER; --产品分类
  V_WDID        NUMBER; --文档ID
  V_WDFL        NUMBER; --文档分类
  V_CPMC        VARCHAR2(200); --产品

BEGIN
  --INIT
  O_CODE  := -1;
  O_NOTE  := '';
  V_COUNT := 0;
  V_FJSTR := I_FJSTR;
  V_CPID  := I_CPID;

  --第一次切割得到item部分，循环的终止条件
  SELECT SUBSTR(STR, INSTR(STR, '["', 1, 1))
    INTO V_CHECK_FJSTR
    FROM (SELECT SUBSTR(V_FJSTR, INSTR(V_FJSTR, '"items":[') + 9) AS STR
            FROM DUAL);

  --获取营销产品信息
  SELECT CPMC, CPGLRID, CPXL
    INTO V_CPMC, V_CPGLR, V_CPXL
    FROM PIF.TPIF_CPDM
   WHERE ID = I_CPID;

  --转换文档分类
  SELECT DECODE(I_WDLX, 1, 900013, 2, 900012, 3, 900014)
    INTO V_WDFL
    FROM DUAL;

  LOOP
    V_COUNT := V_COUNT + 1;
  
    SELECT SUBSTR(STR, INSTR(STR, '["', 1, V_COUNT))
      INTO V_SUBFJSTR
      FROM (SELECT SUBSTR(V_FJSTR, INSTR(V_FJSTR, '"items":[') + 9) AS STR
              FROM DUAL);
  
    IF V_SUBFJSTR = V_CHECK_FJSTR AND V_COUNT <> 1 THEN
      EXIT;
      --检测是否是空附件
    ELSIF V_SUBFJSTR = ']}' THEN
      EXIT;
    
    ELSE
      --拿到FJID
      SELECT SUBSTR(V_SUBFJSTR, 3, INSTR(V_SUBFJSTR, '"', 1, 2) - 3)
        INTO V_FJID
        FROM DUAL;
      --去除掉数组第一个数据的ID
      SELECT SUBSTR(V_SUBFJSTR, INSTR(V_SUBFJSTR, '","', 1, 1) + 3)
        INTO V_FJNAME1
        FROM DUAL;
      --拿到数组中第一个附件名称
      SELECT SUBSTR(V_FJNAME1, 1, INSTR(V_FJNAME1, '"]', 1, 1) - 1)
        INTO V_FJNAME
        FROM DUAL;
    
      --SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPWDK') INTO V_WDID FROM DUAL;
      V_WDID := LIVEBOS.FUNC_NEXTID('TPIF_CPWDK');
      INSERT INTO TPIF_CPWDK
        (ID,
         BM,
         GLLX,
         GLID,
         CPMC,
         CPXL,
         WDFL,
         WDMC,
         FJ,
         SFYX,
         SCRY,
         SCRQ,
         BBH,
         WDYSTJ,
         WDGS,
         XZWDSJ,
         GGRQ,
         GLRMC,
         BZ,
         GLLC,
         GLLCCPXX)
      VALUES
        (V_WDID,
         V_WDID,
         1,
         V_CPID,
         V_CPID,
         V_CPXL,
         V_WDFL,
         V_FJNAME,
         V_FJNAME,
         1,
         I_RY,
         TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')),
         V_CPMC || '_' || I_ID || '_V100.0_' ||
         TO_CHAR(SYSDATE, 'yyyymmdd'),
         1,
         FUNC_GETWDGS(V_FJNAME),
         SYSDATE,
         TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')),
         V_CPGLR,
         V_FJID,
         4,
         I_ID);
    END IF;
  
  END LOOP;
  --COMMIT;

  O_CODE := 1;
  O_NOTE := '成功';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    ROLLBACK;
END;
/

