create procedure pcx_pif_cpqj_jjhyfb_out(o_code    out number,
                                                o_note    out varchar2,
                                                o_result  out sys_refcursor,
                                                i_userid  in number,
                                                i_ip      in varchar2,
                                                i_prod_id in number --产品专区ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-查询基金行业分布
  所属用户：PIF
  概要说明：查询基金行业分布.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金行业分布.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/29     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql varchar2(32767);
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_prod_id is null then
    o_note := '产品ID不允许为空！';
    return;
  end if;
 if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;
  v_sql := ' select t.industry_code,
                    t.industry_name,
                   to_char(industry_mktvalue,''FM9999999990.00''）industry_mktvalue,
                   to_char(occupy_nav_ratio,''FM9990.0000''）occupy_nav_ratio
             from pif.tfund_industry_invest t
             where t.prod_id = ' || i_prod_id || '
             order by occupy_nav_ratio desc ';

  open o_result for v_sql;

  o_code := 0;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end pcx_pif_cpqj_jjhyfb_out;
/

