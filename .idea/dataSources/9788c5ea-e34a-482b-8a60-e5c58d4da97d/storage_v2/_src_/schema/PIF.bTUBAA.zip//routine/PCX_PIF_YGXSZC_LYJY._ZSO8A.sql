create procedure pcx_pif_ygxszc_lyjy(o_code            out number,
                                                o_note            out varchar2,
                                                o_result          out sys_refcursor,
                                                i_userid          in number, --用户ID
                                                i_id              in number --记录ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-员工销售支持-路演纪要
  所属用户：PIF
  概要说明：查询路演纪要信息

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金经理概况.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql        varchar2(32767);
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_id is null then
    o_note := '记录ID不允许为空！';
    return;
  end if;

  v_sql := ' select a.id as id,
                    a.fj as name,
                    a.fjmc as attachment,
                    a.zzr as uploadperson,
                    a.scsj as uploadtime
             from pif.TPIF_LYJY a
             where sjmc = ' || i_id || ' order by scsj desc';
  --dbms_output.put_line(v_sql);
  open o_result for v_sql;

  o_code := 1;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end ;
/

