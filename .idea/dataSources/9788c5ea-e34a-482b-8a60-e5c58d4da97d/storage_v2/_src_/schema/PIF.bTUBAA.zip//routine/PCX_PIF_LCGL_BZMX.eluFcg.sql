create PROCEDURE PCX_PIF_LCGL_BZMX(O_CODE      OUT NUMBER,
                                              O_NOTE      OUT VARCHAR2,
                                              O_RESULT    OUT SYS_REFCURSOR,
                                              I_USERID    IN NUMBER, --登陆用户ID
                                              I_PROD_TYPE IN VARCHAR2 -- 产品类型，多值选择项，分号“;“分隔
                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 流程管理-产品流程步骤查询
  
      语法信息：
           输入参数：   I_USERID          IN NUMBER,  --登陆用户ID
                       I_PROD_TYPE       IN VARCHAR2 -- 产品类型，多值选择项，分号“;“分隔
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_TYPE 不允许为空！';
    RETURN;
  END IF;

  /*  ID  流程ID
      PROCESS_NAME  流程名称
      PROCESS_LEVEL 流程级别
      IS_NECESSARY  是否必须
      ACCESS_RIGHTS 前置流程
      PRE_PROCESS 流程发起人
      PROCESS_START_URL 流程发起URL
      PROCESS_TRACKING_URL  流程跟踪URL
      DOC_DOWNLOAD_URL  文档下载URL
  */

  OPEN O_RESULT FOR
    SELECT B.ID       AS ID,
           A.XSMC     AS PROCESS_NAME,
           A.JB       AS PROCESS_LEVEL,
           A.SFBX     AS IS_NECESSARY,
           A.QZLC     AS ACCESS_RIGHTS,
           A.LCFQR    AS PRE_PROCESS,
           B.LCFQ_URL AS PROCESS_START_URL,
           B.LCGZ_URL AS PROCESS_TRACKING_URL,
           B.WDXZ_URL AS DOC_DOWNLOAD_URL
      FROM TPIF_CPLCPZ A, TPIF_LCDJ B
     WHERE A.LCID = B.ID
       AND INSTR(';' || A.CPXL || ';', ';' || I_PROD_TYPE || ';') > 0
     ORDER BY A.JB ASC;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

