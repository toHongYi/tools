create PROCEDURE PRO_SJQX_DZQY_PROJECT(O_CODE OUT NUMBER, --返回值
                                                  O_NOTE OUT VARCHAR2 --返回消息
                                                  ) IS

  /******************************************************************
      所属用户：PIF
      功能说明：电子签约项目表 PIF.DZQY_PROJECT 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5       1.0       HANQN              创建
  
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO DZQY_PROJECT_TEST T
  USING (SELECT FUND_CODE,
                FUND_NAME,
                PROD_CODE,
                TO_DATE(TO_CHAR(CONFIRM_DATE),'YYYYMMDD') AS CONFIRM_DATE,
                DECODE(PROJ_STATUS, 0, 1, 1, 2, 0) AS STATUS
           FROM SRC_PIF.PROD_PROJ_INFO) S
  ON (T.FUND_CODE = S.FUND_CODE)
  WHEN MATCHED THEN
    UPDATE
       SET T.FUND_NAME        = S.FUND_NAME,
           T.PROD_CODE    = S.PROD_CODE,
           T.CONFIRM_DATE = S.CONFIRM_DATE,
           T.STATUS       = S.STATUS
  WHEN NOT MATCHED THEN
    INSERT
      (T.ID,
       T.FUND_CODE,
       T.FUND_NAME,
       T.PROD_CODE,
       T.CONFIRM_DATE,
       T.STATUS,
       T.CREATE_DATE,
       T.LAST_MODIFIED_DATE,
       T.DELETED_FLAG)
    VALUES
      (LIVEBOS.FUNC_NEXTID('DZQY_PROJECT_TEST'),
       S.FUND_CODE,
       S.FUND_NAME,
       S.PROD_CODE,
       S.CONFIRM_DATE,
       S.STATUS,
       SYSDATE,
       SYSDATE,
       2);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'PIF.DZQY_PROJECT 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'PIF.DZQY_PROJECT  表清洗,未知错误'
                ELSE
                 'PIF.DZQY_PROJECT  ,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

