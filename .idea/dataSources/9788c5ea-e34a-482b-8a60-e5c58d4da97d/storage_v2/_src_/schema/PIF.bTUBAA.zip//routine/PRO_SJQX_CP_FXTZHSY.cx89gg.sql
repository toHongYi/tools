create PROCEDURE PRO_SJQX_CP_FXTZHSY( O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_RQ   IN NUMBER --统计日期
                                             ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：风险调整后收益-DSC_STAT.TPIF_STAT_CP_FXTZHSY数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-15     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
  V_RQ   NUMBER;
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --1. 先将当前表数据备份到HIS表中
  BEGIN
    SELECT MAX(RQ) INTO V_RQ FROM DSC_STAT.TPIF_STAT_CP_FXTZHSY;
  EXCEPTION
    WHEN OTHERS THEN
      V_RQ := NULL;
  END;

  IF V_RQ > 0 THEN

    PRO_SJQX_CP_FXTZHSY_HIS(V_CODE, V_NOTE, V_RQ);

    IF V_CODE = -1 THEN
      O_NOTE := V_NOTE;
      RETURN;
    END IF;

  END IF;

  --2. TPIF_STAT_CP_FXTZHSY表数据清洗开始
  IF I_RQ IS NULL THEN
    --计算上个交易日的
    SELECT MAX(JYR)
      INTO V_RQ
      FROM LIVEBOS.TXTJYR A
     WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
  ELSE
    V_RQ := I_RQ;
  END IF;

  --2.1 清空表数据
  DELETE FROM DSC_STAT.TPIF_STAT_CP_FXTZHSY WHERE 1 = 1;
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_STAT_CP_FXTZHSY';
  

  --2.2 夏普比率
  PRO_SJQX_CP_FXTZHSY_XPBL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.3 索提诺比率
  PRO_SJQX_CP_FXTZHSY_STNBL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.4 卡玛比率
  PRO_SJQX_CP_FXTZHSY_KMBL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;


  --3.TEMP_STAT_CP_SYTZ 表数据加载到 TPIF_STAT_CP_SYTZ表中
  INSERT INTO DSC_STAT.TPIF_STAT_CP_FXTZHSY
         (RQ, 
          CPID, 
          JZRQ, 
          JYRQ, 
          DWJZ, 
          XPBL_3Y, 
          XPBL_6Y, 
          XPBL_1N, 
          XPBL_3N, 
          XPBL_5N, 
          XPBL_CLYL, 
          XPBL_JNYL, 
          STNBL_3Y, 
          STNBL_6Y, 
          STNBL_1N, 
          STNBL_3N, 
          STNBL_5N, 
          STNBL_CLYL, 
          STNBL_JNYL, 
          KMBL_3Y, 
          KMBL_6Y, 
          KMBL_1N, 
          KMBL_3N, 
          KMBL_5N, 
          KMBL_CLYL, 
          KMBL_JNYL
          )
    SELECT RQ,
           CPID,
           JZRQ,
           JYRQ,
           DWJZ,
           SUM(NVL(XPBL_3Y, 0)),
           SUM(NVL(XPBL_6Y, 0)),
           SUM(NVL(XPBL_1N, 0)),
           SUM(NVL(XPBL_3N, 0)),
           SUM(NVL(XPBL_5N, 0)),
           SUM(NVL(XPBL_CLYL, 0)),
           SUM(NVL(XPBL_JNYL, 0)),
           SUM(NVL(STNBL_3Y, 0)),
           SUM(NVL(STNBL_6Y, 0)),
           SUM(NVL(STNBL_1N, 0)),
           SUM(NVL(STNBL_3N, 0)),
           SUM(NVL(STNBL_5N, 0)),
           SUM(NVL(STNBL_CLYL, 0)),
           SUM(NVL(STNBL_JNYL, 0)),
           SUM(NVL(KMBL_3Y, 0)),
           SUM(NVL(KMBL_6Y, 0)),
           SUM(NVL(KMBL_1N, 0)),
           SUM(NVL(KMBL_3N, 0)),
           SUM(NVL(KMBL_5N, 0)),
           SUM(NVL(KMBL_CLYL, 0)),
           SUM(NVL(KMBL_JNYL, 0))

      FROM TEMP_STAT_CP_FXTZHSY
     WHERE RQ = V_RQ
     GROUP BY RQ, CPID, JZRQ, JYRQ, DWJZ;

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'DSC_STAT.TPIF_STAT_CP_FXTZHSY 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := V_NOTE;
END;
/

