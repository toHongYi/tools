create PROCEDURE "PCX_TYCX_OUT" (O_CODE         OUT NUMBER,
                                     O_NOTE         OUT VARCHAR2,
                                     O_HASRECORDSET IN OUT NUMBER,
                                     O_RESULT       OUT SYS_REFCURSOR,
                                     I_PAGING       IN NUMBER,
                                     I_PAGENO       IN NUMBER,
                                     I_PAGELENGTH   IN NUMBER,
                                     I_TOTALROWS    IN OUT NUMBER,
                                     SQLS           IN VARCHAR2,
                                     COLLIST        IN VARCHAR2,
                                     HASWHERE       IN BOOLEAN := TRUE,
                                     GROUPISLAST    IN BOOLEAN := FALSE,
                                     I_SORT         IN VARCHAR2 := '',
                                     I_HASWITH      IN BOOLEAN := FALSE) IS
    /******************************************************************************
    文件名称：PCX_TYCX
    项目名称：机构CRM
    功能说明：通用查询

    参数：
               英文名称            中文名称                可能取值
               O_CODE              返回值
               O_NOTE              返回信息
               O_HASRECORDSET      0/1                     整型，返回1，表示有返回O_RESULT,否俄没有O_RESULT(为空值)
               O_RESULT            返回的数据集合          不一定会有，但通常用于返回结果集合。
               I_PAGING            是否分页                1表示分页，0表示不分页。但即使不分页的情况下，也会计算I_TOTALROWS.
                                                           并不是什么是否都需要分页，看情形而言。
               I_PAGENO            页码
               I_PAGELENGTH        页长
               I_TOTALROWS         总行数                  -1，未知，表示需要计算总长。是IN，OUT参数.如果I_TOTALROWS>=0,则不再计算这个指，
                                                           在很翻页的时候，可以提高效率。
               SQLS                SQLS语句                请务必包含特定格式。
               HASWHERE            是否有WHERE字句         默认是有.
               GROUPISLAST         类似GROUP条件是
                                   最后一个部分            默认FALSE;
               I_SORT              排序字句                通常有.

        返回：

        算法：

        注意事项：

        数据源：

        修改记录;
        ------------------------------------------------------------------------
        操作人  版本号     操作时间                   操作
        孙琦    1.0.2      20181219                  begin之后添加  DBMS_OUTPUT.ENABLE (buffer_size=>null) ;
    ******************************************************************************/

    VSQLS         VARCHAR2(32767);
    VSTARTROW     NUMBER;
    VENDROW       NUMBER;
    --VPAGESQLWHERE VARCHAR2(32767);
    V_SORTSQL     VARCHAR2(1000);
    V_COMPLEX     BOOLEAN;

    B_HASWITH BOOLEAN := I_HASWITH;
    V_WITHSQL VARCHAR2(32767);
    V_WITHPOS NUMBER;

BEGIN
     DBMS_OUTPUT.ENABLE (buffer_size=>null) ;
    V_COMPLEX := GROUPISLAST;

    IF I_TOTALROWS = -1 THEN
        --计算总的行数
        PRO_TJHS(I_TOTALROWS, O_NOTE, SQLS, GROUPISLAST);
        IF I_TOTALROWS = 0 THEN
            --没有数据，则返回一个空壳
            O_CODE := 1;
            O_NOTE := '成功';
            IF O_HASRECORDSET = 1 THEN
                --如果需要返回数据，则直接数据.
                IF COLLIST IS NOT NULL THEN
                    VSQLS := 'SELECT ' || COLLIST || ' FROM
                    (' || SQLS || ')';
                ELSE
                    VSQLS := SQLS;
                END IF;

                OPEN O_RESULT FOR VSQLS;
            END IF;
            RETURN;
        ELSIF I_TOTALROWS = -1 THEN
            --只要异常，就不返回数据集合。
            O_CODE         := -1;
            O_NOTE         := '计算总行数出现异常:' || O_NOTE;
            O_HASRECORDSET := 0;
            RETURN;
        END IF;

    END IF;

    IF O_HASRECORDSET = 1 THEN
        --如果需要返回数据.
        V_SORTSQL := CASE
                         WHEN I_SORT IS NOT NULL THEN
                          ' ORDER BY ' || I_SORT
                         ELSE
                          NULL
                     END;
        IF I_PAGING = 1 THEN
            --如果分页
            --分页请处理有关
            VSTARTROW := (I_PAGENO - 1) * I_PAGELENGTH + 1;

            IF I_TOTALROWS <= I_PAGELENGTH THEN
                VENDROW := I_TOTALROWS;
            ELSE
                VENDROW := I_PAGENO * I_PAGELENGTH;
            END IF;

            IF I_SORT IS NOT NULL THEN
                V_COMPLEX := TRUE;
            END IF;

            ---处理 ROWNUM R部分----------------------------------------------------------------------
            VSQLS := SQLS;
            IF B_HASWITH THEN
                V_WITHPOS := INSTR(VSQLS, '/**WITH**/');
                V_WITHSQL := SUBSTR(VSQLS, 1, V_WITHPOS - 1);
                VSQLS     := SUBSTR(VSQLS, V_WITHPOS + 10);
            END IF;

            /* IF V_COMPLEX = FALSE THEN
                --如果是最简单的（无排序，分组，等等的）
                VSQLS         := REPLACE(VSQLS, '\* ROWNUM R,*\', ' ROWNUM R,');
                VPAGESQLWHERE := CASE WHEN HASWHERE THEN ' AND ROWNUM<=' || VENDROW ELSE ' WHERE ROWNUM<=' || VENDROW END;
                VSQLS         := 'SELECT ' || COLLIST || ' FROM
                (' || VSQLS || VPAGESQLWHERE ||
                                 ') WHERE R>=' || VSTARTROW;

            ELSE
                --如果是复杂的
                 VSQLS := ' SELECT ' || COLLIST || ' FROM
                (
                   SELECT ROWNUM R,A.*
                     FROM
                     (' || VSQLS || V_SORTSQL || '
                     ) A
                     WHERE ROWNUM<=' || VENDROW || '
                 )
                 WHERE R>=' || VSTARTROW;


            END IF;*/

            VSQLS := 'SELECT ' || COLLIST || ' FROM (
                               SELECT ' || COLLIST ||
                     ' ,ROWNUM R FROM (
                                  SELECT ' || COLLIST || ' FROM (' ||
                     VSQLS || ') ' || V_SORTSQL || ')
                                       )
                     WHERE R BETWEEN ' || VSTARTROW || ' AND ' ||
                     VENDROW;

            ---处理WITH语句
            IF B_HASWITH THEN
                VSQLS := V_WITHSQL || '
                ' || VSQLS;
            END IF;

        ELSE
            --不分页
            IF COLLIST IS NOT NULL THEN
                VSQLS := 'SELECT ' || COLLIST || ' FROM
                  (' || SQLS || ')' || V_SORTSQL;
            ELSE
                VSQLS := SQLS || V_SORTSQL;
            END IF;
        END IF;
    END IF;

    O_CODE := 0;
    O_NOTE := '成功';
    DBMS_OUTPUT.PUT_LINE(VSQLS);

    IF O_HASRECORDSET = 1 THEN
        OPEN O_RESULT FOR VSQLS;

    END IF;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE         := -1;
        O_NOTE         := SQLERRM;
        O_HASRECORDSET := -1;
        OPEN O_RESULT FOR
            SELECT '查询出错 ! 错误:' || O_NOTE FROM DUAL;
END PCX_TYCX_OUT;
/

