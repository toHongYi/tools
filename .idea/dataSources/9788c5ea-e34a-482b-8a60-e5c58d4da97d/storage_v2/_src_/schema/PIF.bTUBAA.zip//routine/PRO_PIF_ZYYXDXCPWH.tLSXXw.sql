create PROCEDURE PRO_PIF_ZYYXDXCPWH(O_CODE  OUT NUMBER, --返回值
                                               O_NOTE  OUT VARCHAR2, --返回消息
                                               I_USER  IN INTEGER, --操作人
                                               I_IP    IN VARCHAR2, --操作IP
                                               I_OPER  IN INTEGER, --操作类型 0|设置映射信息;
                                               I_ID    IN INTEGER, --要修改的私募代销维护表记录ID
                                               I_YCPID IN INTEGER --要修改的私募代销维护表记录中的原对应朝阳永续ID
                                               ) IS
  /*
  **功能说明： 朝阳永续代销产品维护
  **创建人：陈勇军
  **创建日期：2017-06-22
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **陈勇军              2017-06-22    创建
  **孙远何    V1.0.2    2018-08-14    增加处理CPDM_WD到产品代码表
  **gaokun    V1.0.3    2021-11-9     大修改
  */
  V_COUNT INTEGER; --计数变量
  V_OBJ   TPIF_SMDXCPWH%ROWTYPE; --表单记录

  V_CZBM VARCHAR2(200); --操作编码
  V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  SELECT * INTO V_OBJ FROM TPIF_SMDXCPWH WHERE ID = I_ID;
  SELECT DECODE(I_OPER, 0, '900803', '') INTO V_CZBM FROM DUAL;
  SELECT '[' || DECODE(I_OPER, 0, '设置映射信息', '') || ']_' || V_OBJ.ZYYXCPMC
    INTO V_CZSM
    FROM DUAL;
  --CHECK
  /*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
  IF V_QXBZ = 0 THEN
      O_NOTE := '系统禁止管理员操作!';
      RETURN;
  END IF;*/
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --设置映射
  
    IF I_YCPID IS NOT NULL THEN
      --原朝阳永续ID不为空，即该记录已经匹配过
    
      IF (I_YCPID != V_OBJ.ZYYXCP) THEN
        --判断 朝阳永续产品ID 是否改变
        --如果改变需要特殊处理
      
        --判断私募内部表里是否存在对应原来的朝阳永续产品记录
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPDM_SMYY
         WHERE ZYNM = I_YCPID;
      
        IF V_COUNT > 0 THEN
          --有，则需要将类型改为经纪户，去掉相关信息
          UPDATE TPIF_CPDM_SMYY M --置空
             SET M.CPYWLX = 2,
                 M.CPTA   = NULL,
                 M.CPTAMC = NULL,
                 M.DXCPDM = NULL,
                 M.CPJYZT = NULL,
                 M.MJKSRQ = NULL,
                 M.MJJSRQ = NULL,
                 M.TZGW   = NULL,
                 M.ZHXGSJ = SYSDATE,
                 M.ZHXGR  = 0
           WHERE M.ZYNM = I_YCPID;
        
          --用经纪户表的数据
          UPDATE TPIF_CPDM_SMYY M
             SET (M.CPMC, M.CLRQ, M.CPXL, M.JRCPFL) =
                 (SELECT CPMC, CLRQ, CPXL, JRCPFL
                    FROM TPIF_SMJJHWH
                   WHERE DYCPID = I_YCPID
                     AND ROWNUM = 1)
           WHERE M.ZYNM = I_YCPID;
        ELSE
          NULL; --私募内部表没有，则什么也不用做  
        END IF;
      
      ELSE
        NULL; --朝阳永续产品ID ，没有改变，则不用这些操作
      END IF;
    
    ELSE
      NULL; --原朝阳永续ID为空，即还没有匹配，则不用这些操作
    END IF;
  
    --更新 私募内部表对应该朝阳永续产品的记录
    MERGE INTO PIF.TPIF_CPDM_SMYY M
    USING (SELECT B.ZYYXCP,
                  A.CPTA, --  TA代码
                  A.CPTAMC, --TA名称
                  A.CPDM, --  产品代码
                  A.CPMC, --  产品名称
                  A.CPJYZT, --产品交易状态 
                  A.MJKSRQ, --  募集开始日期
                  A.MJJSRQ, --  募集结束日期
                  A.CPXL, --产品类型 
                  A.JRCPFL, --一级分类 
                  B.CLRQ,
                  A.TZGW --基金经理 
             FROM PIF.TPIF_CPDM A
            INNER JOIN PIF.TPIF_SMDXCPWH B
               ON A.CPID = B.CPID
            WHERE A.CPID = V_OBJ.CPID) N
    ON (M.ZYNM = N.ZYYXCP)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPYWLX = 3,
             M.CPTA   = N.CPTA,
             M.CPTAMC = N.CPTAMC,
             M.CPMC   = N.CPMC,
             M.DXCPDM = N.CPDM,
             M.CPJYZT = N.CPJYZT,
             M.MJKSRQ = N.MJKSRQ,
             M.MJJSRQ = N.MJJSRQ,
             M.CLRQ   = N.CLRQ,
             M.CPXL   = N.CPXL,
             M.JRCPFL = N.JRCPFL,
             M.TZGW   = N.TZGW,
             M.ZHXGSJ = SYSDATE,
             M.ZHXGR  = 0;
  
  END IF;

  --RECORD
  O_NOTE := '记录日志';
  PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, 1, V_CZSM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;

  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER, 0, '设置映射信息', '') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_ZYYXDXCPWH;
/

