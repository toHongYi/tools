create PROCEDURE PRO_SJQX_CP_FXTZHSY_HIS(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    I_RQ   IN NUMBER --统计日期
                                                    ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险特征-DSC_STAT.TPIF_STAT_CP_FXTZHSY_HIS数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-13     1.0       吴金锋              创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_RQ    NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_RQ   := I_RQ;
  SELECT COUNT(1)
    INTO V_COUNT
    FROM DSC_STAT.TPIF_STAT_CP_FXTZHSY_HIS
   WHERE RQ = V_RQ;
   
  IF V_COUNT > 0 THEN
    
    DELETE FROM DSC_STAT.TPIF_STAT_CP_FXTZHSY_HIS WHERE RQ = V_RQ ;
    
  END IF ; 
  
    INSERT INTO DSC_STAT.TPIF_STAT_CP_FXTZHSY_HIS
      (RQ,
       CPID,
       JZRQ,
       JYRQ,
       DWJZ,
       XPBL_3Y,
       XPBL_6Y,
       XPBL_1N,
       XPBL_3N,
       XPBL_5N,
       XPBL_CLYL,
       XPBL_JNYL,
       STNBL_3Y,
       STNBL_6Y,
       STNBL_1N,
       STNBL_3N,
       STNBL_5N,
       STNBL_CLYL,
       STNBL_JNYL,
       KMBL_3Y,
       KMBL_6Y,
       KMBL_1N,
       KMBL_3N,
       KMBL_5N,
       KMBL_CLYL,
       KMBL_JNYL)
      SELECT RQ,
             CPID,
             JZRQ,
             JYRQ,
             DWJZ,
             XPBL_3Y,
             XPBL_6Y,
             XPBL_1N,
             XPBL_3N,
             XPBL_5N,
             XPBL_CLYL,
             XPBL_JNYL,
             STNBL_3Y,
             STNBL_6Y,
             STNBL_1N,
             STNBL_3N,
             STNBL_5N,
             STNBL_CLYL,
             STNBL_JNYL,
             KMBL_3Y,
             KMBL_6Y,
             KMBL_1N,
             KMBL_3N,
             KMBL_5N,
             KMBL_CLYL,
             KMBL_JNYL
        FROM DSC_STAT.TPIF_STAT_CP_FXTZHSY
       WHERE RQ = V_RQ;
       
  O_CODE := 1;
  O_NOTE := '备份TPIF_STAT_CP_FXTZHSY表数据到TPIF_STAT_CP_FXTZHSY_HIS表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '备份TPIF_STAT_CP_FXTZHSY表数据到TPIF_STAT_CP_FXTZHSY_HIS表清洗失败';

END;
/

