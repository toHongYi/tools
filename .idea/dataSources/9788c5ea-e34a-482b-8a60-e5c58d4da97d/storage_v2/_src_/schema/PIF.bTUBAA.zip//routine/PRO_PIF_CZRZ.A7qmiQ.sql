create PROCEDURE PRO_PIF_CZRZ(O_CODE OUT INTEGER, --返回值
                                         O_NOTE OUT VARCHAR2, --返回信息
                                         I_USER IN INTEGER, --操作人
                                         I_IP   IN VARCHAR2, --操作人IP
                                         I_CZBM IN VARCHAR2, --操作码
                                         I_CZID IN VARCHAR2, --操作标识
                                         I_CZSM IN VARCHAR2, --操作说明
                                         I_KZBZ IN INTEGER := 0 --快照标识 1|校验快照;0|否;
                                         ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：记录操作日志
        语法信息：
             输入参数：   I_USER IN INTEGER, --操作人
                          I_IP   IN VARCHAR2, --操作人IP
                          I_CZBM IN VARCHAR2, --操作码
                          I_CZID IN VARCHAR2, --操作标识
                          I_CZSM IN VARCHAR2, --操作说明
                          I_KZBZ IN INTEGER := 0 --快照标识 1|校验快照;0|否;
             输出参数：   O_CODE OUT INTEGER, --返回值
                          O_NOTE OUT VARCHAR2, --返回信息
        逻辑说明：
             1、首先记录日志流水；
             2、再根据快照标识进行快照处理(预留)
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1    戴文生              新增
    ***********************************************************************/
    V_COUNT   INTEGER; --计数变量
    V_KZBZ    INTEGER; --快照标识
    V_KZ      INTEGER; --快照
    V_MC      VARCHAR2(200);
    V_JYBZ    INTEGER;
    V_LSDM    VARCHAR2(100);
    V_SCBZ    INTEGER;
    V_SERNUM  INTEGER;
    V_LSH     VARCHAR2(100);
    V_SYSDATE INTEGER;
    V_RZID    INTEGER;
    V_ID      INTEGER; --原快照表ID
    V_PID1    INTEGER; --临时ID1
    V_PID2    INTEGER; --临时ID2
    V_PID3    INTEGER; --临时ID3
    V_TABLE   VARCHAR2(200); --关联表
    V_KZLS    INTEGER; --快照ID
    V_SQL     VARCHAR2(2000); --SQL串
    V_SQL_X   VARCHAR2(2000); --SQL串获取其他
    V_IDBZ VARCHAR2(200);
    V_CZID VARCHAR2(200);
BEGIN
    --INIT 初始化赋值
    O_CODE := -1;
    O_NOTE := '';
    SELECT TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) INTO V_SYSDATE FROM DUAL;
    --CHECK 参数校验
    O_NOTE := '参数校验';
    IF I_CZBM IS NULL THEN
        O_NOTE := '记录日志异常:[操作码]为空!';
        RETURN;
    END IF;
    BEGIN
        SELECT MC,NVL(KZBZ,0),NVL(JYBZ,0),LSDM INTO V_MC,V_KZBZ,V_JYBZ,V_LSDM FROM TPIF_YWCZ WHERE BM = I_CZBM;
        EXCEPTION
            WHEN OTHERS THEN
                O_NOTE := '记录日志异常:[操作码]不存在!';
                RETURN;
    END;
    --START
    O_NOTE := '记录日志';
    --明确快照标识
    IF NVL(I_KZBZ, 1) = 0 THEN V_KZ := 0; END IF;
    IF NVL(I_KZBZ, 1) = 1 THEN V_KZ := V_KZBZ; END IF;
    --获取日志流水号 根据'CZRZ'||V_SYSDATE获取序列号，再用操作码+年月日+6位序号形成流水号
    livebos.ABS_NEXTSERIALNO('CZRZ'||V_SYSDATE, 1, 1, V_SERNUM);
    SELECT V_LSDM|| V_SYSDATE || LPAD(V_SERNUM, 6, '0') INTO V_LSH FROM DUAL;
    --记录操作日志
    O_NOTE := '写入日志表';
    livebos.PNEXTID('TPIF_CZRZ', V_RZID);
    INSERT INTO TPIF_CZRZ (ID,LSH,CZLX,CZSM,KZBZ,CZRMC,CZRGH,CZBMMC,CZBMBM,CZIP,CZSJ,CZLXBZ,CZID,CZR,CZBM,CZRQ)
    SELECT V_RZID, V_LSH, V_MC, I_CZSM, V_KZBZ, NAME, USERID,
           (SELECT NAME FROM livebos.LBORGANIZATION WHERE ID = ORGID),
           (SELECT ORGCODE FROM livebos.LBORGANIZATION WHERE ID = ORGID),
           I_IP, SYSDATE, I_CZBM, V_CZID, ID, ORGID, V_SYSDATE
      FROM livebos.TUSER
     WHERE ID = I_USER;
    UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID),0) FROM TPIF_CZRZ) WHERE NAME = 'TPIF_CZRZ';
    --快照处理
    IF V_KZ = 1 THEN
        --记录快照流水
        livebos.PNEXTID('TPIF_KZLS', V_KZLS);
        INSERT INTO TPIF_KZLS (ID,LSH,KZMC,KZSM,KZRMC,KZRGH,KZBMMC,KZBMBM,KZIP,KZSJ,KZR,KZBM,KZRQ)
            SELECT V_KZLS,V_LSH,V_MC,I_CZSM,NAME,USERID,
                   (SELECT NAME FROM livebos.LBORGANIZATION WHERE ID = ORGID),
                   (SELECT ORGCODE FROM livebos.LBORGANIZATION WHERE ID = ORGID),
                   I_IP, SYSDATE, ID, ORGID, V_SYSDATE
              FROM livebos.TUSER
             WHERE ID = I_USER;
        UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID),0) FROM TPIF_KZLS) WHERE NAME = 'TPIF_KZLS';
        --读取配置表，进行操作前数据快照
        FOR CUR IN (SELECT * FROM TPIF_YWKZ WHERE YWCZ = I_CZBM) LOOP
            BEGIN --获取ID标识字段
                V_SQL_X := 'SELECT NAME FROM livebos.TTABLEOBJ WHERE TABLENAME = '''||CUR.JCB||''' AND PRIMARYKEY=2';
                EXECUTE IMMEDIATE V_SQL_X INTO V_IDBZ;
                EXCEPTION WHEN OTHERS THEN
                    V_IDBZ := 'ID';
            END;
            IF CUR.DWLX IN (0,1) THEN
                IF CUR.DWLX = 0 THEN V_CZID := I_CZID; END IF;
                IF V_CZID IS NOT NULL THEN
                    --//:快照主表
                    O_NOTE := '快照主表';
                    SELECT WM_CONCAT(NAME) INTO V_SQL
                      FROM (SELECT NAME
                              FROM livebos.TTABLEOBJ
                             WHERE TYPE NOT IN (8, 9, 10, 19) AND NAME NOT IN ('ID', 'KZLS', 'YID')
                               AND PRIMARYKEY <> 8 AND TABLENAME = CUR.KZB
                             ORDER BY NO);
                    livebos.PNEXTID(CUR.KZB, V_PID1);
                    V_SQL := 'INSERT INTO ' || CUR.KZB || '(ID,KZLS,YID,' || V_SQL || ') ' ||
                             'SELECT ' || V_PID1 || '+ROWNUM-1,' || V_KZLS || ','||V_IDBZ||',' || V_SQL;
                    --获取删除标识（删除取上一条数据）
                    BEGIN
                        V_SQL_X := 'SELECT COUNT(1) FROM '|| CUR.JCB || ' WHERE '||V_IDBZ||' = ' || V_CZID;
                        EXECUTE IMMEDIATE V_SQL_X INTO V_COUNT;
                        EXCEPTION WHEN OTHERS THEN
                            V_COUNT := 0;
                    END;
                    IF (V_COUNT = 0 OR V_SCBZ = 1) THEN V_SCBZ := 1;ELSE V_SCBZ := 0; END IF;
                    --获取快照处理
                    IF V_SCBZ = 1 THEN
                        BEGIN
                            V_SQL_X := 'SELECT MAX(ID) FROM ' || CUR.KZB || ' WHERE YID = ' || V_CZID;
                            EXECUTE IMMEDIATE V_SQL_X INTO V_ID;
                            EXCEPTION WHEN OTHERS THEN
                                V_ID := NULL;
                        END;
                        V_SQL := V_SQL || ' FROM ' || CUR.KZB || ' WHERE ID =' || V_ID;
                    ELSE
                        V_SQL := V_SQL || ' FROM ' || CUR.JCB || ' WHERE '||V_IDBZ||' = ' || V_CZID;
                    END IF;
                    BEGIN --正常情况下不需要屏蔽异常,初始化的数据需先禁用故也不需要,为避免异常操作仍增加此屏蔽
                        EXECUTE IMMEDIATE V_SQL;
                        EXCEPTION WHEN OTHERS THEN
                            NULL;
                    END;
                    BEGIN
                        V_SQL := 'UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID),0) FROM '
                                 || CUR.KZB || ') WHERE NAME=''' || CUR.KZB || '''';
                        EXECUTE IMMEDIATE V_SQL;
                        EXCEPTION WHEN OTHERS THEN
                            NULL;
                    END;
                    --//:快照从表
                    O_NOTE := '快照从表';
                    FOR CURSUB IN (SELECT * FROM livebos.TTABLEOBJ WHERE TABLENAME = CUR.JCB AND TYPE = 10) LOOP
                        --获取快照表从表
                        SELECT REFTABLE INTO V_TABLE FROM livebos.TTABLEOBJ WHERE TABLENAME = CUR.KZB AND NAME = CURSUB.NAME;
                        SELECT WM_CONCAT(NAME) INTO V_SQL
                          FROM (SELECT NAME
                                  FROM livebos.TTABLEOBJ
                                 WHERE TYPE NOT IN (8, 9, 10, 19) AND NAME <> 'ID' AND PRIMARYKEY <> 8 AND TABLENAME = V_TABLE
                                 ORDER BY NO);
                        livebos.PNEXTID(V_TABLE, V_PID2);
                        V_SQL := 'INSERT INTO ' || V_TABLE || '(ID,' || CUR.KZB || '_ID,' ||
                                 V_SQL || ') ' || 'SELECT ' || V_PID2 || '+ROWNUM-1,' || V_PID1 || ',' ||
                                 V_SQL;
                        IF V_SCBZ = 1 THEN
                            V_SQL := V_SQL || ' FROM ' || V_TABLE || ' a ' ||
                                     'WHERE EXISTS(SELECT 1 FROM ' || CUR.KZB || ' WHERE ID = a.' ||
                                     CUR.KZB || '_ID AND YID=' || V_ID || ')';
                        ELSE
                            V_SQL := V_SQL || ' FROM ' || CURSUB.REFTABLE || ' a ' ||
                                     'WHERE EXISTS(SELECT 1 FROM ' || CUR.JCB || ' WHERE ID = a.' ||
                                     CUR.JCB || '_ID AND '||V_IDBZ||'=' || V_CZID || ')';
                        END IF;
                        BEGIN
                            EXECUTE IMMEDIATE V_SQL;
                            EXCEPTION WHEN OTHERS THEN
                                NULL;
                        END;
                        V_SQL := 'UPDATE livebos.TSEQUENCE SET ID=(SELECT NVL(MAX(ID),0) FROM '
                                 || V_TABLE || ') WHERE NAME=''' || V_TABLE || '''';
                        BEGIN
                            EXECUTE IMMEDIATE V_SQL;
                            EXCEPTION WHEN OTHERS THEN
                                NULL;
                        END;
                    END LOOP;
                    livebos.PNEXTID('TPIF_CZRZ_KZMX', V_PID3);
                    INSERT INTO TPIF_CZRZ_KZMX(ID,TPIF_CZRZ_ID,JCB,KZB,KZID)
                    SELECT V_PID3,V_RZID,CUR.JCB,CUR.KZB,V_PID1 FROM DUAL;
                    UPDATE livebos.TSEQUENCE SET ID = (SELECT NVL(MAX(ID),0) FROM TPIF_CZRZ_KZMX) WHERE NAME = 'TPIF_CZRZ_KZMX';
                END IF;
            END IF;
        END LOOP;
    END IF;
    --return
    O_CODE := 100;
    O_NOTE := '';
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE WHEN O_NOTE IS NULL THEN '未知错误' ELSE '在 ' || O_NOTE || ' 时出现异常' END) || ':' || SQLERRM;
END PRO_PIF_CZRZ;
/

