create PROCEDURE PRO_PIF_YYCPZTGX(O_CODE OUT NUMBER,
                                             O_NOTE OUT VARCHAR2) AS
  /******************************************************************
  项目名称：PIF  产品中心-预约产品状态更新
  所属用户：PIF
  概要说明：预约产品状态更新
          I_RQ    --日期
  语法信息：
       输出参数：
          O_CODE  成功返回 成功，失败返回-1
          O_NOTE     成功返回操作成功，失败返回错误信息

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2019-05-23     1.0.1     涂 孟              创建
  *********************************************************************************************************************/
  V_RQ  NUMBER(8) := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
  V_RQ2 NUMBER(8);
BEGIN

  O_CODE := 1;
  O_NOTE := '成功';
  --交易日才会进行更新
  SELECT A.JYR INTO V_RQ2 FROM livebos.TXTJYR A WHERE A.ZRR = V_RQ;
  IF V_RQ = V_RQ2 THEN
    --更新预约产品的状态
    --在区间之内的更新为已开始(可预约)
    UPDATE TPIF_YYCPGL A
       SET ZT = 2
     WHERE A.KSSJ <= SYSDATE
       AND A.JSSJ >= SYSDATE;
    --区间之外更新为未开始（不可预约）
    UPDATE TPIF_YYCPGL A
       SET ZT = 1
     WHERE A.KSSJ > SYSDATE
        OR A.JSSJ < SYSDATE;
    COMMIT;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
      RETURN;
    END;
END PRO_PIF_YYCPZTGX;
/

