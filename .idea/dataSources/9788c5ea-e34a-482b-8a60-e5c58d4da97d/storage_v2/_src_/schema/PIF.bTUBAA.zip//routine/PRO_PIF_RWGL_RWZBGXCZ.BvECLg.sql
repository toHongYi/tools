create PROCEDURE pro_pif_rwgl_rwzbgxcz(O_CODE   OUT NUMBER, --返回值
                                                  O_NOTE   OUT VARCHAR2, --返回消息
                                                  I_USERid IN INTEGER, --操作人
                                                  I_IP     IN VARCHAR2, --操作IP
                                                  I_OPER   IN INTEGER, --操作类型 0|新增；1|修改（总任务调整）；2|任务落实
                                                  I_ID     in integer, --操作ID 新增时可为空
                                                  I_RWID   in number, --任务ID
                                                  I_CZC    in varchar2 --操作串
                                                  ) IS
  /*
  **功能说明：任务指标关系管理
  **创建人：涂孟
  **创建日期：2020-07-20
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **涂孟                 2020-07-20   创建
  */
  V_COUNT  INTEGER; --计数变量
  V_ID     INTEGER;
  V_NOTE   VARCHAR2(2000); --描述信息
  V_RWZTMS varchar2(50); --任务状态描述
  V_CZC    varchar2(1000) := I_CZC; --操作串
  V_ZBID   varchar2(100);
  V_MBL    varchar2(100);
  V_CZC_S  varchar2(1000); --操作子串
  v_frwid integer; --父任务id
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  /*  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_RWFPXX WHERE ID = I_ID;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;*/
  --check
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --//:新增-----------------------------------------------------------------------
    IF I_CZC IS NULL THEN
      O_NOTE := '[操作串]不允许为空!';
      RETURN;
    END IF;
    IF I_RWID IS NULL THEN
      O_NOTE := '[任务ID]不允许为空!';
      RETURN;
    END IF;
    --先删后增
     delete from tpif_rwzbgx where rwxx = i_rwid;
    --分解操作串
    while V_CZC is not null loop
      V_CZC_S := substr(V_CZC, 1, instr(V_CZC, ',', 1, 1) - 1);
      if V_CZC_S is null then
        V_ZBID := substr(V_CZC, 1, instr(V_CZC, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC, instr(V_CZC, '=', 1, 1) + 1);
        V_CZC  := '';
        insert into TPIF_RWZBGX a
          (id, rwxx, zbxx, mbl)
        values
          (livebos.func_nextid('TPIF_RWZBGX'), i_rwid, v_zbid, v_mbl);
      else
        V_ZBID := substr(V_CZC_S, 1, instr(V_CZC_S, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC_S, instr(V_CZC_S, '=', 1, 1) + 1);
        V_CZC  := substr(V_CZC, instr(V_CZC, ',', 1, 1) + 1);
        insert into TPIF_RWZBGX a
          (id, rwxx, zbxx, mbl)
        values
          (livebos.func_nextid('TPIF_RWZBGX'), i_rwid, v_zbid, v_mbl);
      end if;
    end loop;
  
  END IF;
  IF I_OPER = 1 THEN
    --修改-----------------------------------------------------------------------
    IF I_CZC IS NULL THEN
      O_NOTE := '[操作串]不允许为空!';
      RETURN;
    END IF;
    IF I_RWID IS NULL THEN
      O_NOTE := '[任务ID]不允许为空!';
      RETURN;
    END IF;
    --分解操作串
    while V_CZC is not null loop
      V_CZC_S := substr(V_CZC, 1, instr(V_CZC, ',', 1, 1) - 1);
      if V_CZC_S is null then
        V_ZBID := substr(V_CZC, 1, instr(V_CZC, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC, instr(V_CZC, '=', 1, 1) + 1);
        V_CZC  := '';
        update TPIF_RWZBGX a
           set a.mbl = v_mbl
         where a.rwxx = i_rwid
           and a.zbxx = v_zbid;
      else
        V_ZBID := substr(V_CZC_S, 1, instr(V_CZC_S, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC_S, instr(V_CZC_S, '=', 1, 1) + 1);
        V_CZC  := substr(V_CZC, instr(V_CZC, ',', 1, 1) + 1);
        update TPIF_RWZBGX a
           set a.mbl = v_mbl
         where a.rwxx = i_rwid
           and a.zbxx = v_zbid;
      end if;
    end loop;
  END IF;
  IF I_OPER = 2 THEN
    --任务落实-----------------------------------------------------------------------
    IF I_CZC IS NULL THEN
      O_NOTE := '[操作串]不允许为空!';
      RETURN;
    END IF;
    IF I_RWID IS NULL THEN
      O_NOTE := '[任务ID]不允许为空!';
      RETURN;
    END IF;
    begin 
      select frw into v_frwid from tpif_rwfpxx where id = i_rwid;
    exception
      when others then
        v_frwid := null;
    end;
    
    --分解操作串
    while V_CZC is not null loop
      V_CZC_S := substr(V_CZC, 1, instr(V_CZC, ',', 1, 1) - 1);
      if V_CZC_S is null then
        V_ZBID := substr(V_CZC, 1, instr(V_CZC, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC, instr(V_CZC, '=', 1, 1) + 1);
        V_CZC  := '';
        update TPIF_RWZBGX a
           set a.wcl = v_mbl
         where a.rwxx = i_rwid
           and a.zbxx = v_zbid;
        --父任务们的完成量需要加上完成量
        update tpif_rwzbgx b
        set b.wcl = b.wcl+v_mbl
        where id in (
        select t.id from tpif_rwfpxx t
        start with t.id = v_frwid
        connect by id = prior frw
        )and b.zbxx = v_zbid; 
      else
        V_ZBID := substr(V_CZC_S, 1, instr(V_CZC_S, '=', 1, 1) - 1);
        V_MBL  := substr(V_CZC_S, instr(V_CZC_S, '=', 1, 1) + 1);
        V_CZC  := substr(V_CZC, instr(V_CZC, ',', 1, 1) + 1);
        update TPIF_RWZBGX a
           set a.wcl = v_mbl
         where a.rwxx = i_rwid
           and a.zbxx = v_zbid;
        --父任务们的完成量需要加上完成量
        update tpif_rwzbgx b
        set b.wcl = b.wcl+v_mbl
        where id in (
        select t.id from tpif_rwfpxx t
        start with t.id = v_frwid
        connect by id = prior frw
        ) and b.zbxx = v_zbid;   
      end if;
    end loop;
  --更新任务状态为执行中
  update tpif_rwfpxx a 
  set a.rwzt = 5
  where a.id = i_rwid;
  
  END IF;
  IF I_OPER = 3 THEN
    --预留-----------------------------------------------------------------
    null;
  END IF;

  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER, 0, '新增',1,'修改',2,'任务落实') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
  commit;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    rollback;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END pro_pif_rwgl_rwzbgxcz;
/

