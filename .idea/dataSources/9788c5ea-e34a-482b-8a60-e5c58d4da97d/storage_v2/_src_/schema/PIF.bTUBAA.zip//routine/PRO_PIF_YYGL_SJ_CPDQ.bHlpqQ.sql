create PROCEDURE PRO_PIF_YYGL_SJ_CPDQ(O_CODE OUT NUMBER,
                                                 O_NOTE OUT VARCHAR2,
                                                 I_RZLX IN NUMBER, --1|日常;2|重做;3|调整
                                                 I_KSRQ IN NUMBER DEFAULT NULL, --开始日期
                                                 I_JSRQ IN NUMBER DEFAULT NULL --结束日期
                                                 ) AS
  /******************************************************************
  项目名称：PIF  产品中心-运营管理
  所属用户：PIF
  概要说明：产品到期事件
        I_KSRQ    --开始日期
        I_JSRQ    --结束日期
  语法信息：
       输出参数：
          O_CODE  成功返回 成功，失败返回-1
          O_NOTE     成功返回操作成功，失败返回错误信息
  数据准备：
        1)、TPIF_CPCJLX(产品事件类型);
        2)、TPIF_CPSJ(产品事件);
  运行原理：
        1.入参校验
       2.产品发行到期事件生成。
         2.1判断条件,获取事件类型。
         2.2生成产品事件。
  功能修订：
      简要说明：
        产品到期事件
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2017-09-29     1.0.2     SYH                修改：筛选条件排除掉发行失败的产品
  *********************************************************************************************************************/
  CONST_DYGC_CPDQ  CONSTANT VARCHAR2(100) DEFAULT UPPER('PRO_PIF_YYGL_SJ_CPDQ'); --产品到期过程编码
  CONST_CPZTBS_YSJ CONSTANT INTEGER DEFAULT 8; --产品标识_已上架

  V_SJLX    NUMBER(16); --事件类型
  V_KSRQ    NUMBER(8) DEFAULT I_KSRQ; --当前日期
  V_JSRQ    NUMBER(8) DEFAULT I_JSRQ; --当前日期
  V_CURDATE TIMESTAMP; --当前时间
  V_CLSJS   NUMBER(8); --生成事件数
  V_SJCZLX  NUMBER(8); --事件类型对应的操作类型
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';
  --1.***************************入参校验 ***************************
  --当前变量赋值
  IF V_KSRQ IS NULL THEN
    V_KSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
  END IF;
  IF V_JSRQ IS NULL THEN
    V_JSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
  END IF;
  --1.1获取产品事件类型
  SELECT A.ID, A.CZLX
    INTO V_SJLX, V_SJCZLX
    FROM TPIF_CPSJLX A
   WHERE A.DYGC = CONST_DYGC_CPDQ
     AND ROWNUM = 1;
  --1.2去除已经生成的无效的事件或者任务
  IF V_SJCZLX = 2 THEN
    V_CURDATE := SYSTIMESTAMP;
    DELETE FROM TPIF_CPSJ
     WHERE CPSJLX = V_SJLX
       AND SJKSSJ >= TO_DATE(V_KSRQ, 'YYYYMMDD');
    V_CLSJS := SQL%ROWCOUNT; --处理事件数
  
  END IF;
  --2.***************************获取事件类型，执行事件调度。***************************
  V_CURDATE := SYSTIMESTAMP;
  --2.1.***************************执行调度过程。***************************
  INSERT INTO TPIF_CPSJ
    (ID, CPID, CPSJLX, SJKSSJ, SJJSSJ, CXTS, SJMS, SJSCRQ, SJSCSJ, SFSX)
    SELECT SEQ_TPIF_CPSJ.NEXTVAL,
           A.ID,
           V_SJLX,
           TO_DATE(A.DQRQ, 'YYYYMMDD') - 10,
           TO_DATE(A.DQRQ, 'YYYYMMDD') - 10,
           1,
           '产品【' || A.CPMC || '】将于[' || A.DQRQ || '] 到期。',
           V_KSRQ,
           SYSDATE,
           1
      FROM TPIF_CPDM A
     WHERE TO_NUMBER(TO_CHAR(TO_DATE(A.DQRQ, 'YYYYMMDD') - 10, 'YYYYMMDD')) >=
           V_KSRQ
       AND TO_NUMBER(TO_CHAR(TO_DATE(A.DQRQ, 'YYYYMMDD') - 10, 'YYYYMMDD')) <=
           V_JSRQ
       and a.dqrq > 0
       and length(a.dqrq) = 8;
  /*AND EXISTS (SELECT 1
   FROM TPIF_CPDM_POTC_J T
  WHERE A.ID = T.CPID
    AND T.FXZT <> 6); --发行失败;*/

  V_CLSJS := SQL%ROWCOUNT;

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
      RETURN;
    END;
END PRO_PIF_YYGL_SJ_CPDQ;
/

