create PROCEDURE PRO_SJQX_CPJZCSH(O_CODE OUT NUMBER,
                                             O_NOTE OUT VARCHAR2) AS
  /******************************************************************
      所属用户：PIF
      功能说明：产品净值 初始化 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号        修订人             修改内容简要说明
          2021-7-7       1.0.0    GAOKUN、HANQIAONAN           创建
          2021-7-23      1.0.1    GAOKUN、HANQIAONAN      RZF计算公式修改
  
  ***********************************************************************/
  V_COUNT  NUMBER;
  V_YCXX   VARCHAR2(200); --异常信息
  V_JZYC   INTEGER := 0; --净值异常  0|无异常,1|单位净值不同,2|累计净值不同,3|都不同
  V_ZDFYC  INTEGER; --涨跌幅异常  0|无异常,1|异常
  V_ZJJGID INTEGER; --质检结果ID
  V_ZDF    NUMBER(16, 4); --涨跌幅
  V_LASTSX NUMBER; --上一个有效顺序
  V_YJYRQ  NUMBER; --有效交易日期
  V_YJZRQ  NUMBER; --有效净值日期
  V_YDWJZ  NUMBER(16, 4); --有效单位净值
  V_YLJJZ  NUMBER(16, 4); --有效累计净值

BEGIN

  O_CODE := -1;
  O_NOTE := '';

  --该部分产品不用质检，直接插入到产品净值表
  FOR CUR_CP IN (SELECT B.PROD_CODE, B.PRODTA_NO，A.CPID
                   FROM SRC_PIF.DWD_PRD_PRODCODE_DD B, PIF.TPIF_CPDM A
                  WHERE TRIM(B.PROD_CODE) IS NOT NULL
                    AND TRIM(B.PRODCODE_TYPE) IS NOT NULL
                    AND TRIM(B.PROD_CODE) = TRIM(A.CPDM)
                    AND A.CPXL = 5 --银行理财
                    AND A.CPNBZT >= 0 --去掉已删除和已下架产品
                 ) LOOP
  
    INSERT INTO TPIF_CPJZ
      (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM)
      SELECT SEQ_TPIF_CPJZ.NEXTVAL,
             CUR_CP.CPID,
             TO_NUMBER(TRIM(INIT_DATE)),
             TO_NUMBER(TRIM(NAV_DATE)),
             TO_NUMBER(TRIM(NET_VALUE)),
             TO_NUMBER(TRIM(NAV_TOTAL)),
             5, --数据来源 5柜台
             1, --确认状态 1有效
             CUR_CP.PROD_CODE
        FROM (SELECT DISTINCT M.INIT_DATE,
                              M.NAV_DATE,
                              M.NET_VALUE,
                              M.NAV_TOTAL
                FROM SRC_PIF.DWD_PRD_PRODPRICE_DD M
               WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
                 AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO)
               ORDER BY M.NAV_DATE);
  END LOOP;

  --权益类的私募产品进行质检
  FOR CUR_CP IN (SELECT B.PROD_CODE, B.PRODTA_NO，A.CPID
                   FROM SRC_PIF.DWD_PRD_PRODCODE_DD B, PIF.TPIF_CPDM A
                  WHERE TRIM(B.PROD_CODE) IS NOT NULL
                    AND TRIM(B.PRODCODE_TYPE) IS NOT NULL
                    AND TRIM(B.PROD_CODE) = TRIM(A.CPDM)
                    AND A.CPXL IN (2, 3, 8) --私募投资基金、私募资管计划、信托计划
                    AND A.CPNBZT >= 0 --去掉已删除和已下架产品
                 ) LOOP
    --对每个产品循环
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_JZZJ ';
  
    INSERT INTO TMP_JZZJ
      (CPID, CPDM, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, ZJZT, SX)
      SELECT CUR_CP.CPID,
             CUR_CP.PROD_CODE,
             TO_NUMBER(TRIM(INIT_DATE)),
             TO_NUMBER(TRIM(NAV_DATE)),
             TO_NUMBER(TRIM(NET_VALUE)),
             TO_NUMBER(TRIM(NAV_TOTAL)),
             5, --数据来源 5柜台
             0, --质检状态，默认为0
             ROWNUM --顺序
        FROM (SELECT DISTINCT M.INIT_DATE,
                              M.NAV_DATE,
                              M.NET_VALUE,
                              M.NAV_TOTAL
                FROM SRC_PIF.DWD_PRD_PRODPRICE_DD M
               WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
                 AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO)
               ORDER BY M.NAV_DATE);
  
    --原交易日期初始化
    V_YJYRQ := 0;
    SELECT COUNT(1) INTO V_COUNT FROM TMP_JZZJ;
    IF V_COUNT = 0 THEN
      CONTINUE;
    END IF;
  
    FOR CUR_JZ IN (SELECT * FROM TMP_JZZJ ORDER BY SX) LOOP
      --START
      V_YCXX  := '';
      V_JZYC  := 0;
      V_ZDFYC := 0;
    
      --第一条有效净值验证
      IF V_YJYRQ = 0 THEN
        IF CUR_JZ.DWJZ = 0 OR CUR_JZ.LJJZ = 0 THEN
          V_JZYC := 1;
          IF CUR_JZ.DWJZ = 0 THEN
            V_YCXX := V_YCXX || '单位净值异常';
          END IF;
          IF CUR_JZ.LJJZ = 0 THEN
            V_YCXX := V_YCXX || '累计净值异常';
          END IF;
          SELECT COUNT(1)
            INTO V_COUNT
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          IF V_COUNT > 0 THEN
            SELECT ID
              INTO V_ZJJGID
              FROM TPIF_ZJJG_CPJZ
             WHERE CPID = CUR_JZ.CPID
               AND JZRQ = CUR_JZ.JZRQ
               AND YCLB = 1;
            UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            CONTINUE;
          ELSE
            SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
            INSERT INTO TPIF_ZJJG_CPJZ
              (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
            VALUES
              (V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JZRQ,
               0,
               1,
               V_YCXX);
            --插入异常明细
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            CONTINUE;
          END IF;
        END IF;
        --有效则作为初始有效数据
        IF CUR_JZ.DWJZ != 0 AND CUR_JZ.LJJZ != 0 THEN
          UPDATE TMP_JZZJ SET ZJZT = 1 WHERE SX = CUR_JZ.SX;
          V_LASTSX := CUR_JZ.SX;
          SELECT JYRQ, JZRQ, DWJZ, LJJZ
            INTO V_YJYRQ, V_YJZRQ, V_YDWJZ, V_YLJJZ
            FROM TMP_JZZJ
           WHERE SX = V_LASTSX;
          CONTINUE;
        END IF;
      END IF;
      --重复数据跳过
      IF V_YJZRQ = CUR_JZ.JZRQ AND V_YDWJZ = CUR_JZ.DWJZ AND
         V_YLJJZ = CUR_JZ.LJJZ THEN
        UPDATE TMP_JZZJ SET ZJZT = 1 WHERE SX = CUR_JZ.SX;
        V_YJYRQ := CUR_JZ.JYRQ;
        CONTINUE;
      END IF;
      --净值为0进入净值异常
      IF CUR_JZ.DWJZ = 0 OR CUR_JZ.LJJZ = 0 THEN
        V_JZYC := 1;
        IF CUR_JZ.DWJZ = 0 THEN
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;
        IF CUR_JZ.LJJZ = 0 THEN
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_ZJJG_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ
           AND YCLB = 1;
        IF V_COUNT > 0 THEN
          SELECT ID
            INTO V_ZJJGID
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
        ELSE
          SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
          INSERT INTO TPIF_ZJJG_CPJZ
            (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
          VALUES
            (V_ZJJGID, CUR_JZ.CPID, CUR_JZ.CPDM, CUR_JZ.JZRQ, 0, 1, V_YCXX);
        END IF;
        --插入异常明细
        INSERT INTO TPIF_ZJJG_CPJZ_MX
          (ID,
           ZJJGID,
           CPID,
           CPDM,
           JYRQ,
           JZRQ,
           DWJZ,
           LJJZ,
           ZDF,
           CZR,
           ZT,
           CZSJ)
        VALUES
          (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
           V_ZJJGID,
           CUR_JZ.CPID,
           CUR_JZ.CPDM,
           CUR_JZ.JYRQ,
           CUR_JZ.JZRQ,
           CUR_JZ.DWJZ,
           CUR_JZ.LJJZ,
           NULL,
           0,
           0,
           SYSDATE);
        CONTINUE;
      END IF;
    
      --相同净值日期判断净值
      IF V_YJZRQ = CUR_JZ.JZRQ THEN
        IF V_YDWJZ != CUR_JZ.DWJZ OR CUR_JZ.DWJZ = 0 THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;
      
        IF V_YLJJZ != CUR_JZ.LJJZ OR CUR_JZ.LJJZ = 0 THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;
      
        --存在净值异常插入质检结果表
        IF V_JZYC > 0 THEN
        
          --是否存在异常结果
          SELECT COUNT(1)
            INTO V_COUNT
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          IF V_COUNT > 0 THEN
            SELECT ID
              INTO V_ZJJGID
              FROM TPIF_ZJJG_CPJZ
             WHERE CPID = CUR_JZ.CPID
               AND JZRQ = CUR_JZ.JZRQ
               AND YCLB = 1;
            UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
          ELSE
            SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
            INSERT INTO TPIF_ZJJG_CPJZ
              (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
            VALUES
              (V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JZRQ,
               0,
               1,
               V_YCXX);
            --插入异常明细
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               V_YJYRQ,
               V_YJZRQ,
               V_YDWJZ,
               V_YLJJZ,
               NULL,
               0,
               0,
               SYSDATE);
          END IF;
          CONTINUE;
        END IF;
      END IF;
    
      --涨跌幅异常
    
      V_ZDF := ROUND((CUR_JZ.LJJZ - V_YLJJZ) / V_YDWJZ, 4);
    
      IF V_ZDF > 0.15 OR V_ZDF < -0.15 THEN
        V_ZDFYC := 1;
        V_YCXX  := '涨跌幅异常';
        --质检结果ID
        SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
        --插入质检结果
        INSERT INTO TPIF_ZJJG_CPJZ
          (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
        VALUES
          (V_ZJJGID, CUR_JZ.CPID, CUR_JZ.CPDM, CUR_JZ.JZRQ, 0, 2, V_YCXX);
        --插入异常明细
        INSERT INTO TPIF_ZJJG_CPJZ_MX
          (ID,
           ZJJGID,
           CPID,
           CPDM,
           JYRQ,
           JZRQ,
           DWJZ,
           LJJZ,
           ZDF,
           CZR,
           ZT,
           CZSJ)
        VALUES
          (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
           V_ZJJGID,
           CUR_JZ.CPID,
           CUR_JZ.CPDM,
           CUR_JZ.JYRQ,
           CUR_JZ.JZRQ,
           CUR_JZ.DWJZ,
           CUR_JZ.LJJZ,
           V_ZDF,
           0,
           0,
           SYSDATE);
        INSERT INTO TPIF_ZJJG_CPJZ_MX
          (ID,
           ZJJGID,
           CPID,
           CPDM,
           JYRQ,
           JZRQ,
           DWJZ,
           LJJZ,
           ZDF,
           CZR,
           ZT,
           CZSJ)
        VALUES
          (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
           V_ZJJGID,
           CUR_JZ.CPID,
           CUR_JZ.CPDM,
           V_YJYRQ,
           V_YJZRQ,
           V_YDWJZ,
           V_YLJJZ,
           NULL,
           0,
           0,
           SYSDATE);
      END IF;
      IF V_JZYC = 0 AND V_ZDFYC = 0 THEN
        UPDATE TMP_JZZJ SET ZJZT = 1 WHERE SX = CUR_JZ.SX;
        V_LASTSX := CUR_JZ.SX;
        SELECT JYRQ, JZRQ, DWJZ, LJJZ
          INTO V_YJYRQ, V_YJZRQ, V_YDWJZ, V_YLJJZ
          FROM TMP_JZZJ
         WHERE SX = V_LASTSX;
      END IF;
    END LOOP;
  
    INSERT INTO TPIF_CPJZ
      (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM)
      SELECT SEQ_TPIF_CPJZ.NEXTVAL,
             CPID,
             JYRQ,
             JZRQ,
             DWJZ,
             LJJZ,
             5, --数据来源 5柜台
             1, --确认状态 1有效
             CPDM -- CPJZ表增加cpdm
        FROM TMP_JZZJ
       WHERE ZJZT = 1; --质检状态为1的插入TPIF_CPJZ
  
  END LOOP;

  /**************更新TPIF_CPJZ表RZF ************************************/
  MERGE INTO TPIF_CPJZ M
  USING (SELECT CPID,
                JYRQ,
                LJJZ,
                LAG(LJJZ, 1, 0) OVER(PARTITION BY CPID ORDER BY JYRQ ASC) AS ZRLJJZ,
                LAG(DWJZ, 1, 0) OVER(PARTITION BY CPID ORDER BY JYRQ ASC) AS ZRDWJZ
           FROM TPIF_CPJZ) N
  ON (M.JYRQ = N.JYRQ AND M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.RZF = ROUND((CASE
                           WHEN N.ZRDWJZ = 0 THEN
                            0
                           ELSE
                            (N.LJJZ - N.ZRLJJZ) / N.ZRDWJZ
                         END),
                         6);

  /**********************************************************************************/
  --更新 TPIF_CPJZXX_CPZX(产品净值信息_产品中心表，该表以净值日期为唯一日期,
  --用于计算相关指标)
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPJZXX_CPZX ';

  INSERT INTO TPIF_CPJZXX_CPZX
    (CPID, JZRQ, DWJZ, LJJZ, FQJZ, JYRQ, CPDM)
    SELECT CPID, JZRQ, DWJZ, LJJZ, FQJZ, JYRQ, CPDM
      FROM (SELECT CPID,
                   JZRQ,
                   DWJZ,
                   LJJZ,
                   FQJZ,
                   JYRQ,
                   CPDM,
                   ROW_NUMBER() OVER(PARTITION BY CPID, JZRQ ORDER BY JYRQ DESC) AS RN
              FROM TPIF_CPJZ
             WHERE DWJZ != 0
               AND LJJZ != 0)
     WHERE RN = 1; --同一净值日期，如果存在不同净值信息，则取交易日期最大的那一天的数据

  /********计算 TPIF_CPJZXX_CPZX 的RZF，接口查询用到，前端会展示*************/
  MERGE INTO TPIF_CPJZXX_CPZX M
  USING (SELECT A.CPID,
                A.JZRQ,
                A.LJJZ,
                LAG(A.LJJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRLJJZ,
                LAG(A.DWJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRDWJZ
           FROM TPIF_CPJZXX_CPZX A) N
  ON (M.JZRQ = N.JZRQ AND M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.RZF = ROUND((CASE
                           WHEN N.ZRDWJZ = 0 THEN
                            0
                           ELSE
                            (N.LJJZ - N.ZRLJJZ) / N.ZRDWJZ
                         END),
                         6);

  /********************产品最新净值表清空并重新插入最新数据************************/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPZXJZ ';

  INSERT INTO TPIF_CPZXJZ
    (ID,
     CPID,
     JYRQ,
     JZRQ,
     DWJZ,
     LJJZ,
     FQJZ,
     NHSYL,
     WFSYL,
     RZF,
     ZZF,
     QRZT,
     SJLY,
     FBR,
     CZSJ,
     NHSYL_D7,
     CPDM)
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPZXJZ'),
           X.CPID,
           X.JYRQ,
           X.JZRQ,
           X.DWJZ,
           X.LJJZ,
           X.FQJZ,
           X.NHSYL,
           X.WFSYL,
           X.RZF,
           X.ZZF,
           X.QRZT,
           X.SJLY,
           X.FBR,
           SYSDATE,
           X.NHSYL_D7,
           X.CPDM
      FROM (SELECT A.CPID,
                   A.JYRQ,
                   A.JZRQ,
                   A.DWJZ,
                   A.LJJZ,
                   A.FQJZ,
                   A.NHSYL,
                   A.WFSYL,
                   A.RZF,
                   A.ZZF,
                   A.QRZT,
                   A.SJLY,
                   A.FBR,
                   A.NHSYL_D7,
                   A.CPDM,
                   ROW_NUMBER() OVER(PARTITION BY A.CPID ORDER BY A.JZRQ DESC) AS RNN
              FROM TPIF_CPJZXX_CPZX A) X
     WHERE X.RNN = 1;

  /**************更新TPIF_CPDM表净值信息***************************************/
  MERGE INTO PIF.TPIF_CPDM M
  USING (SELECT CPID, JZRQ, DWJZ, LJJZ /*, NHSYL_D7, WFSYL*/
           FROM TPIF_CPZXJZ) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE SET M.JZRQ = N.JZRQ, M.CPJZ = N.DWJZ, M.LJJZ = N.LJJZ;
  /* M.QRNHSYL = N.NHSYL_D7,
  M.WFSYL   = N.WFSYL;*/

  /**************更新TPIF_CPJZXX_CPZX表的 复权净值******************************/
  UPDATE TPIF_CPJZXX_CPZX A --每个产品第一条记录的复权净值
     SET A.FQJZ =
         (A.DWJZ * (A.LJJZ - A.DWJZ + 1))
   WHERE A.JZRQ =
         (SELECT MIN(B.JZRQ) FROM TPIF_CPJZXX_CPZX B WHERE A.CPID = B.CPID);

  --后续的复权净值
  FOR CUR_CP IN (SELECT A.CPID,
                        A.JZRQ,
                        A.RZF,
                        LAG(A.JZRQ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRJZRQ
                   FROM TPIF_CPJZXX_CPZX A) LOOP
    UPDATE TPIF_CPJZXX_CPZX B
       SET B.FQJZ = ROUND((CUR_CP.RZF + 1) *
                          (SELECT FQJZ
                             FROM TPIF_CPJZXX_CPZX
                            WHERE JZRQ = CUR_CP.ZRJZRQ
                              AND CPID = CUR_CP.CPID),
                          4)
     WHERE CUR_CP.ZRJZRQ > 0
       AND B.CPID = CUR_CP.CPID
       AND B.JZRQ = CUR_CP.JZRQ;
  END LOOP;

  /**************更新TPIF_CPDM表 首发净值信息***************************************/
  FOR CUR IN (SELECT CPDM, YRRQ, CPXL, CPID
                FROM TPIF_CPDM
               WHERE YRRQ IS NOT NULL
                 AND SFJZRQ IS NULL) LOOP
    --引入日期不为空，首发净值日期为空
    IF CUR.CPXL = 1 THEN
      --公募净值取聚源
      UPDATE TPIF_CPDM M
         SET (M.SFJZRQ, M.SFDWJZ, M.SFLJJZ) =
             (SELECT TO_NUMBER(TO_CHAR(N.ENDDATE, 'yyyymmdd')),
                     N.UNITNV,
                     N.ACCUMULATEDUNITNV
                FROM INFO.TINFO_JJJZ N
               WHERE N.SECUCODE = CUR.CPDM
                 AND N.ENDDATE =
                     (SELECT MIN(A.ENDDATE)
                        FROM INFO.TINFO_JJJZ A
                       WHERE A.SECUCODE = CUR.CPDM
                         AND TO_NUMBER(TO_CHAR(A.ENDDATE, 'yyyymmdd')) >=
                             CUR.YRRQ))
       WHERE M.CPDM = CUR.CPDM;
    ELSE
      --其余取柜台净值
      UPDATE TPIF_CPDM M
         SET (M.SFJZRQ, M.SFDWJZ, M.SFLJJZ) =
             (SELECT N.JZRQ, N.DWJZ, N.LJJZ
                FROM TPIF_CPJZXX_CPZX N
               WHERE N.CPID = CUR.CPID
                 AND N.JZRQ = (SELECT MIN(A.JZRQ)
                                 FROM TPIF_CPJZXX_CPZX A
                                WHERE A.CPID = CUR.CPID
                                  AND A.JZRQ >= CUR.YRRQ))
       WHERE M.CPID = CUR.CPID;
    END IF;
  END LOOP;
  --引入来源不为空，但是首发净值日期为空的更新，已经有首发净值日期的就不更新了，因为值是固定的不会变

  COMMIT;
  O_CODE := 1;
  O_NOTE := '净值初始化成功！';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '净值表初始化,未知错误'
                ELSE
                 '净值表初始化,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
  
END;
/

