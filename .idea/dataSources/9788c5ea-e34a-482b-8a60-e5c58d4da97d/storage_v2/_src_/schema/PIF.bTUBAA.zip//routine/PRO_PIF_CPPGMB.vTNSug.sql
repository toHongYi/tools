create PROCEDURE PRO_PIF_CPPGMB(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                               I_ID   IN INTEGER --操作ID
                                               ) IS
    /*
    **功能说明：平台管理
    **创建人：刘浪浪
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **刘浪浪     1.0.1     2015/06/02   创建
    **刘浪浪     1.0.2     2015/07/09   解决审核时操作全表记录的bug
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPPGMB%ROWTYPE; --表单记录
    --V_SCBZ    INTEGER; --日志删除标识
    V_OPER    VARCHAR2(200); --操作方法
    V_FDETAIL VARCHAR2(2000); --日志操作明细
    V_WJBM    VARCHAR2(300); --模板编码
    V_VERSION VARCHAR2(300); --版本号
    V_NEWID   INTEGER; --新版本记录对应ID
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    SELECT * INTO V_OBJ FROM TPIF_CPPGMB WHERE ID = I_ID;

    SELECT '[' ||
           DECODE(I_OPER, 0, '新增', 1, '修改', 2, '作废', 3, '生成新版本', 4, '审核')
      INTO V_FDETAIL
      FROM DUAL;

    SELECT DECODE(I_OPER,
                  0,
                  'TPIF_CPPGMB_XZ',
                  1,
                  'TPIF_CPPGMB_XG',
                  2,
                  'TPIF_CPPGMB_ZF',
                  3,
                  'TPIF_CPPGMB_SCXBB',
                  4,
                  'TPIF_CPPGMB_SH')
      INTO V_OPER
      FROM DUAL;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';

    /*IF I_OPER = 0 THEN
        --//:新增



    END IF;*/
    IF I_OPER = 1 THEN
        --//:修改

        IF V_OBJ.STATUS != 1 THEN
            O_NOTE := '只能新增待审的模板才允许操作';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
    END IF;

    IF I_OPER = 2 THEN
        --//:作废
        IF V_OBJ.STATUS != 1 AND V_OBJ.STATUS != 0 THEN
            O_NOTE := '状态为正常或新增待审的模板才允许作废';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;

        IF V_OBJ.STATUS = 0 THEN
            --正常的模板则改为作废待审
            UPDATE TPIF_CPPGMB SET STATUS = 2 WHERE ID = I_ID;
        ELSE
            --新增待审的模板则删除掉该记录
            DELETE FROM TPIF_CPPGMB WHERE ID = I_ID;
        END IF;
    END IF;

    IF I_OPER = 3 THEN
        /*IF V_OBJ.STATUS != 0 THEN
            O_NOTE := '只能正常的模板才允许操作';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;*/

        --获取当前ID对应编码的最大版本号
        SELECT WJBM INTO V_WJBM FROM TPIF_CPPGMB WHERE ID = I_ID;
        SELECT MAX(VERSION)
          INTO V_VERSION
          FROM TPIF_CPPGMB
         WHERE ID = (SELECT MAX(ID) FROM TPIF_CPPGMB WHERE WJBM = V_WJBM);

        IF V_VERSION IS NULL THEN
            V_VERSION := 'V1.0';
        END IF;

        BEGIN
            SELECT SUBSTR(V_VERSION, 0, INSTR(V_VERSION, '.')) ||
                   TO_CHAR(TO_NUMBER(SUBSTR(V_VERSION,
                                            INSTR(V_VERSION, '.') + 1,
                                            LENGTH(V_VERSION))) + 1)
              INTO V_VERSION
              FROM DUAL;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                O_CODE := -1;
                O_NOTE := '获取新版本号出错';
                RETURN;
        END;

        pif.PNEXTID('TPIF_CPPGMB', V_NEWID);
        --插入模板信息
        INSERT INTO TPIF_CPPGMB
            (ID, NAME, WJBM, VERSION, STATUS, CJR, CJSJ)
            SELECT V_NEWID, NAME, WJBM, V_VERSION, 1, I_USER, SYSDATE
              FROM TPIF_CPPGMB
             WHERE ID = I_ID;
        IF SQL%ROWCOUNT = 0 THEN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '记录产品模板信息出错';
            RETURN;
        END IF;
        --插入维度信息
        INSERT INTO TPIF_CPPGMB_QUESTIONS
            (ID, QID, CATEGORY, ANSWER, BH, TPIF_CPPGMB_ID)
            SELECT pif.FUNC_NEXTID('TPIF_CPPGMB_QUESTIONS'),
                   QID,
                   CATEGORY,
                   ANSWER,
                   BH,
                   V_NEWID
              FROM TPIF_CPPGMB_QUESTIONS
             WHERE TPIF_CPPGMB_ID = I_ID;
        IF SQL%ROWCOUNT = 0 THEN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '记录产品框架维度出错';
            RETURN;
        END IF;
        --插入产品评估匹配设置
        INSERT INTO TPIF_CPPGPPSZ
            (ID, PGMB, ZDYJ, PFXX, PFSX, HZFW)
            SELECT pif.FUNC_NEXTID('TPIF_CPPGPPSZ'), V_NEWID, ZDYJ, PFXX, PFSX, HZFW
              FROM TPIF_CPPGPPSZ
             WHERE PGMB = I_ID;
    END IF;

    IF I_OPER = 4 THEN
        --审核

        IF V_OBJ.STATUS != 1 AND V_OBJ.STATUS != 2 THEN
            O_NOTE := '状态为待审的模板才需要审核';
            RETURN;
        END IF;

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPPGPPSZ WHERE PGMB = I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '该模板评估配置未设置';
            RETURN;
        END IF;

        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;

        --新增待审的记录变更为正常，作废待审的变更为作废
        UPDATE TPIF_CPPGMB
           SET STATUS = DECODE(V_OBJ.STATUS, 1, 0, -1), SHR = I_USER, SHSJ = SYSDATE
         WHERE ID = I_ID;
    END IF;

    --RECORD
    /*CRMII.PRO_CZRZDJ(O_CODE,
                     O_NOTE,
                     I_USER,
                     'TPIF_CPPGMB',
                     V_OPER,
                     I_ID,
                     V_FDETAIL,
                     I_IP,
                     '28001',
                     '');
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;*/

    O_CODE := 199;
    SELECT '执行[' ||
           DECODE(I_OPER, 0, '新增', 1, '修改', 2, '作废', 3, '生成新版本', 4, '审核') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
        ROLLBACK;
END PRO_PIF_CPPGMB;
/

