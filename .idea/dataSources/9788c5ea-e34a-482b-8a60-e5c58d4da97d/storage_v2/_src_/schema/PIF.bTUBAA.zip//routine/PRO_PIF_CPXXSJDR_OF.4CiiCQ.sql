create PROCEDURE PRO_PIF_CPXXSJDR_OF(O_RESULT OUT INT, --返回结果代码
                                                O_NOTE   OUT VARCHAR2, --返回结果说明
                                                I_RQ     IN NUMBER, --日期
                                                I_JGDM   IN VARCHAR2, --机构代码
                                                I_USERID IN VARCHAR2, --用户ID, tuser.userid
                                                I_IP     IN VARCHAR2 --操作站点
                                                ) AS
    /******************************************************************************
    *
    *文件名称：pro_pif_cpxxsjdr_of
    *项目名称：海通产品中心
    *功能说明：TXT文件导入产品后处理通用过程
    *处理逻辑：先将参数信息写到临时表 TPIF_CPDM_TMP_OF中存储起来,再将其信息分别写到'1'、'N'、'P'等属性表中
     I_RQ     IN NUMBER  --日期
     I_JGDM   IN VARCHAR2, --机构代码
     I_USERID IN VARCHAR2, --用户ID, tuser.userid
     I_IP     IN VARCHAR2 --操作站点
    
    *------------------------------------------------------------------------------
    *修改者        版本号        修改日期         说明
    *孙远何        v1.0.1        2015-12-07       新增
    *孙远何        v1.0.2        2015-12-21       修改：增加重点参数变更提醒（邮件形式）
    *邵建杰        v1.0.3        2016-03-04       修改：将v_ids的长度扩展到30000，并且将第668行语句改写
    *****************************************************************************/

    V_COUNT    NUMBER(8) := 0;
    V_COUNT_CL NUMBER(8) := 0;
    V_FXJG     NUMBER(16);
    V_CZY      NUMBER(12);
    --V_IDS      VARCHAR2(30000);
    V_SQL      VARCHAR2(8000);
    V_JOBID    NUMBER(16);


BEGIN

    O_RESULT := 1;
    O_NOTE   := '成功';

    BEGIN
        SELECT ID INTO V_CZY FROM livebos.TUSER WHERE USERID = I_USERID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            O_RESULT := -1;
            O_NOTE   := '用户' || I_USERID || '不存在';
            RETURN;
    END;

    SELECT MAX(JOB_ID)
      INTO V_JOBID
      FROM TPIF_XTWJPZ
     WHERE YWFL = 7 /*产品信息文件*/
       AND JGDM = I_JGDM;
    IF (V_JOBID > 0) THEN
        UPDATE TFILEJOB SET STATUS = 3, MSG = '数据处理中' WHERE ID = V_JOBID;
        COMMIT;
    END IF;
    --过滤空格
    FOR X IN (SELECT COLUMN_NAME || '=replace(' || COLUMN_NAME || ','' '',null)' COL
                FROM USER_TAB_COLS
               WHERE DATA_TYPE = 'VARCHAR2'
                 AND TABLE_NAME = 'TPIF_TEMP_QS_OF_07') LOOP
        IF (V_SQL IS NULL) THEN
            V_SQL := X.COL;
        ELSE
            V_SQL := V_SQL || ',' || X.COL;
        END IF;
    END LOOP;
    IF (V_SQL IS NOT NULL) THEN
        V_SQL := 'update TPIF_TEMP_QS_OF_07 set ' || V_SQL;
        EXECUTE IMMEDIATE V_SQL;
    END IF;
    commit ;
    --取发行机构
    SELECT ID INTO V_FXJG FROM tORG_CODE_INFO WHERE ORG_CODE = I_JGDM;

    
    --计算导入总行数
    SELECT COUNT(*) INTO V_COUNT FROM TPIF_TEMP_QS_OF_07;
    /*----------------------------------------------------------------------
     基金信息数据如下：
     FundName                    VARCHAR2(40),   --C  40  基金名称
     TotalFundVol                NUMBER(16,2),   --N  16（两位小数）  基金总份数
     FundCode                    VARCHAR2(6),    --C  6  基金代码
     FundStatus                  VARCHAR2(1),    --C  1  基金状态  0-可申购赎回，1-发行 4-停止申购赎回 5-停止申购，6-停止赎回 8-基金终止，9-基金封闭
     NAV                         NUMBER(7,4),    --N  7（四位小数）  基金单位净值
     UpdateDate                  NUMBER(8),      --A  8  基金净值日期
     NetValueType                VARCHAR2(1),    --C  1  净值类型  0-普通净值1-申购净值 2-赎回净值 对ETF、QDII基金可同时下发3条净值记录，通过此字段区分基金单位净值及基金净值日期的含义
     AccumulativeNAV             NUMBER(7,4),    --N  7（四位小数）  累计基金单位净值
     ConvertStatus               VARCHAR2(1),    --C  1  基金转换状态  0-可转入，可转出  1-只可转入  2-只可转出  3-不可转换
     PeriodicStatus              VARCHAR2(1),    --C  1  定期定额状态  0-允许定期定额业务  1-仅允许定投业务  2-仅允许定赎业务  3-禁止定期定额业务
     TransferAgencyStatus        VARCHAR2(1),    --C  1  转托管状态  0-允许所有转托管  1-仅允许场外转托管  2-仅允许跨市场转托管3-禁止所有转托管
     FundSize                    NUMBER(16,2),   --N  16（两位小数）  基金规模
     CurrencyType                VARCHAR2(3),    --A  3  结算币种
     AnnouncFlag                 VARCHAR2(1),    --C  1  公告标志
     "DEFDIVIDENDMETHOD"         NUMBER(1),      --A  1  默认分红方式
     InstAppSubsAmnt             NUMBER(16,2),   --N  16（两位小数）  法人追加认购金额
     InstAppSubsVol              NUMBER(16,2),   --N  16（两位小数）  法人追加认购份数
     MinAmountByInst             NUMBER(16,2),   --N  16（两位小数）  法人首次认购最低金额
     MinVolByInst                NUMBER(16,2),   --N  16（两位小数）  法人首次认购最低份数
     CustodianCode               VARCHAR2(3),    --A  3  托管人代码
     AmountOfPeriodicSubs        NUMBER(16,2),   --N  16（两位小数）  定时定额申购的金额
     DateOfPeriodicSubs          NUMBER(8),      --A  8  定时定额申购日期
     MaxRedemptionVol            NUMBER(16,2),   --N  16（两位小数）  基金最高赎回份数
     MinAccountBalance           NUMBER(16,2),   --N  16（两位小数）  基金最低持有份数
     IPOStartDate                NUMBER(8),      --A  8  基金募集开始日期
     IPOEndDate                  NUMBER(8),      --A  8  基金募集结束日期
     FundManagerCode             VARCHAR2(3),    --C  3  基金管理人
     IndiAppSubsVol              NUMBER(16,2),   --N  16（两位小数）  个人追加认购份数
     IndiAppSubsAmount           NUMBER(16,2),   --N  16（两位小数）  个人追加认购金额
     MinSubsVolByIndi            NUMBER(16,2),   --N  16（两位小数）  个人首次认购最低份数
     MinSubsAmountByIndi         NUMBER(16,2),   --N  16（两位小数）  个人首次认购最低金额
     RegistrarCode               VARCHAR2(2),    --C  2  注册登记人代码
     FundSponsor                 VARCHAR2(3),    --A  3  基金发起人
     TradingPrice                NUMBER(7,4),    --N  7（四位小数）  交易价格
     FaceValue                   NUMBER(7,4),    --N  7（四位小数）  基金面值
     DividentDate                NUMBER(8),      --A  8  分红日;发放日
     RegistrationDate            NUMBER(8),      --A  8  权益登记日期
     XRDate                      NUMBER(8),      --A  8  除权日
     MaxSubsVolByIndi            NUMBER(16,2),   --N  16（两位小数）  个人最高认购份数
     MaxSubsAmountByIndi         NUMBER(16,2),   --N  16（两位小数）  个人最高认购金额
     MaxSubsVolByInst            NUMBER(16,2),   --N  16（两位小数）  法人最高认购份数
     MaxSubsAmountByInst         NUMBER(16,2),   --N  16（两位小数）  法人最高认购金额
     UnitSubsVolByIndi           NUMBER(16,2),   --N  16（两位小数）  个人认购份数单位
     UnitSubsAmountByIndi        NUMBER(16,2),   --N  16（两位小数）  个人认购金额单位
     UnitSubsVolByInst           NUMBER(16,2),   --N  16（两位小数）  法人认购份数单位
     UnitSubsAmountByInst        NUMBER(16,2),   --N  16（两位小数）  法人认购金额单位
     MinBidsAmountByIndi         NUMBER(16,2),   --N  16（两位小数）  个人首次申购最低金额
     MinBidsAmountByInst         NUMBER(16,2),   --N  16（两位小数）  法人首次申购最低金额
     MinAppBidsAmountByIndi      NUMBER(16,2),   --N  16（两位小数）  个人追加申购最低金额
     MinAppBidsAmountByInst      NUMBER(16,2),   --N  16（两位小数）  法人追加申购最低金额
     MinRedemptionVol            NUMBER(16,2),   --N  16（两位小数）  基金最少赎回份数
     MinInterconvertVol          NUMBER(16,2),   --N  16（两位小数）  最低基金转换份数
     IssueTypeByIndi             VARCHAR2(1),    --C  1  个人发行方式  1-比例发行  2-摇号  3-先来先买
     IssueTypeByInst             VARCHAR2(1),    --C  1  机构发行方式  1-比例发行  2-摇号  3-先来先买
     SubsType                    VARCHAR2(1),    --C  1  认购方式  0-金额认购  1-份数认购
     CollectFeeType              VARCHAR2(1),    --C  1  交易费收取方式  0-价内费  1-价外费
     NextTradeDate               NUMBER(8),      --A  8  下一开放日
     ValueLine                   NUMBER(7,2),    --N  7（两位小数）  产品价值线数值
     TotalDivident               NUMBER(8,5),    --N  8(五位小数)  累计单位分红
     FundIncome                  NUMBER(8,5),    --N  8(五位小数)  货币基金万份收益  0-正  1-负  货币基金必填
     FundIncomeFlag              VARCHAR2(1),    --C  1  货币基金万份收益正负
     Yield                       NUMBER(8,5),    --N  8(五位小数)  货币基金七日年化收益率
     YieldFlag                   VARCHAR2(1),    --C  1  货币基金七日年化收益率正负
     GuaranteedNAV               NUMBER(7,4),    --N  7(四位小数)  保本净值
     FundYearIncomeRate          NUMBER(8,5),    --N  8(五位小数)  货币基金年收益率
     FundYearIncomeRateFlag      VARCHAR2(1),    --C  1  货币基金年收益率正负
     IndiMaxPurchase             NUMBER(16,2),   --N  16(两位小数)  个人最大申购金额
     InstMaxPurchase             NUMBER(16,2),   --N  16(两位小数)  法人最大申购金额
     IndiDayMaxSumBuy            NUMBER(16,2),   --N  16(两位小数)  个人当日累计购买最大金额
     InstDayMaxSumBuy            NUMBER(16,2),   --N  16(两位小数)  法人当日累计购买最大金额
     IndiDayMaxSumRedeem         NUMBER(16,2),   --N  16(两位小数)  个人当日累计赎回最大份额
     InstDayMaxSumRedeem         NUMBER(16,2),   --N  16(两位小数)  法人当日累计赎回最大份额
     IndiMaxRedeem               NUMBER(16,2),   --N  16(两位小数)  个人最大赎回份额
     InstMaxRedeem               NUMBER(16,2),   --N  16(两位小数)  法人最大赎回份额
     FundDayIncomeFlag           VARCHAR2(1),    --C  1  基金当日总收益正负
     FundDayIncome               NUMBER(16,2),   --N  16(两位小数)  基金当日总收益
     AllowBreachRedempt          VARCHAR2(1),    --C  1  允许违约赎回标志  0-允许，1-不允许
     FundType                    VARCHAR2(2),    --C  2  基金类型  01-股票型02-债券型03-混合型04-货币型
     FundTypeName                VARCHAR2(30),   --C  30  基金类型名称
     RegistrarName               VARCHAR2(40),   --C  40  注册登记人名称
     FundManagerName             VARCHAR2(40),   --C  40  基金管理人名称
     FundServerTel               VARCHAR2(30),    --C  30  基金公司客服电话
     FundInternetAddress         VARCHAR2(40)       --C  40  基金公司网站网址
    -------------------------------------------------------------------------*/

    --数据写到公募基金临时表中存储
    MERGE /*+APPEND*/ INTO TPIF_CPDM_TMP_OF A
    USING (SELECT/*+PARALLEL(C,4)*/ FUNDNAME CPMC,
                  TOTALFUNDVOL JJZFS,
                  FUNDCODE CPDM,
                  FUNDSTATUS JJZT,
                  NAV JJJZ,
                  UPDATEDATE JZRQ,
                  NETVALUETYPE JZLX,
                  ACCUMULATIVENAV LJJZ,
                  CONVERTSTATUS JJZHZT,
                  PERIODICSTATUS DQDEZT,
                  TRANSFERAGENCYSTATUS ZTGZT,
                  FUNDSIZE JJGM,
                  CURRENCYTYPE JSBZ,
                  ANNOUNCFLAG GGBZ,
                  DEFDIVIDENDMETHOD MRFHFS,
                  TRADINGPRICE JYJG,
                  FACEVALUE JJMZ,
                  ISSUETYPEBYINDI GRFXFS,
                  ISSUETYPEBYINST JGFXFS,
                  COLLECTFEETYPE JYFSQFS,
                  VALUELINE CPJZXSZ,
                  TOTALDIVIDENT LJDWFH,
                  FUNDINCOME HBJJWFSY,
                  FUNDINCOMEFLAG HBJJWFSYZF,
                  YIELD HBJJQRNHSYL,
                  YIELDFLAG HBJJQRNHSYLZF,
                  GUARANTEEDNAV BBJZ,
                  FUNDYEARINCOMERATE HBJJNSYL,
                  FUNDYEARINCOMERATEFLAG HBJJNSYLZF,
                  FUNDDAYINCOMEFLAG JJDRZSYZF,
                  FUNDDAYINCOME JJDRZSY,
                  IPOSTARTDATE JJMJKSRQ,
                  IPOENDDATE JJMJJSRQ,
                  FUNDTYPE JJLX,
                  FUNDTYPENAME JJLXMC,
                  INSTAPPSUBSAMNT ZJRGJE_JG,
                  INSTAPPSUBSVOL ZJRGFS_JG,
                  MINAMOUNTBYINST SCRGZDJE_JG,
                  MINVOLBYINST SCRGZDFS_JG,
                  INDIAPPSUBSVOL ZJRGFS_GR,
                  INDIAPPSUBSAMOUNT ZJRGJE_GR,
                  MINSUBSVOLBYINDI SCRGZDFS_GR,
                  MINSUBSAMOUNTBYINDI SCRGZDJE_GR,
                  MAXSUBSVOLBYINDI ZGRGFS_GR,
                  MAXSUBSAMOUNTBYINDI ZGRGJE_GR,
                  MAXSUBSVOLBYINST ZGRGFS_JG,
                  MAXSUBSAMOUNTBYINST ZGRGJE_JG,
                  UNITSUBSVOLBYINDI RGFSDW_GR,
                  UNITSUBSAMOUNTBYINDI RGJEDW_GR,
                  UNITSUBSVOLBYINST RGFSDW_JG,
                  UNITSUBSAMOUNTBYINST RGJEDW_JG,
                  SUBSTYPE RGFS,
                  INDIDAYMAXSUMBUY DRLJGMZDJE_GR,
                  INSTDAYMAXSUMBUY DRLJGMZDJE_JG,
                  AMOUNTOFPERIODICSUBS DSDESGJE,
                  DATEOFPERIODICSUBS DSDESGRQ,
                  MINBIDSAMOUNTBYINDI SCSGZDJE_GR,
                  MINBIDSAMOUNTBYINST SCSGZDJE_JG,
                  MINAPPBIDSAMOUNTBYINDI ZJSGZDJE_GR,
                  MINAPPBIDSAMOUNTBYINST ZJSGZDJE_JG,
                  INDIMAXPURCHASE ZDSGJE_GR,
                  INSTMAXPURCHASE ZDSGJE_JG,
                  MININTERCONVERTVOL ZDJJZHFS,
                  MAXREDEMPTIONVOL JJZGSHFS,
                  MINACCOUNTBALANCE JJZDCYFS,
                  MINREDEMPTIONVOL JJZSSHFS,
                  INDIMAXREDEEM ZDSHFE_GR,
                  INSTMAXREDEEM ZDSHFE_JG,
                  ALLOWBREACHREDEMPT YXWYSHBZ,
                  INDIDAYMAXSUMREDEEM DRLJSHZDFE_GR,
                  INSTDAYMAXSUMREDEEM DRLJSHZDFE_JG,
                  '' JJSSTA,
                  CUSTODIANCODE TGRDM,
                  '' JJTGRMC,
                  FUNDMANAGERCODE JJGLR,
                  FUNDMANAGERNAME JJGLRMC,
                  REGISTRARCODE ZCDJR,
                  REGISTRARNAME ZCDJRMC,
                  FUNDSPONSOR JJFQR,
                  FUNDSERVERTEL JJGSKFDH,
                  FUNDINTERNETADDRESS JJGSWZ,
                  DIVIDENTDATE FHR,
                  REGISTRATIONDATE QYDJR,
                  XRDATE CQR,
                  NEXTTRADEDATE XYKFR,
                  V_FXJG JJFXR
             FROM TPIF_TEMP_QS_OF_07 C
            WHERE NOT EXISTS (SELECT 1
                     FROM TPIF_TEMP_QS_OF_07
                    WHERE FUNDCODE = C.FUNDCODE
                      AND UPDATEDATE > C.UPDATEDATE)
            ) B
    ON (A.CPDM = B.CPDM AND A.JJFXR = V_FXJG)
    WHEN MATCHED THEN
        UPDATE
           SET A.CPMC          = NVL(B.CPMC, A.CPMC),
               A.JJZFS         = NVL(B.JJZFS, A.JJZFS),
               A.JJZT          = NVL(B.JJZT, A.JJZT),
               A.JJJZ          = NVL(B.JJJZ, A.JJJZ),
               A.JZRQ          = NVL(B.JZRQ, A.JZRQ),
               A.JZLX          = NVL(B.JZLX, A.JZLX),
               A.LJJZ          = NVL(B.LJJZ, A.LJJZ),
               A.JJZHZT        = NVL(B.JJZHZT, A.JJZHZT),
               A.DQDEZT        = NVL(B.DQDEZT, A.DQDEZT),
               A.ZTGZT         = NVL(B.ZTGZT, A.ZTGZT),
               A.JJGM          = NVL(B.JJGM, A.JJGM),
               A.JSBZ          = NVL(B.JSBZ, A.JSBZ),
               A.GGBZ          = NVL(B.GGBZ, A.GGBZ),
               A.MRFHFS        = NVL(B.MRFHFS, A.MRFHFS),
               A.JYJG          = NVL(B.JYJG, A.JYJG),
               A.JJMZ          = NVL(B.JJMZ, A.JJMZ),
               A.GRFXFS        = NVL(B.GRFXFS, A.GRFXFS),
               A.JGFXFS        = NVL(B.JGFXFS, A.JGFXFS),
               A.JYFSQFS       = NVL(B.JYFSQFS, A.JYFSQFS),
               A.CPJZXSZ       = NVL(B.CPJZXSZ, A.CPJZXSZ),
               A.LJDWFH        = NVL(B.LJDWFH, A.LJDWFH),
               A.HBJJWFSY      = NVL(B.HBJJWFSY, A.HBJJWFSY),
               A.HBJJWFSYZF    = NVL(B.HBJJWFSYZF, A.HBJJWFSYZF),
               A.HBJJQRNHSYL   = NVL(B.HBJJQRNHSYL, A.HBJJQRNHSYL),
               A.HBJJQRNHSYLZF = NVL(B.HBJJQRNHSYLZF, A.HBJJQRNHSYLZF),
               A.BBJZ          = NVL(B.BBJZ, A.BBJZ),
               A.HBJJNSYL      = NVL(B.HBJJNSYL, A.HBJJNSYL),
               A.HBJJNSYLZF    = NVL(B.HBJJNSYLZF, A.HBJJNSYLZF),
               A.JJDRZSYZF     = NVL(B.JJDRZSYZF, A.JJDRZSYZF),
               A.JJDRZSY       = NVL(B.JJDRZSY, A.JJDRZSY),
               A.JJMJKSRQ      = NVL(B.JJMJKSRQ, A.JJMJKSRQ),
               A.JJMJJSRQ      = NVL(B.JJMJJSRQ, A.JJMJJSRQ),
               A.JJLX          = NVL(B.JJLX, A.JJLX),
               A.JJLXMC        = NVL(B.JJLXMC, A.JJLXMC),
               A.ZJRGJE_JG     = NVL(B.ZJRGJE_JG, A.ZJRGJE_JG),
               A.ZJRGFS_JG     = NVL(B.ZJRGFS_JG, A.ZJRGFS_JG),
               A.SCRGZDJE_JG   = NVL(B.SCRGZDJE_JG, A.SCRGZDJE_JG),
               A.SCRGZDFS_JG   = NVL(B.SCRGZDFS_JG, A.SCRGZDFS_JG),
               A.ZJRGFS_GR     = NVL(B.ZJRGFS_GR, A.ZJRGFS_GR),
               A.ZJRGJE_GR     = NVL(B.ZJRGJE_GR, A.ZJRGJE_GR),
               A.SCRGZDFS_GR   = NVL(B.SCRGZDFS_GR, A.SCRGZDFS_GR),
               A.SCRGZDJE_GR   = NVL(B.SCRGZDJE_GR, A.SCRGZDJE_GR),
               A.ZGRGFS_GR     = NVL(B.ZGRGFS_GR, A.ZGRGFS_GR),
               A.ZGRGJE_GR     = NVL(B.ZGRGJE_GR, A.ZGRGJE_GR),
               A.ZGRGFS_JG     = NVL(B.ZGRGFS_JG, A.ZGRGFS_JG),
               A.ZGRGJE_JG     = NVL(B.ZGRGJE_JG, A.ZGRGJE_JG),
               A.RGFSDW_GR     = NVL(B.RGFSDW_GR, A.RGFSDW_GR),
               A.RGJEDW_GR     = NVL(B.RGJEDW_GR, A.RGJEDW_GR),
               A.RGFSDW_JG     = NVL(B.RGFSDW_JG, A.RGFSDW_JG),
               A.RGJEDW_JG     = NVL(B.RGJEDW_JG, A.RGJEDW_JG),
               A.RGFS          = NVL(B.RGFS, A.RGFS),
               A.DRLJGMZDJE_GR = NVL(B.DRLJGMZDJE_GR, A.DRLJGMZDJE_GR),
               A.DRLJGMZDJE_JG = NVL(B.DRLJGMZDJE_JG, A.DRLJGMZDJE_JG),
               A.DSDESGJE      = NVL(B.DSDESGJE, A.DSDESGJE),
               A.DSDESGRQ      = NVL(B.DSDESGRQ, A.DSDESGRQ),
               A.SCSGZDJE_GR   = NVL(B.SCSGZDJE_GR, A.SCSGZDJE_GR),
               A.SCSGZDJE_JG   = NVL(B.SCSGZDJE_JG, A.SCSGZDJE_JG),
               A.ZJSGZDJE_GR   = NVL(B.ZJSGZDJE_GR, A.ZJSGZDJE_GR),
               A.ZJSGZDJE_JG   = NVL(B.ZJSGZDJE_JG, A.ZJSGZDJE_JG),
               A.ZDSGJE_GR     = NVL(B.ZDSGJE_GR, A.ZDSGJE_GR),
               A.ZDSGJE_JG     = NVL(B.ZDSGJE_JG, A.ZDSGJE_JG),
               A.ZDJJZHFS      = NVL(B.ZDJJZHFS, A.ZDJJZHFS),
               A.JJZGSHFS      = NVL(B.JJZGSHFS, A.JJZGSHFS),
               A.JJZDCYFS      = NVL(B.JJZDCYFS, A.JJZDCYFS),
               A.JJZSSHFS      = NVL(B.JJZSSHFS, A.JJZSSHFS),
               A.ZDSHFE_GR     = NVL(B.ZDSHFE_GR, A.ZDSHFE_GR),
               A.ZDSHFE_JG     = NVL(B.ZDSHFE_JG, A.ZDSHFE_JG),
               A.YXWYSHBZ      = NVL(B.YXWYSHBZ, A.YXWYSHBZ),
               A.DRLJSHZDFE_GR = NVL(B.DRLJSHZDFE_GR, A.DRLJSHZDFE_GR),
               A.DRLJSHZDFE_JG = NVL(B.DRLJSHZDFE_JG, A.DRLJSHZDFE_JG),
               A.JJSSTA        = NVL(B.JJSSTA, A.JJSSTA),
               A.TGRDM         = NVL(B.TGRDM, A.TGRDM),
               A.JJTGRMC       = NVL(B.JJTGRMC, A.JJTGRMC),
               A.JJGLR         = NVL(B.JJGLR, A.JJGLR),
               A.JJGLRMC       = NVL(B.JJGLRMC, A.JJGLRMC),
               A.ZCDJR         = NVL(B.ZCDJR, A.ZCDJR),
               A.ZCDJRMC       = NVL(B.ZCDJRMC, A.ZCDJRMC),
               A.JJFQR         = NVL(B.JJFQR, A.JJFQR),
               A.JJGSKFDH      = NVL(B.JJGSKFDH, A.JJGSKFDH),
               A.JJGSWZ        = NVL(B.JJGSWZ, A.JJGSWZ),
               A.FHR           = NVL(B.FHR, A.FHR),
               A.QYDJR         = NVL(B.QYDJR, A.QYDJR),
               A.CQR           = NVL(B.CQR, A.CQR),
               A.XYKFR         = NVL(B.XYKFR, A.XYKFR),
               A.SCDRRQ        = A.SCDRRQ,
               A.ZJGXRQ        = TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'))
               --A.DJZT          = 2 --有更新
        
    
    WHEN NOT MATCHED THEN
        INSERT
            (A.ID,
             A.CPMC,
             A.JJZFS,
             A.CPDM,
             A.JJZT,
             A.JJJZ,
             A.JZRQ,
             A.JZLX,
             A.LJJZ,
             A.JJZHZT,
             A.DQDEZT,
             A.ZTGZT,
             A.JJGM,
             A.JSBZ,
             A.GGBZ,
             A.MRFHFS,
             A.JYJG,
             A.JJMZ,
             A.GRFXFS,
             A.JGFXFS,
             A.JYFSQFS,
             A.CPJZXSZ,
             A.LJDWFH,
             A.HBJJWFSY,
             A.HBJJWFSYZF,
             A.HBJJQRNHSYL,
             A.HBJJQRNHSYLZF,
             A.BBJZ,
             A.HBJJNSYL,
             A.HBJJNSYLZF,
             A.JJDRZSYZF,
             A.JJDRZSY,
             A.JJMJKSRQ,
             A.JJMJJSRQ,
             A.JJLX,
             A.JJLXMC,
             A.ZJRGJE_JG,
             A.ZJRGFS_JG,
             A.SCRGZDJE_JG,
             A.SCRGZDFS_JG,
             A.ZJRGFS_GR,
             A.ZJRGJE_GR,
             A.SCRGZDFS_GR,
             A.SCRGZDJE_GR,
             A.ZGRGFS_GR,
             A.ZGRGJE_GR,
             A.ZGRGFS_JG,
             A.ZGRGJE_JG,
             A.RGFSDW_GR,
             A.RGJEDW_GR,
             A.RGFSDW_JG,
             A.RGJEDW_JG,
             A.RGFS,
             A.DRLJGMZDJE_GR,
             A.DRLJGMZDJE_JG,
             A.DSDESGJE,
             A.DSDESGRQ,
             A.SCSGZDJE_GR,
             A.SCSGZDJE_JG,
             A.ZJSGZDJE_GR,
             A.ZJSGZDJE_JG,
             A.ZDSGJE_GR,
             A.ZDSGJE_JG,
             A.ZDJJZHFS,
             A.JJZGSHFS,
             A.JJZDCYFS,
             A.JJZSSHFS,
             A.ZDSHFE_GR,
             A.ZDSHFE_JG,
             A.YXWYSHBZ,
             A.DRLJSHZDFE_GR,
             A.DRLJSHZDFE_JG,
             A.JJSSTA,
             A.TGRDM,
             A.JJTGRMC,
             A.JJGLR,
             A.JJGLRMC,
             A.ZCDJR,
             A.ZCDJRMC,
             A.JJFQR,
             A.JJGSKFDH,
             A.JJGSWZ,
             A.FHR,
             A.QYDJR,
             A.CQR,
             A.XYKFR,
             A.JJFXR,
             A.CZR,
             A.SCDRRQ,
             A.ZJGXRQ/*,
             A.DJZT*/)
        VALUES
            (SEQ_TPIF_CPDM_TMP_OF.NEXTVAL,
             B.CPMC,
             B.JJZFS,
             B.CPDM,
             B.JJZT,
             B.JJJZ,
             B.JZRQ,
             B.JZLX,
             B.LJJZ,
             B.JJZHZT,
             B.DQDEZT,
             B.ZTGZT,
             B.JJGM,
             B.JSBZ,
             B.GGBZ,
             B.MRFHFS,
             B.JYJG,
             B.JJMZ,
             B.GRFXFS,
             B.JGFXFS,
             B.JYFSQFS,
             B.CPJZXSZ,
             B.LJDWFH,
             B.HBJJWFSY,
             B.HBJJWFSYZF,
             B.HBJJQRNHSYL,
             B.HBJJQRNHSYLZF,
             B.BBJZ,
             B.HBJJNSYL,
             B.HBJJNSYLZF,
             B.JJDRZSYZF,
             B.JJDRZSY,
             B.JJMJKSRQ,
             B.JJMJJSRQ,
             B.JJLX,
             B.JJLXMC,
             B.ZJRGJE_JG,
             B.ZJRGFS_JG,
             B.SCRGZDJE_JG,
             B.SCRGZDFS_JG,
             B.ZJRGFS_GR,
             B.ZJRGJE_GR,
             B.SCRGZDFS_GR,
             B.SCRGZDJE_GR,
             B.ZGRGFS_GR,
             B.ZGRGJE_GR,
             B.ZGRGFS_JG,
             B.ZGRGJE_JG,
             B.RGFSDW_GR,
             B.RGJEDW_GR,
             B.RGFSDW_JG,
             B.RGJEDW_JG,
             B.RGFS,
             B.DRLJGMZDJE_GR,
             B.DRLJGMZDJE_JG,
             B.DSDESGJE,
             B.DSDESGRQ,
             B.SCSGZDJE_GR,
             B.SCSGZDJE_JG,
             B.ZJSGZDJE_GR,
             B.ZJSGZDJE_JG,
             B.ZDSGJE_GR,
             B.ZDSGJE_JG,
             B.ZDJJZHFS,
             B.JJZGSHFS,
             B.JJZDCYFS,
             B.JJZSSHFS,
             B.ZDSHFE_GR,
             B.ZDSHFE_JG,
             B.YXWYSHBZ,
             B.DRLJSHZDFE_GR,
             B.DRLJSHZDFE_JG,
             B.JJSSTA,
             B.TGRDM,
             B.JJTGRMC,
             B.JJGLR,
             B.JJGLRMC,
             B.ZCDJR,
             B.ZCDJRMC,
             B.JJFQR,
             B.JJGSKFDH,
             B.JJGSWZ,
             B.FHR,
             B.QYDJR,
             B.CQR,
             B.XYKFR,
             B.JJFXR,
             V_CZY,
             TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')),
             TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'))/*,
             0*/);

    V_COUNT_CL := SQL%ROWCOUNT;
    
    
    COMMIT;
 /*   --SELECT wm_concat(id) INTO v_ids FROM tpif_cpdm_tmp_of WHERE JJFXR = V_FXJG;
    FOR CUR_UID IN (SELECT ID FROM TPIF_CPDM_TMP_OF WHERE JJFXR = V_FXJG) LOOP
        V_IDS := V_IDS || CUR_UID.ID || ',';
    END LOOP;
    V_IDS := SUBSTR(V_IDS, 1, LENGTH(V_IDS) - 1); --去掉最后一个逗号*/
    
    PRO_PIF_CPXXSJDR_CPDJ(O_RESULT,
                          O_NOTE,
                         -- V_IDS, --更新的对象ID串
                          I_RQ, --日期
                          I_JGDM, --机构代码
                          V_CZY,
                          I_IP);
                          
                          

  --INSERT INTO TEST_PARA VALUES(V_IDS) ;
 
    IF (V_JOBID > 0) THEN
        UPDATE TFILEJOB
           SET STATUS = 4,
               MSG    = '完成,导入' || V_COUNT || '条,处理' || V_COUNT_CL || '条'
         WHERE ID = V_JOBID;
    END IF;
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        O_RESULT := -1;
        O_NOTE   := SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1000) || SQLERRM;
        ROLLBACK;
        IF (V_JOBID > 0) THEN
            UPDATE TFILEJOB SET STATUS = -2, MSG = O_NOTE WHERE ID = V_JOBID;
            COMMIT;
        END IF;
    
END PRO_PIF_CPXXSJDR_OF;

/

