create PROCEDURE PRO_SJQX_CPDM_GL_XSFL(O_CODE OUT NUMBER, --返回值
                                                  O_NOTE OUT VARCHAR2 --返回消息
                                                  ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品费率表 TPIF_CPDM_XSFL数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：  后端收费的 不考虑
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-08-09     1.0       吴金锋              创建
  ***********************************************************************/
  V_COUNT NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO TPIF_CPDM_GL_XSFL M
  USING (SELECT B.CPID,
                A.FEE_TYPE_CODE,
                A.FEE_LEVEL,
                A.FEE_RATIO,
                A.FEE,
                A.UPPER_LIMIT,
                A.LOWER_LIMIT,
                DECODE(A.LIMIT_UNITS,
                       'YUAN',
                       1,
                       'PCT',
                       2,
                       'Y',
                       3,
                       'M',
                       4,
                       'D',
                       5) AS LIMIT_UNITS,
                A.LIMIT_NAME,
                TO_CHAR(A.START_DATE, 'YYYYMMDD') AS START_DATE,
                TO_CHAR(A.END_DATE, 'YYYYMMDD') AS END_DATE,
                A.REMARK,
                A.ENTRY_TIME
           FROM SRC_PIF.T_FUND_FEE_DATA A, TPIF_CPDM B
          WHERE A.FUND_ID = B.SJYID) N
  ON (M.CPID = N.CPID AND M.FLLB = N.FEE_TYPE_CODE AND M.LJFYJB = N.FEE_LEVEL)
  WHEN MATCHED THEN
    UPDATE
       SET M.FL    = N.FEE_RATIO, --费率  
           M.FY    = N.FEE, --费用
           M.LJSXZ = N.UPPER_LIMIT, --累进上限值
           M.LJXXZ = N.LOWER_LIMIT, --累进下限值
           M.LJZDW = N.LIMIT_UNITS, --累进值单位
           M.KSRQ  = N.START_DATE, --开始日期
           M.JSRQ  = N.END_DATE, --结束日期
           M.BZ    = N.REMARK --备注
    
  
  WHEN NOT MATCHED THEN
    INSERT
      (ID, --ID
       CPID, --产品ID
       FLLB, --费率类别
       LJFYJB, --累进费用级别
       FL, --费率  
       FY, --费用
       LJSXZ, --累进上限值
       LJXXZ, --累进下限值
       LJZDW, --累进值单位
       KSRQ, --开始日期
       JSRQ, --结束日期
       BZ, --备注
       SJLY, --数据来源
       ZT, --ZT
       LRR, --操作人
       LRSJ --操作时间
       )
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_GL_XSFL'),
       N.CPID,
       N.FEE_TYPE_CODE,
       N.FEE_LEVEL,
       N.FEE_RATIO,
       N.FEE,
       N.UPPER_LIMIT,
       N.LOWER_LIMIT,
       N.LIMIT_UNITS,
       N.START_DATE,
       N.END_DATE,
       N.REMARK,
       2,
       4,
       0,
       N.ENTRY_TIME);

  /* --第一次全量
    SELECT COUNT(*) INTO V_COUNT FROM PIF.TPIF_CPDM_XSFL A WHERE A.SJLY = 3;
  
    --增量更新近3天数据
    IF V_COUNT > 0 THEN
  
      MERGE INTO PIF.TPIF_CPDM_XSFL M
      USING (SELECT C.CPID,
                    A.ID,
                    to_char(A.ExcuteDate, 'yyyymmdd') QSRQ,
                    to_char(A.CancelDate, 'yyyymmdd') ZZRQ,
                    A.ChargeRateType,
                    A.ChargeRateTyDes,
                    A.ClientType,
                    A.MinChargeRate,
                    A.MaxChargeRate,
                    A.ChargeRateUnit,
                    A.DivIntervalDes,
                    A.DivStandUnit1,
                    A.StDivStand1,
                    A.EnDivStand1,
                    A.IfApplyStart1,
                    A.IfApplyEnd1,
                    A.XGRQ
               FROM SRC_PIF.MF_CHARGERATENEW A,
                    SRC_PIF.SECUMAIN         B,
                    PIF.TPIF_CPDM            C
              WHERE A.INNERCODE = B.INNERCODE
                AND B.SECUCODE = C.CPDM
                AND C.CPXL = 1
                AND A.CHARGERATETYPE IN ('10010',
                                         -- '10020',
                                         '10210',
                                         -- '10220',
                                         '11010',
                                         -- '11020',
                                         '11210',
                                         -- '11220',
                                         '12000',
                                         '12023',
                                         '12200',
                                         -- '12223',
                                         '15000',
                                         '16000',
                                         '22010',
                                         -- '22020',
                                         '22210',
                                         -- '22220',
                                         '19000')
                AND to_char(A.XGRQ, 'yyyymmdd') >
                    to_char(SYSDATE - 3, 'yyyymmdd') --更新近3天
             ) N
      ON (M.JYID = N.ID)
      WHEN MATCHED THEN
        UPDATE
           SET m.QSRQ    = N.QSRQ, --  起始日期
               m.ZZRQ    = N.ZZRQ, --  终止日期
               m.FLSX    = N.MinChargeRate, -- 费率上限
               m.FLXX    = N.MaxChargeRate, -- 费率下限
               m.FLDW   =
               (CASE
                 WHEN N.ChargeRateUnit = 6 THEN
                  1
                 WHEN N.ChargeRateUnit = 7 THEN
                  2
               END), -- 费率单位 6-%，7-元
               m.FLQJMS  = N.DivIntervalDes, --  费率区间描述
               m.FLHFDW  = N.DivStandUnit1, -- 费率划分标准单位
               m.FLHFQSZ = N.StDivStand1, -- 费率划分起始数值
               m.FLHFJZZ = N.EnDivStand1, -- 费率划分截止数值
               m.SFBHQSZ = N.IfApplyStart1, -- 是否包含范围起始点
               m.SFBHJZZ = N.IfApplyEnd1 -- 是否包含范围截止点
  
  
      WHEN NOT MATCHED THEN
        INSERT
          (ID, --  ID
           JYID,
           SJLY, --  数据来源
           CPID, --  产品名称
           FLLB, --  费率类别
           SYKHLX, --  适用客户类型
           QSRQ, --  起始日期
           ZZRQ, --  终止日期
           FLSX, --  费率上限
           FLXX, --  费率下限
           FLDW, --  费率单位
           FLQJMS, --  费率区间描述
           FLHFDW, --  费率划分标准单位
           FLHFQSZ, --  费率划分起始数值
           FLHFJZZ, --  费率划分截止数值
           SFBHQSZ, --  是否包含范围起始点
           SFBHJZZ, --  是否包含范围截止点
           ZKL, --  折扣率
           ZT, --  状态
           LRR, --  录入人
           LRSJ --  录入时间
           )
        VALUES
          (CRMII.FUNC_NEXTID('TPIF_CPDM_XSFL'), --  ID
           N.ID,
           3, --  聚源采集
           N.CPID, --  产品名称
           (CASE
             WHEN ChargeRateType IN (10220, 10210, 10020, 10010) THEN
              1
             WHEN ChargeRateType IN (11010, 11220, 11210, 11020) THEN
              2
             WHEN ChargeRateType IN (12000, 12023, 12200, 12223) THEN
              3
             WHEN ChargeRateType = 15000 THEN
              4
             WHEN ChargeRateType = 16000 THEN
              5
             WHEN ChargeRateType IN (22220, 22210, 22020, 22010) THEN
              6
             WHEN ChargeRateType = 19000 THEN
              7
           END),
           N.ClientType, -- 适用客户类型
           N.QSRQ, --  起始日期
           N.ZZRQ, --  终止日期
           N.MinChargeRate, -- 费率上限
           N.MaxChargeRate, -- 费率下限
           (CASE
             WHEN N.ChargeRateUnit = 6 THEN
              1
             WHEN N.ChargeRateUnit = 7 THEN
              2
           END), -- 费率单位 6-%，7-元
           N.DivIntervalDes, --  费率区间描述
           N.DivStandUnit1, -- 费率划分标准单位
           N.StDivStand1, -- 费率划分起始数值
           N.EnDivStand1, -- 费率划分截止数值
           N.IfApplyStart1, -- 是否包含范围起始点
           N.IfApplyEnd1, -- 是否包含范围截止点
           1, -- 折扣率，默认给1，后面更新
           4, -- 状态
           0, -- 录入人
           SYSDATE --  录入时间
           );
    ELSE
      INSERT INTO PIF.TPIF_CPDM_XSFL
        (ID, --  ID
         JYID,
         SJLY, --  数据来源
         CPID, --  产品名称
         FLLB, --  费率类别
         SYKHLX, --  适用客户类型
         QSRQ, --  起始日期
         ZZRQ, --  终止日期
         FLSX, --  费率上限
         FLXX, --  费率下限
         FLDW, --  费率单位
         FLQJMS, --  费率区间描述
         FLHFDW, --  费率划分标准单位
         FLHFQSZ, -- 费率划分起始数值
         FLHFJZZ, -- 费率划分截止数值
         SFBHQSZ, -- 是否包含范围起始点
         SFBHJZZ, -- 是否包含范围截止点
         ZKL, -- 折扣率
         ZT, --  状态
         LRR, -- 录入人
         LRSJ -- 录入时间
         )
        SELECT CRMII.FUNC_NEXTID('TPIF_CPDM_XSFL'), -- ID
               A.ID,
               3, -- 聚源采集
               C.CPID, --  产品名称
               (CASE
                 WHEN ChargeRateType IN (10220, 10210, 10020, 10010) THEN
                  1
                 WHEN ChargeRateType IN (11010, 11220, 11210, 11020) THEN
                  2
                 WHEN ChargeRateType IN (12000, 12023, 12200, 12223) THEN
                  3
                 WHEN ChargeRateType = 15000 THEN
                  4
                 WHEN ChargeRateType = 16000 THEN
                  5
                 WHEN ChargeRateType IN (22220, 22210, 22020, 22010) THEN
                  6
                 WHEN ChargeRateType = 19000 THEN
                  7
               END),
               A.ClientType, -- 适用客户类型
               to_char(A.ExcuteDate, 'yyyymmdd') QSRQ,
               to_char(A.CancelDate, 'yyyymmdd') ZZRQ,
               A.MinChargeRate, -- 费率上限
               A.MaxChargeRate, -- 费率下限
               (CASE
                 WHEN A.ChargeRateUnit = 6 THEN
                  1
                 WHEN A.ChargeRateUnit = 7 THEN
                  2
               END), -- 费率单位 6-%，7-元
               A.DivIntervalDes, --  费率区间描述
               A.DivStandUnit1, -- 费率划分标准单位
               A.StDivStand1, -- 费率划分起始数值
               A.EnDivStand1, -- 费率划分截止数值
               A.IfApplyStart1, -- 是否包含范围起始点
               A.IfApplyEnd1, -- 是否包含范围截止点
               1, -- 折扣率，默认给1，后面更新
               4, -- 状态
               0, -- 录入人
               SYSDATE --  录入时间
          FROM SRC_PIF.MF_CHARGERATENEW A,
               SRC_PIF.SECUMAIN         B,
               PIF.TPIF_CPDM            C
         WHERE A.INNERCODE = B.INNERCODE
           AND B.SECUCODE = C.CPDM
           AND C.CPXL = 1
              \*AND A.CHARGERATETYPE IN ('10010',
              '10020',
              '10210',
              '10220',
              '11010',
              '11020',
              '11210',
              '11220',
              '12000',
              '12023',
              '12200',
              '12223',
              '15000',
              '16000',
              '22010',
              '22020',
              '22210',
              '22220',
              '19000'--营销费
              );*\
           AND A.CHARGERATETYPE IN ('10010',
                                    -- '10020',
                                    '10210',
                                    -- '10220',
                                    '11010',
                                    -- '11020',
                                    '11210',
                                    -- '11220',
                                    '12000',
                                    '12023',
                                    '12200',
                                    -- '12223',
                                    '15000',
                                    '16000',
                                    '22010',
                                    -- '22020',
                                    '22210',
                                    -- '22220',
                                    '19000');
  
    END IF;
    --更新折扣率
    MERGE INTO PIF.TPIF_CPDM_XSFL M
    USING (SELECT B.CPID,
                  A.OFCODE,
                  A.TOPDISCRATIO,
                  A.TOPLIMIT
             FROM SRC_PIF.OFHQDISCRATIOCTRL A, PIF.TPIF_CPDM B
            WHERE TRIM(A.OFCODE) = B.CPDM
              AND A.TRDID = '240022') N
    ON (M.CPID = N.CPID AND M.FLHFQSZ <= N.TOPLIMIT)
    WHEN MATCHED THEN
      UPDATE SET M.ZKL = N.TOPDISCRATIO
    WHERE M.FLLB=2;--只更新申购费率的折扣率
  */
  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM_GL_XSFL 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM_GL_XSFL 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM_GL_XSFL 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

