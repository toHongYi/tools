create PROCEDURE PCX_PIF_WDGL_WDSCGZ(O_CODE   OUT NUMBER,
                                                    O_NOTE   OUT VARCHAR2,
                                                    O_RESULT OUT SYS_REFCURSOR,
                                                    
                                                    I_USERID IN NUMBER --登陆用户ID
                                                    
                                                    ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：文档管理-我的收藏规则查询
  
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
  
  
  
        ----------------------------------------------------------
        操作人       版本号      时间                        操作
        WUJINFENG    1.0        2020/06/29                  新增
        HANQIAONAN   1.0.1      2021/09/27                  新增出参产品名称串，机构名称串
  -------------------------------------------------------------------------------------------------*/

BEGIN
  O_CODE         := 1;
  O_NOTE         := '成功!';


  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;
  /*PROD_IDS      产品ID串
    ORG_IDS       机构ID串
    DOC_TYPE_IDS  文档分类ID串
    PROD_TYPE_IDS 产品分类ID串
  */

  OPEN O_RESULT FOR
    SELECT A.CPID AS PROD_IDS,
           A.JGID AS ORG_IDS,
           FUNC_PIF_IDSTONAME(A.CPID,1) AS PROD_NAMES,
           FUNC_PIF_IDSTONAME(A.JGID,2) AS ORG_NAMES,
           A.WDFL AS DOC_TYPE_IDS,
           A.CPXL AS PROD_TYPE_IDS
      FROM TPIF_WDSZGZ A
     WHERE A.YH = I_USERID;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

