create PROCEDURE PRO_PIF_NDKHRW(O_CODE OUT NUMBER,   --返回值
                                           O_NOTE OUT VARCHAR2, --返回消息
                                           I_ND   IN NUMBER,    --年度 YYYY
                                           I_LX   IN NUMBER     --资产规模计算类型：1:根据期末资产计算   2：根据日均资产计算

                                           ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募机构年度考核任务
      语法信息：
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    陈勇军                创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_ND    NUMBER;
  V_LX    NUMBER;
BEGIN

  V_ND := I_ND;
  V_LX := I_LX;

  IF I_ND IS NULL THEN

    SELECT TO_CHAR(SYSDATE, 'YYYY') INTO V_ND FROM DUAL;

  END IF;

  IF I_LX IS NULL THEN

    V_LX := 1 ;

  END IF;

  --SELECT YYB,KHH,RQ,SUM(CPSR) AS SR  FROM SRC_PIF.TCPSXSR_R WHERE LX IN(3,4,5,6,7) GROUP BY YYB,KHH,RQ ;
  --SELECT YYB,KHH,RQ,SUM(ZZC) AS ZC FROM SRC_PIF.T_STAT_KHH_R GROUP BY YYB,KHH,RQ ;

  --分公司明细
  --TPIF_FGSMX
  --1）计算创收
  MERGE INTO TPIF_FGSMX M
  USING (SELECT A.TDMC AS TDMC, A.FGS AS FGS, B.YYB AS YYB, B.SR AS SMCPCS
           FROM PIF.TPIF_TDYFGSGLB A,
                (SELECT (SELECT FID
                           FROM LIVEBOS.LBORGANIZATION
                          WHERE BRANCH_ID = YYB) AS FGS,
                        (SELECT ID
                           FROM LIVEBOS.LBORGANIZATION
                          WHERE BRANCH_ID = YYB) AS YYB,
                       -- KHH,
                        RQ,
                        SUM(CPSR) AS SR
                   FROM SRC_PIF.TCPSXSR_R
                  WHERE LX IN (3, 4, 5, 6, 7)
                    AND RQ >= I_ND || '0101'
                    AND RQ <= I_ND || '1231'
                  GROUP BY YYB, /*KHH,*/ RQ) B
          WHERE A.ZT = 1
            AND A.FGS = B.FGS) N
  ON (M.ND = V_ND AND M.TDMC = N.TDMC AND M.FGS = N.FGS AND M.YYB = N.YYB)
  WHEN MATCHED THEN
    UPDATE SET M.SMCPCS = N.SMCPCS
  WHEN NOT MATCHED THEN
    INSERT
      (ID, ND, TDMC, FGS, YYB, SMCPCS, SMCPGM)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_FGSMX'),
       V_ND,
       N.TDMC,
       N.FGS,
       N.YYB,
       N.SMCPCS,
       0);


  --2）计算规模 
  IF V_LX = 1 THEN    --1:根据期末资产计算

    MERGE INTO TPIF_FGSMX M
    USING (SELECT A.TDMC AS TDMC, A.FGS AS FGS, B.YYB AS YYB, B.ZC AS SMCPGM
             FROM PIF.TPIF_TDYFGSGLB A,
                  (SELECT (SELECT FID
                             FROM LIVEBOS.LBORGANIZATION
                            WHERE BRANCH_ID = YYB) AS FGS,
                          (SELECT ID
                             FROM LIVEBOS.LBORGANIZATION
                            WHERE BRANCH_ID = YYB) AS YYB,
                          RQ,
                          SUM(ZZC) AS ZC,
                          ROW_NUMBER() OVER(PARTITION BY YYB ORDER BY RQ DESC) AS PX
                     FROM SRC_PIF.T_STAT_KHH_R
                    WHERE RQ >= I_ND || '0101'
                      AND RQ <= I_ND || '1231'
                    GROUP BY YYB,RQ
                  ) B

            WHERE A.ZT = 1
              AND A.FGS = B.FGS
              AND B.PX = 1) N
    ON (M.ND = V_ND AND M.TDMC = N.TDMC AND M.FGS = N.FGS AND M.YYB = N.YYB)
    WHEN MATCHED THEN
      UPDATE SET M.SMCPGM = N.SMCPGM
    WHEN NOT MATCHED THEN
      INSERT
        (ID, ND, TDMC, FGS, YYB, SMCPCS, SMCPGM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_FGSMX'),
         V_ND,
         N.TDMC,
         N.FGS,
         N.YYB,
         0,
         N.SMCPGM);

  ELSE          -- 2：根据日均资产计算

    MERGE INTO TPIF_FGSMX M
    USING (SELECT A.TDMC AS TDMC, A.FGS AS FGS, B.YYB AS YYB, B.ZC AS SMCPGM
             FROM PIF.TPIF_TDYFGSGLB A,
                  (SELECT FGS,YYB,AVG(ZC) AS ZC
                    FROM ( SELECT (SELECT FID
                             FROM LIVEBOS.LBORGANIZATION
                                  WHERE BRANCH_ID = YYB) AS FGS,
                                (SELECT ID
                                   FROM LIVEBOS.LBORGANIZATION
                                  WHERE BRANCH_ID = YYB) AS YYB,
                                RQ,
                                SUM(ZZC) AS ZC,
                                ROW_NUMBER() OVER(PARTITION BY YYB ORDER BY RQ DESC) AS PX
                           FROM SRC_PIF.T_STAT_KHH_R
                          WHERE RQ >= I_ND || '0101'
                            AND RQ <= I_ND || '1231'
                          GROUP BY YYB,RQ)
                    GROUP BY  FGS,YYB
                  ) B

            WHERE A.ZT = 1
              AND A.FGS = B.FGS) N
    ON (M.ND = V_ND AND M.TDMC = N.TDMC AND M.FGS = N.FGS AND M.YYB = N.YYB)
    WHEN MATCHED THEN
      UPDATE SET M.SMCPGM = N.SMCPGM
    WHEN NOT MATCHED THEN
      INSERT
        (ID, ND, TDMC, FGS, YYB, SMCPCS, SMCPGM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_FGSMX'),
         V_ND,
         N.TDMC,
         N.FGS,
         N.YYB,
         0,
         N.SMCPGM);

  END IF;


  --团队任务完成进度
  --TPIF_TDRWWCJD
  SELECT COUNT(*) INTO V_COUNT FROM TPIF_TDRWWCJD WHERE ND = V_ND;
  IF V_COUNT > 0 THEN

    DELETE FROM TPIF_TDRWWCJD WHERE ND = V_ND;

  END IF;

  --使用序列：SEQ_TPIF_TDRWWCJD

  --1)先插入目标值
  INSERT INTO TPIF_TDRWWCJD
    (ID,
     ND,
     TDMC,
     FGS,
     SMCPCSWCE,
    -- SMCPCSMBZ,
    -- SMCPCSWCBL,
     SMCPGMWCE
     --  SMCPGMMBZ,
    -- SMCPGMWCBL
    )
    SELECT SEQ_TPIF_TDRWWCJD.NEXTVAL,
           V_ND,
           A.TDMC,
           A.FGS,
           0,
         --  A.KHMBZ,
           0
         --  0,
          -- B.KHMBZ,
          -- 0
      FROM (SELECT ND, TDMC, FGS, KHMBZ
              FROM TPIF_FGSKH A
             WHERE A.ND = V_ND
               AND KHLX = 1) A, --考核类型：1|私募产品创收;2|私募产品规模
           (SELECT ND, TDMC, FGS, KHMBZ
              FROM TPIF_FGSKH A
             WHERE A.ND = V_ND
               AND KHLX = 2) B --1|私募产品创收;2|私募产品规模
     WHERE A.TDMC = B.TDMC
       AND A.FGS = B.FGS;

  --2)再更新实际值
  MERGE INTO TPIF_TDRWWCJD M
  USING (SELECT TDMC,
                FGS,
                SUM(SMCPCS) AS SMCPCSWCE,
                SUM(SMCPGM) AS SMCPGMWCE
           FROM TPIF_FGSMX
          WHERE ND = V_ND
          GROUP BY TDMC, FGS) N
  ON (M.TDMC = N.TDMC AND M.FGS = N.FGS)
  WHEN MATCHED THEN
    UPDATE
       SET M.SMCPCSWCE  = N.SMCPCSWCE,
           M.SMCPGMWCE  = N.SMCPGMWCE;
          -- M.SMCPCSWCBL = 100*LEAST(1, N.SMCPCSWCE / M.SMCPCSMBZ),
          -- M.SMCPGMWCBL = 100*LEAST(1, N.SMCPGMWCE / M.SMCPGMMBZ);

  COMMIT;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
    ROLLBACK;
END;
/

