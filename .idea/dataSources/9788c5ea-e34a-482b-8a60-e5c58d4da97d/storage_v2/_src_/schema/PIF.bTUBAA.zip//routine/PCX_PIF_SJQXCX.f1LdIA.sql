create PROCEDURE PCX_PIF_SJQXCX(
                                O_CODE OUT NUMBER,
                                O_NOTE OUT VARCHAR2,
                                O_RESULT OUT SYS_REFCURSOR,
                                I_UID  IN NUMBER
)as
/*-------------------------------------------------------------------
项目名称：机构CRM
      所属用户：PIF
      运行原理：
               输入用户id，返回用户数据权限部门及下属部门
      修订记录：
               修订日期       版本号    修订人             修改内容简要说明
               20200325     1.0.0     xsm               新增
---------------------------------------------------------------------*/
  v_sql    VARCHAR2(32767);
begin
  --INIT
  O_CODE:=1;
  O_NOTE:='成功';

if i_uid is not null then

v_sql :=
                   ' SELECT ID FROM LIVEBOS.LBORGANIZATION  START WITH ID IN (SELECT CASE WHEN SCOPEEXP = ''<ALL>'' THEN ''1'' ELSE SCOPEEXP END
                               FROM LIVEBOS.LBDATASCOPEAUTH
                              WHERE MEMBERID IN
                                    (select ROLEID from LIVEBOS.LBMEMBER WHERE USERID = ' || i_uid || ')
                                AND TYPE = 1
                                AND SCOPENAME = ''YYB''
                             UNION ALL
                             SELECT CASE WHEN SCOPEEXP = ''<ALL>'' THEN ''1'' ELSE SCOPEEXP END
                               FROM LIVEBOS.LBDATASCOPEAUTH
                              WHERE MEMBERID = ' || i_uid || '
                                AND TYPE = 0
                                AND SCOPENAME = ''YYB'') CONNECT BY PRIOR  ID=FID';
            end if;

  OPEN O_RESULT FOR V_SQL;


  EXCEPTION
    WHEN OTHERS THEN
        o_code   := -1;
        o_note   := '查询失败';

end PCX_PIF_SJQXCX;
/

