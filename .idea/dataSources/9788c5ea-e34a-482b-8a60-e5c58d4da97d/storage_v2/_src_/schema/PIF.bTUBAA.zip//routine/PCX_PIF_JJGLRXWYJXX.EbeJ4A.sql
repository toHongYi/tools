create PROCEDURE PCX_PIF_JJGLRXWYJXX(O_RESULT OUT SYS_REFCURSOR, --返回的数据集合,不一定会有，但通常用于返回结果集合。
                                             I_KSRQ   IN NUMBER, --开始日期
                                             I_JSRQ   IN NUMBER, --结束日期
                                             I_JJXX   IN VARCHAR2,
                                             I_GSMC   IN VARCHAR2)

 IS
  /*
  过程名称：基金管理人新闻预警信息查询

  20181030   zhangchongzheng      新增
  */
  V_SQL VARCHAR2(28000);
  --V_RQC    VARCHAR2(500);

BEGIN

    V_SQL := 'SELECT XWDM    "新闻代码",
                     XWBT    "新闻标题",
                     YJ.GSDM "公司代码",
                     YJ.GSQC "公司全称",
                     FBSJ    "发布时间"
                FROM TPIF_JJ_GLRXWYJXX YJ
               INNER JOIN (SELECT DISTINCT GLRGSDM FROM TPIF_SCYQ_JJXXB) JJ
                  ON (YJ.GSDM = JJ.GLRGSDM)
              WHERE TO_CHAR(YJ.FBSJ,''YYYYMMDD'') BETWEEN ' ||
             I_KSRQ || ' AND ' || I_JSRQ;

  --债券信息
  IF I_JJXX IS NOT NULL THEN
    V_SQL := V_SQL ||
             ' AND YJ.GSDM IN (SELECT DISTINCT GLRGSDM FROM TPIF_SCYQ_JJXXB WHERE JJDM LIKE ''%' ||
             I_JJXX || '%'' OR JJMC LIKE ''%' || I_JJXX || '%'')';
  END IF;

  -- 公司名称
  IF I_GSMC IS NOT NULL THEN
    V_SQL := V_SQL || ' AND YJ.GSQC LIKE ''%' || I_GSMC || '%''';
  END IF;

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    OPEN O_RESULT FOR
      SELECT -1, '查询失败！' FROM DUAL;
END;
/

