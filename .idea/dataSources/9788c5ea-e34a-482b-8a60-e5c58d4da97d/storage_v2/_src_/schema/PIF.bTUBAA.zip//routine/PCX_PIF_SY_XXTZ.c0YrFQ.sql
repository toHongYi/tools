create PROCEDURE PCX_PIF_SY_XXTZ(O_CODE     OUT NUMBER,
                                            O_NOTE     OUT VARCHAR2,
                                            O_RESULT   OUT SYS_REFCURSOR,
                                            i_current  IN Number, --页码   
                                            i_pageSize IN Number, --页长 
                                            i_paging   IN Number, --是否分页 
                                            i_sort     IN String, --排序规模 
                                            i_total    IN OUT Number, --记录总数                                             
                                            i_userid   IN INTEGER, --用户ID
                                            i_type     IN String	--类别 1：查询全部  2：运营任务 3：流程提醒 4：风控事件

                                            ) IS

  /* -----------------------------------------------------------------------
  项目名称：   产品中心
  概要说明：查询员工消息提醒
                 I_USERID          IN NUMBER,--TUSER.ID
  语法信息：
       输出参数：
         成功返回员工消息提醒信息，失败返回 原因
  
  数据准备：
      1)CRMII.Lbnotification (消息通知)
      2)CRMII.Lbnotificationuser(消息通知从表)
      3)CRMII.tuser(用户)
  
  运行原理：
      ID,标题,内容,时间,类型,相关客户
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
   -----------------------------------------------------------------------*/
  V_SQL          VARCHAR2(32767);
  V_SQL2         VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  v_HASRECORDSET number;
BEGIN
  --否则返回结果集合
  v_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF i_total IS NULL THEN
    i_total := -1;
  END IF;
  V_SORT := I_SORT;


  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '用户ID不能为空!';
    RETURN;
  END IF;
  
  IF I_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_TYPE不能为空!';
    RETURN;
  END IF;
  
  --排除 Workflow 
  V_SQL := 'SELECT B.ID ID,
                     ''【''||DECODE(A.TYPE,''Workflow'',''流程提醒'',''TPIF_CPYYRW'',''产品事件'',''TPIF_FKSJTX'',''风控事件'')||''】 ''||
                     (SELECT NAME FROM livebos.TUSER WHERE ID = A.SENDUSER)||'' ''||A.CONTENT   msg_desc,
                     SUBSTR(A.SENDTIME,1,10) occur_time,
                     B.ISREAD   is_read,
                     A.TYPE ,
                     DECODE(A.TYPE,''Workflow'',''流程提醒'',''TPIF_CPYYRW'',''产品事件'',''TPIF_FKSJTX'',''风控事件'') AS TYPE_DESC ,
                     A.ID AS  notification_id,
                     (case when A.TYPE=''TPIF_CPYYRW'' then ''/plug-in/bss/images/xxlx/rw.png''
                          when A.TYPE=''Workflow'' then ''/UIProcessor?Table=WORKFLOW_TOTASK''  
                          when A.TYPE=''TPIF_FKSJTX'' then ''/UIProcessor?Table=vPIF_SJJHJG'' 
                      end ) url
                    FROM livebos.LBNOTIFICATION A, livebos.LBNOTIFICATIONUSER B
                   WHERE A.ID = B.NOTIFICATIONID
                     --AND A.TYPE IN (''TPIF_CPYYRW'',''Workflow'',''TPIF_FKSJTX'')
                     AND A.TYPE IN (''TPIF_CPYYRW'',''TPIF_FKSJTX'')
                     AND B.ISREAD = 0';
  IF I_USERID <> 0 THEN
    --管理员不过滤数据
    V_SQL := V_SQL || ' AND B.USERID=' || I_USERID;
  END IF;
                     
                     
                     
   --Workflow 单独处理
  V_SQL2 := ' SELECT T.ID,
                     ''【流程提醒】''||A.SUBJECT  AS MSG_DESC , 
                     TO_CHAR(A.INIT_DATE,''YYYY/MM/DD HH24:MI:SS'')  AS occur_time, 
                     0 is_read,
                     ''Workflow'' AS TYPE,
                     ''流程提醒'' AS TYPE_DESC ,
                     T.ID AS notification_id,
                     ''/UIProcessor?Creator=workflow&''||''Table=''||(SELECT NAME FROM LIVEBOS.OS_WFENTRY WHERE ID = ENTRY_ID)||''&''||''StepID=''||T.STEP_ID|| ''&''||''WorkID=''||T.ENTRY_ID  as url 
             FROM  LIVEBOS.OS_CURRENTSTEP T,LIVEBOS.OS_WFENTRY A 
             WHERE T.ENTRY_ID=A.ID AND INSTR('',''||T.OWNER||'','','',''||' || I_USERID || '||'','') > 0';


  V_SQL := 'SELECT * FROM ('|| V_SQL ||' UNION ALL '||V_SQL2||')';

  
  
  IF I_TYPE <> '1' THEN
    V_SQL := V_SQL || ' WHERE TYPE= DECODE('||I_TYPE||',2,''Workflow'',3,''TPIF_CPYYRW'',4,''TPIF_FKSJTX'')';
  END IF;
  


  IF V_SORT IS NULL THEN
    V_SORT := 'occur_time DESC,notification_id DESC';
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  V_COLLIST := 'ID,msg_desc,occur_time,is_read,type,type_desc,notification_id,url';

  PCX_TYCX(O_CODE,
           O_NOTE,
           v_HASRECORDSET,
           O_RESULT,
           i_paging,
           i_current,
           i_pageSize,
           i_total,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

