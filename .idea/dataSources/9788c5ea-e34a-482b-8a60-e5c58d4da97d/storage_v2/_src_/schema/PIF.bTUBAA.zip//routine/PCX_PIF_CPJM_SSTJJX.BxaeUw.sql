create PROCEDURE PCX_PIF_CPJM_SSTJJX(O_CODE   OUT NUMBER,
                                                O_NOTE   OUT VARCHAR2,
                                                O_RESULT OUT SYS_REFCURSOR,
                                                i_PROD_TYPE IN VARCHAR2, --产品分类ID
                                                I_template_id   IN NUMBER --模版ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品视图-搜索条件解析
  所属用户：PIF
  概要说明：查询当前登录人产品查询条件解析.
               i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                               并不是什么是否都需要分页,看情形而言.
               i_PageNo      --页码
               i_PageLength  --页长
               i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               i_Sort        --排序字段
               i_PROD_TYPE       IN NUMBER, --产品分类ID
               I_template_id         IN NUMBER  --模版ID
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
      PIF.TFP_CPLX 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询搜索条件的解析.
  
        1.查询搜索条件的解析,供前端查询展示.
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/10/29     4.0.0.1   guonanhua           新增.
  *********************************************************************************************************************/
  V_SQL       VARCHAR2(32767);
  V_SQL_QUERY VARCHAR2(32767);
 
 
  V_ERRMSG    VARCHAR2(300); --错误信息
  V_TYPE      NUMBER(12);
  V1_TYMB     NUMBER(16);
  V1_ID       NUMBER(16);
  V1_XSMC     VARCHAR2(300); --显示名称
  V1_XSSX     NUMBER(12); --显示顺序
  V1_SXLX     NUMBER(12); --属性类型
  V1_YWDX     VARCHAR2(120); --业务对象
  V1_CPSX     VARCHAR2(1024); --产品属性
  V1_TJQJZB   NUMBER(16); --条件 区间指标
  V1_XSMS     NUMBER(12); --显示模式
  V1_MS       VARCHAR2(2000);
  V1_IDBZ     VARCHAR2(2000);
  V_CPSX      VARCHAR2(1024); --产品属性
  V1_SSTJ     VARCHAR2(1000);
  V_REFCODE   VARCHAR2(2000); --关联对象名称/字典的FLDM
  V_TJXXMS    VARCHAR2(32767); --条件选项描述
  V_TABLENAME VARCHAR2(120);
  V_COUNT     NUMBER(16);
  V_FROMTABLE VARCHAR2(500); --数据源表
  V_SQL_HFXJY VARCHAR2(5000); --合法性验证
  V_QUERYCOL  VARCHAR2(32767); --查询字段
  TYPE TYPE_CUR IS REF CURSOR;
  V_SXTJFZ    number(16);   --筛选条件分组
  V_SXTJFZ_MC varchar2(200); --筛选条件分组名称
  CURSOR_COL TYPE_CUR;
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_template_id IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【模版ID】';
    RETURN;
  END IF;

  --数据源赋值
  IF i_PROD_TYPE IS NULL THEN
    V_FROMTABLE := ' TPIF_TYMBSSPZ T  WHERE T.TYMB = ' || I_template_id ||
                   '  AND T.ZT = 1';
  
  ELSE
    V_FROMTABLE := ' PIF.TPIF_FLMBSSPZ T, PIF.TPIF_FLMBDY H WHERE T.FLMB = H.ID AND T.FLMB = ' || I_template_id || ' AND T.ZT = 1 AND H.MBZT = 1 ';
                   --AND exists( select 1 from table(split(''' || I_PROD_TYPE || ''','';''))  where instr('';''||CPDL||'';'','';''||column_value||'';'')>0 ) ';
  END IF;
  --验证是否存在适用于当前登录人的通用模版
  V_SQL_HFXJY := ' SELECT COUNT(1) FROM ' || V_FROMTABLE;
  EXECUTE IMMEDIATE V_SQL_HFXJY
    INTO V_COUNT;
  IF V_COUNT = 0 THEN
    O_CODE := -2;
    O_NOTE := '错误：没有此条件模版！';
    RETURN;
  END IF;
  --将结果插入到临时表里
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA_BIG';
  -- 根据配置得到通用模版查询字段
  IF i_PROD_TYPE IS NULL THEN
    V_QUERYCOL := 'SELECT T.TYMB, T.ID, T.XSMC, T.XSSX, T.SXLX, T.YWDX, T.CPSX,T.TJQJZB, T.XSMS, T.MS, T.SSTJ, T.IDBZ,T.SXTJFZ  FROM ' ||
                  V_FROMTABLE;
  ELSE
    V_QUERYCOL := 'SELECT T.FLMB, T.ID, T.XSMC, T.XSSX, T.SXLX, T.YWDX, T.CPSX,T.TJQJZB, T.XSMS, T.MS, T.SSTJ, T.IDBZ,T.SXTJFZ  FROM ' ||
                  V_FROMTABLE;
  END IF;
  OPEN CURSOR_COL FOR V_QUERYCOL;
  LOOP
    EXIT WHEN CURSOR_COL%NOTFOUND;
    FETCH CURSOR_COL
      INTO V1_TYMB,
           V1_ID,
           V1_XSMC,
           V1_XSSX,
           V1_SXLX,
           V1_YWDX,
           V1_CPSX,
           V1_TJQJZB,
           V1_XSMS,
           V1_MS,
           V1_SSTJ,
           V1_IDBZ,
           V_SXTJFZ;
    IF CURSOR_COL%FOUND THEN
      IF V1_SXLX = 1 THEN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM PIF.TPIF_FIELD T1
         WHERE tablename = V1_YWDX
           AND INSTR(';' || V1_CPSX || ';', T1.ID) > 0
           AND V1_XSMS <> 1; --add:排除文本输入的模式
        IF V_COUNT >= 1 THEN
          SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME
            INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME
            FROM PIF.TPIF_FIELD T1
           WHERE T1.tablename = V1_YWDX
             AND T1.ID = V1_CPSX;
          --内部对象
          IF V_TYPE IN (6, 16) THEN
            V_SQL := 'SELECT  ''[''||WM_CONCAT( ''{"id":"''||' || V1_IDBZ ||
                     '|| ''","value":"''|| ' || V1_MS || '|| ''"}'' )||'']''  FROM ' ||
                     V_REFCODE;
                     
                     
                     --临时加入，避免管理人报错
                  IF   V_REFCODE LIKE'%TPIF_JGDM%' THEN
                    V1_SSTJ:=V1_SSTJ||' rownum <50 ';
                    END IF;
                    
                  IF   V_REFCODE LIKE'%TPIF_JRCPFL%' THEN
                    V1_SSTJ:=V1_SSTJ||' rownum <50 ';
                    END IF;
                     
            IF TRIM(V1_SSTJ) IS NOT NULL THEN
              V_SQL := V_SQL || ' WHERE ' || V1_SSTJ;
            END IF;
            
             dbms_output.put_line('V_SQL1:'||V_SQL);   
            EXECUTE IMMEDIATE V_SQL
              INTO V_TJXXMS;
              
              dbms_output.put_line('V_SQL1:'||V_SQL);
              
            --字典型
          ELSIF V_TYPE IN (7, 15) THEN
            V_SQL := 'SELECT ''[''||WM_CONCAT( ''{"id":"''|| IBM || ''","value":"'' || NOTE ||''"}'' )||'']'' 
                                    FROM (SELECT * FROM LIvebos.TXTDM T WHERE T.FLDM = ''' ||
                     V_REFCODE || '''';
            IF TRIM(V1_SSTJ) IS NOT NULL THEN
              V_SQL := V_SQL || ' AND ' || V1_SSTJ;
            END IF;
            V_SQL := V_SQL || ' ORDER BY T.IBM ASC )';
            EXECUTE IMMEDIATE V_SQL
              INTO V_TJXXMS;           
              
             dbms_output.put_line('V_SQL1:'||V_SQL);
              
          ELSE
            V_TJXXMS := '';
          END IF;
        ELSE
          V_TJXXMS := '';
        END IF;
      ELSIF V1_SXLX = 2 THEN
        V_SQL := ' SELECT  ''[''||WM_CONCAT( ''{"id":"''|| QJID || ''","value":"'' || MS ||''"}'' )||'']''
                   FROM(SELECT T1.ID ZBID, T1.ZBMC,T2.ID QJID, T1.ZBDM, T2.MS
                          FROM TPIF_MBTJZB T1, TPIF_MBTJZBQJ T2
                         WHERE T1.ID = T2.GJZB
                           AND T1.ID = ' || V1_TJQJZB;
        IF TRIM(V1_SSTJ) IS NOT NULL THEN
          V_SQL := V_SQL || ' AND ' || V1_SSTJ;
        END IF;
        V_SQL := V_SQL || ' ORDER BY T2.XX ASC)';
        EXECUTE IMMEDIATE V_SQL
          INTO V_TJXXMS;
         
      --   dbms_output.put_line('V_SQL2:'||V_SQL);
          
          
      ELSIF V1_SXLX = 3 THEN
        V_SQL := ' SELECT  ''[''||WM_CONCAT( ''{''|| JHID || ''='' || MC ||''}'' )||'']''
                   FROM (SELECT ID JHID, COLLECTION_NAME as MC
                         FROM PIF.tPROD_COLLECTION 
                         WHERE 1=1 ';
        IF TRIM(V1_SSTJ) IS NOT NULL THEN
          V_SQL := V_SQL || ' AND ' || V1_SSTJ;
        END IF;
        V_SQL := V_SQL || ' ORDER BY ID ASC)';
        EXECUTE IMMEDIATE V_SQL
          INTO V_TJXXMS;
          
          --    dbms_output.put_line('V_SQL3:'||V_SQL);
          
      END IF;
      --获取分组名称
      begin
      select note  into V_SXTJFZ_MC from livebos.txtdm a where a.fldm = 'PIF_SXTJFZ' and ibm = V_SXTJFZ;
      exception when others then
        V_SXTJFZ_MC := '';
      end;      
      INSERT INTO TEMPDATA_BIG
        (N1, N2, C1, C2, N3,N4,C3)
        SELECT V1_XSSX, V1_ID, V1_XSMC, V_TJXXMS, V1_XSMS,V_SXTJFZ,V_SXTJFZ_MC FROM DUAL;
    END IF;
  END LOOP;
  CLOSE CURSOR_COL;
  

/*  
  V_SQL_QUERY := ' SELECT TRUNC(N1) AS display_order, 
                          TRUNC(N2) AS condition_id, 
                          C1 AS display_name, 
                          C2 AS option_desc, 
                          TRUNC(N3) AS display_mode ,
                          TRUNC(N4) AS group_id,
                          C3 as group_name
                    FROM TEMPDATA_BIG ORDER BY TRUNC(N1) ';*/
V_SQL_QUERY := ' SELECT TRUNC(N1) AS display_order, 
                          TRUNC(N2) AS condition_id, 
                          C1 AS display_name, 
                          C2 AS option_desc, 
                          TRUNC(N3) AS display_mode ,
                          TRUNC(N4) AS group_id,
                          C3 as group_name,
                        ( CASE WHEN   TRUNC(N2) =10 THEN' ||'''PIF.TPIF_JGDM'''||' 
                               WHEN   TRUNC(N2) =202 THEN' ||'''PIF.TPIF_JRCPFL_GM'''||' 
                               WHEN   TRUNC(N2) =203 THEN' ||'''PIF.TPIF_JRCPFL_SMTZJJ'''||' 
                               WHEN   TRUNC(N2) =204 THEN' ||'''PIF.TPIF_JRCPFL_SMZGJH'''||' 
                               WHEN   TRUNC(N2) =205 THEN' ||'''PIF.TPIF_JRCPFL_XTJH'''||' 
                               WHEN   TRUNC(N2) =206 THEN' ||'''PIF.TPIF_JRCPFL_YHLC'''||' 
                               WHEN   TRUNC(N2) =207 THEN' ||'''PIF.TPIF_JRCPFL_SYPZ'''||'   
                              ELSE NULL END) AS objectName
                    FROM TEMPDATA_BIG ORDER BY TRUNC(N1) ';     
                    
  OPEN O_RESULT FOR V_SQL_QUERY;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := ' 查询失败 ';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT ' 异常信息： ' || V_ERRMSG FROM DUAL;
END PCX_PIF_CPJM_SSTJJX;
/

