create PROCEDURE PRO_SJQX_CPJZ(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2 --返回消息
                                          ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品净值 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      RZF的含义要根据净值披露频率来看，
      对于公募，一天一公布，则是 日涨幅
      对于私募，因为公布频率不定，可以理解为较上期涨幅
  
      计算公式：
               (本期累计净值-上期累计净值)/上期单位净值
  
      例如：
            2021.7.23的公募RZF，等于 (7.23的累计净值-7.22的累计净值)/7.22的单位净值
  
      修订记录：
          修订日期       版本号      修订人                 修改内容简要说明
          2021-7-9       1.0.0    GAOKUN\HANQIAONAN             创建
          2021-7-23      1.0.1    GAOKUN\HANQIAONAN         RZF计算公式修改
  ***********************************************************************/
  V_COUNT      NUMBER;
  V_COUNT_LAST NUMBER;
  V_COUNT_NEXT NUMBER;
  V_JYRQ       NUMBER;
  V_JZRQ       NUMBER;
  V_DWJZ       NUMBER(16, 4);
  V_LJJZ       NUMBER(16, 4);
  V_YCXX       VARCHAR2(200); --异常信息
  V_JZYC       INTEGER := 0; --净值异常  0|无异常,1|单位净值不同,2|累计净值不同,3|都不同
  V_ZDFYC      INTEGER; --涨跌幅异常  0|无异常,1|异常
  V_ZJJGID     INTEGER; --质检结果ID
  V_ZDF        NUMBER(16, 6); --涨跌幅
  V_RZF        NUMBER(16, 6); --涨跌幅
  V_YJYRQ      NUMBER; --有效交易日期
  V_YJZRQ      NUMBER; --有效净值日期

  V_SQLJJZ NUMBER; --上期累计净值
  V_SQDWJZ NUMBER; --上期单位净值
  V_SQFQJZ NUMBER; --上期复权净值
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --判断中间表是否有数据，无数据报错
  SELECT COUNT(1) INTO V_COUNT FROM PIF.TMP_PRODPRICE;
  IF V_COUNT = 0 THEN
    O_NOTE := '没有净值数据，请检查！';
    RETURN;
  END IF;

  --该部分产品不用质检，直接插入到产品净值表
  FOR CUR_CP IN (SELECT B.PROD_CODE, B.PRODTA_NO，A.CPID
                   FROM SRC_PIF.DWD_PRD_PRODCODE_DD B, PIF.TPIF_CPDM A
                  WHERE TRIM(B.PROD_CODE) IS NOT NULL
                    AND TRIM(B.PRODCODE_TYPE) IS NOT NULL
                    AND TRIM(B.PROD_CODE) = TRIM(A.CPDM)
                    AND A.CPXL = 5 --银行理财
                    AND A.CPNBZT >= 0 --去掉已删除和已下架产品
                 ) LOOP
    --1.更新TPIF_CPJZ
    BEGIN
      --查出来TMP表该产品的JYRQ，用于判断TPIF_CPJZ表是否已存在该JYRQ的记录
      SELECT M.INIT_DATE
        INTO V_JYRQ
        FROM PIF.TMP_PRODPRICE M
       WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
         AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO);
    EXCEPTION
      WHEN OTHERS THEN
        V_JYRQ := -1;
    END;
  
    IF V_JYRQ = -1 THEN
      --如果TMP表没有该产品净值记录，直接进入下一次循环
      CONTINUE;
    ELSE
      --判断TPIF_CPJZ表有没有该产品这一天JYRQ的记录
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZ
       WHERE CPID = CUR_CP.CPID
         AND JYRQ = V_JYRQ;
    
      IF V_COUNT > 0 THEN
        --如果已经有了，不需要再新增了
        NULL;
      ELSE
        --如果没有，向TPIF_CPJZ表插入最新一个交易日期的数据
        --取TPIF_CPJZ表中该产品最新一期的累计净值，单位净值,用于计算RZF
        BEGIN
          SELECT LJJZ, DWJZ
            INTO V_SQLJJZ, V_SQDWJZ
            FROM TPIF_CPJZ
           WHERE CPID = CUR_CP.CPID
             AND JYRQ =
                 (SELECT MAX(JYRQ) FROM TPIF_CPJZ WHERE CPID = CUR_CP.CPID);
        EXCEPTION
          WHEN OTHERS THEN
            V_SQLJJZ := 0;
            V_SQDWJZ := 0;
        END;
      
        INSERT INTO TPIF_CPJZ
          (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM, RZF)
          SELECT SEQ_TPIF_CPJZ.NEXTVAL,
                 CUR_CP.CPID,
                 TO_NUMBER(TRIM(INIT_DATE)),
                 TO_NUMBER(TRIM(NAV_DATE)),
                 TO_NUMBER(TRIM(NET_VALUE)),
                 TO_NUMBER(TRIM(NAV_TOTAL)),
                 5, --数据来源 5柜台
                 1, --确认状态 1有效
                 CUR_CP.PROD_CODE,
                 ROUND((CASE
                         WHEN V_SQDWJZ = 0 THEN
                          0
                         ELSE
                          (TO_NUMBER(TRIM(NAV_TOTAL)) - V_SQLJJZ) / V_SQDWJZ
                       END),
                       6)
            FROM (SELECT DISTINCT M.INIT_DATE,
                                  M.NAV_DATE,
                                  M.NET_VALUE,
                                  M.NAV_TOTAL
                    FROM PIF.TMP_PRODPRICE M
                   WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
                     AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO)
                   ORDER BY M.NAV_DATE);
      END IF;
    END IF;
  
    --2.更新TPIF_CPJZXX_CPZX
    --取净值日期和交易日期，用于判断是否需要新增或修改TPIF_CPJZXX_CPZX表
    BEGIN
      SELECT M.NAV_DATE, M.INIT_DATE
        INTO V_JZRQ, V_JYRQ
        FROM PIF.TMP_PRODPRICE M
       WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
         AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO);
    EXCEPTION
      WHEN OTHERS THEN
        V_JZRQ := -1;
        V_JYRQ := -1;
    END;
    --如果TMP表没有这个产品的净值，直接进入下次循环
    IF V_JZRQ = -1 AND V_JYRQ = -1 THEN
      CONTINUE;
    ELSE
      --如果有，则判断是否需要新增或更新
      --取CPJZXX表的最新一期单位净值、累计净值、复权净值，用于计算RZF和复权净值
      BEGIN
        SELECT LJJZ, DWJZ, FQJZ
          INTO V_SQLJJZ, V_SQDWJZ, V_SQFQJZ
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = CUR_CP.CPID
           AND JZRQ = (SELECT MAX(JZRQ)
                         FROM TPIF_CPJZXX_CPZX
                        WHERE CPID = CUR_CP.CPID);
      EXCEPTION
        WHEN OTHERS THEN
          V_SQLJJZ := 0;
          V_SQDWJZ := 0;
          V_SQFQJZ := 0;
      END;
    
      --判断TPIF_CPJZXX_CPZX是否有净值记录
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = CUR_CP.CPID
         AND JZRQ = V_JZRQ;
      IF V_COUNT > 0 THEN
        --有这个净值日期
        SELECT COUNT(1) --判断交易日期大小
          INTO V_COUNT
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = CUR_CP.CPID
           AND JZRQ = V_JZRQ
           AND JYRQ >= V_JYRQ;
        IF V_COUNT > 0 THEN
          --TPIF_CPJZXX_CPZX表的JYRQ大，则不用更新
          NULL;
        ELSE
          --否则，更新交易日期
          UPDATE TPIF_CPJZXX_CPZX
             SET JYRQ = V_JYRQ
           WHERE CPID = CUR_CP.CPID
             AND JZRQ = V_JZRQ;
        END IF;
      ELSE
        --如果没有这个净值日期，则插入
        INSERT INTO TPIF_CPJZXX_CPZX
          (CPID, JYRQ, JZRQ, DWJZ, LJJZ, CPDM, RZF)
          SELECT CUR_CP.CPID,
                 TO_NUMBER(TRIM(INIT_DATE)),
                 TO_NUMBER(TRIM(NAV_DATE)),
                 TO_NUMBER(TRIM(NET_VALUE)),
                 TO_NUMBER(TRIM(NAV_TOTAL)),
                 CUR_CP.PROD_CODE,
                 ROUND((CASE
                         WHEN V_SQDWJZ = 0 THEN
                          0
                         ELSE
                          (TO_NUMBER(TRIM(NAV_TOTAL)) - V_SQLJJZ) / V_SQDWJZ
                       END),
                       6)
            FROM (SELECT DISTINCT M.INIT_DATE,
                                  M.NAV_DATE,
                                  M.NET_VALUE,
                                  M.NAV_TOTAL
                    FROM PIF.TMP_PRODPRICE M
                   WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
                     AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO)
                     AND M.NAV_TOTAL != 0
                     AND M.NET_VALUE != 0
                   ORDER BY M.NAV_DATE);
      
        --更新复权净值
        --取上期净值没取到进入EXCEPTION，则说明净值表没该产品净值，此处新增的净值为第一条
        IF V_SQFQJZ = 0 THEN
          UPDATE TPIF_CPJZXX_CPZX A
             SET A.FQJZ = ROUND(A.DWJZ * (A.LJJZ - A.DWJZ + 1), 4)
           WHERE A.CPID = CUR_CP.CPID
             AND A.JZRQ = V_JZRQ;
          --上期复权净值有值
        ELSE
          UPDATE TPIF_CPJZXX_CPZX A
             SET A.FQJZ = ROUND((A.RZF + 1) * V_SQFQJZ, 4)
           WHERE A.CPID = CUR_CP.CPID
             AND A.JZRQ = V_JZRQ;
        END IF;
      END IF;
    END IF;
  END LOOP;

  --权益类的私募产品进行质检
  FOR CUR_CP IN (SELECT B.PROD_CODE, B.PRODTA_NO，A.CPID
                   FROM SRC_PIF.DWD_PRD_PRODCODE_DD B, PIF.TPIF_CPDM A
                  WHERE TRIM(B.PROD_CODE) IS NOT NULL
                    AND TRIM(B.PRODCODE_TYPE) IS NOT NULL
                    AND TRIM(B.PROD_CODE) = TRIM(A.CPDM)
                    AND A.CPXL IN (2, 3, 8) --私募投资基金、私募资管计划、信托计划
                    AND A.CPNBZT >= 0 --去掉已删除和已下架产品
                 ) LOOP
  
    --对每个产品循环
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_JZZJ ';
  
    INSERT INTO TMP_JZZJ
      (CPID, CPDM, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, ZJZT, SX)
      SELECT CUR_CP.CPID,
             CUR_CP.PROD_CODE,
             TO_NUMBER(TRIM(INIT_DATE)),
             TO_NUMBER(TRIM(NAV_DATE)),
             TO_NUMBER(TRIM(NET_VALUE)),
             TO_NUMBER(TRIM(NAV_TOTAL)),
             5, --数据来源 5柜台
             0, --质检状态，默认为0
             ROWNUM --顺序
        FROM (SELECT DISTINCT M.INIT_DATE,
                              M.NAV_DATE,
                              M.NET_VALUE,
                              M.NAV_TOTAL
                FROM PIF.TMP_PRODPRICE M
               WHERE TRIM(M.PROD_CODE) = TRIM(CUR_CP.PROD_CODE)
                 AND TRIM(M.PRODTA_NO) = TRIM(CUR_CP.PRODTA_NO)
               ORDER BY M.INIT_DATE);
  
    FOR CUR_JZ IN (SELECT * FROM TMP_JZZJ ORDER BY SX) LOOP
      --变量初始化
      V_JZYC  := 0;
      V_ZDFYC := 0;
      V_ZDF   := 0;
      V_RZF   := 0;
      V_YCXX  := '';
      --质检
      SELECT COUNT(1) INTO V_COUNT FROM TMP_JZZJ;
      IF V_COUNT = 0 THEN
        CONTINUE;
      END IF;
      --已存在异常明细则跳过
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_ZJJG_CPJZ_MX
       WHERE CPID = CUR_JZ.CPID
         AND JYRQ = CUR_JZ.JYRQ
         AND JZRQ = CUR_JZ.JZRQ
         AND DWJZ = CUR_JZ.DWJZ
         AND LJJZ = CUR_JZ.LJJZ;
      IF V_COUNT > 0 THEN
        CONTINUE;
      END IF;
      --存在相同净值跳过
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JYRQ = CUR_JZ.JYRQ
         AND JZRQ = CUR_JZ.JZRQ
         AND DWJZ = CUR_JZ.DWJZ
         AND LJJZ = CUR_JZ.LJJZ;
      IF V_COUNT > 0 THEN
        CONTINUE;
      END IF;
      --净值为0时进入净值异常
      IF CUR_JZ.DWJZ = 0 OR CUR_JZ.LJJZ = 0 THEN
        V_JZYC := 1;
        IF CUR_JZ.DWJZ = 0 THEN
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;
        IF CUR_JZ.LJJZ = 0 THEN
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_ZJJG_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ
           AND YCLB = 1;
        IF V_COUNT > 0 THEN
          --已存在同净值日期质检结果获取ID
          SELECT ID
            INTO V_ZJJGID
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
        ELSE
          SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
          --不存在则插入产品净值质检结果
          INSERT INTO TPIF_ZJJG_CPJZ
            (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
          VALUES
            (V_ZJJGID, CUR_JZ.CPID, CUR_JZ.CPDM, CUR_JZ.JZRQ, 0, 1, V_YCXX);
        END IF;
        --插入异常明细
        INSERT INTO TPIF_ZJJG_CPJZ_MX
          (ID,
           ZJJGID,
           CPID,
           CPDM,
           JYRQ,
           JZRQ,
           DWJZ,
           LJJZ,
           ZDF,
           CZR,
           ZT,
           CZSJ)
        VALUES
          (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
           V_ZJJGID,
           CUR_JZ.CPID,
           CUR_JZ.CPDM,
           CUR_JZ.JYRQ,
           CUR_JZ.JZRQ,
           CUR_JZ.DWJZ,
           CUR_JZ.LJJZ,
           NULL,
           0,
           0,
           SYSDATE);
        CONTINUE;
      END IF;
    
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = CUR_JZ.JZRQ;
    
      --判断同净值日期净值是否一致
      IF V_COUNT > 0 THEN
        --对比净值
        SELECT DWJZ, LJJZ, JYRQ, JZRQ
          INTO V_DWJZ, V_LJJZ, V_JYRQ, V_JZRQ
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ
           AND ROWNUM = 1;
        IF V_DWJZ != CUR_JZ.DWJZ THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;
      
        IF V_LJJZ != CUR_JZ.LJJZ THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;
      
        --存在净值异常插入质检结果表
        IF V_JZYC > 0 THEN
        
          --是否存在异常明细
          SELECT COUNT(1)
            INTO V_COUNT
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          IF V_COUNT > 0 THEN
            SELECT ID
              INTO V_ZJJGID
              FROM TPIF_ZJJG_CPJZ
             WHERE CPID = CUR_JZ.CPID
               AND JZRQ = CUR_JZ.JZRQ
               AND YCLB = 1;
            UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
          ELSE
            SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
            INSERT INTO TPIF_ZJJG_CPJZ
              (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
            VALUES
              (V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JZRQ,
               0,
               1,
               V_YCXX);
            --插入异常明细
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               V_JYRQ,
               V_JZRQ,
               V_DWJZ,
               V_LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
          END IF;
          CONTINUE;
        END IF;
      
      END IF;
      --是否存在上一个净值日期
      SELECT COUNT(1)
        INTO V_COUNT_LAST
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = (SELECT MAX(JZRQ)
                       FROM TPIF_CPJZ
                      WHERE CPID = CUR_JZ.CPID
                        AND JZRQ < CUR_JZ.JZRQ);
      IF V_COUNT_LAST > 0 THEN
        SELECT JZRQ, DWJZ, LJJZ, JYRQ
          INTO V_JZRQ, V_DWJZ, V_LJJZ, V_JYRQ
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = (SELECT MAX(JZRQ)
                         FROM TPIF_CPJZ
                        WHERE CPID = CUR_JZ.CPID
                          AND JZRQ < CUR_JZ.JZRQ)
           AND ROWNUM = 1;
      
        /*--相差交易日
        SELECT COUNT(1) INTO V_JYRS FROM LIVEBOS.TXTJYR
           WHERE JYR=ZRR
             AND JYR<CUR_JZ.JZRQ AND JYR>=V_JZRQ;
          V_ZDF := ROUND(CUR_JZ.LJJZ/V_LJJZ-1,4); */
      
        V_ZDF := ROUND((CUR_JZ.LJJZ - V_LJJZ) / V_DWJZ, 6);
        IF V_ZDF > 0.15 OR V_ZDF < -0.15 THEN
          --涨跌幅异常
          V_ZDFYC := 1;
          V_YCXX  := '涨跌幅异常';
          --获取质检结果ID
          SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
          --插入质检结果
          INSERT INTO TPIF_ZJJG_CPJZ
            (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
          VALUES
            (V_ZJJGID, CUR_JZ.CPID, CUR_JZ.CPDM, CUR_JZ.JZRQ, 0, 2, V_YCXX);
          --插入异常明细
          INSERT INTO TPIF_ZJJG_CPJZ_MX
            (ID,
             ZJJGID,
             CPID,
             CPDM,
             JYRQ,
             JZRQ,
             DWJZ,
             LJJZ,
             ZDF,
             CZR,
             ZT,
             CZSJ)
          VALUES
            (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
             V_ZJJGID,
             CUR_JZ.CPID,
             CUR_JZ.CPDM,
             CUR_JZ.JYRQ,
             CUR_JZ.JZRQ,
             CUR_JZ.DWJZ,
             CUR_JZ.LJJZ,
             V_ZDF,
             0,
             0,
             SYSDATE);
          INSERT INTO TPIF_ZJJG_CPJZ_MX
            (ID,
             ZJJGID,
             CPID,
             CPDM,
             JYRQ,
             JZRQ,
             DWJZ,
             LJJZ,
             ZDF,
             CZR,
             ZT,
             CZSJ)
          VALUES
            (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
             V_ZJJGID,
             CUR_JZ.CPID,
             CUR_JZ.CPDM,
             V_JYRQ,
             V_JZRQ,
             V_DWJZ,
             V_LJJZ,
             NULL,
             0,
             0,
             SYSDATE);
          CONTINUE;
        END IF;
      END IF;
      --是否存在下一个净值日期
      SELECT COUNT(1)
        INTO V_COUNT_NEXT
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = (SELECT MIN(JZRQ)
                       FROM TPIF_CPJZ
                      WHERE CPID = CUR_JZ.CPID
                        AND JZRQ > CUR_JZ.JZRQ);
      IF V_COUNT_NEXT > 0 THEN
        SELECT JZRQ, DWJZ, LJJZ, JYRQ
          INTO V_JZRQ, V_DWJZ, V_LJJZ, V_JYRQ
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = (SELECT MIN(JZRQ)
                         FROM TPIF_CPJZ
                        WHERE CPID = CUR_JZ.CPID
                          AND JZRQ > CUR_JZ.JZRQ)
           AND ROWNUM = 1;
      
        V_ZDF := ROUND((V_LJJZ - CUR_JZ.LJJZ) / CUR_JZ.DWJZ, 6);
        IF V_ZDF > 0.15 OR V_ZDF < -0.15 THEN
          --涨跌幅异常
          IF V_ZDFYC = 0 THEN
            V_ZDFYC := 1;
            V_YCXX  := '涨跌幅异常';
            --质检结果ID
            SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
            --插入质检结果
            INSERT INTO TPIF_ZJJG_CPJZ
              (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
            VALUES
              (V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JZRQ,
               0,
               2,
               V_YCXX);
            --插入异常明细
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               V_JYRQ,
               V_JZRQ,
               V_DWJZ,
               V_LJJZ,
               V_ZDF,
               0,
               0,
               SYSDATE);
          ELSE
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               V_JYRQ,
               V_JZRQ,
               V_DWJZ,
               V_LJJZ,
               V_ZDF,
               0,
               0,
               SYSDATE);
          END IF;
        END IF;
      END IF;
      IF V_JZYC = 0 AND V_ZDFYC = 0 THEN
        UPDATE TMP_JZZJ SET ZJZT = 1 WHERE SX = CUR_JZ.SX;
      END IF;
      --质检没问题的数据插入净值表
      --是否存在上一个净值日期
      SELECT COUNT(1)
        INTO V_COUNT_LAST
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = CUR_JZ.JZRQ;
      IF V_COUNT_LAST > 0 THEN
        V_RZF := 0;
      ELSE
        V_RZF := V_ZDF;
      END IF;
      INSERT INTO TPIF_CPJZ
        (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM, RZF)
        SELECT SEQ_TPIF_CPJZ.NEXTVAL,
               CPID,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               5, --数据来源 5柜台
               1, --确认状态 1有效
               CPDM,
               V_RZF
          FROM TMP_JZZJ
         WHERE ZJZT = 1 --质检状态为1的插入TPIF_CPJZ
           AND SX = CUR_JZ.SX;
    
      -- 判断TPIF_CPJZXX_CPZX是否有净值记录
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = CUR_JZ.JZRQ;
      IF V_COUNT > 0 THEN
        CONTINUE;
      ELSE
      
        -- V_SQFQJZ := 0;
        --取复权净值
        BEGIN
          SELECT FQJZ
            INTO V_SQFQJZ
            FROM TPIF_CPJZXX_CPZX
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = (SELECT MAX(JZRQ)
                           FROM TPIF_CPJZXX_CPZX
                          WHERE CPID = CUR_JZ.CPID
                            AND JZRQ < CUR_JZ.JZRQ);
        EXCEPTION
          --净值表没该产品净值，则要插入的记录为第一条净值
          WHEN OTHERS THEN
            V_SQFQJZ := 0;
        END;
      
        INSERT INTO TPIF_CPJZXX_CPZX
          (CPID, JYRQ, JZRQ, DWJZ, LJJZ, CPDM, RZF)
          SELECT CPID, JYRQ, JZRQ, DWJZ, LJJZ, CPDM, V_ZDF
            FROM TMP_JZZJ
           WHERE ZJZT = 1 --质检状态为1的插入TPIF_CPJZ
             AND SX = CUR_JZ.SX;
      
        --更新复权净值
        --第一条净值记录的复权净值
        IF V_SQFQJZ = 0 THEN
          UPDATE TPIF_CPJZXX_CPZX
             SET FQJZ = ROUND(DWJZ * (LJJZ - DWJZ + 1), 4)
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ;
        ELSE
          UPDATE TPIF_CPJZXX_CPZX
             SET FQJZ = ROUND((RZF + 1) * V_SQFQJZ, 4)
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ;
        END IF;
      END IF;
    END LOOP;
  END LOOP;

  /********************产品最新净值表清空并重新插入最新数据************************/
  /*  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPZXJZ ';
  */
  DELETE FROM TPIF_CPZXJZ A WHERE A.SJLY = 5;
  DELETE FROM TPIF_CPZXJZ A WHERE TRIM(A.SJLY) IS NULL;

  INSERT INTO TPIF_CPZXJZ
    (ID,
     CPID,
     JYRQ,
     JZRQ,
     DWJZ,
     LJJZ,
     FQJZ,
     NHSYL,
     WFSYL,
     RZF,
     ZZF,
     QRZT,
     SJLY,
     FBR,
     CZSJ,
     NHSYL_D7,
     CPDM)
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPZXJZ'),
           X.CPID,
           X.JYRQ,
           X.JZRQ,
           X.DWJZ,
           X.LJJZ,
           X.FQJZ,
           X.NHSYL,
           X.WFSYL,
           X.RZF,
           X.ZZF,
           X.QRZT,
           5 AS SJLY,
           X.FBR,
           SYSDATE,
           X.NHSYL_D7,
           X.CPDM
      FROM (SELECT A.CPID,
                   A.JYRQ,
                   A.JZRQ,
                   A.DWJZ,
                   A.LJJZ,
                   A.FQJZ,
                   A.NHSYL,
                   A.WFSYL,
                   A.RZF,
                   A.ZZF,
                   A.QRZT,
                   A.SJLY,
                   A.FBR,
                   A.NHSYL_D7,
                   A.CPDM,
                   ROW_NUMBER() OVER(PARTITION BY A.CPID ORDER BY A.JZRQ DESC) AS RNN
              FROM TPIF_CPJZXX_CPZX A) X
     WHERE X.RNN = 1
       AND NOT EXISTS (SELECT 1
              FROM TPIF_CPDM C
             WHERE C.CPID = X.CPID
               AND C.SJLY = 1);

  /**************更新TPIF_CPDM表净值信息***************************************/
  MERGE INTO PIF.TPIF_CPDM M
  USING (SELECT CPID, JZRQ, DWJZ, LJJZ /*, NHSYL_D7, WFSYL*/
           FROM TPIF_CPZXJZ) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE SET M.JZRQ = N.JZRQ, M.CPJZ = N.DWJZ, M.LJJZ = N.LJJZ;
  /*   M.QRNHSYL = N.NHSYL_D7,
  M.WFSYL   = N.WFSYL;*/

  /**************更新TPIF_CPDM表 首发净值信息***************************************/
  FOR CUR IN (SELECT CPDM, YRRQ, CPXL, CPID
                FROM TPIF_CPDM
               WHERE YRRQ IS NOT NULL
                 AND SFJZRQ IS NULL) LOOP
    --引入日期不为空，首发净值日期为空
    IF CUR.CPXL = 1 THEN
      --公募净值取聚源
      UPDATE TPIF_CPDM M
         SET (M.SFJZRQ, M.SFDWJZ, M.SFLJJZ) =
             (SELECT TO_NUMBER(TO_CHAR(N.ENDDATE, 'yyyymmdd')),
                     N.UNITNV,
                     N.ACCUMULATEDUNITNV
                FROM INFO.TINFO_JJJZ N
               WHERE N.SECUCODE = CUR.CPDM
                 AND N.ENDDATE =
                     (SELECT MIN(A.ENDDATE)
                        FROM INFO.TINFO_JJJZ A
                       WHERE A.SECUCODE = CUR.CPDM
                         AND TO_NUMBER(TO_CHAR(A.ENDDATE, 'yyyymmdd')) >=
                             CUR.YRRQ))
       WHERE M.CPDM = CUR.CPDM;
    ELSE
      --其余取柜台净值
      UPDATE TPIF_CPDM M
         SET (M.SFJZRQ, M.SFDWJZ, M.SFLJJZ) =
             (SELECT N.JZRQ, N.DWJZ, N.LJJZ
                FROM TPIF_CPJZXX_CPZX N
               WHERE N.CPID = CUR.CPID
                 AND N.JZRQ = (SELECT MIN(A.JZRQ)
                                 FROM TPIF_CPJZXX_CPZX A
                                WHERE A.CPID = CUR.CPID
                                  AND A.JZRQ >= CUR.YRRQ))
       WHERE M.CPID = CUR.CPID;
    END IF;
  END LOOP;
  --引入来源不为空，但是首发净值日期为空的更新，已经有首发净值日期的就不更新了，因为值是固定的不会变

  COMMIT;

  O_CODE := 1;
  O_NOTE := '产品净值清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '产品净值清洗,未知错误'
                ELSE
                 '产品净值清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

