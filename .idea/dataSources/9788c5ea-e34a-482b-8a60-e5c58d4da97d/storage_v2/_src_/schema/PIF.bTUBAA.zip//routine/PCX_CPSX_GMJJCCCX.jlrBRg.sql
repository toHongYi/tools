create PROCEDURE PCX_CPSX_GMJJCCCX(CUR_RESULT OUT TYPES.CURSORTYPE,
                                              I_KSRQ     IN NUMBER,
                                              I_JSRQ     IN NUMBER,
                                              I_TJLX     IN NUMBER,
                                              I_CPDMS    IN VARCHAR2,
                                              I_JJFL     IN VARCHAR2) IS
    /*  项目：中信建投产品中心
    功能作用：公募基金持仓查询
    创建：
    作者      版本     时间
    涂 孟    1.0.1     20190530
    统计类型： 1|分公司;2|营业部;3|产品;
    组织机构层级标识   GRADE|  1|分公司；2|营业部   FDNCODE| 分公司管辖营业部

    作者           版本          创建时间       说明
    涂孟           1.0.1         2019-05-30     新建
    涂孟           1.0.2         2019-07-01     修改：新增基金类型维度的查询
    涂孟           1.0.3         2019-07-16     修改：新增 查询截止日持仓人数
    涂孟           1.0.4         2019-08-28     修改: 新增otc系统公募持仓
    涂孟           1.0.5         2019-09-05     修改：新增持有份额列
    涂孟           1.0.6         2020-01-06     修改：002260特殊处理
                  */
    V_NOTE VARCHAR2(2000);
    V_TS   NUMBER(8);
BEGIN
    --计算天数
    SELECT TO_DATE(TO_CHAR(I_JSRQ), 'YYYYMMDD') -
           TO_DATE(TO_CHAR(I_KSRQ), 'YYYYMMDD') + 1
      INTO V_TS
      FROM DUAL;
/*    IF V_TS = 0 THEN
        OPEN CUR_RESULT FOR
            SELECT '您所选择的时间区间交易日天数为0！请重新选择时间区间！' FROM DUAL;
        RETURN;
    END IF;*/
    --1/分公司
    IF I_TJLX = 1 THEN
        IF I_CPDMS IS NULL THEN
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       fgsdm 分公司代码,
                       fgsmc 分公司,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 GROUP BY T1.CPMC,fgsdm,fgsmc
                 ORDER BY fgsdm;
        ELSE
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       fgsdm 分公司代码,
                       fgsmc 分公司,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 where instr(';'||I_CPDMs||';',';'||T1.CPMC||';')>0
                 GROUP BY T1.CPMC,fgsdm,fgsmc
                 ORDER BY fgsdm;
        END IF;
    END IF;
    --2/营业部
    IF I_TJLX = 2 THEN
        IF I_CPDMS IS NULL THEN
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       fgsdm 分公司代码,
                       fgsmc 分公司,
                       yybdm 营业部代码,
                       yybmc 营业部名称,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 GROUP BY T1.CPMC,fgsdm,fgsmc,yybdm,yybmc
                 ORDER BY yybdm;
        ELSE
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       fgsdm 分公司代码,
                       fgsmc 分公司,
                       yybdm 营业部代码,
                       yybmc 营业部名称,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 where instr(';'||I_CPDMs||';',';'||T1.CPMC||';')>0
                 GROUP BY T1.CPMC,fgsdm,fgsmc,yybdm,yybmc
                 ORDER BY yybdm;
        END IF;
    END IF;
    --3/产品
    IF I_TJLX = 3 THEN
        IF I_CPDMS IS NULL THEN
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 GROUP BY T1.CPMC
                 ORDER BY cpmc;
        ELSE
            OPEN CUR_RESULT FOR
                SELECT TO_CHAR(SYSDATE, 'yyyymmdd') AS 时间,
                       T1.CPMC 产品代码,
                       MAX(T1.CPDM) 产品名称,
                       SUM(T1.rjcc)  日均持仓,
                       SUM(T1.rjcyfe) 日均持有份额,
                       MAX(T1.jzsjgmrs) 查询截止日持仓人数
                  FROM T_GMJJCCCX T1
                 where instr(';'||I_CPDMs||';',';'||T1.CPMC||';')>0
                 GROUP BY T1.CPMC
                 ORDER BY cpmc;
        END IF;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        V_NOTE := SQLERRM;
        OPEN CUR_RESULT FOR
            SELECT '异常信息: ' || V_NOTE || '' FROM DUAL;
END PCX_CPSX_GMJJCCCX;
/

