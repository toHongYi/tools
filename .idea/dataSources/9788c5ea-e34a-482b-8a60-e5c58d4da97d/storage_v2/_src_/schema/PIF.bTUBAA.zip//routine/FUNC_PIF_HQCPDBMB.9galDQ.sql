create FUNCTION FUNC_PIF_HQCPDBMB(
  I_USERID IN INTEGER, --??ID
  I_PROD_ID IN INTEGER  --??ID
)RETURN INTEGER IS
  Result INTEGER;          --??????ID
/*
**?????????????
**???????
**?????2014-12-10
*************************************************************
**???     ???    ????     ??
**???      v1.0    2014-12-10    ??
**
*/
V_JRCPFL VARCHAR2(200);
V_COUNT INTEGER;
BEGIN
  --init
  Result := '';
  --check
  IF I_USERID is null THEN
    RETURN(Result);
  END IF;
  IF I_PROD_ID is null THEN
    RETURN(Result);
  END IF;
  --start
  BEGIN
      SELECT JRCPFL INTO V_JRCPFL FROM PIF.TPIF_CPDM WHERE ID = I_PROD_ID;
      EXCEPTION
          WHEN OTHERS THEN
              RETURN(Result);
  END;
  IF V_JRCPFL IS NULL THEN
      RETURN(Result);
  END IF;
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_FLMBDY WHERE INSTR(';'||CPFL||';',';'||V_JRCPFL||';') >0 AND MBZT = 1;
  IF V_COUNT = 0 THEN
      RETURN(Result);
  END IF;
  IF I_USERID = 0 THEN
      SELECT A.ID INTO Result
        FROM TPIF_FLMBDY A
       WHERE INSTR(';'||A.CPFL||';',';'||V_JRCPFL||';') >0
         AND A.MBZT = 1
         AND A.ZHXGRQ = (SELECT MAX(B.ZHXGRQ) FROM TPIF_FLMBDY B WHERE B.MBZT = 1 AND INSTR(';'||B.CPFL||';',';'||V_JRCPFL||';') >0 )
         AND ROWNUM = 1;
      RETURN(Result);
  END IF;
  --??:????>????>??>??>????!
  FOR CUR IN (SELECT *
                FROM TPIF_FLMBDY A
               WHERE A.MBZT = 1
                 AND INSTR(';' || CPFL || ';', ';' || V_JRCPFL || ';') > 0
                 AND EXISTS(SELECT 1
                              FROM TPIF_FLMBDY_SYFW B
                             WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 3)) LOOP
       FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 3) LOOP
           IF INSTR(';' || CUR_S.SYYH || ';', ';' || I_USERID || ';') > 0 THEN
               Result := CUR.ID;
               RETURN(Result);
           END IF;
       END LOOP;
  END LOOP;
  FOR CUR IN (SELECT *
                FROM TPIF_FLMBDY A
               WHERE A.MBZT = 1
                 AND INSTR(';' || CPFL || ';', ';' || V_JRCPFL || ';') > 0
                 AND EXISTS(SELECT 1
                              FROM TPIF_FLMBDY_SYFW B
                             WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 4)) LOOP
      FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 4) LOOP
          SELECT COUNT(1) INTO V_COUNT
            FROM livebos.LBMEMBER
           WHERE USERID = I_USERID AND ROLEID = CUR_S.SYJS AND ORGID = CUR_S.SYBM;
          IF V_COUNT > 0 THEN
              Result := CUR.ID;
              RETURN(Result);
          END IF;
      END LOOP;
   END LOOP;
   FOR CUR IN (SELECT *
                 FROM TPIF_FLMBDY A
                WHERE A.MBZT = 1
                  AND INSTR(';' || CPFL || ';', ';' || V_JRCPFL || ';') > 0
                  AND EXISTS(SELECT 1
                               FROM TPIF_FLMBDY_SYFW B
                              WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 2)) LOOP
      FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 2) LOOP
          SELECT COUNT(1) INTO V_COUNT
            FROM livebos.LBMEMBER
           WHERE USERID = I_USERID AND ROLEID = CUR_S.SYJS;
          IF V_COUNT > 0 THEN
              Result := CUR.ID;
              RETURN(Result);
          END IF;
      END LOOP;
  END LOOP;
  FOR CUR IN (SELECT *
                FROM TPIF_FLMBDY A
               WHERE A.MBZT = 1
                 AND INSTR(';' || CPFL || ';', ';' || V_JRCPFL || ';') > 0
                 AND EXISTS(SELECT 1
                              FROM TPIF_FLMBDY_SYFW B
                             WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 1)) LOOP
      FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 1) LOOP
          SELECT COUNT(1) INTO V_COUNT
            FROM livebos.TUSER
           WHERE ID = I_USERID
             AND ORGID = CUR_S.SYBM;
          IF V_COUNT > 0 THEN
              Result := CUR.ID;
              RETURN(Result);
          END IF;
      END LOOP;
  END LOOP;
  FOR CUR IN (SELECT *
                FROM TPIF_FLMBDY A
               WHERE A.MBZT = 1
                 AND INSTR(';' || CPFL || ';', ';' || V_JRCPFL || ';') > 0
                 AND EXISTS(SELECT 1
                              FROM TPIF_FLMBDY_SYFW B
                             WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 0)) LOOP
      Result := CUR.ID;
      RETURN(Result);
  END LOOP;
  --return
  RETURN(Result);
END FUNC_PIF_HQCPDBMB;
/

