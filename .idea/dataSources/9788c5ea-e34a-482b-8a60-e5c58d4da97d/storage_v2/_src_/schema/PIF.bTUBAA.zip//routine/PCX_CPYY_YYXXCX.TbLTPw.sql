create PROCEDURE PCX_CPYY_YYXXCX (
                                                       --    O_NOTE  OUT VARCHAR2,
                                                           O_RESULT     OUT SYS_REFCURSOR,-- 返回结果集
                                                           I_CZR IN NUMBER,--当前登录人
                                                           I_CPDM IN VARCHAR2, --产品代码/产品名称
                                                           I_YYKSRQ IN VARCHAR2, --预约开始日期
                                                           I_YYJZRQ IN VARCHAR2,--预约截至日期
                                                           I_XSKSRQ IN VARCHAR2, --销售开始日期
                                                           I_XSJZRQ IN VARCHAR2, --销售截止日期
                                                           I_CPLX IN  NUMBER, --产品类型
                                                           I_YYZT IN NUMBER --预约状态

) AS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：    
                      I_CZR 操作人
                     I_CPDM   产品代码/产品名称           
                     I_YYKSRQ     预约开始日期 
                     I_YYJZRQ     预约截止日期                   
                     I_XSKSRQ    销售开始日期    
                     I_XSJZRQ    销售截止日期    
                     I_CPLX        产品类型
                     I_YYZT       预约状态
           输出参数：   O_RESULT  返回数据
                               
                              
      逻辑说明：1.总部查全部预约产品，预约总额度、总人数、剩余额度、人数为当前产品的剩余额度人数
                     2.分公司查当前分公司下的营业部有权限的产品，预约总额度、总人数、剩余额度、人数为
                        产品总的剩余额度人数和总部数据相同
                        3.营业部查当前营业部有权限的产品，预约总额度、总人数、剩余额度、人数为当前营业部的额度和人数              
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WWH        预约信息查询
         2021-10-21     2.0.0     WWH        数据权限变更，SQL分为总部、多部门查询、单营业部查询
  ***********************************************************************/
V_SQL_ZBGL VARCHAR2(32767);
V_SQL_FGSGL VARCHAR2(32767);
V_SQL_YYBGL VARCHAR2(32767);
V_CZR NUMBER;
V_ORGID NUMBER;--用户所属部门
V_ZBGLG NUMBER; --总部管理岗
V_FGSGLG NUMBER;--分公司管理岗
V_YYBYWRY NUMBER;--营业部业务人员
ZB_ROLE NUMBER; --总部管理人角色ID
FGS_ROLE NUMBER;--分公司管理人角色ID
YYB_ROLE NUMBER; --营业部业务人员角色ID
V_COUNT NUMBER;
V_YYCZLJ VARCHAR2(2000);--预约操作链接


--查询条件


 
V_WHERE VARCHAR2(4000);

O_NOTE   VARCHAR2(300);
BEGIN
O_NOTE:='';

/*ZB_ROLE:=900011;
FGS_ROLE:=900012;
YYB_ROLE:=900013;*/
V_YYCZLJ:=q'[<a href='javascript:void(0)' class='Link' windowtitle='产品预约客户信息' onclick="DoCommand('/livebos/UIProcessor?Table=xn_CPYYKHXX&ParamAction=true&YYCPID=XID&SYKYYED=XSYKYYED&SYKYYRS=XSYKYYRS',false,true,'',1);">预约明细</a>]';



V_CZR:=I_CZR;

IF I_CPDM IS NOT NULL THEN
V_WHERE:= '  AND (  CPDM  LIKE  ''%'||I_CPDM||'%''  OR CPJC LIKE  ''%'||I_CPDM||'%'' )';
END IF;
IF I_CPLX IS NOT NULL THEN
V_WHERE:=V_WHERE||' AND ( JRCPFL = '||I_CPLX||')';
  END IF;
IF I_YYZT IS NOT NULL THEN
    V_WHERE:=V_WHERE||' AND ( CPYYZT = '||I_YYZT||')';
END IF;
IF I_YYKSRQ  IS NOT NULL AND I_YYJZRQ  IS NOT NULL THEN
  
V_WHERE:=V_WHERE||'  AND (NOT( (TO_CHAR(YYKSRQ,''YYYY-MM-DD'' )> '''||I_YYJZRQ||''') OR ( (TO_CHAR(YYJZRQ,''YYYY-MM-DD'')<'''||I_YYKSRQ||'''))))';
END IF;

IF I_XSKSRQ  IS NOT NULL AND I_XSJZRQ  IS NOT NULL THEN
  
V_WHERE:=V_WHERE||'  AND (NOT( (TO_CHAR(XSKSRQ ,''YYYY-MM-DD'')> '''||I_XSJZRQ||''') OR ( (TO_CHAR(XSJZRQ,''YYYY-MM-DD'')<'''||I_XSKSRQ||'''))))';
END IF;

IF I_XSKSRQ IS NULL AND I_XSJZRQ IS NOT NULL THEN
  V_WHERE:=V_WHERE||'   AND TO_CHAR(XSJZRQ ) < '''|| I_XSJZRQ||'''';
END IF;
IF I_XSKSRQ IS NOT  NULL AND I_XSJZRQ IS  NULL THEN
  V_WHERE:=V_WHERE||'   AND TO_CHAR(XSKSRQ ) >'''|| I_XSKSRQ||'''';
END IF;
IF I_YYKSRQ IS NOT  NULL AND I_YYJZRQ IS  NULL THEN
  V_WHERE:=V_WHERE||'   AND TO_CHAR(YYKSRQ,''YYYY-MM-DD'' ) > '''|| I_YYKSRQ||'''';
END IF;
IF I_YYKSRQ IS   NULL AND I_YYJZRQ IS NOT NULL THEN
  V_WHERE:=V_WHERE||'   AND TO_CHAR(XSJZRQ ,''YYYY-MM-DD'') <  '''||I_YYJZRQ||'''';
END IF;

  



/*--获取用户所在部门
SELECT ORGID INTO V_ORGID FROM   LIVEBOS.TUSER WHERE  ID = V_CZR;
--判断该用户是否是总部管理人角色
SELECT COUNT(1) INTO  V_ZBGLG FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =ZB_ROLE AND USERID =V_CZR;
--判断该用户是否是分公司管理人角色
SELECT COUNT(1) INTO  V_FGSGLG FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =FGS_ROLE AND USERID =V_CZR;
--判断该用户是否是营业部业务人员
SELECT COUNT(1) INTO  V_YYBYWRY FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =YYB_ROLE AND USERID =V_CZR;
--管理员查看
*/
--判断该用户是否是总部管理人角色
SELECT COUNT(1) INTO V_ZBGLG
FROM   LIVEBOS.LBDATASCOPEAUTH
WHERE  TYPE = 1 --角色
AND    AUDITFLAG = 1
AND    SCOPENAME = 'YYB'
AND    MEMBERID IN(
          SELECT ROLEID FROM LIVEBOS.LBMEMBER WHERE USERID = V_CZR);
          
 --判断是否是单营业部权限
SELECT COUNT(1)
INTO   V_COUNT
FROM   LIVEBOS.LBDATASCOPEAUTH
WHERE  TYPE = 0 --用户
AND    AUDITFLAG = 1
AND    SCOPENAME = 'YYB'
AND    MEMBERID  =V_CZR;
     
       IF V_COUNT = 1 THEN
           SELECT COUNT(1) INTO V_YYBYWRY FROM LIVEBOS.LBORGANIZATION WHERE LX =1 AND BRANCH_ID IS NOT NULL AND 
           ID = (SELECT SCOPEEXP 
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 --用户
          AND    AUDITFLAG = 1
          AND    SCOPENAME = 'YYB'
          AND    MEMBERID = V_CZR);
              IF V_YYBYWRY =1 THEN
                      V_YYBYWRY:=1;
                ELSE
                      V_FGSGLG:=1;
              END IF;
 
                    ELSE
                      V_FGSGLG:=1;
          END IF;
IF V_CZR = 0 THEN
  V_ZBGLG:=1;
END IF;

IF V_YYBYWRY =1 THEN
  SELECT SCOPEEXP INTO V_ORGID  --单营业部时，V_ORGID 为数据权限所在营业部
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 --用户
          AND    AUDITFLAG = 1
          AND    SCOPENAME = 'YYB'
          AND    MEMBERID =V_CZR;
END IF;


/*
 (CASE WHEN  A.GLCPID  IS NOT NULL THEN   (A.YYZED - (SELECT SUM(YYJE)   FROM   TPIF_YYBXE
        WHERE  GLCPID IN (SELECT ID
                          FROM   PIF.TPIF_YYCPGL
                          WHERE  ID =   A.GLCPID
                          OR     GLCPID =    A.GLCPID)) ) ELSE (A.YYZED - A.YYYZJE) END) AS SYKYYED,
            (CASE WHEN  A.GLCPID  IS NOT NULL THEN   (A.YYZRS - (SELECT SUM(YYRS)   FROM   TPIF_YYBXE
        WHERE  GLCPID IN (SELECT ID
                          FROM   PIF.TPIF_YYCPGL
                          WHERE  ID =   A.GLCPID
                          OR     GLCPID =    A.GLCPID)) ) ELSE (A.YYZRS - A.YYYZRS) END) AS SYKYYRS,*/
  

--总部查询SQL
       V_SQL_ZBGL:='
     SELECT CPGLID,DKHYYSXJE,DKHYYXXJE,CPPC,GLCPPC,CPJC,CPDM,NAME,SFQYDZHT,YYKSRQ,YYJZRQ,XSKSRQ,XSJZRQ,SYKYYED,SYKYYRS,YYYZJE,YYYZRS,CPYYZT,
     REPLACE(REPLACE(YYCZLJ,''XSYKYYED'',SYKYYED),''XSYKYYRS'',SYKYYRS) AS YYCZLJ FROM
  (SELECT A.ID AS CPGLID,A.CPPC,
            (SELECT CPPC FROM PIF.TPIF_YYCPGL  WHERE A.GLCPID = ID  ) AS GLCPPC,
            A.DKHYYSXJE,
            A.DKHYYXXJE,
            B.CPJC,
            B.JRCPFL,
            B.CPDM,
            C.NAME,
            A.SFQYDZHT,
            A.YYKSRQ,
            A.YYJZRQ,
            A.XSKSRQ,
            A.XSJZRQ,
                  (CASE
                   WHEN A.YYZED = 0 THEN
                  ''无限制''
                   ELSE (CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZED- (  SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )||''  ''                   
                WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZED-(SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID))))||''  ''  ELSE(A.YYZED-A.YYYZJE)||''  ''  END )END)   AS SYKYYED,

       (CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZRS- (  SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )
                    WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZRS-(SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID)))) ELSE(A.YYZRS-A.YYYZRS) END ) AS SYKYYRS,
                
          (A.YYYZJE+A.CCKHYYJE) AS YYYZJE,
      (A.YYYZRS+A.CCKHYYSL)||''人/未持仓''|| (A.YYYZRS ) ||''人''as YYYZRS,
            (CASE
               WHEN ((A.YYKSRQ) < SYSDATE AND
                    (A.YYJZRQ) > SYSDATE) THEN
               1
               WHEN ((A.YYJZRQ) > SYSDATE AND
                    (A.YYJZRQ) > SYSDATE) THEN
                0
               WHEN ((A.YYKSRQ) < SYSDATE AND
                    (A.YYJZRQ) < SYSDATE) THEN
                2
           END) AS CPYYZT,REPLACE(
           '||'q''['||V_YYCZLJ||']'''||',''XID'',A.ID) AS YYCZLJ
     FROM   TPIF_YYCPGL A
     LEFT   JOIN TPIF_CPDM B
     ON     A.CPBS = B.ID
     LEFT   JOIN TPIF_JRCPFL C
     ON     B.JRCPFL = C.ID WHERE SFYX =1) 
    
     WHERE 1=1   '||V_WHERE||'
     ORDER BY CPPC  DESC';

 --多部门查询SQL
     V_SQL_FGSGL:='
     SELECT CPGLID,GLCPPC,CPPC,DKHYYXXJE,DKHYYSXJE,CPJC,CPDM,NAME,SFQYDZHT,YYKSRQ,YYJZRQ,XSKSRQ,XSJZRQ,SYKYYED,SYKYYRS,YYYZJE,YYYZRS,CPYYZT,
     REPLACE(REPLACE(YYCZLJ,''XSYKYYED'',SYKYYED),''XSYKYYRS'',SYKYYRS) AS YYCZLJ FROM
(SELECT  A.ID AS CPGLID,
(SELECT CPPC FROM PIF.TPIF_YYCPGL  WHERE A.GLCPID = ID  ) AS GLCPPC,
A.CPPC,
 A.DKHYYSXJE,
            A.DKHYYXXJE,
       B.CPJC,
       B.JRCPFL,
       B.CPDM,
       C.NAME,
       A.SFQYDZHT,
       A.YYKSRQ,
       A.YYJZRQ,
       A.XSKSRQ,
       A.XSJZRQ,
       (CASE
                   WHEN A.YYZED = 0 THEN
                 ''无限制''  ELSE (CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZED- (  SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )||''  ''  
                    WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZED-(SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID))))||''  ''     ELSE(A.YYZED-A.YYYZJE)||''  ''    END )END)AS SYKYYED,

       (CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZRS- (  SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )
                    WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZRS-(SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID)))) ELSE(A.YYZRS-A.YYYZRS) END ) AS SYKYYRS,

      ( SELECT SUM(YYJE) +SUM(CCKHYYJE)
         FROM   TPIF_YYBXE
         WHERE  CPGLID = A.ID
         AND    YYBID IN (SELECT ID
                          FROM   LIVEBOS.LBORGANIZATION
                          WHERE  BRANCH_ID IS NOT NULL
                          START  WITH ID IN( SELECT SCOPEEXP 
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 
          AND    AUDITFLAG = 1
          AND    SCOPENAME = ''YYB''
          AND    MEMBERID ='||V_CZR||'    )
                          CONNECT BY PRIOR ID = FID) )AS YYYZJE,

      ( SELECT SUM(YYRS) +SUM(CCKHYYSL)
         FROM   TPIF_YYBXE
         WHERE  CPGLID = A.ID
         AND    YYBID IN (SELECT ID
                          FROM   LIVEBOS.LBORGANIZATION
                          WHERE  BRANCH_ID IS NOT NULL
                          START  WITH ID IN (SELECT SCOPEEXP 
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 
          AND    AUDITFLAG = 1
          AND    SCOPENAME = ''YYB''
          AND    MEMBERID ='||V_CZR||'  )
                          CONNECT BY PRIOR ID = FID))||''人/未持仓''|| (SELECT SUM(YYRS) 
         FROM   TPIF_YYBXE
         WHERE  CPGLID = A.ID
         AND    YYBID IN (SELECT ID
                          FROM   LIVEBOS.LBORGANIZATION
                          WHERE  BRANCH_ID IS NOT NULL
                          START  WITH ID IN ( SELECT SCOPEEXP 
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 
          AND    AUDITFLAG = 1
          AND    SCOPENAME = ''YYB''
          AND    MEMBERID ='||V_CZR||'    )
                          CONNECT BY PRIOR ID = FID)) ||''人'' AS YYYZRS，
(CASE
           WHEN ((A.YYKSRQ) <
                SYSDATE AND
                (A.YYJZRQ) >
                SYSDATE) THEN
            1
           WHEN ((A.YYJZRQ) >
                SYSDATE AND
                (A.YYJZRQ) >
                SYSDATE) THEN
            0
           WHEN ((A.YYKSRQ) <
                SYSDATE AND
                (A.YYJZRQ) <
                SYSDATE) THEN
            2
       END) AS CPYYZT,REPLACE(
        '||'q''['||V_YYCZLJ||']'''||',''XID'',A.ID) AS YYCZLJ
FROM   TPIF_YYCPGL A
LEFT   JOIN TPIF_CPDM B
ON     A.CPBS = B.ID
LEFT   JOIN TPIF_JRCPFL C
ON     B.JRCPFL = C.ID

WHERE  SFYX =1 AND A.ID IN (

                SELECT CPGLID
                FROM   TPIF_YYBXE
                WHERE  YYBID IN (

                              SELECT ID
                              FROM   LIVEBOS.LBORGANIZATION
                              WHERE  BRANCH_ID IS NOT NULL
                              START  WITH ID IN ( SELECT SCOPEEXP 
          FROM   LIVEBOS.LBDATASCOPEAUTH
          WHERE  TYPE = 0 
          AND    AUDITFLAG = 1
          AND    SCOPENAME = ''YYB''
          AND    MEMBERID ='||V_CZR||'  )
                              CONNECT BY PRIOR ID = FID))) WHERE 1=1   '||V_WHERE||'  ORDER BY CPPC  DESC  ' ;

--单部门查询SQL
V_SQL_YYBGL:=
' SELECT CPGLID,GLCPPC,CPPC,DKHYYSXJE,DKHYYXXJE,CPJC,CPDM,NAME,SFQYDZHT,YYKSRQ,YYJZRQ,XSKSRQ,XSJZRQ,SYKYYED,SYKYYRS,YYYZJE,YYYZRS,CPYYZT,
  REPLACE(REPLACE(YYCZLJ,''XSYKYYED'',SYKYYED),''XSYKYYRS'',SYKYYRS) AS YYCZLJ FROM
(SELECT  A.ID AS CPGLID,A.CPPC,
(SELECT CPPC FROM PIF.TPIF_YYCPGL  WHERE A.GLCPID = ID  ) AS GLCPPC,
 A.DKHYYSXJE,
            A.DKHYYXXJE,
        B.CPJC,
        B.JRCPFL,
        B.CPDM,
        C.NAME,
        A.SFQYDZHT,
        A.YYKSRQ,
        A.YYJZRQ,
        A.XSKSRQ,
        A.XSJZRQ,
        (CASE WHEN ((SELECT ZKYED FROM TPIF_YYBXE WHERE CPGLID =A.ID  AND YYBID ='||V_ORGID||') =0) THEN  ((CASE
                   WHEN A.YYZED = 0 THEN
                 ''无限制''  ELSE( CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZED- (  SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )||'' ''
                    WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZED-(SELECT SUM(YYJE)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID))))||'' ''     ELSE(A.YYZED-A.YYYZJE)||'' ''  END)END))
        ELSE  ((SELECT (ZKYED-YYJE) FROM TPIF_YYBXE WHERE CPGLID =A.ID  AND YYBID ='||V_ORGID||'))||'' '' END)
         AS SYKYYED,
       ( (CASE WHEN ((SELECT (ZKYRS) FROM TPIF_YYBXE WHERE CPGLID =A.ID  AND YYBID ='||V_ORGID||') =0 )  THEN (CASE 
                 WHEN A.GLCPID IS NOT NULL THEN  A.YYZRS- (  SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.GLCPID OR GLCPID = A.GLCPID)) )
                    WHEN (A.GLCPID IS NULL AND (SELECT COUNT(1) FROM TPIF_YYCPGL WHERE GLCPID =A.ID )>0 ) THEN(A.YYZRS-(SELECT SUM(YYRS)
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = A.ID OR GLCPID = A.ID)))) ELSE(A.YYZRS-A.YYYZRS) END)  ELSE (SELECT (ZKYRS-YYRS) FROM TPIF_YYBXE WHERE CPGLID =A.ID  AND YYBID ='||V_ORGID||') END) ) AS SYKYYRS,
        ( (SELECT (YYJE+CCKHYYJE)  FROM TPIF_YYBXE WHERE CPGLID = A.ID   AND YYBID ='||V_ORGID||')) AS YYYZJE,
         (SELECT (YYRS+CCKHYYSL)||''人/未持仓''||(YYRS)||''人''   FROM TPIF_YYBXE WHERE CPGLID = A.ID   AND YYBID ='||V_ORGID||')AS YYYZRS，
        (CASE
           WHEN ((A.YYKSRQ) < SYSDATE AND
                (A.YYJZRQ) > SYSDATE) THEN
            1
           WHEN ((A.YYJZRQ) > SYSDATE AND
                (A.YYJZRQ) > SYSDATE) THEN
            0
           WHEN ((A.YYKSRQ) < SYSDATE AND
                (A.YYJZRQ) < SYSDATE) THEN
            2
       END) AS CPYYZT,REPLACE(
       '||'q''['||V_YYCZLJ||']'''||',''XID'',A.ID) AS YYCZLJ
 FROM   TPIF_YYCPGL A
 LEFT   JOIN TPIF_CPDM B
 ON     A.CPBS = B.ID
 LEFT   JOIN TPIF_JRCPFL C
 ON     B.JRCPFL = C.ID
    
 WHERE SFYX =1 AND A.ID IN (
                SELECT CPGLID
                FROM   TPIF_YYBXE
                WHERE    YYBID ='||V_ORGID||')) WHERE 1=1   '||V_WHERE||'
 ORDER BY CPPC  DESC';


/*dbms_output.put_line(V_SQL_ZBGL);
dbms_output.put_line(V_SQL_FGSGL);
dbms_output.put_line(V_SQL_YYBGL);*/
IF V_ZBGLG =0 AND V_FGSGLG=0 AND V_YYBYWRY =0 THEN
  O_NOTE:='没有找到您查看的数据，请联系管理员！';
  RETURN;
END IF;

IF V_ZBGLG >0 THEN
  OPEN O_RESULT FOR V_SQL_ZBGL;
  RETURN;
  END IF;

  IF V_FGSGLG >0 THEN
  OPEN O_RESULT FOR V_SQL_FGSGL;
  RETURN;
  END IF;

  IF V_YYBYWRY >0 THEN
  OPEN O_RESULT FOR V_SQL_YYBGL;
  RETURN;
  END IF;

O_NOTE:='成功！';
EXCEPTION
  WHEN OTHERS THEN

    O_NOTE := SQLERRM;
    OPEN o_result FOR
      SELECT '异常信息：' || O_NOTE FROM dual;

END;
/

