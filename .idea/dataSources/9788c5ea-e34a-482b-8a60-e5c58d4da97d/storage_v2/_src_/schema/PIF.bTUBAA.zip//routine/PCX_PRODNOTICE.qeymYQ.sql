create PROCEDURE pcx_ProdNotice(O_CODE          OUT NUMBER,
                                           O_NOTE          OUT VARCHAR2,
                                           O_RECORD_NUMBER OUT NUMBER,
                                           O_RESULT        OUT SYS_REFCURSOR,
                                           I_USER          IN INTEGER, --操作人
                                           I_IP            IN VARCHAR2, --访问IP
                                           I_PROD_ID       IN NUMBER, --产品ID
                                           I_PROD_CODE     IN VARCHAR2, --产品代码
                                           I_BEGIN_DATE    IN NUMBER, --开始日期（含）
                                           I_END_DATE      IN NUMBER, --结束日期（含）
                                           I_PAGE_NO       IN NUMBER, --页码
                                           I_PAGE_LONG     IN NUMBER --页长

                                           ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品的公告查询

      语法信息：
           输入参数：    I_PROD_CODE     IN VARCHAR2, --产品代码
                         I_BEGIN_DATE    IN NUMBER, --开始日期（含）
                         I_END_DATE      IN NUMBER, --结束日期（含）
                         I_PAGE_NO       IN NUMBER, --页码
                         I_PAGE_LONG     IN NUMBER --页长
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000010');
  V_COUNT     NUMBER;
  V_JKLX      NUMBER;
  V_PAGE_NO   NUMBER;
  V_PAGE_LONG NUMBER;
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
  END IF;

  /*IF I_BEGIN_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_BEGIN_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_END_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_END_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;*/

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

 /* SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_WHITELIST A
   WHERE A.INTERFACE_TYPE = V_JKLX
     AND A.ALLOW_VISIT_IP = I_IP;
  IF V_COUNT <= 0 THEN
    O_CODE := 1003;
    O_NOTE := 'IP:' || I_IP || '未配置白名单';
    GOTO BOTTOM;
  END IF;*/

  V_PAGE_NO   := NVL(I_PAGE_NO, 1); --默认第1页
  V_PAGE_LONG := NVL(I_PAGE_LONG, 50); --默认每页50条记录

  SELECT COUNT(*)
    INTO O_RECORD_NUMBER
    FROM PIF.TPROD_NOTICE A
   WHERE A.NOTICE_DATE BETWEEN I_BEGIN_DATE AND I_END_DATE
     AND A.PROD_ID =
         (SELECT ID
            FROM PIF.TPROD_BASIC_INFO
           WHERE ID = NVL(I_PROD_ID, ID)
             AND PROD_CODE = NVL(I_PROD_CODE, PROD_CODE));

/*  IF O_RECORD_NUMBER = 0 THEN
    O_CODE := 1004;
    O_NOTE := '查询总记录数据为0';
    GOTO BOTTOM;
  END IF;*/

  IF V_PAGE_NO > CEIL(O_RECORD_NUMBER / V_PAGE_LONG) THEN
    V_PAGE_NO := CEIL(O_RECORD_NUMBER / V_PAGE_LONG);
  END IF;

  OPEN O_RESULT FOR
    SELECT NOTICE_DATE, --公告日期
           PROD_CODE, --产品代码
           PROD_NAME, --产品名称
           NOTICE_ID, --公告ID
           NOTICE_TITLE, --公告标题
           NOTICE_CONTENT, --公告内容
           NOTICE_VISIT_LINK --公告访问链接
      FROM (SELECT ROWNUM              AS XH,
                   B.NOTICE_DATE, --公告日期
                   A.PROD_CODE, --产品代码
                   A.PROD_FULLNAME     AS PROD_NAME, --产品名称
                   B.NOTICE_ID, --公告ID
                   B.NOTICE_TITLE, --公告标题
                   B.NOTICE_CONTENT, --公告内容
                   B.NOTICE_VISIT_LINK --公告访问链接
              FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_NOTICE B
             WHERE A.ID = B.PROD_ID
                AND A.ID =
                   (SELECT ID
                      FROM PIF.TPROD_BASIC_INFO
                     WHERE ID = NVL(I_PROD_ID, ID)
                       AND PROD_CODE = NVL(I_PROD_CODE, PROD_CODE))
               AND B.NOTICE_DATE BETWEEN I_BEGIN_DATE AND I_END_DATE
             ORDER BY B.NOTICE_DATE ASC)
     WHERE XH > (V_PAGE_NO - 1) * V_PAGE_LONG
       AND XH <= V_PAGE_NO * V_PAGE_LONG;

  O_CODE :=0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT NULL AS NOTICE_DATE, --公告日期
           NULL AS PROD_CODE, --产品代码
           NULL AS PROD_NAME, --产品名称
           NULL AS NOTICE_ID, --公告ID
           NULL AS NOTICE_TITLE, --公告标题
           NULL AS NOTICE_CONTENT, --公告内容
           NULL AS NOTICE_VISIT_LINK --公告访问链接
      FROM DUAL
     WHERE 1 = 2;
  END IF ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

