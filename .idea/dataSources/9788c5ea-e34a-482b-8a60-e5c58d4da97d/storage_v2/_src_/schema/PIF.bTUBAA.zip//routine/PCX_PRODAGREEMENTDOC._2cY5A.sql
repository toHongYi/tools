create PROCEDURE pcx_ProdAgreementDoc(O_CODE      OUT NUMBER,
                                                 O_NOTE      OUT VARCHAR2,
                                                 O_RESULT    OUT SYS_REFCURSOR,
                                                 I_USER      IN INTEGER, --操作人
                                                 I_IP        IN VARCHAR2, --访问IP
                                                 I_PROD_ID   IN NUMBER, --产品ID
                                                 I_PROD_CODE IN VARCHAR2 --产品代码
                                                 ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品协议文档查询
      语法信息：
           输入参数：   I_PROD_CODE  IN   VARCHAR2   --产品代码
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000004');
  V_COUNT NUMBER;
  V_JKLX  NUMBER;
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;



  OPEN O_RESULT FOR
    SELECT A.PROD_CODE, --产品代码
           A.PROD_FULLNAME AS PROD_NAME, --产品名称
           B.AGREEMENT_NAME, --协议名称
           B.AGREEMENT_ATTACHMENT, --协议附件
           B.AGREEMENT_CONTENT, --协议内容
           B.AGREEMENT_VERSION, --版本
           B.AGREE_RESOURSE_INTERNAL_ADDR, --协议资源内网地址
           B.FILE_TYPE, --文件类型
           B.AGREEMENT_NO, --协议编号
           --B.AGREE_RESOURSE_EXTERNAL_ADDR, --协议资源外网地址
           B.USER_FLAG, --启用标志
           B.REGISTER_DATE, --登记日期
           B.IS_VIEW, --是否展示
           B.AGREEMENT_TYPE, --协议类型
           B.IMAGE_STR_ADDRESS AS AGREE_RESOURSE_EXTERNAL_ADDR --协议资源外网地址
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_AGREEMENT B
     WHERE A.ID = B.PROD_ID
       AND A.ID = NVL(I_PROD_ID, A.ID)
       AND A.PROD_CODE = NVL(I_PROD_CODE, A.PROD_CODE);
  O_CODE := 0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT A.PROD_CODE, --产品代码
           A.PROD_FULLNAME AS PROD_NAME, --产品名称
           B.AGREEMENT_NAME, --协议名称
           B.AGREEMENT_ATTACHMENT, --协议附件
           B.AGREEMENT_CONTENT, --协议内容
           B.AGREEMENT_VERSION, --版本
           B.AGREE_RESOURSE_INTERNAL_ADDR, --协议资源内网地址
           B.FILE_TYPE, --文件类型
           B.AGREEMENT_NO, --协议编号
           --B.AGREE_RESOURSE_EXTERNAL_ADDR, --协议资源外网地址
           B.USER_FLAG, --启用标志
           B.REGISTER_DATE, --登记日期
           B.IS_VIEW, --是否展示
           B.AGREEMENT_TYPE, --协议类型
           B.IMAGE_STR_ADDRESS AS AGREE_RESOURSE_EXTERNAL_ADDR --协议资源外网地址
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_AGREEMENT B
     WHERE A.ID = B.PROD_ID
       AND 1 = 2;
  END IF ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

