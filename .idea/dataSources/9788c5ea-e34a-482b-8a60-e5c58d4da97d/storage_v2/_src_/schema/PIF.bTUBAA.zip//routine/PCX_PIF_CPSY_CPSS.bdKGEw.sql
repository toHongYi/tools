create PROCEDURE PCX_PIF_CPSY_CPSS(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              
                                              I_qury_condition IN VARCHAR2 --搜索条件
                                              
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：海通证券产品中心
  
         功能说明：按重要程度统计
             参数说明：
                  入参：
                       I_qury_condition     IN VARCHAR2 --搜索条件
  
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT SYS_REFCURSOR
  
  
        ----------------------------------------------------------
        操作人   版本号         时间                     操作
        刘浪浪   1.0.1     2014/11/18                  新增
        刘浪浪   1.0.2     2014/11/22                  修改逻辑
        刘浪浪   1.0.3     2014/12/04                  增加总数量已经已完成数量的统计
  
  -------------------------------------------------------------------------------------------------*/

BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_qury_condition IS NULL THEN
    O_CODE := -1;
    O_NOTE := '搜索条件不能为空!';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
    SELECT T.ID,
           T.PROD_SIMP_NAME as PROD_NAME,
           T.PROD_FULLNAME  as PROD_FULLNAME,
           T.PROD_CODE
      FROM tPROD_BASIC_INFO T
     WHERE T.AUDIT_STATUS = 2
       AND (LOWER(T.PROD_CODE) LIKE '%' || LOWER(I_qury_condition) || '%' OR
           LOWER(T.PROD_FULLNAME) LIKE
           '%' || LOWER(I_qury_condition) || '%')
     ORDER BY T.ID DESC;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

