create procedure prc_hehe as language java name 'Demo.main(java.lang.String[])';
/

