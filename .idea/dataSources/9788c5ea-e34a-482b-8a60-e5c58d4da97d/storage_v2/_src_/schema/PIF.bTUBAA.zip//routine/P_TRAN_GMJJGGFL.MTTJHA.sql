create PROCEDURE P_TRAN_GMJJGGFL(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2 --返回消息
                                               ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：公募基金公告分类表 TINFO_GMJJGGFL 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-12-20     1.0       HJH                创建
  ***********************************************************************/

BEGIN
    --INIT
    O_CODE := 1;
    O_NOTE := '';

    --将更新完的资讯数据插入到INFO表中
    MERGE INTO INFO.TINFO_GMJJGGFL T1
    USING (SELECT A.ID,
                  A.NotTextAnnID,
                  A.Level1,
                  A.Level2,
                  A.Level3,
                  A.InsertTime,
                  A.UpdateTime,
                  A.JSID
             FROM SRC_PIF.MF_AnnClassifi A) T2
    ON (T1.ID = T2.ID )
    WHEN MATCHED THEN
        UPDATE
           SET 
               T1.NotTextAnnID = T2.NotTextAnnID,
               T1.Level1 = T2.Level1,
               T1.Level2 = T2.Level2,
               T1.Level3 = T2.Level3,
               T1.InsertTime = T2.InsertTime,
               T1.UpdateTime = T2.UpdateTime,
               T1.JSID = T2.JSID
    WHEN NOT MATCHED THEN
        INSERT
             ( T1.ID,
               T1.NotTextAnnID,
               T1.Level1,
               T1.Level2,
               T1.Level3,
               T1.InsertTime,
               T1.UpdateTime,
               T1.JSID)
        VALUES
             ( T2.ID,
               T2.NotTextAnnID,
               T2.Level1,
               T2.Level2,
               T2.Level3,
               T2.InsertTime,
               T2.UpdateTime,
               T2.JSID);
               
    --新发产品公告清洗           
  MERGE INTO INFO.TINFO_GMJJGGFL T1
    USING (SELECT A.ID,
                  A.NotTextAnnID,
                  A.Level1,
                  A.Level2,
                  A.Level3,
                  A.InsertTime,
                  A.UpdateTime,
                  A.JSID
             FROM SRC_PIF.MF_AnnClassifi A) T2
    ON (T1.ID = T2.ID )
    WHEN MATCHED THEN
        UPDATE
           SET 
               T1.NotTextAnnID = T2.NotTextAnnID,
               T1.Level1 = T2.Level1,
               T1.Level2 = T2.Level2,
               T1.Level3 = T2.Level3,
               T1.InsertTime = T2.InsertTime,
               T1.UpdateTime = T2.UpdateTime,
               T1.JSID = T2.JSID
    WHEN NOT MATCHED THEN
        INSERT
             ( T1.ID,
               T1.NotTextAnnID,
               T1.Level1,
               T1.Level2,
               T1.Level3,
               T1.InsertTime,
               T1.UpdateTime,
               T1.JSID)
        VALUES
             ( T2.ID,
               T2.NotTextAnnID,
               T2.Level1,
               T2.Level2,
               T2.Level3,
               T2.InsertTime,
               T2.UpdateTime,
               T2.JSID);
    COMMIT;
    O_CODE := 1;
    O_NOTE := 'TINFO_GMJJGGFL 表清洗成功';
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1; --运行失败
        O_NOTE := (CASE
                   WHEN O_NOTE IS NULL THEN
                     'TINFO_GMJJGGFL 表清洗,未知错误'
                   ELSE
                     'TINFO_GMJJGGFL 表清洗,在 ' || O_NOTE || ' 时出现异常'
                 END) || ':' || SQLERRM;
        ROLLBACK;
END P_TRAN_GMJJGGFL;
/

