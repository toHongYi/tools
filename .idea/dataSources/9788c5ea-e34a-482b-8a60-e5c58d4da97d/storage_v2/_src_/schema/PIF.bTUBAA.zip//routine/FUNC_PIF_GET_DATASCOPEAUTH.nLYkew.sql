create FUNCTION FUNC_PIF_GET_DATASCOPEAUTH(
                                                                               I_USERID IN NUMBER,--用户ID
                                                                               I_SCOPENAME IN VARCHAR --权限要素
                                                                               ) RETURN VARCHAR2 IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：获取权限要素
全部权限时候返回<ALL>,部分权限时，返回拼接的权限部门字符串
      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        wwh   1.0.0    2021/11/02                新增
  --------------------------------------------------------------------------------*/
  V_SCOPEEXPS VARCHAR2(32767);
  V_USERID NUMBER;
  V_SCOPENAME  VARCHAR2(200);
  V_COUNT NUMBER;
BEGIN

  V_USERID:=I_USERID;
  V_SCOPENAME:=I_SCOPENAME;
  
  
/*SELECT * FROM TPIF_ZDXS_CPK S WHERE EXISTS
 (SELECT 1 FROM  LIVEBOS.LBDATASCOPEAUTH T  WHERE   T.TYPE =0 AND T.MEMBERID =  4330 AND  EXISTS (SELECT 1 FROM
       livebos.lborganization WHERE ID = T.SCOPEEXP
     START WITH ID = S.SSBM
    CONNECT BY PRIOR fID = ID )  );*/
         SELECT COUNT(1) INTO V_COUNT FROM                    (   (SELECT CASE
                                        WHEN SCOPEEXP =183THEN
                                         '<ALL>'
                                        ELSE
                                         SCOPEEXP
                                    END  SCOPEEXP
                             FROM   LIVEBOS.LBDATASCOPEAUTH
                             WHERE  MEMBERID IN
                                    (SELECT ROLEID
                                     FROM   LIVEBOS.LBMEMBER
                                     WHERE  USERID = V_USERID)
                             AND    TYPE = 1
                             AND    SCOPENAME = V_SCOPENAME
                             
                             UNION 
                             
                             SELECT CASE
                                        WHEN SCOPEEXP = '183' THEN
                                         '<ALL>'
                                        ELSE
                                         SCOPEEXP
                                    END SCOPEEXP
                             FROM   LIVEBOS.LBDATASCOPEAUTH
                             WHERE  MEMBERID = V_USERID
                             AND    TYPE = 0
                             AND    SCOPENAME = V_SCOPENAME)) WHERE SCOPEEXP ='<ALL>';
    
    IF V_COUNT >0 THEN  
      RETURN '<ALL>';
      END IF;
      
  SELECT LISTAGG(ID, ',') WITHIN GROUP(ORDER BY ID) AS IDS
  INTO   V_SCOPEEXPS
  FROM   (SELECT ID
          FROM   LIVEBOS.LBORGANIZATION
          START  WITH ID IN (SELECT CASE
                                        WHEN SCOPEEXP = '<ALL>' THEN
                                         '183'
                                        ELSE
                                         SCOPEEXP
                                    END
                             FROM   LIVEBOS.LBDATASCOPEAUTH
                             WHERE  MEMBERID IN
                                    (SELECT ROLEID
                                     FROM   LIVEBOS.LBMEMBER
                                     WHERE  USERID = V_USERID)
                             AND    TYPE = 1
                             AND    SCOPENAME = V_SCOPENAME
                             
                             UNION 
                             
                             SELECT CASE
                                        WHEN SCOPEEXP = '<ALL>' THEN
                                         '183'
                                        ELSE
                                         SCOPEEXP
                                    END
                             FROM   LIVEBOS.LBDATASCOPEAUTH
                             WHERE  MEMBERID = V_USERID
                             AND    TYPE = 0
                             AND    SCOPENAME = V_SCOPENAME)
          CONNECT BY PRIOR ID = FID);

 RETURN  V_SCOPEEXPS;

  EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;


/

