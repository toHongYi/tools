create PROCEDURE PRO_SJQX_CP_BB_DBCPCETJ(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    I_RQ   IN NUMBER --统计日期
                                                    ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：指数增强代表产品超额中间表-计算（DSC_STAT.TPIF_STAT_BB_DBCPCETJ）
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-13     1.0       吴金锋              创建
          2021-05-14     1.1       高昆               因拆分而修改
  ***********************************************************************/
  V_COUNT   NUMBER;
  V_RQ      NUMBER;
  V_SR      NUMBER;
  V_RQ_BZ   NUMBER; -- 近1月
  V_RQ_JNYL NUMBER; -- 今年以来
  V_RQ_CLYL NUMBER; -- 成立以来

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --1. 统计日期获取，默认取传入的日期，如果传入日期为空则取上个交易日
  IF I_RQ IS NULL THEN
    --计算上个交易日的
    SELECT MAX(JYR)
      INTO V_RQ
      FROM LIVEBOS.TXTJYR A
     WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
  ELSE
    V_RQ := I_RQ;
  END IF;

  --V_RQ对应的上一个交易日
  SELECT MAX(JYR) INTO V_SR FROM LIVEBOS.TXTJYR A WHERE A.JYR < V_RQ;

  -- 本周
  /* SELECT MIN(JYR)
   INTO V_RQ_BZ
   FROM LIVEBOS.TXTJYR A
  WHERE A.ND = SUBSTR(V_RQ, 1, 4)
    AND A.ZH = (SELECT ZH FROM LIVEBOS.TXTJYR B WHERE B.ZRR = V_RQ);*/
  SELECT JYR
    INTO V_RQ_BZ
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(TRUNC(TO_DATE(V_RQ, 'yyyymmdd'), 'iw'), 'yyyymmdd');
  -- 今年以来
  SELECT JYR
    INTO V_RQ_JNYL
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR = TO_NUMBER(SUBSTR(V_RQ, 1, 4) || '0101');

  --2.清空当天表DSC_STAT.TPIF_STAT_BB_DBCPCETJ数据
  SELECT COUNT(1)
    INTO V_COUNT
    FROM DSC_STAT.TPIF_STAT_BB_DBCPCETJ
   WHERE RQ = V_RQ;
  IF V_COUNT > 0 THEN
    DELETE FROM DSC_STAT.TPIF_STAT_BB_DBCPCETJ WHERE RQ = V_RQ;
  END IF;

  --3.循环从 TPIF_SMCP 表中获取指数增强型产品,计算每只产品的超额值 19：指数增强
  FOR CUR_CP IN (SELECT *
                   FROM TPIF_CPDM_SMYY A
                  WHERE EXISTS (SELECT 1
                           FROM TPIF_SMCP B
                          WHERE A.ZYNM = B.DYCPID
                            AND B.SHZT = 2
                            AND B.SJCL = 19)
                    AND A.CLRQ <= V_RQ) LOOP
    --V_RQ_CLYL NUMBER;  -- 成立以来
    V_RQ_CLYL := CUR_CP.CLRQ;
  
    INSERT INTO DSC_STAT.TPIF_STAT_BB_DBCPCETJ
      (RQ,
       CPID,
       CPDM,
       CPMC,
       GLR,
       CLRQ,
       ZJZH,
       DR_ZSSPJ,
       ZZ500_RZF,
       DR_CPZC,
       DR_CRJ,
       SR_CPZC,
       DR_SZZR,
       DR_SZZC)
      SELECT V_RQ, CUR_CP.ID, CUR_CP.CPDM, CUR_CP.DYCPQC, （SELECT JGMC
        FROM TPIF_JGDM
       WHERE ID = CUR_CP.CPGLRID), CUR_CP.CLRQ, CUR_CP.GLKHH, A.ZSPJ, A.RZF,
      /*  NVL( (SELECT SUM(TOTAL_ASSET) RZC
       FROM SRC_PIF.DWD_AST_ACC_ASSET_DI_SPECIAL
      WHERE INIT_DATE = V_RQ
        AND INSTR( ','||CUR_CP.GLKHH||',' , ','||FUND_ACCOUNT||',' )>0) ,0 ),*/
      
       NVL((SELECT SUM(ZZC - ZFZ)
              FROM SRC_PIF.T_STAT_KHH_R
             WHERE RQ = V_RQ
               AND INSTR(',' || CUR_CP.GLKHH || ',',
                         ',' || KHH || ',') > 0), 0),
      
       NVL((SELECT SUM(CRJE - QCJE) AS CRJ
              FROM SRC_PIF.T_STAT_KHH_R
             WHERE RQ = V_RQ
               AND INSTR(',' || CUR_CP.GLKHH || ',',
                         ',' || KHH || ',') > 0), 0),
      
      /*NVL((SELECT SUM(OCCUR_BALANCE) AS CRJ
       FROM SRC_PIF.DWD_EVT_ACC_FUNDJOUR_DI_SPEC
      WHERE INIT_DATE = V_RQ
        AND INSTR( ','||CUR_CP.GLKHH||',' , ','||FUND_ACCOUNT||',' )>0
        AND BUSINESS_FLAG IN
            ( 2089,
              2102,
              2110,
              2020,
              2041,
              2064,
              2142,
              2414,
              2420,
              4196,
              2148,
              2405,
              2409,
              2005,
              2013,
              2007,
              2009,
              2003,
              2001,
              2002,
              2006,
              2147,
              2404,
              2415,
              2410,
              2419,
              2004,
              2141,
              2014,
              2042,
              2063,
              2015,
              2021,
              2022,
              2109,
              2008,
              2120,
              2010,
              2090,
              2101
              )),0),*/
      
      /* NVL((SELECT SUM(TOTAL_ASSET) RZC
       FROM SRC_PIF.DWD_AST_ACC_ASSET_DI_SPECIAL
      WHERE INIT_DATE = V_SR
        AND INSTR( ','||CUR_CP.GLKHH||',' , ','||FUND_ACCOUNT||',' )>0
        ),0),*/
       NVL((SELECT SUM(ZZC - ZFZ) AS CRJ
              FROM SRC_PIF.T_STAT_KHH_R
             WHERE RQ = V_SR
               AND INSTR(',' || CUR_CP.GLKHH || ',',
                         ',' || KHH || ',') > 0), 0),
      
       NVL((SELECT SUM(ZRZQSZ) AS CRJ
              FROM SRC_PIF.T_STAT_KHH_R
             WHERE RQ = V_RQ
               AND INSTR(',' || CUR_CP.GLKHH || ',',
                         ',' || KHH || ',') > 0), 0),
      /*NVL((SELECT SUM(SZZR) 
      FROM (SELECT SUM(M.BUSINESS_AMOUNT * M.BUSINESS_PRICE) AS SZZR
      FROM SRC_PIF.DWD_EVT_DELIVER_DI_SPEC M   
      WHERE M.INIT_DATE =  V_RQ
       AND  INSTR( ','||CUR_CP.GLKHH||',' , ','||M.FUND_ACCOUNT||',' )>0
       AND  M.BUSINESS_FLAG IN(4028,4007,4017,4019,4136,4016,4009,4014)*/
      /* UNION ALL
      SELECT SUM(N.OCCUR_AMOUNT) AS SZZR
      FROM SRC_PIF.DWD_EVT_STOCKJOUR_DI_SPEC N
      WHERE N.INIT_DATE = V_RQ
       AND  INSTR( ','||CUR_CP.GLKHH||',' , ','||N.FUND_ACCOUNT||',' )>0
       AND N.BUSINESS_FLAG=3001)),0),*/
      
       NVL((SELECT SUM(ZCZQSZ) AS CRJ
              FROM SRC_PIF.T_STAT_KHH_R
             WHERE RQ = V_RQ
               AND INSTR(',' || CUR_CP.GLKHH || ',',
                         ',' || KHH || ',') > 0), 0)
      
      /* NVL((SELECT SUM(SZZC) 
      FROM (SELECT SUM(M.BUSINESS_AMOUNT * M.BUSINESS_PRICE) AS SZZC
      FROM SRC_PIF.DWD_EVT_DELIVER_DI_SPEC M   
      WHERE M.INIT_DATE =  V_RQ
       AND  INSTR( ','||CUR_CP.GLKHH||',' , ','||M.FUND_ACCOUNT||',' )>0
       AND  M.BUSINESS_FLAG IN(4029,4008,4010,3002)*/
      /*UNION ALL
      SELECT SUM(N.OCCUR_AMOUNT) AS SZZC
      FROM SRC_PIF.DWD_EVT_STOCKJOUR_DI_SPEC N
      WHERE N.INIT_DATE = V_RQ
       AND  INSTR( ','||CUR_CP.GLKHH||',' , ','||N.FUND_ACCOUNT||',' )>0
       AND N.BUSINESS_FLAG=4135)),0)*/
      
       FROM DSC_STAT.TPIF_STAT_ZSHQ A
       WHERE A.SJRQ = V_RQ
         AND A.ZSDM = '000905.SH';
  
  END LOOP;

  --更新 产品日涨幅  产品日超额,产品周超额
  UPDATE DSC_STAT.TPIF_STAT_BB_DBCPCETJ A
     SET A.CP_RZF = (CASE
                      WHEN SR_CPZC = 0 THEN
                       0
                      ELSE
                       (DR_CPZC - DR_CRJ - A.DR_SZZR + A.DR_SZZC - SR_CPZC) * 100 /
                       SR_CPZC
                    END)
   WHERE A.RQ = V_RQ;

  UPDATE DSC_STAT.TPIF_STAT_BB_DBCPCETJ A
     SET A.DR_LJCE = (CASE
                       WHEN A.SR_CPZC = 0 THEN
                        0
                       ELSE
                        (A.CP_RZF - A.ZZ500_RZF)
                     END)
   WHERE A.RQ = V_RQ;

  --更新 周度累计超额、今年以来,成立以来累计超额
  UPDATE DSC_STAT.TPIF_STAT_BB_DBCPCETJ A
     SET A.BZLY_LJCE =
         (SELECT SUM(DR_LJCE)
            FROM DSC_STAT.TPIF_STAT_BB_DBCPCETJ B
           WHERE B.CPID = A.CPID
             AND B.RQ >= V_RQ_BZ
             AND B.RQ <= V_RQ),
         A.JNYL_LJCE =
         (SELECT SUM(DR_LJCE)
            FROM DSC_STAT.TPIF_STAT_BB_DBCPCETJ B
           WHERE B.CPID = A.CPID
             AND B.RQ >= V_RQ_JNYL
             AND B.RQ <= V_RQ),
         A.CLYL_LJCE =
         (SELECT SUM(DR_LJCE)
            FROM DSC_STAT.TPIF_STAT_BB_DBCPCETJ B
           WHERE B.CPID = A.CPID)
   WHERE A.RQ = V_RQ;

  COMMIT;

  O_CODE := 1;
  O_NOTE := '指数增强代表产品超额中间表-计算清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '指数增强代表产品超额中间表-清洗失败' || SQLERRM;
END;
/

