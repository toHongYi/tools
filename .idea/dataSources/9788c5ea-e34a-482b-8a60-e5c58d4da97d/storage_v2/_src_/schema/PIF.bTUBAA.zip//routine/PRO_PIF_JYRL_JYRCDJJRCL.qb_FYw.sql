create PROCEDURE PRO_PIF_JYRL_JYRCDJJRCL(O_CODE    OUT NUMBER, --返回值
                                                    O_NOTE    OUT VARCHAR2, --返回消息
                                                    I_DATE    IN DATE, --处理日期
                                                    I_NEWDDGZ IN NUMBER, --新定点规则
                                                    I_YWLX    IN NUMBER, --业务类型
                                                    I_YXJYR   IN NUMBER, --运行交易日
                                                    I_CZR     IN NUMBER DEFAULT NULL --操作人
                                                    ) IS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：根据规则记录刷新产品交易日历
            输入日期, 单独处理这一天的产品交易日历
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-06-27     V1.0      谢莉莉             创建
      2016-10-19     V2.0      王大一             托管系统迁移改造接入产品中心
      2021-10-12                  WWH             新增加入前后两个日期的规则
      2021-12-02     V2.1      韩乔楠             支持节假日规则1|节假日前的最近一个工作日
   *********************************************************************************************************************/
  V_CPID         NUMBER; --产品ID
  V_CPDM         VARCHAR2(300); --产品代码
  V_DDGZ         NUMBER; --定点规则
  V_JYRCD        NUMBER; --交易日长度
  V_JYR          NUMBER; --交易日处理用
  V_COUNT        NUMBER; --判断
  V_DATE         DATE; --处理日期
  V_RLID         NUMBER; --日历ID
  V_FLAG         NUMBER; --标志
  V_RQYD         NUMBER; --前移或后移
  V_GZLX         NUMBER; --规则类型
  V_GZMC         VARCHAR2(300); --定点规则名称
  V_JJRCL        NUMBER; --节假日规则:1|节假日前的最近一个工作日;2|节假日后的最近一个工作日
  V_JJNF         NUMBER; --节假年份
  V_SHZT         NUMBER; --审核状态
  V_BH           VARCHAR2(100); --编号
  V_GZ1          VARCHAR2(100) := 'R22'; --特殊处理 每月单一开放日（支持冷静期）
  V_GZ2          VARCHAR2(100) := 'R23'; --特殊处理 每月最后一个工作日（支持冷静期）
  V_GZ3          VARCHAR2(100) := 'R24'; --特殊处理 固定月单一开放日（支持冷静期）
  V_GZ4          VARCHAR2(100) := 'R25'; --特殊处理 固定月第固定个星期的固定日（支持冷静期）
  V_GZ5          VARCHAR2(100) := 'R26'; --特殊处理 固定月最后一个交易日（支持冷静期）
  V_GZ6          VARCHAR2(100) := 'R58'; --特殊处理 成立日期及每年对日（支持冷静期）
  V_GZ7          VARCHAR2(100) := 'R27'; --R27,固定月第N个交易日（支持冷静期）
  V_GZ8          VARCHAR2(100) := 'R28'; --R28,固定月第N个自然日（支持冷静期
  V_DATE_PRE     DATE; --前一天
  V_DATE_PRE_2   DATE; --前2天
  V_DATE_CURR    DATE; --当前工作日或者下一个工作日 
  V_SM           VARCHAR2(1000); --说明
  V_GZYWLX       VARCHAR2(100); --该条规则记录的业务类型
  STR_CURR_DATE  VARCHAR2(100); --T日字符串类型
  STR_PRE_DATE   VARCHAR2(100); --T-1日字符串类型
  STR_PRE_2_DATE VARCHAR2(100); --T-2日字符串类型
  V_LOOP_ID      NUMBER; --循环临时变量
BEGIN
  O_CODE := 1;
  O_NOTE := '操作成功！';
  V_JYR  := 1;
  V_FLAG := 0;
  V_DATE := I_DATE;

  --取得产品ID, 交易日类型, 业务类型, 定点规则, 交易日长度, 节假日处理
  SELECT CPID,
         CPDM /*,YXJYR,YWLX*/,
         DDGZ,
         JYRCD,
         JJRCLGZ,
         DECODE(JJRCLGZ, 1, -1, 2, 1, 3, 7, 0),
         GZJLLX,
         SHZT,
         YWLX
    INTO V_CPID,
         V_CPDM /*,V_JYRLX,V_YWLX*/,
         V_DDGZ,
         V_JYRCD,
         V_JJRCL,
         V_RQYD,
         V_GZLX,
         V_SHZT,
         V_GZYWLX
    FROM TPIF_JYRL_GZJL
   WHERE ID = I_NEWDDGZ;

  --取得编号, 对R22 R23 R24 R25 R26进行特殊处理, 交易日长度、节假日处理单独处理
  SELECT BH INTO V_BH FROM TPIF_JYRL_DDGZ WHERE ID = V_DDGZ;

  --取得定点规则编号
  IF (V_GZLX = 1) THEN
    SELECT GZMC INTO V_GZMC FROM TPIF_JYRL_DDGZ WHERE ID = V_DDGZ;
    --关联交易日节假日长度不需要再次处理
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL_YXJYR
     WHERE ID = I_YXJYR
       AND GLJYR IS NOT NULL;
    IF (V_COUNT > 0) THEN
      V_JYRCD := 1;
    END IF;
  
  ELSE
    V_GZMC  := ' ';
    V_JYRCD := 1;
  
    --特殊规则：该日期已存在, 返回
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL
     WHERE CPID = V_CPID
       AND JYRLX = I_YXJYR
       AND YWLX = I_YWLX
       AND RQ = V_DATE
       AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0
       AND JJRCLGZ IS NULL;
    IF (V_COUNT > 0) THEN
      RETURN;
    END IF;
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL
     WHERE CPID = V_CPID
       AND JYRLX = I_YXJYR
       AND YWLX = I_YWLX
       AND RQ = V_DATE
       AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0
       AND JJRCLGZ IS NOT NULL;
    --取得配置的最新节假日年份
    SELECT MAX(NF) INTO V_JJNF FROM LIVEBOS.tJRXX;
    IF (V_COUNT > 0) THEN
      --取得特殊规则节假日处理
      SELECT DECODE(JJRCLGZ, 1, -1, 2, 1, 0)
        INTO V_RQYD
        FROM TPIF_JYRL
       WHERE CPID = V_CPID
         AND JYRLX = I_YXJYR
         AND YWLX = I_YWLX
         AND RQ = V_DATE
         AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0
         AND JJRCLGZ IS NOT NULL;
      --特殊规则：清空节假日处理数据
      UPDATE TPIF_JYRL
         SET JJRCLGZ = ''
       WHERE CPID = V_CPID
         AND JYRLX = I_YXJYR
         AND YWLX = I_YWLX
         AND RQ = V_DATE
         AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0
         AND JJRCLGZ IS NOT NULL;
      IF (SUBSTR(TO_CHAR(V_DATE, 'YYYYMMDD'), 0, 4) > V_JJNF) THEN
        RETURN;
      END IF;
    END IF;
  END IF;

  --取得工作日
  --V_DATE := FUNC_PIF_JYRL_JYRCDJJRCL(I_DATE,V_JJRCL);

  IF (FUNC_PIF_JYRL_JJRPD(V_DATE) > 0) THEN
    IF (V_GZLX = 2) THEN
    
      --清除该日期的数据
      IF (V_COUNT > 0) THEN
        --删除交易日历中规则记录为I_NEWDDGZ的数据
        DELETE FROM TPIF_JYRL
         WHERE (RQ = V_DATE AND CPID = V_CPID AND JYRLX = I_YXJYR AND
               YWLX = I_YWLX AND GZJL = TO_CHAR(I_NEWDDGZ));
        --删除交易日历中规则记录包含I_NEWDDGZ的数据
        UPDATE TPIF_JYRL
           SET GZJL = rtrim(ltrim(REPLACE(';' || GZJL || ';',
                                          ';' || I_NEWDDGZ || ';',
                                          ';'),
                                  ';'),
                            ';')
         WHERE (RQ = V_DATE AND CPID = V_CPID AND JYRLX = I_YXJYR AND
               YWLX = I_YWLX AND INSTR(GZJL, ';' || I_NEWDDGZ || ';') > 0);
      END IF;
    END IF;
  
    IF (V_RQYD != 0) THEN
      V_DATE := FUNC_PIF_JYRL_QJGGZR(V_DATE, V_RQYD);
    ELSE
      --节假日不处理
      RETURN;
    END IF;
  ELSE
    IF (V_GZLX = 2 AND V_COUNT > 0) THEN
      RETURN;
    END IF;
  END IF;

  --对支持冷静期进行特殊处理,  V_GZ1:='R22';V_GZ2:='R23';V_GZ3:='R24';V_GZ4:='R25';V_GZ5:='R26'
  --IF V_BH = V_GZ1 OR V_BH = V_GZ2 OR V_BH = V_GZ3 OR V_BH = V_GZ4 OR V_BH = V_GZ5 THEN
  IF V_BH IN (V_GZ1, V_GZ2, V_GZ3, V_GZ4, V_GZ5, V_GZ6, V_GZ7, V_GZ8) THEN
    --判断当前日期是否为节假日或者周末, 0为非节假日, 1为节假日
    IF (FUNC_PIF_JYRL_JJRPD(I_DATE) = 0) THEN
      V_DATE_CURR := I_DATE;
      V_DATE_PRE  := FUNC_PIF_JYRL_QJGGZR(I_DATE, -1);
    ELSE
      IF V_JJRCL = 1 THEN
        --1|节假日前的最近一个工作日
        V_DATE_CURR := FUNC_PIF_JYRL_QJGGZR(I_DATE, -1);
        V_DATE_PRE  := FUNC_PIF_JYRL_QJGGZR(I_DATE, -2);
      ELSE
        --2|节假日后的最近一个工作日            
        V_DATE_CURR := FUNC_PIF_JYRL_QJGGZR(I_DATE, 1);
        V_DATE_PRE  := FUNC_PIF_JYRL_QJGGZR(I_DATE, -1);
      END IF;
    END IF;
    SELECT TO_CHAR(V_DATE_PRE, 'yyyymmdd') INTO STR_PRE_DATE FROM DUAL;
    SELECT TO_CHAR(V_DATE_CURR, 'yyyymmdd') INTO STR_CURR_DATE FROM DUAL;
    --申购+赎回
    IF V_GZYWLX = '7;8' THEN
      IF I_YWLX = 7 THEN
        V_SM := '自然人客户及普通法人机构客户在' || STR_PRE_DATE || '进行申购, ' ||
                STR_CURR_DATE || ' 回访+赎回, 外规规定的特殊合格投资者 ' || STR_CURR_DATE ||
                ' 申购';
      END IF;
      --申购
    ELSIF V_GZYWLX = '7' THEN
      IF I_YWLX = 7 THEN
        V_SM := '自然人客户及普通法人机构客户在' || STR_PRE_DATE || '进行申购, ' ||
                STR_CURR_DATE || ' 回访, 外规规定的特殊合格投资者 ' || STR_CURR_DATE ||
                ' 申购';
      END IF;
    END IF;
  
    --判断该日期是否已经存在
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL
     WHERE CPID = V_CPID
       AND JYRLX = I_YXJYR
       AND YWLX = I_YWLX
       AND RQ = V_DATE_PRE;
    --没有其他规则生成的数据就直接插入
    IF V_COUNT = 0 THEN
      IF I_YWLX = 7 THEN
        V_RLID := LIVEBOS.FUNC_NEXTID('TPIF_JYRL');
        INSERT INTO TPIF_JYRL
          (ID, RQ, CPID, CPDM, JYRLX, YWLX, GZJL, SHTGGZJL, CZR, SM)
        VALUES
          (V_RLID,
           V_DATE_PRE,
           V_CPID,
           V_CPDM,
           I_YXJYR,
           I_YWLX,
           I_NEWDDGZ,
           DECODE(V_SHZT, 1, I_NEWDDGZ, ''),
           I_CZR,
           V_SM);
      END IF;
    ELSE
      IF I_YWLX = 7 THEN
        UPDATE TPIF_JYRL
           SET SM =
               (CASE
                 WHEN (V_SM = SM OR TRIM(V_SM) IS NULL) THEN
                  SM
                 ELSE
                  (V_SM || ', ' || SM)
               END)
         WHERE CPID = V_CPID
           AND JYRLX = I_YXJYR
           AND YWLX = I_YWLX
           AND RQ = V_DATE_PRE;
        COMMIT;
      END IF;
    END IF;
  
    --判断该日期是否已经存在
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL
     WHERE CPID = V_CPID
       AND JYRLX = I_YXJYR
       AND YWLX = I_YWLX
       AND RQ = V_DATE_CURR;
    --没有其他规则生成的数据就直接插入
    IF V_COUNT = 0 THEN
      V_RLID := LIVEBOS.FUNC_NEXTID('TPIF_JYRL');
      INSERT INTO TPIF_JYRL
        (ID, RQ, CPID, CPDM, JYRLX, YWLX, GZJL, SHTGGZJL, CZR, SM)
      VALUES
        (V_RLID,
         V_DATE_CURR,
         V_CPID,
         V_CPDM,
         I_YXJYR,
         I_YWLX,
         I_NEWDDGZ,
         DECODE(V_SHZT, 1, I_NEWDDGZ, ''),
         I_CZR,
         V_SM);
    ELSE
      IF I_YWLX = 7 THEN
        UPDATE TPIF_JYRL
           SET SM =
               (CASE
                 WHEN (V_SM = SM OR TRIM(V_SM) IS NULL) THEN
                  SM
                 ELSE
                  (V_SM || ', ' || SM)
               END)
         WHERE CPID = V_CPID
           AND JYRLX = I_YXJYR
           AND YWLX = I_YWLX
           AND RQ = V_DATE_CURR;
        COMMIT;
      END IF;
    END IF;
  
    V_LOOP_ID := 1;
    -- 通过循环，支持交易日长度
    WHILE V_LOOP_ID < V_JYRCD LOOP
      V_DATE_PRE_2 := FUNC_PIF_JYRL_QJGGZR(V_DATE_CURR, V_LOOP_ID);
      SELECT TO_CHAR(V_DATE_PRE_2, 'yyyymmdd')
        INTO STR_PRE_2_DATE
        FROM DUAL;
    
      --申购+赎回
      IF V_GZYWLX = '7;8' THEN
        IF I_YWLX = 7 THEN
          V_SM := '自然人客户及普通法人机构客户在' || STR_CURR_DATE || '进行申购, ' ||
                  STR_PRE_2_DATE || ' 回访+赎回, 外规规定的特殊合格投资者 ' ||
                  STR_PRE_2_DATE || ' 申购';
        END IF;
        --申购
      ELSIF V_GZYWLX = '7' THEN
        IF I_YWLX = 7 THEN
          V_SM := '自然人客户及普通法人机构客户在' || STR_CURR_DATE || '进行申购, ' ||
                  STR_PRE_2_DATE || ' 回访, 外规规定的特殊合格投资者 ' || STR_PRE_2_DATE ||
                  ' 申购';
        END IF;
      END IF;
      -- 更新上日的SM
      UPDATE TPIF_JYRL
         SET SM = (CASE
                    WHEN (V_SM = SM OR TRIM(V_SM) IS NULL) THEN
                     SM
                    ELSE
                     (V_SM || ', ' || SM)
                  END)
       WHERE CPID = V_CPID
         AND JYRLX = I_YXJYR
         AND YWLX = I_YWLX
         AND RQ = V_DATE_CURR;
      --判断该日期是否已经存在
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_JYRL
       WHERE CPID = V_CPID
         AND JYRLX = I_YXJYR
         AND YWLX = I_YWLX
         AND RQ = V_DATE_PRE_2;
      --没有其他规则生成的数据就直接插入
      IF V_COUNT = 0 THEN
        --当天
        V_RLID := LIVEBOS.FUNC_NEXTID('TPIF_JYRL');
        INSERT INTO TPIF_JYRL
          (ID, RQ, CPID, CPDM, JYRLX, YWLX, GZJL, SHTGGZJL, CZR, SM)
        VALUES
          (V_RLID,
           V_DATE_PRE_2,
           V_CPID,
           V_CPDM,
           I_YXJYR,
           I_YWLX,
           I_NEWDDGZ,
           DECODE(V_SHZT, 1, I_NEWDDGZ, ''),
           I_CZR,
           V_SM);
      ELSE
        UPDATE TPIF_JYRL
           SET SM = (CASE
                      WHEN (V_SM = SM OR TRIM(V_SM) IS NULL) THEN
                       SM
                      ELSE
                       (V_SM || ', ' || SM)
                    END)
         WHERE CPID = V_CPID
           AND JYRLX = I_YXJYR
           AND YWLX = I_YWLX
           AND RQ = V_DATE_PRE_2;
        COMMIT;
      END IF;
    
      V_LOOP_ID := V_LOOP_ID + 1;
    END LOOP;
  
    RETURN;
  END IF;

  --交易日长度和节假日处理
  WHILE (V_JYR <= V_JYRCD) LOOP
    IF (V_JYRCD > 1 AND V_JYR != 1) THEN
      V_DATE := FUNC_PIF_JYRL_QJGGZR(V_DATE, V_RQYD);
    END IF;
    <<next_x_loop>>
  --判断该日期是否已经存在
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JYRL
     WHERE CPID = V_CPID
       AND JYRLX = I_YXJYR
       AND YWLX = I_YWLX
       AND RQ = V_DATE;
    IF (V_COUNT = 0) THEN
      V_RLID := LIVEBOS.FUNC_NEXTID('TPIF_JYRL');
      INSERT INTO TPIF_JYRL
        (ID, RQ, CPID, CPDM, JYRLX, YWLX, GZJL, SHTGGZJL, CZR)
      VALUES
        (V_RLID,
         V_DATE,
         V_CPID,
         V_CPDM,
         I_YXJYR,
         I_YWLX,
         I_NEWDDGZ,
         DECODE(V_SHZT, 1, I_NEWDDGZ, ''),
         I_CZR);
    
      COMMIT;
    ELSIF (INSTR(V_GZMC, '工作日') = 0 OR INSTR(V_GZMC, '交易日') = 0) THEN
      --判断该规则该日期是否已经存在, 如果存在向后移动
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_JYRL
       WHERE CPID = V_CPID
         AND JYRLX = I_YXJYR
         AND YWLX = I_YWLX
         AND RQ = V_DATE
         AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0;
    
      IF (V_COUNT = 0) THEN
      
        SELECT ID
          INTO V_RLID
          FROM TPIF_JYRL
         WHERE CPID = V_CPID
           AND JYRLX = I_YXJYR
           AND YWLX = I_YWLX
           AND RQ = V_DATE;
      
        UPDATE TPIF_JYRL
           SET GZJL = GZJL || ';' || I_NEWDDGZ, CZR = I_CZR
         WHERE ID = V_RLID;
        --审核通过处理
        IF (V_SHZT = 1) THEN
          UPDATE TPIF_JYRL
             SET SHTGGZJL = SHTGGZJL || ';' || I_NEWDDGZ
           WHERE ID = V_RLID;
        END IF;
        V_FLAG := 0;
        COMMIT;
      END IF;
    
      WHILE (V_COUNT > 0) LOOP
        V_FLAG := 1;
        V_DATE := FUNC_PIF_JYRL_QJGGZR(V_DATE, V_RQYD);
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JYRL
         WHERE CPID = V_CPID
           AND JYRLX = I_YXJYR
           AND YWLX = I_YWLX
           AND RQ = V_DATE
           AND INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0;
      END LOOP;
      IF (V_FLAG = 1) THEN
        goto next_x_loop;
      END IF;
    END IF;
    V_JYR := V_JYR + 1;
    --V_DATE := FUNC_PIF_JYRL_QJGGZR(V_DATE,1);
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
    ROLLBACK;
END PRO_PIF_JYRL_JYRCDJJRCL;
/

