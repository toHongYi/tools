create PROCEDURE PRO_PIF_JYRL_JZJYR_CSH(O_CODE OUT NUMBER, --返回值
                                                       O_NOTE OUT VARCHAR2 --返回消息
                                                       ) IS
    /*
    **功能说明：基准交易日初始化
    **创建人：王大一
    **创建日期：2016-11-03
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **王大一     V1.0.0    2016-11-03   创建
    **王大一     V1.0.1    2016-11-04   募集起始日改为认购开始日期
    **王大一     V1.0.2    2016-11-07   取备案日期
    **孙远何     V1.0.3    2017-06-16   取消备案日期

    */
    V_COUNT INTEGER; --计数变量
BEGIN
    O_CODE := 1;
    O_NOTE := '';
    FOR CUR IN (SELECT TY.CPID, TY.CPDM, TY.CLRQ CPCLR, TY.DQRQ CPDQR, NULL AS CPBAR
                  FROM TPIF_CPDM TY) LOOP
        BEGIN
            SELECT COUNT(0) INTO V_COUNT FROM TPIF_JYRL_JZJYR WHERE CPID = CUR.CPID;
        EXCEPTION
            WHEN OTHERS THEN
                V_COUNT := 0;
        END;

        IF V_COUNT = 0 THEN
            INSERT INTO TPIF_JYRL_JZJYR
                (ID, CPID, CPDM, RGKSRQ, CPCLR, CPBAR, FBQQSR, FBQJSR, CPDQR, QTJZR)
            VALUES
                (LIVEBOS.FUNC_NEXTID('TPIF_JYRL_JZJYR'),
                 CUR.CPID,
                 CUR.CPDM,
                 NULL,
                 CUR.CPCLR,
                 CUR.CPBAR,
                 NULL,
                 NULL,
                 CUR.CPDQR,
                 NULL);
        ELSE
            UPDATE TPIF_JYRL_JZJYR
               SET CPCLR = NVL(CUR.CPCLR, CPCLR), CPDQR = NVL(CUR.CPDQR, CPDQR)
             WHERE CPID = CUR.CPID;
        END IF;
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JYRL_JZJYR_CSH;
/

