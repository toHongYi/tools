create procedure pcx_pif_cpqj_jjjlgk_out(o_code            out number,
                                                o_note            out varchar2,
                                                o_result          out sys_refcursor,
                                                i_userid          in number, --用户ID
                                                i_ip                in varchar2,
                                                i_fund_magager_no in varchar2, --基金经理编号
                                                i_prod_id         in number --产品id
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-查询基金经理概况
  所属用户：PIF
  概要说明：查询基金经理概况.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金经理概况.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql        varchar2(32767);
  v_best_ratio varchar2(100);
  v_zz_rq      number(8);
  v_cyjy       number(8); --从业经验
  v_rqsc_n     number(5); --任期时长_年
  v_rqsc_t     number(5); --任期时长_天
  v_zgm        number(19, 4); --管理基金总规模
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_prod_id is null then
    o_note := '产品ID不允许为空！';
    return;
  end if;
  if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;
  --获取最佳回报率
  select max(a.period_yield_payback_ratio)
    into v_best_ratio
    from pif.tfund_manager_info a
   where a.fund_manager_no = i_fund_magager_no;

  --获取最早任期时间
  select min(a.assume_office_begin_time)
    into v_zz_rq
    from pif.tfund_manager_info a
   where a.fund_manager_no = i_fund_magager_no;
  --获取从业经验
  select round((sysdate - to_date(to_char(v_zz_rq), 'yyyymmdd')) / 365)
    into v_cyjy
    from dual;
  --获取任期时长_天
  select mod((nvl(to_date(to_char(a.assume_office_end_time), 'yyyymmdd'),
                  sysdate) -
             to_date(to_char(a.assume_office_begin_time), 'yyyymmdd')),
             365)
    into v_rqsc_t
    from pif.tfund_manager_info a
   where a.prod_id = i_prod_id
     and a.fund_manager_no = i_fund_magager_no;
  --获取任期时长_年
  select trunc((nvl(to_date(to_char(a.assume_office_end_time), 'yyyymmdd'),
                    sysdate) -
               to_date(to_char(a.assume_office_begin_time), 'yyyymmdd')) / 365,
               0)
    into v_rqsc_n
    from pif.tfund_manager_info a
   where a.prod_id = i_prod_id
     and a.fund_manager_no = i_fund_magager_no;

  --基金总规模
  select sum(a.prod_scale_amount)
    into v_zgm
    from tprod_basic_info a,
         (select prod_id
            from tfund_manager_info b
           where b.fund_manager_no = i_fund_magager_no) c
   where a.id = c.prod_id;

  v_sql := ' select a.name,
                    a.sex,
                    a.edu,
                    a.brief_intr,
                    a.image,
                    ''' || v_cyjy || '年''  occupation_experience,' || '
                    ''' || v_rqsc_n || '年' || v_rqsc_t ||
           '天 ''  assume_office_duration,' || '
                    ' || v_zgm || ' total_scale,' || '
                    ' || case when v_best_ratio is null then '''暂无信息''' else v_best_ratio end ||
           ' best_period_payback_ratio
             from pif.tfund_manager_info a
             where prod_id = ' || i_prod_id || '
             and fund_manager_no = ' || '''' || i_fund_magager_no || '''';
  dbms_output.put_line(v_sql);
  open o_result for v_sql;

  o_code := 0;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end pcx_pif_cpqj_jjjlgk_out;
/

