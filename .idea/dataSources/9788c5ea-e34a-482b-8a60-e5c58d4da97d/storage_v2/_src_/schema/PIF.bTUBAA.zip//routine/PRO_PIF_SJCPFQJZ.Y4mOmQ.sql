create PROCEDURE PRO_PIF_SJCPFQJZ(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_CPDM IN VARCHAR2 --产品代码
                                             ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：计算产品复权净值
      语法信息：
           输入参数：
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-07-27     1.0.1     hanqiaonan         新增
  ***********************************************************************/
  V_COUNT INTEGER; --计数变量

BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '';

  --CHECK
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM WHERE CPDM = I_CPDM;
  IF V_COUNT = 0 THEN
    O_CODE := -1;
    O_NOTE := '产品代码不存在';
    RETURN;
  END IF;

  UPDATE TPIF_CPJZXX_CPZX A --每个产品第一条记录的复权净值
     SET A.FQJZ =
         (A.DWJZ * (A.LJJZ - A.DWJZ + 1))
   WHERE A.JZRQ =
         (SELECT MIN(B.JZRQ) FROM TPIF_CPJZXX_CPZX B WHERE A.CPID = B.CPID)
     AND CPDM = I_CPDM;

  --后续的复权净值
  FOR CUR_CP IN (SELECT A.CPID,
                        A.JZRQ,
                        A.RZF,
                        LAG(A.JZRQ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRJZRQ
                   FROM TPIF_CPJZXX_CPZX A
                  WHERE CPDM = I_CPDM) LOOP
    UPDATE TPIF_CPJZXX_CPZX B
       SET B.FQJZ = ROUND((CUR_CP.RZF + 1) *
                          (SELECT FQJZ
                             FROM TPIF_CPJZXX_CPZX
                            WHERE JZRQ = CUR_CP.ZRJZRQ
                              AND CPID = CUR_CP.CPID),
                          4)
     WHERE CUR_CP.ZRJZRQ > 0
       AND B.CPID = CUR_CP.CPID
       AND B.JZRQ = CUR_CP.JZRQ;
   
   --更新产品最新净值表复权净值    
   UPDATE TPIF_CPZXJZ T
      SET FQJZ =
          (SELECT FQJZ FROM TPIF_CPJZXX_CPZX WHERE CPDM = T.CPDM AND JZRQ=T.JZRQ)
    WHERE CPDM = I_CPDM;
    
  END LOOP;
  O_NOTE := '产品复权净值计算成功！';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_SJCPFQJZ;
/

