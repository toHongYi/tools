create PROCEDURE PRO_PIF_ZZHTGLLS_TEST(O_CODE   OUT NUMBER, --返回值
                                                  O_NOTE   OUT VARCHAR2, --返回消息
                                                  I_CPID   IN NUMBER, --产品id
                                                  I_HTXZ   IN VARCHAR2, --合同选择
                                                  I_HTQSZT IN NUMBER, --合同签署状态
                                                  I_YYB    IN NUMBER, --营业部
                                                  I_SQBH   IN VARCHAR2, --申请编号
                                                  I_KDDH   IN VARCHAR2, --快递单号
                                                  I_LCZT   IN NUMBER, --流程状态 1|提交;2|驳回;3|结束
                                                  I_SQLC   IN NUMBER --1|合同申请;2|合同寄回;3|总部寄出
                                                  ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：纸质合同管理流程
      语法信息：
           输入参数：   I_CPID   IN NUMBER, --
                       I_HTXZ   IN VARCHAR2, --合同选择
                       I_HTQSZT IN NUMBER,
                       I_YYB    IN NUMBER, --营业部
                       I_SQBH   IN VARCHAR2, --申请编号
                       I_KDDH   IN VARCHAR2,
                       I_SQLC   IN NUMBER --1|合同申请;2|合同寄回;3|总部寄出
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-11-18     1.0.0    LTX                 创建
  ***********************************************************************/

  V_OBJ  TPIF_CPDM%ROWTYPE; --表单记录
  V_HTBH VARCHAR2(100);
  V_ZT   NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_CPDM WHERE ID = I_CPID;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  FOR CUR IN (SELECT REGEXP_SUBSTR(I_HTXZ, '[^;]+', 1, LEVEL, 'i') AS HTBH
                FROM DUAL T
              CONNECT BY LEVEL <=
                         LENGTH(I_HTXZ) -
                         LENGTH(REGEXP_REPLACE(I_HTXZ, ';', '')) + 1) LOOP
  
    SELECT HTBH, ZT
      INTO V_HTBH, V_ZT
      FROM TPIF_CPHT
     WHERE CPID = I_CPID
       AND ID = CUR.HTBH;
  
    INSERT INTO PIF.TPIF_HTLSCX
      (ID,
       CPID,
       CPDM,
       CPMC,
       HTBH,
       HTZT,
       HTQSZT,
       YYB,
       SQBH,
       SQLC,
       KDDH,
       CZSJ,
       LCZT)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
       I_CPID,
       V_OBJ.CPDM,
       V_OBJ.CPMC,
       V_HTBH,
       V_ZT,
       I_HTQSZT,
       I_YYB,
       I_SQBH,
       DECODE(I_SQLC, 1, '合同申请流程', 2, '合同寄回流程', 3, '总部寄出流程'),
       I_KDDH,
       SYSDATE,
       DECODE(I_LCZT, 1, '提交', 2, '驳回', 3, '结束'));
  
  END LOOP;

  COMMIT;
  O_CODE := 199;
  SELECT '执行成功!' INTO O_NOTE FROM DUAL;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_ZZHTGLLS_TEST;
/

