create PROCEDURE PRO_PIF_RWFP(O_CODE OUT NUMBER,
                                         O_NOTE OUT VARCHAR2,
                                         I_USERID IN NUMBER,
                                         I_RWID IN NUMBER)    --任务id
                                         AS


BEGIN
  O_CODE := 1;
  O_NOTE := '成功！';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'USERID不允许为空！';
    RETURN;
  END IF;

  IF I_RWID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'RWID不允许为空！';
    RETURN;
  END IF;

  --选择当前任务的任务分配表格
  FOR CUR IN(SELECT * FROM PIF.TPIF_YYCSRW_RWFP WHERE TPIF_YYCSRW_ID=I_RWID)  LOOP

  --插入到子任务表中
    INSERT INTO PIF.TPIF_ZRW
      (ID, RWBT, YYB, ZT, BZ, ZHXGR, ZHXGSJ, JZRQ, KSRQ, CSMB, GMMB)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_ZRW'),
       I_RWID,
       CUR.YYB,
       1,
       CUR.BZ,
       I_USERID,
       SYSDATE,
       CUR.JZRQ,
       CUR.KSRQ,
       CUR.CSMB,
       CUR.GMMB
       );

  END LOOP;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

