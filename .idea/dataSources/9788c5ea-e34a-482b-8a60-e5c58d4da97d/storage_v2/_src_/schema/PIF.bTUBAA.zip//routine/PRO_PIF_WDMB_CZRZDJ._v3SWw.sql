create PROCEDURE PRO_PIF_WDMB_CZRZDJ(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_USER IN INTEGER, --操作人
                                                I_IP   IN VARCHAR2, --操作IP
                                                I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;
                                                I_ID   IN INTEGER --操作ID
                                                ) IS
  /*
  **功能说明：平台管理
  **创建人：刘浪浪
  **创建日期：2014-09-17
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者   版本号   修改日期     说明
  **刘浪浪   1.0.1   2014/10/22    创建
  **刘浪浪   1.0.2   2014/10/31    增加保存操作
  */
  --V_COUNT INTEGER; --计数变量
  V_OBJ TPIF_WDMB%ROWTYPE; --表单记录
  --V_SCBZ    INTEGER; --日志删除标识
  V_OPER    VARCHAR2(200); --操作方法
  V_FDETAIL VARCHAR2(2000); --日志操作明细
  V_COUNT   NUMBER(8);
  V_CZBM    VARCHAR2(200); --操作编码
  V_CZSM    VARCHAR2(2000); --日志操作明细
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  SELECT * INTO V_OBJ FROM TPIF_WDMB WHERE ID = I_ID;

  SELECT DECODE(I_OPER,
                0,
                'A00301',
                1,
                'A00302',
                2,
                'A00303',
                3,
                'A00304',
                4,
                'A00305',
                5,
                'A00306',
                '0')
    INTO V_CZBM
    FROM DUAL;
  SELECT '[' || DECODE(I_OPER,
                       0,
                       '新增',
                       1,
                       '修改',
                       2,
                       '删除',
                       3,
                       '启用',
                       4,
                       '禁用',
                       5,
                       '复制',
                       '') || ']_' || V_OBJ.MBMC
    INTO V_CZSM
    FROM DUAL;
  --check
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --//:新增
    IF V_OBJ.MBMC IS NULL THEN
      O_NOTE := '[模板名称]不允许为空!';
      RETURN;
    END IF;

    SELECT COUNT(1) INTO V_COUNT FROM TPIF_WDMB WHERE MBMC = V_OBJ.MBMC;
    IF V_COUNT > 1 THEN
      O_NOTE := '当前已存在[名称]为[' || V_OBJ.MBMC || ']的记录!';
      RETURN;
    END IF;

    IF V_OBJ.SYCPFL IS NULL AND V_OBJ.XSQD IS NULL AND V_OBJ.XSPT IS NULL THEN
      O_NOTE := '请配置相应的维度!';
      RETURN;
    END IF;

  END IF;
  IF I_OPER = 1 THEN
    --//:修改
    IF V_OBJ.MBMC IS NULL THEN
      O_NOTE := '[模板名称]不允许为空!';
      RETURN;
    END IF;

    SELECT COUNT(1) INTO V_COUNT FROM TPIF_WDMB WHERE MBMC = V_OBJ.MBMC;
    IF V_COUNT > 1 THEN
      O_NOTE := '当前已存在[名称]为[' || V_OBJ.MBMC || ']的记录!';
      RETURN;
    END IF;

    IF V_OBJ.SYCPFL IS NULL AND V_OBJ.XSQD IS NULL AND V_OBJ.XSPT IS NULL THEN
      O_NOTE := '请配置相应的维度!';
      RETURN;
    END IF;

  END IF;

  IF I_OPER = 5 THEN
    --//:复制
    IF V_OBJ.MBMC IS NULL THEN
      O_NOTE := '[模板名称]不允许为空!';
      RETURN;
    END IF;

    SELECT COUNT(1) INTO V_COUNT FROM TPIF_WDMB WHERE MBMC = V_OBJ.MBMC;
    IF V_COUNT > 1 THEN
      O_NOTE := '当前已存在[名称]为[' || V_OBJ.MBMC || ']的记录!';
      RETURN;
    END IF;
  END IF;
  --RECORD
  O_NOTE := '记录日志';
  PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;
  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '启用',
                         4,
                         '禁用',
                         5,
                         '复制',
                         '') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_WDMB_CZRZDJ;
/

