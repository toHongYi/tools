create PROCEDURE PRO_PIF_CPST_RSCPBQ(O_CODE     OUT NUMBER, --返回值
                                                    O_NOTE     OUT VARCHAR2, --返回消息
                                                    I_LABLE_ID IN NUMBER --标签ID
                                                    ) IS
  /******************************************************************
      项目名称：产品视图-热搜产品标签维护
      所属用户：PIF
      语法信息：
           输入参数：    I_LABLE_ID IN NUMBER --标签ID
                       
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
    逻辑说明：
           1、
      ----------------------------------------------------------
      操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
  ***********************************************************************/
  V_COUNT INTEGER; --计数变量

BEGIN

  IF I_LABLE_ID IS NULL THEN
  
    O_CODE := -1;
    O_NOTE := '入参【I_LABLE_ID】不允许为空';
    RETURN;
  
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TPIF_RSCPBQ A
   WHERE A.CPBQ = I_LABLE_ID;
   
  IF V_COUNT > 0 THEN
    
    UPDATE TPIF_RSCPBQ A SET A.SSCS = A.SSCS + 1 WHERE A.CPBQ = I_LABLE_ID ;
  
  ELSE
  
    INSERT INTO TPIF_RSCPBQ
      (id, cpbq, sscs, czr, czsj)
    VALUES
     ( LIVEBOS.FUNC_NEXTID('TPIF_RSCPBQ'),
       I_LABLE_ID,
       1,
       0,
       SYSDATE
      );
  
  END IF;

  COMMIT;
  O_CODE := 1;
  O_NOTE := '成功!';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

