create PROCEDURE PCX_PIF_SY_CPGKMX(O_CODE      OUT NUMBER,
                                                  O_NOTE      OUT VARCHAR2,
                                                  O_RESULT    OUT SYS_REFCURSOR,
                                                  I_PROD_TYPE IN VARCHAR2 --产品类型
                                                  ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：首页-产品概况明细
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                          TYPE  消息类别
                          TOTAL_RECORD_NUM  总记录数
                          ALREADY_DEAL_NUM  已阅/已处理数
                          TIPS  提示信息
                          URL 明细链接URL
  
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        刘浪浪    1.0.1    2015/01/26                   新增
        高昆      1.0.2    2020/08/03                   修改
  -------------------------------------------------------------------------------------------------*/

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_PROD_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_PROD_TYPE不能为空!';
    RETURN;
  END IF;  


  IF I_PROD_TYPE = '其他产品' THEN
  
    OPEN O_RESULT FOR
      SELECT NVL(SFSF, 0) AS prod_type, -- 产品类型
             DECODE(NVL(SFSF, 0), '1', '首发产品', '持续营销') prod_type_desc, --  产品类型描述
             COUNT(*) AS prod_num --  产品数量
        FROM pif.TPIF_CPDM M
       WHERE M.CPXL IN
             (SELECT PROD_TYPE
                FROM (SELECT PROD_TYPE, PROD_NUM, ROWNUM AS PX
                        FROM (SELECT CPXL PROD_TYPE, --产品类型                           
                                     COUNT(*) AS PROD_NUM --产品数量
                                FROM pif.TPIF_CPDM A
                               where A.CPNBZT = 8
                               GROUP BY CPXL
                               ORDER BY PROD_NUM DESC))
               WHERE PX > 5)
               AND CPNBZT = 8         --2020/8/3新增该行，产品概述显示的是产品内部状态为'8',
       GROUP BY NVL(SFSF, 0);         -- 即'已上架'的产品
  
  ELSE
    OPEN O_RESULT FOR
    
      SELECT NVL(SFSF, 0) AS prod_type, -- 产品类型
             DECODE(NVL(SFSF, 0), '1', '首发产品', '持续营销') prod_type_desc, --  产品类型描述
             COUNT(*) AS prod_num --  产品数量
        FROM pif.TPIF_CPDM M
       WHERE M.CPXL IN
             (SELECT PROD_TYPE
                FROM (SELECT CPXL PROD_TYPE, --产品类型
                             (SELECT NOTE
                      FROM LIVEBOS.TXTDM
                     WHERE FLDM='PIF_CPXL_CPZX' AND IBM = A.CPXL) PROD_TYPE_DESC, -- 产品类型描述
                             COUNT(*) AS PROD_NUM --产品数量
                      
                        FROM pif.TPIF_CPDM A
                       where A.CPNBZT = 8
                       
                       GROUP BY CPXL
                       ORDER BY PROD_NUM DESC)
               WHERE PROD_TYPE_DESC = I_PROD_TYPE AND ROWNUM <= 5)
               AND M.CPNBZT = 8            --2020/8/3新增该行，产品概述显示的是产品内部状态为'8',
       GROUP BY NVL(SFSF, 0);              -- 即'已上架'的产品
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

