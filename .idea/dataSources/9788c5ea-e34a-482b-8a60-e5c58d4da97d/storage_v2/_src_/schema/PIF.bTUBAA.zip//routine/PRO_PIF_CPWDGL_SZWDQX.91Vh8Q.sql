create PROCEDURE PRO_PIF_CPWDGL_SZWDQX(O_CODE      OUT NUMBER,
                                                      O_NOTE      OUT VARCHAR2,
                                                      I_USERID    IN NUMBER, --操作人
                                                      I_IP        IN VARCHAR2, --操作IP
                                                      I_CZLX      IN NUMBER, --1|权限变更(约束条件变化)；2|角色对应权限;3|人员对应权限;4|上传新版本文档
                                                      I_WDKID     IN NUMBER, --文档库ID
                                                      I_WDKID_OLD IN NUMBER, --更新文档时原有文档ID
                                                      I_ZZJG      IN NUMBER, --组织机构
                                                      I_LWZ       IN VARCHAR2, --组织机构对应的角色或者人员值
                                                      I_WDYSTJ    IN NUMBER --文档约束条件
                                                      ) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：海通证券产品中心

           功能说明：设置文档权限
               参数说明：
                    入参：
                         I_USERID IN NUMBER, --操作人
                         I_IP     IN VARCHAR2, --操作IP
                         I_CZLX   IN NUMBER, --1|删除权限；2|角色对应权限;3|人员对应权限
                         I_WDKID  IN NUMBER, --文档库ID
                         I_ZZJG   IN NUMBER, --组织机构
                         I_LWZ    IN VARCHAR2 --组织机构对应的角色或者人员值


                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,



          ----------------------------------------------------------
          操作人   版本号       时间                     操作
          刘浪浪   1.0.1     2014/12/17                  新增
          刘浪浪   1.0.2     2015/01/16                  处理DECODE的bug
          刘浪浪   1.0.3     2015/02/28                  文档权限增加组织机构以及角色维度，修改文档时先删除文档已有权限再插入新的权限，
                                                         不再判断权限是否发生变化
          刘浪浪   1.0.4     2015/03/10                  增加文档约束条件参数，当文档没有上传，而文档权限发生变更时更新文档的文档约束条件字段的值
          刘浪浪   1.0.5     2015/03/16                  插入权限时，剔除掉重复的权限，避免照成数据冗余
    -------------------------------------------------------------------------------------------------*/
    V_COUNT NUMBER(8);
BEGIN
    O_CODE := 1;
    O_NOTE := '成功!';

    IF I_USERID IS NULL OR I_IP IS NULL THEN
        O_CODE := -1;
        O_NOTE := '操作人或操作IP不能为空!';
        RETURN;
    END IF;

    IF I_WDKID IS NULL THEN
        O_CODE := -1;
        O_NOTE := '文档库ID不能为空!';
        RETURN;
    END IF;

    IF I_CZLX IS NULL THEN
        O_CODE := -1;
        O_NOTE := '操作类型不能为空!';
        RETURN;
    END IF;

    IF I_CZLX = 1 THEN
        --删除已有权限
        DELETE FROM TPIF_WDQXXX WHERE WDK = I_WDKID;

        IF I_WDYSTJ IS NOT NULL THEN
            --若没有上传新文档，文档的权限变更了，则修改文档约束条件
            UPDATE TPIF_CPWDK T SET T.WDYSTJ = I_WDYSTJ WHERE T.ID = I_WDKID;
        END IF;

    ELSIF I_CZLX = 2 THEN
        --角色对应权限
        FOR LWZ IN (SELECT TO_NUMBER(REGEXP_SUBSTR(I_LWZ, '([^;]+)', 1, ROWNUM)) ID
                      FROM DUAL
                    CONNECT BY ROWNUM < LENGTH(REGEXP_REPLACE(I_LWZ, '[^;]', '')) + 2) LOOP

            --校验是否已经存在重复权限,重复则不插入
            SELECT COUNT(*)
              INTO V_COUNT
              FROM TPIF_WDQXXX T
             WHERE T.LWBM = I_ZZJG
               AND T.LWJS = LWZ.ID
               AND T.WDK = I_WDKID;

            IF V_COUNT = 0 THEN
                INSERT INTO TPIF_WDQXXX
                    (ID, WDK, LWBM, LWJS, SZRQ)
                    SELECT livebos.FUNC_NEXTID('TPIF_WDQXXX'),
                           I_WDKID,
                           I_ZZJG,
                           LWZ.ID,
                           TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
                      FROM DUAL;
            END IF;
        END LOOP;
    ELSIF I_CZLX = 3 THEN
        --人员对应权限

        FOR LWZ IN (SELECT TO_NUMBER(REGEXP_SUBSTR(I_LWZ, '([^;]+)', 1, ROWNUM)) ID
                      FROM DUAL
                    CONNECT BY ROWNUM < LENGTH(REGEXP_REPLACE(I_LWZ, '[^;]', '')) + 2) LOOP

            --校验是否已经存在重复权限，重复则不插入
            SELECT COUNT(*)
              INTO V_COUNT
              FROM TPIF_WDQXXX T
             WHERE T.LWBM = I_ZZJG
               AND T.LWRY = LWZ.ID
               AND T.WDK = I_WDKID;

            IF V_COUNT = 0 THEN
                INSERT INTO TPIF_WDQXXX
                    (ID, WDK, LWBM, LWRY, SZRQ)
                    SELECT livebos.FUNC_NEXTID('TPIF_WDQXXX'),
                           I_WDKID,
                           I_ZZJG,
                           LWZ.ID， TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
                      FROM DUAL;
            END IF;
        END LOOP;
    ELSIF I_CZLX = 4 THEN
        --更新文档时没有修改文档权限信息，则将原来旧的文档的权限信息复制到新文档下
        INSERT INTO TPIF_WDQXXX
            (ID, WDK, LWBM, LWRY, LWJS, SZRQ)
            SELECT livebos.FUNC_NEXTID('TPIF_WDQXXX'),
                   I_WDKID,
                   T.LWBM,
                   T.LWRY,
                   T.LWJS,
                   TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
              FROM TPIF_WDQXXX T
             WHERE T.WDK = I_WDKID_OLD;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        ROLLBACK;

END PRO_PIF_CPWDGL_SZWDQX;
/

