create PACKAGE BODY PIF_PKG_TRANS IS

  --清洗程序主调度
  PROCEDURE PRO_PIF_TRANS_MAIN(O_CODE OUT NUMBER,
                               O_NOTE OUT VARCHAR2,
                               I_BID  IN NUMBER) --清洗表IDIS
   AS

    V_CODE     NUMBER;
    V_NOTE     VARCHAR2(1000);
    V_SQL      VARCHAR2(20000);
    V_ROWCOUNT NUMBER;
    V_RZID     NUMBER;
    V_TBBZZDZ  NUMBER;

  BEGIN

    FOR CUR_RW IN (SELECT *
                     FROM TPIF_SJQXJK A
                    WHERE A.ZT = 1
                      AND A.ID = NVL(I_BID, A.ID)
                    ORDER BY XH ASC) LOOP

      --1.获取同步标志最大值
      PIF.PIF_PKG_TRANS.PRO_PIF_TRANS_BEGIN(V_CODE,
                                            V_NOTE,
                                            V_RZID,
                                            CUR_RW.ID);

      IF V_CODE < 0 THEN

        UPDATE TPIF_SJQXRZ A
           SET A.JSSJ = SYSDATE,
               A.SJL  = 0,
               A.ZT   = -1,
               A.BZ   = '执行PRO_PIF_TRANS_BEGIN失败：' || V_NOTE
         WHERE A.ID = V_RZID;

        COMMIT;
        CONTINUE;
      END IF;

      SELECT MAX(JYR)
        INTO V_TBBZZDZ
        FROM LIVEBOS.TXTJYR A
       WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');

      --2.业务处理
      --参数说明：
      -- V1 ：  OUT   O_CODE
      -- V2 :   OUT   O_NOTE
      -- V3 :   OUT   O_ROWCOUNT
      -- V4 :   IN   O_TBBZZDZ 同步标志最大值,增量清洗可能会用到
      V_SQL := 'BEGIN PIF.PIF_PKG_TRANS.' || CUR_RW.YWCLLJ ||
               '(:V1,:V2,:V3,:V4); END;';

      EXECUTE IMMEDIATE V_SQL
        USING OUT V_CODE, OUT V_NOTE, OUT V_ROWCOUNT, IN V_TBBZZDZ;

      IF V_CODE < 0 THEN

        UPDATE TPIF_SJQXRZ A
           SET A.JSSJ = SYSDATE,
               A.SJL  = 0,
               A.ZT   = -1,
               A.BZ   = '执行业务处理失败：' || V_NOTE
         WHERE A.ID = V_RZID;
        COMMIT;
        CONTINUE;
      END IF;

      --3.更新同步标志最大值
      PIF.PIF_PKG_TRANS.PRO_PIF_TRANS_END(V_CODE, V_NOTE, CUR_RW.ID);

      --4.记录清洗日志
      PIF.PIF_PKG_TRANS.PRO_PIF_TRANS_LOG(V_RZID,
                                          V_ROWCOUNT,
                                          (CASE WHEN V_CODE > 0 THEN 2
                                           ELSE - 1 END),
                                          V_NOTE);

    END LOOP;

    O_CODE := 1;
    O_NOTE := '成功！';

  EXCEPTION
    WHEN OTHERS THEN
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
  END;

  /**
   --清洗程序开始日志
   --1.KETTLE清洗前获取同步标志最大值作为增量清洗的标志
   --2.记录清洗日志
  **/
  PROCEDURE PRO_PIF_TRANS_BEGIN(O_CODE OUT NUMBER,
                                O_NOTE OUT VARCHAR2,
                                O_RZID OUT NUMBER, --日志ID
                                I_BID  IN NUMBER --清洗表ID
                                )

   IS
    V_RZID NUMBER;
  BEGIN

    --记录数据清洗日志,标明数据清洗状态为进行中
    SELECT SEQ_TPIF_SJQXRZ.NEXTVAL INTO V_RZID FROM DUAL;
    INSERT INTO TPIF_SJQXRZ
      (ID, CJYB, KSSJ, JSSJ, SJL, ZT, BZ)
    VALUES
      (V_RZID, I_BID, SYSDATE, NULL, 0, 1, NULL);

    O_RZID := V_RZID; --日志ID
    O_CODE := 1;
    O_NOTE := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
  END;

  /**
   --清洗程序结束日志
   --1.KETTLE清洗结束时记录清洗日志，更新同步标志最大值
   --2.执行增量清洗后的业务处理逻辑
  **/
  PROCEDURE PRO_PIF_TRANS_END(O_CODE OUT NUMBER,
                              O_NOTE OUT VARCHAR2,
                              I_BID  IN NUMBER --清洗表ID
                              )

   IS

    --V_TBBZZDZ NUMBER := NULL;
    --V_TBBZLX  NUMBER;
    --V_ZLTBBZ  VARCHAR2(200);
  BEGIN

    O_CODE := 1;
    O_NOTE := '成功！';

    UPDATE TPIF_SJQXJK A SET A.ZJZXSJ = SYSDATE WHERE A.ID = I_BID;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;

  END;

  /**
   记录清洗日志通用过程
  **/
  PROCEDURE PRO_PIF_TRANS_LOG(I_RZID IN NUMBER, --ID
                              I_SJL  IN NUMBER,
                              I_ZT   IN NUMBER,
                              I_BZ   IN VARCHAR2) AS

  BEGIN

    UPDATE TPIF_SJQXRZ A
       SET A.JSSJ = SYSDATE, A.SJL = I_SJL, A.ZT = I_ZT, A.BZ = I_BZ
     WHERE A.ID = I_RZID;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;

  --柜台-产品代码设置清洗逻辑
  PROCEDURE PRO_TPIF_CPDM(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    --1.集中柜台更新
   MERGE INTO TPIF_CPDM M
   USING (SELECT *
            FROM SRC_PIF.PRODCODE
           WHERE PROD_CODE IS NOT NULL
             AND PRODTA_NO IS NOT NULL) N
   ON (M.CPDM = N.PROD_CODE AND M.CPTA = N.PRODTA_NO)
   WHEN MATCHED THEN
     UPDATE
        SET M.CPMC      = N.PROD_NAME,
            M.CPJC      = N.PROD_NAME,
            M.PYDM      = N.PRODSPELL_CODE,
            M.CPJYZT    = N.PROD_STATUS,
            M.CPJD      = DECODE(N.PROD_STATUS,
                                 1,
                                 3,
                                 2,
                                 2,
                                 3,
                                 1,
                                 4,
                                 3,
                                 5,
                                 4,
                                 3),
            M.HBZL      = N.MONEY_TYPE,
            M.FXJG      = N.ISSUE_PRICE,
            M.MFMZ      = N.PAR_VALUE,
            M.SFFS      = TRIM(N.CHARGE_TYPE),
            M.FHFS      = TRIM(N.DIVIDEND_WAY),
            M.YXZHDM    = N.EN_CHANGE_CODE,
            M.YXCFDM    = N.EN_SPLIT_CODE,
            M.YXZHZT    = TRIM(N.PROD_CONVERT_STATUS),
            M.QTJE     =
            (CASE
              WHEN N.MIN_SHARE2 = 0 THEN
               N.MIN_SHARE
              ELSE
               N.MIN_SHARE2
            END),
            M.CPLB      = N.PROD_TYPE,
            M.CPFZLB   =
            (SELECT IBM
               FROM LIVEBOS.TXTDM
              WHERE FLDM = 'PIF_GTCPFZLB'
                AND CBM = N.PROD_TYPE_ASS),
            M.CPZDMJJE  = N.PROD_MIN_BALA,
            M.CPZGMJJE  = N.PROD_MAX_BALA,
            M.CPSJMJJE  = N.PROD_REAL_BALA,
            M.CPZED    =
            (SELECT MAX(ENABLE_QUOTA)
               FROM SRC_PIF.PRODQUOT
              WHERE PROD_CODE = N.PROD_CODE
                AND PRODTA_NO = N.PRODTA_NO
                AND EN_ENTRUST_WAY IS NULL),
            M.MJKSRQ    = N.IPO_BEGIN_DATE,
            M.MJJSRQ    = N.IPO_END_DATE,
            M.CLRQ      = N.PROD_BEGIN_DATE,
            M.DQRQ      = N.PROD_END_DATE,
            M.JXKSRQ    = N.INTEREST_BEGIN_DATE,
            M.JXJSRQ    = N.INTEREST_END_DATE,
            M.CPQX      = N.PROD_TERM,
            M.CPTAMC   =
            (SELECT TA_NAME
               FROM SRC_PIF.PRODARG
              WHERE PRODTA_NO = N.PRODTA_NO),
            M.CPTGR     = N.PROD_TRUSTEE,
            M.TGYH      = N.TRUSTEE_BANK,
            M.CPFQR     = N.PROD_SPONSOR,
            M.TZLB      = TRIM(N.INVEST_TYPE),
            M.SYLX      = TRIM(N.INCOME_TYPE),
            M.CPTZQX    = TRIM(N.PROD_INVEST_TERM),
            M.CPFXDJ    = N.PRODRISK_LEVEL,
            M.CPPGDJ    = N.ASSESS_LEVEL,
            M.CPSDXKZC  = N.PROD_ELIG_CTRLSTR,
            M.ZDFXDJ    = N.LOW_CORP_RISK_LEVEL,
            M.ZDZCYQ    = N.MIN_ASSET_NEED,
            M.YXZYTZZLX =
            (SELECT REPLACE(WM_CONCAT(IBM), ',', ';')
               FROM LIVEBOS.TXTDM
              WHERE FLDM = 'PIF_YXZYTZLLX'
                AND CBM = N.EN_PROF_FLAG),
            M.ZDZHJE    = N.MIN_SWITCH_IN_BALANCE,
            M.ZSZHFE    = N.TRANS_LIMITSHARE,
            M.ZHDW      = N.SWITCH_UNIT,
            M.SHZDZ     = N.REDEEM_LIMITSHARE,
            M.SHZXDW    = N.REDEMPTION_UNIT,
            M.SHZJKYBZ  = TRIM(N.REDEEM_USE_FLAG),
            M.MCZDKSGBL = N.MAX_ALLOTRATIO,
            M.JEBL      = N.HUGE_RATIO,
            --M.QD = N.    --销售渠道
            M.PT      = 3,
            M.XSXXBZ  = 1,
            M.XSSC    = 2,
            M.TZZLJQ  = N.COOLING_PERIOD,
            M.SHTZZLX = DECODE(N.PRODRISK_LEVEL,
                               1,
                               '1',
                               2,
                               '1;2',
                               3,
                               '1;2;3',
                               4,
                               '1;2;3;4',
                               5,
                               '1;2;3;4;5'),
            M.NHTS    = N.YEAR_DAYS,
            M.YQSYL   = N.PRODPRE_RATIO,
            M.YQSYLMS = N.PROD_RATIO_STR,
            M.KFQMS   = N.PROD_OPEN_DATE_STR,
            M.CPSJZT  = 1
            
             WHEN NOT MATCHED THEN INSERT(ID, --ID
             CPDM, --产品代码
             CPTA, --TA代码
             CPMC, --产品名称
             CPJC, --产品简称
             PYDM, --拼音代码
             CPJYZT, --产品交易状态
             CPNBZT, --产品内部状态
             CPJD, --产品阶段
             HBZL, --币种类别
             FXJG, --发行价格
             MFMZ, --每份面值
             SFFS, --收费类型
             FHFS, --分红方式
             YXZHDM, --允许转换的代码
             YXCFDM, --允许拆分成的代码
             YXZHZT, --允许转换状态
             QTJE, --起投金额(元)
             CPLB, --产品类别
             CPFZLB, --产品辅助类别
             CPZDMJJE, --产品最低募集金额
             CPZGMJJE, --产品最高募集金额
             CPSJMJJE, --产品实际募集金额
             CPZED, --产品总额度
             MJKSRQ, --募集开始日期
             MJJSRQ, --募集结束日期
             CLRQ, --产品成立日期
             DQRQ, --产品结束日期
             JXKSRQ, --记息开始日期
             JXJSRQ, --记息结束日期
             CPQX, --产品期限
             CPTAMC, --产品TA名称
             CPGLRID, --产品管理人???
             CPTGR, --产品托管人
             TGYH, --托管银行
             CPFQR, --产品发起人
             TZLB, --投资类别
             SYLX, --收益类型
             CPTZQX, --产品投资期限
             CPFXDJ, --产品风险等级
             CPPGDJ, --产品评估等级
             CPSDXKZC, --产品适当性控制串
             ZDFXDJ, --最低风险等级
             ZDZCYQ, --最低资产要求
             YXZYTZZLX, --允许专业投资者类型
             ZDZHJE, --最低转换金额
             ZSZHFE, --最少转换份额
             ZHDW, --转换单位
             SHZDZ, --赎回最低份额
             SHZXDW, --赎回最小单位
             SHZJKYBZ, --赎回资金可用标志
             MCZDKSGBL, --每次最大可申购比例
             JEBL, --巨额比例
            --QD,       --销售渠道
             PT, --销售平台
             XSXXBZ, --线上线下标志
             XSSC, --销售市场
             TZZLJQ, --投资者冷静期(小时)
             SHTZZLX, --适合投资者类型
             NHTS, --年化天数
             YQSYL, --预期年收益率
             YQSYLMS, --产品收益率信息
             KFQMS, --开放期描述
             CPSJZT, --数据状态,
             SFSF --首发/持营
             ) 
      VALUES(LIVEBOS.FUNC_NEXTID('TPIF_CPDM'), 
             TRIM(N.PROD_CODE), 
             TRIM(N.PRODTA_NO), 
             TRIM(N.PROD_NAME), 
             TRIM(N.PROD_NAME), 
             N.PRODSPELL_CODE, 
             N.PROD_STATUS, 
             8, --已上架
             DECODE(N.PROD_STATUS, 1, 3, 2, 2, 3, 1, 4, 3, 5, 4, 3),
             N.MONEY_TYPE, 
             N.ISSUE_PRICE, 
             N.PAR_VALUE, 
             TRIM(N.CHARGE_TYPE), 
             TRIM(N.DIVIDEND_WAY), 
             N.EN_CHANGE_CODE, 
             N.EN_SPLIT_CODE, 
             TRIM(N.PROD_CONVERT_STATUS),
             (CASE
              WHEN N.MIN_SHARE2 = 0 THEN
               N.MIN_SHARE
              ELSE
               N.MIN_SHARE2
            END), 
            N.PROD_TYPE, 
            (SELECT IBM FROM LIVEBOS.TXTDM
                      WHERE FLDM = 'PIF_GTCPFZLB'
                        AND CBM = N.PROD_TYPE_ASS), 
            N.PROD_MIN_BALA, 
            N.PROD_MAX_BALA, 
            N.PROD_REAL_BALA, 
            (SELECT MAX(ENABLE_QUOTA) FROM SRC_PIF.PRODQUOT
                      WHERE PROD_CODE = N.PROD_CODE
                         AND PRODTA_NO = N.PRODTA_NO
                         AND EN_ENTRUST_WAY IS NULL),
            N.IPO_BEGIN_DATE, 
            N.IPO_END_DATE, 
            N.PROD_BEGIN_DATE, 
            N.PROD_END_DATE, 
            N.INTEREST_BEGIN_DATE, 
            N.INTEREST_END_DATE, 
            N.PROD_TERM, 
            (SELECT TA_NAME FROM SRC_PIF.PRODARG WHERE PRODTA_NO = N.PRODTA_NO), 
            (SELECT ID FROM PIF.TPIF_JGDM WHERE JGDM = N.PROD_MANAGER), 
            N.PROD_TRUSTEE, 
            N.TRUSTEE_BANK, 
            N.PROD_SPONSOR, 
            TRIM(N.INVEST_TYPE), 
            TRIM(N.INCOME_TYPE), 
            TRIM(N.PROD_INVEST_TERM), 
            N.PRODRISK_LEVEL, 
            N.ASSESS_LEVEL, 
            N.PROD_ELIG_CTRLSTR, 
            N.LOW_CORP_RISK_LEVEL, 
            N.MIN_ASSET_NEED, 
            (SELECT REPLACE(WM_CONCAT(IBM),',',';') FROM LIVEBOS.TXTDM  WHERE FLDM = 'PIF_YXZYTZLLX' AND CBM = N.EN_PROF_FLAG), 
            N.MIN_SWITCH_IN_BALANCE, 
            N.TRANS_LIMITSHARE, 
            N.SWITCH_UNIT, 
            N.REDEEM_LIMITSHARE, 
            N.REDEMPTION_UNIT, 
            TRIM(N.REDEEM_USE_FLAG), 
            N.MAX_ALLOTRATIO, 
            N.HUGE_RATIO,
            --QD,    --销售渠道
             3, --集中交易
             1, --线上
             2, --2-场外
             N.COOLING_PERIOD, 
             DECODE(N.PRODRISK_LEVEL, 1, '1', 2, '1;2', 3, '1;2;3', 4, '1;2;3;4', 5, '1;2;3;4;5'), 
             N.YEAR_DAYS, 
             N.PRODPRE_RATIO, 
             N.PROD_RATIO_STR, 
             N.PROD_OPEN_DATE_STR, 
             1, 
             0 
            ）;
    UPDATE TPIF_CPDM A SET A.CPID = A.ID WHERE A.CPID IS NULL;

    O_ROWCOUNT := SQL%ROWCOUNT;
    
    
    
    --聚源
     --聚源 基金概况 MF_FundArchives--- SecuMain.ChiName
    MERGE INTO TPIF_CPDM M
    USING(SELECT  A.INNERCODE,
                  B.SECUCODE,            --交易代码
                  A.APPLYINGCODEFRONT ,  --前端申购代码
                  A.APPLYINGCODEBACK,    --后端申购代码
                  B.CHINAMEABBR  ,--简称
                  B.CHINAME,             --全称
                  A.BRIEFINTRO,          --产品简介
                  TO_CHAR(A.EXPIREDATE , 'YYYYMMDD') EXPIREDATE ,--存续期截止日
                  A.MANAGER,             --基金经理
                  TO_CHAR(C.REDEEMOPENINGDATE, 'YYYYMMDD') REDEEMOPENINGDATE,-- 赎回开放起始日
                  A.INVESTFIELD,          --基金投资范围
                  to_char(A.EstablishmentDate,'yyyymmdd') as clrq,   --成立日期
                  A.FoundedSize   --基金设立规模（份）
            FROM SRC_PIF.MF_FUNDARCHIVES A,SRC_PIF.SECUMAIN B,SRC_PIF.MF_ISSUEANDLISTING C
            WHERE A.INNERCODE = B.INNERCODE
              AND A.INNERCODE = C.INNERCODE(+)
           ) N
    ON(M.JYNM = N.INNERCODE)
    WHEN MATCHED THEN UPDATE
    SET M.CPJC   = N.CHINAMEABBR,       --产品全称
        M.CPJJ   = N.BRIEFINTRO,    --产品简介
        --M.DQRQ   = N.EXPIREDATE,    --到期日期
        M.TZFZR   = N.MANAGER,       --投资负责人
       -- M.SFQDXS = NVL2(N.APPLYINGCODEFRONT,1,0),  --是否前端销售
       -- M.SFHDXS = NVL2(N.APPLYINGCODEBACK,1,0),  --是否后端销售
       -- M.SHQSRQ = N.REDEEMOPENINGDATE, --赎回起始日期
        M.TZFW = N.INVESTFIELD,        --投资范围描述
        M.Clrq = N.Clrq,        --成立日期
        M.JRCPFL = '300100',
        m.cpxl = 1
       -- M.SF= N.FoundedSize
        ;

    --SFSF首发/持营
    UPDATE TPIF_CPDM A
       SET SFSF = (CASE
                    WHEN NVL(A.CLRQ, 19000101) >=
                         TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
                     1
                    WHEN NVL(A.MJJSRQ, 19000101) >=
                         TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
                     1
                    ELSE
                     0
                  END);

    /***BEGIN:  JRCPFL  金融产品分类 更新****/

    --集合资产管理计划深市TA代码D4开头的产品+自建TA-CD4的产品
    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '100100'
     WHERE EXISTS (

            SELECT 1
              FROM SRC_PIF.PRODCODE B
             WHERE B.PROD_CODE = A.CPDM
               AND B.PRODTA_NO = A.CPTA
               AND B.PROD_CODE LIKE 'D4%'
               AND B.PRODTA_NO IN ('98')
            )
       AND A.JRCPFL IS NULL;

    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '100100'
     WHERE EXISTS (
            SELECT 1
              FROM SRC_PIF.PRODCODE B
             WHERE B.PROD_CODE = A.CPDM
               AND B.PRODTA_NO = A.CPTA
               AND B.PRODTA_NO IN ('D4')
            )
       AND A.JRCPFL IS NULL;


    --收益凭证  通过中证TA-CZZ
    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '100400'
     WHERE EXISTS (
            SELECT 1
              FROM SRC_PIF.PRODCODE B
             WHERE B.PROD_CODE = A.CPDM
               AND B.PRODTA_NO = A.CPTA
               --AND B.PRODCODE_KIND = '2'
               AND B.PRODTA_NO = 'CZZ'
            )
       AND A.JRCPFL IS NULL;

    --公募基金产品  300100公募基金自建TA或者中登TA（取纯数字代码不带字母）
    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '300100'
     WHERE EXISTS (
            SELECT 1
              FROM SRC_PIF.PRODCODE B
             WHERE B.PROD_CODE = A.CPDM
               AND B.PRODTA_NO = A.CPTA
               AND B.PRODCODE_KIND = '1'
               AND (B.PRODTA_NO NOT IN ('98', '99') OR B.PRODTA_NO IN(SELECT JGDM FROM TPIF_JGDM C WHERE C.GSFL=1 AND ZT=1))
               AND TRIM(TRANSLATE(B.PROD_CODE, '1234567890', '          ')) IS NULL
            )
       AND A.JRCPFL IS NULL;


   /* --天风天梯  天风天融  天风天利  天风天阳
    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '100400'
     WHERE A.JRCPFL IS NULL
       AND (A.CPMC LIKE '天风天梯%' OR A.CPMC LIKE '天风天融%' OR
           A.CPMC LIKE '天风天利%' OR A.CPMC LIKE '天风天阳%' OR
           A.CPMC LIKE '天风天曦%');*/

    --D01兴业银行
    UPDATE TPIF_CPDM A
       SET A.JRCPFL = '800100'
     WHERE A.CPTA = 'D01'
       AND A.JRCPFL IS NULL;

    --信托
     UPDATE TPIF_CPDM A
       SET A.JRCPFL = '600100'
     WHERE A.CPTA IN(SELECT PRODTA_NO FROM SRC_PIF.PRODARG B WHERE B.TA_NAME LIKE '%信托%')
       AND A.JRCPFL IS NULL;



    /***END :  JRCPFL 金融产品分类 更新****/
    --CPXL 产品系列

    UPDATE TPIF_CPDM A
       SET A.CPXL = (CASE
                      WHEN A.JRCPFL IN ('300100', '300200', '300300') THEN
                       1
                      WHEN A.JRCPFL IN ('100300',
                                        '500100',
                                        '500200',
                                        '500300',
                                        '500400',
                                        '500500') THEN
                       2
                      WHEN A.JRCPFL IN
                           ('100100', '100200', '200100', '200200') THEN
                       3
                      WHEN A.JRCPFL IN ('100400') THEN
                       4
                      WHEN A.JRCPFL IN ('800100') THEN
                       5
                      WHEN A.JRCPFL IN ('600100', '600200', '600300') THEN
                       8
                      WHEN A.JRCPFL IN ('700100', '700200') THEN
                       9
                      WHEN A.JRCPFL IN ('100500') THEN
                       10
                      WHEN A.JRCPFL IN
                           ('300200', '300300', '400100', '400200') THEN
                       11
                    END)
     WHERE A.CPXL IS NULL;

    --CPGLRID 产品管理人

    --2.聚源更新
    MERGE INTO TPIF_CPDM M
    USING(   SELECT A.INNERCODE,
                    A.CHISPELLING,
                    B.BRIEFINTRO,
                    A.SECUCODE
               FROM SRC_PIF.SECUMAIN A,
                    SRC_PIF.MF_FUNDARCHIVES B
               WHERE A.INNERCODE = B.INNERCODE ) N
    ON( M.CPDM = N.SECUCODE AND M.CPXL = 1)
    WHEN MATCHED THEN UPDATE
      SET M.PYDM = N.CHISPELLING,
          M.CPJJ = N.BRIEFINTRO,
          M.JYNM = N.INNERCODE ;
    
 

    O_CODE := 1;
    O_NOTE := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品开发属性
  PROCEDURE PRO_TPIF_CPDM_P_GT(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT M
    USING (SELECT A.CPID,
                  B.PROD_INTERNAL_CODE,
                  B.PRODRELATIVE_CODE,
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTCPDMZL'
                      AND CBM = B.PRODCODE_KIND) AS PRODCODE_KIND, --产品代码种类
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTCPDMLX'
                      AND CBM = B.PRODCODE_TYPE) AS PRODCODE_TYPE, --产品代码类型
                  B.TOTAL_SHARE,
                  B.TOTAL_ASSET,
                  B.BUY_PROCESS,
                  B.ELIGPAPER_VERSION,
                  B.EN_INTERNAL_CONDITION,
                  B.ISSUE_DATE,
                  B.PAY_OVERTIME,
                  (SELECT REPLACE(WM_CONCAT(IBM), ',', ';')
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXWTFS'
                      AND INSTR(B.EN_ENTRUST_WAY, CBM) > 0) AS EN_ENTRUST_WAY, --允许委托方式
                  (SELECT REPLACE(WM_CONCAT(IBM), ',', ';')
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXZFFS'
                      AND INSTR(B.EN_PAY_KIND, CBM) > 0) AS EN_PAY_KIND, --允许支付方式
                  B.QUOTA_VALID_TERM,
                  B.SUB_RISK_URL,
                  B.ECONTRACT_VERSION,
                  B.PROD_BACK_N,
                  B.PRECISIONS,
                  B.PRODCODE_CTRLSTR,
                  B.CTRLSTR_USEFLAGS,
                  B.IPO_BEGIN_TIME,
                  B.IPO_END_TIME,
                  B.PROM_BEGIN_DATE,
                  B.PROM_END_DATE,
                  B.SUBCONF_ENDDATE,
                  B.SUBCONF_ENDTIME,
                  B.PRE_END_DATE,
                  B.PRE_END_TIME,
                  B.PRESELL_BEGIN_DATE,
                  B.PRESELL_END_DATE,
                  B.PRESELL_BEGIN_TIME,
                  B.PRESELL_END_TIME,
                  B.PROMFARE_RATE,
                  B.PROM_SCALE,
                  B.MIN_TIMER_BALANCE,
                  B.MAX_TIMER_BALANCE,
                  B.PROD_INTEREST,
                  B.PROD_PUT_PRICE,
                  B.REBUY_PROP,
                  B.TRIAL_DAYS,
                  B.TRIAL_REORDER_MAX_TIME,
                  B.MAX_DEFICIT_RATE,
                  B.BANK_RISK_LEVEL,
                  B.EN_COMPANY_NO,
                  B.INTEREST_FREQ,
                  B.PRODSUB_RATE
             FROM TPIF_CPDM A, SRC_PIF.PRODCODE B
            WHERE A.CPDM = B.PROD_CODE
              AND A.CPTA = B.PRODTA_NO) N
    ON (M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPNM       = N.PROD_INTERNAL_CODE,
             M.CPXGDM     = N.PRODRELATIVE_CODE,
             M.CPDMZL     = N.PRODCODE_KIND,
             M.CPDMLX     = N.PRODCODE_TYPE,
             M.KFHDJSFE   = N.TOTAL_SHARE,
             M.ZZC        = N.TOTAL_ASSET,
             M.GMLC       = N.BUY_PROCESS,
             M.SDXSJBB    = N.ELIGPAPER_VERSION,
             M.NTTJ       = N.EN_INTERNAL_CONDITION,
             M.FXRQ       = N.ISSUE_DATE,
             M.ZFCSSJ_M   = N.PAY_OVERTIME,
             M.YXWTFS     = N.EN_ENTRUST_WAY,
             M.YXZFFS     = N.EN_PAY_KIND,
             M.EDSLYXQX   = N.QUOTA_VALID_TERM,
             M.FXJSSLJDZ  = N.SUB_RISK_URL,
             M.DZHTBB     = N.ECONTRACT_VERSION,
             M.SYKQZJ     = N.PROD_BACK_N,
             M.FEJQXSWS   = N.PRECISIONS,
             M.YWKZC      = N.PRODCODE_CTRLSTR,
             M.CPKZCSYBZC = N.CTRLSTR_USEFLAGS,
             M.MJKSSJ     = N.IPO_BEGIN_TIME,
             M.MJJSSJ     = N.IPO_END_TIME,
             M.TJKSRQ     = N.PROM_BEGIN_DATE,
             M.TJJSRQ     = N.PROM_END_DATE,
             M.RGQRJZRQ   = N.SUBCONF_ENDDATE,
             M.REQRJZSJ   = N.SUBCONF_ENDTIME,
             M.RGCDJZRQ   = N.PRE_END_DATE,
             M.RGCDJZSJ   = N.PRE_END_TIME,
             M.YSKSRQ     = N.PRESELL_BEGIN_DATE,
             M.YSJSRQ     = N.PRESELL_END_DATE,
             M.YSKSSJ     = N.PRESELL_BEGIN_TIME,
             M.YSJSSJ     = N.PRESELL_END_TIME,
             M.TJFL       = N.PROMFARE_RATE,
             M.TJGM       = N.PROM_SCALE,
             M.ZXDTJE     = N.MIN_TIMER_BALANCE,
             M.ZDDTJE     = N.MAX_TIMER_BALANCE,
             M.YJLX       = N.PROD_INTEREST,
             M.HSJG       = N.PROD_PUT_PRICE,
             M.ZTSX       = N.REBUY_PROP,
             M.SYQTS      = N.TRIAL_DAYS,
             M.SYQTDZGCS  = N.TRIAL_REORDER_MAX_TIME,
             M.ZDKSL      = N.MAX_DEFICIT_RATE,
             M.YHDFXDJ    = N.BANK_RISK_LEVEL,
             M.YXQSBH     = N.EN_COMPANY_NO,
             M.FXPL       = N.INTEREST_FREQ,
             M.RGFL       = N.PRODSUB_RATE
    WHEN NOT MATCHED THEN
      INSERT
        (M.ID,
         M.CPID,
         M.CPNM,
         M.CPXGDM,
         M.CPDMZL,
         M.CPDMLX,
         M.KFHDJSFE,
         M.ZZC,
         M.GMLC,
         M.SDXSJBB,
         M.NTTJ,
         M.FXRQ,
         M.ZFCSSJ_M,
         M.YXWTFS,
         M.YXZFFS,
         M.EDSLYXQX,
         M.FXJSSLJDZ,
         M.DZHTBB,
         M.SYKQZJ,
         M.FEJQXSWS,
         M.YWKZC,
         M.CPKZCSYBZC,
         M.MJKSSJ,
         M.MJJSSJ,
         M.TJKSRQ,
         M.TJJSRQ,
         M.RGQRJZRQ,
         M.REQRJZSJ,
         M.RGCDJZRQ,
         M.RGCDJZSJ,
         M.YSKSRQ,
         M.YSJSRQ,
         M.YSKSSJ,
         M.YSJSSJ,
         M.TJFL,
         M.TJGM,
         M.ZXDTJE,
         M.ZDDTJE,
         M.YJLX,
         M.HSJG,
         M.ZTSX,
         M.SYQTS,
         M.SYQTDZGCS,
         M.ZDKSL,
         M.YHDFXDJ,
         M.YXQSBH,
         M.FXPL,
         M.RGFL)
      VALUES
        (N.CPID,
         N.CPID,
         N.PROD_INTERNAL_CODE,
         N.PRODRELATIVE_CODE,
         N.PRODCODE_KIND,
         N.PRODCODE_TYPE,
         N.TOTAL_SHARE,
         N.TOTAL_ASSET,
         N.BUY_PROCESS,
         N.ELIGPAPER_VERSION,
         N.EN_INTERNAL_CONDITION,
         N.ISSUE_DATE,
         N.PAY_OVERTIME,
         N.EN_ENTRUST_WAY,
         N.EN_PAY_KIND,
         N.QUOTA_VALID_TERM,
         N.SUB_RISK_URL,
         N.ECONTRACT_VERSION,
         N.PROD_BACK_N,
         N.PRECISIONS,
         N.PRODCODE_CTRLSTR,
         N.CTRLSTR_USEFLAGS,
         N.IPO_BEGIN_TIME,
         N.IPO_END_TIME,
         N.PROM_BEGIN_DATE,
         N.PROM_END_DATE,
         N.SUBCONF_ENDDATE,
         N.SUBCONF_ENDTIME,
         N.PRE_END_DATE,
         N.PRE_END_TIME,
         N.PRESELL_BEGIN_DATE,
         N.PRESELL_END_DATE,
         N.PRESELL_BEGIN_TIME,
         N.PRESELL_END_TIME,
         N.PROMFARE_RATE,
         N.PROM_SCALE,
         N.MIN_TIMER_BALANCE,
         N.MAX_TIMER_BALANCE,
         N.PROD_INTEREST,
         N.PROD_PUT_PRICE,
         N.REBUY_PROP,
         N.TRIAL_DAYS,
         N.TRIAL_REORDER_MAX_TIME,
         N.MAX_DEFICIT_RATE,
         N.BANK_RISK_LEVEL,
         N.EN_COMPANY_NO,
         N.INTEREST_FREQ,
         N.PRODSUB_RATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-销售控制
  PROCEDURE PRO_TPIF_CPDM_P_GT_XSKZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN
    MERGE INTO TPIF_CPDM_P_GT_XSKZ M
    USING (SELECT A.CPID,
                  B.OPEN_SHARE,
                  B.MINSIZE,
                  B.MAX_PDSHARE,
                  B.ORG_MAX_PDSHARE,
                  B.MIN_SHARE,
                  B.ORG_LOWLIMIT_BALANCE,
                  B.ALLOT_LIMITSHARE,
                  B.ORG_APPEND_BALANCE,
                  B.MIN_SHARE2,
                  B.ORG_LOWLIMIT_BALANCE2,
                  B.ALLOT_LIMITSHARE2,
                  B.ORG_APPEND_BALANCE2,
                  B.SUM_SUB_BALANCE,
                  B.ORG_SUM_SUB_BALANCE,
                  B.PER_ONESUB_MAX_BALANCE,
                  B.ORG_ONESUB_MAX_BALANCE,
                  B.PER_ONEAPP_MAX_BALANCE,
                  B.ORG_ONEAPP_MAX_BALANCE,
                  B.PERHOLD_UP_LIMIT,
                  B.ORGHOLD_UP_LIMIT,
                  B.SUB_UNIT,
                  B.ORGAN_SUB_UNIT,
                  B.PER_APP_UNIT,
                  B.ORG_APP_UNIT,
                  B.MAX_PERRED_SHARE,
                  B.MAX_ORGRED_SHARE,
                  B.MAX_PERAPP_BALANCE,
                  B.MAX_ORGAPP_BALANCE,
                  B.MIN_PERFAPP_BALANCE,
                  B.MIN_ORGFAPP_BALANCE,
                  B.MIN_SUBSCRIBE_BALANCE,
                  B.MAX_SUBSCRIBE_BALANCE,
                  B.MIN_MERGEAMOUNT,
                  B.MIN_SPLITAMOUNT
             FROM TPIF_CPDM A, SRC_PIF.PRODCODE B
            WHERE A.CPDM = B.PROD_CODE
              AND A.CPTA = B.PRODTA_NO) N
    ON (M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.GRSCZDJE    = N.OPEN_SHARE,
             M.JGSCZDJE    = N.MINSIZE,
             M.GRDRZGRSGJE = N.MAX_PDSHARE,
             M.JGDRZGRSGJE = N.ORG_MAX_PDSHARE,
             M.GRZDRGJE    = N.MIN_SHARE,
             M.JGZDRGJE    = N.ORG_LOWLIMIT_BALANCE,
             M.GRZJRGJE    = N.ALLOT_LIMITSHARE,
             M.JGZJRGJE    = N.ORG_APPEND_BALANCE,
             M.GRZDSGJE    = N.MIN_SHARE2,
             M.JGZDSGJE    = N.ORG_LOWLIMIT_BALANCE2,
             M.GRZJSGJE    = N.ALLOT_LIMITSHARE2,
             M.JGZJSGJE    = N.ORG_APPEND_BALANCE2,
             M.GRLJZGRGJE  = N.SUM_SUB_BALANCE,
             M.JGLJZGRGJE  = N.ORG_SUM_SUB_BALANCE,
             M.GRDBZGRGJE  = N.PER_ONESUB_MAX_BALANCE,
             M.JGDBZGRGJE  = N.ORG_ONESUB_MAX_BALANCE,
             M.GRDBZGSGJE  = N.PER_ONEAPP_MAX_BALANCE,
             M.JGDBZGSGJE  = N.ORG_ONEAPP_MAX_BALANCE,
             M.GRCCLJSX    = N.PERHOLD_UP_LIMIT,
             M.JGCCLJSX    = N.ORGHOLD_UP_LIMIT,
             M.GRRGDW      = N.SUB_UNIT,
             M.JGRGDW      = N.ORGAN_SUB_UNIT,
             M.GRSGDW      = N.PER_APP_UNIT,
             M.JGSGDW      = N.ORG_APP_UNIT,
             M.GRZGSHFE    = N.MAX_PERRED_SHARE,
             M.JGZGSHFE    = N.MAX_ORGRED_SHARE,
             M.GRZGSGJE    = N.MAX_PERAPP_BALANCE,
             M.JGZGSGJE    = N.MAX_ORGAPP_BALANCE,
             M.GRSCZDSGJE  = N.MIN_PERFAPP_BALANCE,
             M.JGSCZDSGJE  = N.MIN_ORGFAPP_BALANCE,
             M.XHXXJE      = N.MIN_SUBSCRIBE_BALANCE,
             M.XHSXJE      = N.MAX_SUBSCRIBE_BALANCE,
             M.ZDHBSL      = N.MIN_MERGEAMOUNT,
             M.ZDCFSL      = N.MIN_SPLITAMOUNT
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         CPID,
         GRSCZDJE,
         JGSCZDJE,
         GRDRZGRSGJE,
         JGDRZGRSGJE,
         GRZDRGJE,
         JGZDRGJE,
         GRZJRGJE,
         JGZJRGJE,
         GRZDSGJE,
         JGZDSGJE,
         GRZJSGJE,
         JGZJSGJE,
         GRLJZGRGJE,
         JGLJZGRGJE,
         GRDBZGRGJE,
         JGDBZGRGJE,
         GRDBZGSGJE,
         JGDBZGSGJE,
         GRCCLJSX,
         JGCCLJSX,
         GRRGDW,
         JGRGDW,
         GRSGDW,
         JGSGDW,
         GRZGSHFE,
         JGZGSHFE,
         GRZGSGJE,
         JGZGSGJE,
         GRSCZDSGJE,
         JGSCZDSGJE,
         XHXXJE,
         XHSXJE,
         ZDHBSL,
         ZDCFSL)
      VALUES
        (N.CPID,
         N.CPID,
         N.OPEN_SHARE,
         N.MINSIZE,
         N.MAX_PDSHARE,
         N.ORG_MAX_PDSHARE,
         N.MIN_SHARE,
         N.ORG_LOWLIMIT_BALANCE,
         N.ALLOT_LIMITSHARE,
         N.ORG_APPEND_BALANCE,
         N.MIN_SHARE2,
         N.ORG_LOWLIMIT_BALANCE2,
         N.ALLOT_LIMITSHARE2,
         N.ORG_APPEND_BALANCE2,
         N.SUM_SUB_BALANCE,
         N.ORG_SUM_SUB_BALANCE,
         N.PER_ONESUB_MAX_BALANCE,
         N.ORG_ONESUB_MAX_BALANCE,
         N.PER_ONEAPP_MAX_BALANCE,
         N.ORG_ONEAPP_MAX_BALANCE,
         N.PERHOLD_UP_LIMIT,
         N.ORGHOLD_UP_LIMIT,
         N.SUB_UNIT,
         N.ORGAN_SUB_UNIT,
         N.PER_APP_UNIT,
         N.ORG_APP_UNIT,
         N.MAX_PERRED_SHARE,
         N.MAX_ORGRED_SHARE,
         N.MAX_PERAPP_BALANCE,
         N.MAX_ORGAPP_BALANCE,
         N.MIN_PERFAPP_BALANCE,
         N.MIN_ORGFAPP_BALANCE,
         N.MIN_SUBSCRIBE_BALANCE,
         N.MAX_SUBSCRIBE_BALANCE,
         N.MIN_MERGEAMOUNT,
         N.MIN_SPLITAMOUNT);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品业务设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_YWSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_YWSZ M
    USING (SELECT PROD_CODE,
                  PROD_TYPE,
                  PROD_STATUS,
                  REPLACE(EN_PRODBUSI_TYPE, ',', ';') AS EN_PRODBUSI_TYPE,
                  PRODTA_NO,
                  MODIFY_TIME,
                  (SELECT REPLACE(WM_CONCAT(ID), ',', ';')
                     FROM LIVEBOS.LBORGANIZATION A
                    WHERE A.FID IN (1209, 1)
                      AND INSTR(';' || EN_BRANCH_NO || ';',
                                ';' || A.BRANCH_NETWORK_ID || ';') > 0) AS EN_BRANCH_NO
             FROM SRC_PIF.PRODALLOWBUSIN) N
    ON (M.CPTABH = N.PRODTA_NO AND M.CPDM = N.PROD_CODE AND M.CPLB = N.PROD_TYPE AND M.CPZT = N.PROD_STATUS)
    WHEN MATCHED THEN
      UPDATE
         SET M.YXYWLB = N.EN_PRODBUSI_TYPE,
             M.YXYYB  = N.EN_BRANCH_NO,
             M.JLGXSJ = N.MODIFY_TIME
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPTABH, CPDM, CPLB, CPZT, YXYWLB, YXYYB, JLGXSJ)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_YWSZ'),
         N.PRODTA_NO,
         N.PROD_CODE,
         N.PROD_TYPE,
         N.PROD_STATUS,
         N.EN_PRODBUSI_TYPE,
         N.EN_BRANCH_NO,
         N.MODIFY_TIME);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品额度设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_EDSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_EDSZ M
    USING (SELECT PRODTA_NO,
                  PROD_CODE,
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTJGBZ'
                      AND CBM = ORGAN_FLAG) AS ORGAN_FLAG,
                  BUSINESS_FLAG,
                  MAX_SUB_QUATO,
                  MIN_SUB_QUATO,
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXWTFS'
                      AND CBM = ENTRUST_WAY) AS ENTRUST_WAY,
                  MAX_SHARE,
                  PERSON_UP_LIMITED,
                  UP_LIMITED,
                  CURR_LIMITED,
                  DATE_UP_LIMITED,
                  MODIFY_TIME,
                  (SELECT ID
                     FROM LIVEBOS.LBORGANIZATION A
                    WHERE BRANCH_NETWORK_ID = BRANCH_NO
                      AND A.FID IN (1209, 1)) AS BRANCH_NO, --只取营业部和总部
                  DAY_USED_QUOTA
             FROM SRC_PIF.PRODCONTROL) N
    ON (M.CPDM = N.PROD_CODE AND M.CPTABH = N.PRODTA_NO AND M.FZJG = N.BRANCH_NO AND M.YWBZ = N.BUSINESS_FLAG AND M.JGBZ = N.ORGAN_FLAG AND M.WTFS = N.ENTRUST_WAY)
    WHEN MATCHED THEN
      UPDATE
         SET M.DBRGSX = N.MAX_SUB_QUATO,
             M.DBRGXX = N.MIN_SUB_QUATO,
             M.ZDFE   = N.MAX_SHARE,
             M.DRSX   = N.PERSON_UP_LIMITED,
             M.SX     = N.UP_LIMITED,
             M.DQXE   = N.CURR_LIMITED,
             M.DTSX   = N.DATE_UP_LIMITED,
             M.JLGXSJ = N.MODIFY_TIME,
             M.DRYYED = N.DAY_USED_QUOTA
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         CPTABH,
         CPDM,
         JGBZ,
         YWBZ,
         DBRGSX,
         DBRGXX,
         WTFS,
         ZDFE,
         DRSX,
         SX,
         DQXE,
         DTSX,
         JLGXSJ,
         FZJG,
         DRYYED)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_EDSZ'),
         N.PRODTA_NO,
         N.PROD_CODE,
         N.ORGAN_FLAG,
         N.BUSINESS_FLAG,
         N.MAX_SUB_QUATO,
         N.MIN_SUB_QUATO,
         N.ENTRUST_WAY,
         N.MAX_SHARE,
         N.PERSON_UP_LIMITED,
         N.UP_LIMITED,
         N.CURR_LIMITED,
         N.DATE_UP_LIMITED,
         N.MODIFY_TIME,
         N.BRANCH_NO,
         N.DAY_USED_QUOTA);
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品延迟交收设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_YCJS(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS
  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_YCJS M
    USING (SELECT PRODTA_NO,
                  PROD_CODE,
                  DELAY_TYPE,
                  ALLOW_FLAG,
                  BUSINESS_FLAG,
                  TRIM(FARE_TYPE) AS FARE_TYPE,
                  DATE_COUNT,
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXZFFS'
                      AND CBM = PAY_KIND) AS PAY_KIND,
                  REPLACE(JS_DATE, 0, NULL) AS JS_DATE
             FROM SRC_PIF.PRODDELAYDATE) N
    ON (M.CPTABH = N.PRODTA_NO AND M.CPDM = N.PROD_CODE AND M.YWBZ = N.BUSINESS_FLAG AND M.YCLX = N.DELAY_TYPE AND M.ZFFS = N.PAY_KIND)
    WHEN MATCHED THEN
      UPDATE
         SET M.YXBZ = N.ALLOW_FLAG,
             M.FYLB = N.FARE_TYPE,
             M.YCTS = N.DATE_COUNT,
             M.JSRQ = N.JS_DATE
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPTABH, CPDM, YCLX, YXBZ, YWBZ, FYLB, YCTS, ZFFS, JSRQ)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_YCJS'),
         PRODTA_NO,
         PROD_CODE,
         DELAY_TYPE,
         ALLOW_FLAG,
         BUSINESS_FLAG,
         FARE_TYPE,
         DATE_COUNT,
         PAY_KIND,
         JS_DATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品折扣设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_ZKSZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN
    MERGE INTO TPIF_CPDM_P_GT_ZKSZ M
    USING (SELECT (SELECT ID
                     FROM LIVEBOS.LBORGANIZATION A
                    WHERE BRANCH_NETWORK_ID = BRANCH_NO) AS BRANCH_NO,
                  (SELECT IBM
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXWTFS'
                      AND CBM = ENTRUST_WAY) AS ENTRUST_WAY,
                  PRODTA_NO,
                  PROD_CODE,
                  BALANCE_STEP,
                  FUND_ACCOUNT,
                  ROOM_CODE,
                  BUSINESS_FLAG,
                  DISCOUNT_TYPE,
                  DISCOUNT_RATE,
                  SWITCH_PROD_CODE
             FROM SRC_PIF.PRODDISCOUNT) N
    ON (M.CPTABH = N.PRODTA_NO AND M.CPDM = N.PROD_CODE AND M.ZCZH = N.FUND_ACCOUNT AND M.KHSH = N.ROOM_CODE AND M.WTFS = N.ENTRUST_WAY AND M.YYB = N.BRANCH_NO AND M.YWBZ = N.BUSINESS_FLAG AND M.ZKLX = N.DISCOUNT_TYPE AND M.JEJD = N.BALANCE_STEP)
    WHEN MATCHED THEN
      UPDATE SET M.ZKBL = N.DISCOUNT_RATE, M.ZHDM = N.SWITCH_PROD_CODE
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         YYB,
         WTFS,
         CPTABH,
         CPDM,
         JEJD,
         ZCZH,
         KHSH,
         YWBZ,
         ZKLX,
         ZKBL,
         ZHDM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_ZKSZ'),
         BRANCH_NO,
         ENTRUST_WAY,
         PRODTA_NO,
         PROD_CODE,
         BALANCE_STEP,
         FUND_ACCOUNT,
         ROOM_CODE,
         BUSINESS_FLAG,
         DISCOUNT_TYPE,
         DISCOUNT_RATE,
         SWITCH_PROD_CODE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品限额设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_XESZ(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_XESZ M
    USING (SELECT PRODTA_NO,
                  PROD_CODE,
                  PRODBRANCH_ZONE,
                  NVL((SELECT ID
                        FROM LIVEBOS.LBORGANIZATION A
                       WHERE BRANCH_NETWORK_ID = BRANCH_NO
                         AND A.FID IN (1209, 1)),
                      0) AS BRANCH_NO,
                  (SELECT TO_CHAR(REPLACE(WM_CONCAT(IBM), ',', ';'))
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_GTYXWTFS'
                      AND INSTR(EN_ENTRUST_WAY, CBM) > 0) AS EN_ENTRUST_WAY,
                  MAX_SUBSCRIBE_NUM,
                  CURRENT_QUOTA,
                  ENABLE_QUOTA,
                  USED_SUBSCRIBE_NUM
             FROM SRC_PIF.PRODQUOT) N
    ON (M.CPTABM = N.PRODTA_NO AND M.CPDM = N.PROD_CODE AND M.YYQY = N.PRODBRANCH_ZONE AND M.FZJG = N.BRANCH_NO AND M.YXWTFS = N.EN_ENTRUST_WAY)
    WHEN MATCHED THEN
      UPDATE
         SET --M.YXWTFS = N.EN_ENTRUST_WAY,
             M.XHSRGSX = N.MAX_SUBSCRIBE_NUM,
             M.YYED    = N.CURRENT_QUOTA,
             M.ZED     = N.ENABLE_QUOTA,
             M.YYXHRGS = N.USED_SUBSCRIBE_NUM
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPTABM, CPDM, YYQY, FZJG, YXWTFS, XHSRGSX, YYED, ZED, YYXHRGS)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_XESZ'),
         PRODTA_NO,
         PROD_CODE,
         PRODBRANCH_ZONE,
         BRANCH_NO,
         EN_ENTRUST_WAY,
         MAX_SUBSCRIBE_NUM,
         CURRENT_QUOTA,
         ENABLE_QUOTA,
         USED_SUBSCRIBE_NUM);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品报送代码设置
  PROCEDURE PRO_TPIF_CPDM_P_GT_BSDMSZ(O_CODE     OUT NUMBER,
                                      O_NOTE     OUT VARCHAR2,
                                      O_ROWCOUNT OUT NUMBER,
                                      I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_BSDMSZ M
    USING (SELECT PRODTA_NO,
                  PROD_CODE,
                  PROD_NAME,
                  TA_NAME,
                  RELATIVE_CODE,
                  FULL_STATNAME,
                  CSRC_ASSIGN_NO
             FROM SRC_PIF.PRODSENDCODE) N
    ON (M.CPDM = N.PROD_CODE AND M.CPTADM = N.PRODTA_NO)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPMC    = N.PROD_NAME,
             M.JJGSMC  = N.TA_NAME,
             M.TJDM    = N.RELATIVE_CODE,
             M.TJDMMC  = N.FULL_STATNAME,
             M.ZJHFPHM = N.CSRC_ASSIGN_NO
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPTADM, CPDM, CPMC, JJGSMC, TJDM, TJDMMC, ZJHFPHM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_BSDMSZ'),
         PRODTA_NO,
         PROD_CODE,
         PROD_NAME,
         TA_NAME,
         RELATIVE_CODE,
         FULL_STATNAME,
         CSRC_ASSIGN_NO);
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品控制串
  PROCEDURE PRO_TPIF_CPDM_P_GT_KZC(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO TPIF_CPDM_P_GT_KZC M
    USING (SELECT PROD_TYPE, CTRLSTR_USEFLAGS, PRODTA_NO
             FROM SRC_PIF.PRODCONTRLSTRUSE) N
    ON (M.CPLX = N.PROD_TYPE AND NVL(M.CPTABM, '-1') = NVL(N.PRODTA_NO, '-1'))
    WHEN MATCHED THEN
      UPDATE SET M.CPKZC = N.CTRLSTR_USEFLAGS
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPLX, CPKZC, CPTABM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_KZC'),
         PROD_TYPE,
         CTRLSTR_USEFLAGS,
         PRODTA_NO);
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --集中柜台-产品TA信息
  PROCEDURE PRO_TPIF_TADM(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER) AS

  BEGIN
    MERGE INTO TPIF_TADM M
    USING (SELECT PROD_TYPE,
                  PRODTA_NO,
                  TA_NAME,
                  TA_SHORTNAME,
                  AGENCY_NO,
                  AGENCY_NAME,
                  TA_CTRLSTR
             FROM SRC_PIF.PRODARG) N
    ON (M.TABM = N.PRODTA_NO)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPLX   = N.PROD_TYPE,
             M.TAMC   = N.TA_NAME,
             M.TAJC   = N.TA_SHORTNAME,
             M.DLJGBH = N.AGENCY_NO,
             M.DLJGMC = N.AGENCY_NAME,
             M.KZC    = N.TA_CTRLSTR
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPLX, TABM, TAMC, TAJC, DLJGBH, DLJGMC, KZC)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_P_GT_KZC'),
         N.PROD_TYPE,
         N.PRODTA_NO,
         N.TA_NAME,
         N.TA_SHORTNAME,
         N.AGENCY_NO,
         N.AGENCY_NAME,
         N.TA_CTRLSTR);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

    PROCEDURE PRO_TPIF_CPJZ(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER)

   AS
      V_COUNT NUMBER;
   BEGIN
      /************1.公募净值********************************************/

  --   公募基金净值_货币型基金MF_MFNETVALUE  ????
  --  公募基金净值  MF_NETVALUE
  SELECT COUNT(*)
    INTO V_COUNT
    FROM TPIF_CPJZ A, TPIF_CPDM B
   WHERE A.CPID = B.CPID
     AND B.CPXL = 1;
  IF V_COUNT = 0 THEN
    --第一次更新所有
    INSERT INTO TPIF_CPJZ( ID,
                           CPID,
                           JZRQ,
                           ZCJZ,
                           DWJZ,
                           LJJZ,
                           -- FQJZ,
                           NHSYL,
                           WFSYL,
                           ZZF, --周涨幅
                           SJLY,
                           QRZT,
                           CZSJ
                        )
      SELECT SEQ_TPIF_CPJZ.NEXTVAL,
             C.CPID,
             TO_CHAR(A.ENDDATE, 'YYYYMMDD'),
             A.NV, --资产净值
             A.UNITNV, --单位净值
             A.ACCUMULATEDUNITNV, --累计净值
             A.LATESTWEEKLYYIELD, --七日年化
             A.DAILYPROFIT， --每万份基金单位当日收益(元)
             NVWEEKLYGROWTHRATE, --单位基金净值周增长率
             2,
             1,
             SYSDATE
        FROM SRC_PIF.MF_NETVALUE A, SRC_PIF.SECUMAIN B, PIF.TPIF_CPDM C
       WHERE A.INNERCODE = B.INNERCODE
         AND C.CPDM = B.SECUCODE
         /*AND C.CPXL = 1
         AND TO_CHAR(A.ENDDATE, 'YYYYMMDD') >= TO_CHAR(SYSDATE - 365 * 3, 'YYYYMMDD')*/;

    /* --复权净值更新*/
    MERGE INTO  TPIF_CPJZ M
      USING( SELECT X.CPID, X.TRADINGDAY, X.UNITNVRESTORED
                  FROM (SELECT /*+PARALLEL(XX,8) */
                         C.CPID,
                         TO_CHAR(TRADINGDAY, 'YYYYMMDD') AS TRADINGDAY,
                         UNITNVRESTORED,
                         ROW_NUMBER() OVER(PARTITION BY XX.INNERCODE, XX.TRADINGDAY ORDER BY UPDATETIME DESC) AS RNN
                          FROM SRC_PIF.MF_FUNDNETVALUERE    XX, SRC_PIF.SECUMAIN B, PIF.TPIF_CPDM C
                         WHERE XX.INNERCODE = B.INNERCODE
                           AND B.SECUCODE = C.CPDM
                           AND C.CPXL = 1
                           AND TO_CHAR(TRADINGDAY, 'YYYYMMDD') >= TO_CHAR(SYSDATE - 365 * 3, 'YYYYMMDD')
                           AND UNITNVRESTORED IS NOT NULL) X ---首日如果没有净值（记录不存在或者净值为空），则不考虑
                 WHERE RNN = 1 ) N
     ON(M.CPID =N.CPID AND M.JZRQ = N.TRADINGDAY)
     WHEN MATCHED THEN  UPDATE SET M.FQJZ = N.UNITNVRESTORED;

    ---XGRQ 更新日期,更新近10天的净值数据
  ELSE

    MERGE INTO PIF.TPIF_CPJZ M
    USING (SELECT C.CPID,
                  TO_CHAR(A.ENDDATE, 'YYYYMMDD') JZRQ,
                  A.NV, --资产净值
                  A.UNITNV, --单位净值
                  A.ACCUMULATEDUNITNV, --累计净值
                  A.LATESTWEEKLYYIELD, --七日年化
                  A.DAILYPROFIT， --每万份基金单位当日收益(元)
                  NVWEEKLYGROWTHRATE --单位基金净值周增长率
             FROM SRC_PIF.MF_NETVALUE A, SRC_PIF.SECUMAIN B, PIF.TPIF_CPDM C
            WHERE A.INNERCODE = B.INNERCODE
              AND C.CPDM = B.SECUCODE
              --AND C.CPXL = 1
              AND TO_CHAR(A.XGRQ, 'YYYYMMDD') >=
                  TO_CHAR(SYSDATE - 10, 'YYYYMMDD')) N
    ON (M.CPID = N.CPID AND M.JZRQ = N.JZRQ)
    WHEN MATCHED THEN
      UPDATE SET M.ZCJZ  = N.NV, --资产净值,
             M.DWJZ  = N.UNITNV, --单位净值
             M.LJJZ  = N.ACCUMULATEDUNITNV, --累计净值
             M.NHSYL = N.LATESTWEEKLYYIELD, --七日年化
             M.WFSYL = N.DAILYPROFIT， --每万份基金单位当日收益(元)
             M.ZZF = NVWEEKLYGROWTHRATE --单位基金净值周增长率

    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         CPID,
         JZRQ,
         ZCJZ,
         DWJZ,
         LJJZ,
         -- FQJZ,
         NHSYL,
         WFSYL,
         ZZF, --周涨幅
         SJLY,
         QRZT,
         CZSJ)
      VALUES
        (SEQ_TPIF_CPJZ.NEXTVAL,
         N.CPID,
         N.JZRQ,
         N.NV, --资产净值
         N.UNITNV, --单位净值
         N.ACCUMULATEDUNITNV, --累计净值
         N.LATESTWEEKLYYIELD, --七日年化
         N.DAILYPROFIT， --每万份基金单位当日收益(元)
         N.NVWEEKLYGROWTHRATE, --单位基金净值周增长率
         2,
         1,
         SYSDATE);

    /* --复权净值更新*/
    MERGE INTO  TPIF_CPJZ M
      USING( SELECT X.CPID, X.TRADINGDAY, X.UNITNVRESTORED
                  FROM (SELECT /*+PARALLEL(XX,8) */
                         C.CPID,
                         TO_CHAR(TRADINGDAY, 'YYYYMMDD') AS TRADINGDAY,
                         UNITNVRESTORED,
                         ROW_NUMBER() OVER(PARTITION BY XX.INNERCODE, XX.TRADINGDAY ORDER BY UPDATETIME DESC) AS RNN
                          FROM SRC_PIF.MF_FUNDNETVALUERE    XX, SRC_PIF.SECUMAIN B, PIF.TPIF_CPDM C
                         WHERE XX.INNERCODE = B.INNERCODE
                           AND B.SECUCODE = C.CPDM
                           AND C.CPXL = 1
                           AND TO_CHAR(XX.UPDATETIME, 'YYYYMMDD') >= TO_CHAR(SYSDATE - 10, 'YYYYMMDD')
                           AND UNITNVRESTORED IS NOT NULL) X ---首日如果没有净值（记录不存在或者净值为空），则不考虑
                 WHERE RNN = 1 ) N
     ON(M.CPID =N.CPID AND M.JZRQ = N.TRADINGDAY)
     WHEN MATCHED THEN  UPDATE SET M.FQJZ = N.UNITNVRESTORED;


  END IF;

  /************2.非公募********************************************/
  SELECT COUNT(*)
    INTO V_COUNT
    FROM TPIF_CPJZ A, TPIF_CPDM B
   WHERE A.CPID = B.CPID
     AND B.CPXL>1;
  IF V_COUNT = 0 THEN
    --第一次插入所有净值数据
    INSERT INTO TPIF_CPJZ
      (ID, CPID, JZRQ,  ZCJZ,DWJZ,LJJZ, SJLY, QRZT,CZSJ)
      SELECT SEQ_TPIF_CPJZ.NEXTVAL, B.CPID, A.NAV_DATE,  A.TOTAL_SHARE*A.NET_VALUE, A.NET_VALUE,A.NAV_TOTAL ,  5  , 1,SYSDATE
        FROM SRC_PIF.PRODPRICE A, PIF.TPIF_CPDM B
       WHERE TRIM(A.PROD_CODE) = B.CPDM AND A.PRODTA_NO=B.CPTA
         AND B.CPXL>1;

    --更新近60天的净值数据
  ELSE
    MERGE INTO PIF.TPIF_CPJZ M
    USING ( SELECT   B.CPID, A.NAV_DATE, A.TOTAL_SHARE*A.NET_VALUE AS ZCJZ, A.NET_VALUE,A.NAV_TOTAL
                FROM SRC_PIF.PRODPRICE A, PIF.TPIF_CPDM B
               WHERE TRIM(A.PROD_CODE) = B.CPDM AND A.PRODTA_NO=B.CPTA
                 AND B.CPXL>1
              AND A.NAV_DATE >= TO_CHAR(SYSDATE - 60, 'YYYYMMDD')) N
    ON (M.CPID = N.CPID AND M.JZRQ = N.NAV_DATE)
    WHEN MATCHED THEN
      UPDATE SET M.DWJZ = N.NET_VALUE, --单位净值
                 M.LJJZ = N.NAV_TOTAL,
                 M.ZCJZ = N.ZCJZ

    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPID,JZRQ,ZCJZ ,DWJZ,LJJZ ,SJLY, QRZT,CZSJ)
      VALUES
        (SEQ_TPIF_CPJZ.NEXTVAL,
         N.CPID,
         N.NAV_DATE,
         N.ZCJZ,
         N.NET_VALUE,
         N.NAV_TOTAL,
         5,
         1,
         SYSDATE);

  END IF;


  --更新TPIF_CPDM 表净值信息
    --3.净值更新

    /*JZRQ  净值日期
     CPJZ  单位净值
     LJJZ  累计净值
     QRNHSYL 七日年化收益率
     WFSYL 万份单位收益
    */
   MERGE INTO PIF.TPIF_CPDM M
   USING( SELECT X.CPID, X.JZRQ, X.DWJZ,X.LJJZ,X.FQJZ,X.NHSYL,X.WFSYL
                  FROM (SELECT A.CPID,
                               A.JZRQ,
                               A.DWJZ,
                               A.LJJZ,
                               A.FQJZ,
                               A.NHSYL,
                               A.WFSYL,
                             ROW_NUMBER() OVER(PARTITION BY A.CPID  ORDER BY A.JZRQ DESC) AS RNN
                          FROM PIF.TPIF_CPJZ A
                          -- WHERE A.JZRQ >= TO_CHAR(SYSDATE-365,'YYYYMMDD')
                          ) X
                 WHERE RNN = 1  ）N
   ON( M.CPID =N.CPID )
   WHEN MATCHED THEN UPDATE
                        SET M.JZRQ = N.JZRQ,
                            M.CPJZ = N.DWJZ,
                            M.LJJZ = N.LJJZ,
                            M.QRNHSYL = N.NHSYL,
                            M.WFSYL = N.WFSYL;

   


    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  
  --公募基金扩展属性 TPIF_CPDM_N_GMJJ
  PROCEDURE PRO_TPIF_CPDM_N_GMJJ( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
                                  
                                                               
  AS
  BEGIN
    
      MERGE INTO TPIF_CPDM_N_GMJJ M
      USING(SELECT B.CPID,
                   A.FUNDTYPECODE,    --基金类别
                   A.APPLYINGCODEFRONT,   --前端申购代码
                   A.APPLYINGCODEBACK, --后端申购代码
                   A.EXAPPLYINGCODE, --场内申赎代码
                   A.TYPE --基金运作方式
                   
           FROM SRC_PIF.MF_FUNDARCHIVES A,
                TPIF_CPDM B
           WHERE A.INNERCODE = B.JYNM )N
      ON(M.CPID = N.CPID)
      WHEN NOT MATCHED THEN 
        INSERT(ID, 
              CPID, 
              JJLX, 
              QDDM, 
              HDDM, 
              CNSGDM, 
              JJYZFS
              )
         VALUES(N.CPID,
                N.CPID,
                N.FUNDTYPECODE,
                N.APPLYINGCODEFRONT,
                N.APPLYINGCODEBACK,
                N.EXAPPLYINGCODE,
                N.TYPE
               )
       WHEN MATCHED THEN UPDATE
          SET M.JJLX = N.FUNDTYPECODE, 
              M.QDDM = N.APPLYINGCODEFRONT,  
              M.HDDM = N.APPLYINGCODEBACK,  
              M.CNSGDM = N.EXAPPLYINGCODE,  
              M.JJYZFS = N.TYPE
          ;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  
  
  --产品销售费率 TPIF_CPDM_GL_XSFL
  PROCEDURE PRO_TPIF_CPDM_GL_XSFL( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 
    V_COUNT NUMBER;
  BEGIN
    
  --第一次全量 
  SELECT COUNT(*) INTO V_COUNT FROM PIF.TPIF_CPDM_GL_XSFL A WHERE A.SJLY = 3;

  --增量更新近3天数据
  IF V_COUNT > 0 THEN
  
    MERGE INTO PIF.TPIF_CPDM_GL_XSFL M
    USING (SELECT C.CPID,
                  A.ID,
                  TO_CHAR(A.EXCUTEDATE, 'yyyymmdd') QSRQ,
                  TO_CHAR(A.CANCELDATE, 'yyyymmdd') ZZRQ,
                  A.CHARGERATETYPE,
                  A.CHARGERATETYDES,
                  A.CLIENTTYPE,
                  A.MINCHARGERATE,
                  A.MAXCHARGERATE,
                  A.CHARGERATEUNIT,
                  A.DIVINTERVALDES,
                  A.DIVSTANDUNIT1,
                  A.STDIVSTAND1,
                  A.ENDIVSTAND1,
                  A.IFAPPLYSTART1,
                  A.IFAPPLYEND1,
                  A.XGRQ
             FROM SRC_PIF.MF_CHARGERATENEW A,
                  PIF.TPIF_CPDM            C
            WHERE A.INNERCODE =  C.JYNM 
              AND A.CHARGERATETYPE IN (10220 ,10210  ,10020  ,10010  ,11010  ,11020  ,11210  ,11220  ,12000  ,12200  ,12023  ,12223  ,15000  ,16000  ,22210  ,22220  ,22010  ,22020  ,19000  ,13000 ,13010 ,13020 ,14000 ,14010 ,14020)                       
              AND TO_CHAR(A.XGRQ, 'yyyymmdd') >
                  TO_CHAR(SYSDATE - 10, 'yyyymmdd') --更新近10天
           ) N
    ON (M.JYID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.QSRQ    = N.QSRQ, --  起始日期                                                                                  
             M.ZZRQ    = N.ZZRQ, --  终止日期                                                                                  
             M.FL    = N.MINCHARGERATE, -- 费率上限                                                                                                                                     
             M.FLDW   =
             (CASE
               WHEN N.CHARGERATEUNIT = 6 THEN
                1
               WHEN N.CHARGERATEUNIT = 7 THEN
                2
             END), -- 费率单位 6-%，7-元
             M.FLQJMS  = N.DIVINTERVALDES, --  费率区间描述                                                                    
             M.FLHFDW  = N.DIVSTANDUNIT1, -- 费率划分标准单位                                                                  
             M.FLHFQSZ = N.STDIVSTAND1, -- 费率划分起始数值                                                                    
             M.FLHFJZZ = N.ENDIVSTAND1 -- 费率划分截止数值     
      
    
    WHEN NOT MATCHED THEN
      INSERT
        (ID, --  ID
         JYID,
         SJLY, --  数据来源
         CPID, --  产品名称
         FLLB, --  费率类别
         QSRQ, --  起始日期
         ZZRQ, --  终止日期
         FL, --  费率上限
         FLDW, --  费率单位
         FLQJMS, --  费率区间描述
         FLHFDW, --  费率划分标准单位
         FLHFQSZ, --  费率划分起始数值
         FLHFJZZ, --  费率划分截止数值
         ZKL, --  折扣率
         ZT, --  状态
         LRR, --  录入人
         LRSJ --  录入时间
 )
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_GL_XSFL'), --  ID
         N.ID,
         3, --  聚源采集
         N.CPID, --  产品名称
         (CASE
           WHEN CHARGERATETYPE IN (10220, 10210, 10020, 10010) THEN
            1   --认购费率
           WHEN CHARGERATETYPE IN (11010, 11220, 11210, 11020) THEN
            2   --申购费率
           WHEN CHARGERATETYPE IN (12000, 12023, 12200, 12223) THEN
            3   --赎回费率
           WHEN CHARGERATETYPE = 15000 THEN
            4
           WHEN CHARGERATETYPE = 16000 THEN
            5
           WHEN CHARGERATETYPE IN (22220, 22210, 22020, 22010) THEN
            6
           WHEN CHARGERATETYPE = 19000 THEN
            7
           WHEN CHARGERATETYPE IN (13000, 13010, 13020) THEN
            8
           WHEN CHARGERATETYPE IN (14000, 14010, 14020) THEN
            9 
         END),
         
   /*      1	认购费率
          2	申购费率
          3	赎回费率
          4	年管理费
          5	年托管费
          6	定期定额申购费率
          7	销售服务费
          8	转换费率
          9	代销费率*/

         
         
         N.QSRQ, --  起始日期
         N.ZZRQ, --  终止日期
         N.MAXCHARGERATE, -- 费率
         (CASE
           WHEN N.CHARGERATEUNIT = 6 THEN
            1
           WHEN N.CHARGERATEUNIT = 7 THEN
            2
         END), -- 费率单位 6-%，7-元
         N.DIVINTERVALDES, --  费率区间描述
         N.DIVSTANDUNIT1, -- 费率划分标准单位
         N.STDIVSTAND1, -- 费率划分起始数值
         N.ENDIVSTAND1, -- 费率划分截止数值
         1, -- 折扣率，默认给1，后面更新
         4, -- 状态
         0, -- 录入人
         SYSDATE --  录入时间
         );
  ELSE
    
    INSERT INTO PIF.TPIF_CPDM_GL_XSFL
      (ID, --  ID
       JYID,
       SJLY, --  数据来源
       CPID, --  产品名称
       FLLB, --  费率类别
       QSRQ, --  起始日期
       ZZRQ, --  终止日期
       FL, --  费率上限
       FLDW, --  费率单位
       FLQJMS, --  费率区间描述
       FLHFDW, --  费率划分标准单位
       FLHFQSZ, -- 费率划分起始数值
       FLHFJZZ, -- 费率划分截止数值
       ZKL, -- 折扣率
       ZT, --  状态
       LRR, -- 录入人
       LRSJ -- 录入时间
       )
      SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPDM_GL_XSFL'), -- ID
             A.ID,
             3, -- 聚源采集
             C.CPID, --  产品名称
              (CASE
                     WHEN CHARGERATETYPE IN (10220, 10210, 10020, 10010) THEN
                      1   --认购费率
                     WHEN CHARGERATETYPE IN (11010, 11220, 11210, 11020) THEN
                      2   --申购费率
                     WHEN CHARGERATETYPE IN (12000, 12023, 12200, 12223) THEN
                      3   --赎回费率
                     WHEN CHARGERATETYPE = 15000 THEN
                      4
                     WHEN CHARGERATETYPE = 16000 THEN
                      5
                     WHEN CHARGERATETYPE IN (22220, 22210, 22020, 22010) THEN
                      6
                     WHEN CHARGERATETYPE = 19000 THEN
                      7
                     WHEN CHARGERATETYPE IN (13000, 13010, 13020) THEN
                      8
                     WHEN CHARGERATETYPE IN (14000, 14010, 14020) THEN
                      9 
                   END),
             TO_CHAR(A.EXCUTEDATE, 'yyyymmdd') QSRQ,
             TO_CHAR(A.CANCELDATE, 'yyyymmdd') ZZRQ,
             A.MAXCHARGERATE, -- 费率
             (CASE
               WHEN A.CHARGERATEUNIT = 6 THEN
                1
               WHEN A.CHARGERATEUNIT = 7 THEN
                2
             END), -- 费率单位 6-%，7-元
             A.DIVINTERVALDES, --  费率区间描述
             A.DIVSTANDUNIT1, -- 费率划分标准单位
             A.STDIVSTAND1, -- 费率划分起始数值
             A.ENDIVSTAND1, -- 费率划分截止数值
             1, -- 折扣率，默认给1，后面更新
             4, -- 状态
             0, -- 录入人
             SYSDATE --  录入时间
        FROM SRC_PIF.MF_CHARGERATENEW A,
             SRC_PIF.SECUMAIN         B,
             PIF.TPIF_CPDM            C
       WHERE A.INNERCODE = B.INNERCODE
         AND B.SECUCODE = C.CPDM
         AND C.CPXL = 1
         AND A.CHARGERATETYPE IN (10220 ,10210  ,10020  ,10010  ,11010  ,11020  ,11210  ,11220  ,12000  ,12200  ,12023  ,12223  ,15000  ,16000  ,22210  ,22220  ,22010  ,22020  ,19000  ,13000 ,13010 ,13020 ,14000 ,14010 ,14020) ;
  
  END IF;
  
  --更新折扣率
  
    --1）通过TA

    MERGE INTO PIF.TPIF_CPDM_GL_XSFL M
    USING (SELECT B.CPID, 
                  A.DISCOUNT_RATE,
                  A.BALANCE_STEP
             FROM SRC_PIF.PRODDISCOUNT A, PIF.TPIF_CPDM B
            WHERE A.PROD_CODE='!' 
              AND A.PRODTA_NO = B.CPTA
              AND A.BUSINESS_FLAG = '44022') N
    ON (M.CPID = N.CPID AND M.FLHFQSZ <= N.BALANCE_STEP)
    WHEN MATCHED THEN
      UPDATE SET M.ZKL = N.DISCOUNT_RATE
    WHERE M.FLLB=2;--只更新申购费率的折扣率
    
    
    --2) 通过CPDM
    MERGE INTO PIF.TPIF_CPDM_GL_XSFL M
    USING (SELECT B.CPID, 
                  A.DISCOUNT_RATE,
                  A.BALANCE_STEP
             FROM SRC_PIF.PRODDISCOUNT A, PIF.TPIF_CPDM B
            WHERE A.PROD_CODE = B.CPDM
              AND A.PRODTA_NO = B.CPTA
              AND A.BUSINESS_FLAG = '44022') N
    ON (M.CPID = N.CPID AND M.FLHFQSZ <= N.BALANCE_STEP)
    WHEN MATCHED THEN
      UPDATE SET M.ZKL = N.DISCOUNT_RATE
    WHERE M.FLLB=2;--只更新申购费率的折扣率

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

--基金分红信息-TPIF_CPDM_GL_JJFH                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJFH( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN 
    MERGE INTO TPIF_CPDM_GL_JJFH M
    USING( SELECT B.CPID,
                   TO_CHAR(A.ENDDATE, 'yyyymmdd') AS JZRQ,
                   A.IFDISTRIBUTED AS SFFH,
                   A.DIVIDENDRATIOBEFORETAX AS PXBL,
                   A.ACTUALRATIOAFTERTAX SPBL,
                   A.DIVIDENDSUM AS PXHEHJ,
                   TO_CHAR(A.REDATE, 'yyyymmdd') AS QYDJR,
                   TO_CHAR(A.EXRIGHTDATE, 'yyyymmdd') AS CXR,
                   TO_CHAR(A.EXECUTEDATE, 'yyyymmdd') AS FFR,
                   TO_CHAR(A.REINVESTDAY, 'yyyymmdd') AS HLZTZR,
                   TO_CHAR(A.ACCOUNTDAY, 'yyyymmdd') AS HLZTZRFEDZR,
                   TO_CHAR(A.REDEMPTIONDAY, 'yyyymmdd') AS HLZTZRFEKSHR
              FROM SRC_PIF.MF_DIVIDEND A,
                   TPIF_CPDM B
              WHERE A.INNERCODE = B.JYNM ) N
    ON(M.CPID = N.CPID AND M.JZRQ = N.JZRQ)
    WHEN MATCHED THEN UPDATE
      SET M.SFFH = N.SFFH, 
          M.PXBL = N.PXBL, 
          M.SPBL = N.SPBL, 
          M.PXHEHJ = N.PXHEHJ, 
          M.QYDJR = N.QYDJR, 
          M.CXR = N.CXR, 
          M.FFR = N.FFR, 
          M.HLZTZR = N.HLZTZR,  
          M.HLZTZRFEDZR = N.HLZTZRFEDZR,  
          M.HLZTZRFEKSHR = N.HLZTZRFEKSHR
    WHEN NOT MATCHED THEN 
      INSERT( ID, 
              CPID, 
              JZRQ, 
              SFFH, 
              PXBL, 
              SPBL, 
              PXHEHJ, 
              QYDJR, 
              CXR, 
              FFR, 
              HLZTZR, 
              HLZTZRFEDZR, 
              HLZTZRFEKSHR, 
              LRR, 
              LRSJ  )
       VALUES(SEQ_TPIF_CPDM_GL_JJFH.NEXTVAL,
              N.CPID, 
              N.JZRQ, 
              N.SFFH, 
              N.PXBL, 
              N.SPBL, 
              N.PXHEHJ, 
              N.QYDJR, 
              N.CXR, 
              N.FFR, 
              N.HLZTZR, 
              N.HLZTZRFEDZR, 
              N.HLZTZRFEKSHR, 
              0, 
              SYSDATE  );
    
  
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

--基金拆分信息-TPIF_CPDM_GL_JJCF                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJCF( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN
    
    MERGE INTO TPIF_CPDM_GL_JJCF M
    USING( SELECT  B.CPID,
                   A.INFOTYPE AS LX,
                   ROUND(A.SPLITRATIO, 6) AS CFZSBL,
                   TO_CHAR(A.SPLITDAY, 'YYYYMMDD') AS CFZSR,
                   TO_CHAR(A.OUTCOMENOTICEISSUEDATE, 'YYYYMMDD') AS JGGBR,
                   TO_CHAR(A.CHANGEREGDATE, 'YYYYMMDD') AS FEBGDJR
              FROM SRC_PIF.MF_SHARESSPLIT A,
                   TPIF_CPDM B
                   WHERE A.INNERCODE = B.JYNM ) N
    ON(M.CPID = N.CPID AND M.LX = N.LX AND M.CFZSR = N.CFZSR)
    WHEN MATCHED THEN UPDATE
      SET M.CFZSBL = N.CFZSBL,
          M.JGGBR = N.JGGBR,
          M.FEBGDJR = FEBGDJR
    WHEN NOT MATCHED THEN
      INSERT( ID, 
              CPID, 
              LX, 
              CFZSBL, 
              CFZSR, 
              JGGBR, 
              FEBGDJR, 
              LRR, 
              LRSJ
              )
     VALUES(SEQ_TPIF_CPDM_GL_JJCF.NEXTVAL,
            N.CPID,
            N.LX,
            N.CFZSBL,
            N.CFZSR,
            N.JGGBR,
            N.FEBGDJR,
            0,
            SYSDATE
      );

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

--基金行业投资-TPIF_CPDM_GL_JJHYTZ                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJHYTZ( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN
    
    MERGE INTO TPIF_CPDM_GL_JJHYTZ M
    USING(SELECT B.CPID,
                 TO_CHAR(A.REPORTDATE,'YYYYMMDD') BBQ, --报告期
                 A.INVESTTYPE TZLX, --投资类型 1|综合投资;2|积极投资;3|指数投资;4|境内投资;5|沪港通投资
                 A.INDUSTRYCODE HYDM, --行业代码
                 A.INDUSTRYNAME HYMC, --行业名称
                 A.MARKETVALUE HYSZ, --行业市值(元)
                 A.RATIOINNV ZZCJZBL  --占资产净值比例
            FROM SRC_PIF.MF_INVESTINDUSTRY A,
                 TPIF_CPDM B
             WHERE A.INNERCODE = B.JYNM 
               AND A.INDUSTRYNAME<>'行业投资合计' ) N
    ON( M.CPID = N.CPID AND M.BBQ = N.BBQ AND M.HYDM = N.HYDM AND M.TZLX = N.TZLX)
    WHEN NOT MATCHED THEN 
      INSERT (ID, 
              CPID, 
              BBQ, 
              TZLX, 
              HYDM, 
              HYMC, 
              HYSZ, 
              ZZCJZBL, 
              LRR, 
              LRSJ  )
      VALUES( SEQ_TPIF_CPDM_GL_JJHYTZ.NEXTVAL, 
              N.CPID, 
              N.BBQ, 
              N.TZLX, 
              N.HYDM, 
              N.HYMC, 
              N.HYSZ, 
              N.ZZCJZBL, 
              0, 
              SYSDATE );
  
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;


--基金资产配置-TPIF_CPDM_GL_JJZCPZ                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZCPZ( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN
    
    MERGE INTO TPIF_CPDM_GL_JJZCPZ M
    USING (SELECT B.CPID AS CPID,
                  TO_CHAR(A.REPORTDATE, 'YYYYMMDD') AS BBQ,
                  A.ASSETTYPECODE AS ZCZLDM,
                  A.ASSETTYPE AS ZCZLMC,
                  A.MARKETVALUE AS ZCSZ,
                  A.RATIOINTOTALASSET AS ZZCZZBL,
                  A.RATIOINNV AS ZZCJZBL
             FROM SRC_PIF.MF_ASSETALLOCATION A, TPIF_CPDM B
            WHERE A.INNERCODE = B.JYNM
              AND A.ASSETTYPECODE IN (10020, 10010, 1000202) --股票、债券、现金
           ) N
    ON (M.CPID = N.CPID AND M.BBQ = N.BBQ AND M.ZCZLDM = N.ZCZLDM)
    WHEN NOT MATCHED THEN
      INSERT
        (ID, CPID, BBQ, ZCZLDM, ZCZLMC, ZCSZ, ZZCZZBL, ZZCJZBL, LRR, LRSJ)
      VALUES
        (SEQ_TPIF_CPDM_GL_JJZCPZ.NEXTVAL,
         N.CPID,
         N.BBQ,
         N.ZCZLDM,
         N.ZCZLMC,
         N.ZCSZ,
         N.ZZCZZBL,
         N.ZZCJZBL,
         0,
         SYSDATE);
  
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;


--基金重仓股票-TPIF_CPDM_GL_JJZCGP                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZCGP( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN
    
      MERGE INTO TPIF_CPDM_GL_JJZCGP M
      USING (SELECT D.CPID,
                    TO_CHAR(A.REPORTDATE, 'YYYYMMDD') AS BBQ,
                    A.SERIALNUMBER XH,
                    NVL(B.SECUCODE,C.SECUCODE) GPDM,
                    NVL(B.CHINAMEABBR,C.SECUABBR) GPMC,
                    A.SHARESHOLDING CGSL,
                    A.CHANGEOFSHARESHOLDING JSQCCBD,
                    ROUND(A.MARKETVALUE,2) ZQSZ,
                    A.RATIOINNV ZZCJZBL,
                    A.INVESTTYPE TZLX
               FROM SRC_PIF.MF_KEYSTOCKPORTFOLIO A,
                    SRC_PIF.SECUMAIN             B,
                    SRC_PIF.HK_SECUMAIN          C,
                    TPIF_CPDM                    D
              WHERE A.STOCKINNERCODE = B.INNERCODE(+)
                AND A.STOCKINNERCODE = C.INNERCODE(+)
                AND A.INNERCODE = D.JYNM
              ORDER BY BBQ) N
      ON (M.CPID = N.CPID AND M.BBQ = N.BBQ AND M.GPDM = N.GPDM and m.tzlx=n.tzlx)
      WHEN MATCHED THEN
        UPDATE
           SET M.CGSL    = N.CGSL,
               M.JSQCCBD = N.JSQCCBD,
               M.ZQSZ    = N.ZQSZ,
               M.ZZCJZBL = N.ZZCJZBL,
              -- M.TZLX    = N.TZLX,
               M.XH = N.XH
      WHEN NOT MATCHED THEN
        INSERT
          (ID,
           CPID,
           BBQ,
           XH,
           GPDM,
           GPMC,
           CGSL,
           JSQCCBD,
           ZQSZ,
           ZZCJZBL,
           TZLX,
           LRR,
           LRSJ)
        VALUES
          (SEQ_TPIF_CPDM_GL_JJZCGP.NEXTVAL,
           N.CPID,
           N.BBQ,
           N.XH,
           N.GPDM,
           N.GPMC,
           N.CGSL,
           N.JSQCCBD,
           N.ZQSZ,
           N.ZZCJZBL,
           N.TZLX,
           0,
           SYSDATE);

  
    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

--基金债券组合明细 TPIF_CPDM_GL_JJZQZH                  
  PROCEDURE PRO_TPIF_CPDM_GL_JJZQZH( O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER)
  AS 

  BEGIN
    
    MERGE INTO TPIF_CPDM_GL_JJZQZH  M
    USING( SELECT  C.CPID,
                   TO_CHAR(A.REPORTDATE, 'YYYYMMDD') BBQ,
                   A.SERIALNUMBER SEQNO,
                   B.SECUCODE ZQDM,
                   B.CHINAME  ZQMC,
                   A.HOLDVOLUME CYZS,
                   ROUND(A.MARKETVALUE, 2) ZQSZ,
                   A.RATIOINNV ZZCJZBL,
                   A.IFINCONVERTIBLETERM BGQMSFCYZGQ
              FROM SRC_PIF.MF_BONDPORTIFOLIODETAIL A, 
                   SRC_PIF.SECUMAIN B, 
                   TPIF_CPDM C
             WHERE A.BONDCODE = B.INNERCODE
               AND A.INNERCODE = C.JYNM
             ORDER BY  BBQ ) N
    ON(M.CPID = N.CPID AND M.BBQ = N.BBQ AND M.ZQDM = N.ZQDM and m.ZQMC=n.ZQMC and m.BGQMSFCYZGQ = n.BGQMSFCYZGQ)
    WHEN MATCHED THEN UPDATE
      SET M.SEQNO = N.SEQNO, 
          M.CYZS = N.CYZS, 
          M.ZQSZ = N.ZQSZ, 
          M.ZZCJZBL = N.ZZCJZBL
    WHEN NOT MATCHED THEN 
      INSERT(ID, 
              CPID, 
              BBQ, 
              SEQNO, 
              ZQDM, 
              ZQMC, 
              CYZS, 
              ZQSZ, 
              ZZCJZBL, 
              BGQMSFCYZGQ, 
              LRR, 
              LRSJ )
       VALUES(SEQ_TPIF_CPDM_GL_JJZQZH.NEXTVAL, 
              N.CPID, 
              N.BBQ, 
              N.SEQNO, 
              N.ZQDM, 
              N.ZQMC, 
              N.CYZS, 
              N.ZQSZ, 
              N.ZZCJZBL, 
              N.BGQMSFCYZGQ, 
              0, 
              SYSDATE
       
          );

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  
  
  PROCEDURE PRO_TPIF_GMJJJL(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER)
   AS 

  BEGIN
    --SEQ_TPIF_GMJJJL
    MERGE INTO TPIF_GMJJJL  M
    USING( SELECT  C.CPID,
                   A.PERSONALCODE   AS JJJLBH,
                   A.NAME           AS XM,
                   B.GENDER         AS XB,
                   B.EDUCATION      AS XL,
                   B.BACKGROUND     AS JJ,
                   B.PERSONALDATA   AS TX,
                   TO_CHAR(A.ACCESSIONDATE,'YYYYMMDD') AS RZKSRQ,
                   TO_CHAR(A.DIMISSIONDATE,'YYYYMMDD') AS RZJSRQ,
                   A.PERFORMANCE AS RQSYHBL,
                   B.ExperienceTime AS CYJN,
                   DECODE(A.INCUMBENT,1,1,0,2)  AS RZZT   --1:在职  2：离职
              FROM (select  innercode, 
                            infopubldate, 
                            infosource, 
                            personalcode, 
                            name, 
                            postname, 
                            incumbent, 
                            accessiondate, 
                            dimissiondate, 
                            managementtime, 
                            performance,
                            row_number() over (partition by innercode,personalcode order by jsid desc) px
                      from src_pif.MF_FundManagerNew ) A, 
                   SRC_PIF.MF_PERSONALINFO B,
                   PIF.TPIF_CPDM C
             WHERE A.PERSONALCODE = B.PERSONALCODE 
               AND A.INNERCODE = C.JYNM 
               and a.px =1 ) N
    ON(M.CPID = N.CPID AND M.JJJLBH = N.JJJLBH)
    WHEN MATCHED THEN UPDATE
      SET M.JJ = N.JJ, 
          M.XL = N.XL, 
          M.RZJSRQ = N.RZJSRQ, 
          M.RQSYHBL = N.RQSYHBL,
          M.RZZT = N.RZZT,
          M.CYJN = N.CYJN
    WHEN NOT MATCHED THEN 
      INSERT( ID, 
              CPID, 
              JJJLBH, 
              XM, 
              XB, 
              XL, 
              JJ, 
              TX, 
              RZKSRQ, 
              RZJSRQ, 
              RQSYHBL, 
              RZZT, 
              LRR, 
              LRSJ,
              CYJN
               )
       VALUES(SEQ_TPIF_GMJJJL.NEXTVAL, 
              N.CPID, 
             N.JJJLBH, 
              N.XM, 
              N.XB, 
              N.XL, 
              N.JJ, 
              N.TX, 
              N.RZKSRQ, 
              N.RZJSRQ, 
              N.RQSYHBL, 
              N.RZZT, 
              0, 
              SYSDATE,
              N.CYJN
          );

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
                            
                            
                              
  
  --产品净值衍生指标 TPIF_CPJZ_YSZB              
  PROCEDURE PRO_TPIF_ZB_CP_SYZB( O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER)
  AS
  BEGIN
     --SEQ_TPIF_ZB_CP_SYZB
     --公募基金,区间回报
     MERGE INTO TPIF_ZB_CP_SYZB M
     USING(SELECT B.CPID,
                  TO_CHAR(A.TradingDay,'YYYYMMDD') AS RQ, --交易日 
                  A.UNITNV AS DWJZ, --单位净值
                  A.RRInSingleMonth,-- 一个月回报率（%）
                  A.RRInThreeMonth, -- 三个月回报率（%）
                  A.RRInSixMonth,   --六个月回报率（%）
                  A.RRInSingleYear,--一年回报率（%）
                  A.RRInThreeYear,--三年回报率（%）
                  A.RRSinceThisYear,--今年以来回报率（%）
                  A.RRSinceStart --设立以来回报率（%）  
            FROM  SRC_PIF.MF_NETVALUEPERFORMANCE A,
                  PIF.TPIF_CPDM B
            WHERE A.INNERCODE = B.JYNM ) N
     ON(M.CPID = N.CPID)
     WHEN MATCHED THEN UPDATE 
       SET M.RQ = N.RQ,
           M.QJSYL_1Y = N.RRInSingleMonth,
           M.QJSYL_3Y = N.RRInThreeMonth,
           M.QJSYL_6Y = N.RRInSixMonth,
           M.QJSYL_1N = N.RRInSingleYear,
           M.QJSYL_3N = N.RRInThreeYear,
           M.QJSYL_CLYL = N.RRSinceStart,
           M.QJSYL_JNYL = N.RRSinceThisYear
     WHEN NOT MATCHED THEN 
       INSERT ( ID,
                RQ,
                CPID,
                DWJZ,
                QJSYL_1Y,
                QJSYL_3Y,
                QJSYL_6Y,
                QJSYL_1N,
                QJSYL_3N ,
                QJSYL_CLYL,
                QJSYL_JNYL 
               ) 
        VALUES(SEQ_TPIF_ZB_CP_SYZB.NEXTVAL,
               N.RQ,
               N.CPID,
               N.DWJZ, --单位净值
               N.RRINSINGLEMONTH,-- 一个月回报率（%）
               N.RRINTHREEMONTH, -- 三个月回报率（%）
               N.RRINSIXMONTH,   --六个月回报率（%）
               N.RRINSINGLEYEAR,--一年回报率（%）
               N.RRINTHREEYEAR,--三年回报率（%）
               N.RRSINCETHISYEAR,--今年以来回报率（%）
               N.RRSINCESTART --设立以来回报率（%） 
        );


    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
                                    

END;

/

