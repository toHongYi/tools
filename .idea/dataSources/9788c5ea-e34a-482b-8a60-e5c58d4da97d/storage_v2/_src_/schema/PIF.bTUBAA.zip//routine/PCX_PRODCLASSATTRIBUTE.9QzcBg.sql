create PROCEDURE PCX_PRODCLASSATTRIBUTE(O_CODE      OUT NUMBER,
                                                   O_NOTE      OUT VARCHAR2,
                                                   O_RESULT    OUT SYS_REFCURSOR,
                                                   I_USER      IN INTEGER, --操作人
                                                   I_IP        IN VARCHAR2, --访问IP
                                                   I_PROD_ID   IN NUMBER, --产品ID
                                                   I_PROD_CODE IN VARCHAR2 --产品代码
                                                   ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品分类属性查询
      语法信息：
           输入参数：   I_PROD_ID    IN   NUMBER,   --产品ID
                        I_PROD_CODE  IN  VARCHAR2   --产品代码
           输出参数：   O_RESULT
                       O_CODE
                          1000:成功；
                          1001:入参异常；
                          1002:接口未开启；
                          1003:IP未配置白名单
                          1004:查询总记录数据为0
                          1005:其他程序错误
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000001');
  V_COUNT NUMBER;
  V_JKLX  NUMBER;
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
    --RETURN;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
    --RETURN;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
    --RETURN;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;


  OPEN O_RESULT FOR
    SELECT A.PROD_CODE AS PROD_CODE, --产品代码
           A.PROD_FULLNAME AS PROD_NAME, --产品名称
           A.PROD_TYPE AS CLASS_CODE, --分类编码
           (SELECT NAME FROM PIF.TFIN_PROD_CLASS WHERE ID = A.PROD_TYPE) AS CLASS_NAME --分类名称
      FROM PIF.TPROD_BASIC_INFO A
     WHERE A.ID = NVL(I_PROD_ID, A.ID)
       AND A.PROD_CODE = NVL(I_PROD_CODE, A.PROD_CODE);


  O_CODE := 0;
  O_NOTE := '查询成功';

 <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
      SELECT A.PROD_CODE AS PROD_CODE, --产品代码
             A.PROD_FULLNAME AS PROD_NAME, --产品名称
             A.PROD_TYPE AS CLASS_CODE, --分类编码
             (SELECT NAME FROM PIF.TFIN_PROD_CLASS WHERE ID = A.PROD_TYPE) AS CLASS_NAME --分类名称
        FROM PIF.TPROD_BASIC_INFO A
       WHERE 1 = 2;
  END IF ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

