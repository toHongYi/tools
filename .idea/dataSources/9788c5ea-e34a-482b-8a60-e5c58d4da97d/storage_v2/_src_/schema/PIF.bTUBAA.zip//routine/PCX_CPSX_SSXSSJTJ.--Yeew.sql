create procedure pcx_cpsx_ssxssjtj(cur_result out types.cursortype,
                                              i_tjlx     in number,
                                              i_cpdm     in varchar2) is
  --zjj 新增  2017年7月19日
  /*  项目：中信建投产品中心
      功能作用：实时统计产品销售数据
      创建：
      作者               版本               时间
      陈勇军            1.0.1             20170613
      统计类型： 1|分公司;2|营业部;3|产品;
      组织机构层级标识   GRADE|  1|分公司；2|营业部   FDNCODE| 分公司管辖营业部

      修改：
      修改人             版本                    时间
      zjj                1.0.2                20170719
      增加 I_CPDM 产品代码 及WHERE条件的代码更新
      houjinbo           1.0.3                20170727
      cpmc 不再作为group by 的条件，因为有同一cpdm多个产品名称的情况，直接取max,增加 cpdm 的展示
      侯金铂    1.0.4   20170824    增加 持营/首发 的展示
      侯金铂    1.0.5   20170831    增加 营业部代码 和 分公司代码
      侯金铂    1.0.6   20171026    增加 不获取 资管，建投基金的数据的限制
      涂孟      1.0.7   20180611    修改 与 pif.tpif_jkdmwh 关联条件改变
      侯金铂    1.0.8   20180823    修改 改成从视图 crmii.vpif_jtzzjg_fj 获取机构相关信息
      涂孟      1.0.9   20190228    修改 关联监控产品代码表时，今天应该处于监控范围内
  */
  v_sql  varchar2(2000);
  v_jlsj varchar2(20) := to_char(sysdate, 'yyyymmdd hh24:mi:ss');
  v_rq   number(8) := to_number(to_char(sysdate,'yyyymmdd'));
begin
  --分公司统计    实时购买量      实时购买人数     限制额度
  if i_tjlx = 1 then

    v_sql := '
      SELECT   ''' ||v_jlsj ||  ''' as 时间,
            fgsdm 分公司代码,
            fgsmc 分公司,
            CPMC 产品代码,
             max(A.CPDM) 产品名称,
             max(cysf)  as "持营/首发" ,
             SUM(A.xsl) 购买量,
             sum(gmrs) 购买人数
        FROM T_RJWTXSTJ A
        where trim(A.CPmc) = ''' || i_cpdm ||
             ''' OR ''' || i_cpdm ||
             ''' IS NULL
        group by fgsdm,fgsmc,CPmc order by fgsdm';
        dbms_output.put_line(v_sql);

    open cur_result for v_sql;

  end if;

  if i_tjlx = 2 then
    v_sql := '
      SELECT  ''' ||v_jlsj ||  ''' as 时间,
            fgsdm 分公司代码,
            fgsmc 分公司,
            yybdm 营业部代码,
            yybmc 营业部名称,
            CPmc 产品代码,
             max(A.CPdm) 产品名称,
             max(cysf)  as "持营/首发" ,
             SUM(A.xsl) 购买量,
             sum(gmrs) 购买人数
        FROM T_RJWTXSTJ A
        where trim(A.CPmc) = ''' || i_cpdm ||
             ''' OR ''' || i_cpdm ||
             ''' IS NULL
        group by fgsdm,fgsmc,yybdm,yybmc,cpmc order by fgsdm';

    open cur_result for v_sql;
  end if;

  if i_tjlx = 3 then
    v_sql := '
      SELECT  ''' ||v_jlsj ||  ''' as 时间,
            CPmc 产品代码,
             max(A.CPdm) 产品名称,
             max(cysf)  as "持营/首发" ,
             SUM(A.xsl) 购买量,
             sum(gmrs) 购买人数
        FROM T_RJWTXSTJ A
        where trim(A.CPmc) = ''' || i_cpdm ||
             ''' OR ''' || i_cpdm ||
             ''' IS NULL
        group by cpmc order by cpmc';
        dbms_output.put_line(v_sql);

    open cur_result for v_sql;
  end if;

exception
  when others then
    v_sql := 'SELECT ' || sqlerrm || ' FROM DUAL';
    open cur_result for v_sql;
    /*  O_CODE := -1;
    O_NOTE := SQLERRM;*/
end pcx_cpsx_ssxssjtj;
/

