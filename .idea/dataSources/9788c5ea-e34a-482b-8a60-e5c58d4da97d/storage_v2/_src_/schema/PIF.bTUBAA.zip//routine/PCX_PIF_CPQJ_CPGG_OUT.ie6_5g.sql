create procedure pcx_pif_cpqj_cpgg_out(o_code     out number,
                                              o_note     out varchar2,
                                              o_result   out sys_refcursor,
                                              i_current  in number, --页码
                                              i_pagesize in number, --页长
                                              i_paging   in number, --是否分页
                                              i_sort     in string, --排序规模
                                              i_total    in out number, --记录总数
                                              i_userid   in integer, --用户ID
                                              i_ip       in varchar2,--IP
                                              i_prod_id  in number --产品ID
                                              ) as
  /******************************************************************
  项目名称：产品中心-产品全景-查询产品公告
  所属用户：PIF
  概要说明：查询产品公告.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品公告.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql          varchar2(32767);
  v_collist      varchar2(32767);
  v_sort         varchar2(300);
  v_hasrecordset number;
begin

  --否则返回结果集合
  v_hasrecordset := 1;
  o_code         := 0;
  o_note         := '成功';
  if i_total is null then
    i_total := -1;
  end if;
 /* if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;*/
  v_sort := i_sort;

  --条件检验

  if i_prod_id is null then
    o_code := -1;
    o_note := '产品ID不允许为空！';
    return;
  end if;
    if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;

  v_sql := ' SELECT T.NOTICE_TITLE,
                    T.NOTICE_CONTENT,
                    T.NOTICE_VISIT_LINK,
                    T.NOTICE_DATE
             FROM TPROD_NOTICE T
             WHERE T.PROD_ID = ' || i_prod_id;

  if v_sort is null then
    v_sort := 'NOTICE_DATE DESC';
  end if;

  v_collist := 'NOTICE_TITLE,NOTICE_CONTENT,NOTICE_VISIT_LINK,NOTICE_DATE';

  pif.pcx_tycx_OUT(o_code,
           o_note,
           v_hasrecordset,
           o_result,
           i_paging,
           i_current,
           i_pagesize,
           i_total,
           sqls           => v_sql,
           collist        => v_collist,
           haswhere       => true,
           groupislast    => false,
           i_sort         => v_sort,
           i_haswith      => false);

exception
  when others then
    o_code := -1;
    o_note := '失败:' || sqlerrm;

end pcx_pif_cpqj_cpgg_out;
/

