create PROCEDURE PRO_PIF_JYRL_GZJL(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2, --返回消息
                                              I_USER IN INTEGER, --操作人
                                              I_IP   IN VARCHAR2, --操作IP
                                              I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|审核;4|反审核；
                                              I_ID   IN INTEGER --操作ID
                                              ) IS
  /*
  **功能说明：银河产品中心
  **创建人：潘建峰
  **创建日期：2016-06-17
  **************************************************************************
  修订日期       版本号    修订人             修改内容简要说明
  20161020       2.0.0     王大一             中信证券平台管理迁移并修改
  20161028       2.0.1     王大一             审核通过后生成交易日历，反审核后删除交易日历
  **************************************************************************
  */
  V_COUNT INTEGER; --计数变量

  V_OBJ TPIF_JYRL_GZJL%ROWTYPE; --表单记录
  --V_OBJ_YZXX  TPIF_CPYZXX%ROWTYPE;
  V_SHZT NUMBER(4); --审核状态
  V_SHYJ VARCHAR2(300); --审核意见
  V_CZKM VARCHAR2(200) := '32002'; --操作科目
  V_CZSM VARCHAR2(2000); --日志操作明细
  V_CZFF VARCHAR2(200); --操作方法
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_JYRL_GZJL WHERE ID = I_ID;
    /*    IF(V_OBJ.QJJS<SUBSTR(SYSDATE,1,9))THEN
    O_CODE := -1;
    O_NOTE := '区间结束应大于今天！';
    RETURN;
    ROLLBACK;
    ELSIF(V_OBJ.QJQS>V_OBJ.QJJS)THEN
     O_CODE := -1;
    O_NOTE := '区间结束应大于等于区间起始！';
     RETURN;
    ROLLBACK;
    END IF;*/

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --审核后备份到规则记录备份表的对应的审核状态和审核意见字段
  IF (I_OPER = 3) THEN
    select shzt, shyj
      into V_SHZT, V_SHYJ
      from TPIF_JYRL_GZJL
     where id = I_ID;
    update TPIF_JYRL_GZJLBF
       set SHZT = V_SHZT,
           shyj = V_SHYJ,
           czjl = czjl || to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') ||
                  '[用户ID:' || I_USER || ']==>审核' || CHR(10)
     where id = I_ID;
    --insert into t_wdy_test (b) values (i_id || '--' || v_shzt);
    commit;
    --生成交易日历
    if v_shzt = 2 then
      --审核通过
      PRO_PIF_JYRL_SCJYRL(O_CODE, O_NOTE, I_ID);
    end if;
  END IF;
  --反审核后备份到规则记录备份表的对应的审核状态和审核意见字段
  IF (I_OPER = 4) THEN
    select shzt, shyj
      into V_SHZT, V_SHYJ
      from TPIF_JYRL_GZJL
     where id = I_ID;
    update TPIF_JYRL_GZJLBF
       set SHZT = V_SHZT,
           shyj = V_SHYJ,
           czjl = czjl || to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS') ||
                  '[用户ID:' || I_USER || ']==>反审核' || CHR(10)
     where id = I_ID;
    --删除交易日历
    delete from tpif_jyrl t where t.gzjl = to_char(I_ID);
    --删除交易日历中规则记录包含I_GZJL的数据
    UPDATE TPIF_JYRL
       SET GZJL = rtrim(ltrim(REPLACE(';' || GZJL || ';',
                                      ';' || I_ID || ';',
                                      ';'),
                              ';'),
                        ';')
     where INSTR(';' || GZJL || ';', ';' || I_ID || ';') > 0;
  END IF;
  --删除在这里处理
  IF (I_OPER = 2) THEN
    DELETE FROM TPIF_JYRL_GZJL WHERE ID = I_ID;
  END IF;

  /*IF I_IP != '[check]' THEN*/

  SELECT DECODE(I_OPER, 0, 'XZ', 1, 'XG', 2, 'SC', 3, 'SH', 4, 'FSH', '0')
    INTO V_CZFF
    FROM DUAL;
  SELECT '[' || DECODE(I_OPER,
                       0,
                       '新增',
                       1,
                       '修改',
                       2,
                       '删除',
                       3,
                       '审核',
                       4,
                       '反审核',
                       '') || ']_' || 'ID=' || V_OBJ.ID
    INTO V_CZSM
    FROM DUAL;
  /* END IF;*/
  --check

  O_NOTE := '记录日志';
  --PRO_JG_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, I_ID, V_CZSM);
  LIVEBOS.PRO_CZRZDJ(O_CODE,
                   O_NOTE,
                   I_USER,
                   'TPIF_JYRL_GZJL',
                   V_CZFF,
                   I_ID,
                   V_CZSM,
                   I_IP,
                   V_CZKM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;
  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '审核',
                         4,
                         '反审核',
                         '') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_GZJL;
/

