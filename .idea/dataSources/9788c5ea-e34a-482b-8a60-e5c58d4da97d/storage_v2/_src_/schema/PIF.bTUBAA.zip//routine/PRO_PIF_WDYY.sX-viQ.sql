create PROCEDURE Pro_PIF_WDYY(O_CODE     OUT NUMBER, --返回值
                                         O_NOTE     OUT VARCHAR2, --返回消息
                                         i_menu_ids IN varchar2, --菜单ID串 逗号分隔
                                         i_userid   IN INTEGER   --用户ID
                                         ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：维护首页我的应用
      语法信息：
           输入参数：   i_userid     IN INTEGER --用户ID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
                        O_RESULT OUT TYPES.CURSORTYPE, --返回结果集
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    陈勇军                创建
  ***********************************************************************/
  V_COUNT number;

BEGIN
  
  IF i_menu_ids IS NULL THEN
    O_CODE := -1;
    O_NOTE := '菜单ID串不能为空!';
    RETURN;
  END IF;

  IF i_userid IS NULL THEN
    O_CODE := -1;
    O_NOTE := '用户ID不能为空!';
    RETURN;
  END IF;

  for cur_cd in (select column_value as cdid
                   from table(split(i_menu_ids, ','))) loop
    select count(*)
      into V_COUNT
      from TPIF_YHKJCZCD
     where userid = i_userid
       and KJCZCD = cur_cd.cdid;
  
    if V_COUNT = 0 then
      INSERT INTO TPIF_YHKJCZCD
        (ID, KJCZCD, USERID)
      values
        (livebos.FUNC_NEXTID('TPIF_YHKJCZCD'), cur_cd.cdid, i_userid);
    end if;
  
  end loop;
  commit;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
    rollback;
END;
/

