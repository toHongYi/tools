create FUNCTION FUNC_GET_WDBBH(I_CZLX IN NUMBER, --1发布新版本|；2修改
                                              I_WDMC IN VARCHAR2, --文档名称
                                              I_BBH  IN VARCHAR2 --前有效文档的版本号
                                              ) RETURN VARCHAR2 IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取新的文档版本号
        语法信息：
             输入参数：    I_CZLX IN NUMBER, --1发布新版本|；2修改
                           I_WDMC IN VARCHAR2, --文档名称
                           BBH 当前有效文档的版本号
             输出参数：   当前版本号的下一个版本号
        逻辑说明：根据当前文件版本号获取下一个版本号，版本号由文件名_v版本ID_当前时间构成
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-15     1.0.2    徐阳                创建
    ***********************************************************************/
    V_NEXT_BBH VARCHAR2(1000);
    V_BBID     VARCHAR2(100);
    V_WDMC     VARCHAR2(300);
BEGIN
    V_BBID := SUBSTR(I_BBH,
                     INSTR(I_BBH, '_', -1, 2) + 2,
                     INSTR(I_BBH, '_', -1, 1) - INSTR(I_BBH, '_', -1, 2) - 2); --获取版本ID

    IF I_CZLX = 1 THEN
        --发布新版本
        IF INSTR(V_BBID, '.') > 0 THEN
            V_BBID := TO_CHAR(TO_NUMBER(SUBSTR(V_BBID, 1, INSTR(V_BBID, '.') - 1)) + 1);
            V_BBID := V_BBID || '.0';
        ELSE
            V_BBID := TO_CHAR(TO_NUMBER(V_BBID) + 1);
        END IF;
    
    ELSE
        --更新版本
        V_BBID := SUBSTR(V_BBID, 1, INSTR(V_BBID, '.')) ||
                  TO_CHAR(TO_NUMBER(SUBSTR(V_BBID, INSTR(V_BBID, '.') + 1)) + 1);
    END IF;

    V_WDMC     := SUBSTR(I_WDMC, 1, INSTR(I_WDMC, '.', -1, 1) - 1); --获取文件名称
    V_NEXT_BBH := V_WDMC || '_V' || V_BBID || '_' || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
    RETURN(V_NEXT_BBH);
END FUNC_GET_WDBBH;


/

