create PROCEDURE PCX_PIF_CPJM_ZSLBJX(O_CODE OUT NUMBER,
                                                O_NOTE OUT VARCHAR2,
                                                --O_HASRECORDSET OUT NUMBER,
                                                O_RESULT          OUT SYS_REFCURSOR,
                                                I_CURRENT         IN NUMBER, --页码
                                                I_PAGESIZE        IN NUMBER, --页长
                                                I_PAGING          IN NUMBER, --是否分页
                                                I_SORT            IN STRING, --排序规模
                                                I_TOTAL           IN OUT NUMBER, --记录总数
                                                I_PROD_TYPE       IN VARCHAR2, --产品分类ID
                                                I_TEMPLATE_ID     IN NUMBER, --模版ID
                                                I_QUERY_CONDITION IN VARCHAR2,
                                                I_USERID          IN NUMBER,
                                                I_CPDM            IN VARCHAR2) AS
  /******************************************************************
  项目名称：产品中心-产品视图-展示列表解析
  所属用户：PIF
  概要说明：查询当前登录人产品展示列表解析.
               I_PAGING      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算I_TOTALROWS.
                               并不是什么是否都需要分页,看情形而言.
               I_CURRENT      --页码
               I_PAGESIZE  --页长
               I_TOTAL   --总行数 -1,未知,表示需要计算总长.是IN,OUT参数.如果I_TOTALROWS>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               I_SORT        --排序字段
               I_PROD_TYPE       IN NUMBER, --产品分类ID
               I_TEMPLATE_ID         IN NUMBER  --模版ID
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_HASRECORDSET  IN,OUT参数.整型,返回1,表示有返回O_RESULT,否则没有O_RESULT(为空值)
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
      PIF.TPIF_JRCPFL 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询展示列表的解析.
  
        1.查询展示列表的解析,供前端查询展示.
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/10/29     1.0.1   GUONANHUA           新增.
      2015/06/04     1.0.2   刘浪浪              修改排序BUG，并支持多个字段排序
      2015/08/17     1.0.3   刘浪浪              增加DISTINCT过滤掉查询从表中有多条记录重复的情况
      2020/07/14     1.0.4   涂孟                对于产品列表前固定列特殊处理
      2020/07/23     1.0.5   涂孟                增加色块多选的支持（暂时只支持选择项）、增加关键字搜索入参
     
  *********************************************************************************************************************/
  V_SQL        VARCHAR2(32767);
  V_SQL_WHERE  VARCHAR2(32767);
  V_SQL_WHERE1 VARCHAR2(32767);
  V_COLLIST    VARCHAR2(32767);
  V_SORT       VARCHAR2(2000);
  V_ERRMSG     VARCHAR2(300); --错误信息
  V_COL        VARCHAR2(32767); --返回列表
  V_TYPE       NUMBER(12);
  V_ID         NUMBER(16);
  V_XSMC       VARCHAR2(300); --显示名称
  V_XSSX       NUMBER(12); --显示顺序
  V_SXLX       NUMBER(12); --属性类型
  V_CPSX       VARCHAR2(241); --产品属性
  V_TJQJZB     NUMBER(16); --条件 区间指标
  V_XSMS       NUMBER(12); --显示模式
  V_REFCODE    VARCHAR2(2000); --关联对象名称/字典的FLDM
  V_ALLCXTJ    VARCHAR2(5000); --查询条件
  V_CXZD       VARCHAR2(5000); --查询字段
  V_ZB         VARCHAR2(500); --条件项 例如：1=0-5%(含)
  V_ZBM        VARCHAR2(500); --ID值 (内部对象ID,字典IBM,区间ID) 例如：1
  V_ZBQZ       VARCHAR2(500); --描述 例如0-5%(含)
  V_CPSX1      VARCHAR2(241); --产品属性
  V_TABLENAME  VARCHAR2(2000);
  V_C1         VARCHAR2(500); --多值选择项值
  V_C1_1       VARCHAR2(500); --多值选择项值
  V_XX         NUMBER(20, 5); --下限
  V_SX         NUMBER(20, 5); --上限
  V_ZDSX       VARCHAR2(241); --字段属性
  V_PXTJ       VARCHAR2(241); --排序条件

  V_KEYWORD VARCHAR2(500); --输入框关键词，产品名称或者产品代码模糊查询

  TYPE TYPE_CUR IS REF CURSOR;
  CURSOR_D       TYPE_CUR;
  V_FROMTABLE    VARCHAR2(500); --数据源表
  V_SQL_HFXJY    VARCHAR2(5000); --合法性验证
  V1_TYMB        NUMBER(16);
  V1_ID          NUMBER(16);
  V1_XSMC        VARCHAR2(500);
  V1_XSSX        NUMBER(16);
  V1_YWDX        VARCHAR2(500);
  V1_CPSX        VARCHAR2(500);
  V1_SFPXTJ      NUMBER(16);
  V1_PXTJ        VARCHAR2(500);
  V1_LJDZ        VARCHAR2(500);
  V1_DKFS        NUMBER(16);
  V1_MS          VARCHAR2(500);
  V1_SSTJ        VARCHAR2(1000);
  V1_IDBZ        VARCHAR2(1000);
  V_KSRQ         NUMBER(8) := 0;
  V_JSRQ         NUMBER(8) := 0;
  V_LENGTH       NUMBER;
  V_QUERYCOL     VARCHAR2(32767); --查询字段
  V_SQL_COL      VARCHAR2(32767); --分页函数的查询字段
  V_HASRECORDSET NUMBER;
  V_GSHJB        VARCHAR2(1000);
  V_COUNT        NUMBER;
  V_PROD_TYPE    VARCHAR2(500);
  V_JRCPFL       VARCHAR2(500);

  --TEMP
  V_COUNT1 NUMBER(16);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';
  V_SORT := I_SORT;

  V_KEYWORD := TRIM(I_CPDM); --20211020HQN

  IF I_PROD_TYPE IS NULL THEN
    --V_PROD_TYPE := NULL ;
    V_JRCPFL := NULL;
  
  ELSE
  
    V_JRCPFL := I_PROD_TYPE;
  
  END IF;
  V_PROD_TYPE := I_TEMPLATE_ID;

  IF I_TEMPLATE_ID IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入必填参数【模版ID】';
    RETURN;
  END IF;
  IF I_USERID IS NULL THEN
    O_CODE := -1802;
    O_NOTE := '请输入必填参数【用户ID】';
    RETURN;
  END IF;

  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  --数据源赋值
  IF V_PROD_TYPE IS NULL THEN
    V_FROMTABLE := ' TPIF_TYMBLBPZ T WHERE T.ZT = 1 AND T.TYMB = ' ||
                   I_TEMPLATE_ID;
  
  ELSE
    V_FROMTABLE := ' TPIF_FLMBLBPZ T, PIF.TPIF_FLMBDY MB WHERE T.FLMB = MB.ID AND T.ZT = 1 AND MB.MBZT = 1 AND T.FLMB = ' ||
                   I_TEMPLATE_ID;
    --|| '  AND EXISTS( SELECT 1 FROM TABLE(SPLIT(''' || V_PROD_TYPE || ''','';''))  WHERE INSTR('';''||MB.CPDL||'';'','';''||COLUMN_VALUE||'';'')>0 ) ';
  END IF;
  --验证是否存在适用于当前登录人的通用模版
  V_SQL_HFXJY := ' SELECT COUNT(1) FROM ' || V_FROMTABLE;
  EXECUTE IMMEDIATE V_SQL_HFXJY
    INTO V_COUNT;
  IF V_COUNT = 0 THEN
    O_CODE := -2;
    O_NOTE := '错误：没有此列表模版！';
    RETURN;
  END IF;
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA_BIG';
  -- 根据配置得到通用模版查询字段
  --数据源赋值
  IF V_PROD_TYPE IS NULL THEN
    V_QUERYCOL := 'SELECT T.TYMB, T.ID, T.XSMC, T.XSSX, T.YWDX, T.CPSX, T.SFPXTJ,T.PXTJ, T.LJDZ, T.DKFS, T.MS,T.IDBZ,T.GSHJB FROM ' ||
                  V_FROMTABLE;
  ELSE
    V_QUERYCOL := 'SELECT T.FLMB, T.ID, T.XSMC, T.XSSX, T.YWDX, T.CPSX, T.SFPXTJ,T.PXTJ, T.LJDZ, T.DKFS, T.MS,T.IDBZ,T.GSHJB FROM ' ||
                  V_FROMTABLE;
  END IF;
  V_QUERYCOL := V_QUERYCOL || ' ORDER BY T.PXYXJ ';
  OPEN CURSOR_D FOR V_QUERYCOL;
  LOOP
    EXIT WHEN CURSOR_D%NOTFOUND;
    FETCH CURSOR_D
      INTO V1_TYMB,
           V1_ID,
           V1_XSMC,
           V1_XSSX,
           V1_YWDX,
           V1_CPSX,
           V1_SFPXTJ,
           V1_PXTJ,
           V1_LJDZ,
           V1_DKFS,
           V1_MS,
           V1_IDBZ,
           V_GSHJB;
    IF CURSOR_D%FOUND THEN
      SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME, T1.LENGTH
        INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME, V_LENGTH
        FROM PIF.TPIF_FIELD T1
       WHERE T1.TABLENAME = V1_YWDX
         AND T1.ID = V1_CPSX;
    
      --显示格式化,如果有配置则已配置为准
      IF V_GSHJB IS NOT NULL THEN
      
        V_ZDSX := REPLACE(V_GSHJB, '?', V1_CPSX);
      
      ELSE
        --时间类型，进行格式化
        IF V_TYPE = 13 THEN
          V_ZDSX := ' TO_CHAR(TO_DATE(case ' || V1_CPSX ||
                    ' when 0 then null else ' || V1_CPSX ||
                    ' end,''YYYYMMDD''),''YYYY-MM-DD'') ';
        ELSIF V_TYPE = 3 THEN
          V_ZDSX := ' TO_CHAR(' || V1_CPSX || ',''YYYY-MM-DD'') ';
          --内部对象
        ELSIF V_TYPE = 6 THEN
          V_ZDSX := '(SELECT ' || V1_MS || ' FROM PIF.' || V_REFCODE ||
                    '  WHERE ' || V1_IDBZ || ' = ' || V1_CPSX || ')';
        ELSIF V_TYPE = 16 THEN
          V_ZDSX := '(SELECT WM_CONCAT(' || V1_MS || ') FROM PIF.' ||
                    V_REFCODE || '  WHERE INSTR('';''||' || V1_CPSX ||
                    '||'';'','';''||' || V1_IDBZ || '||'';'') >0 )';
          --字典型
        ELSIF V_TYPE = 7 THEN
          V_ZDSX := '(SELECT  NOTE  FROM livebos.TXTDM T WHERE T.FLDM = ''' ||
                    V_REFCODE || ''' AND T.IBM = ' || V1_CPSX || ')';
        ELSIF V_TYPE = 15 THEN
          V_ZDSX := '(SELECT  TO_CHAR(WM_CONCAT(NOTE))  FROM livebos.TXTDM T WHERE T.FLDM = ''' ||
                    V_REFCODE || ''' AND INSTR('';''||' || V1_CPSX ||
                    '||'';'','';''||T.IBM||'';'') >0 )';
        ELSE
          IF INSTR(V_LENGTH, '.') > 0 THEN
            V_ZDSX := ' TO_CHAR(' || V1_CPSX ||
                      ',''FM999,999,999,999,990.009999'') ';
          ELSE
            V_ZDSX := V1_CPSX;
          END IF;
          --20210912HQN 基金规模特殊化：除以100000000
          IF V1_CPSX = 'TPIF_CPDM.CPZXGM' THEN
            V_ZDSX := ' TO_CHAR(' || V1_CPSX || '/100000000' ||
                      ',''FM999,999,999,999,990.00'') ';
          END IF;
        END IF;
      
      END IF;
    
      INSERT INTO TEMPDATA_BIG
        (N1, N2, C1, C2)
        SELECT V1_XSSX,
               V1_TYMB,
               V_ZDSX,
               SUBSTR(V1_CPSX, INSTR(V1_CPSX, '.') + 1)
          FROM DUAL;
    
      --处理排序字段;支持多个字段同时排序
      IF V1_SFPXTJ = 1 THEN
        V_SQL := 'SELECT DECODE ( ' || V1_PXTJ ||
                 ' ,1, ''ASC'',2,''DESC '') FROM DUAL';
        EXECUTE IMMEDIATE V_SQL
          INTO V_PXTJ;
      
        IF V_SORT IS NULL THEN
          V_SORT := '"' || V1_XSMC || '" ' || V_PXTJ;
        ELSE
          V_SORT := V_SORT || ',"' || V1_XSMC || '" ' || V_PXTJ;
        END IF;
      
      END IF;
      --V_SORT := I_SORT;
    END IF;
  END LOOP;

  CLOSE CURSOR_D;

  IF V_SORT IS NULL THEN
    V_SORT := '1 DESC';
  END IF;

  --1 返回最终的结果列表
  SELECT WM_CONCAT(A.CXLB)
    INTO V_CXZD
    FROM (SELECT XSSX, T.CPSX || ' ' || T.XSMC CXLB
            FROM (SELECT N1 XSSX, C1 CPSX, C2 XSMC
                    FROM TEMPDATA_BIG T
                   WHERE T.N2 = I_TEMPLATE_ID
                     AND T.N1 NOT IN
                         (SELECT T.N1
                            FROM TEMPDATA_BIG T
                           WHERE T.N2 = I_TEMPLATE_ID
                             AND (T.C2 LIKE '%(%' OR T.C2 LIKE '%)%' OR
                                 T.C2 LIKE '%[%' OR T.C2 LIKE '%]%'))
                  UNION ALL
                  SELECT N1 XSSX, C1 CPSX, '"' || C2 || '"' XSMC
                    FROM TEMPDATA_BIG T
                   WHERE T.N2 = I_TEMPLATE_ID
                     AND (T.C2 LIKE '%(%' OR T.C2 LIKE '%)%' OR
                         T.C2 LIKE '%[%' OR T.C2 LIKE '%]%')) T
           ORDER BY XSSX) A;

  --2. 根据入参解析查询条件

  --2.1去掉[{,}],{,}
  V_ALLCXTJ := REPLACE(REPLACE(I_QUERY_CONDITION, '[{', ''), '}]', '');
  V_ALLCXTJ := REPLACE(REPLACE(V_ALLCXTJ, '{', ''), '}', '');
  DBMS_OUTPUT.PUT_LINE(V_ALLCXTJ);

  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA';

  --2.2 将条件ID 与选项值 解析出来存放进临时表
  WHILE V_ALLCXTJ IS NOT NULL LOOP
    IF INSTR(V_ALLCXTJ, ',', 1, 1) > 0 THEN
      V_ZB      := SUBSTR(V_ALLCXTJ, 1, INSTR(V_ALLCXTJ, ',', 1, 1) - 1);
      V_ALLCXTJ := SUBSTR(V_ALLCXTJ, INSTR(V_ALLCXTJ, ',', 1, 1) + 1);
      V_ZBM     := SUBSTR(V_ZB, 1, INSTR(V_ZB, '=', 1, 1) - 1);
      V_ZBQZ    := SUBSTR(V_ZB, INSTR(V_ZB, '=', 1, 1) + 1);
    ELSE
      V_ZB      := V_ALLCXTJ;
      V_ALLCXTJ := NULL;
      V_ZBM     := SUBSTR(V_ZB, 1, INSTR(V_ZB, '=', 1, 1) - 1);
      V_ZBQZ    := SUBSTR(V_ZB, INSTR(V_ZB, '=', 1, 1) + 1);
    END IF;
  
    BEGIN
      --KEYWORD 不插入临时表  
      IF V_ZBM = 'keyword' THEN
        V_KEYWORD := V_ZBQZ;
      
      ELSE
        INSERT INTO TEMPDATA
          (N1, C1)
          SELECT V_ZBM, -- 1;      --2;      --
                 V_ZBQZ --0-5%(含);--预热期;
            FROM DUAL;
      END IF;
    END;
  END LOOP;

  --3 组装WHERE后面的查询条件

  FOR V1 IN (SELECT * FROM TEMPDATA) LOOP
  
    SELECT COUNT(1)
      INTO V_COUNT1
      FROM PIF.TPIF_FLMBSSPZ T
     WHERE T.FLMB = I_TEMPLATE_ID
       AND T.ZT = 1
       AND T.ID = TRUNC(V1.N1);
  
    IF V_PROD_TYPE IS NULL THEN
      SELECT T.ID,
             T.YWDX,
             T.CPSX,
             T.SXLX,
             T.TJQJZB,
             T.XSMS,
             T.XSMC,
             T.XSSX,
             T.SSTJ
        INTO V_ID,
             V1_YWDX,
             V_CPSX1,
             V_SXLX,
             V_TJQJZB,
             V_XSMS,
             V_XSMC,
             V_XSSX,
             V1_SSTJ
        FROM PIF.TPIF_TYMBSSPZ T
       WHERE T.TYMB = I_TEMPLATE_ID
         AND T.ZT = 1
         AND T.ID = TRUNC(V1.N1);
    ELSIF V_COUNT1 > 0 THEN
      SELECT T.ID,
             T.YWDX,
             T.CPSX,
             T.SXLX,
             T.TJQJZB,
             T.XSMS,
             T.XSMC,
             T.XSSX,
             T.SSTJ
        INTO V_ID,
             V1_YWDX,
             V_CPSX1,
             V_SXLX,
             V_TJQJZB,
             V_XSMS,
             V_XSMC,
             V_XSSX,
             V1_SSTJ
        FROM PIF.TPIF_FLMBSSPZ T
       WHERE T.FLMB = I_TEMPLATE_ID
         AND T.ZT = 1
         AND T.ID = TRUNC(V1.N1);
    ELSE
      CONTINUE;
    END IF;
  
    --产品属性（即字段）
    IF V1.C1 IS NOT NULL THEN
      --色块多选单独处理,只支持单字，单值选择项
      IF V_XSMS = 3 THEN
        SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME
          INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME
          FROM PIF.TPIF_FIELD T1
         WHERE T1.TABLENAME = V1_YWDX
           AND T1.ID = V_CPSX1;
        V_SQL_WHERE := V_SQL_WHERE || ' AND instr('';''|| ''' || V1.C1 ||
                       ''' || '';'', '';''|| ' || V_CPSX1 ||
                       ' || '';'')>0  ';
      ELSE
        IF V_SXLX = 1 THEN
          IF INSTR(V_CPSX1, ';', 1, 1) = 0 THEN
            SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME
              INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME
              FROM PIF.TPIF_FIELD T1
             WHERE T1.TABLENAME = V1_YWDX
               AND T1.ID = V_CPSX1;
            --内部对象 单选
            IF V_TYPE IN (6, 7) THEN
              -- V_SQL_WHERE := V_SQL_WHERE || ' AND ' || V_CPSX1 || '= ' || V1.C1 || '';
              --20210914HQN,金融产品分类特殊处理
              IF V_CPSX1 IN ('TPIF_CPDM.JRCPFL', 'TPIF_CPDM.CPGLRID') THEN
                V_SQL_WHERE := V_SQL_WHERE || 'AND INSTR('';''||' || '''' ||
                               V1.C1 || '''' || '||'';'','';''||' ||
                               V_CPSX1 || '||'';'') >0 ';
              ELSE
                V_SQL_WHERE := V_SQL_WHERE || ' AND ' || V_CPSX1 || '= ' ||
                               V1.C1 || '';
              END IF;
              --内部对象 多选 多值选择项
            ELSIF V_TYPE IN (15, 16) THEN
              V_C1 := V1.C1 || ';';
              WHILE V_C1 IS NOT NULL LOOP
                V_C1_1       := SUBSTR(V_C1, 1, INSTR(V_C1, ';', 1) - 1);
                V_SQL_WHERE1 := V_SQL_WHERE1 || 'OR INSTR('';''||' ||
                                V_CPSX1 || '||'';'','';''||' || V_C1_1 ||
                                '||'';'') >0 ';
                V_C1         := SUBSTR(V_C1, INSTR(V_C1, ';', 1) + 1);
              END LOOP;
              V_SQL_WHERE := V_SQL_WHERE || ' AND (' ||
                             SUBSTR(V_SQL_WHERE1, 3) || ') ';
              --字典型 EG: 风险等级-高,中,低
            ELSIF V_TYPE IN (3, 13) THEN
              V_KSRQ := TO_NUMBER(TO_CHAR(TO_DATE(SUBSTR(V1.C1,
                                                         1,
                                                         INSTR(V1.C1, '-') - 1),
                                                  'YYYY/MM/DD'),
                                          'YYYYMMDD'));
              V_JSRQ := TO_NUMBER(TO_CHAR(TO_DATE(SUBSTR(V1.C1,
                                                         INSTR(V1.C1, '-') + 1),
                                                  'YYYY/MM/DD'),
                                          'YYYYMMDD'));
              IF V_TYPE = 3 THEN
                V_SQL_WHERE := V_SQL_WHERE || ' AND TO_NUMBER(TO_CHAR(' ||
                               V_CPSX1 || ',''YYYYMMDD'')) >= ' || V_KSRQ ||
                               ' AND TO_NUMBER(TO_CHAR(' || V_CPSX1 ||
                               ',''YYYYMMDD'')) <=  ' || V_JSRQ || '';
              ELSIF V_TYPE = 13 THEN
                V_SQL_WHERE := V_SQL_WHERE || ' AND ' || V_CPSX1 || ' >= ' ||
                               V_KSRQ || ' AND ' || V_CPSX1 || ' <= ' ||
                               V_JSRQ || '';
              END IF;
            END IF;
          ELSIF INSTR(V_CPSX1, ';', 1, 1) > 0 THEN
            V_SQL_WHERE := V_SQL_WHERE || ' AND ( 1 = 2 ';
            WHILE V_CPSX1 IS NOT NULL LOOP
              IF INSTR(V_CPSX1, ';', 1, 1) > 0 THEN
                V_ZB    := SUBSTR(V_CPSX1, 1, INSTR(V_CPSX1, ';', 1, 1) - 1);
                V_CPSX1 := SUBSTR(V_CPSX1, INSTR(V_CPSX1, ';', 1, 1) + 1);
                V_ZBM   := SUBSTR(V_ZB, 1, INSTR(V_ZB, '.', 1, 1) - 1);
                V_ZBQZ  := SUBSTR(V_ZB, INSTR(V_ZB, '.', 1, 1) + 1);
              ELSE
                V_ZB    := V_CPSX1;
                V_CPSX1 := NULL;
                V_ZBM   := SUBSTR(V_ZB, 1, INSTR(V_ZB, '=', 1, 1) - 1);
                V_ZBQZ  := SUBSTR(V_ZB, INSTR(V_ZB, '=', 1, 1) + 1);
              
              END IF;
            
              V_SQL_WHERE := V_SQL_WHERE || ' OR  UPPER(' || V_ZB ||
                             ') LIKE UPPER(''%' || V1.C1 || '%'')  ';
            
            END LOOP;
            V_SQL_WHERE := V_SQL_WHERE || ' ) ';
            DBMS_OUTPUT.PUT_LINE(V_SQL_WHERE);
          
          END IF;
        
          --END IF;
        ELSIF V_SXLX = 2 THEN
          --取区间条件
          V_CPSX := SUBSTR(V_CPSX1, INSTR(V_CPSX1, '.', 1, 1) + 1);
          SELECT XX, SX
            INTO V_XX, V_SX
            FROM PIF.TPIF_MBTJZBQJ T
           WHERE T.ID = TRUNC(V1.C1);
          V_SQL_WHERE := V_SQL_WHERE || ' AND ' || V_CPSX || ' BETWEEN ' || V_XX ||
                         ' AND  ' || V_SX;
        ELSIF V_SXLX = 3 THEN
          --取集合
          SELECT V_SQL_WHERE || ' AND ' || SQLWHERE || ' '
            INTO V_SQL_WHERE
            FROM PIF.TPIF_CPJH
           WHERE ID = V1.C1;
        END IF;
      END IF;
    END IF;
  END LOOP;

  --数据源赋值TPIF_CPJZ_YSZB
  IF V_PROD_TYPE IS NULL THEN
    V_FROMTABLE := ' TPIF_TYMBLBPZ T WHERE T.ZT = 1 AND T.TYMB = ' ||
                   I_TEMPLATE_ID;
  ELSE
    V_FROMTABLE := ' TPIF_FLMBLBPZ T, PIF.TPIF_FLMBDY MB WHERE T.FLMB = MB.ID AND T.ZT = 1 AND MB.MBZT = 1 AND T.FLMB = ' ||
                   I_TEMPLATE_ID;
    --|| '  AND EXISTS( SELECT 1 FROM TABLE(SPLIT(''' || V_PROD_TYPE || ''','';''))  WHERE INSTR('';''||MB.CPDL||'';'','';''||COLUMN_VALUE||'';'')>0 ) ';
  END IF;

  --4 根据配置得到显示列表，用于分页查询
  -- IF I_PROD_TYPE IS NULL THEN
  V_SQL_COL := ' SELECT WM_CONCAT(A.CXLB)
     -- INTO V_COL
      FROM (SELECT XSSX, substr(T.CPSX,instr(T.CPSX,''.'')+1) CXLB
              FROM (SELECT T.XSSX, T.CPSX, T.XSMC
                      FROM ' || V_FROMTABLE ||
               ' AND T.XSSX NOT IN (SELECT XSSX
                                            FROM ' ||
               V_FROMTABLE || ' AND ( T.XSMC LIKE ''%(%''
                                                  OR T.XSMC LIKE ''%)%''
                                                  OR T.XSMC LIKE ''%[%''
                                                  OR T.XSMC LIKE ''%]%'') )
                    UNION ALL
                    SELECT T.XSSX, T.CPSX, ''"'' || T.XSMC || ''"'' XSMC
                      FROM ' || V_FROMTABLE ||
               ' AND ( T.XSMC LIKE ''%(%''
                                OR T.XSMC LIKE ''%)%''
                                OR T.XSMC LIKE ''%[%''
                                OR T.XSMC LIKE ''%]%'')) T
             ORDER BY XSSX) A ';
  EXECUTE IMMEDIATE V_SQL_COL
    INTO V_COL;
  --  DBMS_OUTPUT.PUT_LINE(V_SQL_COL);

  --V_CXZD := REPLACE(V_CXZD,'TPIF_CPDM.SYL','(CASE WHEN TPIF_CPDM.SFGBSYL = 0 THEN ''--'' ELSE TO_CHAR(TPIF_CPDM.SYL) END)');

  --5 组装查询SQL
  SELECT 'SELECT DISTINCT ' || V_CXZD || ' ,TPIF_CPDM.cpfxdj cpfxdjbm , case when sj is not null then 1 else 0 end is_concern ,1 CZ   FROM PIF.TPIF_CPDM left join TPIF_WGZDCP on TPIF_CPDM.ID = TPIF_WGZDCP.CPID
      AND TPIF_WGZDCP.YH =   ' || I_USERID || '  ' ||
         (SELECT REPLACE(WM_CONCAT('LEFT JOIN PIF.' || BM ||
                                   ' ON TPIF_CPDM.ID = ' || BM || '.CPID'),
                         ',',
                         ' ')
            FROM PIF.TPIF_CPJMDX
           WHERE DXLX > 1
             AND ZT = 1
             AND BM IN (SELECT DISTINCT (YWDX) BM
                          FROM TPIF_TYMBLBPZ
                         WHERE TYMB = I_TEMPLATE_ID
                           AND I_PROD_TYPE IS NULL
                        UNION ALL
                        SELECT DISTINCT (YWDX) BM
                          FROM TPIF_FLMBLBPZ
                         WHERE FLMB = I_TEMPLATE_ID
                           AND I_PROD_TYPE IS NOT NULL
                        UNION ALL
                        /*211122HQN*/
                        SELECT DISTINCT (YWDX) BM
                          FROM TPIF_TYMBSSPZ
                         WHERE TYMB = I_TEMPLATE_ID
                        UNION ALL
                        SELECT DISTINCT (YWDX) BM
                          FROM TPIF_FLMBSSPZ
                         WHERE FLMB = I_TEMPLATE_ID)) ||
         ' WHERE CPNBZT =8 /*and cpxl<>12*/  ' || (CASE
           WHEN V_JRCPFL IS NOT NULL THEN
            ' AND instr('';''||''' || V_JRCPFL ||
            '''||'';'','';''||jrcpfl||'';'')>0 '
           ELSE
            NULL
         END) || (CASE
           WHEN I_CPDM IS NOT NULL THEN
            ' AND (UPPER(TPIF_CPDM.CPDM) like  ''%' || V_KEYWORD ||
            '%'' or TPIF_CPDM.CPMC like ''%' || V_KEYWORD || '%'') '
         
         --     WHEN V_KEYWORD IS NOT NULL THEN
         --        ' AND (UPPER(TPIF_CPDM.CPDM) LIKE  ''%' || V_KEYWORD || '%'' OR TPIF_CPDM.CPMC LIKE ''%'|| V_KEYWORD || '%'') ' 
         
           ELSE
            NULL
         END) || V_SQL_WHERE
    INTO V_SQL
    FROM DUAL;

  --DBMS_OUTPUT.PUT_LINE(V_CXZD);

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  --DBMS_OUTPUT.PUT_LINE(V_SORT);

  --OPEN O_RESULT FOR V_SQL;

  --6.==============调用分页查询过程，返回游标==============
  --6.1 初始化分页查询入参
  --列表
  V_COLLIST := '' || V_COL || ' ,cpfxdjbm ,is_concern , CZ ';
  --是否返回结果集
  V_HASRECORDSET := 1;
  COMMIT;
  --6.2.调用分页查询过程

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => TRUE,
           I_SORT         => V_SORT, --至多一条，强制不排序
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || V_ERRMSG FROM DUAL;
  
  
END PCX_PIF_CPJM_ZSLBJX;
/

