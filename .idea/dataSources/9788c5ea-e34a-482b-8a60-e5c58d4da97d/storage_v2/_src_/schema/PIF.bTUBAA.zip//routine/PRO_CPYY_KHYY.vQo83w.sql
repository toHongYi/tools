create PROCEDURE PRO_CPYY_KHYY
(
    O_CODE   OUT NUMBER,
    O_NOTE   OUT VARCHAR2,
    I_CZR    IN NUMBER, --当前登录人,
    I_YYZJZH IN VARCHAR2, --预约资金账号
    I_YYYYB IN NUMBER, --预约营业部
    I_YYCPID IN NUMBER, --预约产品ID
    I_YYJE   IN NUMBER --预约金额
    
    --预约逻辑
    
) AS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：     I_YYCPID  产品预约管理ID
                                 I_CZR   操作人
                                 I_YYZJZH 当前预约资金账号
                                 I_YYJE  预约金额
           输出参数：   O_CODE  返回值
                               O_NOTE   返回消息
                              
      逻辑说明：  
      1.营业部进行预约判断当前预约资金账号所在的营业部，预约额度是否足够，足够则进行预约，
      持仓客户预约不消耗额度；
      2.分公司和总部可以对产品进行预约，但是只能对有资金账号进行预约且资金账号所在营业部
      要有该产品的权限;                           
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WWH        营业部预约
         2021-10-21     2.0.0     WWH        预约权限修改，取消用户所在部门判断
  ***********************************************************************/
    V_YYCPID     NUMBER(16);
    V_ORG        NUMBER(16);
    V_YYZJZH     VARCHAR(300);--预约资金账号
    V_YYBZKYED   NUMBER(16, 2); --营业部总可约额度
    V_YYBZKYRS   NUMBER(10); --营业部总可约人数
    V_YYJE       NUMBER(16, 2); --预约金额
    V_YYBGXYYED  NUMBER(16, 2); --营业部共享额度
    V_YYBGXYYRS  NUMBER(10); --营业部共享人数
    V_CZR        NUMBER(10);
    V_GLCPID     NUMBER(10); --关联的产品
    V_COUNT      NUMBER(10); --对该产品持仓
    V_CPDM       VARCHAR2(300); --预约产品代码
    V_DQSL       NUMBER(16, 2); --持仓当前数量
    V_FLAG       NUMBER; --预约类型,1|持仓客户预约,2|非持仓且无关联产品客户预约,3|预约产品被其他产品关联,4|预约产品关联其他产品
    V_COUNT_GLCP NUMBER(10);
    V_GXCPID     NUMBER(10);
    SUM_ZKYED    NUMBER(16, 2); --所有关联产品的营业部独属额度
    SUM_ZKYRS    NUMBER(16); --所有关联产品的营业部独属人数
    V_COUNT_CCKH NUMBER(4); --持仓客户所在营业部权限
    V_YYZED NUMBER(16,2); --预约总额度
    V_SFYXE NUMBER(2);--是否有限额
BEGIN
    O_NOTE   := '';
    V_YYCPID := I_YYCPID;
    V_YYZJZH := I_YYZJZH;
    V_YYJE   := I_YYJE;
    V_CZR    := I_CZR;
    V_FLAG   := 0;
    

    
    SELECT YYZED INTO V_YYZED FROM TPIF_YYCPGL WHERE ID = V_YYCPID;
    IF V_YYZED = 0 THEN 
      --该产品无限额
      V_SFYXE :=0;
      ELSE
        --有限额
      V_SFYXE:=1;
      END IF;

    SELECT GLCPID, CPDM
    INTO   V_GLCPID, V_CPDM
    FROM   TPIF_YYCPGL
    WHERE  ID = V_YYCPID;

    SELECT COUNT(1)
    INTO   V_COUNT
    FROM   DSC_STAT.TPIF_YYCZXX
    WHERE  ZJZH = V_YYZJZH
    AND    CPDM = V_CPDM
    AND    DQSL>0;
    
    SELECT COUNT(1)
    INTO   V_COUNT_GLCP
    FROM   TPIF_YYCPGL
    WHERE  GLCPID = V_YYCPID;
    
    IF V_COUNT > 0 THEN
       V_FLAG := 1;
            --非关联产品预约
        ELSIF (V_GLCPID IS NULL AND V_COUNT_GLCP = 0 AND V_COUNT = 0)
        THEN
            V_FLAG := 2;
            --产品关联其他产品(GLCPID为关联产品)
        ELSIF (V_GLCPID IS NOT NULL AND V_COUNT_GLCP = 0 AND V_COUNT = 0)
        THEN
            V_FLAG := 3;
            --产品被其他产品关联(GLCPID为空)
        ELSIF (V_GLCPID IS NULL AND V_COUNT_GLCP > 0 AND V_COUNT = 0)
        THEN
            V_FLAG := 4;
        END IF;
    V_ORG:=I_YYYYB;
    -----------预约逻辑-----------------------

    IF V_FLAG = 1
    THEN
    /*SELECT SSYYB
                INTO   V_ORG
                FROM   INFO.TINFO_ZJZHXX
                WHERE  ZJZH = V_YYZJZH;*/
                --查询资金账号所在营业部是否有该产品预约权限
                SELECT COUNT(1)  INTO  V_COUNT_CCKH FROM  TPIF_YYBXE WHERE CPGLID =V_YYCPID AND YYBID = V_ORG;
                IF V_COUNT_CCKH > 0 THEN    
        --该客户不需要消耗额度,直接新增已预约人数和已预约金额
        UPDATE TPIF_YYCPGL
        SET    CCKHYYSL = CCKHYYSL + 1,
               CCKHYYJE = CCKHYYJE + V_YYJE
        WHERE  ID = V_YYCPID;
    
        UPDATE TPIF_YYBXE
        SET    CCKHYYSL = CCKHYYSL + 1,
               CCKHYYJE = CCKHYYJE + V_YYJE
        WHERE  CPGLID = V_YYCPID AND YYBID = (SELECT SSYYB
                 FROM   INFO.TINFO_ZJZHXX WHERE ZJZH =V_YYZJZH  );
                
                ELSE
                  O_CODE:=-1;
                  O_NOTE:='该资金账号所在营业部对该产品无预约权限！';
                  RETURN;
                  END IF;
    ELSE
  --非关联产品的共享额度为该产品总额度-其他营业部额度总和
 --关联产品的共享额度为该产品总额度-(本批次的+共享批次的)营业部独享额度
        IF V_FLAG = 2
        THEN
        
            SELECT (A.YYZED - (SELECT SUM(ZKYED)
                               FROM   TPIF_YYBXE
                               WHERE  CPGLID = V_YYCPID)),
                   (A.YYZRS - (SELECT SUM(ZKYRS)
                               FROM   TPIF_YYBXE
                               WHERE  CPGLID = V_YYCPID))
            INTO   V_YYBGXYYED, V_YYBGXYYRS
            FROM   TPIF_YYCPGL A
            WHERE  A.ID = V_YYCPID;
        
         /*   IF V_YYZJZH IS NULL
            THEN
                SELECT ORGID
                INTO   V_ORG
                FROM   LIVEBOS.TUSER
                WHERE  ID = V_CZR;
            ELSE
                --获取资金账号所属营业部，判断消耗营业部额度还是消耗营业部共享额度
                SELECT SSYYB
                INTO   V_ORG
                FROM   INFO.TINFO_ZJZHXX
                WHERE  ZJZH = V_YYZJZH;
            END IF;*/
        
            IF V_CZR = 0
            THEN
                V_ORG := 759;
            END IF;
        
         /* --分公司和总部对无资金账号客户禁止预约
            SELECT COUNT(1) INTO V_COUNT_ORG FROM LIVEBOS.LBORGANIZATION WHERE LX =1 AND BRANCH_ID IS NOT NULL AND ID =V_ORG;
            
            IF V_COUNT_ORG =0 THEN
              O_CODE:=-1;
              O_NOTE:= '登录用户所在部门无可约产品!';
            RETURN;
            END IF;
            */
            SELECT ZKYED, ZKYRS
            INTO   V_YYBZKYED, V_YYBZKYRS
            FROM   TPIF_YYBXE
            WHERE  YYBID = V_ORG
            AND    CPGLID = V_YYCPID;
        
            IF V_YYBZKYED > 0 AND V_YYBZKYRS > 0
            THEN
                --额度和人数消耗营业部额度
                UPDATE TPIF_YYBXE
                SET    YYJE = YYJE + V_YYJE,
                       YYRS = YYRS + 1
                WHERE  CPGLID = V_YYCPID
                AND    YYBID = V_ORG
                AND    (YYJE + V_YYJE) <= V_YYBZKYED
                AND    (YYRS + 1) <= V_YYBZKYRS;
                --判断更新行数，若没有更新，则提示额度不够
                IF SQL%ROWCOUNT > 0
                THEN
                    --更新产品预约额度、人数
                    UPDATE TPIF_YYCPGL
                    SET    YYYZJE = YYYZJE + V_YYJE,
                           YYYZRS = YYYZRS + 1
                    WHERE  ID = V_YYCPID;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该资金账号所属营业部对该产品预约已达上限!';
                    RETURN;
                END IF;
            
            ELSIF V_YYBZKYED = 0 AND V_YYBZKYRS = 0
            THEN
            
                --人数和额度消耗营业部共享额度
                --产品有限额
                IF V_SFYXE =1 THEN  
                UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                AND    (1 + (SELECT NVL(SUM(YYRS), 0)
                             FROM   TPIF_YYBXE
                             WHERE  CPGLID = V_YYCPID
                             AND    ZKYRS = 0) <= V_YYBGXYYRS)
                AND    (V_YYJE + (SELECT NVL(SUM(YYJE), 0)
                                  FROM   TPIF_YYBXE
                                  WHERE  CPGLID = V_YYCPID
                                  AND    ZKYED = 0) <= V_YYBGXYYED);
                 ELSIF V_SFYXE=0 THEN
                   --产品无限额
                   
                   UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                AND    (1 + (SELECT NVL(SUM(YYRS), 0)
                             FROM   TPIF_YYBXE
                             WHERE  CPGLID = V_YYCPID
                             AND    ZKYRS = 0) <= V_YYBGXYYRS);
                 
                   END IF;                 
                                  
                                  
                IF SQL%ROWCOUNT > 0
                THEN
                    UPDATE TPIF_YYBXE
                    SET    YYJE = YYJE + V_YYJE,
                           YYRS = YYRS + 1
                    WHERE  CPGLID = V_YYCPID
                    AND    YYBID = V_ORG;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该产品预约已达上限!';
                    RETURN;
                END IF;
            ELSIF V_YYBZKYED = 0 AND V_YYBZKYRS <> 0
            THEN
                --额度消耗共享额度，人数消耗营业部额度
                --产品有限额
                 IF V_SFYXE =1 THEN
                UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                AND    (V_YYJE + (SELECT NVL(SUM(YYJE), 0)
                                  FROM   TPIF_YYBXE
                                  WHERE  CPGLID = V_YYCPID
                                  AND    ZKYED = 0) <= V_YYBGXYYED);
                                  --产品无限额
                                  ELSIF   V_SFYXE =0 THEN
                                     UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID;              
                   END IF;
                   
                   
                IF SQL%ROWCOUNT > 0
                THEN
                    UPDATE TPIF_YYBXE
                    SET    YYRS = YYRS + 1,
                           YYJE = YYJE + V_YYJE
                    WHERE  CPGLID = V_YYCPID
                    AND    YYBID = V_ORG
                    AND    (YYRS + 1) <= ZKYRS;
                    IF SQL%ROWCOUNT > 0
                    THEN
                        O_CODE := 199;
                        --正常
                        O_NOTE := '预约成功!';
                    ELSE
                        O_CODE := -1;
                        O_NOTE := '该资金账号所属营业部预约人数已达上限!';
                        RETURN;
                    END IF;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该产品预约额度已达上限!';
                    RETURN;
                END IF;
            
                --额度消耗营业部额度，人数消耗共享额度
            ELSIF V_YYBZKYED <> 0 AND V_YYBZKYRS = 0
            THEN
                UPDATE TPIF_YYBXE
                SET    YYJE = YYJE + V_YYJE,
                       YYRS = YYRS + 1
                WHERE  CPGLID = V_YYCPID
                AND    YYBID = V_ORG
                AND    (YYJE + V_YYJE) <= V_YYBZKYED;
                IF SQL%ROWCOUNT > 0
                THEN
                    --营业部额度足够
                    UPDATE TPIF_YYCPGL
                    SET    YYYZJE = YYYZJE + V_YYJE,
                           YYYZRS = YYYZRS + 1
                    WHERE  ID = V_YYCPID
                    AND    (1 + (SELECT NVL(SUM(YYRS), 0)
                                 FROM   TPIF_YYBXE
                                 WHERE  CPGLID = V_YYCPID
                                 AND    YYZRS = 0) <= V_YYBGXYYRS);
                    IF SQL%ROWCOUNT > 0
                    THEN
                        --正常
                        O_CODE := 199;
                        O_NOTE := '预约成功';
                    ELSE
                        O_CODE := -1;
                        O_NOTE := '该产品预约已达上限!';
                        RETURN;
                    END IF;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该资金账号所属营业部该产品预约已达上限!';
                    RETURN;
                END IF;
            END IF;
        ELSIF V_FLAG IN (3, 4)
        THEN
            --V_GLCPID 不为空
            IF V_FLAG = 3
            THEN
                
                --V_GLCPID 为空
                V_GXCPID := V_GLCPID;
            ELSE
                V_GXCPID := V_YYCPID;
            END IF;
            SELECT SUM(ZKYED), SUM(ZKYRS)
            INTO   SUM_ZKYED, SUM_ZKYRS
            FROM   PIF.TPIF_YYBXE
            WHERE  CPGLID IN
                   (SELECT ID
                    FROM   PIF.TPIF_YYCPGL
                    WHERE  (ID = V_GXCPID OR GLCPID = V_GXCPID));
            --计算营业部共享额度
            SELECT (A.YYZED - SUM_ZKYED), (A.YYZRS - SUM_ZKYRS)
            INTO   V_YYBGXYYED, V_YYBGXYYRS
            FROM   TPIF_YYCPGL A
            WHERE  A.ID = V_YYCPID;
        
            IF V_YYZJZH IS NULL
            THEN
                SELECT ORGID
                INTO   V_ORG
                FROM   LIVEBOS.TUSER
                WHERE  ID = V_CZR;
            ELSE
                --获取资金账号所属营业部，判断消耗营业部额度还是消耗营业部共享额度
                SELECT SSYYB
                INTO   V_ORG
                FROM   INFO.TINFO_ZJZHXX
                WHERE  ZJZH = V_YYZJZH;
            END IF;
            
            IF V_CZR = 0
            THEN
                V_ORG := 759;
            END IF;
  /*          --分公司和总部对无资金账号客户禁止预约
            SELECT COUNT(1) INTO V_COUNT_ORG FROM LIVEBOS.LBORGANIZATION WHERE LX =1 AND BRANCH_ID IS NOT NULL AND ID =V_ORG;
            
            IF V_COUNT_ORG =0 THEN
              O_CODE:=-1;
              O_NOTE:= '登录用户所在部门无可约产品!';
            RETURN;
            END IF;*/
            
            SELECT ZKYED, ZKYRS
            INTO   V_YYBZKYED, V_YYBZKYRS
            FROM   TPIF_YYBXE
            WHERE  YYBID = V_ORG
            AND    CPGLID = V_YYCPID;
        
            IF V_YYBZKYED > 0 AND V_YYBZKYRS > 0
            THEN
                --额度和人数消耗营业部额度
               
                   
                UPDATE TPIF_YYBXE
                SET    YYJE = YYJE + V_YYJE,
                       YYRS = YYRS + 1
                WHERE  CPGLID = V_YYCPID
                AND    YYBID = V_ORG
                AND    (YYJE + V_YYJE) <= V_YYBZKYED
                AND    (YYRS + 1) <= V_YYBZKYRS;
              IF V_SFYXE =0 THEN
                  
                --判断更新行数，若没有更新，则提示额度不够
                IF SQL%ROWCOUNT > 0 THEN
                    --更新产品预约额度、人数
                    UPDATE TPIF_YYCPGL
                    SET    YYYZJE = YYYZJE + V_YYJE,
                           YYYZRS = YYYZRS + 1
                    WHERE  ID = V_YYCPID;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该资金账号所属营业部对该产品预约已达上限!';
                    RETURN;
                END IF;
                
              ELSIF V_SFYXE =1 THEN
                 IF SQL%ROWCOUNT > 0 THEN
                    --更新产品预约额度、人数
                    UPDATE TPIF_YYCPGL
                    SET    YYYZJE = YYYZJE + V_YYJE,
                           YYYZRS = YYYZRS + 1
                    WHERE  ID = V_YYCPID;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该资金账号所属营业部对该产品预约已达上限!';
                    RETURN;
                END IF;
              END IF;
              
            ELSIF V_YYBZKYED = 0 AND V_YYBZKYRS = 0
            THEN
            
                --人数和额度消耗营业部共享额度
                  --产品有限额
                 IF V_SFYXE =1 THEN
                UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                --确保预约完成后，预约人数和预约金额不能超过额度
                AND    (1 +
                      (SELECT NVL(SUM(YYRS), 0)
                         FROM   TPIF_YYBXE                        
                         WHERE  CPGLID IN
                                (SELECT ID
                                 FROM   PIF.TPIF_YYCPGL
                                 WHERE  (ID = V_GXCPID OR GLCPID = V_GXCPID))
                         AND    ZKYRS = 0) <= V_YYBGXYYRS)
                AND    (V_YYJE +
                      (SELECT NVL(SUM(YYJE), 0)
                         FROM   TPIF_YYBXE
                         WHERE  CPGLID IN
                                (SELECT ID
                                 FROM   PIF.TPIF_YYCPGL
                                 WHERE  (ID = V_GXCPID OR GLCPID = V_GXCPID))
                         AND    ZKYED = 0) <= V_YYBGXYYED);
                         --产品无限额
                         ELSIF V_SFYXE =0 THEN
                           UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                   --确保预约完成后，预约人数和预约金额不能超过额度
                AND    (1 +
                      (SELECT NVL(SUM(YYRS), 0)
                         FROM   TPIF_YYBXE                         
                         WHERE  CPGLID IN
                                (SELECT ID
                                 FROM   PIF.TPIF_YYCPGL
                                 WHERE  (ID = V_GXCPID OR GLCPID = V_GXCPID))
                         AND    ZKYRS = 0) <= V_YYBGXYYRS);
                         
            END IF;
                IF SQL%ROWCOUNT > 0
                THEN
                    UPDATE TPIF_YYBXE
                    SET    YYJE = YYJE + V_YYJE,
                           YYRS = YYRS + 1
                    WHERE  CPGLID = V_YYCPID
                    AND    YYBID = V_ORG;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该产品预约已达上限!';
                    RETURN;
                END IF;
            
            ELSIF V_YYBZKYED = 0 AND V_YYBZKYRS <> 0
            THEN
                     --产品有限额
                 IF V_SFYXE =1 THEN
                --额度消耗共享额度，人数消耗营业部额度
                UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID
                   --确保预约完成后，预约人数和预约金额不能超过额度
                AND    (V_YYJE +
                      (SELECT NVL(SUM(YYJE), 0)
                         FROM   TPIF_YYBXE
                         WHERE  CPGLID IN
                                (SELECT ID
                                 FROM   PIF.TPIF_YYCPGL
                                 WHERE  (ID = V_GXCPID OR GLCPID = V_GXCPID))
                         AND    ZKYED = 0) <= V_YYBGXYYED);
                         ELSIF V_SFYXE =0 THEN
            UPDATE TPIF_YYCPGL
                SET    YYYZJE = YYYZJE + V_YYJE,
                       YYYZRS = YYYZRS + 1
                WHERE  ID = V_YYCPID;
            END IF;
            
                IF SQL%ROWCOUNT > 0
                THEN
                    UPDATE TPIF_YYBXE
                    SET    YYRS = YYRS + 1,
                           YYJE = YYJE + V_YYJE
                    WHERE  CPGLID = V_YYCPID
                    AND    YYBID = V_ORG
                    AND    (YYRS + 1) <= ZKYRS;
                    IF SQL%ROWCOUNT > 0
                    THEN
                        O_CODE := 199;
                        --正常
                        O_NOTE := '预约成功!';
                    ELSE
                        O_CODE := -1;
                        O_NOTE := '该资金账号所属营业部预约人数已达上限!';
                        RETURN;
                    END IF;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该产品预约额度已达上限!';
                    RETURN;
                END IF;
            
                --额度消耗营业部额度，人数消耗共享额度
            ELSIF V_YYBZKYED <> 0 AND V_YYBZKYRS = 0
            THEN
                UPDATE TPIF_YYBXE
                SET    YYJE = YYJE + V_YYJE,
                       YYRS = YYRS + 1
                WHERE  CPGLID = V_YYCPID
                AND    YYBID = V_ORG
                AND    (YYJE + V_YYJE) <= V_YYBZKYED;
                IF SQL%ROWCOUNT > 0
                THEN
                    --营业部额度足够
                    UPDATE TPIF_YYCPGL
                    SET    YYYZJE = YYYZJE + V_YYJE,
                           YYYZRS = YYYZRS + 1
                    WHERE  ID = V_YYCPID
                       --确保预约完成后，预约人数和预约金额不能超过额度
                    AND    (1 + (SELECT NVL(SUM(YYRS), 0)
                                 FROM   TPIF_YYBXE
                                 WHERE  CPGLID IN
                                        (SELECT ID
                                         FROM   PIF.TPIF_YYCPGL
                                         WHERE  (ID = V_GXCPID OR
                                                GLCPID = V_GXCPID))
                                 AND    YYZRS = 0) <= V_YYBGXYYRS);
                    IF SQL%ROWCOUNT > 0
                    THEN
                        --正常
                        O_CODE := 199;
                        O_NOTE := '预约成功';
                    ELSE
                        O_CODE := -1;
                        O_NOTE := '该产品预约已达上限!';
                        RETURN;
                    END IF;
                ELSE
                    O_CODE := -1;
                    O_NOTE := '该资金账号所属营业部该产品预约已达上限!';
                    RETURN;
                END IF;
            
            END IF;
        END IF;
END IF;

    O_CODE := 199;
    O_NOTE := '成功！';
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := SQLERRM;
    
END;
/

