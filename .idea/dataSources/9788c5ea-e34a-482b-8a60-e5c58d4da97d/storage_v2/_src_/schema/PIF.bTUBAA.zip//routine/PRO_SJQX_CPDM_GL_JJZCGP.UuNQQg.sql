create PROCEDURE PRO_SJQX_CPDM_GL_JJZCGP(O_CODE OUT NUMBER, --返回值
                                                  O_NOTE OUT VARCHAR2 --返回消息
                                                  ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：基金重仓股票-TPIF_CPDM_GL_JJZCGP数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-16     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  ---FUND_ID,STATISTIC_DATE
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPDM_GL_JJZCGP ' ;

  insert into TPIF_CPDM_GL_JJZCGP(id,      --ID
                                  cpid,    --产品ID
                                  bbq,     --报告期
                                  xh,      --序号
                                  gpdm,    --股票代码
                                  gpmc,    --股票名称
                                  cgsl,    --持股数量(股)
                                  jsqccbd, --较上期持仓量变动
                                  zqsz,    --市值(元)
                                  zzcjzbl, --占资产净值比例
                                  lrr,
                                  lrsj
                               )


 SELECT seq_tpif_cpdm_gl_jjzcgp.nextval,
        M.CPID,
        M.BBQ,
        ROW_NUMBER() OVER(PARTITION BY M.CPID ORDER BY M.zzcjzbl DESC) AS PX,
        M.GPDM,
        M.GPMC,
        M.cgsl,
        M.jsqccbd,
        M.zqsz,
        M.zzcjzbl,
        0,
        sysdate

 FROM ( SELECT  B.CPID,
                TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS bbq,
                A.STOCK_CODE AS gpdm,
                A.STOCK_NAME AS GPMC,
                A.stock_num*10000 as cgsl,
                (A.stock_num-nvl(A.last_stock_num,0))*10000 AS jsqccbd,
                A.stock_a_value AS zqsz,
                A. stock_ratio AS zzcjzbl,
                RANK() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) AS RK
          FROM SRC_PIF.T_FUND_SHAREHOLDING A ,PIF.TPIF_CPDM B
         WHERE A.FUND_ID = B.ZYNM ) M
  WHERE M.RK = 1  ;



  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM_GL_JJZCGP 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM_GL_JJZCGP 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM_GL_JJZCGP 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

