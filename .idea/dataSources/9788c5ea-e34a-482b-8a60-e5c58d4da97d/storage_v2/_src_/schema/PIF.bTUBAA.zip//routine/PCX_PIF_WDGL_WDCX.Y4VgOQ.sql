create PROCEDURE PCX_PIF_WDGL_WDCX(O_CODE     OUT NUMBER,
                                              O_NOTE     OUT VARCHAR2,
                                              O_RESULT   OUT SYS_REFCURSOR,
                                              I_CURRENT  IN NUMBER, --页码
                                              I_PAGESIZE IN NUMBER, --页长
                                              I_PAGING   IN NUMBER, --是否分页
                                              I_SORT     IN VARCHAR2, --排序规模
                                              I_TOTAL    IN OUT NUMBER, --记录总数
                                              I_USERID   IN NUMBER, --登陆用户ID
                                              I_TYPE     IN NUMBER --1：最新上传  2：最多下载.  3：我的收藏
                                              
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：文档管理-最新上传文档查询
  
  
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
  
  
  
        ----------------------------------------------------------
        操作人       版本号      时间                        操作
        WUJINFENG    1.0        2020/06/29                  新增
  -------------------------------------------------------------------------------------------------*/

BEGIN
  IF I_TYPE = 1 THEN
    PCX_PIF_WDGL_ZXSC(O_CODE,
                      O_NOTE,
                      O_RESULT,
                      I_CURRENT,
                      I_PAGESIZE,
                      I_PAGING,
                      I_SORT,
                      I_TOTAL,
                      I_USERID);
  
  ELSIF I_TYPE = 2 THEN
    PCX_PIF_WDGL_ZDXZ(O_CODE,
                      O_NOTE,
                      O_RESULT,
                      I_CURRENT,
                      I_PAGESIZE,
                      I_PAGING,
                      I_SORT,
                      I_TOTAL,
                      I_USERID);
  ELSE
    PCX_PIF_WDGL_WDSC(O_CODE,
                      O_NOTE,
                      O_RESULT,
                      I_CURRENT,
                      I_PAGESIZE,
                      I_PAGING,
                      I_SORT,
                      I_TOTAL,
                      I_USERID);
  END IF;

END;
/

