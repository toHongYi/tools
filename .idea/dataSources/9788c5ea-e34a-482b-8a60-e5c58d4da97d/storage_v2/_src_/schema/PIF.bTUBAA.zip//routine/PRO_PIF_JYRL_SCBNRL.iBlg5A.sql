create PROCEDURE PRO_PIF_JYRL_SCBNRL(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_NF   IN NUMBER, --年份
                                                I_USER IN NUMBER --用户ID
                                                ) IS
  /******************************************************************
  项目名称：托管系统
  所属用户：PIF
  概要说明：生成本年规则记录

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-07-26     V1.0      谢莉莉             创建
      2016-10-31     V2.0      王大一             托管系统迁移改造接入产品中心
   *********************************************************************************************************************/

  V_COUNT NUMBER; --统计
  V_JJNF  NUMBER; --节假年份

BEGIN

  O_CODE := 1;
  O_NOTE := '操作成功';

  SELECT COUNT(1) INTO V_COUNT FROM LIVEBOS.tJRXX WHERE NF = I_NF;
  IF (V_COUNT = 0) THEN
    O_CODE := -1;
    O_NOTE := '还未配置【' || I_NF || '】年的节假日信息!';
    RETURN;
  END IF;

  --取得配置的最新节假日年份
  SELECT MAX(NF) INTO V_JJNF FROM LIVEBOS.tJRXX;

  --处理因为推移而生成的下一年的日历，删除已生成的日历
  FOR GZJL IN (SELECT DISTINCT G.ID GZJL
                 FROM TPIF_JYRL_GZJL G, TPIF_JYRL J
                WHERE INSTR(';' || J.GZJL || ';', ';' || G.ID || ';') > 0
                  AND SUBSTR(TO_CHAR(J.RQ, 'YYYYMMDD'), 0, 4) > G.YSNF
                  AND G.YSNF IS NOT NULL) LOOP
    PRO_PIF_JYRL_GZJLSC(O_CODE, O_NOTE, GZJL.GZJL, -2);
  END LOOP;
  --处理正常规则
  FOR GZJL IN (SELECT ID
                 FROM TPIF_JYRL_GZJL
                WHERE GZJLLX = 1
                  AND SHZT=2---2021-4-19 审核通过的产品反审核后，审核状态变为-1
                            --之后调用该方法，仍然会生成交易日数据，故加此限制--GK
                  AND ((SUBSTR(TO_CHAR(QJJS, 'YYYYMMDD'), 0, 4) > YSNF AND
                      YSNF IS NOT NULL AND YSNF < TO_CHAR(I_NF)) OR
                      (YSNF IS NULL))) LOOP
    /*    INSERT INTO TEST_PARA
      (SJ, PROC, SQLS)
    VALUES
      (SYSDATE, 'PRO_PIF_JYRL_SCBNRL', 'GZJL.ID=>' || GZJL.ID || chr(10));
    COMMIT;*/
    PRO_PIF_JYRL_SCJYRL(O_CODE, O_NOTE, GZJL.ID);
  END LOOP;
  --处理特殊规则
  FOR TSGZ IN (SELECT RQ,
                      (SELECT ID
                         FROM TPIF_JYRL_GZJL
                        WHERE GZJLLX = 2
                          AND CPID = T.CPID) GZJL,
                      YWLX,
                      JYRLX,
                      CPID
                 FROM TPIF_JYRL T
                WHERE RQ <= TO_DATE(I_NF || '1231', 'YYYYMMDD')
                  AND JJRCLGZ IS NOT NULL) LOOP
    PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                            O_NOTE,
                            TSGZ.RQ,
                            TSGZ.GZJL,
                            TSGZ.YWLX,
                            TSGZ.JYRLX);
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_SCBNRL;
/

