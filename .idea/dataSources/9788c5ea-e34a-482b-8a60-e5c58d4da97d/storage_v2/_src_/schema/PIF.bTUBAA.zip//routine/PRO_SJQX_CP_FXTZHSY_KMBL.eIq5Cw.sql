create PROCEDURE PRO_SJQX_CP_FXTZHSY_KMBL( O_CODE OUT NUMBER,   --返回值
                                                      O_NOTE OUT VARCHAR2, --返回消息
                                                      I_RQ    IN NUMBER    --统计日期
                                                    ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险调整后收益-卡玛比率计算
      语法信息：

         指标解释：风险调整后收益，收益依然使用年化收益，风险使用最大回撤。

           输入参数：  无
           输出参数：  O_CODE  返回值
                      O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人           修改内容简要说明
          2021-01-13     1.0      吴金锋              创建
  ***********************************************************************/
  V_RQ      NUMBER;
  V_COUNT   NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_RQ := I_RQ ;
  
  SELECT COUNT(1) INTO V_COUNT FROM DSC_STAT.TPIF_STAT_CP_SYTZ WHERE RQ = V_RQ ;
  
  IF V_COUNT > 0 THEN
    
      --插入到临时表 TEMP_STAT_CP_FXTZHSY

      INSERT INTO TEMP_STAT_CP_FXTZHSY
                      ( RQ ,
                        CPID ,
                        JZRQ ,
                        JYRQ ,
                        DWJZ ,
                        KMBL_3Y ,
                        KMBL_6Y ,
                        KMBL_1N ,
                        KMBL_3N ,
                        KMBL_5N ,
                        KMBL_CLYL ,
                        KMBL_JNYL
                     )
          SELECT A.RQ,
                 A.CPID,
                 A.JZRQ,
                 A.JYRQ,
                 A.DWJZ,     
                 (CASE WHEN B.ZDHC_3Y=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_3Y / B.ZDHC_3Y) ,4) END),
                 (CASE WHEN B.ZDHC_6Y=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_6Y / B.ZDHC_6Y) ,4) END),
                 (CASE WHEN B.ZDHC_1N=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_1N / B.ZDHC_1N) ,4) END),
                 (CASE WHEN B.ZDHC_3N=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_3N / B.ZDHC_3N) ,4) END),
                 (CASE WHEN B.ZDHC_5N=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_5N / B.ZDHC_5N) ,4) END),
                 (CASE WHEN B.ZDHC_CLYL=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_CLYL / B.ZDHC_CLYL) ,4) END),
                 (CASE WHEN B.ZDHC_JNYL=0 THEN 0 ELSE  ROUND( (A.QJNHSYL_JNYL / B.ZDHC_JNYL) ,4) END)
          FROM DSC_STAT.TPIF_STAT_CP_SYTZ A,
               DSC_STAT.TPIF_STAT_CP_FXTZ B
          WHERE A.RQ = B.RQ
            AND A.CPID = B.CPID
            AND A.RQ = V_RQ
            AND B.RQ = V_RQ ;
  
  ELSE

      --插入到临时表 TEMP_STAT_CP_FXTZHSY

      INSERT INTO TEMP_STAT_CP_FXTZHSY
                      ( RQ ,
                        CPID ,
                        JZRQ ,
                        JYRQ ,
                        DWJZ ,
                        KMBL_3Y ,
                        KMBL_6Y ,
                        KMBL_1N ,
                        KMBL_3N ,
                        KMBL_5N ,
                        KMBL_CLYL ,
                        KMBL_JNYL
                     )
          SELECT A.RQ,
                 A.CPID,
                 A.JZRQ,
                 A.JYRQ,
                 A.DWJZ,
                 (CASE WHEN B.ZDHC_3Y=0 THEN 0 ELSE  ROUND((A.QJNHSYL_3Y / B.ZDHC_3Y),4) END),
                 (CASE WHEN B.ZDHC_6Y=0 THEN 0 ELSE  ROUND((A.QJNHSYL_6Y / B.ZDHC_6Y),4) END),
                 (CASE WHEN B.ZDHC_1N=0 THEN 0 ELSE  ROUND((A.QJNHSYL_1N / B.ZDHC_1N),4) END),
                 (CASE WHEN B.ZDHC_3N=0 THEN 0 ELSE  ROUND((A.QJNHSYL_3N / B.ZDHC_3N),4) END),
                 (CASE WHEN B.ZDHC_5N=0 THEN 0 ELSE  ROUND((A.QJNHSYL_5N / B.ZDHC_5N),4) END),
                 (CASE WHEN B.ZDHC_CLYL=0 THEN 0 ELSE  ROUND((A.QJNHSYL_CLYL / B.ZDHC_CLYL),4) END),
                 (CASE WHEN B.ZDHC_JNYL=0 THEN 0 ELSE  ROUND((A.QJNHSYL_JNYL / B.ZDHC_JNYL),4) END)
          FROM DSC_STAT.TPIF_STAT_CP_SYTZ_his A,
               DSC_STAT.TPIF_STAT_CP_FXTZ_his B
          WHERE A.RQ = B.RQ
            AND A.CPID = B.CPID
            AND A.RQ = V_RQ
            AND B.RQ = V_RQ ;
            
   END IF;

  --COMMIT;
  O_CODE := 1;
  O_NOTE := '产品风险调整后收益-卡玛比率清算成功';

EXCEPTION
  WHEN OTHERS THEN
  --  ROLLBACK;
    O_CODE := -1;
    O_NOTE := '产品风险调整后收益-卡玛比率清算失败';
END;
/

