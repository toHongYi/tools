create PROCEDURE PRO_PIF_FWCPWH(O_CODE         OUT NUMBER, --返回值
                                         O_NOTE         OUT VARCHAR2, --返回消息
                                         I_USERID       IN NUMBER,  --操作用户
                                         I_OPER         IN NUMBER ,--操作类型 1：提交审批
                                         I_IDS          IN VARCHAR2 --审批的ID串
                                         ) IS
  /*
  **功能说明：服务产品维护
  **创建人：杨啸天
  **创建日期：2020-07-30
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者          版本号     修改日期     说明
  **杨啸天          1.0.0     2020-07-30   创建
  */

  V_COUNT NUMBER; --存储数据过程变量（计数，求和）

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --操作类型 1：提交审批
  IF I_OPER = 1 THEN

        --进入循环，遍历ID串的值
        FOR CUR_FWCP IN (SELECT COLUMN_VALUE AS CPID
                           FROM TABLE(SPLIT(replace(replace(replace(I_IDS ,'[',''),']',''),' ',''), ','))) LOOP



            -- 校验 传的ID串中的服务产品是否都有定价信息
            SELECT COUNT(ID)
              INTO V_COUNT
              FROM PIF.TPIF_CPDM_FW_DJ A
             WHERE A.CPID = CUR_FWCP.CPID;

            --不存在定价信息进行报错提示
            IF V_COUNT <= 0 THEN

              O_CODE := -1;
              O_NOTE := ' 服务产品ID ：' || CUR_FWCP.CPID || '未添加定价信息，请添加后提交！';
              ROLLBACK;
              RETURN;

            END IF;


            -- 校验 传的ID串中的服务产品的组合成分是否符合要
            -- 第一步判断，该产品是否是服务产品中的组合产品
            SELECT TO_NUMBER(JRCPFL)
              INTO V_COUNT
             FROM TPIF_CPDM
            WHERE CPID = CUR_FWCP.CPID;

            IF 990500 = V_COUNT THEN
              -- 计数：该产品是否存在组合成分信息，不存在报错
               SELECT COUNT(ID)
                 INTO V_COUNT
                 FROM PIF.TPIF_CPDM_FW_ZHCF A
                WHERE A.CPID = CUR_FWCP.CPID;
               --不存在组合成分信息进行报错提示
               IF V_COUNT <= 0 THEN
                O_CODE := -1;
                O_NOTE := ' 服务产品ID ：' || CUR_FWCP.CPID || '未添加组合成分信息，请添加后提交！';
                ROLLBACK;
                RETURN;
               END IF;


               --存在组合成分信息则进行判断，组合成分权重是否和为100
               SELECT SUM(CPQZ)
                 INTO V_COUNT
                FROM PIF.TPIF_CPDM_FW_ZHCF A
               WHERE A.CPID = CUR_FWCP.CPID;
               IF V_COUNT != 100 THEN
                O_CODE := -1;
                O_NOTE := ' 服务产品ID ：' || CUR_FWCP.CPID || '组合成分权重和不为100，信息有误，请修改！';
                ROLLBACK;
                RETURN;
               END IF;


             END IF;

            --执行提交审批，修改内部状态为上架审批中
            UPDATE PIF.TPIF_CPDM SET CPNBZT = 2  WHERE CPID=CUR_FWCP.CPID;


        END LOOP;
       O_NOTE := '提交审批成功！';
        O_CODE := 1;
 ELSE

    O_NOTE := '待添加逻辑！';
    O_CODE := -1;

 END IF;

  COMMIT;



EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END ;
/

