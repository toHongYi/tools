create PROCEDURE PCX_PIF_RGXXSSCX(I_USERID   IN NUMBER,
                                                 CUR_RESULT OUT TYPES.CURSORTYPE --返回结果集
                                                 ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：收益凭证认购监控
        语法信息：
             输入参数：
             输出参数：   CUR_RESULT OUT TYPES.CURSORTYPE, --返回结果集
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2018-06-26     1.0.1    牛玉洁              创建
            2018-08-28     1.0.2    涂孟                修改：去掉人数统计、剩余额度、统计时间
    ***********************************************************************/
    V_ORGID        NUMBER DEFAULT 0; --所在组织结构ID
    V_FATHER_ORGID NUMBER DEFAULT 0; --父组织机构ID
    V_NOTE         VARCHAR2(2000);
BEGIN
    --init
    IF I_USERID IS NULL THEN
        OPEN CUR_RESULT FOR
            SELECT -1 O_CODE, '客户号不能为空' FROM DUAL;
        RETURN;
    ELSIF I_USERID != 0 THEN
        SELECT T.ID, T.FID
          INTO V_ORGID, V_FATHER_ORGID
          FROM livebos.LBORGANIZATION T, livebos.LBMEMBER S
         WHERE T.ID = S.ORGID
           AND S.USERID = I_USERID;
    END IF;

    --start
    OPEN CUR_RESULT FOR
        WITH TT1 AS
         (SELECT CPDM, CPMC, RGRS, RGJE
            FROM TPIF_RGXXSSCX S
           /*WHERE EXISTS (SELECT 1
                    FROM TPIF_CPDM T
                   WHERE S.CPDM = T.CPDM
                     \*AND (T.DJBM = V_FATHER_ORGID OR T.DJBM = V_ORGID OR
                         I_USERID = 0 OR V_ORGID <> 10296)*\)*/),
        TT2 AS
         (SELECT '汇总：' CPDM,
                 NULL CPMC,
                 NULL RGRS,
                 SUM(RGJE) RGJE
            FROM TT1)
        SELECT CPDM, CPMC, RGRS, RGJE
          FROM TT1
        UNION ALL
        SELECT CPDM, CPMC, RGRS, RGJE FROM TT2;
    /* SELECT CPDM 产品代码, CPMC 产品名称, RGRS 认购人数, RGJE 认购金额, TJRQ 统计日期, SYED 剩余额度
      FROM TT1
    UNION ALL
    SELECT CPDM 产品代码, '产品名称' 产品名称, RGRS 认购人数, RGJE 认购金额, TJRQ 统计日期, SYED 剩余额度
      FROM TT2;*/

EXCEPTION
    WHEN OTHERS THEN
        V_NOTE := SQLERRM;
        OPEN CUR_RESULT FOR
            SELECT '异常信息:' || V_NOTE FROM DUAL;
END PCX_PIF_RGXXSSCX;
/

