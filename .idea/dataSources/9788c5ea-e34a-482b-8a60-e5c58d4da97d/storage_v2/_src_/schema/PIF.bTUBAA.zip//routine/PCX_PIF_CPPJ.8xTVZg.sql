create PROCEDURE PCX_PIF_CPPJ(O_CODE        OUT NUMBER,
                                         O_NOTE        OUT VARCHAR2,
                                         O_RESULT      OUT SYS_REFCURSOR,
                                         I_PROD_ID     IN VARCHAR2, --产品ID
                                         I_TEMPLATE_ID IN VARCHAR2, --评价模版ID
                                         I_RESULT_ID   IN NUMBER, --评价结果ID  评价详情信息的查看和导出时传
                                         I_USERID      IN NUMBER --登陆用户ID
                                         ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 产品评价明细查询
  
      语法信息：
           输入参数：    I_PROD_ID     IN VARCHAR2, --产品ID
                        I_TEMPLATE_ID IN VARCHAR2, --评价模版ID
                        I_RESULT_ID   IN NUMBER,   --评价结果ID  评价详情信息的查看和导出时传
                        I_USERID      IN NUMBER     --登陆用户ID
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-10-12    1.0       WUJINFENG              新增
  ***********************************************************************/

  V_CPDM VARCHAR2(50);
  V_CPMC VARCHAR2(200);

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF nvl(I_RESULT_ID,0) = 0 THEN
  
    IF I_PROD_ID IS NULL THEN
      O_CODE := -1;
      O_NOTE := '入参 I_PROD_ID 不允许为空！';
      RETURN;
    END IF;
  
    IF I_TEMPLATE_ID IS NULL THEN
      O_CODE := -1;
      O_NOTE := '入参 I_TEMPLATE_ID 不允许为空！';
      RETURN;
    END IF;
  
    SELECT CPDM, CPMC
      INTO V_CPDM, V_CPMC
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  
    /*  prod_code 产品代码
        prod_name 产品名称
        seqno 序号
        evaluation_dimension  评价维度
        weights 权重
        evaluation_index  评价指标
        evaluation_index_val  评价指标值
        score_way 打分方法
        scores  得分
        editable  得分是否可编辑
    */
  
    OPEN O_RESULT FOR
    
      SELECT PROD_CODE,
             PROD_NAME,
             SEQNO,
             EVALUATION_DIMENSION,
             WEIGHTS,
             EVALUATION_INDEX,
             EVALUATION_INDEX_VAL,
             SCORE_WAY,
             (CASE
               WHEN WDLX = 1 THEN
                (SELECT MAX(MX.FZ)
                   FROM TPIF_CPPJWD_DFMX MX
                  WHERE MX.TPIF_CPPJWD_ID = K.ID
                    AND MX.XX >= EVALUATION_INDEX_VAL
                    AND MX.SX < EVALUATION_INDEX_VAL)
               ELSE
                0
             END) AS SCORES,
             EDITABLE
        FROM (SELECT V_CPDM AS PROD_CODE,
                     V_CPMC AS PROD_NAME,
                     A.BH AS SEQNO,
                     B.KJWD AS EVALUATION_DIMENSION,
                     B.WDLX,
                     A.QZ AS WEIGHTS,
                     (CASE
                       WHEN B.WDLX = 1 THEN
                        (SELECT ZBMC FROM TPIF_CPPJZB WHERE ID = B.PJZB)
                       ELSE
                        '不适用'
                     END) AS EVALUATION_INDEX,
                     (CASE
                       WHEN B.WDLX = 1 THEN
                        (SELECT M.ZBZ
                           FROM PIF.TPIF_CPPJZBJG M
                          WHERE M.CPID = I_PROD_ID
                            AND M.ZB = B.PJZB
                            AND RQ = (SELECT MAX(RQ)
                                        FROM PIF.TPIF_CPPJZBJG M2
                                       WHERE M2.CPID = I_PROD_ID
                                         AND M2.ZB = B.PJZB))
                       ELSE
                        NULL
                     END) EVALUATION_INDEX_VAL,
                     B.SJSM AS SCORE_WAY,
                     --NULL AS SCORES,      --得分
                     1    AS EDITABLE,
                     B.ID
                FROM TPIF_CPPJMB_TM A, --题目
                     TPIF_CPPJWD    B, --维度
                     TPIF_CPPJMB    C --模板
              
               WHERE A.PJWD = B.ID
                 AND C.ID = I_TEMPLATE_ID
                 AND C.ID = A.TPIF_CPPJMB_ID) K
       ORDER BY SEQNO ASC;
  
    --评价详情信息的查看和导出 (I_RESULT_ID)
  ELSE
    
     OPEN O_RESULT FOR
     SELECT C.CPDM AS prod_code,
            C.CPMC AS prod_name,
            A.BH AS seqno,
            D.KJWD AS evaluation_dimension,
            A.QZ AS weights,
            (CASE  WHEN D.WDLX = 1 THEN
                        (SELECT ZBMC FROM TPIF_CPPJZB WHERE ID = D.PJZB)
                       ELSE
                        '不适用'
                     END) AS evaluation_index,
            A.ZBZ AS evaluation_index_val,
            D.SJSM AS score_way,
            A.DF AS scores,
            0 AS editable
     FROM TPIF_CPPJJG_JGMX A ,
          TPIF_CPPJJG B,
          TPIF_CPDM C ,
          TPIF_CPPJWD D
     WHERE B.ID = A.TPIF_CPPJJG_ID
       AND B.CPID = C.ID 
       AND D.ID = A.PJWD 
       AND A.TPIF_CPPJJG_ID  = I_RESULT_ID ;

  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

