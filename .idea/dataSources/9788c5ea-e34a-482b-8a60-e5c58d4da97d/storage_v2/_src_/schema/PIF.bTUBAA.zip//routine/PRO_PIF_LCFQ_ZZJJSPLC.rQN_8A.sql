create PROCEDURE PRO_PIF_LCFQ_ZZJJSPLC(O_CODE            OUT NUMBER, --返回值
                                                  O_NOTE            OUT VARCHAR2, --返回消息
                                                  O_INSTID          OUT NUMBER, --流程实例ID
                                                  O_OBJECTID        OUT VARCHAR2, --子对象ID串
                                                  O_GROUPID         OUT VARCHAR2, --子对象ID串
                                                  I_FORMVALUES      IN VARCHAR2, --字符串（JSON）,流程表单数据
                                                  I_WORKFLOWCREATOR IN VARCHAR2, --流程发起人，为单值，同OA登录名一致
                                                  I_WORKFLOWKEYWORD IN VARCHAR2 --流程关键字，预留

                                                  ) IS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：流程发起后台处理逻辑--种子基金审批流程
      语法信息：
           输入参数：   。。。。
           输出参数：   O_CODE    返回值
                       O_NOTE    返回消息
                       O_INSTID  流程实例ID

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-07     1.0.0    WUJINFENG                创建
  ***********************************************************************/
  V_NUMNEWINSTID       NUMBER; --流程实例ID
  V_NUMNEWSTEPID       NUMBER; --启动步骤ID
  V_NUMNEWSTEPID1      NUMBER; --下一步骤ID
  V_ZT                 VARCHAR2(300);
  V_OWNER              VARCHAR2(1000);
  V_COUNT              NUMBER;
  --V_PRODLIST           VARCHAR2(10000);
  V_OBJECTID          VARCHAR2(10000);
  V_LCZZJJSPLC_ID      NUMBER;
  V_LCZZJJSPLC_CPQD_ID NUMBER;
  V_PRODId           VARCHAR2(500);

  V_JSON_OBJ                 PLJSON; --JSON对象
  V_JSON_DATA                PLJSON;
  V_JSON_LIST                PLJSON_LIST;--JSON 数组
  V_LIST_OBJ                 PLJSON; --JSON对象


 -- V_groupId  VARCHAR2(500);
  V_groupId1 VARCHAR2(500);    --源池
  V_groupId2 VARCHAR2(500);    --目标池
  V_operType VARCHAR2(500);    --操作类型   1:入池 2:出池

BEGIN
  --INIT
  O_CODE   := 99;
  O_NOTE   := '';
  O_INSTID := -1;


  V_JSON_OBJ := PLJSON(I_FORMVALUES);
  V_JSON_DATA:= PLJSON(V_JSON_OBJ.GET('data'));

  --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-斩杀b","C-000vlc","C-000vld","C-000vle"]}

  V_JSON_LIST:= PLJSON_LIST(V_JSON_OBJ.GET('prodList'));--转换成JSON数组
  V_groupId1 := V_JSON_OBJ.get_number('groupId1');  --获取源池类型
  V_groupId2 := V_JSON_OBJ.get_number('groupId2');  --获取目标池类型
  V_operType := V_JSON_OBJ.GET_STRING('operType');  --获取操作类型

  --获取流程主题  日期 + 种子基金+入池/出池+流程
  --SELECT V_JSON_OBJ.GET_STRING('workflowTheme') INTO V_ZT FROM DUAL;
  --种子基金入池流程(2020/01/21 19:44:55)
  SELECT '种子基金'|| DECODE(V_OPERTYPE,1,'入池',2,'出池') ||'流程('||TO_CHAR(SYSDATE,'yyyy/mm/dd hh24:mi:ss')||')' INTO V_ZT FROM DUAL;

/*  SELECT COUNT(*)
    INTO V_COUNT
    FROM LCZZJJSPLC
   WHERE ZT = V_ZT;

  IF V_COUNT > 0 THEN

    O_NOTE := '流程主题不允许重复，请检查FORMVALUES参数';
    RETURN;

  END IF;*/

  --{"workflowTheme":"杭州拓源股权投资管理有限公司白名单流程申请","orgCode":"MA2HYB3D7", "orgName":"MA2HYB3D7", "foundationDate":"20200617","regAddress":"浙江省杭州市余杭区仓前街道景兴路999号6幢209-6-220", "remark":""}

  /************1、获取相关参数***************/

  --生成流程实例化ID
  SELECT LIVEBOS.SEQ_OS_WFENTRY.NEXTVAL INTO V_NUMNEWINSTID FROM DUAL;
  --生成启动步骤ID
  SELECT LIVEBOS.SEQ_OS_CURRENTSTEPS.NEXTVAL INTO V_NUMNEWSTEPID FROM DUAL;
  --下一步骤ID
  SELECT LIVEBOS.SEQ_OS_CURRENTSTEPS.NEXTVAL
    INTO V_NUMNEWSTEPID1
    FROM DUAL;

    /*1011? 白名单
      1012? 观察名单
      1013? 黑名单
      1014? 精选池
      1015? 正面清单
      2011? 储备池
      2012? 拟投资池
      10000?投资池
    */


  IF V_groupId2 = 2011 THEN

    --获取下一步审批人员（测试，先写死）
    SELECT TO_CHAR(WMSYS.WM_CONCAT(A.USERID))
      INTO V_OWNER --下一步流程审核人
      FROM LIVEBOS.LBMEMBER A
     WHERE A.ROLEID =
           (SELECT ID FROM LIVEBOS.LBROLE WHERE ROLECODE = 'CLTYBJL'); --策略投研部二级部门经理

  ELSIF  V_groupId2 = 2012 THEN

    --获取下一步审批人员（测试，先写死）
    SELECT TO_CHAR(WMSYS.WM_CONCAT(A.USERID))
      INTO V_OWNER --下一步流程审核人
      FROM LIVEBOS.LBMEMBER A
     WHERE A.ROLEID =
           (SELECT ID FROM LIVEBOS.LBROLE WHERE ROLECODE = 'HGZY'); --合规一级部门专员审批
  --未定义流程
  ELSE

    NULL ;

  END IF ;



  IF  V_OWNER IS NOT NULL THEN

          /************2、入数据到工作流表单中 ***************/

          LIVEBOS.PNEXTID('LCZZJJSPLC', V_LCZZJJSPLC_ID);

          INSERT INTO LCZZJJSPLC
            (ID,
             INSTID,
             ZT,
             SQR,
             SQRQ,
             SHZT,
             --WCRQ,
             --FJ,
             --HYJY,
             BZ,
             DATA,
             CRC,
          --   CRCLX
             YCLX,  --源池类型
             MBCLX  --目标池类型
             )
            SELECT V_LCZZJJSPLC_ID,
                   V_NUMNEWINSTID,
                   V_ZT,
                   (SELECT ID
                      FROM LIVEBOS.TUSER
                     WHERE USERID = I_WORKFLOWCREATOR
                       AND ROWNUM = 1),
                   SYSDATE,
                   1,
                   V_JSON_OBJ.GET_STRING('remark'),
                   UNISTR(REPLACE(V_JSON_DATA.TO_CHAR,'\u','\')),
                   V_operType,
                   V_groupId1,  --源池类型
                   (case when V_operType=1 then V_groupId2 else null end)   --目标池类型
              FROM DUAL;

          /* SELECT SUBSTR(I_FORMVALUES,
                    INSTR(I_FORMVALUES, 'prodList') + 12,
                    INSTR(I_FORMVALUES, ']') - INSTR(I_FORMVALUES, 'prodList') - 12)
             INTO V_PRODLIST
             FROM DUAL;*/

          --循环插入到子表格LCZZJJSPLC_CPQD   产品清单
          V_OBJECTID := '[';

          --{"prodId":"C-000vlb","prodCode":"000001","prodName":"华夏成长混合1"},
          FOR I IN 1..V_JSON_LIST.COUNT LOOP

              V_LIST_OBJ :=  PLJSON(V_JSON_LIST.GET(I));

              SELECT UNISTR(REPLACE(V_LIST_OBJ.GET('prodId').TO_CHAR,'\u','\'))
                INTO V_PRODId
                FROM DUAL;

              --20210129:判断有相同的产品正在走出入池流（原池 和 目标池 也能够匹配的上）程时。提示有A产品流程审批中，不允许再次发起
              select count(*) into V_COUNT
               from PIF.LCZZJJSPLC_CPQD a
              where  a.lczzjjsplc_id <>V_LCZZJJSPLC_ID
                 and a.cpid = replace(V_PRODId,'"','')
                 and exists(select 1 from PIF.LCZZJJSPLC b
                            where b.id = a.lczzjjsplc_id
                              and b.CRC = V_operType
                              and b.yclx = V_groupId1
                              and (b.mbclx is null or b.mbclx = V_groupId2)
                              and b.shzt = 1
                             );

              IF V_COUNT > 0 THEN

                 ROLLBACK ;
                 O_CODE := 99;
                 O_NOTE := '产品：'||replace(UNISTR(REPLACE(V_LIST_OBJ.GET('prodName').TO_CHAR,'\u','\')),'"','')||' 相关流程正在审核中，请核实后重新发起';

                 RETURN ;
              END IF ;
              --V_OBJECTID
              LIVEBOS.PNEXTID('LCZZJJSPLC_CPQD', V_LCZZJJSPLC_CPQD_ID);
              INSERT INTO PIF.LCZZJJSPLC_CPQD
                (LCZZJJSPLC_ID, ID, CPDM, CPMC,CPID)
              VALUES
                (V_LCZZJJSPLC_ID,
                 V_LCZZJJSPLC_CPQD_ID,
                 replace(UNISTR(REPLACE(V_LIST_OBJ.GET('prodCode').TO_CHAR,'\u','\')),'"',''),
                 replace(UNISTR(REPLACE(V_LIST_OBJ.GET('prodName').TO_CHAR,'\u','\')),'"',''),
                 replace(V_PRODId,'"',''));

              V_OBJECTID := V_OBJECTID || '{"objectName":' || V_PRODId ||
                             ',"id":"' || V_LCZZJJSPLC_CPQD_ID || '"},';

          END LOOP;

          V_OBJECTID := RTRIM(V_OBJECTID, ',')||']';

          /************3、插入OS_WFENTRY ***************/
          INSERT INTO LIVEBOS.OS_WFENTRY
            (ID, NAME, STATE, INITIATOR, INIT_DATE, SUBJECT)
            SELECT V_NUMNEWINSTID, 'WF_ZZJJSPLCGZL', 1, 0, SYSDATE, V_ZT
              FROM DUAL;

          /************4、插入OS_CURRENTSTEP ***************/
          INSERT INTO LIVEBOS.OS_CURRENTSTEP
            (ID,
             ENTRY_ID,
             STEP_ID,
             ACTION_ID,
             OWNER,
             START_DATE,
             FINISH_DATE,
             DUE_DATE,
             STATUS,
             CALLER,
             SUMMARY,
             CONSIGNER)
            SELECT V_NUMNEWSTEPID,
                   V_NUMNEWINSTID,
                /*   case V_operType
                     when '1' then     --入池  目标池为准
                       decode(V_groupId2,2011,8,2012,15)
                     when '2' then     --出池  源池为准
                       decode(V_groupId1,2011,8,2012,15)
                   end,*/
                   decode(V_groupId2,2011,8,2012,15),
                   NULL,
                   0,
                   SYSDATE,
                   NULL,
                   NULL,
                   '待处理',
                   NULL,
                   NULL,
                   NULL
              FROM DUAL;

          /************5、插入OS_HISTORYSTEP ***************/
          INSERT INTO LIVEBOS.OS_HISTORYSTEP
            (ID,
             ENTRY_ID,
             STEP_ID,
             ACTION_ID,
             OWNER,
             START_DATE,
             FINISH_DATE,
             DUE_DATE,
             STATUS,
             CALLER,
             SUMMARY,
             CONSIGNER)
            SELECT ID,
                   ENTRY_ID,
                   STEP_ID,
                  /* case V_operType
                     when '1' then     --入池  以目标池为准
                       decode(V_groupId2,2011,8,2012,15)
                     when '2' then     --出池  以源池为准
                       decode(V_groupId1,2011,8,2012,15)
                   end,*/
                   decode(V_groupId2,2011,9,2012,16),
                   OWNER,
                   START_DATE,
                   SYSDATE,
                   DUE_DATE,
                   '完成',
                   0,
                   NULL,
                   NULL
              FROM LIVEBOS.OS_CURRENTSTEP
             WHERE ID = V_NUMNEWSTEPID;

          /************6、插入OS_HISTORYSTEP_PREV ***************/
          INSERT INTO LIVEBOS.OS_HISTORYSTEP_PREV
            (ID, PREVIOUS_ID)
            SELECT ID, PREVIOUS_ID
              FROM LIVEBOS.OS_CURRENTSTEP_PREV
             WHERE ID = V_NUMNEWSTEPID;

          /************7、更新OS_CURRENTSTEP ***************/
          UPDATE LIVEBOS.OS_CURRENTSTEP
             SET ID = V_NUMNEWSTEPID1,
/*                 STEP_ID =
                   case V_operType
                     when '1' then     --入池  以目标池为准
                       decode(V_groupId2,2011,8,2012,15)
                     when '2' then     --出池  以源池为准
                       decode(V_groupId1,2011,8,2012,15)
                   end,*/
                 STEP_ID = decode(V_groupId2,2011,9,2012,16),
                 OWNER = V_OWNER
           WHERE ID = V_NUMNEWSTEPID;

          /************8、插入OS_CURRENTSTEP_PREV ***************/
          INSERT INTO LIVEBOS.OS_CURRENTSTEP_PREV
            (ID, PREVIOUS_ID)
            SELECT V_NUMNEWSTEPID1, V_NUMNEWSTEPID FROM DUAL;

          /************9、插入LBWFCURRENTOWNER（当前步骤执行人） ***************/
          FOR Y IN (SELECT DISTINCT A.ID
                      FROM LIVEBOS.TUSER A
                     WHERE 1 = 1
                       AND INSTR(',' || V_OWNER || ',', ',' || A.ID || ',') > 0
                     ORDER BY A.ID) LOOP
            INSERT INTO LIVEBOS.LBWFCURRENTOWNER
              (ID, STEPID, OWNER, FLAG, STATUS)
              SELECT LIVEBOS.S_LBWFCURRENTOWNER.NEXTVAL,
                     V_NUMNEWSTEPID1,
                     Y.ID,
                     1,
                     NULL
                FROM DUAL;
          END LOOP;

          --RETURN

          O_INSTID    := V_LCZZJJSPLC_ID;
          O_OBJECTID  := V_OBJECTID;
          O_CODE      := 1;
          O_NOTE      := '成功';
          O_GROUPID   := V_groupId2;

  ELSE

          O_INSTID    := NULL;
          O_OBJECTID  := NULL;
          O_CODE      := 99;
          O_NOTE      := '流程下一步审批人为空';
          O_GROUPID   := NULL;

  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

