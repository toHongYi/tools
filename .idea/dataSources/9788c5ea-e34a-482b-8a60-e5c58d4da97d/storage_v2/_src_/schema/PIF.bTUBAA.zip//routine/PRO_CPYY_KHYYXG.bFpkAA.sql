create PROCEDURE PRO_CPYY_KHYYXG(
    O_CODE   OUT NUMBER,
    O_NOTE   OUT VARCHAR2,

    I_YYZJZH IN VARCHAR2, --预约资金账号
    I_YYCPID IN NUMBER, --预约产品ID
    I_YYJE   IN NUMBER, --修改金额
    I_YYGLID IN NUMBER --预约记录ID

) AS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：      
                      I_YYZJZH 预约资金账号
                      I_YYCPID 预约产品ID
                      I_YYJE      预约金额        
                      I_YYGLID   预约记录ID       
                                 
                                 
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                              
      逻辑说明：   预约记录修改，修改资金账号或者预约金额，预约金额要小于当前营业部的可约额度                            
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WEIWENHAO        预约记录修改
  ***********************************************************************/
V_YYJLID NUMBER(10);
V_YYJE NUMBER(16,2); --预约金额
V_XGJE NUMBER(16,2);--修改金额
V_ZJZH VARCHAR2(300);--预约资金账号
V_ORG NUMBER(10);--资金账号所属营业部
V_YYBZKYED NUMBER(16,2);--营业部预约总额度（0为无限制，此时取用共享额度）
V_CZ NUMBER(16,2);--差值
V_YYBGXYYED NUMBER(16,2);--营业部共享额度
V_YYCPID NUMBER(10);
V_ZKYED NUMBER(16,2);
V_ZKYRS NUMBER(10);
V_CPGLID NUMBER(10);
V_COUNT NUMBER(10);
V_SFYXE NUMBER(2); --是否有限额
V_SFCC NUMBER(2);--预约时是否有持仓
 BEGIN
   V_YYJLID:=I_YYGLID;
   V_XGJE:=I_YYJE;
   V_ZJZH:=I_YYZJZH;
   V_YYJE:=I_YYJE;
   V_YYCPID:=I_YYCPID;
 

 SELECT  YYJE,YYBID,YYSYWCC INTO   V_YYJE,V_ORG,V_SFCC FROM TPIF_YYGL  WHERE  ID = V_YYJLID;
SELECT YYZED INTO V_ZKYED FROM TPIF_YYCPGL WHERE ID = V_YYCPID;
IF V_SFCC =1 THEN
  --有持仓，直接修改不消耗额度
  
 V_CZ:=V_XGJE-V_YYJE;
  
      UPDATE TPIF_YYCPGL
        SET    CCKHYYJE = CCKHYYJE+V_CZ
        WHERE  ID = V_YYCPID;
        
         UPDATE TPIF_YYBXE
        SET    CCKHYYJE = CCKHYYJE + V_CZ
        WHERE  CPGLID = V_YYCPID
        AND    YYBID = V_ORG;
               
        UPDATE TPIF_YYGL SET YYJE =V_XGJE WHERE ID =V_YYJLID;
    O_CODE:=199;
    O_NOTE:='修改成功!';
  RETURN;
  END IF;
  
 IF V_ZKYED = 0 THEN
    --无限额
   V_SFYXE:=0;
   ELSE
     --有限额
     V_SFYXE:=1;
     END IF;
 --获取预约产品共享额度

SELECT GLCPID INTO V_CPGLID FROM TPIF_YYCPGL WHERE ID = V_YYCPID;
SELECT COUNT(1) INTO  V_COUNT FROM TPIF_YYCPGL WHERE GLCPID = V_YYCPID;
    IF V_CPGLID IS NOT NULL THEN
      --获取所有关联产品的共享人数和额度
      SELECT    YYZED,YYZRS   INTO V_ZKYED,V_ZKYRS        FROM  TPIF_YYCPGL  WHERE ID =V_YYCPID;

        SELECT V_ZKYED-SUM(ZKYED)  INTO V_YYBGXYYED
        FROM   TPIF_YYBXE
        WHERE  CPGLID IN (SELECT ID
                          FROM   PIF.TPIF_YYCPGL
                          WHERE  ID = V_CPGLID
                          OR     GLCPID = V_CPGLID);
                          
ELSIF  V_CPGLID IS NULL AND V_COUNT=0 THEN

SELECT (A.YYZED -
           (SELECT SUM(ZKYED) FROM TPIF_YYBXE WHERE CPGLID = V_YYCPID))
    INTO   V_YYBGXYYED
    FROM   TPIF_YYCPGL A
    WHERE  A.ID = V_YYCPID;
 ELSIF  V_CPGLID IS NULL AND V_COUNT>0 THEN
    SELECT    YYZED,YYZRS   INTO V_ZKYED,V_ZKYRS        FROM  TPIF_YYCPGL  WHERE ID =V_YYCPID;

        SELECT V_ZKYED-SUM(ZKYED)  INTO V_YYBGXYYED
        FROM   TPIF_YYBXE
        WHERE  CPGLID IN (SELECT ID
                          FROM   PIF.TPIF_YYCPGL
                          WHERE  ID = V_YYCPID
                          OR     GLCPID = V_YYCPID);
    END IF;
    --获取营业部额度
       SELECT ZKYED
    INTO   V_YYBZKYED
    FROM   TPIF_YYBXE
    WHERE  YYBID = V_ORG
    AND    CPGLID = V_YYCPID;

 --判断金额变大还是减小
 IF V_XGJE=V_YYJE THEN
   UPDATE TPIF_YYGL SET ZJZHID =V_ZJZH WHERE ID = V_YYJLID;
   --预约金额增加

   ELSIF V_XGJE>V_YYJE THEN
         V_CZ:=V_XGJE-V_YYJE;
     IF V_YYBZKYED > 0 THEN
       --额度消耗营业部额度
        UPDATE TPIF_YYBXE
        SET    YYJE = YYJE + V_CZ
        WHERE  CPGLID = V_YYCPID
        AND    YYBID = V_ORG
        AND    (V_CZ + V_YYJE) <= V_YYBZKYED;
         --判断更新行数，若没有更新，则提示额度不够
        IF SQL%ROWCOUNT > 0 THEN
            --更新产品预约额度、人数
            UPDATE TPIF_YYCPGL
            SET    YYYZJE = YYYZJE + V_CZ
            WHERE  ID = V_YYCPID;
            ELSE
              O_CODE:=-1;
            O_NOTE := '该资金账号所属营业部对该产品预约已达上限!';
            RETURN;
            END IF;
            --消耗产品共享额度
            ELSE
              IF V_SFYXE =1 THEN  
         UPDATE TPIF_YYCPGL
        SET    YYYZJE = YYYZJE + V_CZ
        WHERE  ID = V_YYCPID
        AND    (V_CZ + (SELECT NVL(SUM(YYJE), 0)
         FROM   TPIF_YYBXE
         WHERE  CPGLID = V_YYCPID
         AND    ZKYED = 0) <= V_YYBGXYYED);
         ELSIF V_SFYXE=0 THEN
           UPDATE TPIF_YYCPGL
        SET    YYYZJE = YYYZJE + V_CZ
        WHERE  ID = V_YYCPID;
         END IF;
                           IF SQL%ROWCOUNT > 0  THEN
                                UPDATE TPIF_YYBXE
                                SET    YYJE = YYJE + V_CZ
                                WHERE  CPGLID = V_YYCPID
                                AND    YYBID = V_ORG;
                                
                           ELSE
                            O_CODE:=-1;
                              O_NOTE := '该产品预约已达上限!';
                              RETURN;
                          END IF;
                          END IF;
        --预约金额减少
         ELSIF  V_YYJE >V_XGJE THEN
         V_CZ:=V_YYJE - V_XGJE;
          UPDATE TPIF_YYCPGL
        SET    YYYZJE = YYYZJE - V_CZ
        WHERE  ID = V_YYCPID;
        
         UPDATE TPIF_YYBXE
        SET    YYJE = YYJE - V_CZ
        WHERE  CPGLID = V_YYCPID
        AND    YYBID = V_ORG;
        END IF;
        
        UPDATE TPIF_YYGL SET YYJE =V_XGJE WHERE ID =V_YYJLID;

        O_CODE:=199;
        O_NOTE:='修改成功!';
        EXCEPTION
    WHEN OTHERS THEN
        O_CODE:=-1;
        O_NOTE := SQLERRM;

END;
/

