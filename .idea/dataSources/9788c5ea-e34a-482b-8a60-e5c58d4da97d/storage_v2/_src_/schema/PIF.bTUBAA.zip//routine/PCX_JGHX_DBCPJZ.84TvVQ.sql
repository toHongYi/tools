create PROCEDURE PCX_JGHX_DBCPJZ(O_CODE OUT NUMBER,
                                            O_NOTE OUT VARCHAR2,
                                            O_RESULT OUT SYS_REFCURSOR,
                                            I_USERID IN NUMBER,    --用户ID
                                            I_ORGID IN NUMBER      --机构ID
                                            ) AS

/******************************************************************
  项目名称：财通证券运营展业平台-H5机构画像
  所属用户：PIF
  概要说明：代表产品净值查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/17     1.0.0.1   GAOKUN            新增.
  ********************************************************************/

V_FUND_ID NUMBER := -999; --记录该机构的代表产品ID,部分机构没有代表产品，则取默认-999，查询结果为空

BEGIN
  O_CODE := 1;
  O_NOTE := '成功！';

  IF I_ORGID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '机构ID不允许为空！';
    RETURN;
  END IF;

  SELECT REPRESENTATIVE_FUND_ID
    INTO V_FUND_ID
    FROM SRC_PIF.T_FUND_ORG
   WHERE ORG_ID = I_ORGID;

  OPEN O_RESULT FOR
   SELECT A.FUND_ID,
          A.FUND_NAME,
          TO_CHAR(A.STATISTIC_DATE, 'YYYYMMDD') DATA_DATE,
          TO_CHAR(A.NAV,'FM990.0000') UNIT_NAV,
          TO_CHAR(B.ZSPJ,'FM99990.0000') CLOSING_PRICE
     FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A, DSC_STAT.TPIF_STAT_ZSHQ B
    WHERE TO_CHAR(A.STATISTIC_DATE, 'YYYYMMDD') = TO_CHAR(B.SJRQ)
      AND B.ZSDM = '000300.SH'
      AND A.FUND_ID = V_FUND_ID
    ORDER BY A.STATISTIC_DATE ASC;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := '查询失败：'||SQLERRM;
END;
/

