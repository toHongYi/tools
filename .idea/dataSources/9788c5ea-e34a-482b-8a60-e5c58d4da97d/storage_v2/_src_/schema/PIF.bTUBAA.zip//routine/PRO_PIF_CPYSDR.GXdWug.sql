create PROCEDURE PRO_PIF_CPYSDR(O_CODE OUT NUMBER,
                                           O_NOTE OUT VARCHAR2,
                                           I_LX   IN NUMBER, --1:资管产品  2:收益凭证  
                                           I_USERID IN NUMBER --操作用户
                                           ) AS
                                           
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品要素批量导入
      语法信息：
           输入参数：
                           I_USERID IN NUMBER     --操作用户
                           I_LX   IN NUMBER       --1:资管产品  2:收益凭证
           输出参数：
                           O_CODE OUT NUMBER
                           O_NOTE OUT VARCHAR2
                           
      修订记录：
          修订日期       版本号    修订人         修改内容简要说明
          2020-08-04     1.0       杨啸天              新增
          2020-08-05     1.1       高昆                修改
  ***********************************************************************/
  
  V_COUNT NUMBER;         --用于计数判断
  V_NUM   NUMBER := 0;    --记录导入数据条数
  V_ID    NUMBER;         --记录最大的ID，用于插入ID

BEGIN

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;
  
  IF I_LX IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_LX不能为空!';
    RETURN;
  END IF;

  --资管产品要素批量导入
  IF I_LX = 1 THEN    
    
    SELECT COUNT(ID)    --校验批量导入模板中的是否存在数据，不存在则报错
    INTO V_COUNT
    FROM PIF.TPIF_ZGCPYSDR;
    
    IF V_COUNT <= 0 THEN
      O_CODE := -1;
      O_NOTE := '批量导入模板中无数据，请检查！';
      RETURN;
    END IF;
    
    FOR CUR_ZGCP IN (SELECT * FROM PIF.TPIF_ZGCPYSDR) LOOP  --循环遍历资管产品要素导入模板表
      
      SELECT COUNT(ID)
      INTO V_COUNT
      FROM PIF.TPIF_ZGCPYSLR A
      WHERE A.CPDM = CUR_ZGCP.CPDM;
    
      IF V_COUNT > 0 THEN   --校验批量导入模板中的产品代码是否在资管产品要素录入中已存在，存在则报错
        O_CODE := -1;
        O_NOTE := '产品:(' || CUR_ZGCP.CPDM || ')' || CUR_ZGCP.CPMC || 
                '在资管产品要素录入中已存在,请检查！';
        RETURN;
      END IF;

      SELECT MAX(ID)+1 INTO V_ID FROM PIF.TPIF_ZGCPYSLR A;  --查询出最大的ID，从此处开始追加插入
  
      --将 资管产品要素批量导入模板 中的数据 插入到 资管产品要素录入 中
      INSERT INTO PIF.TPIF_ZGCPYSLR
      (ID,
      CPDM,
      CPMC,
      CPQC,
      HBZL,
      RGQSRQ,
      RGJSRQ,
      CLRQ,
      DQRQ,
      CPQX,
      CPGMXX,
      CPGMSX,
      YQSYL,
      CPXL,
      JRCPFL,
      CPFL_PZLB,
      CPFL_FXDJ,
      CPFL_SYTZ,
      CPFL_GGBD,
      CPFL_TZPZ,
      CPFL_TZQX,
      CPGLRID,
      CPTGRID,
      ZCDJJG,
      CPJL,
      GJBM,
      CZR,
      CZSJ,
      ZT,
      FHR,
      FHSJ,
      PCH)
      VALUES
      (V_ID,
      CUR_ZGCP.CPDM,
      CUR_ZGCP.CPMC,
      CUR_ZGCP.CPQC,
      CUR_ZGCP.HBZL,
      CUR_ZGCP.RGQSRQ,
      CUR_ZGCP.RGJSRQ,
      CUR_ZGCP.CLRQ,
      CUR_ZGCP.DQRQ,
      CUR_ZGCP.CPQX,
      CUR_ZGCP.CPGMXX,
      CUR_ZGCP.CPGMSX,
      CUR_ZGCP.YQSYL,
      CUR_ZGCP.CPXL,
      CUR_ZGCP.JRCPFL,
      CUR_ZGCP.CPFL_PZLB,
      CUR_ZGCP.CPFL_FXDJ,
      CUR_ZGCP.CPFL_SYTZ,
      CUR_ZGCP.CPFL_GGBD,
      CUR_ZGCP.CPFL_TZPZ,
      CUR_ZGCP.CPFL_TZQX,
      CUR_ZGCP.CPGLRID,
      CUR_ZGCP.CPTGRID,
      CUR_ZGCP.ZCDJJG,
      CUR_ZGCP.CPJL,
      CUR_ZGCP.GJBM,
      I_USERID,
      SYSDATE,
      0,
      NULL,
      NULL,
      NULL);
  
      --记录导入的数据条数
      V_NUM := V_NUM + 1; 
      
    END LOOP;

    --清除临时表数据
    DELETE FROM PIF.TPIF_ZGCPYSDR;

    O_CODE := 1;
    O_NOTE := '成功导入【' || V_NUM || '】条数据！';
    
  END IF;

  --收益凭证产品要素批量导入
  IF I_LX = 2 THEN
    
    SELECT COUNT(ID)     --校验批量导入模板中的是否存在数据，不存在则报错
    INTO V_COUNT
    FROM PIF.TPIF_SYPZCPYSPLDRMB;
    
    IF V_COUNT <= 0 THEN
      O_CODE := -1;
      O_NOTE := '批量导入模板中无数据，请检查！';
      RETURN;
    END IF;
    
    --将 收益凭证产品要素批量导入模板 中的数据 插入到 产品要素录入 中
    FOR CUR_SYPZ IN (SELECT * FROM PIF.TPIF_SYPZCPYSPLDRMB) LOOP
      
      SELECT COUNT(ID)
      INTO V_COUNT
      FROM PIF.TPIF_CPYSLR A
      WHERE A.CPDM = CUR_SYPZ.CPDM;
    
      IF V_COUNT > 0 THEN   
        O_CODE := -1;
        O_NOTE := '产品:(' || CUR_SYPZ.CPDM || ')' || CUR_SYPZ.CPMC || 
                '在收益凭证产品要素录入中已存在,请检查！';
        RETURN;
      END IF;

      SELECT MAX(ID)+1 INTO V_ID FROM PIF.TPIF_CPYSLR A;  --查询出最大的ID，从此处开始追加插入
      
      INSERT INTO TPIF_CPYSLR
      (ID,
      CPM,
      CPDM,
      CPMC,
      CPQC,
      RGQSRQ,
      CPQX,
      YQSYL,
      HBZL,
      MFMZ,
      CPGMXX,
      CPGMSX,
      CPXL,
      JRCPFL,
      CPFL_PZLB,
      CPFL_FXDJ,
      CPFL_SYTZ,
      CPFL_GGBD,
      CPFL_TZPZ,
      CPFL_TZQX,
      CPGLR,
      ZCDJJG,
      CPJL,
      GJBM,
      TZFZR,
      XSSC,
      SFYHFQ,
      SFYLJQ,
      SFZDDX,
      FXED,
      SFXYLG,
      SFKTQX,
      SFXYDZHT,
      ZDGMRS,
      JYGT,
      QTJE,
      CYJEDZDW,
      CZR,
      CZSJ,
      FHZT)
      VALUES
      (CUR_SYPZ.ID,
      CUR_SYPZ.CPM,
      CUR_SYPZ.CPDM,
      CUR_SYPZ.CPMC,
      CUR_SYPZ.CPQC,
      CUR_SYPZ.RGQSRQ,
      CUR_SYPZ.CPQX,
      CUR_SYPZ.YQSYL,
      CUR_SYPZ.HBZL,
      CUR_SYPZ.MFMZ,
      CUR_SYPZ.CPGMXX,
      CUR_SYPZ.CPGMSX,
      CUR_SYPZ.CPXL,
      CUR_SYPZ.JRCPFL,
      CUR_SYPZ.CPFL_PZLB,
      CUR_SYPZ.CPFL_FXDJ,
      CUR_SYPZ.CPFL_SYTZ,
      CUR_SYPZ.CPFL_GGBD,
      CUR_SYPZ.CPFL_TZPZ,
      CUR_SYPZ.CPFL_TZQX,
      CUR_SYPZ.CPGLR,
      CUR_SYPZ.ZCDJJG,
      CUR_SYPZ.CPJL,
      CUR_SYPZ.GJBM,
      CUR_SYPZ.TZFZR,
      CUR_SYPZ.XSSC,
      CUR_SYPZ.SFYHFQ,
      CUR_SYPZ.SFYLJQ,
      CUR_SYPZ.SFZDDX,
      CUR_SYPZ.FXED,
      CUR_SYPZ.SFXYLG,
      CUR_SYPZ.SFKTQX,
      CUR_SYPZ.SFXYDZHT,
      CUR_SYPZ.ZDGMRS,
      CUR_SYPZ.JYGT,
      CUR_SYPZ.QTJE,
      CUR_SYPZ.CYJEDZDW,
      I_USERID,
      SYSDATE,
      2);
      
      --记录导入的数据条数
      V_NUM := V_NUM + 1; 
      
    END LOOP;

    --清除临时表数据
    DELETE FROM PIF.TPIF_SYPZCPYSPLDRMB;

    O_CODE := 1;
    O_NOTE := '成功导入【' || V_NUM || '】条数据！';
    
  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := O_NOTE || SQLERRM;
  
END;
/

