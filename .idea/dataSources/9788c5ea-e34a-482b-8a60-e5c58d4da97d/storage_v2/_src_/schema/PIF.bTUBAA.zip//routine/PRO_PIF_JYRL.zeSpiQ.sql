create PROCEDURE PRO_PIF_JYRL(O_CODE OUT NUMBER, --返回值
                                         O_NOTE OUT VARCHAR2, --返回消息
                                         I_USER IN INTEGER, --操作人
                                         I_IP   IN VARCHAR2, --操作IP
                                         I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                         I_ID   IN INTEGER --操作ID
                                         ) IS
  /*
  **功能说明：银河证券产品中心
  **创建人：王大一
  **创建日期：2016-10-24
  **************************************************************************
  **修改记录
  2016-10-24     V2.0      王大一             托管系统迁移改造接入产品中心
  */
  V_COUNT INTEGER; --计数变量
  V_OBJ   TPIF_JYRL%ROWTYPE; --表单记录
  --V_OBJ_YZXX  TPIF_CPYZXX%ROWTYPE;
  V_CZKM VARCHAR2(200) := '32005'; --操作科目
  V_CZSM VARCHAR2(2000); --日志操作明细
  V_CZFF VARCHAR2(200); --操作方法
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_JYRL WHERE ID = I_ID;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --删除在这里处理
  IF (I_OPER = 2) THEN
    DELETE FROM TPIF_JYRL WHERE ID = I_ID;
  END IF;
  /*IF I_IP != '[check]' THEN*/
  SELECT DECODE(I_OPER, 0, 'XZ', 1, 'XG', 2, 'SC', '0')
    INTO V_CZFF
    FROM DUAL;
  SELECT '[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', '') || ']_' ||
         'ID=' || V_OBJ.ID
    INTO V_CZSM
    FROM DUAL;
  /* END IF;*/
  --check

  O_NOTE := '记录日志';
  --PRO_JG_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, I_ID, V_CZSM);
  LIVEBOS.PRO_CZRZDJ(O_CODE,
                   O_NOTE,
                   I_USER,
                   'TPIF_JYRL',
                   V_CZFF,
                   I_ID,
                   V_CZSM,
                   I_IP,
                   V_CZKM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;
  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', '') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL;
/

