create FUNCTION FUNC_GET_SFHZYYD(I_SMBMDID IN NUMBER --TPIF_SMGLRBMD.ID
                                              ) RETURN NUMBER IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取是否合作意愿低私募白名单管理人(2个月未回复邮件)
        语法信息：
             输入参数：    I_SMBMDID IN NUMBER IN NUMBER, --TPIF_SMGLRBMD.ID
             输出参数：   0|否；1|是
        逻辑说明：2个月未回复邮件则为合作意愿低私募白名单管理人
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-11-08     1.0.1     HanQN                创建
    ***********************************************************************/
    V_SF NUMBER(32);

BEGIN
   SELECT CASE
         WHEN NOT EXISTS (SELECT 1
                 FROM TPIF_HFFJJL A, LIVEBOS.INFOSEND B
                WHERE A.INFOSENDID = B.ID
                  AND B.STATUS = 5
                  AND A.JGID = T.JGID
                  AND (SYSDATE - A.FJSJ) > 60) THEN
          0
         WHEN  EXISTS
          (SELECT 1
                 FROM TPIF_SJJL S
                WHERE S.JGID = T.JGID
                  AND S.SJSJ > (SELECT MAX(FJSJ)
                                  FROM TPIF_HFFJJL A, LIVEBOS.INFOSEND B
                                 WHERE A.INFOSENDID = B.ID
                                   AND B.STATUS = 5
                                   AND A.JGID = S.JGID AND A.FJSJ<(SYSDATE-60))) THEN
          0
         ELSE
          1
       END AS SF INTO V_SF  FROM TPIF_SMGLRBMD T WHERE ID=I_SMBMDID;
    RETURN(V_SF);
END FUNC_GET_SFHZYYD;
/

