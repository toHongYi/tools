create PROCEDURE PRO_PIF_ZDXS_CPXG(O_CODE OUT NUMBER,    --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_ID   IN INTEGER,   --操作ID (重点销售产品管理ID)
                                               I_CPKID IN INTEGER,  --产品库id
                                               I_SFZD  IN INTEGER,   --是否置顶  1|是，0|否
                                               I_USERID  IN INTEGER  --用户ID
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：重点销售产品管理-产品修改
        语法信息：
             输入参数：I_ID   IN INTEGER, --操作ID (重点销售产品管理ID)
                       I_CPKID IN INTEGER,--产品库id
                       I_SFZD  IN INTEGER--是否置顶
             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-05-19     1.0.1     HQN                新增
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_COUNT1 INTEGER;--计数变量1
    V_CPKID INTEGER; --产品库id
    V_ID    INTEGER;
    V_ZHID  INTEGER; --置换id
    V_ZHSX  INTEGER; --置换顺序
    V_ZSSX  INTEGER; --显示排序
    V_ZDSX  INTEGER; --置顶顺序
    V_OBJ   TPIF_CPBQMX%ROWTYPE; --表单记录
    V_SFZD  INTEGER; --是否置顶
    V_CPID  NUMBER; --产品id
    V_SX    NUMBER; --顺序变量
    V_CPDM  VARCHAR2(32);
BEGIN

    --check
/*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/

    --START
     O_CODE :=1;
     O_NOTE :='操作成功';
      --CHECK
  SELECT COUNT(1)
    INTO V_COUNT
    FROM PIF.TPIF_ZDXS_CP_YYXX
   WHERE TPIF_ZDXS_CP_ID = I_ID
     AND LX = 1;
  
   SELECT COUNT(1)
    INTO V_COUNT1
    FROM PIF.TPIF_ZDXS_CP_YYXX
   WHERE TPIF_ZDXS_CP_ID = I_ID
     AND LX = 2;
  
  IF V_COUNT>1 OR V_COUNT1>1 THEN
     O_CODE := -1;
     O_NOTE := '该类型已存在，请确认！';
     RETURN;
  END IF;
  --获取是否置顶，置顶顺序，展示顺序和产品库id,产品id
    SELECT SFZD,ZDSX,ZSSX,CPKID,CPID,CPDM INTO V_SFZD,V_ZDSX,V_ZSSX,V_CPKID,V_CPID,V_CPDM
     FROM PIF.TPIF_ZDXS_CP WHERE ID=I_ID;

    IF V_CPKID!=I_CPKID THEN --更换产品库
      
      SELECT COUNT(1) INTO V_COUNT 
        FROM PIF.TPIF_ZDXS_CP
       WHERE CPKID=I_CPKID AND CPID=V_CPID;
      --CHECK 
      IF V_COUNT>0 THEN
        O_CODE :=-1;
        O_NOTE :='指定产品库已存在该产品,请确认！';
        RETURN;
      END IF;
      --换产品库且置顶
      IF I_SFZD=1 THEN
         SELECT COUNT(1) INTO V_COUNT 
           FROM PIF.TPIF_ZDXS_CP
          WHERE CPKID=I_CPKID AND SFZD=1 AND SFSC=0;
         IF V_COUNT>=3 THEN 
           O_CODE :=-1;
           O_NOTE :='指定产品库已有3条置顶产品,无法置顶！';
           RETURN;
         END IF;
         
         UPDATE PIF.TPIF_ZDXS_CP 
            SET CPKID=I_CPKID,
                SFZD=1,
                ZDSX=(SELECT NVL(MAX(ZDSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=I_CPKID),
                ZSSX=(SELECT NVL(MAX(ZSSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=I_CPKID)
          WHERE ID=I_ID;
            
         --原产品库非置顶产品顺序-1
         UPDATE PIF.TPIF_ZDXS_CP
            SET ZSSX=ZSSX-1
          WHERE CPKID=V_CPKID AND ZSSX>V_ZSSX AND SFSC=0;
         
         IF V_SFZD=1 THEN --原产品库置顶产品顺序-1
           UPDATE PIF.TPIF_ZDXS_CP
            SET ZDSX=ZDSX-1
           WHERE CPKID=V_CPKID AND ZDSX>V_ZDSX AND SFZD=1 AND SFSC=0; 
         END IF;
       END IF;
      
      --换产品库，非置顶 
      IF I_SFZD=0 THEN 
        UPDATE PIF.TPIF_ZDXS_CP 
            SET CPKID=I_CPKID,
                SFZD=0,
                ZDSX=NULL,
                ZSSX=(SELECT NVL(MAX(ZSSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=I_CPKID)
          WHERE ID=I_ID;
        
         --原产品库非置顶产品顺序-1
         UPDATE PIF.TPIF_ZDXS_CP
            SET ZSSX=ZSSX-1
          WHERE CPKID=V_CPKID AND ZSSX>V_ZSSX ;
        
         IF V_SFZD=1 THEN --原产品库置顶产品顺序-1
           UPDATE PIF.TPIF_ZDXS_CP
            SET ZDSX=ZDSX-1
           WHERE CPKID=V_CPKID AND ZDSX>V_ZDSX AND SFZD=1 AND SFSC=0; 
         END IF;
      END IF;
    END IF;
    
    IF V_CPKID=I_CPKID THEN --不更换产品库  
      --非置顶改为置顶
      IF V_SFZD=0 AND I_SFZD=1 THEN
        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=1 AND SFSC=0;
        IF V_COUNT>=3 THEN 
           O_CODE :=-1;
           O_NOTE :='指定产品库已有3条产品,无法置顶';
           RETURN;
        END IF;
        --放在置顶最后一位
        UPDATE PIF.TPIF_ZDXS_CP 
           SET SFZD=1,
               ZDSX=(SELECT NVL(MAX(ZDSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFSC=0)
         WHERE ID=I_ID;
      END IF;
      --置顶改为非置顶
      IF V_SFZD=1 AND I_SFZD=0 THEN
         UPDATE PIF.TPIF_ZDXS_CP 
            SET ZSSX=ZSSX-1 
          WHERE CPKID=I_CPKID AND ZSSX>V_ZSSX AND SFSC=0;
          
         UPDATE PIF.TPIF_ZDXS_CP 
            SET ZDSX=ZDSX-1 
          WHERE CPKID=I_CPKID AND SFZD=1 AND ZDSX>V_ZDSX; 
         --展示顺序置为1   
         UPDATE PIF.TPIF_ZDXS_CP 
           SET SFZD=0,
               ZDSX=NULL,
               ZSSX=(SELECT NVL(MAX(ZSSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=I_CPKID AND ID!=I_ID)
         WHERE ID=I_ID;
       END IF;
   END IF;
   
   --运营信息修改
   MERGE INTO TPIF_ZDXS_CPYYXX T
  USING (SELECT M.ID,
                M.LX,
                M.NR,
                N.CPKID AS CPKID,
                N.CPID,
                M.TPIF_ZDXS_CP_ID,
                M.LDMC
          FROM  TPIF_ZDXS_CP_YYXX M,TPIF_ZDXS_CP N WHERE M.TPIF_ZDXS_CP_ID=N.ID AND M.TPIF_ZDXS_CP_ID= I_ID
        )S
  ON (T.ZDCPGLID=S.TPIF_ZDXS_CP_ID AND T.YYXXID=S.ID)
  WHEN NOT MATCHED THEN
    INSERT(T.ID, T.CPKID, T.YYXXID,T.CPID, T.ZDCPGLID, T.LX, T.LDMC, T.NR, T.CZR, T.CZSJ ,T.SFSC)
    VALUES(LIVEBOS.FUNC_NEXTID('tpif_zdxs_cpyyxx'),S.CPKID,S.ID,S.CPID, S.TPIF_ZDXS_CP_ID, S.LX, S.LDMC, S.nr,I_USERID,SYSDATE ,0 )
  WHEN MATCHED THEN 
    UPDATE SET T.LX=S.LX,
               T.NR=S.NR,
               T.LDMC=S.LDMC
              ;

   
   --宣传链接修改 
 MERGE INTO TPIF_ZDXS_CPXCLJ T
  USING (SELECT N.ID,
                N.XCBQ,
                N.XCLX,
                N.GGLX,
                N.GGID,
                N.XCBT,
                N.FJ,
                N.XCKSRQ,
                N.XCJSRQ,
                N.TPIF_ZDXS_CP_ID,
                M.CPDM,
                M.CPID,
                N.YID,
                N.URL 
          FROM  TPIF_ZDXS_CP_XCLJ N,TPIF_ZDXS_CP M
         WHERE  N.TPIF_ZDXS_CP_ID=I_ID  AND N.TPIF_ZDXS_CP_ID=M.ID     
                )S
     ON (T.ZDCPGLID=S.TPIF_ZDXS_CP_ID AND T.XCLJID=S.ID)            
    WHEN MATCHED THEN
      UPDATE SET T.XCBQ=S.XCBQ,
                 T.XCLX=S.XCLX,
                 T.GGLX=S.GGLX,
                 T.GGID=S.GGID,
                 T.XCBT=S.XCBT,
                 T.FJ=S.FJ,
                 T.XCKSRQ=S.XCKSRQ,
                 T.XCJSRQ=S.XCJSRQ,
                 T.OSSURL=S.URL;
                 
  MERGE INTO TPIF_ZDXS_CPXCLJ T
  USING (SELECT N.ID,
                N.XCBQ,
                N.XCLX,
                N.GGLX,
                N.GGID,
                N.XCBT,
                N.FJ,
                N.XCKSRQ,
                N.XCJSRQ,
                N.TPIF_ZDXS_CP_ID,
                M.CPDM,
                M.CPID,
                N.YID,
                N.URL 
          FROM  TPIF_ZDXS_CP_XCLJ N,TPIF_ZDXS_CP M
         WHERE  N.TPIF_ZDXS_CP_ID=I_ID  AND N.TPIF_ZDXS_CP_ID=M.ID     
                )S
     ON (T.CPDM=S.CPDM AND T.XCLJID=S.YID)            
    WHEN MATCHED THEN
      UPDATE SET T.XCBQ=S.XCBQ,
                 T.XCLX=S.XCLX,
                 T.GGLX=S.GGLX,
                 T.GGID=S.GGID,
                 T.XCBT=S.XCBT,
                 T.FJ=S.FJ,
                 T.XCKSRQ=S.XCKSRQ,
                 T.XCJSRQ=S.XCJSRQ,
                 T.OSSURL=S.URL;                
   
    MERGE INTO TPIF_ZDXS_CPXCLJ T
  USING (SELECT N.ID,
                N.XCBQ,
                N.XCLX,
                N.GGLX,
                N.GGID,
                N.XCBT,
                N.FJ,
                N.XCKSRQ,
                N.XCJSRQ,
                N.TPIF_ZDXS_CP_ID,
                M.CPDM,
                M.CPID,
                N.YID,
                N.URL 
          FROM  TPIF_ZDXS_CP_XCLJ N,TPIF_ZDXS_CP M
         WHERE  N.TPIF_ZDXS_CP_ID=I_ID  AND N.TPIF_ZDXS_CP_ID=M.ID 
           AND NOT EXISTS(SELECT 1 FROM TPIF_ZDXS_CPXCLJ WHERE CPDM=M.CPDM AND SFSC=0 AND (XCLJID=N.ID OR XCLJID=N.YID))    
                )S
     ON (T.CPDM=S.CPDM AND T.XCLJID=S.YID)            
    WHEN NOT MATCHED THEN 
      INSERT (T.ID,T.ZDCPGLID,T.XCLJID,T.CPID,T.CPDM,T.XCBQ,T.XCLX,T.GGLX,T.GGID,T.XCBT,T.FJ,T.XCKSRQ,T.XCJSRQ,T.CZR,T.CZSJ,T.SFSC,T.OSSURL)
      VALUES (LIVEBOS.FUNC_NEXTID('TPIF_ZDXS_CPXCLJ'),S.TPIF_ZDXS_CP_ID,S.ID,S.CPID,S.CPDM,S.XCBQ,S.XCLX,S.GGLX,S.GGID,S.XCBT,S.FJ,S.XCKSRQ,S.XCJSRQ,I_USERID,SYSDATE,0,S.URL);

    --运营信息置为删除
    UPDATE PIF.TPIF_ZDXS_CPYYXX T SET SFSC=1
     WHERE T.ZDCPGLID = I_ID
      AND NOT EXISTS (SELECT 1 FROM PIF.TPIF_ZDXS_CP_YYXX WHERE ID=T.YYXXID);
     
    --宣传链接置为删除
   /* UPDATE PIF.TPIF_ZDXS_CPXCLJ T SET SFSC=1
     WHERE T.ZDCPGLID = I_ID
      AND NOT EXISTS (SELECT 1 FROM PIF.TPIF_ZDXS_CP_XCLJ WHERE ID=T.XCLJID); */
      
    --原表格对象附件补齐
     UPDATE TPIF_ZDXS_CP_XCLJ B
       SET FJ=(SELECT FJ FROM PIF.TPIF_ZDXS_CPXCLJ WHERE SFSC=0 AND XCLJID=B.ID OR XCLJID=B.YID AND ROWNUM=1)
      WHERE EXISTS(SELECT 1 FROM PIF.TPIF_ZDXS_CP WHERE ID=B.TPIF_ZDXS_CP_ID AND CPID=V_CPID);
     
    --宣传链接置为删除
     UPDATE TPIF_ZDXS_CPXCLJ A
       SET SFSC=1
     WHERE A.CPID=V_CPID 
       AND NOT EXISTS(SELECT 1 FROM TPIF_ZDXS_CP_XCLJ WHERE TPIF_ZDXS_CP_ID=I_ID AND (YID=A.XCLJID OR ID=A.XCLJID));
       
     DELETE FROM TPIF_ZDXS_CP_XCLJ B
      WHERE CPDM=V_CPDM
        AND EXISTS(SELECT 1 FROM TPIF_ZDXS_CPXCLJ WHERE CPDM=V_CPDM AND SFSC=1 AND (XCLJID=B.ID OR XCLJID=B.YID));
       
    --置为待发布
    UPDATE PIF.TPIF_ZDXS_CP SET FBZT=0 WHERE ID=I_ID;
     
    COMMIT; 
       
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_ZDXS_CPXG;
/

