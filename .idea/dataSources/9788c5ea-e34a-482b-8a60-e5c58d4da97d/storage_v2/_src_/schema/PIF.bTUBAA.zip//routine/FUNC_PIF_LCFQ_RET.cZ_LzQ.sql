create FUNCTION FUNC_PIF_LCFQ_RET(I_WORKFLOWID IN VARCHAR2, --发起流程的类型ID：LC_SMJGBMDLC
                                             I_ID         IN NUMBER)
  RETURN VARCHAR2 IS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：流程发起后台,回调入参DATA,处理逻辑
      语法信息：
           输入参数：   。。。。
           输出参数：   O_CODE    返回值
                       O_NOTE    返回消息
                       O_INSTID  流程实例ID
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-07     1.0.0    WUJINFENG                创建
  ***********************************************************************/
  V_COUNT INTEGER; --计数变量
  V_DATA CLOB;
  V_RET VARCHAR2(4000);
  
  V_DATA_JSON PLJSON; --JSON对象
  
  V_CODES_LIST PLJSON_LIST;--JSON 数组

BEGIN

  --1.私募机构白名单流程
  IF I_WORKFLOWID = 'lc_SMJGBMDLC' THEN
  
    null;
  
  END IF;
  --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-斩杀b","C-000vlc","C-000vld","C-000vle"]}
  --2.种子基金审批流程
  IF I_WORKFLOWID = 'LCZZJJSPLC' THEN
  
    SELECT DATA INTO V_DATA FROM PIF.LCZZJJSPLC A WHERE A.ID = I_ID;
    --"result":[" C-000vlb "," C-000nnb "] 
  
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PIF.LCZZJJSPLC_CPQD A
     WHERE A.LCZZJJSPLC_ID = I_ID
       AND A.SFTG = 1;
  
    V_RET := ',"result":[';
    IF V_COUNT > 0 THEN
    
      FOR CUR_RET IN (SELECT *
                        FROM PIF.LCZZJJSPLC_CPQD A
                       WHERE A.LCZZJJSPLC_ID = I_ID
                         AND A.SFTG = 1) LOOP
      
        V_RET := V_RET || '"' || CUR_RET.CPID || '",';
      
      END LOOP;
    
    END IF;
    --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-000vlb","C-000nnb","C-000isc"]}
    --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-000vlb","C-000nnb","C-000isc"],"result":[" C-000vlb "," C-000nnb "]}
    V_DATA := RTRIM(RTRIM(TRIM(V_DATA), '}') || V_RET, ',') || ']}';
    
    
    --第二种方案 就是 codes 做差
    --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-000vlb","C-000nnb","C-000isc"]}
    --{"userId":160464021394337,"userName":"xdg","category":5,"groupId":1011,"fileIds":[],"codes":["C-000vlb","C-000nnb"]}
   /* V_DATA_JSON  := PLJSON(V_DATA);  
    V_CODES_LIST :=PLJSON_LIST(V_DATA_JSON.GET('codes'));
     
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PIF.LCZZJJSPLC_CPQD A
     WHERE A.LCZZJJSPLC_ID = I_ID
       AND nvl(A.SFTG,0) = 0;
  

    IF V_COUNT > 0 THEN
    
      FOR CUR_RET IN (SELECT * FROM PIF.LCZZJJSPLC_CPQD A WHERE A.LCZZJJSPLC_ID = I_ID AND NVL(A.SFTG,0) = 0) LOOP
      
        FOR I IN 1..V_CODES_LIST.COUNT LOOP
          IF V_CODES_LIST.GET_STRING(I)=CUR_RET.CPID THEN   --获取数组中值为P000001 的序号
               PLJSON_EXT.REMOVE(V_DATA_JSON, 'codes['||I||']');  --移除
          END IF;
        END LOOP ;
      
      END LOOP;
    
    END IF;
    
    
    V_DATA :=  UNISTR(REPLACE(V_DATA_JSON.To_Char,'\u','\'));*/

  END IF;

  RETURN(V_DATA);

END;
/

