create PROCEDURE PCX_PIF_CPST_XSRL(O_CODE       OUT NUMBER,
                                                  O_NOTE       OUT VARCHAR2,
                                                  O_RESULT     OUT SYS_REFCURSOR,
                                                  --I_BEGIN_DATE IN NUMBER, --开始日期
                                                  --I_END_DATE   IN NUMBER, --结束日期
                                                  I_QUERY_MONTH IN VARCHAR2,
                                                  I_USERID     IN NUMBER --操作用户  
                                                  ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：产品视图-产品销售日历
             参数说明：
                  入参：
                        I_BEGIN_DATE IN NUMBER, -- 开始日期
                        I_END_DATE   IN NUMBER, --结束日期
                        I_USERID     IN NUMBER --操作用户  
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                         DATE 日期
                         CNT  产品数量
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
  
  -------------------------------------------------------------------------------------------------*/

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_QUERY_MONTH IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_QUERY_MONTH不能为空!';
    RETURN;
  END IF;


  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
 
 select "DATE", COUNT(*) AS CNT  from (SELECT to_char(A.JYR) AS "DATE"
   FROM LIVEBOS.TXTJYR A, PIF.TPIF_DQCP_SSSZ B,TPIF_DQCP C
  WHERE (A.JYR BETWEEN TO_CHAR(B.XSKSRQ, 'yyyyMMdd') AND
        TO_CHAR(B.XSJSRQ, 'yyyyMMdd'))
    AND A.ZRR = A.JYR
    AND TO_CHAR(B.XSKSRQ, 'yyyyMMdd') >= I_QUERY_MONTH || '01'
    AND TO_CHAR(B.XSJSRQ, 'yyyyMMdd') <= I_QUERY_MONTH || '31'
  union
  select to_char(rq, 'yyyyMMdd') as "DATE" from TPIF_JYRL 
  where to_char(rq, 'yyyyMMdd') >= I_QUERY_MONTH || '01'
  and to_char(rq,'yyyyMMdd') <= I_QUERY_MONTH || '31')
   GROUP BY "DATE"
  ORDER BY "DATE";

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

