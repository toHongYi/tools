create PROCEDURE PCX_PIF_CPSY_CPZQ_CPLB(O_CODE          OUT NUMBER, --返回码
                                                   O_NOTE          OUT VARCHAR2, --返回信息
                                                   O_RECORD_NUMBER OUT NUMBER,
                                                   O_RESULT        OUT SYS_REFCURSOR,
                                                   I_page_no       IN NUMBER, --页码
                                                   I_page_long     IN NUMBER, --页长
                                                   ------------------------------------------------------------
                                                   I_output_col          IN VARCHAR2 := NULL, --输出列，允许空
                                                   I_prod_name           IN VARCHAR2, --产品代码/名称
                                                   I_expected_yield_rate IN NUMBER, --预期收益率1|0-5%(含)；2|5-8%（含）；3|8%以上
                                                   I_risk_level          IN NUMBER, --风险等级(字典:CPFXDJ)
                                                   I_area_id             IN INTEGER, --专区ID
                                                   I_USERID              IN NUMBER --登陆用户
                                                   ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      概要说明：产品专题-产品列表
               I_prod_name         IN VARCHAR2, --产品代码/名称
               I_expected_yield_rate        IN NUMBER, --预期收益率1|0-5%(含)；2|5-8%（含）；3|8%以上
               I_RGQD         IN NUMBER, --产品规模(字典:JJGM) 1|5万以下；2|5-10万；3|10-50万；4|50-100万；5|100-300万，6|300以上；
               I_CPQX         IN NUMBER, --投资周期（1|六个月以下;2|6-12个月;3|12-18个月;4|18-24个月；5|2年以上）
               I_SYLX         IN NUMBER, --金融产品收益类型(JRCPSYLX)
               I_risk_level         IN NUMBER, --风险级别(字典:CPFXDJ)
               I_CPZT         IN NUMBER, --产品状态字典: TXTDM(FP_CPZT)
               I_USERID       IN NUMBER, --登陆用户
               I_SHOWTYPE     IN NUMBER := 0 --0|JSP使用;1|LIVEBOS使用
      语法信息：
           输出参数：
              O_CODE  成功返回 订单号，失败返回-1
              O_NOTE     成功返回操作成功，失败返回错误信息
  修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2012/09/09     1.0.1    戴文生             从C4迁移过来
          2015/05/11     1.0.2    郭坤               根据不同的专区配置不同的查询字段  
  ***********************************************************************/

  V_SQL          VARCHAR2(32767);
  V_SORT         VARCHAR2(2000);
  V_COLLIST      VARCHAR2(500) := NVL(I_output_col, '*');
  v_HASRECORDSET number;
BEGIN

  O_CODE         := 1;
  O_NOTE         := NULL;
  v_HASRECORDSET := 1;

  V_SQL := 'SELECT /* ROWNUM R,*/ /*START*/'  --此行是固定格式，不要修改、删除
           --|| 'A.ID prod_id,' 
           || 'A.ID prod_id,' 
           || 'a.PROD_CODE PROD_CODE,' 
           || 'a.PROD_FULLNAME prod_name,' 
           || 'A.PROD_TERM PROD_TERM,' 
           || 'A.SUBSCRIBE_BEGIN_DATE SUBSCRIBE_BEGIN_DATE,' 
           || 'A.SUBSCRIBE_END_DATE SUBSCRIBE_END_DATE,' 
           --||'A.CPQXR 产品起息日,'
           || 'A.ESTABLISH_DAY as ESTABLISH_DATE, ' 
           || 'A.EXPIRE_DATE as  EXPIRE_DATE, ' 
           || 'A.SUBSCRIBE_ORIGIN SUBSCRIBE_ORIGIN,' 
           --||'NULL  "认购变动（份）",' 
           || 'A.FACEVALUE FACEVALUE,' 
           || 'A.PROD_ESTABLISH_SHARE/10000 PROD_ESTABLISH_SHARE,' 
           || '(SELECT NOTE FROM CRMII.TXTDM WHERE TXTDM.IBM=a.PROD_RISK_LEVEL AND FLDM=''D_PROD_RISK_LEVEL'') PROD_RISK_LEVEL,' 
           || '(SELECT NOTE FROM CRMII.TXTDM WHERE TXTDM.IBM=A.PROD_PHASE AND FLDM=''D_PROD_PHASE'') PROD_PHASE' 
           ||' /*END*/  '  --此行是固定格式，不要修改、删除
           || ' FROM PIF.tPROD_BASIC_INFO A '
           || ' WHERE AUDIT_STATUS =2 '
           || ' AND A.ID IN (SELECT H.CPID FROM TPIF_CPZTMX H WHERE H.CPZT = ' || I_area_id || ') ' 
           || CASE WHEN I_prod_name IS NOT NULL THEN
              ' AND (a.PROD_CODE LIKE ''%' || I_prod_name || '%'' OR a.PROD_FULLNAME LIKE ''%' || I_prod_name || '%'') '
              END || CASE
             WHEN I_risk_level IS NOT NULL THEN
              ' AND a.PROD_RISK_LEVEL=' || I_risk_level
           END;

  --预期收益率(1|0-5%(含)；2|5-8%（含）；3|8%以上)
  IF I_expected_yield_rate IS NOT NULL AND
     I_expected_yield_rate IN (1, 2, 3) THEN
    IF I_expected_yield_rate = 1 THEN
      V_SQL := V_SQL || ' AND A.FIX_YIELD_RATE/100>=0 AND A.FIX_YIELD_RATE/100<=0.05 ';
    END IF;
    IF I_expected_yield_rate = 2 THEN
      V_SQL := V_SQL || ' AND A.FIX_YIELD_RATE/100>0.05 AND A.FIX_YIELD_RATE/100<=0.08';
    END IF;
    IF I_expected_yield_rate = 3 THEN
      V_SQL := V_SQL || ' AND A.FIX_YIELD_RATE/100>0.08';
    END IF;
  END IF;

  V_SORT := 'prod_id DESC ';

  --DBMS_OUTPUT.PUT_LINE(V_SQL)

  PCX_TYCX(O_CODE,
           O_NOTE,
           v_HASRECORDSET,
           O_RESULT,
           1,
           I_page_no,
           I_page_long,
           O_RECORD_NUMBER,
           SQLS            => V_SQL,
           COLLIST         => V_COLLIST,
           HASWHERE        => TRUE,
           GROUPISLAST     => FALSE,
           I_SORT          => V_SORT,
           I_HASWITH       => FALSE);

END PCX_PIF_CPSY_CPZQ_CPLB;
/

