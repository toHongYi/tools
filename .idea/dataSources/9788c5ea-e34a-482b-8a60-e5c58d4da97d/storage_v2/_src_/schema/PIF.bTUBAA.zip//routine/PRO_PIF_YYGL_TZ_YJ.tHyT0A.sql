create PROCEDURE PRO_PIF_YYGL_TZ_YJ(O_CODE OUT NUMBER,
                                               O_NOTE OUT VARCHAR2,
                                               I_RQ   NUMBER DEFAULT NULL, --日期
                                               I_SJLX IN NUMBER DEFAULT NULL --事件类型
                                               ) AS
  /******************************************************************
  项目名称：PIF  产品中心-运营管理
  所属用户：PIF
  概要说明：邮件通知执行人
        I_RQ    --日期
  语法信息：
       输出参数：
          O_CODE  成功返回 成功，失败返回-1
          O_NOTE     成功返回操作成功，失败返回错误信息
  数据准备：
       关联调度
  运行原理：
        1.入参校验
       2.发送邮件通知
         2.1获取当日需要邮件通知的 运营任务信息。
         2.2进行邮件通。
  功能修订：
      简要说明：
        运营任务生成调度主过程
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/11/14     1.0.1     林嵩              运营任务生成调度主过程。
      2014/11/24     1.0.2     刘浪浪            添加邮件接收人地址入参
      2014/11/28     1.0.3     刘浪浪            加入事件类型入参
      2015/01/27     1.0.4     刘浪浪            日期入参由VARCHAR2改为NUMBER
  *********************************************************************************************************************/
  CONST_MSGTYPE_YJ    CONSTANT INTEGER DEFAULT 2; --电子邮件
  CONST_MSGSENDER_SYS CONSTANT INTEGER DEFAULT 0; --系统发送人
  CONST_PSFS_ZD       CONSTANT INTEGER DEFAULT 1; --配送方式-自动

  V_RQ NUMBER(8) DEFAULT I_RQ; --当前日期
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';
  --1.***************************入参校验 ***************************
  --当前变量赋值
  IF V_RQ IS NULL THEN
    V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
  END IF;
  --2.***************************发送邮件通知***************************
  --2.1.***************************获取当日需要邮件通知的 运营任务信息***************************
  FOR CUR_CPYYRW IN (SELECT A.ID, A.RWNR, A.ZXRY
                       FROM TPIF_CPYYRW A, TPIF_CPYYRWLX B
                      WHERE A.YYRWLX = B.ID
                        AND A.RWFSRQ = V_RQ
                        AND ZXZT = 0
                        AND B.SFYJTX = 1
                        AND A.CPSJLX = NVL(I_SJLX, A.CPSJLX)) LOOP
    --2.2.***************************2进行邮件通***************************
    livebos.PRO_FWGL_DXFS(O_CODE, O_NOTE, CONST_MSGSENDER_SYS, CONST_MSGTYPE_YJ, CONST_PSFS_ZD, CUR_CPYYRW.ZXRY, NULL, '运营任务邮件提醒', CUR_CPYYRW.RWNR);
  END LOOP;

  --CRMII.PRO_YJHBCL(O_CODE,O_NOTE,'运营任务邮件提醒');

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
      RETURN;
    END;
END PRO_PIF_YYGL_TZ_YJ;
/

