create PROCEDURE PCX_KHBF_XQ(O_CODE OUT NUMBER,        --错误代码
                                        O_NOTE OUT VARCHAR2,      --错误消息
                                        O_RESULT  OUT SYS_REFCURSOR,--返回数据集
                                        I_USERID IN NUMBER,       --登陆用户ID
                                        I_VISITID IN NUMBER       --拜访记录ID
                                        )AS
                                        
/******************************************************************
  项目名称：财通证券运营展业平台-客户拜访
  所属用户：PIF
  概要说明：客户拜访详情查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回数据集
       输入参数：
          见参数定义部分   

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   GAOKUN            新增.
  ********************************************************************/

BEGIN
  O_CODE :=1;
  O_NOTE :='成功！';

  IF I_USERID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='登录用户ID不能为空！';
    RETURN;
  END IF;

  IF I_VISITID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='拜访记录ID不能为空！';
    RETURN;
  END IF;

  OPEN O_RESULT FOR

  SELECT A.ID,
       A.JGMC||TO_CHAR(TO_DATE(A.JLRQ,'YYYYMMDD'),'MM-DD')||'拜访记录'  COMM_SUBJECT,
       A.JLRQ  COMM_DATE,
       
       A.JLDXLX  COMM_OBJECT_TYPE,
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.NOTE)), ',', ';')
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_JLDXLX'
           AND INSTR(';' || A.JLDXLX || ';', ';' || B.IBM || ';') > 0) COMM_OBJECT_TYPE_NAME,
           
       A.JLDX COMM_OBJECT,
       (SELECT B.NOTE
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_DYJLXS'
           AND B.IBM = A.DYJLXS) COMM_FORM,
       A.JGID VISIT_ORG_ID,
       A.JGMC ORG_NAME,
       (SELECT B.NOTE
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_GLR_GSFL'
           AND B.IBM = A.JGXZ) ORG_PROP,
       (SELECT B.NOTE
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_GLR_ZJGLGM'
           AND B.IBM = A.GSZJGLGM) CORP_FUND_MANAGE_SCALE,     
       A.GSHXTYTD CORP_CORE_RESEARCH_PERSON,
       A.JGHXCL ORG_CORE_POLICY,
       A.QTQKSM OTHER_CONDITION_DESC,
       C.XQMC REQUEST_NAME,
       
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.BM)), ',', ';')
          FROM TPIF_XQLX B
         WHERE INSTR(';' || C.XQLX || ';', ';' || B.ID || ';') > 0 ) REQUEST_TYPE,
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.MC)), ',', ';')
          FROM TPIF_XQLX B
         WHERE INSTR(';' || C.XQLX || ';', ';' || B.ID || ';') > 0)  REQUEST_TYPE_NAME,
    
       C.FBRQ PUBLISH_DATE,
 /*       C.JZRQ END_DATE,
       (SELECT B.NOTE
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_YWXQZT'
           AND B.IBM = C.XQZT) REQUEST_STATUS, */
       
       C.SJYWDY  INVOLVE_BUSINESS_UNIT,
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.NOTE)), ',', ';')
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = 'PIF_SJYWDY'
           AND INSTR(';' || C.SJYWDY || ';', ';' || B.IBM || ';') > 0) INVOLVE_BUSINESS_NAME,
       
       C.YWXQSM  BUSINESS_REQUEST_DESC,
       C.XQMZQK REQUEST_SATISFY_CONDITION,
       A.JGGDFX ORG_MARKET_VIEW_SHARING,
--       A.HYZXFX INDUSTRY_INFO_SHARING,
       A.DJR REG_PERSON,
       A.DJRQ REG_DATE,
       
       A.BMMC GROUP_NAME,
       A.DKLX CHECKIN_TYPE,
       A.DD LOCATION_TITLE,
       A.WZMX LOCATION_DETAIL,
       A.DKSJ CHECKIN_TIME,
       A.SFHXZC IS_CORE_PROPERTY,
       A.FJMC FILE_NAME,
       A.OSSURL OSS_URL,
       A.WZLJ ARTICLE_LINK,
       A.SCLX SKIP_TYPE
       
  FROM PIF.TPIF_BFJL A,TPIF_XQXX C
 WHERE A.ID = I_VISITID AND A.YWXQ=C.ID;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    
END;
/

