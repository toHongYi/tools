create PROCEDURE PRO_PIF_SMCPJXCX(O_RESULT  OUT SYS_REFCURSOR,
                                             I_USERID  IN NUMBER,
                                             I_KEYWORD IN VARCHAR2) AS
  /******************************************************************
  项目名称：财通证券产品中心-私募产品绩效查询
  所属用户：PIF
  概要说明：私募产品绩效维护报表，
  
            涉及表：
            
            1.产品维护表 PIF.TPIF_SMJXBBCPWH ，用于确定报表展示哪些产品，
            
            2.私募基金自适应基础业绩表 INFO.T_FUND_ADJUSTED_PERFORMANCE ，
           
            该表只存最新一天，取各个维度的收益率、最大回撤、夏普比率
            
            3.私募产品每年收益率 INFO.PRIVATE_FUND_YEAR_RETURN ，取每年收益
  
            
            每年的收益率是展示前面6年的，即
  
            如果当年是2021年，则展示 2015、2016、2017、2018、2019、2020年收益率
  
            如果当年是2022年，则展示 2016、2017、2018、2019、2020、2021年收益率
  
            如果当年是X年，则展示 X-6、X-5、X-4、X-3、X-2、X-1年收益率
  
  语法信息：
       输出参数：
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分
  
  修订记录：
      修订日期        版本号     修订人             修改内容简要说明
      2021-12-8       1.0.0     GAOKUN             新增
      2021-12-14      1.0.1     GAOKUN           新增近一年维度的四个字段
  ********************************************************************/
  V_NOTE VARCHAR2(1000); --报错信息输出
  V_SQL  VARCHAR2(4000); --动态拼接SQL
  V_NF   NUMBER; --年份
BEGIN

  IF I_USERID IS NULL THEN
    V_NOTE := '入参USERID不能为空！';
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
  
  
    RETURN;
  END IF;

  V_SQL := 'SELECT A.CL AS "策略",
                   A.GLR AS "管理人",
                   A.TZJL AS "投资经理",
                   A.CPMC AS "产品名称",
                   A.CPDM AS "产品代码",
                   B.WEEK_RETURN * 100 AS "本周收益率(%)",
                   B.M1_RETURN * 100 AS "近一月收益率(%)",
                   B.M3_RETURN * 100 AS "近三月收益率(%)",
                   B.M6_RETURN * 100 AS "近六月收益率(%)",
                   B.YEAR_RETURN * 100 AS "今年以来收益率(%)",
                   B.Y1_RETURN * 100 AS "近一年收益率(%)",
                   B.Y1_RETURN_A * 100 AS "近一年年化收益率(%)",
                   B.Y1_MAX_RETRACEMENT * 100 AS "近一年最大回撤(%)",
                   B.Y1_SHARP AS "近一年夏普比率",
                   B.TOTAL_RETURN * 100 AS "成立以来收益率(%)",
                   B.TOTAL_RETURN_A * 100 AS "成立以来年化收益率(%)",
                   B.TOTAL_MAX_RETRACEMENT * 100 AS "成立以来最大回撤(%)",
                   B.TOTAL_SHARP AS "成立以来夏普比率",
                   TO_DATE(A.CLRQ, ''YYYY-MM-DD'') AS "成立日期",
                   B.STATISTIC_DATE AS "净值日期",';

  --展示前面6年的收益率，所以 -6
  --当年是2021，则 V_NF=2021-6=2015
  --当年是X，则V_NF=X-6
  SELECT TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')) - 6 INTO V_NF FROM DUAL;

  --展示前面6年的收益率，所以循环6遍，最后一遍末尾不加 逗号
  --当年是2021，则V_SQL拼接的是2015、2016、2017、2018、2019、2020
  --当年是X，则V_SQL拼接的是X、X+1、X+2、X+3、X+4、X+5
  FOR I IN 0 .. 5 LOOP
    IF I = 5 THEN
      V_SQL := V_SQL || '
      C.SYL_' || (V_NF + I) || ' * 100 AS "' || (V_NF + I) ||
               '年收益率(%)"';
    ELSE
      V_SQL := V_SQL || '
      C.SYL_' || (V_NF + I) || ' * 100 AS "' || (V_NF + I) ||
               '年收益率(%)",';
    END IF;
  END LOOP;

  V_SQL := V_SQL || '
         FROM PIF.TPIF_SMJXBBCPWH A
  LEFT JOIN INFO.T_FUND_ADJUSTED_PERFORMANCE B
    ON A.FUND_ID = B.FUND_ID
  LEFT JOIN INFO.PRIVATE_FUND_YEAR_RETURN C
    ON A.FUND_ID = C.FUND_ID ';

  --关键字查询
  IF I_KEYWORD IS NOT NULL THEN
    V_SQL := V_SQL || '
    WHERE INSTR(A.CPDM,''' || I_KEYWORD ||
             ''')>0 OR INSTR(A.CPMC,''' || I_KEYWORD || ''')>0 ';
  END IF;

  --根据策略排序，空值在最后
  V_SQL := V_SQL || '
  ORDER BY A.CL ASC NULLS LAST';

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
  
  
END;
/

