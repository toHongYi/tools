create PROCEDURE PRO_PIF_GSMJZ(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2, --返回消息
                                          I_USER IN INTEGER, --操作人
                                          I_IP   IN VARCHAR2, --操作IP
                                          I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|批量删除;4|校验;5|确认导入
                                          I_ID   IN VARCHAR2 --操作IDs
                                          ) IS
    /*
    **功能说明： 私募产品净值导入
    **创建人：陈勇军
    **创建日期：2017-06-22
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **陈勇军              2017-06-22    创建
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_GSMJZ%ROWTYPE; --表单记录
    V_QXBZ  INTEGER; --权限标识
    V_CZBM  VARCHAR2(200); --操作编码
    V_CZSM  VARCHAR2(2000); --日志操作明细
    V_JYJG  INTEGER;
    V_JYSM  VARCHAR2(2000);
    V_C_S   INTEGER;
    V_C_F   INTEGER;
    V_IDS   VARCHAR2(2000);
    V_CPID  INTEGER;
    V_NOTE  VARCHAR2(2000);
    V_JZRQ  INTEGER;
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_GSMJZ WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  0,
                  '900701',
                  1,
                  '900702',
                  2,
                  '900703',
                  '3',
                  '900704',
                  '4',
                  '900705',
                  '5',
                  '900706')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', 3, '批量删除', 4, '校验', 5, '确认导入') || ']_'
           || (CASE
               WHEN I_OPER = 3 THEN
                I_ID
               WHEN I_OPER IN (4, 5) THEN
                '全部'
               ELSE
                V_OBJ.CPMC||'_'||V_OBJ.JZRQ END)
      INTO V_CZSM
      FROM DUAL;
    --CHECK
/*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增
        IF V_OBJ.CPDM IS NULL THEN
            O_NOTE := '[产品代码]' || V_OBJ.CPDM || '不允许为空！';
            RETURN;
        END IF;
        IF V_OBJ.CPMC IS NULL THEN
            O_NOTE := '[产品名称]' || V_OBJ.CPMC || '不允许为空！';
            RETURN;
        END IF;
        IF V_OBJ.JZRQ IS NULL THEN
            O_NOTE := '[净值日期]' || V_OBJ.JZRQ || '不允许为空！';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT
          FROM TPIF_GSMJZ A
         WHERE A.CPDM = V_OBJ.CPDM AND A.CPMC = V_OBJ.CPMC AND A.JZRQ = V_OBJ.JZRQ;
        IF V_COUNT > 1 THEN
            O_NOTE := '[产品代码]:' || V_OBJ.CPDM || '[产品名称]:' || V_OBJ.CPMC || '[净值日期]:' ||
                      V_OBJ.JZRQ || '记录已存在，不允许重复新增！';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --//:修改
        IF V_OBJ.CPDM IS NULL THEN
            O_NOTE := '[产品代码]' || V_OBJ.CPDM || '不允许为空！';
            RETURN;
        END IF;
        IF V_OBJ.CPMC IS NULL THEN
            O_NOTE := '[产品名称]' || V_OBJ.CPMC || '不允许为空！';
            RETURN;
        END IF;
        IF V_OBJ.JZRQ IS NULL THEN
            O_NOTE := '[净值日期]' || V_OBJ.JZRQ || '不允许为空！';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_GSMJZ A
         WHERE A.CPDM = V_OBJ.CPDM AND A.CPMC = V_OBJ.CPMC AND A.JZRQ = V_OBJ.JZRQ;
        IF V_COUNT > 1 THEN
            O_NOTE := '[产品代码]:' || V_OBJ.CPDM || '[产品名称]:' || V_OBJ.CPMC || '[净值日期]:' ||
                      V_OBJ.JZRQ || '记录已存在，不允许重复新增！';
            RETURN;
        END IF;
        UPDATE TPIF_GSMJZ SET JYJG = '',JYSM = '' WHERE ID = I_ID;
    END IF;
    IF I_OPER = 2 THEN
        --//:删除
        DELETE FROM TPIF_GSMJZ I WHERE I.ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --批量删除
        V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_ID, ' ', ''), '[', ''), ']', ''),
                         ',',
                         ';');
        DELETE TPIF_GSMJZ WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0;
    END IF;
    IF I_OPER IN (4,5) THEN
        V_C_S := 0;
        V_C_F := 0;
        FOR CUR IN (SELECT * FROM TPIF_GSMJZ WHERE CZR = I_USER) LOOP
            V_JYJG := 1;
            V_JYSM := '';
            --基础校验
            IF CUR.CPDM IS NULL THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[产品代码]不允许为空;';
            END IF;
            IF CUR.CPMC IS NULL THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[产品名称]不允许为空;';
            END IF;
            IF CUR.JZRQ IS NULL THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[净值日期]不允许为空;';
            END IF;
            IF CUR.JZRQ > TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')) THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[净值日期]不能大于当日;';
            END IF;
            IF CUR.DWJZ IS NULL THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[单位净值]不允许为空;';
            END IF;
            IF CUR.DWJZ < 0 THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[单位净值]不允许为负;';
            END IF;
            IF CUR.LJJZ IS NULL THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[累计净值]不允许为空;';
            END IF;
            IF CUR.LJJZ < 0 THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '[累计净值]不允许为负;';
            END IF;
            --拓展校验
            SELECT COUNT(1)
              INTO V_COUNT
              FROM TPIF_GSMJZ
             WHERE CPDM = CUR.CPDM AND CPMC = CUR.CPMC AND JZRQ = CUR.JZRQ AND ID < CUR.ID;
            IF V_COUNT > 0 THEN
                V_JYJG := -1;
                V_JYSM := V_JYSM || '相同[产品+净值日期]数据重复导入;';
            END IF;
            IF CUR.CPID IS NULL THEN
                SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM WHERE CPNBZT = 8 AND CPDM = TRIM(CUR.CPDM);
                IF V_COUNT = 0 THEN
                    V_JYJG := -1;
                    V_JYSM := V_JYSM || '产品代码不存在;';
                ELSE
                    SELECT MAX(ID) INTO V_CPID FROM TPIF_CPDM WHERE CPNBZT = 8 AND CPDM = TRIM(CUR.CPDM);
                END IF;
            ELSE
                V_CPID := CUR.CPID;
            END IF;
            IF V_CPID IS NOT NULL THEN
                SELECT COUNT(1) INTO V_COUNT
                  FROM TPIF_CPJZ
                 WHERE CPID = V_CPID AND JZRQ = CUR.JZRQ AND SJLY = 9 AND QRZT = 1 AND (DWJZ != CUR.DWJZ OR LJJZ != CUR.LJJZ);
                IF V_COUNT > 0 THEN
                    V_JYJG := -1;
                    V_JYSM := V_JYSM || '存在已确认的净值冲突数据;';
                END IF;
                SELECT COUNT(1) INTO V_COUNT
                  FROM TPIF_CPJZ
                 WHERE CPID = V_CPID AND JZRQ = CUR.JZRQ AND SJLY = 9 AND QRZT = 1 AND DWJZ = CUR.DWJZ AND LJJZ = CUR.LJJZ;
                IF V_COUNT > 0 THEN
                    V_JYJG := -1;
                    V_JYSM := V_JYSM || '存在已确认的相同净值数据;';
                END IF;
            END IF;
            --处理校验结果
            UPDATE TPIF_GSMJZ
               SET JYJG = V_JYJG, JYSM = SUBSTR(V_JYSM, 1, LENGTH(V_JYSM) - 1), CPID = V_CPID
             WHERE ID = CUR.ID;
            IF V_JYJG = 1 THEN
                V_C_S := V_C_S + 1;
            ELSE
                V_C_F := V_C_F + 1;
            END IF;
            COMMIT; ----|
        END LOOP;
        V_NOTE := '校验通过(' || V_C_S || ')|异常(' || V_C_F || ')';
    END IF;
    IF I_OPER = 5 THEN
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_GSMJZ WHERE CZR = I_USER AND NVL(JYJG, 0) = 1;
        IF V_COUNT > 0 THEN
            --更新产品净值表
            MERGE INTO TPIF_CPJZ A USING (SELECT * FROM TPIF_GSMJZ WHERE CZR = I_USER AND NVL(JYJG, 0) = 1) B
                  ON (A.CPID = B.CPID AND A.JZRQ = B.JZRQ AND A.SJLY = 9 AND QRZT = 0)
            WHEN MATCHED THEN
                UPDATE
                   SET A.FBR = I_USER,A.CZSJ = SYSDATE,A.DWJZ = B.DWJZ,A.LJJZ = B.LJJZ
            WHEN NOT MATCHED THEN
                INSERT (ID,CPID,JZRQ ,DWJZ ,LJJZ ,FBR ,CZSJ ,SJLY ,QRZT)
                VALUES (livebos.FUNC_NEXTID('TPIF_CPJZ'),B.CPID,B.JZRQ,B.DWJZ,B.LJJZ,I_USER,SYSDATE,9,1);
            UPDATE TPIF_CPJZ A
               SET A.QRZT = 1
             WHERE A.SJLY = 9 AND QRZT = 0 AND EXISTS (SELECT 1 FROM TPIF_GSMJZ B
                             WHERE B.CZR = I_USER AND NVL(B.JYJG, 0) = 1 AND B.CPID = A.CPID AND B.JZRQ = A.JZRQ);
            FOR CUR IN (SELECT * FROM TPIF_GSMJZ WHERE CZR = I_USER AND NVL(JYJG, 0) = 1) LOOP
                SELECT NVL(JZRQ, 0) INTO V_JZRQ FROM TPIF_CPDM WHERE ID = CUR.CPID;
                IF V_JZRQ <= CUR.JZRQ THEN
                    --更新代码表净值信息
                    UPDATE TPIF_CPDM
                       SET JZRQ   = CUR.JZRQ,
                           CPJZ   = CUR.DWJZ,
                           LJJZ   = CUR.LJJZ
                           --ZJWHRQ = TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
                     WHERE ID = CUR.CPID;
                /*ELSE
                    --更新净值维护信息
                    UPDATE TPIF_CPDM
                       SET ZJWHRQ = TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
                     WHERE ID = CUR.CPID;*/
                END IF;
            END LOOP;
            DELETE FROM TPIF_GSMJZ WHERE CZR = I_USER AND NVL(JYJG, 0) = 1;
        END IF;
        V_NOTE := '确认导入(' || V_COUNT || ')';
    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' ||
           DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', 3, '批量删除', 4, V_NOTE, 5, V_NOTE) || ']成功!'
      INTO O_NOTE
      FROM DUAL;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_GSMJZ;
/

