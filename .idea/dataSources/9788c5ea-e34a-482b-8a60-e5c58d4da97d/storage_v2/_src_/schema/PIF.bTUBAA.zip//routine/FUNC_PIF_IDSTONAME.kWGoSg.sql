create FUNCTION FUNC_PIF_IDSTONAME(I_IDS  IN VARCHAR2, --产品ID
                                              I_TYPE IN NUMBER --1|产品，2|机构
                                              ) RETURN STRING IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：产品机构id串转换名称串

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        HANQN     1.0.0      2021/09/27                新增
  --------------------------------------------------------------------------------*/
  V_MCS   VARCHAR(5000); --返回名称串
  V_COUNT NUMBER; --计数
  V_COUNT_1 NUMBER; --计数1
  V_IDS   VARCHAR2(5000);
  V_NUM   NUMBER := 1;
  V_ID    NUMBER;
  V_MC    VARCHAR2(200);
  V_XZQD  NUMBER;
  V_LEN   NUMBER; --长度
BEGIN

  --变量初始化
  V_IDS := ';' || I_IDS || ';';

  --获取ID数量
  SELECT LENGTH(V_IDS) - LENGTH(REPLACE(V_IDS, ';')) - 1
    INTO V_COUNT_1
    FROM DUAL;

  --产品id串转换
  IF I_TYPE = 1 THEN
    WHILE V_NUM <= V_COUNT_1 LOOP
      SELECT INSTR(V_IDS, ';', 1, V_NUM + 1) - INSTR(V_IDS, ';', 1, V_NUM) - 1
        INTO V_LEN
        FROM DUAL;

      SELECT TO_NUMBER(SUBSTR(V_IDS, INSTR(V_IDS, ';', 1, V_NUM) + 1, V_LEN))
        INTO V_ID
        FROM DUAL;

      SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM WHERE CPID = V_ID;

      --获取产品名称
      IF V_COUNT > 0 THEN
        SELECT '['||CPDM||']'||CPMC INTO V_MC FROM TPIF_CPDM WHERE CPID = V_ID;
      ELSE
        V_MC := TO_CHAR(V_ID);
      END IF;

      --拼接名称串
      IF V_NUM = 1 THEN
        V_MCS := V_MC;
      ELSE
        V_MCS := V_MCS || ';' || V_MC;
      END IF;

      V_NUM := V_NUM + 1;
    END LOOP;
  END IF;

  --机构id串转换
  IF I_TYPE = 2 THEN
    WHILE V_NUM <= V_COUNT_1 LOOP
      SELECT INSTR(V_IDS, ';', 1, V_NUM + 1) - INSTR(V_IDS, ';', 1, V_NUM) - 1
        INTO V_LEN
        FROM DUAL;

      SELECT TO_NUMBER(SUBSTR(V_IDS, INSTR(V_IDS, ';', 1, V_NUM) + 1, V_LEN))
        INTO V_ID
        FROM DUAL;

      SELECT COUNT(1) INTO V_COUNT FROM TPIF_JGDM WHERE ID = V_ID;

      --获取产品名称
      IF V_COUNT > 0 THEN
        SELECT JGMC INTO V_MC FROM TPIF_JGDM WHERE ID = V_ID;
      ELSE
        V_MC := TO_CHAR(V_ID);
      END IF;

      --拼接名称串
      IF V_NUM = 1 THEN
        V_MCS := V_MC;
      ELSE
        V_MCS := V_MCS || ';' || V_MC;
      END IF;

      V_NUM := V_NUM + 1;
    END LOOP;
  END IF;
  RETURN V_MCS;
EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;
/

