create PROCEDURE PCX_PIF_CPDB_QJSY(O_CODE             OUT NUMBER,
                                              O_NOTE             OUT VARCHAR2,
                                              O_RESULT           OUT SYS_REFCURSOR,
                                              I_STATISTIC_PERIOD IN VARCHAR2, --统计周期 
                                              I_PROD_IDS         IN VARCHAR2, --产品ID串
                                              I_INDEX_NAME       IN VARCHAR2 --指数
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品对比-区间收益走势
  所属用户：PIF
  概要说明：查询对比产品的区间收益走势.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
      
      输入参数：
          I_STATISTIC_PERIOD    统计周期         1
          I_PROD_IDS            产品ID串       936263;939406;902610
          I_INDEX_NAME          要对比的指数     1
  
  功能修订：
      简要说明：
        查询产品对比结果列表.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/05/08     1.0.0    TUMENG             新增
      2021/09/09     1.0.1    GAOKUN          修改,根据净值计算区间收益，支持选指数
  /*****************************************************************************/
  V_SQL VARCHAR2(32767);

  V_RQ      NUMBER(8); --起始日期
  V_ZS_JSPJ NUMBER; --指数起始今收盘价
  V_ZSDM    VARCHAR2(100); --指数代码

  V_DWJZ NUMBER; --起始单位净值
  V_LJJZ NUMBER; --起始累计净值
  V_JZRQ NUMBER; --起始净值日期

  V_CPDM       VARCHAR2(200);
  V_CPJC       VARCHAR2(200);
  V_CPID       VARCHAR2(100); --当前处理的产品ID
  V_CPIDS_REST VARCHAR2(1000); --剩余产品ID

  V_POSITION NUMBER(8); -- ';'第一分号所在位置
  V_COUNT    NUMBER;
  V_PROD_IDS VARCHAR2(1000) := I_PROD_IDS;
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_IDS IS NULL THEN
    O_NOTE := '入参 I_PROD_IDS 不能为空！';
    RETURN;
  END IF;

  IF I_STATISTIC_PERIOD IS NULL THEN
    O_NOTE := '入参 I_STATISTIC_PERIOD 不能为空！';
    RETURN;
  END IF;

  IF I_INDEX_NAME IS NULL THEN
    O_NOTE := '入参 I_INDEX_NAME 不能为空！';
    RETURN;
  END IF;

  IF I_INDEX_NAME = 1 THEN
    --万得全A
    V_ZSDM := '881001.WI';
  ELSIF I_INDEX_NAME = 2 THEN
    --沪深300
    V_ZSDM := '000300.SH';
  ELSIF I_INDEX_NAME = 3 THEN
    --中证500
    V_ZSDM := '000905.SH';
  ELSIF I_INDEX_NAME = 4 THEN
    --中证800  暂无
    V_ZSDM := '000906.SH';
  ELSIF I_INDEX_NAME = 5 THEN
    --国债指数
    V_ZSDM := '000012.SH';
  END IF;

  --第一个分号位置
  SELECT INSTR(V_PROD_IDS, ';', 1, 1) INTO V_POSITION FROM DUAL;

  --要处理的CPID
  SELECT SUBSTR(V_PROD_IDS, 1, V_POSITION - 1) INTO V_CPID FROM DUAL;

  --剩余CPIDS
  SELECT SUBSTR(V_PROD_IDS, V_POSITION + 1) INTO V_CPIDS_REST FROM DUAL;

  --返回结果
  /*  PROD_ID 产品ID
      PROD_CODE 产品代码
      PROD_NAME 产品名称
      NAV_DATE  日期
      PERIOD_YIELD_RATIO  区间收益率
  */

  --处理日期，获取开始日期
  --1|近3月
  IF I_STATISTIC_PERIOD = 1 THEN
    SELECT JYR --获取开始日期
      INTO V_RQ
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -3),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
    --2|近6月       
  ELSIF I_STATISTIC_PERIOD = 2 THEN
    SELECT JYR
      INTO V_RQ
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -6),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
    --3|近1年 
  ELSIF I_STATISTIC_PERIOD = 3 THEN
    SELECT JYR
      INTO V_RQ
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -12),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
    --4|近3年 
  ELSIF I_STATISTIC_PERIOD = 4 THEN
    SELECT JYR
      INTO V_RQ
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -36),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
    --5|近5年       
  ELSIF I_STATISTIC_PERIOD = 5 THEN
    SELECT JYR
      INTO V_RQ
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -60),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
  END IF;

  BEGIN
    --获取开始日期的指数 今收盘价
    SELECT JSPJ
      INTO V_ZS_JSPJ
      FROM DSC_STAT.TPIF_STAT_ZSHQ
     WHERE SJRQ = V_RQ
       AND ZSDM = V_ZSDM;
  
    --指数
    V_SQL := 'SELECT 99999999 AS PROD_ID,--产品ID
            ''' || V_ZSDM || ''' AS PROD_CODE, --产品代码
             ZSMC AS PROD_NAME, --产品名称
             SJRQ AS NAV_DATE, --日期
             (CASE
               WHEN ' || V_ZS_JSPJ || ' IS NULL THEN NULL 
               WHEN ' || V_ZS_JSPJ ||
             ' = 0 THEN NULL
               ELSE TO_CHAR(((JSPJ - ' || V_ZS_JSPJ || ' ) / ' ||
             V_ZS_JSPJ || ')*100 , ''FM9990.00'')
             END) AS PERIOD_YIELD_RATIO --区间收益率
        FROM DSC_STAT.TPIF_STAT_ZSHQ
       WHERE ZSDM = ''' || V_ZSDM || ''' AND SJRQ >= ' || V_RQ;
  
    --如果没有获取到指数的今收盘价，则会进入该异常，
    --正常情况下是不可能进入该异常的，因为指数的收盘价按说每个交易日都有，只要交易日取对了，肯定有值
  EXCEPTION
    WHEN OTHERS THEN
      V_SQL := V_SQL || '        SELECT 99999999 AS PROD_ID,
               NULL     AS PROD_CODE,
               NULL     AS PROD_NAME,
               NULL     AS NAV_DATE,
               NULL     AS PERIOD_YIELD_RATIO
        FROM DUAL';
  END;

  --产品
  --循环处理CPID
  WHILE V_CPID IS NOT NULL AND LENGTH(V_CPID) > 0 LOOP
    SELECT COUNT(1) --判断是否是公募
      INTO V_COUNT
      FROM TPIF_CPDM
     WHERE CPID = V_CPID
       AND SJLY = 1;
  
    SELECT CPDM, CPJC --获取产品代码、产品简称
      INTO V_CPDM, V_CPJC
      FROM TPIF_CPDM
     WHERE CPID = V_CPID;
  
    IF V_COUNT = 1 THEN
      --公募取聚源
      BEGIN
        --为了避免开始日期没数据，取大于等于这一天的数据
        SELECT UNITNV,
               ACCUMULATEDUNITNV,
               TO_NUMBER(TO_CHAR(ENDDATE, 'YYYYMMDD'))
          INTO V_DWJZ, V_LJJZ, V_JZRQ
          FROM INFO.TINFO_JJJZ
         WHERE SECUCODE = V_CPDM
           AND ENDDATE =
               (SELECT MIN(T.ENDDATE)
                  FROM INFO.TINFO_JJJZ T
                 WHERE T.SECUCODE = V_CPDM
                   AND TO_CHAR(T.ENDDATE, 'YYYYMMDD') >= V_RQ);
      
        V_SQL := V_SQL || '
        UNION 
        SELECT ' || V_CPID || ' AS PROD_ID,
        SECUCODE AS PROD_CODE, 
        '' ' || V_CPJC || ' '' AS PROD_NAME,
        TO_NUMBER(TO_CHAR(ENDDATE, ''YYYYMMDD'')) AS NAV_DATE,
        (CASE 
        WHEN ' || V_DWJZ || ' IS NULL THEN NULL
        WHEN ' || V_DWJZ ||
                 ' = 0 THEN NULL
        ELSE TO_CHAR(((ACCUMULATEDUNITNV - ' || V_LJJZ ||
                 ' )/ ' || V_DWJZ ||
                 ')*100 ,''FM9990.00'') END ) AS PERIOD_YIELD_RATIO
        FROM INFO.TINFO_JJJZ WHERE SECUCODE= ''' ||
                 V_CPDM || '''
        AND TO_CHAR(ENDDATE, ''YYYYMMDD'') >=' || V_JZRQ;
      
        --如果上面SELECT INTO未取到数据，则会报错，则进入该部分，
        --没取到数据说明净值表没该产品净值，则直接往下走
      EXCEPTION
        WHEN OTHERS THEN
          V_SQL := V_SQL || '';
      END;
    
    ELSIF V_COUNT = 0 THEN
      --私募取柜台
      BEGIN
        --为了避免开始日期没数据，取大于等于这一天的数据
        SELECT DWJZ, LJJZ, JZRQ
          INTO V_DWJZ, V_LJJZ, V_JZRQ
          FROM PIF.TPIF_CPJZXX_CPZX
         WHERE CPID = V_CPID
           AND JZRQ = (SELECT MIN(T.JZRQ)
                         FROM PIF.TPIF_CPJZXX_CPZX T
                        WHERE T.CPID = V_CPID
                          AND T.JZRQ >= V_RQ);
      
        V_SQL := V_SQL || '
        UNION 
        SELECT CPID AS PROD_ID,
        CPDM AS PROD_CODE, 
        '' ' || V_CPJC || ' '' AS PROD_NAME,
        JZRQ AS NAV_DATE,
        (CASE 
        WHEN ' || V_DWJZ || ' IS NULL THEN NULL
        WHEN ' || V_DWJZ || ' = 0 THEN NULL
        ELSE TO_CHAR(((LJJZ - ' || V_LJJZ || ' )/ ' ||
                 V_DWJZ ||
                 ')*100 ,''FM9990.00'') END ) AS PERIOD_YIELD_RATIO
        FROM PIF.TPIF_CPJZXX_CPZX WHERE CPID= ''' ||
                 V_CPID || '''
        AND JZRQ >=' || V_JZRQ;
      
        --如果上面SELECT INTO未取到数据，则会报错，则进入该部分，
        --没取到数据说明净值表没该产品净值，则直接往下走
      EXCEPTION
        WHEN OTHERS THEN
          V_SQL := V_SQL || '';
      END;
    
    END IF;
  
    --取剩余CPID串的第一个分号位置
    SELECT INSTR(V_CPIDS_REST, ';', 1, 1) INTO V_POSITION FROM DUAL;
  
    --如果只剩一个产品ID，则位置为0
    IF V_POSITION = 0 THEN
      V_CPID       := V_CPIDS_REST;
      V_CPIDS_REST := '';
    ELSE
      --取下一个要处理的CPID
      SELECT SUBSTR(V_CPIDS_REST, 1, V_POSITION - 1) INTO V_CPID FROM DUAL;
    
      --更新剩余待处理产品串
      SELECT SUBSTR(V_CPIDS_REST, V_POSITION + 1)
        INTO V_CPIDS_REST
        FROM DUAL;
    END IF;
  
  END LOOP;

  --排序
  V_SQL := V_SQL || ' ORDER BY PROD_ID DESC,NAV_DATE ASC';

  --DBMS_OUTPUT.PUT_LINE(V_SQL);
  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END;
/

