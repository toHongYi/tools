create PROCEDURE PCX_PIF_CPST_CPBQMX(O_CODE     OUT NUMBER,
                                                    O_NOTE     OUT VARCHAR2,
                                                    O_RESULT   OUT SYS_REFCURSOR,
                                                    I_CURRENT  IN NUMBER, --页码   
                                                    I_PAGESIZE IN NUMBER, --页长 
                                                    I_PAGING   IN NUMBER, --是否分页 
                                                    I_SORT     IN VARCHAR2, --排序规模 
                                                    I_TOTAL    IN OUT NUMBER, --记录总数
                                                    I_LABLE_ID IN NUMBER --标签ID  
                                                    
                                                    ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品视图-产品标签明细查询
  
      语法信息：
           输入参数：     I_CURRENT  IN NUMBER, --页码   
                          I_PAGESIZE IN NUMBER, --页长 
                          I_PAGING   IN NUMBER, --是否分页 
                          I_SORT     IN VARCHAR2, --排序规模 
                          I_TOTAL    IN OUT NUMBER --记录总数  
                          I_QUERY_DATE IN VARCHAR2, --查询日期
                          I_LABLE_ID   IN NUMBER --标签ID 
           输出参数：   O_RESULT
      逻辑说明：
           1、
      ----------------------------------------------------------
      操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
  ***********************************************************************/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;

BEGIN

  IF I_LABLE_ID IS NULL THEN
  
    O_CODE := -1;
    O_NOTE := '入参【I_LABLE_ID】不允许为空';
    RETURN;
  
  END IF;

  --否则返回结果集合
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  V_SQL := 'SELECT A.ID AS PROD_ID ,--产品ID
                   A.CPDM AS PROD_CODE,-- 产品代码
                   A.CPMC AS  PROD_NAME,--产品名称
                   (SELECT NAME FROM TPIF_JRCPFL WHERE ID=A.JRCPFL) AS PROD_TYPE,--产品类型
                   (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_JZJYCPZT'' AND IBM=A.CPJYZT) AS PROD_STATUS,--产品状态
                   (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=A.CPFXDJ) AS PROD_RISK_LEVEL，--产品风险等级
                    A.QTJE||''元'' AS SUBSCRIBE_ORIGIN,--认购起点(元)
                    A.YQSYL*100 AS EXPECTED_YIELD_RATE ,--预期收益率
                    A.CLRQ AS ESTABLISH_DATE, 
                    A.DQRQ AS EXPIRE_DATE, 
                    (CASE WHEN A.CPQX=''0'' THEN ''无固定期限'' 
                          WHEN trim(A.CPQX) is null THEN ''无固定期限'' 
                    else A.CPQX||''天'' end) AS PROD_TERM,
                    ( SELECT WM_CONCAT(M.MC) FROM TPIF_CPBQ M,TPIF_CPBQMX N WHERE M.ID = N.CPBQ AND N.CPID = A.ID ) AS PROD_HAVE_LABELS,--产品拥有标签
                    TO_CHAR(C.JYYSYL,''FM9990.0000'')    AS YIELD_RATE_MONTH ,--近1月收益率
                    TO_CHAR(C.JSYSYL,''FM9990.0000'')  AS YIELD_RATE_QUARTER ,--近3月收益率
                    TO_CHAR(C.JLYSYL,''FM9990.0000'') AS YIELD_RATE_HALFYEAR ,--近6月收益率
                    TO_CHAR(C.JYNSYL,''FM9990.0000'') AS YIELD_RATE_ONE_YEAR  --近1年收益率
             FROM  PIF.TPIF_CPDM A,
                   PIF.TPIF_CPBQMX B,
                   PIF.TPIF_CPJZ_YSZB C
             WHERE A.ID = B.CPID
               AND B.CPBQ =  '||I_LABLE_ID||'
               AND B.CPID = C.CPID(+)';
               
  delete from test_para;
  insert into   test_para(PARAM_VALES) values(V_SQL);
  commit ;
               

  IF V_SORT IS NULL THEN
    V_SORT := 'PROD_ID DESC';
  END IF;
  V_COLLIST := 'PROD_ID,PROD_CODE,PROD_NAME,PROD_TYPE,PROD_STATUS,PROD_RISK_LEVEL,SUBSCRIBE_ORIGIN,EXPECTED_YIELD_RATE,ESTABLISH_DATE,EXPIRE_DATE,PROD_TERM,PROD_HAVE_LABELS,YIELD_RATE_MONTH,YIELD_RATE_QUARTER,YIELD_RATE_HALFYEAR,YIELD_RATE_ONE_YEAR';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

