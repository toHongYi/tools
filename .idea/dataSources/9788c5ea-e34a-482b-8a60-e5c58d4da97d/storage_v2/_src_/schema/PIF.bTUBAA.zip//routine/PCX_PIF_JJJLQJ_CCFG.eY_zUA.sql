create PROCEDURE     PCX_PIF_JJJLQJ_CCFG(O_CODE   OUT NUMBER, --返回值
                                                O_NOTE   OUT VARCHAR2, --返回信息
                                                O_RESULT OUT SYS_REFCURSOR, --返回的数据集合
                                                I_USERID     IN NUMBER, --登陆用户ID，预留，便于后面文档查询的权限控制
                                                I_MANAGER_ID IN NUMBER --基金经理ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-基金经理全景-持仓风格
  所属用户：PIF
  概要说明：查询基金经理的持仓风格

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
       输入参数：
          I_USERID        登陆用户ID，预留，便于后面文档查询的权限控制
          I_MANAGER_ID    基金经理ID

  运行原理：


  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/06     1.0.0     杨啸天             新增.
  *****************************************************************************/
  --V_SQL VARCHAR2(32767);   --写SQL备用
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';
  --条件检验
  IF I_MANAGER_ID IS NULL THEN
    O_NOTE := '产品经理ID不允许为空！';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
    SELECT CCFG  POSITION_STYLE, --持仓风格
           JJSL  POSITION_FUNDNUM, --持仓基金数量
           ZZCGM POSITION_FUNDSIZE --持仓基金总资产规模
      FROM DSC_STAT.TPIF_STAT_JJJL_CCFG A
     WHERE A.JJJLID = I_MANAGER_ID;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;

END PCX_PIF_JJJLQJ_CCFG;
/

