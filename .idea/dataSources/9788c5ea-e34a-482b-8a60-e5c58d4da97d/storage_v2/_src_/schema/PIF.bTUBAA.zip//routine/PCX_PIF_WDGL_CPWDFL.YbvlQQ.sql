create PROCEDURE PCX_PIF_WDGL_CPWDFL(O_CODE   OUT NUMBER,
                                                    O_NOTE   OUT VARCHAR2,
                                                    O_RESULT OUT SYS_REFCURSOR,
                                                    I_TYPE   IN  NUMBER    --1:产品；2:机构;3:所有
) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：产品中心

           功能说明：文档管理-产品文档分类
               参数说明：
                    入参：
                          I_USERID   IN  NUMBER     --登陆用户ID

                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,
                          O_RESULT OUT   SYS_REFCURSOR,



          ----------------------------------------------------------
          操作人       版本号      时间                        操作
          wujinfeng    1.0        2020/06/29                  新增
    -------------------------------------------------------------------------------------------------*/
    --V_SQL VARCHAR2(4000);

BEGIN
    O_CODE := 1;
    O_NOTE := '成功!';

    IF I_TYPE IS NULL  THEN
        O_CODE := -1;
        O_NOTE := 'I_TYPE不能为空!';
        RETURN;
    END IF;
    --1:产品
    if I_TYPE = 1 then
          OPEN O_RESULT FOR
                 select  id,
                /*(case when fid=1 then -1 else fid end) as*/ fid,
                name,
                fdncode,
                Grade jdjb ,
                Type jdlx
        from tPIF_CPWDFL
        WHERE WDLX=1 AND GRADE >0;


    --2:机构;3:所有
    elsif I_TYPE = 2 then
         OPEN O_RESULT FOR
                select  id,
                /*(case when fid=1 then -1 else fid end) as*/ fid,
                name,
                fdncode,
                Grade jdjb ,
                Type jdlx
        from tPIF_CPWDFL
        WHERE WDLX=2 AND GRADE>0;
    else
         OPEN O_RESULT FOR
                select  id,
                /*(case when fid=1 then -1 else fid end) as*/ fid,
                name,
                fdncode,
                Grade jdjb ,
                Type jdlx
        from tPIF_CPWDFL
        /*where id > 1*/ ;
    end if;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        OPEN O_RESULT FOR
            SELECT O_NOTE FROM DUAL;

END ;
/

