create PROCEDURE PRO_PIF_CPPJ(O_CODE            OUT NUMBER, --返回值
                                         O_NOTE            OUT VARCHAR2, --返回消息
                                         I_PROD_ID         IN NUMBER, --产品ID
                                         I_TEMPLATE_ID     IN NUMBER, --评价模版ID
                                         I_TEMPLATE_RESULT IN VARCHAR2, --评价结果
                                         I_SCORES          IN NUMBER, --总分
                                         I_USERID          IN NUMBER --登陆用户ID
                                         
                                         ) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品评价结果提交
      语法信息：
           输入参数： I_PROD_ID       IN NUMBER , --产品ID
                     I_TEMPLATE_ID   IN NUMBER , --评价模版ID
                     I_TEMPLATE_RESULT  IN VARCHAR2 ,--评价结果
                     I_USERID      IN NUMBER --登陆用户ID
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-10-12     V1.0     WUJINFENG              新增
  ***********************************************************************/
  V_ID                   NUMBER;
  V_JGMX_ID              NUMBER;
  V_SEQNO                NUMBER;
  V_SCORES               NUMBER;
  V_EVALUATION_INDEX_VAL NUMBER;

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF I_TEMPLATE_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_TEMPLATE_ID 不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_ID 不允许为空！';
    RETURN;
  END IF;

  IF I_TEMPLATE_RESULT IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_TEMPLATE_RESULT 不允许为空！';
    RETURN;
  END IF;
  LIVEBOS.PNEXTID('TPIF_CPPJJG', V_ID);
  INSERT INTO PIF.TPIF_CPPJJG
    (ID,
     MBID,
     CPID,
     CPMC,
     ZF,
     ZDYJ,
     HZFW,
     FXPJ,
     PJXJ,
     PGR,
     PGRQ,
     PGSJ)
    SELECT V_ID,
           I_TEMPLATE_ID,
           I_PROD_ID,
           (SELECT '【'||CP.CPDM||'】'||CP.CPMC FROM TPIF_CPDM CP WHERE CP.ID = I_PROD_ID),
           I_SCORES,
           A.ZDYJ,
           A.HZFW,
           A.FXPJ,
           A.PJXJ,
           I_USERID,
           TO_CHAR(SYSDATE, 'YYYYMMDD'),
           SYSDATE
      FROM TPIF_CPPJPPSZ A
     WHERE A.PJMB = I_TEMPLATE_ID
       AND A.PFXX <= I_SCORES
       AND A.PFSX >= I_SCORES
       AND ROWNUM < 2;

  ---结果明细表
  --TPIF_CPPJJG_JGMX
  FOR CUR_JSON IN (SELECT COLUMN_VALUE AS JSON
                     FROM TABLE(SPLIT(replace(replace(RTRIM(I_TEMPLATE_RESULT, ','),'[',''),']',''), '}'))
                    WHERE COLUMN_VALUE IS NOT NULL) LOOP
  
    SELECT PARSEJSON(CUR_JSON.JSON, 'seqno'),
           PARSEJSON(CUR_JSON.JSON, 'scores'),
           PARSEJSON(CUR_JSON.JSON, 'evaluationIndexVal')
           
           
           --[{"seqno":"1","evaluationIndexVal":"","scores":90},
           --{"seqno":"2","evaluationIndexVal":"","scores":30},
           --{"seqno":"3","evaluationIndexVal":"","scores":30},
           --{"seqno":"4","evaluationIndexVal":"","scores":30},
           --{"seqno":"5","evaluationIndexVal":"","scores":30}]
           
    
      INTO V_SEQNO, V_SCORES, V_EVALUATION_INDEX_VAL
      FROM DUAL;
  
    LIVEBOS.PNEXTID('TPIF_CPPJJG_JGMX', V_JGMX_ID);
    INSERT INTO TPIF_CPPJJG_JGMX
      (TPIF_CPPJJG_ID, ID, BH, PJWD, QZ, ZBZ, DF)
      SELECT V_ID,
             V_JGMX_ID,
             V_SEQNO,
             A.PJWD,
             A.QZ,
             V_EVALUATION_INDEX_VAL,
             V_SCORES
        FROM TPIF_CPPJMB_TM A
       WHERE A.TPIF_CPPJMB_ID = I_TEMPLATE_ID
         AND A.BH = V_SEQNO;
  
  END LOOP;

  COMMIT;

  O_CODE := 1;
  O_NOTE := '产品评价结果提交成功!';

EXCEPTION
  WHEN OTHERS THEN
  
    ROLLBACK;
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

