create PROCEDURE PRO_SJQX_JJJZ_HD(O_CODE OUT NUMBER,
                                             O_NOTE OUT VARCHAR2) AS

  /******************************************************************
      所属用户：PIF
      功能说明：对于没有和聚源基金概况表匹配到的公募产品(主要是后端，后收费产品)，
                复制相关净值信息
                
                使用序列SEQ_TPIF_CPJZ_HD来自动生成ID,ID用负值来区分
                
                清洗过程放到聚源公募这些数据的采集之后，
                PRO_SJQX_GMJJFXPJ、 PRO_SJQX_GMJJSYYGM、 PRO_SJQX_GMJJYJZS、
                P_TRAN_TPIF_CPJZ_YSZB之前
                
                涉及内容：公司产品库净值和下面的关联展示TAB页、产品筛选页面、
                          产品对比页面、H5页面与净值、收益、指标等有关等接口
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-11-29     1.0.0      GAOKUN                创建
  ***********************************************************************/
  V_COUNT NUMBER;

BEGIN

  O_CODE := -1;
  O_NOTE := '';

  --1.基金净值表 INFO.TINFO_JJJZ---------P_TRAN_JJJZ
  DELETE FROM INFO.TINFO_JJJZ WHERE ID < 0;
  INSERT INTO INFO.TINFO_JJJZ
    (ID,
     INNERCODE,
     INFOPUBLDATE,
     INFOSOURCE,
     ENDDATE,
     NV,
     UNITNV,
     ACCUMULATEDUNITNV,
     DAILYPROFIT,
     LATESTWEEKLYYIELD,
     NVDAILYGROWTHRATE,
     NVWEEKLYGROWTHRATE,
     DISCOUNTRATIO,
     XGRQ,
     JSID,
     INVOLVEDDAYS,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INFOPUBLDATE,
           A.INFOSOURCE,
           A.ENDDATE,
           A.NV,
           A.UNITNV,
           A.ACCUMULATEDUNITNV,
           A.DAILYPROFIT,
           A.LATESTWEEKLYYIELD,
           A.NVDAILYGROWTHRATE,
           A.NVWEEKLYGROWTHRATE,
           A.DISCOUNTRATIO,
           A.XGRQ,
           A.JSID,
           A.INVOLVEDDAYS,
           C.CPDM --该产品的后端代码
      FROM INFO.TINFO_JJJZ A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --2.基金净值最新表现 INFO.TINFO_JJJZZXBX---------P_TRAN_JJJZZXBX
  DELETE FROM INFO.TINFO_JJJZZXBX WHERE ID < 0;
  INSERT INTO INFO.TINFO_JJJZZXBX
    (ID,
     INNERCODE,
     TRADINGDAY,
     UNITNV,
     RRINSELECTEDWEEK,
     RRINSINGLEWEEK,
     RRINSELECTEDMONTH,
     RRINSINGLEMONTH,
     RRINTHREEMONTH,
     RRINSIXMONTH,
     RRSINCETHISYEAR,
     RRINSINGLEYEAR,
     RRINTWOYEAR,
     ANNUALIZEDRRINTWOYEAR,
     RRINTHREEYEAR,
     ANNUALIZEDRRINTHREEYEAR,
     RRINFIVEYEAR,
     ANNUALIZEDRRINFIVEYEAR,
     RRINTENYEAR,
     ANNUALIZEDRRINTENYEAR,
     RRSINCESTART,
     ANNUALIZEDRRSINCESTART,
     UPDATETIME,
     JSID,
     NVDAILYGROWTHRATE,
     RRSINCESTARTII,
     ACCUMULATEDUNITNV,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.TRADINGDAY,
           A.UNITNV,
           A.RRINSELECTEDWEEK,
           A.RRINSINGLEWEEK,
           A.RRINSELECTEDMONTH,
           A.RRINSINGLEMONTH,
           A.RRINTHREEMONTH,
           A.RRINSIXMONTH,
           A.RRSINCETHISYEAR,
           A.RRINSINGLEYEAR,
           A.RRINTWOYEAR,
           A.ANNUALIZEDRRINTWOYEAR,
           A.RRINTHREEYEAR,
           A.ANNUALIZEDRRINTHREEYEAR,
           A.RRINFIVEYEAR,
           A.ANNUALIZEDRRINFIVEYEAR,
           A.RRINTENYEAR,
           A.ANNUALIZEDRRINTENYEAR,
           A.RRSINCESTART,
           A.ANNUALIZEDRRSINCESTART,
           A.UPDATETIME,
           A.JSID,
           A.NVDAILYGROWTHRATE,
           A.RRSINCESTARTII,
           A.ACCUMULATEDUNITNV,
           C.CPDM
      FROM INFO.TINFO_JJJZZXBX A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --3.公募基金货币型基金收益表现 INFO.TINFO_HBJJSYBX------------P_TRAN_HBJJSYBX
  DELETE FROM INFO.TINFO_HBJJSYBX WHERE ID < 0;
  INSERT INTO INFO.TINFO_HBJJSYBX
    (ID,
     INNERCODE,
     TRADINGDAY,
     UNITNV,
     ACCUMULATEDUNITNV,
     DAILYPROFIT,
     LATESTWEEKLYYIELD,
     INVOLVEDDAYS,
     ANNUALIZEDRRINSINGLEWEEK,
     ANNUALIZEDRRINTWOWEEK,
     ANNUALIZEDRRINTHREEWEEK,
     ANNUALIZEDRRINFOURWEEK,
     ANNUALIZEDRRINFIVEWEEK,
     RRINTHISWEEK,
     RRINSINGLEWEEK,
     RRINTHISMONTH,
     RRINSINGLEMONTH,
     RRINTHREEMONTH,
     RRINSIXMONTH,
     RRSINCETHISYEAR,
     RRINSINGLEYEAR,
     RRINTWOYEAR,
     ANNUALIZEDRRINTWOYEAR,
     RRINTHREEYEAR,
     ANNUALIZEDRRINTHREEYEAR,
     RRINFIVEYEAR,
     ANNUALIZEDRRINFIVEYEAR,
     RRINTENYEAR,
     ANNUALIZEDRRINTENYEAR,
     RRSINCESTART,
     ANNUALIZEDRRSINCESTART,
     UPDATETIME,
     JSID,
     DAILYPROFIT1,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.TRADINGDAY,
           A.UNITNV,
           A.ACCUMULATEDUNITNV,
           A.DAILYPROFIT,
           A.LATESTWEEKLYYIELD,
           A.INVOLVEDDAYS,
           A.ANNUALIZEDRRINSINGLEWEEK,
           A.ANNUALIZEDRRINTWOWEEK,
           A.ANNUALIZEDRRINTHREEWEEK,
           A.ANNUALIZEDRRINFOURWEEK,
           A.ANNUALIZEDRRINFIVEWEEK,
           A.RRINTHISWEEK,
           A.RRINSINGLEWEEK,
           A.RRINTHISMONTH,
           A.RRINSINGLEMONTH,
           A.RRINTHREEMONTH,
           A.RRINSIXMONTH,
           A.RRSINCETHISYEAR,
           A.RRINSINGLEYEAR,
           A.RRINTWOYEAR,
           A.ANNUALIZEDRRINTWOYEAR,
           A.RRINTHREEYEAR,
           A.ANNUALIZEDRRINTHREEYEAR,
           A.RRINFIVEYEAR,
           A.ANNUALIZEDRRINFIVEYEAR,
           A.RRINTENYEAR,
           A.ANNUALIZEDRRINTENYEAR,
           A.RRSINCESTART,
           A.ANNUALIZEDRRSINCESTART,
           A.UPDATETIME,
           A.JSID,
           A.DAILYPROFIT1,
           C.CPDM
      FROM INFO.TINFO_HBJJSYBX A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --4.公募基金波动率  INFO.TINFO_GMJJBDL--------P_TRAN_GMJJBDL
  DELETE FROM INFO.TINFO_GMJJBDL WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJBDL
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJBDL A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --5.公募基金最大回撤  INFO.TINFO_GMJJZDHC-----------P_TRAN_GMJJZDHC
  DELETE FROM INFO.TINFO_GMJJZDHC WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJZDHC
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJZDHC A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --6.公募基金夏普比率  INFO.TINFO_GMJJXPBL------------P_TRAN_GMJJXPBL
  DELETE FROM INFO.TINFO_GMJJXPBL WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJXPBL
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJXPBL A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --7.公募基金索提诺比率 INFO.TINFO_GMJJSTNBL-------------P_TRAN_GMJJSTNBL    
  DELETE FROM INFO.TINFO_GMJJSTNBL WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJSTNBL
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJSTNBL A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --8.公募基金卡玛比率 INFO.TINFO_GMJJKMBL---------------P_TRAN_GMJJKMBL
  DELETE FROM INFO.TINFO_GMJJKMBL WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJKMBL
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJKMBL A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --9.公募基金贝塔系数 INFO.TINFO_GMJJBETA-----------P_TRAN_GMJJBETA     
  DELETE FROM INFO.TINFO_GMJJBETA WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJBETA
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJBETA A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --10.公募基金信息比率 INFO.TINFO_GMJJXXBL--------P_TRAN_GMJJXXBL
  DELETE FROM INFO.TINFO_GMJJXXBL WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJXXBL
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJXXBL A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --11.公募基金阿尔法系数 INFO.TINFO_GMJJALPHA------------P_TRAN_GMJJALPHA   
  DELETE FROM INFO.TINFO_GMJJALPHA WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJALPHA
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     DATAVALUE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.DATAVALUE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJALPHA A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  --12.产品最新净值表  PIF.TPIF_CPZXJZ--PRO_SJQX_CPJZ、PRO_SJQX_MF_NETVALUE_LATEST
  DELETE FROM TPIF_CPZXJZ
   WHERE ID < 0
      OR CPID IN (SELECT CPID
                    FROM TPIF_CPDM
                   WHERE CPXL = 1
                     AND SJLY = 1
                     AND SJYID IS NULL); --避免产品最新净值表重复而报错
  INSERT INTO TPIF_CPZXJZ
    (ID,
     CPID,
     JYRQ,
     JZRQ,
     ZCZZ,
     ZCJZ,
     DWJZ,
     LJJZ,
     FQJZ,
     NHSYL,
     WFSYL,
     RZF,
     ZZF,
     NHSYL_D7,
     SJLY,
     QRZT,
     FBR,
     CZSJ,
     CPDM)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           D.CPID, --后端产品CPID
           A.JYRQ,
           A.JZRQ,
           A.ZCZZ,
           A.ZCJZ,
           A.DWJZ,
           A.LJJZ,
           A.FQJZ,
           A.NHSYL,
           A.WFSYL,
           A.RZF,
           A.ZZF,
           A.NHSYL_D7,
           A.SJLY,
           A.QRZT,
           A.FBR,
           A.CZSJ,
           D.CPDM --后端产品代码
      FROM TPIF_CPZXJZ A, TPIF_CPDM B, INFO.TINFO_JJGK C, TPIF_CPDM D
     WHERE A.CPID = B.CPID
       AND B.CPDM = C.SECUCODE --B表取前端产品的CPID
       AND B.SJLY = 1
       AND B.SJYID IS NOT NULL --和聚源基金概况表匹配到的产品数据源ID不为空
       AND D.CPDM = C.APPLYINGCODEBACK --D表和基金概况表的后端代码匹配
       AND D.SJLY = 1
       AND D.SJYID IS NULL --后端产品数据源ID为空
       AND C.LISTEDSTATE != 5;

  --13.更新产品代码表净值
  MERGE INTO PIF.TPIF_CPDM M
  USING (SELECT CPID, JZRQ, DWJZ, LJJZ, NHSYL_D7, WFSYL FROM TPIF_CPZXJZ) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.JZRQ    = N.JZRQ,
           M.CPJZ    = N.DWJZ,
           M.LJJZ    = N.LJJZ,
           M.QRNHSYL = N.NHSYL_D7,
           M.WFSYL   = N.WFSYL;

  --14.最大回撤修复天数 INFO.TINFO_GMJJZDHCXFTS-----------P_TRAN_GMJJZDHCXFTS
  --移动端页面 业绩走势页面用到     
  DELETE FROM INFO.TINFO_GMJJZDHCXFTS WHERE ID < 0;
  INSERT INTO INFO.TINFO_GMJJZDHCXFTS
    (ID,
     INNERCODE,
     INDEXCODE,
     INDEXNAME,
     INDEXCYCLE,
     ENDDATE,
     RESTOREDAYS,
     MAXNVDATE,
     MAXDDDATE,
     RESTOREDATE,
     INSERTTIME,
     UPDATETIME,
     JSID,
     SECUCODE)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           -A.INNERCODE, --相反数
           A.INDEXCODE,
           A.INDEXNAME,
           A.INDEXCYCLE,
           A.ENDDATE,
           A.RESTOREDAYS,
           A.MAXNVDATE,
           A.MAXDDDATE,
           A.RESTOREDATE,
           A.INSERTTIME,
           A.UPDATETIME,
           A.JSID,
           C.CPDM
      FROM INFO.TINFO_GMJJZDHCXFTS A, INFO.TINFO_JJGK B, PIF.TPIF_CPDM C
     WHERE A.INNERCODE = B.INNERCODE
       AND B.APPLYINGCODEBACK = C.CPDM --后端代码匹配
       AND B.LISTEDSTATE != 5 --未终止
       AND C.SJLY = 1
       AND C.SJYID IS NULL;

  /*  --公募基金风险评价 TPIF_GMJJFXPJ，PRO_SJQX_GMJJFXPJ，产品筛选、对比页面用到
  DELETE FROM TPIF_GMJJFXPJ WHERE ID < 0;
  INSERT INTO TPIF_GMJJFXPJ
    (ID,
     RQ,
     CPID,
     BETA_3Y,
     BETA_6Y,
     BETA_1N,
     BETA_2N,
     BETA_3N,
     BETA_5N,
     BETA_10N,
     BETA_JNYL,
     BETA_CLYL,
     SYBZC_3Y,
     SYBZC_6Y,
     SYBZC_1N,
     SYBZC_2N,
     SYBZC_3N,
     SYBZC_5N,
     SYBZC_10N,
     SYBZC_JNYL,
     SYBZC_CLYL,
     BDL_3Y,
     BDL_6Y,
     BDL_1N,
     BDL_2N,
     BDL_3N,
     BDL_5N,
     BDL_10N,
     BDL_JNYL,
     BDL_CLYL,
     XGSJ,
     CJSJ,
     CPDM)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           A.RQ,
           D.CPID, --后端产品CPID
           A.BETA_3Y,
           A.BETA_6Y,
           A.BETA_1N,
           A.BETA_2N,
           A.BETA_3N,
           A.BETA_5N,
           A.BETA_10N,
           A.BETA_JNYL,
           A.BETA_CLYL,
           A.SYBZC_3Y,
           A.SYBZC_6Y,
           A.SYBZC_1N,
           A.SYBZC_2N,
           A.SYBZC_3N,
           A.SYBZC_5N,
           A.SYBZC_10N,
           A.SYBZC_JNYL,
           A.SYBZC_CLYL,
           A.BDL_3Y,
           A.BDL_6Y,
           A.BDL_1N,
           A.BDL_2N,
           A.BDL_3N,
           A.BDL_5N,
           A.BDL_10N,
           A.BDL_JNYL,
           A.BDL_CLYL,
           A.XGSJ,
           A.CJSJ,
           D.CPDM --后端产品代码
      FROM TPIF_GMJJFXPJ A, TPIF_CPDM B, INFO.TINFO_JJGK C, TPIF_CPDM D
     WHERE A.CPID = B.CPID
       AND B.CPDM = C.SECUCODE --B表取前端产品的CPID
       AND B.SJLY = 1
       AND B.SJYID IS NOT NULL --和聚源基金概况表匹配到的产品数据源ID不为空
       AND D.CPDM = C.APPLYINGCODEBACK --D表和基金概况表的后端代码匹配
       AND D.SJLY = 1
       AND D.SJYID IS NULL --后端产品数据源ID为空
       AND C.LISTEDSTATE != 5;
  
  --公募基金收益与规模 TPIF_GMJJSYYGM，PRO_SJQX_GMJJSYYGM，产品筛选、对比页面用到
  DELETE FROM TPIF_GMJJSYYGM WHERE ID < 0;
  INSERT INTO TPIF_GMJJSYYGM
    (ID,
     RQ,
     CPID,
     XPBL_3Y,
     XPBL_6Y,
     XPBL_1N,
     XPBL_2N,
     XPBL_3N,
     XPBL_5N,
     XPBL_10N,
     ALPHA_3Y,
     ALPHA_6Y,
     ALPHA_1N,
     ALPHA_2N,
     ALPHA_3N,
     ALPHA_5N,
     ALPHA_10N,
     ALPHA_JNYL,
     ALPHA_CLYL,
     XXBL_3Y,
     XXBL_6Y,
     XXBL_1N,
     XXBL_2N,
     XXBL_3N,
     XXBL_5N,
     XXBL_10N,
     XGSJ,
     CJSJ,
     CPDM,
     NHSYL_2N)
    SELECT -SEQ_TPIF_CPJZ_HD.NEXTVAL, --ID
           A.RQ,
           D.CPID, --后端产品CPID
           A.XPBL_3Y,
           A.XPBL_6Y,
           A.XPBL_1N,
           A.XPBL_2N,
           A.XPBL_3N,
           A.XPBL_5N,
           A.XPBL_10N,
           A.ALPHA_3Y,
           A.ALPHA_6Y,
           A.ALPHA_1N,
           A.ALPHA_2N,
           A.ALPHA_3N,
           A.ALPHA_5N,
           A.ALPHA_10N,
           A.ALPHA_JNYL,
           A.ALPHA_CLYL,
           A.XXBL_3Y,
           A.XXBL_6Y,
           A.XXBL_1N,
           A.XXBL_2N,
           A.XXBL_3N,
           A.XXBL_5N,
           A.XXBL_10N,
           A.XGSJ,
           A.CJSJ,
           D.CPDM, --后端产品代码
           A.NHSYL_2N
      FROM TPIF_GMJJSYYGM A, TPIF_CPDM B, INFO.TINFO_JJGK C, TPIF_CPDM D
     WHERE A.CPID = B.CPID
       AND B.CPDM = C.SECUCODE --B表取前端产品的CPID
       AND B.SJLY = 1
       AND B.SJYID IS NOT NULL --和聚源基金概况表匹配到的产品数据源ID不为空
       AND D.CPDM = C.APPLYINGCODEBACK --D表和基金概况表的后端代码匹配
       AND D.SJLY = 1
       AND D.SJYID IS NULL --后端产品数据源ID为空
       AND C.LISTEDSTATE != 5;*/

  --如果要重置序列，则执行下面命令
  SELECT SEQ_TPIF_CPJZ_HD.NEXTVAL INTO V_COUNT FROM DUAL;
  EXECUTE IMMEDIATE 'ALTER SEQUENCE SEQ_TPIF_CPJZ_HD INCREMENT BY ' ||
                    (-V_COUNT + 1);
  SELECT SEQ_TPIF_CPJZ_HD.NEXTVAL INTO V_COUNT FROM DUAL;
  EXECUTE IMMEDIATE 'ALTER SEQUENCE SEQ_TPIF_CPJZ_HD INCREMENT BY 1';

  COMMIT;
  O_CODE := 1;
  O_NOTE := '后端产品净值清洗成功!';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1; --运行失败
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '后端产品净值清洗,未知错误'
                ELSE
                 '后端产品净值清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
    ROLLBACK;
END;
/

