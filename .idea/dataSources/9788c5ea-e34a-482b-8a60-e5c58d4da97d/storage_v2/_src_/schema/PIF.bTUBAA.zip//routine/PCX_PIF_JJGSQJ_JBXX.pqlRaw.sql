create procedure pcx_pif_jjgsqj_jbxx(o_code   out number,
                                                o_note   out varchar2,
                                                o_result out sys_refcursor,
                                                i_userid in number,
                                                i_org_id in number --机构id
                                                ) as
  /******************************************************************
  项目名称：产品中心-基金公司全景-基本信息
  所属用户：PIF
  概要说明：查询基金公司基本信息.
  
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基本信息.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/05     1.0.0.1   陈云昊             新增.
  *********************************************************************************************************************/
  --v_sql varchar2(32767);
begin

  --初始化
  o_code := -1;
  o_note := '';
  
  --条件检验
  if i_userid is null then
    o_note := ' 用户ID不允许为空！';
    return;
  end if;
  
  if i_org_id is null then
    o_note := '机构id不允许为空！';
    return;
  end if;

  open o_result for
    select JGDM org_code,
           JGMC org_name,
           JGJC org_simp_name,
           to_char(CLRQ) establish_time,
           to_char(ZCZB, 'fm99999999999999990.099999999') reg_capital,
           FRDB legalrep,
           decode(GSFL,
                  1,
                  '证券交易所',
                  2,
                  '银行',
                  3,
                  '基金公司',
                  4,
                  '证券公司',
                  5,
                  '期货交易所',
                  6,
                  '信托公司',
                  7,
                  '咨询公司',
                  8,
                  '保险公司',
                  9,
                  '股权交易所',
                  10,
                  '私募基金管理人',
                  11,
                  '其他私募投资基金管理人',
                  12,
                  '私募股权、创业投资基金管理人',
                  13,
                  '其他金融机构',
                  '其他金融机构') corp_class,
           YWZZ business_qualify,
           to_char(GSPJ) cooperation_level,
           ZCDZ reg_address,
           BGDZ office_address,
           LXFS contact_method,
           to_char(ZGLGM, 'fm99999999999999990.099999999') tota_manage_scale,
           to_char(GMPM) scale_ranking,
           to_char(JJJLSL) fund_manager_num,
           to_char(JJSL) fund_num
      from DSC_STAT.tpif_stat_jjgs t
     where t.id = i_org_id;
  --dbms_output.put_line(v_sql);
  --open o_result for v_sql;

  o_code := 1;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;
  
end pcx_pif_jjgsqj_jbxx;
/

