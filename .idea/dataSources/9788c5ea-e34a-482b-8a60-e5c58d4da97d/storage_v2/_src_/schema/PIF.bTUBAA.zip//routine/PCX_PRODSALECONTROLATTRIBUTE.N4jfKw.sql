create PROCEDURE pcx_ProdSaleControlAttribute(O_CODE      OUT NUMBER,
                                                         O_NOTE      OUT VARCHAR2,
                                                         O_RESULT    OUT SYS_REFCURSOR,
                                                         I_USER      IN INTEGER, --操作人
                                                         I_IP        IN VARCHAR2, --访问IP
                                                         I_PROD_ID   IN NUMBER, --产品ID
                                                         I_PROD_CODE IN VARCHAR2 --产品代码
                                                         ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品销售控制属性查询
      语法信息：
           输入参数：   I_PROD_CODE  IN   VARCHAR2   --产品代码
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000002');
  V_COUNT NUMBER;
  V_JKLX  NUMBER;
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
        GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;



  OPEN O_RESULT FOR
    SELECT B.ID, --产品销售控制属性ID
           A.PROD_CODE, --产品代码
           A.PROD_FULLNAME AS PROD_NAME, --产品名称
           B.TA_CODE AS TA_CODE,
           B.IS_OTC_ACC, -- 是否需要OTC账户
           B.IS_OPEN_FUND_ACC, -- 是否需要开放式基金账户
           B.IS_TAX_RESIDENT_IDENTIFY, -- 税收居民身份识别
           B.PE_QUALIFIED_INVESTOR_FLAG, -- 私募基金合格投资者标志
           B.AM_QUALIFIED_INVESTOR_FLAG, --资管新规合格投资者标志
           (SELECT ID
              FROM TCUSTOM_QUALIFIED_INVESTOR
             WHERE TPROD_SALE_CENTER_INFO_ID = A.ID) AS CUSTOM_QUALIFIED_INVESTOR_FLAG, --自定义合格投资者标识
           B.ELIG_AGREEMENT_TXT_FLAG, --适当性协议文本标志
           B.INVESTOR_DECLARE_FLAG, --投资者声明标志
           B.WITNESS, --视频见证
           B.PROD_CONTRACT_TXT_FLAG, --产品合同文本标志
           B.PROD_SUPPORT_CUST_TYPE, --产品支持客户类型
           B.Is_Trust_Fm_Open, --信托理财是否开户
           B.Is_Org_Agents, --是否机构代理人
           B.Is_Investigate, --是否需要尽职调查
           B.IS_FIRST_SIGN_ORG, --是否允许首次在线签署(机构)
           B.Is_First_Sign_Indv --是否允许首次在线签署(个人)
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_SALE_CENTER_INFO B
     WHERE A.ID = B.PROD_ID
       AND A.ID = NVL(I_PROD_ID, A.ID)
       AND A.PROD_CODE = NVL(I_PROD_CODE, A.PROD_CODE);
  O_CODE := 0;
  O_NOTE := '查询成功';

   <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT B.ID, --产品销售控制属性ID
           A.PROD_CODE, --产品代码
           A.PROD_FULLNAME AS PROD_NAME, --产品名称
           B.TA_CODE AS TA_CODE,
           B.IS_OTC_ACC, -- 是否需要OTC账户
           B.IS_OPEN_FUND_ACC, -- 是否需要开放式基金账户
           B.IS_TAX_RESIDENT_IDENTIFY, -- 税收居民身份识别
           B.PE_QUALIFIED_INVESTOR_FLAG, -- 私募基金合格投资者标志
           B.AM_QUALIFIED_INVESTOR_FLAG, --资管新规合格投资者标志
           (SELECT ID
              FROM TCUSTOM_QUALIFIED_INVESTOR
             WHERE TPROD_SALE_CENTER_INFO_ID = A.ID) AS CUSTOM_QUALIFIED_INVESTOR_FLAG, --自定义合格投资者标识
           B.ELIG_AGREEMENT_TXT_FLAG, --适当性协议文本标志
           B.INVESTOR_DECLARE_FLAG, --投资者声明标志
           B.WITNESS, --视频见证
           B.PROD_CONTRACT_TXT_FLAG, --产品合同文本标志
           B.PROD_SUPPORT_CUST_TYPE, --产品支持客户类型
           B.Is_Trust_Fm_Open, --信托理财是否开户
           B.Is_Org_Agents, --是否机构代理人
           B.Is_Investigate, --是否需要尽职调查
           B.IS_FIRST_SIGN_ORG, --是否允许首次在线签署(机构)
           B.Is_First_Sign_Indv --是否允许首次在线签署(个人
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_SALE_CENTER_INFO B
     WHERE A.ID = B.PROD_ID
       AND 1 = 2;
  END IF ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

