create PROCEDURE PCX_PIF_CPQJ_ZSMK(O_CODE        OUT NUMBER,
                                              O_NOTE        OUT VARCHAR2,
                                              O_RESULT      OUT SYS_REFCURSOR,
                                              I_USER        IN NUMBER, --用户ID
                                              I_TEMPLATE_ID IN NUMBER --模板ID
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-全景显示模块
  所属用户：PIF
  概要说明：查询全景显示模块.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询全景显示模块
        
        根据模板ID查询该模板展示哪些模块
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/07/20     1.0.0.1   TUMENG             新增
      2021-12-13     1.0.0.2   GAOKUN            修改优化格式
  ********************************************************************/
  V_XSMK_IDS VARCHAR2(500);
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_TEMPLATE_ID IS NULL THEN
    O_NOTE := '模板ID不允许为空！';
    RETURN;
  END IF;

  BEGIN
    SELECT XSMK --显示模块
      INTO V_XSMK_IDS
      FROM PIF.TPIF_CPQJMBDY --产品全景模板定义
     WHERE ID = I_TEMPLATE_ID;
  EXCEPTION
    WHEN OTHERS THEN
      V_XSMK_IDS := '';
  END;

  OPEN O_RESULT FOR
    SELECT ID, XSTB AS ICON, MKMC AS NAME, MRXSCS AS DISPLAYPARAM
      FROM PIF.TPIF_QJXSMK
     WHERE INSTR(';' || V_XSMK_IDS || ';', ';' || ID || ';') > 0;


  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END;
/

