create PROCEDURE PCX_PIF_LCGL_LCDH(O_CODE     OUT NUMBER,
                                              O_NOTE     OUT VARCHAR2,
                                              O_RESULT   OUT SYS_REFCURSOR,
                                              I_USERID   IN NUMBER, --登陆用户ID
                                              I_KEY_WORD IN VARCHAR2 --搜索关键字
                                              
                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 流程管理-流程导航查询
  
      语法信息：
           输入参数：   I_USERID          IN NUMBER, --登陆用户ID
                       I_KEY_WORD        IN VARCHAR2--搜索关键字
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  /*  ID  ID
  GROUP_NAME  分组名称  --PIF_LCDH
  FLOW_NAME 流程名称
  FLOW_OBJECT_ULR 流程对象URL
  OPEN_TYPE 窗口类型
  ACCESS_RIGHTS 访问权限*/

  OPEN O_RESULT FOR
    SELECT A.ID AS ID,
           (SELECT NOTE
              FROM LIVEBOS.TXTDM
             WHERE FLDM = 'PIF_LCDH'
               AND IBM = A.LCLX) AS GROUP_NAME,
           A.LCMC AS FLOW_NAME,
           A.LJDZ AS FLOW_OBJECT_ULR,
           A.DKFS AS OPEN_TYPE,
         1 AS ACCESS_RIGHTS
      --FROM TPIF_LCDHPZ A
        FROM TPIF_LCDJ A
     WHERE A.LCMC LIKE '%' || I_KEY_WORD || '%'
     ORDER BY A.LCLX ASC,A.ID ASC ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

