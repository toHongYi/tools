create PROCEDURE PCX_PIF_CPXLMXTJ_glr(O_RESULT OUT SYS_REFCURSOR,
                                             I_TJLX   IN NUMBER,
                                             I_KSRQ   IN NUMBER,
                                             I_JSRQ   IN NUMBER,
                                             I_CPXL   IN NUMBER,
                                             I_XSJG   IN NUMBER,
                                             I_SFZDDX IN NUMBER, --0否；1是
                                             I_XSLX   IN VARCHAR2, --1首发；2持营
                                             I_CPDM   IN NUMBER,
                                             I_USERID IN NUMBER) AS
  /* -----------------------------------------------------------------------
   过程名称 :  PCX_PIF_CPXLMXTJ
   功能简述：  产品销量明细统计



   ------------------------------------------------------------------------
   操作人           操作时间       版本            操作
   LIUTX           20190918       1.0           新增
  -----------------------------------------------------------------------*/
  V_SQL        VARCHAR2(3000);
  V_NOTE       VARCHAR2(1000);
  VN_TJYF_MIN  NUMBER(8);
  VN_TJYF_MAX  NUMBER(8);
  VN_TJYF_MAX1 NUMBER(8);
  VN_TJYF_MAX2 NUMBER(8);
  V_COUNT      NUMBER;
BEGIN

  IF I_TJLX = 1 THEN

    V_SQL := 'SELECT AA.SJRQ,AA.NAME,AA.CPXL,AA.CPDM,AA.CPMC,SUM(AA.RGGM) RGGM ,SUM(AA.SGGM) SGGM,SUM(AA.SHGM) SHGM,SUM(AA.CLGM) CLGM,SUM(AA.RJBYGM) RJBYGM,SUM(AA.BYKHS) BYKHS
      FROM (SELECT Z.SJRQ  ,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.RGGM,Z.SGGM,Z.SHGM,nvl((SELECT clgm FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ = (SELECT MAX(SJRQ) FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE SJRQ LIKE ''' ||
             I_JSRQ ||
             '%'')),Z.CLGM) clgm,nvl((SELECT SUM(RJBYGM)/COUNT(SJRQ) FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SUBSTR(SJRQ,1,4) BETWEEN ' ||
             I_KSRQ || ' AND ' || I_JSRQ ||
             '),Z.RJBYGM) RJBYGM,nvl((SELECT BYKHS FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ =(SELECT MAX(SJRQ) FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE SJRQ LIKE ''' ||
             I_JSRQ || '%'')),Z.BYKHS) BYKHS
    FROM (SELECT A.ID,A.GLRMC as NAME
            FROM PIF.TPIF_HZQD@cpzx205 A ) X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         (SELECT DISTINCT CPID, ZT, SFCY FROM PIF.TPIF_ZDDXCPK@cpzx205) K,
         STAT_PIF.TPIF_STAT_CPDM_XSTJ_N@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2)
     AND X.ID = y.CPGLRID
     AND Y.CPID = K.CPID
     AND Y.CPID = Z.CPID
     AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  ELSIF I_TJLX = 2 THEN
    SELECT MIN(ZRR)
      INTO VN_TJYF_MIN
      FROM livebos.TXTJYR
     WHERE ND || JD = I_KSRQ;

    SELECT MAX(ZRR)
      INTO VN_TJYF_MAX1
      FROM livebos.TXTJYR
     WHERE ND || JD = I_JSRQ;

    SELECT MAX(jyr)
      INTO VN_TJYF_MAX2
      FROM livebos.TXTJYR
     WHERE ND || JD =
           (SELECT ND || JD - 1
              FROM livebos.TXTJYR
             WHERE ZRR = TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')));
    SELECT LEAST(VN_TJYF_MAX1, VN_TJYF_MAX2) INTO VN_TJYF_MAX FROM DUAL;
    V_SQL := 'SELECT AA.SJRQ,AA.NAME,AA.CPXL,AA.CPDM,AA.CPMC,SUM(AA.RGGM) RGGM ,SUM(AA.SGGM) SGGM,SUM(AA.SHGM) SHGM,SUM(AA.CLGM) CLGM,SUM(AA.RJBYGM) RJBYGM,SUM(AA.BYKHS) BYKHS
      FROM (SELECT Z.SJRQ ,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.RGGM,Z.SGGM,Z.SHGM,nvl((SELECT clgm FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ = ' ||
             VN_TJYF_MAX ||
             '),Z.CLGM) clgm,nvl((SELECT SUM(RJBYGM)/COUNT(SJRQ) FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ BETWEEN ' ||
             VN_TJYF_MIN || ' AND ' || VN_TJYF_MAX ||
             '),0) RJBYGM,nvl((SELECT BYKHS FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ = ' ||
             VN_TJYF_MAX || '),Z.BYKHS) BYKHS
    FROM  (SELECT A.ID,A.GLRMC as NAME
            FROM PIF.TPIF_HZQD@cpzx205 A )  X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         (SELECT DISTINCT CPID, ZT, SFCY FROM PIF.TPIF_ZDDXCP@cpzx205K) K,
         STAT_PIF.TPIF_STAT_CPDM_XSTJ_J@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2)
     AND X.ID = y.CPGLRID
     AND Y.CPID = K.CPID
     AND Y.CPID = Z.CPID
     AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  ELSE

    V_SQL := 'SELECT AA.SJRQ,AA.NAME,AA.CPXL,AA.CPDM,AA.CPMC,SUM(AA.RGGM) RGGM ,SUM(AA.SGGM) SGGM,SUM(AA.SHGM) SHGM,SUM(AA.CLGM) CLGM,SUM(AA.RJBYGM) RJBYGM,SUM(AA.BYKHS) BYKHS
      FROM (SELECT Z.SJRQ  ,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.RGGM,Z.SGGM,Z.SHGM,nvl((SELECT clgm FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ = (SELECT MAX(SJRQ) FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE SJRQ LIKE ''' ||
             I_JSRQ ||
             '%'')),Z.CLGM) clgm,nvl((SELECT SUM(RJBYGM)/COUNT(SJRQ) FROM stat_pif.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SUBSTR(SJRQ,1,6) BETWEEN ' ||
             I_KSRQ || ' AND ' || I_JSRQ ||
             '),Z.RJBYGM) RJBYGM,nvl((SELECT BYKHS FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE CPID = Y.CPID AND JGDM = X.ID AND SJRQ =(SELECT MAX(SJRQ) FROM STAT_PIF.TPIF_STAT_XSZB_YMTJ@cpzx205 WHERE SJRQ LIKE ''' ||
             I_JSRQ || '%'')),Z.BYKHS) BYKHS
    FROM (SELECT A.ID,A.GLRMC as NAME
            FROM PIF.TPIF_HZQD@cpzx205 A )  X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         (SELECT DISTINCT CPID, ZT, SFCY FROM PIF.TPIF_ZDDXCPK@cpzx205) K,
         STAT_PIF.TPIF_STAT_CPDM_XSTJ_Y@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2)
     AND X.ID = y.CPGLRID
     AND Y.CPID = K.CPID
     AND Y.CPID = Z.CPID
     AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  END IF;

  IF I_XSLX IS NOT NULL THEN
    V_SQL := V_SQL || ' AND K.SFCY=' || I_XSLX;
  END IF;

  IF I_CPXL IS NOT NULL THEN
    V_SQL := V_SQL || ' and y.CPXL = ' || I_CPXL;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM PIF.TPIF_FZJGRYMD@cpzx205
   WHERE USERNAME = I_USERID;
  IF V_COUNT > 0 THEN
    V_SQL := V_SQL ||
             ' AND instr('', '' || (SELECT WM_CONCAT(QXQYYB)
                                                  FROM PIF.TPIF_FZJGRYMD@cpzx205
                                                 WHERE USERNAME = ' ||
             I_USERID || ') || '', '', '', '' || X.ID || '', '') > 0';
  END IF;

  IF V_COUNT = 0 AND I_XSJG IS NOT NULL AND I_XSJG != 999999999 THEN
    V_SQL := V_SQL || ' and x.id = ' || I_XSJG;
  END IF;

  IF I_SFZDDX IS NOT NULL THEN
    V_SQL := V_SQL || ' and y.SFZDXS = ' || I_SFZDDX;
  END IF;

  IF I_CPDM IS NOT NULL THEN
    V_SQL := V_SQL || ' and y.ID = ' || I_CPDM;
  END IF;

  V_SQL := V_SQL ||
           ') AA GROUP BY AA.CPDM,AA.CPMC,AA.SJRQ,AA.NAME,AA.CPXL';

  DBMS_OUTPUT.PUT_LINE(V_SQL);
  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
END PCX_PIF_CPXLMXTJ_glr;
/

