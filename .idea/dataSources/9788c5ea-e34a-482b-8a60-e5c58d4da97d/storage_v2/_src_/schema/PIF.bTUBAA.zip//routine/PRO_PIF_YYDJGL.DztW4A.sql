create PROCEDURE PRO_PIF_YYDJGL(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2, --返回消息
                                           I_USER IN INTEGER, --操作人
                                           I_IP   IN VARCHAR2, --操作IP
                                           I_OPER IN INTEGER, --操作类型0|修改;1|退回;2|删除;3|修改预约单;4|提交;5|预约
                                           I_ID   IN VARCHAR2 --操作ID
                                           ) IS
    /******************************************************************
        项目名称：预约单据管理
        所属用户：PIF
        功能说明：预约单据管理相关操作
        语法信息：
             输入参数：   I_USER  操作人
                          I_IP    操作IP
                          I_OPER  操作类型0|修改;1|退回;2|删除
                          I_ID    操作ID
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-08-31     1.0.0    侯金铂                创建
            2017-09-26     1.0.1    侯金铂                修改 客户的校验取消
            2018-10-31     1.0.2    涂  孟                修改  增加最低金额的限制
            2020-06-02     1.0.3    涂  孟                修改 同一产品同一资金账户不能重复预约
    ***********************************************************************/
    V_QXBZ  INTEGER; --权限标识
    V_OBJ   TPIF_YYGL%ROWTYPE; --表单记录
    V_CZBM  VARCHAR2(200); --操作编码
    V_CZSM  VARCHAR2(2000); --日志操作明细
    V_COUNT NUMBER; --- 计数用
    V_ZDJE  NUMBER(16, 2); --最低金额
    V_CPMC  VARCHAR2(200); --产品名称
    V_WTZJE NUMBER(16, 2); --委托总金额
    V_ZJE   NUMBER(16, 2); --总金额上限
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';

    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_YYGL WHERE ID = I_ID;
        SELECT A.CPMMC INTO V_CPMC FROM TPIF_YYCPGL A WHERE A.ID = V_OBJ.CPMC;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  0,
                  '140201',
                  1,
                  '140202',
                  2,
                  '140203',
                  3,
                  '140204',
                  4,
                  '140205',
                  5,
                  '140206',
                  '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER,
                         0,
                         '修改',
                         1,
                         '退回',
                         2,
                         '删除',
                         3,
                         '修改提交',
                         4,
                         '提交',
                         5,
                         '预约',
                         '') || ']_' || V_CPMC
      INTO V_CZSM
      FROM DUAL;
    --CHECK
    /*SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --认购金额比最低金额要大
        --取出该单据对应预约产品最低金额
        SELECT ZDJE INTO V_ZDJE FROM TPIF_YYCPGL WHERE ID = V_OBJ.CPMC;
        IF V_OBJ.WTJE < V_ZDJE THEN
            O_CODE := -1;
            O_NOTE := '认购金额不能比最低金额低';
            RETURN;
        END IF;
        --委托总金额不能大于总金额上限
        SELECT SUM(A.WTJE)
          INTO V_WTZJE
          FROM TPIF_YYGL A
         WHERE A.CPMC = V_OBJ.CPMC
           AND A.ZT = 2;
        SELECT B.ZJE INTO V_ZJE FROM TPIF_YYCPGL B WHERE ID = V_OBJ.CPMC;
        IF V_WTZJE > V_ZJE THEN
            O_NOTE := '超过总金额上限！';
            RETURN;
        END IF;

    END IF;
    IF I_OPER = 1 THEN
        --退回-----------------------------------------------------------------------
        UPDATE TPIF_YYGL A SET A.ZT = -1 WHERE ID = I_ID;
        --已预约数量减一
        UPDATE TPIF_YYCPGL A SET A.YTJSL = A.YTJSL - 1 WHERE ID = V_OBJ.CPMC;

    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        DELETE FROM TPIF_YYGL WHERE ID = I_ID;
        --已预约数量减一
        UPDATE TPIF_YYCPGL A SET A.YTJSL = A.YTJSL - 1 WHERE ID = V_OBJ.CPMC;
    END IF;
    /*    IF I_OPER = 3 THEN
        --//:修改预约单-----------------------------------------------------------------------
        --- 逻辑校验
        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.KHXM = V_OBJ.KHMC ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户姓名不匹配';
          RETURN ;
        END IF ;

        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.ZJBH = V_OBJ.KHSFZ ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户身份证不匹配';
          RETURN ;
        END IF ;

        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.SJ = V_OBJ.KHDH ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户电话不匹配';
          RETURN ;
        END IF ;


    END IF;    */
    IF I_OPER = 4 THEN
        --提交
        --已提交数量大于或等于总数量时不允许再提交
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_YYCPGL A
         WHERE A.YTJSL >= A.ZSL
           AND A.ID = V_OBJ.CPMC;
        IF V_COUNT > 0 THEN
            O_NOTE := '数量已满不能再预约！';
            RETURN;
        END IF;
        --委托总金额不能大于总金额上限
        SELECT SUM(A.WTJE)
          INTO V_WTZJE
          FROM TPIF_YYGL A
         WHERE A.CPMC = V_OBJ.CPMC
           AND A.ZT = 2;
        SELECT B.ZJE INTO V_ZJE FROM TPIF_YYCPGL B WHERE ID = V_OBJ.CPMC;
        IF V_WTZJE > V_ZJE THEN
            O_NOTE := '超过总金额上限！';
            RETURN;
        END IF;
        --同一资金账户同一产品不能重复预约
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_YYGL A WHERE A.CPMC = V_OBJ.CPMC AND A.ZJZH = V_OBJ.ZJZH AND A.ZT = 2;
        IF V_COUNT >1 THEN
          O_NOTE := '该资金账号已预约！';
          RETURN;
        END IF;

        --预约数量加一
        UPDATE TPIF_YYCPGL A SET A.YTJSL = A.YTJSL + 1 WHERE A.ID = V_OBJ.CPMC;
    END IF;

    IF I_OPER = 5 THEN
        --预约-----------------------------------------------------------------------
        /*        INSERT INTO PIF.TEST_PARA
            (PROC, VSQL, TIME)
        VALUES
            ('PRO_PIF_YYDJGL', ' ' || V_OBJ.ZJZH || ' ' ||V_OBJ.KHMC, SYSDATE);
        COMMIT;*/

        --- 逻辑校验
        /*        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.KHXM = V_OBJ.KHMC ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户姓名不匹配';
          RETURN ;
        END IF ;

        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.ZJBH = V_OBJ.KHSFZ ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户身份证不匹配';
          RETURN ;
        END IF ;

        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_KHXX A WHERE A.ZJZH = V_OBJ.ZJZH AND A.SJ = V_OBJ.KHDH ;
        IF V_COUNT = 0 THEN
          O_CODE := -1;
          O_NOTE := '客户电话不匹配';
          RETURN ;
        END IF ;*/
        --认购金额比最低金额要大
        --取出该单据对应预约产品最低金额
        SELECT ZDJE INTO V_ZDJE FROM TPIF_YYCPGL WHERE ID = V_OBJ.CPMC;
        IF V_OBJ.WTJE < V_ZDJE THEN
            O_CODE := -1;
            O_NOTE := '认购金额不能比最低金额低';
            RETURN;
        END IF;
        --已提交数量大于或等于总数量时不允许再提交
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_YYCPGL A
         WHERE A.YTJSL >= A.ZSL
           AND A.ID = V_OBJ.CPMC;
        IF V_COUNT > 0 THEN
            O_NOTE := '数量已满不能再预约！';
            RETURN;
        END IF;
        --委托总金额不能大于总金额上限
        SELECT SUM(A.WTJE)
          INTO V_WTZJE
          FROM TPIF_YYGL A
         WHERE A.CPMC = V_OBJ.CPMC
           AND A.ZT = 2;
        SELECT B.ZJE INTO V_ZJE FROM TPIF_YYCPGL B WHERE ID = V_OBJ.CPMC;
        IF V_WTZJE > V_ZJE THEN
            O_NOTE := '超过总金额上限！';
            RETURN;
        END IF;
        --同一资金账户同一产品不能重复预约
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_YYGL A WHERE A.CPMC = V_OBJ.CPMC AND A.ZJZH = V_OBJ.ZJZH AND A.ZT = 2;
        IF V_COUNT >1 THEN
          O_NOTE := '该资金账号已预约！';
          RETURN;
        END IF;

        UPDATE TPIF_YYCPGL A SET A.YTJSL = NVL(A.YTJSL, 0) + 1 WHERE ID = V_OBJ.CPMC;
    END IF;

    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '修改',
                           1,
                           '退回',
                           2,
                           '删除',
                           3,
                           '修改预约单',
                           4,
                           '提交',
                           5,
                           '预约') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_YYDJGL;
/

