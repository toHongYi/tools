create PROCEDURE PRO_PIF_SMJGBMDCDR(O_CODE OUT NUMBER,
                                               O_NOTE OUT VARCHAR2,
                                               I_USER IN NUMBER) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募机构白名单池导入
      语法信息：
           输入参数：
           输出参数：
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人         修改内容简要说明
          2019-08-15     1.0       WUJINFENG              新增
  ***********************************************************************/
  V_COUNT  NUMBER;
  V_NUM    NUMBER := 0;
  V_JGMC   VARCHAR2(200);

BEGIN


    FOR CUR IN (SELECT * FROM PIF.TPIF_SMJGBMDCDR A) LOOP


      select jgmc INTO V_JGMC from tpif_jgdm where id =CUR.jgid ;
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_SMJGBMDCDR
       WHERE JGID = CUR.JGID
         and id <> CUR.id;

      IF V_COUNT > 0 THEN
        O_CODE := -1;
        O_NOTE := '机构[' || V_JGMC || ']存在多条记录,请检查';
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_SMJGBMDC
       WHERE JGID = CUR.JGID;
      IF V_COUNT > 0 THEN
        O_CODE := -1;
        O_NOTE := '机构:(' || V_JGMC || '),在私募机构白名单池中已存在,请检查';
        RETURN;

      END IF;

      INSERT INTO pif.TPIF_SMJGBMDC
        ( id,
          jgid,
         -- jgmc,
        --  jgjc,
        --  clrq,
        --  djbh,
        --  djsj,
        --  zczb,
          lx,
          RCRY,
          rcsj
          )
      VALUES
        (livebos.func_nextid('TPIF_SMJGBMDC'),
         CUR.jgid,
        -- V_JGMC,
        -- CUR.JGJC,
        -- CUR.Clrq,
        -- CUR.Djbh,
        -- CUR.Djsj,
        -- CUR.zczb,
         CUR.LX,
         I_USER,
         sysdate);

      V_NUM := V_NUM + 1;

    END LOOP;
    --清除临时表数据
    DELETE FROM PIF.TPIF_SMJGBMDCDR;


  O_CODE := 199;
  O_NOTE := '成功导入【' || V_NUM || '】条数据！！！';

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := O_NOTE || SQLERRM;

END;
/

