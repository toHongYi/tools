create FUNCTION     FUNC_PIF_HQZDZDYM(I_ZDDM IN VARCHAR2, --字典码
                                                 I_PXLX IN INTEGER, --字典排序类型 1|IBM
                                                 I_YMCD IN INTEGER, --掩码长度
                                                 I_DQZ  IN VARCHAR2 --当前值
                                                 ) RETURN VARCHAR2 IS --返回掩码

    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取指定字典码对应当前值的掩码
        语法信息：
             输入参数：   I_ZDDM  字典码
                          I_PXLX  字典排序类型 1|IBM
                          I_YMCD  掩码长度
                          I_DQZ   当前值
             输出参数：   RETURN 掩码值
        逻辑说明：
             1、按1是0否的逻辑，根据字典码+字典排序类型，顺序生成对应掩码
             2、根据掩码长度右填充‘0’，返回指定长度的掩码值
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1    戴文生              新增
    ***********************************************************************/
    V_RETURN VARCHAR2(100); --返回字典掩码
BEGIN
    --init
    --赋初始值
    V_RETURN := '';
    --start
    --根据字典排序字段的不同，返回对应掩码值
    IF I_PXLX = 1 THEN
        --字典排序类型为1，即按IBM排序/升序返回
        FOR CUR IN (SELECT IBM from livebos.TXTDM WHERE FLDM = I_ZDDM ORDER BY IBM ASC) LOOP
            --循环顺序校验字典值是否在当前值中；是则填充1，否则填充0
            IF INSTR(';'||I_DQZ||';',';'||CUR.IBM||';') > 0 THEN
                V_RETURN := V_RETURN || '1';
            ELSE
                V_RETURN := V_RETURN || '0';
            END IF;
        END LOOP;
    END IF;
    --根据入参掩码长度右填充进行返回
    V_RETURN := RPAD(V_RETURN,I_YMCD,'0');
    --return
    --最终返回
    RETURN(V_RETURN);
END FUNC_PIF_HQZDZDYM;
/

