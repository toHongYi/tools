create PROCEDURE PRO_PIF_JYRL_QXHB(O_RESULT OUT INT, --返回结果代码
                                              O_NOTE   OUT VARCHAR2,
                                              I_USER   IN VARCHAR2,
                                              I_IP     IN VARCHAR2,
                                              I_GZJLID IN NUMBER --规则记录ID
                                              ) AS
  /******************************************************************************
    *
    *文件名称：PRO_PIF_JYRL_QXHB
    *项目名称：产品中心
    *创建日期：2016-06-14
    *功能说明：交易日历清洗合并
  
    *--------------------------------------------------------------------------------------------------------
    *修改者        版本号        修改日期         说明
    *王大一        1.0.0         2016-12-14       交易日历清洗合并
    *王大一        1.0.1         2016-12-19       逻辑修改
    *孙远何        1.0.2         2017-06-16       修改：修改各开放日数据表
  -----------------------------------------------------------------------------------------------------------------*/
  V_ID   NUMBER(16);
  V_CPID NUMBER(16);

BEGIN

  O_RESULT := 1;
  O_NOTE   := '成功';
  --增加对象记录
  LIVEBOS.PNEXTID('TPIF_JYRLQXHB', V_ID);
  INSERT INTO TPIF_JYRLQXHB
    (ID, QXRQ, QXSJ, CZR, ZXJG, BZ)
  VALUES
    (V_ID, TO_CHAR(SYSDATE, 'YYYYMMDD'), SYSDATE, I_USER, 0, NULL);
  COMMIT;

  IF I_GZJLID IS NULL THEN
    --如果不传规则记录ID，则全部重新新增
    --先清空合并表
    EXECUTE IMMEDIATE 'TRUNCATE TABLE PIF.TPIF_JYRL_HB';
    UPDATE LIVEBOS.TSEQUENCE SET ID = 1 WHERE NAME = 'TPIF_JYRL_HB';
    --1、复制本地交易日历
    --INSERT INTO PIF.TPIF_JYRL_HB (ID,RQ,CPID,JYRLX,YWLX) SELECT CRMII.FUNC_NEXTID('TPIF_JYRL_HB'),RQ,CPID,JYRLX,YWLX FROM PIF.TPIF_JYRL ORDER BY ID;
  
    MERGE INTO PIF.TPIF_JYRL_HB A
    USING (SELECT C.CPID, C.RQ, C.JYRLX, C.YWLX,C.SM FROM PIF.TPIF_JYRL C) B
    ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
    WHEN MATCHED THEN
      UPDATE SET A.YWLX = A.YWLX || ';' || B.YWLX
    WHEN NOT MATCHED THEN
      INSERT
        (ID, RQ, CPID, JYRLX, YWLX,SM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_JYRL_HB'),
         B.RQ,
         B.CPID,
         B.JYRLX,
         B.YWLX,
         B.SM);
  
  ELSE
    --如果传规则记录ID，则只增删 该记录对应的产品 的交易日历
    SELECT CPID INTO V_CPID FROM TPIF_JYRL_GZJL WHERE ID = I_GZJLID;
  
    DELETE FROM TPIF_JYRL_HB --先删除该规则记录所对应的产品的交易日历
     WHERE CPID = V_CPID;
  
    MERGE INTO PIF.TPIF_JYRL_HB A
    USING (SELECT C.CPID, C.RQ, C.JYRLX, C.YWLX,C.SM
             FROM PIF.TPIF_JYRL C
            WHERE CPID = V_CPID) B
    ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
    WHEN MATCHED THEN
      UPDATE SET A.YWLX = A.YWLX || ';' || B.YWLX
    WHEN NOT MATCHED THEN
      INSERT
        (ID, RQ, CPID, JYRLX, YWLX,SM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_JYRL_HB'),
         B.RQ,
         B.CPID,
         B.JYRLX,
         B.YWLX,
         B.SM);
  
  END IF;

  /*   --2、清洗合并开放日JYRLX=2
  MERGE INTO PIF.TPIF_JYRL_HB A
  USING (SELECT D.ID CPID,
                TO_DATE(TO_CHAR(C.JSR_RQ, 'YYYYMMDD'), 'YYYYMMDD') RQ,
                2 JYRLX,
                '' YWLX
           FROM PIF.TPIF_CPDM_GL_QX C
           JOIN PIF.TPIF_CPDM D
             ON C.CPID = D.CPID) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
  WHEN NOT MATCHED THEN
      INSERT
          (ID, RQ, CPID, JYRLX, YWLX)
      VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_JYRL_HB'), B.RQ, B.CPID, B.JYRLX, B.YWLX);
  
  --3、清洗合分红日
  --权益登记日
  MERGE INTO PIF.TPIF_JYRL_HB A
  USING (SELECT D.ID CPID,
                TO_DATE(TO_CHAR(C.FHQYDJR, 'YYYYMMDD'), 'YYYYMMDD') RQ,
                10 JYRLX,
                '' YWLX
           FROM LIVEBOS.TPIF_CPDM_GL_QYFA C
           JOIN PIF.TPIF_CPDM D
             ON C.CPID = D.CPID
            AND C.FHQYDJR IS NOT NULL) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
  WHEN NOT MATCHED THEN
      INSERT
          (ID, RQ, CPID, JYRLX, YWLX)
      VALUES
          (CRMII.FUNC_NEXTID('TPIF_JYRL_HB'), B.RQ, B.CPID, B.JYRLX, B.YWLX);
  --除权日
  MERGE INTO PIF.TPIF_JYRL_HB A
  USING (SELECT D.ID CPID,
                TO_DATE(TO_CHAR(C.FHQYPFR, 'YYYYMMDD'), 'YYYYMMDD') RQ,
                11 JYRLX,
                '' YWLX
           FROM PIF.TPIF_CPDM_GL_QYFA C
           JOIN PIF.TPIF_CPDM D
             ON C.CPID = D.CPID
            AND C.FHQYPFR IS NOT NULL) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
  WHEN NOT MATCHED THEN
      INSERT
          (ID, RQ, CPID, JYRLX, YWLX)
      VALUES
          (CRMII.FUNC_NEXTID('TPIF_JYRL_HB'), B.RQ, B.CPID, B.JYRLX, B.YWLX);
  --现金分红确认日
  MERGE INTO PIF.TPIF_JYRL_HB A
  USING (SELECT D.ID CPID,
                TO_DATE(TO_CHAR(C.FHQYJSR, 'YYYYMMDD'), 'YYYYMMDD') RQ,
                21 JYRLX,
                '' YWLX
           FROM PIF.TPIF_CPDM_GL_QYFA C
           JOIN PIF.TPIF_CPDM D
             ON C.CPID = D.CPID
            AND C.FHQYJSR IS NOT NULL) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
  WHEN NOT MATCHED THEN
      INSERT
          (ID, RQ, CPID, JYRLX, YWLX)
      VALUES
          (CRMII.FUNC_NEXTID('TPIF_JYRL_HB'), B.RQ, B.CPID, B.JYRLX, B.YWLX);
  --再投资确认日
  MERGE INTO PIF.TPIF_JYRL_HB A
  USING (SELECT D.ID CPID,
                TO_DATE(TO_CHAR(C.FHHLZTZR, 'YYYYMMDD'), 'YYYYMMDD') RQ,
                20 JYRLX,
                '' YWLX
           FROM PIF.TPIF_CPDM_GL_QYFA C
           JOIN PIF.TPIF_CPDM D
             ON C.CPID = D.CPID
            AND C.FHHLZTZR IS NOT NULL) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ AND A.JYRLX = B.JYRLX)
  WHEN NOT MATCHED THEN
      INSERT
          (ID, RQ, CPID, JYRLX, YWLX)
      VALUES
          (CRMII.FUNC_NEXTID('TPIF_JYRL_HB'), B.RQ, B.CPID, B.JYRLX, B.YWLX);*/
  --完成
  UPDATE TPIF_JYRLQXHB
     SET ZXJG = 1,
         BZ   = '结束时间：' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
   WHERE ID = V_ID;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_RESULT := -1;
    O_NOTE   := SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1000) ||
                SQLERRM;
  
    ROLLBACK;
    IF (O_RESULT < 0) THEN
      UPDATE TPIF_JYRLQXHB
         SET ZXJG = -1,
             BZ   = '结束时间：' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') ||
                    '--------' || O_NOTE
       WHERE ID = V_ID;
      COMMIT;
    END IF;
  
END PRO_PIF_JYRL_QXHB;
/

