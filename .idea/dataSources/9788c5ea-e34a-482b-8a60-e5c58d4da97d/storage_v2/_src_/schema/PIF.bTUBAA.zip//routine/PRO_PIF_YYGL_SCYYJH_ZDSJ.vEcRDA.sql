create PROCEDURE PRO_PIF_YYGL_SCYYJH_ZDSJ(O_CODE OUT NUMBER,
                                                         O_NOTE OUT VARCHAR2,
                                                         I_CZR  IN NUMBER, --操作人
                                                         I_IP   IN VARCHAR2, --操作IP
                                                         I_CPID IN VARCHAR2, --产品ID串,不同产品ID用分号隔开
                                                         I_MBBM IN VARCHAR2  --运营计划模板
                                                         ) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：海通证券产品中心

           功能说明：产品批量自动上架配置运营计划
               参数说明：PRO_PIF_YYGL_SCYYJH_ZDSJ
                    入参：
                         I_CZR    IN NUMBER,
                         I_IP     IN NUMBER,
                         I_CPID   IN NUMBER, --产品ID


                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,



          ----------------------------------------------------------
          操作人        版本号        时间                      操作
          刘浪浪        1.0.1    2015/01/16                     新增

    -------------------------------------------------------------------------------------------------*/

BEGIN

    O_CODE := 1;
    O_NOTE := '成功';

    IF I_CPID IS NULL THEN
        O_CODE := -1;
        O_NOTE := '产品ID不能为空!';
        RETURN;
    END IF;

    IF I_CZR IS NULL OR I_IP IS NULL THEN
        O_CODE := -1;
        O_NOTE := '操作人或操作IP不能为空!';
        RETURN;
    END IF;

    --循环获取模版明细，然后调用产品批量生成运营计划的过程
    FOR YYJHMX IN (SELECT T.CPSJLX, T.YYRWLX, T.ZXRY, T.WCSC, T.ZXSC, T.ZYCD
                     FROM TPIF_CPYYJHMB_MX T
                    WHERE T.YYJHMB = (SELECT ID FROM TPIF_CPYYJHMB WHERE MBBM = I_MBBM)) LOOP
        PRO_PIF_YYGL_SCYYJH(O_CODE,
                            O_NOTE,
                            1,
                            1,
                            I_CZR,
                            I_IP,
                            I_CPID,
                            YYJHMX.CPSJLX,
                            YYJHMX.YYRWLX,
                            YYJHMX.ZXRY,
                            YYJHMX.WCSC,
                            YYJHMX.ZXSC,
                            YYJHMX.ZYCD);
        IF O_CODE < 0 THEN
            ROLLBACK;
            RETURN;
        END IF;
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        ROLLBACK;

END PRO_PIF_YYGL_SCYYJH_ZDSJ;
/

