create FUNCTION FUNC_PIF_GET_CPHTYSSC(I_HTID IN NUMBER --合同ID
                                                 ) RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明: 计算产品合同延时时长
              营业部寄出时间去减开放日最后一天，未寄出则当前时间减开放日最后一天
  
      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        hqn     1.0.0      2021/12/16                 新增
  --------------------------------------------------------------------------------*/
  V_SFYJC NUMBER; --是否有寄出
  V_COUNT NUMBER;
  V_RET   NUMBER := 0;
  V_JSRQ  DATE;
  V_ZT    NUMBER; --合同状态
  --V_QSZT   NUMBER; --签署状态
  V_HTSQID NUMBER;
  V_JCSJ   DATE; --寄出时间
BEGIN

  SELECT COUNT(1)
    INTO V_SFYJC
    FROM LC_HTJH T
   WHERE EXISTS (SELECT 1
            FROM LC_HTJH_JHHTXX S
           WHERE S.LC_HTJH_ID = T.ID
             AND S.CPHT = I_HTID);
  SELECT ZT INTO V_ZT FROM TPIF_CPHT WHERE ID = I_HTID;
  IF V_SFYJC = 0 THEN
    --无寄出
    IF V_ZT IN (1, 7) THEN
      --合同入库和寄回管理人不算延时
      RETURN(V_RET);
    END IF;
    SELECT MAX(ID)
      INTO V_HTSQID
      FROM LC_HTSQ T
     WHERE INSTR(';' || T.HTID || ';', ';' || I_HTID || ';') > 0;
    --存在合同申请
    IF V_HTSQID IS NULL THEN
      RETURN(V_RET);
    END IF;
    SELECT TO_DATE(TO_CHAR(XSJSRQ), 'YYYYMMDD')
      INTO V_JSRQ
      FROM LC_HTSQ
     WHERE ID = V_HTSQID; --获取销售结束时间
  
    IF V_JSRQ IS NULL THEN
      RETURN(V_RET);
    END IF;
  
    IF SYSDATE - 1 > V_JSRQ THEN
      V_RET := ROUND(TO_NUMBER(SYSDATE - 1 - V_JSRQ) * 24, 1);
      RETURN(V_RET);
    END IF;
  END IF;

  IF V_SFYJC > 0 THEN
    --存在寄回流程
    SELECT MAX(CZSJ)
      INTO V_JCSJ
      FROM tPIF_HTLSCX
     WHERE HTID = I_HTID
       AND SQLC = '合同寄回流程'
       AND LCZT = '提交';
    SELECT MAX(ID)
      INTO V_HTSQID
      FROM LC_HTSQ T
     WHERE INSTR(';' || T.HTID || ';', ';' || I_HTID || ';') > 0
       AND FQSJ < V_JCSJ;
  
    IF V_HTSQID IS NULL THEN
      --不存在申请流程返回0
      RETURN(V_RET);
    END IF;
  
    SELECT TO_DATE(TO_CHAR(XSJSRQ), 'YYYYMMDD')
      INTO V_JSRQ
      FROM LC_HTSQ
     WHERE ID = V_HTSQID; --获取销售结束时间
  
    IF V_JSRQ IS NULL THEN
      RETURN(V_RET);
    END IF;
  
    IF V_JCSJ <= V_JSRQ + 1 THEN
      --寄出时间小于开放结束时间不算延长
      RETURN(V_RET);
    ELSE
      V_RET := ROUND(TO_NUMBER(V_JCSJ - 1 - V_JSRQ) * 24, 1);
      RETURN(V_RET);
    END IF;
  
  END IF;
  RETURN(V_RET);
EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;
/

