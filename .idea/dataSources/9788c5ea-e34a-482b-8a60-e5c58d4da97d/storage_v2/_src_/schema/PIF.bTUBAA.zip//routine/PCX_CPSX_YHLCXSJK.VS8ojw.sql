create PROCEDURE     PCX_CPSX_YHLCXSJK(CUR_RESULT OUT TYPES.CURSORTYPE) IS
  /*  项目：产品中心
      功能作用：银行理财销售监控
      创建：
      作者               版本               时间
      zjj            1.0.1             20170729


  */

  V_SQL VARCHAR2(2000);

BEGIN

  V_SQL := ' SELECT A.TJSJ as 时间,
             A.CPDM 产品代码,
             A.CPMC 产品名称,
             A.SM   销售状态
             from T_SSYHLCJK A';

  OPEN CUR_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    V_SQL := 'SELECT ' || SQLERRM || ' FROM DUAL';
    OPEN CUR_RESULT FOR V_SQL;
    /*  O_CODE := -1;
    O_NOTE := SQLERRM;*/
END PCX_CPSX_YHLCXSJK;
/

