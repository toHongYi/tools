create PROCEDURE PRO_PIF_JYRL_DDGZSZ(O_CODE  OUT NUMBER, --返回值
                                                    O_NOTE  OUT VARCHAR2, --返回消息
                                                    O_GZJL  OUT NUMBER, --规则记录ID
                                                    I_CPID  IN NUMBER, --产品ID
                                                    I_YXJYR IN NUMBER, --运行交易日
                                                    I_YWLX  IN VARCHAR2, --业务类型ID串
                                                    I_SCQJ  IN NUMBER, --生成区间
                                                    I_QJKS  IN DATE, --区间开始
                                                    I_QJJS  IN DATE, --区间结束
                                                    I_DDGZ  IN NUMBER, --定点规则ID
                                                    I_MONTH IN VARCHAR2, --固定月
                                                    I_WEEK  IN VARCHAR2, --固定星期
                                                    I_DAY   IN VARCHAR2, --固定日或星期几
                                                    I_JYRCD IN NUMBER, --交易日长度
                                                    I_JJRCL IN NUMBER, --节假日处理规则
                                                    I_CZR   IN NUMBER, --操作人或备份人
                                                    I_CZRQ  IN DATE, --操作日期或备份日期
                                                    I_SFGL  IN NUMBER, --是否关联运行交易日[1是;0否]
                                                    I_GZLX  IN NUMBER, --规则类型[1|正常;2|特殊]
                                                    I_BWL   IN VARCHAR2 DEFAULT '',
                                                    I_CPBZ IN VARCHAR2 DEFAULT '') IS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：定点规则设置

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-06-27     V1.0      谢莉莉             创建
        2016-10-20     V2.0      王大一             托管系统迁移改造接入产品中心
        2016-11-21     V2.1      王大一             初始审核状态改为：未审核
     *********************************************************************************************************************/

    V_NEWGZID NUMBER; --新规则ID
    V_CPQC    VARCHAR2(1000);
    V_COUNT   NUMBER;
    V_YXJRR   NUMBER;
    V_GZMC    VARCHAR2(1000); --规则名称

BEGIN

    O_CODE := 1;
    O_NOTE := '操作成功！';
    O_GZJL := '';
    --清盘且审核通过的产品不允许再设定规则（复制）pjf 20160727
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPDM A, TPIF_JYRL_GZJL B
     WHERE A.ID = B.CPID
       AND B.CPID = I_CPID
       AND B.SHZT = 2
       AND B.YXJYR = 17;
    --产品清盘日
    IF (V_COUNT > 0) THEN
        --取得产品名称
        SELECT CPMC INTO V_CPQC FROM TPIF_CPDM WHERE ID = I_CPID;
        O_CODE := -1;
        O_NOTE := V_CPQC || '已清盘！';
        RETURN;
    END IF;
    IF (I_DDGZ IS NOT NULL) THEN
        SELECT GZMC INTO V_GZMC FROM TPIF_JYRL_DDGZ WHERE ID = I_DDGZ;
        --只有固定星期的可以选择节假日规则为向后推一周的选项
        IF (INSTR(V_GZMC, '固定个星期') = 0 AND I_JJRCL = 3) THEN
            O_CODE := -1;
            O_NOTE := V_GZMC || '不能使用节假日处理规则【节假日后的最近一周】！';
            RETURN;
        END IF;
    END IF;

    --校验入参
    IF (I_GZLX = 1) THEN
        PRO_PIF_JYRL_GZSJJY(O_CODE, O_NOTE, I_CPID, I_SCQJ, I_QJKS, I_QJJS);
    END IF;
    IF (O_CODE > 0) THEN
        --插入新规则数据
        V_NEWGZID := LIVEBOS.FUNC_NEXTID('TPIF_JYRL_GZJL');
        --SELECT CRMII.FUNC_NEXTID('TPIF_JYRL_GZJL') INTO V_NEWGZID FROM DUAL;
        INSERT INTO TPIF_JYRL_GZJL
            (ID,
             GZJLLX,
             CPID,
             CPDM,
             YXJYR,
             YWLX,
             SCQJ,
             QJQS,
             QJJS,
             DDGZ,
             JYRCD,
             JJRCLGZ,
             CZR,
             CZRQ,
             SHZT,
             YF,
             XQ,
             RQ,
             ZDGLQTYXJYR,
             BWL,
             CPBZ)
        VALUES
            (V_NEWGZID,
             I_GZLX,
             I_CPID,
             (SELECT CPDM FROM TPIF_CPDM WHERE ID = I_CPID),
             I_YXJYR,
             I_YWLX,
             I_SCQJ,
             I_QJKS,
             I_QJJS,
             I_DDGZ,
             I_JYRCD,
             I_JJRCL,
             I_CZR,
             SYSDATE,
             0,
             I_MONTH,
             I_WEEK,
             I_DAY,
             I_SFGL,
             I_BWL,
             I_CPBZ);
        --插入规则记录备份表
        INSERT INTO TPIF_JYRL_GZJLBF
            (ID,
             GZLX,
             CPID,
             CPDM,
             YXJYR,
             YWLX,
             SCQJ,
             QJQS,
             QJJS,
             DDGZ,
             JYRCD,
             JJRCLGZ,
             CZR,
             CZRQ,
             SHZT,
             YF,
             XQ,
             RQ,
             ZDGLQTYXJYR,
             CZJL)
        VALUES
            (V_NEWGZID,
             I_GZLX,
             I_CPID,
             (SELECT CPDM FROM TPIF_CPDM WHERE ID = I_CPID),
             I_YXJYR,
             I_YWLX,
             I_SCQJ,
             I_QJKS,
             I_QJJS,
             I_DDGZ,
             I_JYRCD,
             I_JJRCL,
             I_CZR,
             SYSDATE,
             0,
             I_MONTH,
             I_WEEK,
             I_DAY,
             I_SFGL,
             TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '[用户ID:' || I_CZR || ']==>新增' ||
             CHR(10));
        COMMIT;
        O_GZJL := V_NEWGZID;
        --存入TJG_CZRZ写入操作日志PJF-201607011
        PRO_PIF_JYRL_GZJL(O_CODE, O_NOTE, I_CZR, NULL, 0, V_NEWGZID);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
        ROLLBACK;
END PRO_PIF_JYRL_DDGZSZ;
/

