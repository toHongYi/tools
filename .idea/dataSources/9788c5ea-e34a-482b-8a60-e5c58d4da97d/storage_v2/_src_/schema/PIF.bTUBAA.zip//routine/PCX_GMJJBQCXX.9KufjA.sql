create PROCEDURE PCX_GMJJBQCXX(O_CODE     OUT NUMBER,
                                              O_NOTE     OUT VARCHAR2,
                                              O_RESULT   OUT SYS_REFCURSOR,
                                              I_CURRENT  IN NUMBER, --页码
                                              I_PAGESIZE IN NUMBER, --页长
                                              I_PAGING   IN NUMBER, --是否分页
                                              I_SORT     IN STRING, --排序规模
                                              I_TOTAL    IN OUT NUMBER, --记录总数
                                              I_JJID     IN VARCHAR2,
                                              I_RQ       IN NUMBER) AS

  /*-----------------------------------------------------------------------------
  项目：智能理财
  
  功能说明：牛熊轮动统计信息
           输入参数：
           输出参数：
   --------------------------------------------------------------------------------
          操作人      版本号      时间                    操作
          张梦羽      1.0.2       2017/05/22              新增
          陈云昊      1.0.3       2020/09/07              修改分页函数
          高昆        1.0.4       2020/09/17              表名更换了，这边跟着修改一下
  -------------------------------------------------------------------------------*/

  V_CODE         NUMBER(8);
  V_NOTE         VARCHAR2(500);
  V_SQL          VARCHAR(20000);
  V_COLLIST      VARCHAR2(200);
  V_HASRECORDSET NUMBER;
  V_SORT         VARCHAR2(300);
BEGIN
  V_HASRECORDSET := 1;
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;
  --拼接查询SQL
  V_SQL := 'select a.tid      id,
       a.fundid   基金代码,
       b.jjjc     基金简称,
       (SELECT NAME FROM pif.TPIF_GMJJYJBQ WHERE ID =C.FID ) 标签类型,
       c.name     标签名称,
       c.tagid       标签ID,
       a.tagvalue 标签内容,
       b.ejfl     二级分类,
       a.batchno  报告日期
  from PRA_DISCOVERY.fund_tag_info a
  left join pra_info.FUND_CLASSIFY b
    on a.fundid = b.cpdm
  left join pif.TPIF_GMJJYJBQ c
    on c.tagid = a.tagid
 where ' || CASE
             WHEN I_JJID IS NULL THEN
              '1=1'
             ELSE
              ' a.fundid = ' || I_JJID || ''
           END || '
   and a.batchno = (select max(batchno)
                       from PRA_DISCOVERY.fund_tag_info d
                       left join pif.TPIF_GMJJYJBQ e
                         on e.tagid = d.tagid
                      where ' || CASE
             WHEN I_RQ IS NULL THEN
              '1=1 and e.gxpc = 1 )'
             ELSE
              ' batchno <= ' || I_RQ || ' and e.gxpc = 1 )  '
           END || '
   and c.gxpc = 1
   and a.tagvalue <> ''nan''
    union all
  select a.tid      id,
       a.fundid   基金代码,
       b.jjjc     基金简称,
       (SELECT NAME FROM pif.TPIF_GMJJYJBQ WHERE ID =C.FID ) 标签类型,
       c.name     标签名称,
       c.tagid       标签ID,
       a.tagvalue 标签内容,
       b.ejfl     二级分类,
       a.batchno  报告日期
  from PRA_DISCOVERY.fund_tag_info a
  left join pra_info.FUND_CLASSIFY b
    on a.fundid = b.cpdm
  left join pif.TPIF_GMJJYJBQ c
    on c.tagid = a.tagid
 where ' || CASE
             WHEN I_JJID IS NULL THEN
              '1=1'
             ELSE
              ' a.fundid = ' || I_JJID || ''
           END || '
   and a.batchno = (select max(batchno)
                       from PRA_DISCOVERY.fund_tag_info d
                       left join pif.TPIF_GMJJYJBQ e
                         on e.tagid = d.tagid
                      where  ' || CASE
             WHEN I_RQ IS NULL THEN
              '1=1  and e.gxpc = 2 )'
             ELSE
              ' batchno <= ' || I_RQ || ' and e.gxpc = 2 )  '
           END || '
   and c.gxpc = 2
   and a.tagvalue <> ''nan''
    union all
  select a.tid      id,
       a.fundid   基金代码,
       b.jjjc     基金简称,
       (SELECT NAME FROM pif.TPIF_GMJJYJBQ WHERE ID =C.FID ) 标签类型,
       c.name     标签名称,
       c.tagid       标签ID,
       a.tagvalue 标签内容,
       b.ejfl     二级分类,
       a.batchno  报告日期
  from PRA_DISCOVERY.fund_tag_info a
  left join pra_info.FUND_CLASSIFY b
    on a.fundid = b.cpdm
  left join pif.TPIF_GMJJYJBQ c
    on c.tagid = a.tagid
 where ' || CASE
             WHEN I_JJID IS NULL THEN
              '1=1'
             ELSE
              ' a.fundid = ' || I_JJID || ''
           END || '
   and a.batchno = (select max(batchno)
                       from PRA_DISCOVERY.fund_tag_info d
                       left join pif.TPIF_GMJJYJBQ e
                         on e.tagid = d.tagid
                      where  ' || CASE
             WHEN I_RQ IS NULL THEN
              '1=1 and e.gxpc = 3)'
             ELSE
              ' batchno <= ' || I_RQ || ' and e.gxpc = 3 )  '
           END || '
   and c.gxpc = 3
   and a.tagvalue <> ''nan''
    union all
  select a.tid      id,
       a.fundid   基金代码,
       b.jjjc     基金简称,
       (SELECT NAME FROM pif.TPIF_GMJJYJBQ WHERE ID =C.FID ) 标签类型,
       c.name     标签名称,
       c.tagid       标签ID,
       a.tagvalue 标签内容,
       b.ejfl     二级分类,
       a.batchno  报告日期
  from PRA_DISCOVERY.fund_tag_info a
  left join pra_info.FUND_CLASSIFY b
    on a.fundid = b.cpdm
  left join pif.TPIF_GMJJYJBQ c
    on c.tagid = a.tagid
 where ' || CASE
             WHEN I_JJID IS NULL THEN
              '1=1'
             ELSE
              ' a.fundid = ' || I_JJID || ''
           END || '
   and a.batchno = (select max(batchno)
                       from PRA_DISCOVERY.fund_tag_info d
                       left join pif.TPIF_GMJJYJBQ e
                         on e.tagid = d.tagid
                      where  ' || CASE
             WHEN I_RQ IS NULL THEN
              '1=1 and e.gxpc = 4 )'
             ELSE
              ' batchno <= ' || I_RQ || ' and e.gxpc = 4 )  '
           END || '
   and c.gxpc = 4
   and a.tagvalue <> ''nan''';

  --查询字段
  V_COLLIST := 'id,基金代码,基金简称,标签类型,标签名称,标签ID,标签内容,二级分类,报告日期';

  DBMS_OUTPUT.PUT_LINE(V_SQL);

  --分页获取数据
  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    V_CODE := -1;
    V_NOTE := '执行失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT V_CODE O_CODE, V_NOTE O_NOTE FROM DUAL;
    RETURN;
END PCX_GMJJBQCXX;
/

