create PROCEDURE PRO_PIF_JGFW_XZ(O_CODE OUT NUMBER,
                                            O_NOTE OUT VARCHAR2,
                                            I_ID   IN NUMBER --机构服务的ID
                                            ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：机构业务拓展----机构服务新增
      语法信息：
           输入参数：
  
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-08-06     1.0.0     HANQIAONAN                 新增
  ***********************************************************************/
  V_COUNT NUMBER := 0;
  V_SX    NUMBER := 1;

BEGIN
  O_CODE := -1;
  O_NOTE := '';
  --是否存在流程节点，若存在则插入流程节点表
  SELECT COUNT(1)
    INTO V_COUNT
    FROM TPIF_JGFW_JDXX
   WHERE TPIF_JGFW_ID = I_ID;

  IF V_COUNT = 0 THEN
    O_CODE := -1;
    O_NOTE := '节点流程不存在';
    RETURN;
  END IF;
  FOR CUR IN (SELECT *
                FROM TPIF_JGFW_JDXX
               WHERE TPIF_JGFW_ID = I_ID
               ORDER BY ID DESC) LOOP
    INSERT INTO TPIF_JGFWLCJD
      (ID, JGFWID, JDMC, NRJS, SX)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_JGFWLCJD'),
       I_ID,
       CUR.JDMC,
       CUR.NRJS,
       V_SX);
    V_SX := V_SX + 1;
  END LOOP;

  O_CODE := 199;
  O_NOTE := '新增成功';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

