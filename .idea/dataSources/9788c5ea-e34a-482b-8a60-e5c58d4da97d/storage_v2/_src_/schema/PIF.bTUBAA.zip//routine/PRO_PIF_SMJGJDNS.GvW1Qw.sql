create PROCEDURE PRO_PIF_SMJGJDNS( O_CODE     OUT NUMBER,   --返回值
                                              O_NOTE     OUT VARCHAR2, --返回消息
                                              I_OPER     IN INTEGER,   -- 1:审批通过
                                              I_ID       IN INTEGER    --对象ID
) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募机构尽调内审流程后台处理逻辑
      语法信息：


      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    陈勇军                创建
  ***********************************************************************/
  --V_COUNT NUMBER;

BEGIN

  IF I_OPER IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'i_OPER不能为空!';
    RETURN;
  END IF;
  --1:审批通过
  IF I_OPER = 1 THEN

     FOR CUR_IN IN( SELECT * FROM lc_SMJGJDNS_JGLB A WHERE A.LC_SMJGJDNS_ID = I_ID and a.sftg = 1 ) LOOP


        INSERT INTO TPIF_SMJGNSC( ID,
                                  JGID,
                                  JGMC,
                                  JGJC,
                                  CLRQ,
                                  DJBH,
                                  DJSJ,
                                  ZCZB,
                                  ZT,
                                  XGID,
                                  FJMC,
                                  RCSJ
                                 )
         VALUES( LIVEBOS.FUNC_NEXTID('TPIF_SMJGNSC'),
                  CUR_IN.JGID,
                  (SELECT JGMC FROM TPIF_JGDM WHERE ID = CUR_IN.JGID),
                  CUR_IN.JGJC,
                  CUR_IN.CLRQ,
                  CUR_IN.DJBH,
                  CUR_IN.DJSJ,
                  CUR_IN.ZCZB,
                  1,  --待上会
                  CUR_IN.ID,
                  CUR_IN.JDCL,
                  SYSDATE) ;


      --更新机构表信息
      UPDATE TPIF_JGDM A  SET A.jgdm = CUR_IN.jgdm,
                              A.jgjc = CUR_IN.Jgjc,
                              A.clrq = CUR_IN.clrq,
                              A.frdb = CUR_IN.frdb,
                              A.zcdz = CUR_IN.zcdz,
                              A.bgdz = CUR_IN.bgdz,
                              A.lxr = CUR_IN.lxr,
                              A.basfyx = CUR_IN.basfyx,
                              A.djbh = CUR_IN.djbh,
                              A.djsj = CUR_IN.djsj,
                              A.lxfs = CUR_IN.lxfs,
                              A.lxdz = CUR_IN.lxdz,
                              A.gswz = CUR_IN.gswz,
                              A.gsjj = CUR_IN.gsjj,
                              A.zcglgm = CUR_IN.zcglgm,
                              A.zzfxzqjjgmfw = CUR_IN.zzfxzqjjgmfw,
                              A.kggd = CUR_IN.kggd,
                              A.zczb = CUR_IN.zczb,
                              A.sjzb = CUR_IN.sjzb,
                              A.zycl = CUR_IN.zycl,
                              A.tyrygm = CUR_IN.tyrygm,
                              a.SFRGXGG = 1
             where a.id = CUR_IN.Jgid ;


     END LOOP;

     UPDATE lc_SMJGJDNS A SET A.SHZT = 2 ,A.WCRQ=TO_CHAR(SYSDATE,'YYYYMMDD') WHERE A.ID = I_ID ;







  ELSE

    NULL ;

  END IF;

  COMMIT;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
    ROLLBACK;
END;
/

