create PROCEDURE PRO_PIF_CPWDFL(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;5|变更升级节点;
                                               I_ID IN VARCHAR2, --操作ID
                                               I_OP IN VARCHAR2 := '' --其他参数
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品文档分类管理
        语法信息：
             输入参数：   I_USER  操作人
                          I_IP    操作IP
                          I_OPER  操作类型0|新增;1|修改;2|删除;5|变更升级节点;
                          I_ID    操作ID
                          I_OP    其他参数
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-15     1.0.2    徐阳                创建
            2021-09-06     1.0.3    hqn                 更新文档类型（产品、机构）
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_QXBZ  INTEGER; --权限标识
    V_OBJ   TPIF_CPWDFL%ROWTYPE; --表单记录
    V_CZBM VARCHAR2(200); --操作编码
    V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN

    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPWDFL WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  0,
                  'A00201',
                  1,
                  'A00202',
                  2,
                  'A00203',
                  5,
                  'A00204',
                  '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         5,
                         '变更节点',
                         '未知') || ']_' || V_OBJ.NAME
      INTO V_CZSM
      FROM DUAL;
    --check
   /* SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF I_IP = '[check]' THEN
            IF I_ID IS NOT NULL THEN
                SELECT COUNT(1)
                  INTO V_COUNT
                  FROM TPIF_CPWDFL
                 WHERE ID = I_ID
                   AND TYPE = 2;
                IF V_COUNT > 0 THEN
                    O_NOTE := '叶子节点不允许新增下级节点!';
                    RETURN;
                END IF;
            END IF;
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.BM IS NULL THEN
            O_NOTE := '[分类编码]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPWDFL WHERE BM = V_OBJ.BM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[分类编码]不允许重复!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[分类名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPWDFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 1 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_OBJ.FID IS NULL THEN
            UPDATE TPIF_CPWDFL
               SET FID     = 0,
                   GRADE   = 0,
                   TYPE    = 1,
                   FDNCODE = 0
             WHERE ID = I_ID;
        ELSE
            FOR CUR IN (SELECT * FROM TPIF_CPWDFL WHERE ID = V_OBJ.FID) LOOP
                UPDATE TPIF_CPWDFL
                   SET GRADE   = CUR.GRADE + 1,
                       FDNCODE = CUR.FDNCODE || '.' || CUR.ID
                 WHERE ID = I_ID;
            END LOOP;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            IF V_OBJ.GRADE = 0 THEN
                O_CODE := -1;
                O_NOTE := '根节点不允许修改！';
            END IF;
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.BM IS NULL THEN
            O_NOTE := '[分类编码]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPWDFL WHERE BM = V_OBJ.BM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[分类编码]不允许重复!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[分类名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPWDFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 1 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品根节点]!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        SELECT FUNC_PIF_JYSFYY('TPIF_CPWDFL', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前产品文档分类已存在引用记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPWDFL WHERE FID = I_ID;
        IF V_COUNT > 0 THEN
            O_NOTE := '当前节点存在下级节点!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_CPWDFL WHERE ID = I_ID;
    END IF;
    IF I_OPER = 5 THEN
        --变更上级节点-----------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPWDFL WHERE ID = I_OP) LOOP
            UPDATE TPIF_CPWDFL
               SET GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE INSTR('.' || FDNCODE || '.',
                         '.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.') > 0;
            UPDATE TPIF_CPWDFL
               SET FID     = I_OP,
                   GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE ID = I_ID;
        END LOOP;
    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;

  
    --RETURN

    --20210906hqn  文档类型设置（产品、机构）
    UPDATE TPIF_CPWDFL SET WDLX=1
    WHERE ID IN(SELECT id
        from tPIF_CPWDFL
        START WITH ID=1 CONNECT BY PRIOR ID=FID );

    UPDATE TPIF_CPWDFL SET WDLX=2
    WHERE ID IN(SELECT id
        from tPIF_CPWDFL
        START WITH ID=900009 CONNECT BY PRIOR ID=FID );

    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           5,
                           '变更升级节点',
                           '') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPWDFL;
/

