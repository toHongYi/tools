create PROCEDURE PRO_SJQX_CPXSFL_CPZX(O_CODE OUT NUMBER,
                                                 O_NOTE OUT VARCHAR2) AS
  /******************************************************************
      所属用户：PIF
      功能说明：产品销售分类-产品中心-数据清洗逻辑
  
  
  
      语法信息：
           输入参数：    见参数定义
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
           修订日期        版本号     修订人             修改内容简要说明
          2021-8-03        1.0.0     LILIANG               新增
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  -- 更新最新标签
  MERGE INTO TPIF_CPBQMX T
  USING (SELECT A.CPDM, A.CPID, C.ID AS CPBQ
           FROM TPIF_CPDM A, SRC_PIF.SALE_PROD_TYPE_INFO B, TPIF_CPBQ C
          WHERE A.CPDM = B.PROD_CODE
            AND INSTR(C.MC, B.PROD_CATEGORY) > 0
            AND C.BQLX IN (900012, 900013, 900014)
            AND B.IS_DELETE = 0) S
  ON (T.CPID = S.CPID AND T.CPBQ IN (SELECT ID
                                       FROM TPIF_CPBQ C
                                      WHERE C.BQLX IN
                                            (900012, 900013, 900014))) --产品和标签
  WHEN MATCHED THEN
    UPDATE SET T.CPBQ = S.CPBQ, T.CZSJ = SYSDATE
  WHEN NOT MATCHED THEN
    INSERT
      (T.ID, T.CPBQ, T.CPID, T.XSSX, T.YSLY, T.CZSJ) --XSSX显示顺序，目前看没用，YSLY映射来源，1|系统标签;2|手工标签;
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPBQMX'),
       S.CPBQ,
       S.CPID,
       S.CPID,
       1,
       SYSDATE);

  /*更新 DSC_STAT.TPIF_STAT_CPDXYB（中间表） 、
    DSC_STAT.TPIF_STAT_CPDXYB_HZTJ（汇总表），
    执行过程 PIF.PRO_SJQX_STAT_CPDXYB，
    该过程初次全量执行，后续只执行当月的，
    如果没有更新成功，可以执行下面SQL，更新产品代销月表，
  */

  MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB M
  USING (SELECT A.CPDM, --产品代码
                CASE
                  WHEN C.BQLX = 900012 THEN
                   '固收类'
                  WHEN C.BQLX = 900013 THEN
                   '权益类'
                  WHEN C.BQLX = 900014 THEN
                   '货币类'
                END AS BQLXMC, --标签类型名称
                C.BQLX AS BQLXID, --标签类型ID
                CASE
                  WHEN C.MC LIKE '公募%' THEN
                   1
                  WHEN C.MC LIKE '私募%' THEN
                   2
                  WHEN C.MC LIKE '收益%' THEN
                   4
                  WHEN C.MC LIKE '信托%' THEN
                   8
                  WHEN C.MC LIKE '固定%' THEN
                   13
                END AS XSCPXL --销售产品系列
           FROM TPIF_CPDM A, TPIF_CPBQMX B, TPIF_CPBQ C
          WHERE A.CPID = B.CPID
            AND B.CPBQ = C.ID
            AND C.BQLX IN (900012, 900013, 900014)) N
  ON (TRIM(M.CPDM) = TRIM(N.CPDM))
  WHEN MATCHED THEN
    UPDATE
       SET M.BQLXID = N.BQLXID, M.BQLXMC = N.BQLXMC, M.XSCPXL = N.XSCPXL;

  MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB_HZTJ M
  USING (SELECT YF,
                YYBID,
                ROUND(SUM(XSL) / 10000, 2) AS XSL,
                ROUND(SUM(NBYL) / 10000, 2) AS NBYL,
                BQLXID,
                BQLXMC,
                XSCPXL
           FROM DSC_STAT.TPIF_STAT_CPDXYB
          WHERE BQLXID IS NOT NULL
            AND XSCPXL IS NOT NULL
          GROUP BY YF, YYBID, BQLXID, BQLXMC, XSCPXL) N
  ON (M.YF = N.YF AND M.YYBID = N.YYBID AND M.BQLXID = N.BQLXID AND M.XSCPXL = N.XSCPXL)
  WHEN MATCHED THEN
    UPDATE SET M.XSL = N.XSL, M.NBYL = N.NBYL, M.BQLXMC = N.BQLXMC
  WHEN NOT MATCHED THEN
    INSERT
      (M.YF, M.YYBID, M.XSL, M.NBYL, M.BQLXID, M.BQLXMC, M.XSCPXL)
    VALUES
      (N.YF, N.YYBID, N.XSL, N.NBYL, N.BQLXID, N.BQLXMC, N.XSCPXL);

  COMMIT;
  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '产品销售分类-产品中心-数据清洗逻辑,未知错误'
                ELSE
                 '产品销售分类-产品中心-数据清洗逻辑,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
  
END;
/

