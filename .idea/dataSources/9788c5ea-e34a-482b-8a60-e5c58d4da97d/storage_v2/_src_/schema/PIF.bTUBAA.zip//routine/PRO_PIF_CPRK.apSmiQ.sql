create PROCEDURE PRO_PIF_CPRK(O_CODE    OUT NUMBER,
                                         O_NOTE    OUT VARCHAR2,
                                         I_USER    IN NUMBER,
                                         I_CPDM    IN VARCHAR, --产品代码
                                         I_CPMC    IN VARCHAR, --产品名称
                                         I_CPLX    IN NUMBER,
                                         I_JRCPFL  IN VARCHAR2,
                                         I_GLRID   IN NUMBER,
                                         I_CPTGR   IN VARCHAR2

                                         ) AS

  /*--------------------------------------------------------------------------------------------

  项目名称：产品中心标准版本

         功能说明：产品入库


        ----------------------------------------------------------
        操作人   版本号     时间                       操作
      TIANHAONAN   1.0    20190814
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER;
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TPIF_CPDM
   WHERE CPDM = I_CPDM ;

  IF V_COUNT > 0 THEN

    UPDATE PIF.TPIF_CPDM
       SET CPXL    = I_CPLX,
           JRCPFL  = I_JRCPFL,
           CPGLRID    = I_GLRID,
           CPTGR = I_CPTGR,
           CPMC = I_CPMC
     WHERE CPDM = I_CPDM ;

  ELSE

    INSERT INTO PIF.TPIF_CPDM
      (ID,
       CPID,
       CPDM,
       CPMC,
       CPJC,
       CPNBZT,
       PT,
       CPXL,
       JRCPFL,
       CPGLRID,
       CPTGR,
       RKSJ,
       RKCZR,
       CPJYZT)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPDM'),
       NULL,
       I_CPDM,
       I_CPMC,
       I_CPMC,
       1,
       3,
       I_CPLX,
       I_JRCPFL,
       I_GLRID,
       I_CPTGR,
       SYSDATE,
       I_USER,
       6  --停止交易
       );

    UPDATE PIF.TPIF_CPDM SET CPID = ID WHERE CPDM = I_CPDM;

  END IF;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败,' || SQLERRM;
END;
/

