create PROCEDURE PRO_PIF_YYGL_MAIN(O_CODE OUT NUMBER,
                                                  O_NOTE OUT VARCHAR2,
                                                  I_RQ   NUMBER DEFAULT NULL --日期
                                                  ) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：运营管理调度主过程
            I_RQ    --日期
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
         关联调度
    运行原理：
          1.入参校验
          --1.1入参校验
          --1.2初始赋值
          2.产品事件生成。
          3.运营任务生成。
          4.同步任务中心。
         5.邮件通知执行人。
    功能修订：
        简要说明：
          运营管理调度主过程
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/14     1.0.1     林嵩              运营管理调度主过程。
        2015/01/27     1.0.2     刘浪浪            日期入参由VARCHAR2改为NUMBER
    *********************************************************************************************************************/
    V_RQ NUMBER(8) DEFAULT I_RQ; --当前日期
BEGIN

    O_CODE := 1;
    O_NOTE := '成功';
    --0.遍历所有产品，把满足条件的产品加入运营计划中，每天跑
   -- PRO_PIF_YYGL_ZDSCYYJH(O_CODE, O_NOTE);

    --1.***************************入参校验 ***************************
    --当前变量赋值
    IF V_RQ IS NULL THEN
        V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
    END IF;
    --2.***************************产品事件生成***************************
    PRO_PIF_YYGL_MAIN_CPSJSC(O_CODE, O_NOTE, V_RQ);
    IF O_CODE < 0 THEN
        O_CODE := -1;
        O_NOTE := '错误：产品事件生成失败!';
        RETURN;
    END IF;
    --3.***************************运营任务生成***************************
    IF O_CODE > 0 THEN
        PRO_PIF_YYGL_MAIN_YYRWSC(O_CODE, O_NOTE, V_RQ, NULL);
        IF O_CODE < 0 THEN
            O_CODE := -1;
            O_NOTE := '错误：运营任务生成失败!';
            RETURN;
        END IF;
    END IF;
  /*  --4.***************************同步任务中心***************************
    PRO_PIF_YYGL_TBRWZX(O_CODE, O_NOTE, V_RQ, NULL);
    IF O_CODE < 0 THEN
        O_NOTE := O_NOTE || '。提示：同步任务中心失败！';
    END IF;
    --5.***************************邮件通知执行人***************************
    PRO_PIF_YYGL_TZ_YJ(O_CODE, O_NOTE, V_RQ, NULL);
    IF O_CODE < 0 THEN
        O_NOTE := O_NOTE || '。提示：邮件通知执行人失败！';
    END IF;*/
    --6.提交数据
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_MAIN;
/

