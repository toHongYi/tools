create PROCEDURE PRO_PIF_LCFQ_SMJGBMDLC(O_CODE   OUT NUMBER, --返回值
                                                   O_NOTE   OUT VARCHAR2, --返回消息
                                                   O_INSTID OUT NUMBER, --流程实例ID
                                                   
                                                   I_FORMVALUES      IN VARCHAR2, --字符串（JSON）,流程表单数据
                                                   I_WORKFLOWCREATOR IN VARCHAR2, --流程发起人，为单值，同OA登录名一致
                                                   I_WORKFLOWKEYWORD IN VARCHAR2 --流程关键字，预留
                                                   
                                                   ) IS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：流程发起后台处理逻辑--私募机构白名单流程
      语法信息：
           输入参数：   。。。。
           输出参数：   O_CODE    返回值
                       O_NOTE    返回消息
                       O_INSTID  流程实例ID
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-07     1.0.0    WUJINFENG                创建
  ***********************************************************************/
  V_NUMNEWINSTID  NUMBER; --流程实例ID
  V_NUMNEWSTEPID  NUMBER; --启动步骤ID
  V_NUMNEWSTEPID1 NUMBER; --下一步骤ID
  V_ZT            VARCHAR2(300);
  V_OWNER         VARCHAR(1000);
  v_count         number;

BEGIN
  --INIT
  O_CODE := 99;
  O_NOTE := '';
  O_INSTID := -1 ;
  select count(*) into v_count from LC_SMJGBMDLC where JGDM = PARSEJSON(I_FORMVALUES, 'orgCode') ;
  
  if v_count > 0 then
    
     O_NOTE := '机构代码已存在，请检查FORMVALUES参数';
     return;
  
  end if;


  --{"workflowTheme":"杭州拓源股权投资管理有限公司白名单流程申请","orgCode":"MA2HYB3D7", "orgName":"MA2HYB3D7", "foundationDate":"20200617","regAddress":"浙江省杭州市余杭区仓前街道景兴路999号6幢209-6-220", "remark":""}

  /************1、获取相关参数***************/

  --生成流程实例化ID
  SELECT LIVEBOS.SEQ_OS_WFENTRY.NEXTVAL INTO V_NUMNEWINSTID FROM DUAL;
  --生成启动步骤ID
  SELECT LIVEBOS.SEQ_OS_CURRENTSTEPS.NEXTVAL INTO V_NUMNEWSTEPID FROM DUAL;
  --下一步骤ID
  SELECT LIVEBOS.SEQ_OS_CURRENTSTEPS.NEXTVAL
    INTO V_NUMNEWSTEPID1
    FROM DUAL;
  --获取流程主题
  SELECT PARSEJSON(I_FORMVALUES, 'workflowTheme') INTO V_ZT FROM DUAL;
  --获取下一步审批人员
  SELECT TO_CHAR(WMSYS.WM_CONCAT(A.USERID))
    INTO V_OWNER --下一步流程审核人
    FROM LIVEBOS.LBMEMBER A
   WHERE A.ROLEID = (SELECT ID FROM LIVEBOS.LBROLE WHERE ROLECODE = 'SMJGB_BMFZ'); --私募机构部部门副总

  /************2、入数据到工作量表单中 ***************/
  INSERT INTO LC_SMJGBMDLC
    (ID,
     INSTID,
     ZT,
     SQR,
     SQRQ,
     SHZT,
     --WCRQ, 
     JGDM,
     JGMC,
     CLRQ,
     ZCDZ
     --LXR, 
     --LXFS, 
     --GLRJDBG, 
     --GLRJDCL, 
     --BMDCP
     )
    SELECT LIVEBOS.FUNC_NEXTID('lc_SMJGBMDLC'),
           V_NUMNEWINSTID,
           V_ZT,
           (SELECT ID
              FROM LIVEBOS.TUSER
             WHERE USERID = I_WORKFLOWCREATOR
               AND ROWNUM = 1),
           SYSDATE,
           1,
           PARSEJSON(I_FORMVALUES, 'orgCode'),
           PARSEJSON(I_FORMVALUES, 'orgName'),
           PARSEJSON(I_FORMVALUES, 'foundationDate'),
           PARSEJSON(I_FORMVALUES, 'regAddress')
      FROM DUAL;

  /************3、插入os_wfentry ***************/
  INSERT INTO LIVEBOS.OS_WFENTRY
    (ID, NAME, STATE, INITIATOR, INIT_DATE, SUBJECT)
    SELECT V_NUMNEWINSTID, 'WF_SMJGBMDLCGZL', 1, 0, SYSDATE, V_ZT
      FROM DUAL;

  /************4、插入os_currentstep ***************/
  INSERT INTO LIVEBOS.OS_CURRENTSTEP
    (ID,
     ENTRY_ID,
     STEP_ID,
     ACTION_ID,
     OWNER,
     START_DATE,
     FINISH_DATE,
     DUE_DATE,
     STATUS,
     CALLER,
     SUMMARY,
     CONSIGNER)
    SELECT V_NUMNEWSTEPID,
           V_NUMNEWINSTID,
           4,
           NULL,
           0,
           SYSDATE,
           NULL,
           NULL,
           '待处理',
           NULL,
           NULL,
           NULL
      FROM DUAL;

  /************5、插入OS_HistoryStep ***************/
  INSERT INTO LIVEBOS.OS_HISTORYSTEP
    (ID,
     ENTRY_ID,
     STEP_ID,
     ACTION_ID,
     OWNER,
     START_DATE,
     FINISH_DATE,
     DUE_DATE,
     STATUS,
     CALLER,
     SUMMARY,
     CONSIGNER)
    SELECT ID,
           ENTRY_ID,
           STEP_ID,
           5,
           OWNER,
           START_DATE,
           SYSDATE,
           DUE_DATE,
           '完成',
           0,
           NULL,
           NULL
      FROM LIVEBOS.OS_CURRENTSTEP
     WHERE ID = V_NUMNEWSTEPID;

  /************6、插入OS_HistoryStep_Prev ***************/
  INSERT INTO LIVEBOS.OS_HISTORYSTEP_PREV
    (ID, PREVIOUS_ID)
    SELECT ID, PREVIOUS_ID
      FROM LIVEBOS.OS_CURRENTSTEP_PREV
     WHERE ID = V_NUMNEWSTEPID;

  /************7、更新os_currentstep ***************/
  UPDATE LIVEBOS.OS_CURRENTSTEP
     SET ID = V_NUMNEWSTEPID1, STEP_ID = 5, OWNER = V_OWNER
   WHERE ID = V_NUMNEWSTEPID;

  /************8、插入OS_CurrentStep_Prev ***************/
  INSERT INTO LIVEBOS.OS_CURRENTSTEP_PREV
    (ID, PREVIOUS_ID)
    SELECT V_NUMNEWSTEPID1, V_NUMNEWSTEPID FROM DUAL;

  /************9、插入lbwfcurrentowner（当前步骤执行人） ***************/
  FOR Y IN (SELECT DISTINCT A.ID
              FROM LIVEBOS.TUSER A
             WHERE 1 = 1
               AND instr(',' || V_OWNER || ',', ',' || A.ID || ',') > 0
             ORDER BY A.ID) LOOP
    INSERT INTO LIVEBOS.LBWFCURRENTOWNER
      (ID, STEPID, OWNER, FLAG, STATUS)
      SELECT livebos.S_LBWFCURRENTOWNER.NEXTVAL,
             V_NUMNEWSTEPID1,
             Y.ID,
             1,
             NULL
        FROM DUAL;
  END LOOP;

  --RETURN

  SELECT NVL(MAX(ID), 2)
    INTO O_INSTID
    FROM LIVEBOS.TSEQUENCE
   WHERE UPPER(NAME) = UPPER('lc_SMJGBMDLC');
  O_CODE := 1;
  O_NOTE := '成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

