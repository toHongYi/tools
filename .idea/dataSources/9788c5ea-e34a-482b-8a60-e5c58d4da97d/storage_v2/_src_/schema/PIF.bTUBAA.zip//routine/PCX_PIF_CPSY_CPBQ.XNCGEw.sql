create PROCEDURE PCX_PIF_CPSY_CPBQ(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              I_PROD_LABEL   IN NUMBER --产品标签ID
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品首页-查询产品标签
  所属用户：PIF
  数据准备：
      PIF.TFP_CPLX 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品专区列表.
  
        1.查询产品专区列表.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/11/11     1.0.1    guonanhua           新增.
      2015/02/03     1.0.2    刘浪浪              增加产品代码返回值
  *********************************************************************************************************************/
  V_ERRMSG VARCHAR2(300); --错误信息
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_PROD_LABEL IS NULL THEN
  
    OPEN O_RESULT FOR
      SELECT T.ID LABEL_ID, 
             T.LABEL_NAME LABEL_NAME, 
             T.DISPLAY_ORDER DISPLAY_ORDER
        FROM PIF.tPROD_LABEL T
       WHERE T.LABEL_STATUS = 1;
  
  ELSE
  
    OPEN O_RESULT FOR
      SELECT C.ID prod_id,
             C.PROD_FULLNAME PROD_NAME,
             C.PROD_CODE PROD_CODE,
             C.PROD_MANAGER PROD_MANAGER,
             (SELECT NOTE
                FROM LIvebos.TXTDM T
               WHERE T.FLDM = 'D_PROD_RISK_LEVEL'
                 AND T.IBM = C.PROD_RISK_LEVEL) PROD_RISK_LEVEL,
             C.LOWEST_EXPECTED_YIELD_RATE EXPECTED_YIELD_RATE,
             TO_CHAR(C.INDV_SUBSCRIBE_ORIGIN, 'FM999,999,990.0000') SUBSCRIBE_ORIGIN,
             (SELECT NOTE
                FROM LIvebos.TXTDM T
               WHERE T.FLDM = 'D_PROD_PHASE'
                 AND T.IBM = C.PROD_PHASE) PROD_PHASE,
             A.DISPLAY_ORDER DISPLAY_ORDER
        FROM PIF.tPROD_BASIC_INFO  C, PIF.tPROD_LABEL_DETAILS A, PIF.tPROD_LABEL B
       WHERE C.ID = A.PROD_ID
         AND B.ID = A.PROD_LABEL
         AND B.LABEL_STATUS = 1
         AND A.PROD_LABEL = I_PROD_LABEL;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || V_ERRMSG FROM DUAL;
  
END PCX_PIF_CPSY_CPBQ;
/

