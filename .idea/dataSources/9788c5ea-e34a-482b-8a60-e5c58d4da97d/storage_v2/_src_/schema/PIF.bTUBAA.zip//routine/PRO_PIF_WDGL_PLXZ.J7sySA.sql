create PROCEDURE PRO_PIF_WDGL_PLXZ(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2,
                                              I_IDS  IN VARCHAR2, --ID串
                                              I_YHID IN NUMBER
                                              
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  功能说明：文档管理-文档批量下载
  参数说明：
      入参：
       I_IDS   IN  NUMBER     --登陆用户ID
      出参：
       O_CODE   OUT   NUMBER,
       O_NOTE   OUT   VARCHAR2
        ----------------------------------------------------------
        操作人       版本号      时间                        操作
        HANQIAONAN    1.0        2020/09/01                  新增
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER; --计数
  V_IDS   VARCHAR2(5000);
  V_NUM   NUMBER := 1;
  V_ID    NUMBER;
  V_XZQD  NUMBER;
  V_LEN   NUMBER; --长度
BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';
  V_IDS  := ';'||I_IDS || ';';
  --获取需要插入的ID数量
  SELECT LENGTH(V_IDS) - LENGTH(REPLACE(V_IDS, ';'))-1
    INTO V_COUNT
    FROM DUAL;

  IF V_COUNT = 1 THEN
    INSERT INTO TPIF_WDXZRZ
      (ID, WDID, XZQD, SJ, CZR)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_WDXZRZ'),
       TO_NUMBER(I_IDS),
       NULL,
       SYSDATE,
       I_YHID);
  ELSE
    WHILE V_NUM <= V_COUNT LOOP
      SELECT INSTR(V_IDS, ';', 1, V_NUM+1) -
             INSTR(V_IDS, ';', 1, V_NUM) -1
        INTO V_LEN
        FROM DUAL;
      SELECT TO_NUMBER(SUBSTR(V_IDS,
                              INSTR(V_IDS, ';', 1, V_NUM)+1,
                              V_LEN))
        INTO V_ID
        FROM DUAL;
    
      INSERT INTO TPIF_WDXZRZ /*计入下载日志*/
        (ID, WDID, XZQD, SJ, CZR)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_WDXZRZ'),
         TO_NUMBER(V_ID),
         NULL,
         SYSDATE,
         I_YHID);
       V_NUM:=V_NUM+1;
    END LOOP;
  END IF;
  
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
  
END;
/

