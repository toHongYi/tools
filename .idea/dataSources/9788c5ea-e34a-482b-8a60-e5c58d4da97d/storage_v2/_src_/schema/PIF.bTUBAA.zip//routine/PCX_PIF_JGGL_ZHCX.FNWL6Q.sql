create PROCEDURE     PCX_PIF_JGGL_ZHCX(O_CODE               OUT NUMBER,
                                              O_NOTE               OUT VARCHAR2,
                                              O_HASRECORDSET       OUT INTEGER, --是否存在返回结果集
                                              O_RESULT             OUT SYS_REFCURSOR,
                                              I_CURRENT            IN NUMBER, --页码
                                              I_PAGESIZE           IN NUMBER, --页长
                                              I_PAGING             IN NUMBER, --是否分页
                                              I_SORT               IN VARCHAR2, --排序规模
                                              I_TOTAL              IN OUT NUMBER, --记录总数
                                              I_USERID             IN NUMBER, --登陆用户ID
                                              I_ORG_TYPE	         IN VARCHAR2, --机构分类
                                              I_COOPERATION_ACCESS IN VARCHAR2, --合作准入    1|管理人准入;2|FOF准入;3|策略准入;4|产品准入
                                              I_COOPERATION_LEVEL  IN VARCHAR2, --合作等级   1|战略合作;2|重点合作;3|一般上线
                                              I_KEY_WORD           IN VARCHAR2, --搜索关键字
                                              I_ORG_STATUS         IN VARCHAR2 --机构状态   1|审核中;2|审核完成;3|审核不通过
                                              
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：机构管理-机构综合查询
  
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
  
  
  
        ----------------------------------------------------------
        操作人       版本号      时间                        操作
        WUJINFENG    1.0        2020/06/29                  新增
  -------------------------------------------------------------------------------------------------*/
  V_SQL          VARCHAR2(8000);
  V_SORT         VARCHAR2(200);
  V_COLLIST      VARCHAR2(500);
  V_HASRECORDSET NUMBER;

BEGIN
  O_CODE         := 1;
  O_NOTE         := '成功!';
  V_HASRECORDSET := 1;
  o_Hasrecordset := 1;
  I_TOTAL        := -1;
  V_SORT         := I_SORT;

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;
  
  IF I_ORG_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_ORG_TYPE不能为空!';
    RETURN;
  END IF;
  /*ID  ID
     ORG_CODE  机构代码
     ORG_NAME  机构名称
     ORG_SIMP_NAME 机构简称
     ESTABLISH_TIME  成立时间
     LEGALREP  法人代表
     REG_ADDRESS 注册地址
     OFFICE_ADDRESS  办公地址
     CONTACT 联系人
     CONTACT_METHOD  联系方式
     CONTROL_HOLDER  控股股东
     REG_CAPITAL 注册资本（万元）
     COOPERATION_ACCESS  合作准入
     QUASI_ENTRY_POLICY  准入策略
     COOPERATION_LEVEL 合作等级
     CORP_CLASS  公司分类  
     BUSINESS_QUALIFY  业务资质
     MANAGE/_SERVICE_SCALE 管理/服务规模
     EFFECT_DAY  尾佣生效日
     ORG_STATUS  机构状态  1|有效;2|无效
     AUDIT_STATUS  审核状态
  */
  V_SQL := ' SELECT ID,
                    JGDM AS ORG_CODE,
                    JGMC AS ORG_NAME,
                    JGJC AS ORG_SIMP_NAME,
                    CLRQ AS ESTABLISH_TIME,
                    FRDB AS LEGALREP,
                    ZCDZ AS REG_ADDRESS,
                    BGDZ AS OFFICE_ADDRESS,
                    LXR AS CONTACT,
                    LXFS AS CONTACT_METHOD,
                    KGGD AS CONTROL_HOLDER,
                    ZCZB AS REG_CAPITAL,
                    (select NOTE from livebos.txtdm b where b.fldm=''PIF_GLRHZZR'' and b.ibm=HZZR) AS COOPERATION_ACCESS,
                    (select NOTE from livebos.txtdm b where b.fldm=''PIF_GLRHZDJ'' and b.ibm=HZDJ) AS COOPERATION_LEVEL,
                    (select NOTE from livebos.txtdm b where b.fldm=''PIF_GLR_GSFL'' and b.ibm=GSFL) AS CORP_CLASS,
                    YWZZ AS BUSINESS_QUALIFY,
                    GLFWGM AS MANAGE_SERVICE_SCALE,
                    (select NOTE from livebos.txtdm b where b.fldm=''PIF_WYSXR'' and b.ibm=WYSXR) AS EFFECT_DAY,
                    DECODE(ZT,1,''有效'',2,''无效'')    AS ORG_STATUS,   
                    DECODE(SHZT,1,''审核中'',2,''审核完成'',3,''审核未通过'')  AS AUDIT_STATUS
             FROM TPIF_JGDM A WHERE GSFL= '|| I_ORG_TYPE;

  --I_COOPERATION_ACCESS  IN VARCHAR2, --合作准入    1|管理人准入;2|FOF准入;3|策略准入;4|产品准入
  IF I_COOPERATION_ACCESS IS NOT NULL THEN
  
    V_SQL := V_SQL || ' AND INSTR('';''||''' || I_COOPERATION_ACCESS ||
             '''||'';'','';''||A.HZZR||'';'') >0 ';
  
  END IF;

  --I_COOPERATION_LEVEL IN VARCHAR2,   --合作等级   1|战略合作;2|重点合作;3|一般上线
  IF I_COOPERATION_LEVEL IS NOT NULL THEN
  
    V_SQL := V_SQL || ' AND INSTR('';''||''' || I_COOPERATION_LEVEL ||
             '''||'';'','';''||A.HZDJ||'';'') >0 ';
  
  END IF;

  --I_KEY_WORD  IN VARCHAR2,           --搜索关键字
  IF I_KEY_WORD IS NOT NULL THEN
  
    V_SQL := V_SQL || ' AND ( A.JGMC LIKE ''%' || I_KEY_WORD ||
             '%''  OR  A.JGDM LIKE ''%' || I_KEY_WORD || '%'') ';
  
  END IF;

  --I_ORG_STATUS  IN VARCHAR2,         --机构状态   1|审核中;2|审核完成;3|审核不通过
  IF I_ORG_STATUS IS NOT NULL THEN
  
    V_SQL := V_SQL || ' AND INSTR('';''||''' || I_ORG_STATUS ||
             '''||'';'','';''||A.SHZT||'';'') >0 ';
  
  END IF;
  --DBMS_OUTPUT.put_line(V_SQL);

  IF V_SORT IS NULL THEN
    V_SORT := ' ID DESC ';
  END IF;

  V_COLLIST := 'ID, ORG_CODE, ORG_NAME, ORG_SIMP_NAME, ESTABLISH_TIME, LEGALREP,REG_ADDRESS, OFFICE_ADDRESS, CONTACT, CONTACT_METHOD,CONTROL_HOLDER, REG_CAPITAL,COOPERATION_ACCESS, COOPERATION_LEVEL,CORP_CLASS, BUSINESS_QUALIFY, MANAGE_SERVICE_SCALE,  EFFECT_DAY, ORG_STATUS, AUDIT_STATUS';
  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

