create PROCEDURE pcx_ProdSaleDate(O_CODE      OUT NUMBER,
                                             O_NOTE      OUT VARCHAR2,
                                             O_RESULT    OUT SYS_REFCURSOR,
                                             I_PROD_CODE IN VARCHAR2 --产品代码
                                             ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品销售控制属性查询
      语法信息：
           输入参数：   I_PROD_CODE  IN   VARCHAR2   --产品代码
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000002');
  V_COUNT NUMBER;
  V_JKLX  NUMBER;
BEGIN

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
        GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;



  OPEN O_RESULT FOR
    SELECT B.EXPECTED_SHARE_CONFIRM_DAY, --预计份额确认日
           B.EXPECTED_YIELD_ARRIVED_DAY, --预计收益到账日
           B.EXPECTED_REDEEM_CONFIRM_DAY, --预计赎回确认日
           B.EXPECTED_FUND_ARRIVED_DAY --预计资金到账日
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_SALE_CENTER_INFO B
     WHERE A.ID = B.PROD_ID
       AND A.PROD_CODE = I_PROD_CODE;
  O_CODE := 0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT B.EXPECTED_SHARE_CONFIRM_DAY, --预计份额确认日
           B.EXPECTED_YIELD_ARRIVED_DAY, --预计收益到账日
           B.EXPECTED_REDEEM_CONFIRM_DAY, --预计赎回确认日
           B.EXPECTED_FUND_ARRIVED_DAY --预计资金到账日
      FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_SALE_CENTER_INFO B
     WHERE A.ID = B.PROD_ID
       AND A.PROD_CODE = I_PROD_CODE
       AND 1 = 2;
  END IF ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

