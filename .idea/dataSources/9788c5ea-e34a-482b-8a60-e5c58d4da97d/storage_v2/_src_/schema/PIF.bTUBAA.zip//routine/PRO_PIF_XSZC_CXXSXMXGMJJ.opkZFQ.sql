create PROCEDURE PRO_PIF_XSZC_CXXSXMXGMJJ(O_CODE OUT NUMBER, --返回值
                                                         O_NOTE OUT VARCHAR2, --返回消息
                                                         I_USER IN INTEGER, --操作人
                                                         I_IP   IN VARCHAR2, --操作IP
                                                         I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|发布;4|上移;5|下移;6|转历史;7|结束时间维护;8|附件上传
                                                         I_ID   IN INTEGER --操作ID
                                                         ) IS
    /*
    **功能说明：持续销售项目型公募基金管理
    **创建人： 甘霖
    **创建日期：2017-05-05
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    ** 陈勇军    1.0.1     2017-05-21    修改日志记录功能
    */

    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_XSZC_CXXSXMXGMJJ%ROWTYPE; --表单记录
    V_CPID  NUMBER(30);
    V_ZSSX  NUMBER(20);
    V_CZBM  VARCHAR2(200); --操作编码
    V_CZSM  VARCHAR2(2000); --日志操作明细

BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_XSZC_CXXSXMXGMJJ WHERE ID = I_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            O_NOTE := '未找到数据';
            RETURN;
    END;

    SELECT DECODE(I_OPER,
                  0,
                  '400301',
                  1,
                  '400302',
                  2,
                  '400303',
                  3,
                  '400304',
                  4,
                  '400306',
                  5,
                  '400307',
                  6,
                  '400305',
                  7,
                  '400308',
                  8,
                  '400309')
      INTO V_CZBM
      FROM DUAL;

    SELECT '[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '发布',
                         4,
                         '上移',
                         5,
                         '下移',
                         6,
                         '转历史',
                         7,
                         '结束时间维护',
                         8,
                         '附件上传') || ']_' || V_OBJ.CPMC
      INTO V_CZSM
      FROM DUAL;
    --CHECK
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;

    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN

        --//:新增
        IF V_OBJ.CPDM IS NULL THEN
            O_NOTE := '[产品代码]不允许为空!';
            RETURN;
        END IF;
        --判断是否有重复记录
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSXMXGMJJ WHERE CPDM = V_OBJ.CPDM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[产品代码]为' || V_OBJ.CPDM || '记录已经存在，不允许重复添加！';
            RETURN;
        END IF;
        IF V_OBJ.CPMC IS NULL THEN
            O_NOTE := '[产品名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FXDJ IS NULL THEN
            O_NOTE := '[风险等级]不允许为空!';
            RETURN;
        END IF;
         IF V_OBJ.KSRQ>V_OBJ.JSRQ THEN
            O_NOTE := '[开始日期]不能大于[结束日期]';
            RETURN;
          END IF;
        UPDATE TPIF_XSZC_CXXSXMXGMJJ
           SET ZSSX =
               (SELECT NVL(MAX(T.ZSSX), 0) + 1 FROM TPIF_XSZC_CXXSXMXGMJJ T)
         WHERE ID = I_ID;
    END IF;
    IF I_OPER = 1 THEN
        --//:修改
        IF V_OBJ.CPDM IS NULL THEN
            O_NOTE := '[产品代码]不允许为空!';
            RETURN;
        END IF;
        --判断是否有重复记录
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSXMXGMJJ WHERE CPDM = V_OBJ.CPDM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[产品代码]为' || V_OBJ.CPDM || '记录已经存在，不允许重复添加！';
            RETURN;
        END IF;
        IF V_OBJ.CPMC IS NULL THEN
            O_NOTE := '[产品名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FXDJ IS NULL THEN
            O_NOTE := '[风险等级]不允许为空!';
            RETURN;
        END IF;
         IF V_OBJ.KSRQ>V_OBJ.JSRQ THEN
            O_NOTE := '[开始日期]不能大于[结束日期]';
            RETURN;
          END IF;
    END IF;
    IF I_OPER = 2 THEN
        --//:删除
        DELETE FROM TPIF_XSZC_CXXSXMXGMJJ I WHERE I.ID = I_ID;
    END IF;

    IF I_OPER = 3 THEN
        --//:发布
        IF V_OBJ.FBBS = 1 THEN
            O_NOTE := '当前信息已发布!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        --//:发布
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSXMXGMJJ_FJ WHERE TPIF_XSZC_CXXSXMXGMJJ_ID = I_ID;
        IF V_COUNT > 0 AND V_OBJ.CPBS IS NULL THEN
            O_NOTE := '因已上传附件,请选择【关联产品】!';
            RETURN;
        END IF;
        UPDATE PIF.TPIF_XSZC_CXXSXMXGMJJ T
           SET T.FBBS = 1, T.FBRQ = TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'))
         WHERE ID = I_ID;
    END IF;

    IF I_OPER = 4 THEN
        --//:上移
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSXMXGMJJ WHERE ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前产品目录内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_XSZC_CXXSXMXGMJJ
         WHERE ID != I_ID
           AND ZSSX > V_OBJ.ZSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前数据已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.ZSSX
          INTO V_CPID, V_ZSSX
          FROM TPIF_XSZC_CXXSXMXGMJJ T
         WHERE T.ID != I_ID
           AND T.ZSSX = (SELECT MIN(A.ZSSX)
                           FROM TPIF_XSZC_CXXSXMXGMJJ A
                          WHERE A.ID != I_ID
                            AND A.ZSSX > V_OBJ.ZSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_XSZC_CXXSXMXGMJJ SET ZSSX = V_ZSSX WHERE ID = I_ID;
        UPDATE TPIF_XSZC_CXXSXMXGMJJ SET ZSSX = V_OBJ.ZSSX WHERE ID = V_CPID;
    END IF;

    IF I_OPER = 5 THEN
        --//:下移
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSXMXGMJJ WHERE ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前产品目录内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_XSZC_CXXSXMXGMJJ
         WHERE ID != I_ID
           AND ZSSX < V_OBJ.ZSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前数据已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.ZSSX
          INTO V_CPID, V_ZSSX
          FROM TPIF_XSZC_CXXSXMXGMJJ T
         WHERE T.ID != I_ID
           AND T.ZSSX = (SELECT MAX(A.ZSSX)
                           FROM TPIF_XSZC_CXXSXMXGMJJ A
                          WHERE A.ID != I_ID
                            AND A.ZSSX < V_OBJ.ZSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_XSZC_CXXSXMXGMJJ SET ZSSX = V_ZSSX WHERE ID = I_ID;
        UPDATE TPIF_XSZC_CXXSXMXGMJJ SET ZSSX = V_OBJ.ZSSX WHERE ID = V_CPID;
    END IF;
    IF I_OPER = 6 THEN
        --//:转历史
        SELECT COUNT(*)
          INTO V_COUNT
          FROM TPIF_XSZC_CXXSXMXGMJJ_HIS ZLS
         WHERE ZLS.ID = I_ID;
        IF V_COUNT > 0 THEN
            O_CODE := -1;
            O_NOTE := '该记录数已存在历史，请联系技术人员！';
            RETURN;
        END IF;

        INSERT INTO TPIF_XSZC_CXXSXMXGMJJ_HIS
            (ID,
             CPDM,
             CPMC,
             FXDJ,
             KSRQ,
             JSRQ,
             JSSJ,
             SRBL,
             CPBQ,
             CPBS,
             CPZL,
             DJJG,
             BZSM,
             ZLSBS,
             FBBS,
             ZLSRQ,
             CZR,
             ZSSX,
             FBRQ)
            SELECT M.ID,
                   M.CPDM,
                   M.CPMC,
                   M.FXDJ,
                   M.KSRQ,
                   M.JSRQ,
                   M.JSSJ,
                   M.SRBL,
                   M.CPBQ,
                   M.CPBS,
                   M.CPZL,
                   M.DJJG,
                   M.BZSM,
                   1,
                   M.FBBS,
                   SYSDATE,
                   I_USER,
                   M.ZSSX,
                   M.FBRQ
              FROM TPIF_XSZC_CXXSXMXGMJJ M
             WHERE M.ID = I_ID;
        DELETE FROM TPIF_XSZC_CXXSXMXGMJJ N WHERE N.ID = I_ID;
    END IF;

    IF I_OPER = 7 THEN
        --//:结束时间维护

        O_CODE := 1;
        O_NOTE := '';
        -- RETURN;

    END IF;

    IF I_OPER = 8 THEN
        --//:附件上传

        O_CODE := 1;
        O_NOTE := '';
        --RETURN;

    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '发布',
                           4,
                           '上移',
                           5,
                           '下移',
                           6,
                           '转历史',
                           7,
                           '结束时间维护',
                           '附件上传') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_XSZC_CXXSXMXGMJJ;
/

