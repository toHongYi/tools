create PROCEDURE PCX_PIF_SY_CPRL(O_CODE   OUT NUMBER,
                                            O_NOTE   OUT VARCHAR2,
                                            O_RESULT OUT SYS_REFCURSOR,
                                            i_query_month in number
                                           -- I_begin_date IN NUMBER, --开始日期
                                           -- I_end_date   IN NUMBER --结束日期
                                            ) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：海通证券产品中心

           功能说明：运营管理产品日历
               参数说明：
                    入参：
                         I_begin_date       IN  NUMBER,    --开始日期
                         I_end_date         IN  NUMBER     --结束日期

                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,
                          O_RESULT OUT   SYS_REFCURSOR,



          ----------------------------------------------------------
          操作人    版本号      时间                      操作
          刘浪浪    1.0.1    2015/01/26                   新增

    -------------------------------------------------------------------------------------------------*/
    V_SQL VARCHAR2(4000);

BEGIN
    O_CODE := 1;
    O_NOTE := '成功!';


  /*  IF I_begin_date IS NULL OR I_end_date IS NULL THEN
        O_CODE := -1;
        O_NOTE := '开始日期或结束日期不能为空!';
        RETURN;
    END IF;*/

    IF i_query_month IS NULL  THEN
        O_CODE := -1;
        O_NOTE := '查询月份不能为空!';
        RETURN;
    END IF;


    V_SQL := 'SELECT B.ZRR   AS "DATE" ,
                   COUNT(A.ID) CNT
                   FROM TPIF_CPSJ A,
                   livebos.TXTJYR B/*,
                   TPIF_CPSJLX_RLZS C*/
                   WHERE/* A.CPSJLX=C.CPSJLX
                   AND */TO_NUMBER(TO_CHAR(A.SJKSSJ,''YYYYMMDD''))=B.ZRR
                   --AND b.NY = ' || i_query_month || '
                   AND A.SFSX=1
                  -- AND C.RLLX=2
                   GROUP BY B.ZRR
                   ORDER BY B.ZRR';



    OPEN O_RESULT FOR V_SQL;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        OPEN O_RESULT FOR
            SELECT O_NOTE FROM DUAL;

END PCX_PIF_SY_CPRL;
/

