create FUNCTION FUNC_PIF_JYRL_JJRPD(I_DATE IN DATE --要判断的日期
                                               ) RETURN NUMBER AS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：判断日期是否是节假日或周末

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-06-23     V1.0      谢莉莉             创建
      2016-10-18     V2.0      王大一             移植并修改
  *********************************************************************************************************************/

  V_FLAG NUMBER; --返回数据[0:不是节假日,1:是节假日]
  V_DATE DATE; --返回日期

BEGIN
  V_FLAG := 0;
  V_DATE := TO_DATE(TO_CHAR(I_DATE, 'yyyy/mm/dd'), 'yyyy/mm/dd');
  --判断是否是周末
  SELECT COUNT(1)
    INTO V_FLAG
    FROM TPIF_JYRL_GZR
   WHERE XQL = V_DATE
      OR XQR = V_DATE;
  IF (V_FLAG = 0) THEN
    --判断是否是节假日
    SELECT COUNT(1)
      INTO V_FLAG
      FROM livebos.tJRXX
     WHERE V_DATE BETWEEN TO_DATE(TO_CHAR(KSRQ), 'yyyy/mm/dd') AND
           TO_DATE(TO_CHAR(JSRQ), 'yyyy/mm/dd');
  END IF;
  RETURN V_FLAG;
END FUNC_PIF_JYRL_JJRPD;
/

