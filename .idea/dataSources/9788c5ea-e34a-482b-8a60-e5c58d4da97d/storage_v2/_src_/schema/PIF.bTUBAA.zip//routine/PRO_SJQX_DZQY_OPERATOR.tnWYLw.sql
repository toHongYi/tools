create PROCEDURE PRO_SJQX_DZQY_OPERATOR(O_CODE OUT NUMBER, --返回值
                                                   O_NOTE OUT VARCHAR2 --返回消息
                                                   ) IS

  /******************************************************************
      所属用户：PIF
      功能说明：电子签约经办人表 PIF.DZQY_OPERATOR 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5       1.0       HANQN              创建
  
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO DZQY_OPERATOR_TEST T
  USING (SELECT OPERATOR_NO,
                NAME,
                MOBILE,
                CARDTYPE AS CARD_TYPE,
                CARDNO AS CARD_NO,
                EMAIL,
                ITOACCOUNT AS ITO_ACCOUNT,
                ITOTOKEN AS ITO_TOKEN,
                TO_DATE(TO_CHAR(CREATE_DATE) ||
                        TO_CHAR(CREATE_TIME, 'FM099999'),
                        'YYYYMMDDHH24MISS') AS CREATE_DATE,
                BRANCH_NO,
                TO_DATE(TO_CHAR(PUSH_DATE) || TO_CHAR(PUSH_TIME, 'FM099999'),
                        'YYYYMMDDHH24MISS') AS PUSH_DATE,
                DECODE(IS_MAJOR_POSTS, 1, 1, 2) AS POST_FLAG
           FROM SRC_PIF.PROD_OPERATOR_INFO) S
  
  ON (T.OPERATOR_NO = S.OPERATOR_NO)
  /*WHEN MATCHED THEN
          UPDATE
          SET
                 B.SSYYB = C.SSYYB,
                 B.DQSL = C.DQSL,
                B.UPDATE_TIME = C.UPDATE_TIME*/
  WHEN NOT MATCHED THEN
    INSERT
      (T.ID,
       T.OPERATOR_NO,
       T.NAME,
       T.MOBILE,
       T.CARD_TYPE,
       T.CARD_NO,
       T.EMAIL,
       T.BRANCH_NO,
       T.POST_FLAG,
       T.ITO_ACCOUNT,
       T.ITO_TOKEN,
       T.PUSH_DATE,
       T.CREATE_DATE,
       T.LAST_MODIFIED_DATE,
       T.DELETED_FLAG)
    VALUES
      (LIVEBOS.FUNC_NEXTID('dzqy_operator_test'),
       S.OPERATOR_NO,
       S.NAME,
       S.MOBILE,
       S.CARD_TYPE,
       S.CARD_NO,
       S.EMAIL,
       S.BRANCH_NO,
       S.POST_FLAG,
       S.ITO_ACCOUNT,
       S.ITO_TOKEN,
       S.PUSH_DATE,
       S.CREATE_DATE,
       SYSDATE,
       2);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'PIF.DZQY_OPERATOR_TEST 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'PIF.DZQY_OPERATOR_TEST 表清洗,未知错误'
                ELSE
                 'PIF.DZQY_OPERATOR_TEST ,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

