create PROCEDURE PCX_BASE_NBDX(O_CODE        OUT NUMBER,
                                          O_NOTE        OUT VARCHAR2,
                                          O_RESULT      OUT SYS_REFCURSOR,
                                          I_operator    IN NUMBER, --操作人
                                          I_object_name IN VARCHAR2, --对象名称
                                          I_id          IN VARCHAR2, --对象ID
                                          I_KEYWORD     IN VARCHAR2 --关键字
                                          ) AS
  /*****************************************************************************
   *创建人员：chenglin
   *创建日期：2019-11-26
   *功能说明：获取内部对象，可根据名称搜索
   *-----------------------------------------------------------------------------
   * 修改者         版本号          修改日期         说明
   * chenglin           1.0.0          2019-11-26        新增
   ------------------------------------------------------------------------------
  I_DXMC='TJG_DQDM' --地区代码，省份城市
    I_DXMC='TJG_HYFL' --行业分类
   *****************************************************************************/

  V_SQL   VARCHAR2(30000);
  V_CYRID VARCHAR2(30000);

BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '成功';

  --CHECK
  IF I_operator IS NULL THEN
    O_CODE := -1;
    O_NOTE := '用户参数不允许为空!';
    RETURN;
  END IF;
  IF I_object_name IS NULL THEN
    O_CODE := -1;
    O_NOTE := '对象名称参数不允许为空!';
    RETURN;
  END IF;

  IF UPPER(I_object_name) = 'PIF.TPROD_BASIC_INFO' THEN
  
    V_SQL := 'SELECT ID, ''[''||CPDM||'']''||CPMC AS NAME,PYDM AS Simplicity FROM PIF.TPIF_CPDM WHERE 1=1 AND CPNBZT=8';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND (LOWER(CPDM) LIKE ''%' ||
                 LOWER(I_KEYWORD) ||
                 '%'' OR LOWER(CPMC) LIKE ''%' ||
                 LOWER(I_KEYWORD) || '%'')';
      END IF;
    
    END IF;
    
    --V_SQL := V_SQL ||' and rownum <=500' ;
  
  END IF;
  
  IF UPPER(I_object_name) = 'PIF.TPIF_CPSJLX' THEN
  
    V_SQL := 'SELECT ID, LXMC AS NAME,ZSYS AS Simplicity FROM PIF.TPIF_CPSJLX WHERE SFQY=1';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND LXMC LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF;
  
  IF UPPER(I_object_name) = 'LIVEBOS.TUSER' THEN
  
    V_SQL := 'SELECT ID, NAME AS NAME,USERID AS Simplicity FROM LIVEBOS.TUSER WHERE ZT=1';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND NAME LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF;
  
  --PIF.TPIF_JGDM
  
    IF UPPER(I_object_name) = 'PIF.TPIF_JGDM' THEN
  
    V_SQL := 'SELECT ID, JGMC AS NAME,JGDM AS Simplicity FROM PIF.TPIF_JGDM WHERE ZT=1';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND JGMC LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF;
  
  
    IF UPPER(I_object_name) = 'PIF.TPIF_CPPJMB' THEN
  
    V_SQL := 'SELECT ID, MBMC AS NAME,MBBM AS Simplicity FROM PIF.TPIF_CPPJMB WHERE ZT=0';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND MBMC LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF;
  
  
  --TPIF_XQLX
  IF UPPER(I_object_name) = 'PIF.TPIF_XQLX' THEN
  
    V_SQL := 'SELECT ID, MC AS NAME,BM AS Simplicity FROM PIF.TPIF_XQLX WHERE 1=1';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND MC LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF; 
  
  
    --TPIF_BFJL  --拜访记录
  IF UPPER(I_object_name) = 'PIF.TPIF_BFJL' THEN
  
    V_SQL := 'SELECT ID, JGMC||JLRQ||''拜访记录'' AS NAME,JGID AS Simplicity FROM PIF.TPIF_BFJL WHERE 1=1';
   
  
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND JGID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND JGMC LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  
  END IF;
  
  
  IF UPPER(I_OBJECT_NAME) = 'PIF.TPIF_JRCPFL' THEN
    --取状态为启用的分类
    V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE ZT = 1 ';
    --ID当作分类的GRADE
    IF I_ID IS NOT NULL THEN
      V_SQL := V_SQL || ' AND GRADE = ' || I_ID;
    END IF;
    --关键词当作分类的上级节点
    IF I_KEYWORD IS NOT NULL THEN
     V_SQL := V_SQL || ' AND INSTR('',''||''' || I_KEYWORD ||'''||'','','',''||FID||'','')>0' ;
    END IF;
  END IF;  
  
  IF UPPER(I_OBJECT_NAME) LIKE 'PIF.TPIF_JRCPFL_%' THEN
    --取状态为启用的分类
    IF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_GM' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=300000 AND ZT = 1 ';
    ELSIF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_SMTZJJ' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=500000 AND ZT = 1 ';
    ELSIF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_SMZGJH' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=700000 AND ZT = 1 ';
    ELSIF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_XTJH' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=600000 AND ZT = 1 ';
    ELSIF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_YHLC' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=800000 AND ZT = 1 ';
    ELSIF UPPER(I_OBJECT_NAME)='PIF.TPIF_JRCPFL_SYPZ' THEN
      V_SQL := 'SELECT ID,NAME,FLBM AS SIMPLICITY FROM PIF.TPIF_JRCPFL WHERE FID=970000 AND ZT = 1 ';
  END IF;
    --ID当作分类的GRADE
    IF I_ID IS NOT NULL THEN
      V_SQL := V_SQL || ' AND GRADE = ' || I_ID;
    END IF;
    --关键词当作分类的上级节点
    /*IF I_KEYWORD IS NOT NULL THEN
      V_SQL := V_SQL || ' AND INSTR(''' || NAME ||''',I_KEYWORD)>0' ;
    END IF;*/
    IF I_id IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ID=' || I_id;
    ELSE
    
      IF I_KEYWORD IS NOT NULL THEN
        V_SQL := V_SQL || ' AND NAME LIKE ''%' || LOWER(I_KEYWORD) || '%''';
      END IF;
    
    END IF;
  END IF;    
  DBMS_OUTPUT.PUT_LINE(V_SQL);  
  OPEN O_RESULT FOR V_SQL || ' AND ROWNUM<100' ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败！';
    OPEN O_RESULT FOR
      SELECT -1, '查询失败!' 提示 FROM DUAL;
END PCX_BASE_NBDX;
/

