create FUNCTION FUNC_PIF_GET_OPENDAYRANGE(I_CPID IN NUMBER, --产品ID
                                                     I_KSRQ IN NUMBER, --开始时间
                                                     I_YWLX IN NUMBER --业务类型 7申购 8赎回 6认购
                                                     ) RETURN VARCHAR2 IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算最近开放日区间

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        李良   1.0.0    2020/04/13                新增
  --------------------------------------------------------------------------------*/

  V_ENDDAY   NUMBER;
  V_LAST_JYR NUMBER;

BEGIN
  V_ENDDAY := I_KSRQ;
  IF I_KSRQ IS NULL THEN
    RETURN NULL;
  END IF;

  FOR CUR_RQ IN (SELECT TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')) AS RQ
                   FROM TPIF_JYRL_HB
                  WHERE CPID = I_CPID
                    AND YWLX = I_YWLX
                    AND EXISTS
                  (SELECT 1
                           FROM LIVEBOS.TXTJYR
                          WHERE JYR = TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')))
                    AND TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')) > I_KSRQ
                  ORDER BY RQ) LOOP

    SELECT MAX(JYR)
      INTO V_LAST_JYR
      FROM LIVEBOS.TXTJYR
     WHERE JYR < CUR_RQ.RQ;

    IF V_LAST_JYR = V_ENDDAY THEN
      V_ENDDAY := CUR_RQ.RQ;
    ELSE
      EXIT;
    END IF;
  END LOOP;

  RETURN TO_CHAR(TO_DATE(I_KSRQ, 'YYYYMMDD'), 'YYYY.MM.DD') || '-' || TO_CHAR(TO_DATE(V_ENDDAY,
                                                                                      'YYYYMMDD'),
                                                                              'YYYY.MM.DD');

EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;
/

