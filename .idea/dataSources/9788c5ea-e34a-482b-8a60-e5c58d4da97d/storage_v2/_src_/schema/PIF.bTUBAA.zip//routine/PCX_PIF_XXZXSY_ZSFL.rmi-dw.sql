create PROCEDURE PCX_PIF_XXZXSY_ZSFL(O_CODE     OUT NUMBER,
                                                O_NOTE     OUT VARCHAR2,
                                                O_RESULT   OUT SYS_REFCURSOR,
                                                I_TYPE     IN VARCHAR2, --类别 1:一级分类；2:二级分类
                                                I_CLASS_ID IN VARCHAR2 --一级分类ID，当I_TYPE=2时需要传
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 信息中心首页-首页展示分类查询

      语法信息：
           输入参数：     I_TYPE   IN NUMBER , --类别  1:一级分类；2:二级分类
                         I_CLASS_ID IN NUMBER --一级分类ID，当I_TYPE=2时需要传
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/
  V_SQL      VARCHAR2(5000);
  V_DOC_PATH VARCHAR2(1000);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_TYPE 不允许为空！';
    RETURN;
  END IF;

  /*  ID  ID
      NAME  分类名称
      PROD_TYPE 对应产品类型
      SHOWPICTURES  展示图片
  */
  IF I_TYPE = 1 THEN
    
    --select PARAMVALUE INTO V_DOC_PATH from livebos.tsysparam where paramname='document-path';
    
    OPEN O_RESULT FOR

      SELECT A.ID, 
             A.NAME, 
             A.CPXL||'#'||A.JRCPFL AS PROD_TYPE,  
             --V_DOC_PATH||'TPIF_SYZSFL/'||A.ID||'.png' AS SHOWPICTURES
             a.png as SHOWPICTURES
        FROM TPIF_SYZSFL A
       WHERE A.GRADE = 1
       ORDER BY XSSX ASC;

  ELSE

    OPEN O_RESULT FOR

      SELECT A.ID, 
             A.NAME, 
             A.CPXL||'#'||A.JRCPFL AS PROD_TYPE, 
             A.PNG AS SHOWPICTURES
        FROM TPIF_SYZSFL A
       WHERE A.GRADE = 2
         AND A.FID = I_CLASS_ID
       ORDER BY ID ASC;


  END IF;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;

END;
/

