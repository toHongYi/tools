create PROCEDURE PRO_PIF_ZLCJSJQX(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_CJCX IN VARCHAR2 --采集程序
                                             ) AS
  /*
  **功能说明：增量采集数据清洗过程
  **创建人：  WUJINFENG
  **创建日期：2018-7-09
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **WUJINFENG  V1.0      2018-10-26    创建
  *丁小溪      V1.1      2019-12-26    修改：新增O32银行交易清洗，O32归档状态清洗*/
  V_ERR     VARCHAR2(512);
  V_COUNT   NUMBER;
  V_SYSDATE NUMBER;
  v_bgdate  date;
  v_CXMC    VARCHAR2(500);
  V_JYR     NUMBER;
BEGIN
  O_CODE    := 1;
  O_NOTE    := '执行【' || I_CJCX || '】数据清洗成功';

  IF I_CJCX IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_CJCX不允许为空';
    RETURN;
  END IF;
  v_bgdate := sysdate;

  --朝阳永续  :私募基金净值
  IF I_CJCX = 'TMP_FUND_NV_DATA_ZYYX' THEN
      v_CXMC := '朝阳永续  :私募基金净值';
      MERGE INTO SRC_PIF.T_FUND_NV_DATA_ZYYX M
      USING(SELECT * FROM TMP_FUND_NV_DATA_ZYYX WHERE STATISTIC_DATE  >= TRUNC(SYSDATE-30)) N
      ON(M.STATISTIC_DATE = N.STATISTIC_DATE AND M.FUND_ID = N.FUND_ID AND  M.STATISTIC_DATE  >= TRUNC(SYSDATE-30))
      WHEN MATCHED THEN UPDATE
        SET   M.FUND_NAME = N.FUND_NAME,
              M.SOURCE_CODE = N.SOURCE_CODE,
              M.NAV = N.NAV,
              M.ADDED_NAV = N.ADDED_NAV,
              M.SWANAV = N.SWANAV,
              M.SANAV = N.SANAV,
              M.PC = N.PC,
              M.CPC = N.CPC,
              M.TOTAL_ASSET = N.TOTAL_ASSET,
              M.TOTAL_NAV = N.TOTAL_NAV,
              M."SHARE" = N."SHARE",
              M.ANNUALIZED_RETURN = N.ANNUALIZED_RETURN,
              M.D7_ANNUALIZED_RETURN = N.D7_ANNUALIZED_RETURN,
              M.INCOME_VALUE_PER_TEN_THOUSAND = N.INCOME_VALUE_PER_TEN_THOUSAND,
              M.REMARK = N.REMARK,
              M.ENTRY_TIME = N.ENTRY_TIME,
              M.UPDATE_TIME = N.UPDATE_TIME,
              M.TMSTAMP = N.TMSTAMP

      WHEN NOT MATCHED THEN
         INSERT ( fund_id,
                  fund_name,
                  statistic_date,
                  source_code,
                  source,
                  NAV,
                  ADDED_NAV,
                  SWANAV,
                  SANAV,
                  PC,
                  CPC,
                  total_asset,
                  TOTAL_NAV,
                  "SHARE",
                  annualized_return,
                  d7_annualized_return,
                  income_value_per_ten_thousand,
                  remark,
                  entry_time,
                  update_time,
                  TMSTAMP
               )
           VALUES(n.fund_id,
                  n.fund_name,
                  n.statistic_date,
                  n.source_code,
                  n.source,
                  n.NAV,
                  n.ADDED_NAV,
                  n.SWANAV,
                  n.SANAV,
                  n.PC,
                  n.CPC,
                  n.total_asset,
                  n.TOTAL_NAV,
                  n."SHARE",
                  n.annualized_return,
                  n.d7_annualized_return,
                  n.income_value_per_ten_thousand,
                  n.remark,
                  n.entry_time,
                  n.update_time,
                  n.TMSTAMP);
     V_COUNT := SQL%ROWCOUNT;

  END IF;

/*  --私募基金费用信息表
  IF I_CJCX = 'DWD_INF_PRIVATE_FUND_FEE_DD' THEN
       v_CXMC := '朝阳永续  :私募基金费用信息表';
      MERGE INTO SRC_PIF.DWD_INF_PRIVATE_FUND_FEE_DD M
      USING(SELECT * FROM TMP_INF_PRIVATE_FUND_FEE_DD) N
      ON(M.LIST_LAB = N.LIST_LAB
         AND M.CLIENT_ID = N.CLIENT_ID
         AND m.PROD_CODE=n.PROD_CODE
         and m.INIT_DATE=n.INIT_DATE
         and m.init_date >= to_char(sysdate-7,'yyyymmdd')
         )
      WHEN MATCHED THEN UPDATE
        SET m.branch_id = n.branch_id,
           -- m.client_id = n.client_id,
            m.client_id_varchar = n.client_id_varchar,
          --  m.prod_code = n.prod_code,
          --  m.init_date = n.init_date,
          --  m.list_lab = n.list_lab,
            m.list_lab_tran = n.list_lab_tran,
            m.fund_income = n.fund_income,
            m.init_date_timestamp = n.init_date_timestamp,
            m.update_time = n.update_time,
            m.busi_date = n.busi_date

      WHEN NOT MATCHED THEN
         INSERT ( branch_id,
                  client_id,
                  client_id_varchar,
                  prod_code,
                  init_date,
                  list_lab,
                  list_lab_tran,
                  fund_income,
                  init_date_timestamp,
                  update_time,
                  busi_date)
           VALUES(n.branch_id,
                  n.client_id,
                  n.client_id_varchar,
                  n.prod_code,
                  n.init_date,
                  n.list_lab,
                  n.list_lab_tran,
                  n.fund_income,
                  n.init_date_timestamp,
                  n.update_time,
                  n.busi_date
               );
     V_COUNT := SQL%ROWCOUNT;

  END IF;*/


/*  --柜台产品净值表 DWD_PRD_PRODPRICE_DD
   IF I_CJCX = 'DWD_PRD_PRODPRICE_DD' THEN
      v_CXMC := '柜台  :产品净值表';
      MERGE INTO SRC_PIF.DWD_PRD_PRODPRICE_DD M
      USING(SELECT * FROM TMP_PRD_PRODPRICE_DD) N
      ON(M.PRODTA_NO = N.PRODTA_NO
         AND M.prod_code = N.prod_code
         AND m.init_date=n.init_date
         and m.init_date >= to_char(sysdate-7,'yyyymmdd')
         )
      WHEN MATCHED THEN UPDATE
        SET --m.id = n.id,
            --m.prodta_no = n.prodta_no,
            m.prod_type = n.prod_type,
            --m.prod_code = n.prod_code,
            m.prod_name = n.prod_name,
            --m.init_date = n.init_date,
            m.asset_price = n.asset_price,
            m.last_price = n.last_price,
            m.business_balance = n.business_balance,
            m.net_value = n.net_value,
            m.total_share = n.total_share,
            m.nav_total = n.nav_total,
            m.nav_date = n.nav_date,
            m.gold_rate = n.gold_rate,
            m.update_time = n.update_time,
            m.is_trade_day_bool = n.is_trade_day_bool,
            m.busi_date = n.busi_date
      WHEN NOT MATCHED THEN
         INSERT ( id,
                  prodta_no,
                  prod_type,
                  prod_code,
                  prod_name,
                  init_date,
                  asset_price,
                  last_price,
                  business_balance,
                  net_value,
                  total_share,
                  nav_total,
                  nav_date,
                  gold_rate,
                  update_time,
                  is_trade_day_bool,
                  busi_date
                  )
           VALUES(n.id,
                  n.prodta_no,
                  n.prod_type,
                  n.prod_code,
                  n.prod_name,
                  n.init_date,
                  n.asset_price,
                  n.last_price,
                  n.business_balance,
                  n.net_value,
                  n.total_share,
                  n.nav_total,
                  n.nav_date,
                  n.gold_rate,
                  n.update_time,
                  n.is_trade_day_bool,
                  n.busi_date
              );
     V_COUNT := SQL%ROWCOUNT;

  END IF;*/

  --朝阳永续  :私募基金净值每月全量更新一次
  IF I_CJCX = 'TMP_FUND_NV_DATA_ZYYX_M' THEN
     v_CXMC := '朝阳永续  :私募基金净值每月全量更新一次';
      --EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.t_fund_nv_data_zyyx';

      INSERT /*+append*/INTO SRC_PIF.t_fund_nv_data_zyyx(
              fund_id,
              FUND_NAME,
              STATISTIC_DATE,
              SOURCE_CODE,
             -- SOURCE,
              NAV,
              ADDED_NAV,
              SWANAV,
              SANAV,
              PC,
              CPC,
              TOTAL_ASSET,
              TOTAL_NAV,
              "SHARE",
              ANNUALIZED_RETURN,
              D7_ANNUALIZED_RETURN,
              INCOME_VALUE_PER_TEN_THOUSAND,
              REMARK,
              ENTRY_TIME,
              UPDATE_TIME,
              TMSTAMP
              )
         select fund_id,
              FUND_NAME,
              STATISTIC_DATE,
              SOURCE_CODE,
             -- SOURCE,
              NAV,
              ADDED_NAV,
              SWANAV,
              SANAV,
              PC,
              CPC,
              TOTAL_ASSET,
              TOTAL_NAV,
              "SHARE",
              ANNUALIZED_RETURN,
              D7_ANNUALIZED_RETURN,
              INCOME_VALUE_PER_TEN_THOUSAND,
              REMARK,
              ENTRY_TIME,
              UPDATE_TIME,
              TMSTAMP
      FROM TMP_FUND_NV_DATA_ZYYX ;
     V_COUNT := SQL%ROWCOUNT;

  END IF;

/*  --朝阳永续  :T_FUND_ADJUSTED_PERFORMANCE
  IF I_CJCX = 'T_FUND_ADJUSTED_PERFORMANCE' THEN
      v_CXMC := '朝阳永续  :私募基金业绩表现';
      MERGE INTO SRC_PIF.T_FUND_ADJUSTED_PERFORMANCE M
  USING(SELECT * FROM TMP_FUND_ADJUSTED_PERFORMANCE ) N
  ON( M.FUND_ID = N.FUND_ID
     AND M.STATISTIC_DATE = N.STATISTIC_DATE
     AND M.STATISTIC_DATE >= trunc(sysdate-30)
     )
    WHEN MATCHED THEN update SET
          M.nav                                           = N.nav                             ,
          M.added_nav                                     = N.added_nav                       ,
          M.swanav                                        = N.swanav                          ,
          M.sanav                                         = N.sanav                           ,
          M.daily_return                                  = N.daily_return                    ,
          M.week_return                                   = N.week_return                     ,
          M.month_return                                  = N.month_return                    ,
          M.quarter_return                                = N.quarter_return                  ,
          M.year_return                                   = N.year_return                     ,
          M.total_return                                  = N.total_return                    ,
          M.m1_return                                     = N.m1_return                       ,
          M.m3_return                                     = N.m3_return                       ,
          M.m6_return                                     = N.m6_return                       ,
          M.y1_return                                     = N.y1_return                       ,
          M.y2_return                                     = N.y2_return                       ,
          M.y3_return                                     = N.y3_return                       ,
          M.y5_return                                     = N.y5_return                       ,
          M.total_return_a                                = N.total_return_a                  ,
          M.y1_return_a                                   = N.y1_return_a                     ,
          M.y2_return_a                                   = N.y2_return_a                     ,
          M.y3_return_a                                   = N.y3_return_a                     ,
          M.y5_return_a                                   = N.y5_return_a                     ,
          M.month_stdev                                   = N.month_stdev                     ,
          M.quarter_stdev                                 = N.quarter_stdev                   ,
          M.year_stdev                                    = N.year_stdev                      ,
          M.total_stdev                                   = N.total_stdev                     ,
          M.m1_stdev                                      = N.m1_stdev                        ,
          M.m3_stdev                                      = N.m3_stdev                        ,
          M.m6_stdev                                      = N.m6_stdev                        ,
          M.y1_stdev                                      = N.y1_stdev                        ,
          M.y2_stdev                                      = N.y2_stdev                        ,
          M.y3_stdev                                      = N.y3_stdev                        ,
          M.y5_stdev                                      = N.y5_stdev                        ,
          M.month_stdev_a                                 = N.month_stdev_a                   ,
          M.quarter_stdev_a                               = N.quarter_stdev_a                 ,
          M.year_stdev_a                                  = N.year_stdev_a                    ,
          M.total_stdev_a                                 = N.total_stdev_a                   ,
          M.m1_stdev_a                                    = N.m1_stdev_a                      ,
          M.m3_stdev_a                                    = N.m3_stdev_a                      ,
          M.m6_stdev_a                                    = N.m6_stdev_a                      ,
          M.y1_stdev_a                                    = N.y1_stdev_a                      ,
          M.y2_stdev_a                                    = N.y2_stdev_a                      ,
          M.y3_stdev_a                                    = N.y3_stdev_a                      ,
          M.y5_stdev_a                                    = N.y5_stdev_a                      ,
          M.month_max_retracement                         = N.month_max_retracement           ,
          M.month_max_retracement_bdate                   = N.month_max_retracement_bdate       ,
          M.month_max_retracement_edate                   = N.month_max_retracement_edate       ,
          M.month_max_retracement_rdate                   = N.month_max_retracement_rdate       ,
          M.quarter_max_retracement                       = N.quarter_max_retracement         ,
          M.quarter_max_retracement_bdate                 = N.quarter_max_retracement_bdate       ,
          M.quarter_max_retracement_edate                 = N.quarter_max_retracement_edate       ,
          M.quarter_max_retracement_rdate                 = N.quarter_max_retracement_rdate       ,
          M.year_max_retracement                          = N.year_max_retracement            ,
          M.year_max_retracement_bdate                    = N.year_max_retracement_bdate       ,
          M.year_max_retracement_edate                    = N.year_max_retracement_edate       ,
          M.year_max_retracement_rdate                    = N.year_max_retracement_rdate       ,
          M.total_max_retracement                         = N.total_max_retracement           ,
          M.total_max_retracement_bdate                   = N.total_max_retracement_bdate       ,
          M.total_max_retracement_edate                   = N.total_max_retracement_edate       ,
          M.total_max_retracement_rdate                   = N.total_max_retracement_rdate     ,
          M.m1_max_retracement                            = N.m1_max_retracement              ,
          M.m1_max_retracement_bdate                      = N.m1_max_retracement_bdate        ,
          M.m1_max_retracement_edate                      = N.m1_max_retracement_edate        ,
          M.m1_max_retracement_rdate                      = N.m1_max_retracement_rdate        ,
          M.m3_max_retracement                            = N.m3_max_retracement              ,
          M.m3_max_retracement_bdate                      = N.m3_max_retracement_bdate        ,
          M.m3_max_retracement_edate                      = N.m3_max_retracement_edate        ,
          M.m3_max_retracement_rdate                      = N.m3_max_retracement_rdate        ,
          M.m6_max_retracement                            = N.m6_max_retracement              ,
          M.m6_max_retracement_bdate                      = N.m6_max_retracement_bdate        ,
          M.m6_max_retracement_edate                      = N.m6_max_retracement_edate        ,
          M.m6_max_retracement_rdate                      = N.m6_max_retracement_rdate        ,
          M.y1_max_retracement                            = N.y1_max_retracement              ,
          M.y1_max_retracement_bdate                      = N.y1_max_retracement_bdate        ,
          M.y1_max_retracement_edate                      = N.y1_max_retracement_edate        ,
          M.y1_max_retracement_rdate                      = N.y1_max_retracement_rdate        ,
          M.y2_max_retracement                            = N.y2_max_retracement              ,
          M.y2_max_retracement_bdate                      = N.y2_max_retracement_bdate        ,
          M.y2_max_retracement_edate                      = N.y2_max_retracement_edate        ,
          M.y2_max_retracement_rdate                      = N.y2_max_retracement_rdate        ,
          M.y3_max_retracement                            = N.y3_max_retracement              ,
          M.y3_max_retracement_bdate                      = N.y3_max_retracement_bdate        ,
          M.y3_max_retracement_edate                      = N.y3_max_retracement_edate        ,
          M.y3_max_retracement_rdate                      = N.y3_max_retracement_rdate        ,
          M.y5_max_retracement                            = N.y5_max_retracement              ,
          M.y5_max_retracement_bdate                      = N.y5_max_retracement_bdate        ,
          M.y5_max_retracement_edate                      = N.y5_max_retracement_edate        ,
          M.y5_max_retracement_rdate                      = N.y5_max_retracement_rdate        ,
          M.month_sharp                                   = N.month_sharp                     ,
          M.quarter_sharp                                 = N.quarter_sharp                   ,
          M.year_sharp                                    = N.year_sharp                      ,
          M.total_sharp                                   = N.total_sharp                     ,
          M.m1_sharp                                      = N.m1_sharp                        ,
          M.m3_sharp                                      = N.m3_sharp                        ,
          M.m6_sharp                                      = N.m6_sharp                        ,
          M.y1_sharp                                      = N.y1_sharp                        ,
          M.y2_sharp                                      = N.y2_sharp                        ,
          M.y3_sharp                                      = N.y3_sharp                        ,
          M.y5_sharp                                      = N.y5_sharp                        ,
          M.entry_time                                    = N.entry_time                      ,
          M.update_time                                   = N.update_time                     ,
          M.tmstamp                                       = N.tmstamp
    WHEN NOT MATCHED THEN
      INSERT  ( fund_id,
                    fund_name,
                    statistic_date,
                    nav,
                    added_nav,
                    swanav,
                    sanav,
                    daily_return,
                    week_return,
                    month_return,
                    quarter_return,
                    year_return,
                    total_return,
                    m1_return,
                    m3_return,
                    m6_return,
                    y1_return,
                    y2_return,
                    y3_return,
                    y5_return,
                    total_return_a,
                    y1_return_a,
                    y2_return_a,
                    y3_return_a,
                    y5_return_a,
                    month_stdev,
                    quarter_stdev,
                    year_stdev,
                    total_stdev,
                    m1_stdev,
                    m3_stdev,
                    m6_stdev,
                    y1_stdev,
                    y2_stdev,
                    y3_stdev,
                    y5_stdev,
                    month_stdev_a,
                    quarter_stdev_a,
                    year_stdev_a,
                    total_stdev_a,
                    m1_stdev_a,
                    m3_stdev_a,
                    m6_stdev_a,
                    y1_stdev_a,
                    y2_stdev_a,
                    y3_stdev_a,
                    y5_stdev_a,
                    month_max_retracement,
                    month_max_retracement_bdate,
                    month_max_retracement_edate,
                    month_max_retracement_rdate,
                    quarter_max_retracement,
                    quarter_max_retracement_bdate,
                    quarter_max_retracement_edate,
                    quarter_max_retracement_rdate,
                    year_max_retracement,
                    year_max_retracement_bdate,
                    year_max_retracement_edate,
                    year_max_retracement_rdate,
                    total_max_retracement,
                    total_max_retracement_bdate,
                    total_max_retracement_edate,
                    total_max_retracement_rdate,
                    m1_max_retracement,
                    m1_max_retracement_bdate,
                    m1_max_retracement_edate,
                    m1_max_retracement_rdate,
                    m3_max_retracement,
                    m3_max_retracement_bdate,
                    m3_max_retracement_edate,
                    m3_max_retracement_rdate,
                    m6_max_retracement,
                    m6_max_retracement_bdate,
                    m6_max_retracement_edate,
                    m6_max_retracement_rdate,
                    y1_max_retracement,
                    y1_max_retracement_bdate,
                    y1_max_retracement_edate,
                    y1_max_retracement_rdate,
                    y2_max_retracement,
                    y2_max_retracement_bdate,
                    y2_max_retracement_edate,
                    y2_max_retracement_rdate,
                    y3_max_retracement,
                    y3_max_retracement_bdate,
                    y3_max_retracement_edate,
                    y3_max_retracement_rdate,
                    y5_max_retracement,
                    y5_max_retracement_bdate,
                    y5_max_retracement_edate,
                    y5_max_retracement_rdate,
                    month_sharp,
                    quarter_sharp,
                    year_sharp,
                    total_sharp,
                    m1_sharp,
                    m3_sharp,
                    m6_sharp,
                    y1_sharp,
                    y2_sharp,
                    y3_sharp,
                    y5_sharp,
                    entry_time,
                    update_time,
                    tmstamp
                    )
                    VALUES( n.fund_id,
                            n.fund_name,
                            n.statistic_date,
                            n.nav,
                            n.added_nav,
                            n.swanav,
                            n.sanav,
                            n.daily_return,
                            n.week_return,
                            n.month_return,
                            n.quarter_return,
                            n.year_return,
                            n.total_return,
                            n.m1_return,
                            n.m3_return,
                            n.m6_return,
                            n.y1_return,
                            n.y2_return,
                            n.y3_return,
                            n.y5_return,
                            n.total_return_a,
                            n.y1_return_a,
                            n.y2_return_a,
                            n.y3_return_a,
                            n.y5_return_a,
                            n.month_stdev,
                            n.quarter_stdev,
                            n.year_stdev,
                            n.total_stdev,
                            n.m1_stdev,
                            n.m3_stdev,
                            n.m6_stdev,
                            n.y1_stdev,
                            n.y2_stdev,
                            n.y3_stdev,
                            n.y5_stdev,
                            n.month_stdev_a,
                            n.quarter_stdev_a,
                            n.year_stdev_a,
                            n.total_stdev_a,
                            n.m1_stdev_a,
                            n.m3_stdev_a,
                            n.m6_stdev_a,
                            n.y1_stdev_a,
                            n.y2_stdev_a,
                            n.y3_stdev_a,
                            n.y5_stdev_a,
                            n.month_max_retracement,
                            n.month_max_retracement_bdate,
                            n.month_max_retracement_edate,
                            n.month_max_retracement_rdate,
                            n.quarter_max_retracement,
                            n.quarter_max_retracement_bdate,
                            n.quarter_max_retracement_edate,
                            n.quarter_max_retracement_rdate,
                            n.year_max_retracement,
                            n.year_max_retracement_bdate,
                            n.year_max_retracement_edate,
                            n.year_max_retracement_rdate,
                            n.total_max_retracement,
                            n.total_max_retracement_bdate,
                            n.total_max_retracement_edate,
                            n.total_max_retracement_rdate,
                            n.m1_max_retracement,
                            n.m1_max_retracement_bdate,
                            n.m1_max_retracement_edate,
                            n.m1_max_retracement_rdate,
                            n.m3_max_retracement,
                            n.m3_max_retracement_bdate,
                            n.m3_max_retracement_edate,
                            n.m3_max_retracement_rdate,
                            n.m6_max_retracement,
                            n.m6_max_retracement_bdate,
                            n.m6_max_retracement_edate,
                            n.m6_max_retracement_rdate,
                            n.y1_max_retracement,
                            n.y1_max_retracement_bdate,
                            n.y1_max_retracement_edate,
                            n.y1_max_retracement_rdate,
                            n.y2_max_retracement,
                            n.y2_max_retracement_bdate,
                            n.y2_max_retracement_edate,
                            n.y2_max_retracement_rdate,
                            n.y3_max_retracement,
                            n.y3_max_retracement_bdate,
                            n.y3_max_retracement_edate,
                            n.y3_max_retracement_rdate,
                            n.y5_max_retracement,
                            n.y5_max_retracement_bdate,
                            n.y5_max_retracement_edate,
                            n.y5_max_retracement_rdate,
                            n.month_sharp,
                            n.quarter_sharp,
                            n.year_sharp,
                            n.total_sharp,
                            n.m1_sharp,
                            n.m3_sharp,
                            n.m6_sharp,
                            n.y1_sharp,
                            n.y2_sharp,
                            n.y3_sharp,
                            n.y5_sharp,
                            n.entry_time,
                            n.update_time,
                            n.tmstamp

                    );
      V_COUNT := SQL%ROWCOUNT;
  END IF;*/

/*  --朝阳永续  :T_FUND_ADJUSTED_RISK
  IF I_CJCX = 'T_FUND_ADJUSTED_RISK' THEN
      v_CXMC := '朝阳永续  :私募基金风险指标';
      MERGE INTO SRC_PIF.T_FUND_ADJUSTED_RISK M
  USING(SELECT * FROM TMP_FUND_ADJUSTED_RISK) N
  ON( M.FUND_ID = N.FUND_ID
      AND M.STATISTIC_DATE = N.STATISTIC_DATE
      AND M.STATISTIC_DATE >=trunc(sysdate-30)
      )
  WHEN MATCHED THEN UPDATE SET
    m.fund_name            = n.fund_name                  ,
    m.month_beta           = n.month_beta                 ,
    m.quarter_beta         = n.quarter_beta               ,
    m.year_beta            = n.year_beta                  ,
    m.total_beta           = n.total_beta                 ,
    m.m1_beta              = n.m1_beta                    ,
    m.m3_beta              = n.m3_beta                    ,
    m.m6_beta              = n.m6_beta                    ,
    m.y1_beta              = n.y1_beta                    ,
    m.y2_beta              = n.y2_beta                    ,
    m.y3_beta              = n.y3_beta                    ,
    m.y5_beta              = n.y5_beta                    ,
    m.total_calmar         = n.total_calmar               ,
    m.y1_calmar            = n.y1_calmar                  ,
    m.y2_calmar            = n.y2_calmar                  ,
    m.y3_calmar            = n.y3_calmar                  ,
    m.y5_calmar            = n.y5_calmar                  ,
    m.month_dd             = n.month_dd                   ,
    m.quarter_dd           = n.quarter_dd                 ,
    m.year_dd              = n.year_dd                    ,
    m.total_dd             = n.total_dd                   ,
    m.m1_dd                = n.m1_dd                      ,
    m.m3_dd                = n.m3_dd                      ,
    m.m6_dd                = n.m6_dd                      ,
    m.y1_dd                = n.y1_dd                      ,
    m.y2_dd                = n.y2_dd                      ,
    m.y3_dd                = n.y3_dd                      ,
    m.y5_dd                = n.y5_dd                      ,
    m.month_jensen         = n.month_jensen               ,
    m.quarter_jensen       = n.quarter_jensen             ,
    m.year_jensen          = n.year_jensen                ,
    m.total_jensen         = n.total_jensen               ,
    m.m1_jensen            = n.m1_jensen                  ,
    m.m3_jensen            = n.m3_jensen                  ,
    m.m6_jensen            = n.m6_jensen                  ,
    m.y1_jensen            = n.y1_jensen                  ,
    m.y2_jensen            = n.y2_jensen                  ,
    m.y3_jensen            = n.y3_jensen                  ,
    m.y5_jensen            = n.y5_jensen                  ,
    m.month_sor            = n.month_sor                  ,
    m.quarter_sor          = n.quarter_sor                ,
    m.year_sor             = n.year_sor                   ,
    m.total_sor            = n.total_sor                  ,
    m.m1_sor               = n.m1_sor                     ,
    m.m3_sor               = n.m3_sor                     ,
    m.m6_sor               = n.m6_sor                     ,
    m.y1_sor               = n.y1_sor                     ,
    m.y2_sor               = n.y2_sor                     ,
    m.y3_sor               = n.y3_sor                     ,
    m.y5_sor               = n.y5_sor                     ,
    m.month_tre            = n.month_tre                  ,
    m.quarter_tre          = n.quarter_tre                ,
    m.year_tre             = n.year_tre                   ,
    m.total_tre            = n.total_tre                  ,
    m.m1_tre               = n.m1_tre                     ,
    m.m3_tre               = n.m3_tre                     ,
    m.m6_tre               = n.m6_tre                     ,
    m.y1_tre               = n.y1_tre                     ,
    m.y2_tre               = n.y2_tre                     ,
    m.y3_tre               = n.y3_tre                     ,
    m.y5_tre               = n.y5_tre                     ,
    m.month_info_ratio     = n.month_info_ratio           ,
    m.quarter_info_ratio   = n.quarter_info_ratio         ,
    m.year_info_ratio      = n.year_info_ratio            ,
    m.total_info_ratio     = n.total_info_ratio           ,
    m.m1_info_ratio        = n.m1_info_ratio              ,
    m.m3_info_ratio        = n.m3_info_ratio              ,
    m.m6_info_ratio        = n.m6_info_ratio              ,
    m.y1_info_ratio        = n.y1_info_ratio              ,
    m.y2_info_ratio        = n.y2_info_ratio              ,
    m.y3_info_ratio        = n.y3_info_ratio              ,
    m.y5_info_ratio        = n.y5_info_ratio              ,
    m.month_m2_ratio       = n.month_m2_ratio             ,
    m.quarter_m2_ratio     = n.quarter_m2_ratio           ,
    m.year_m2_ratio        = n.year_m2_ratio              ,
    m.total_m2_ratio       = n.total_m2_ratio             ,
    m.m1_m2_ratio          = n.m1_m2_ratio                ,
    m.m3_m2_ratio          = n.m3_m2_ratio                ,
    m.m6_m2_ratio          = n.m6_m2_ratio                ,
    m.y1_m2_ratio          = n.y1_m2_ratio                ,
    m.y2_m2_ratio          = n.y2_m2_ratio                ,
    m.y3_m2_ratio          = n.y3_m2_ratio                ,
    m.y5_m2_ratio          = n.y5_m2_ratio                ,
    m.month_var            = n.month_var                  ,
    m.quarter_var          = n.quarter_var                ,
    m.year_var             = n.year_var                   ,
    m.total_var            = n.total_var                  ,
    m.m1_var               = n.m1_var                     ,
    m.m3_var               = n.m3_var                     ,
    m.m6_var               = n.m6_var                     ,
    m.y1_var               = n.y1_var                     ,
    m.y2_var               = n.y2_var                     ,
    m.y3_var               = n.y3_var                     ,
    m.y5_var               = n.y5_var                     ,
    m.entry_time           = n.entry_time                 ,
    m.update_time          = n.update_time                ,
    m.tmstamp              = n.tmstamp
  when not matched then
    insert( fund_id,
            fund_name,
            statistic_date,
            month_beta,
            quarter_beta,
            year_beta,
            total_beta,
            m1_beta,
            m3_beta,
            m6_beta,
            y1_beta,
            y2_beta,
            y3_beta,
            y5_beta,
            total_calmar,
            y1_calmar,
            y2_calmar,
            y3_calmar,
            y5_calmar,
            month_dd,
            quarter_dd,
            year_dd,
            total_dd,
            m1_dd,
            m3_dd,
            m6_dd,
            y1_dd,
            y2_dd,
            y3_dd,
            y5_dd,
            month_jensen,
            quarter_jensen,
            year_jensen,
            total_jensen,
            m1_jensen,
            m3_jensen,
            m6_jensen,
            y1_jensen,
            y2_jensen,
            y3_jensen,
            y5_jensen,
            month_sor,
            quarter_sor,
            year_sor,
            total_sor,
            m1_sor,
            m3_sor,
            m6_sor,
            y1_sor,
            y2_sor,
            y3_sor,
            y5_sor,
            month_tre,
            quarter_tre,
            year_tre,
            total_tre,
            m1_tre,
            m3_tre,
            m6_tre,
            y1_tre,
            y2_tre,
            y3_tre,
            y5_tre,
            month_info_ratio,
            quarter_info_ratio,
            year_info_ratio,
            total_info_ratio,
            m1_info_ratio,
            m3_info_ratio,
            m6_info_ratio,
            y1_info_ratio,
            y2_info_ratio,
            y3_info_ratio,
            y5_info_ratio,
            month_m2_ratio,
            quarter_m2_ratio,
            year_m2_ratio,
            total_m2_ratio,
            m1_m2_ratio,
            m3_m2_ratio,
            m6_m2_ratio,
            y1_m2_ratio,
            y2_m2_ratio,
            y3_m2_ratio,
            y5_m2_ratio,
            month_var,
            quarter_var,
            year_var,
            total_var,
            m1_var,
            m3_var,
            m6_var,
            y1_var,
            y2_var,
            y3_var,
            y5_var,
            entry_time,
            update_time,
            tmstamp )
    values( n.fund_id                     ,
            n.fund_name                   ,
            n.statistic_date              ,
            n.month_beta                  ,
            n.quarter_beta                ,
            n.year_beta                   ,
            n.total_beta                  ,
            n.m1_beta                     ,
            n.m3_beta                     ,
            n.m6_beta                     ,
            n.y1_beta                     ,
            n.y2_beta                     ,
            n.y3_beta                     ,
            n.y5_beta                     ,
            n.total_calmar                ,
            n.y1_calmar                   ,
            n.y2_calmar                   ,
            n.y3_calmar                   ,
            n.y5_calmar                   ,
            n.month_dd                    ,
            n.quarter_dd                  ,
            n.year_dd                     ,
            n.total_dd                    ,
            n.m1_dd                       ,
            n.m3_dd                       ,
            n.m6_dd                       ,
            n.y1_dd                       ,
            n.y2_dd                       ,
            n.y3_dd                       ,
            n.y5_dd                       ,
            n.month_jensen                ,
            n.quarter_jensen              ,
            n.year_jensen                 ,
            n.total_jensen                ,
            n.m1_jensen                   ,
            n.m3_jensen                   ,
            n.m6_jensen                   ,
            n.y1_jensen                   ,
            n.y2_jensen                   ,
            n.y3_jensen                   ,
            n.y5_jensen                   ,
            n.month_sor                   ,
            n.quarter_sor                 ,
            n.year_sor                    ,
            n.total_sor                   ,
            n.m1_sor                      ,
            n.m3_sor                      ,
            n.m6_sor                      ,
            n.y1_sor                      ,
            n.y2_sor                      ,
            n.y3_sor                      ,
            n.y5_sor                      ,
            n.month_tre                   ,
            n.quarter_tre                 ,
            n.year_tre                    ,
            n.total_tre                   ,
            n.m1_tre                      ,
            n.m3_tre                      ,
            n.m6_tre                      ,
            n.y1_tre                      ,
            n.y2_tre                      ,
            n.y3_tre                      ,
            n.y5_tre                      ,
            n.month_info_ratio            ,
            n.quarter_info_ratio          ,
            n.year_info_ratio             ,
            n.total_info_ratio            ,
            n.m1_info_ratio               ,
            n.m3_info_ratio               ,
            n.m6_info_ratio               ,
            n.y1_info_ratio               ,
            n.y2_info_ratio               ,
            n.y3_info_ratio               ,
            n.y5_info_ratio               ,
            n.month_m2_ratio              ,
            n.quarter_m2_ratio            ,
            n.year_m2_ratio               ,
            n.total_m2_ratio              ,
            n.m1_m2_ratio                 ,
            n.m3_m2_ratio                 ,
            n.m6_m2_ratio                 ,
            n.y1_m2_ratio                 ,
            n.y2_m2_ratio                 ,
            n.y3_m2_ratio                 ,
            n.y5_m2_ratio                 ,
            n.month_var                   ,
            n.quarter_var                 ,
            n.year_var                    ,
            n.total_var                   ,
            n.m1_var                      ,
            n.m3_var                      ,
            n.m6_var                      ,
            n.y1_var                      ,
            n.y2_var                      ,
            n.y3_var                      ,
            n.y5_var                      ,
            n.entry_time                  ,
            n.update_time                 ,
            n.tmstamp
      );
      V_COUNT := SQL%ROWCOUNT;
  END IF ;

*/
  --外出打卡记录增量采集：V_CHECKIN_DATA_TH,更新近5天外出记录
  --create table TMP_CHECKIN_DATA_TH as select * from SRC_PIF.V_CHECKIN_DATA_TH where 1=2
  IF I_CJCX = 'V_CHECKIN_DATA_TH' THEN
     v_CXMC := 'ODS :外出打卡记录增量采集';
     MERGE INTO SRC_PIF.V_CHECKIN_DATA_TH M
     USING(SELECT * FROM TMP_CHECKIN_DATA_TH T WHERE TO_CHAR(T.CHECKIN_TIME,'YYYYMMDD') >= TO_CHAR(SYSDATE-5,'YYYYMMDD')) N
     ON(M.ID = N.ID AND TO_CHAR(M.CHECKIN_TIME,'YYYYMMDD') >= TO_CHAR(SYSDATE-5,'YYYYMMDD'))
     WHEN NOT MATCHED THEN
       INSERT(id,
              userid,
              groupname,
              checkin_type,
              exception_type,
              checkin_time,
              location_title,
              location_detail,
              wifiname,
              notes,
              wifimac,
              mediaids,
              lat,
              lng,
              deviceid,
              gmt_create,
              gmt_modify
              )
              VALUES(
                N.id,
                N.userid,
                N.groupname,
                N.checkin_type,
                N.exception_type,
                N.checkin_time,
                N.location_title,
                N.location_detail,
                N.wifiname,
                N.notes,
                N.wifimac,
                N.mediaids,
                N.lat,
                N.lng,
                N.deviceid,
                N.gmt_create,
                N.gmt_modify
              );
   V_COUNT := SQL%ROWCOUNT;
  END IF;


  --归档舆情信息
  IF I_CJCX = 'ODS_YQXX' THEN
     v_CXMC := 'ODS :归档t-1日舆情数据到历史表';

     select JYR INTO V_JYR FROM LIVEBOS.TXTJYR A WHERE A.ZRR = TO_CHAR(SYSDATE-1,'YYYYMMDD');
     SELECT COUNT(*) INTO V_COUNT FROM tpif_gdrq WHERE RQ = V_JYR ;

     IF V_COUNT = 0 THEN
       /*
       insert into src_pif.fund_manager_change_his(seq,
                                                  sec_code,
                                                  notice_date,
                                                  personal_id,
                                                  personal_name,
                                                  start_date,
                                                  end_date,
                                                  leaving_reasons,
                                                  uuid,
                                                  created_at,
                                                  updated_at,
                                                  fund_invest_type,
                                                  fund_type,
                                                  fund_code,
                                                  isvalid,
                                                  refreshed_at
                                                  )
       select seq,
              sec_code,
              notice_date,
              personal_id,
              personal_name,
              start_date,
              end_date,
              leaving_reasons,
              uuid,
              created_at,
              updated_at,
              fund_invest_type,
              fund_type,
              fund_code,
              isvalid,
              refreshed_at
     from src_pif.fund_manager_change WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;

       insert into src_pif.REDEEM_his(seq,
                                    end_date,
                                    final_total_share,
                                    sec_code,
                                    status_total_share,
                                    purchase_amount,
                                    redemption,
                                    split_share,
                                    merger_share,
                                    created_at,
                                    updated_at,
                                    uuid,
                                    isvalid,
                                    refreshed_at
                                 )
      select seq,
              end_date,
              final_total_share,
              sec_code,
              status_total_share,
              purchase_amount,
              redemption,
              split_share,
              merger_share,
              created_at,
              updated_at,
              uuid,
              isvalid,
              refreshed_at
      from src_pif.redeem  WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;
      */
       insert into src_pif.news_his(seq,
                                  page_title,
                                  publish_source,
                                  de_group_id,
                                  publish_time,
                                  host_name,
                                  data_weight,
                                  uuid,
                                  data_url,
                                  crawl_time,
                                  host_source,
                                  gid,
                                  verify_mode,
                                  reply_tag,
                                  display_time,
                                  isvalid,
                                  updated_at,
                                  created_at,
                                  push_type,
                                  content_hash,
                                  refreshed_at,
                                  news_type
                                  )
      select seq,
              page_title,
              publish_source,
              de_group_id,
              publish_time,
              host_name,
              data_weight,
              uuid,
              data_url,
              crawl_time,
              host_source,
              gid,
              verify_mode,
              reply_tag,
              display_time,
              isvalid,
              updated_at,
              created_at,
              push_type,
              content_hash,
              refreshed_at,
              news_type
      from src_pif.news   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;

       /*insert into src_pif.news_contents_his( seq,
                                            uuid,
                                            page_content_seg,
                                            page_title_seg,
                                            snap_shot,
                                            isvalid,
                                            created_at,
                                            updated_at,
                                            refreshed_at
                                         )
      select seq,
              uuid,
              page_content_seg,
              page_title_seg,
              snap_shot,
              isvalid,
              created_at,
              updated_at,
              refreshed_at
      from src_pif.news_contents   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;

       insert into src_pif.news_subject_tags_his( seq,
                                                uuid,
                                                data_value,
                                                data_sentiment,
                                                data_type,
                                                display_time,
                                                isvalid,
                                                updated_at,
                                                created_at,
                                                refreshed_at
                                            )
      select  seq,
              uuid,
              data_value,
              data_sentiment,
              data_type,
              display_time,
              isvalid,
              updated_at,
              created_at,
              refreshed_at
      from src_pif.news_subject_tags   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;

       insert into src_pif.news_importance_tags_his(seq,
                                                  uuid,
                                                  subject_org,
                                                  subject_importance,
                                                  display_time,
                                                  importance_type,
                                                  isvalid,
                                                  updated_at,
                                                  created_at
                                                )
      select  seq,
              uuid,
              subject_org,
              subject_importance,
              display_time,
              importance_type,
              isvalid,
              updated_at,
              created_at
     from src_pif.news_importance_tags   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;*/

       /*insert into src_pif.news_other_tags_his( seq,
                                              uuid,
                                              data_value,
                                              data_type,
                                              display_time,
                                              isvalid,
                                              updated_at,
                                              created_at,
                                              refreshed_at
                                              )
      select  seq,
              uuid,
              data_value,
              data_type,
              display_time,
              isvalid,
              updated_at,
              created_at,
              refreshed_at
      from src_pif.news_other_tags   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;*/

       /*insert into src_pif.news_risk_tags_his( seq,
                                              uuid,
                                              subject_org,
                                              subject_risk,
                                              data_type,
                                              display_time,
                                              isvalid,
                                              updated_at,
                                              created_at
                                       )
     select seq,
            uuid,
            subject_org,
            subject_risk,
            data_type,
            display_time,
            isvalid,
            updated_at,
            created_at
    from src_pif.news_risk_tags   WHERE TO_CHAR(updated_at,'YYYYMMDD')=V_JYR;
        */

       INSERT INTO tpif_gdrq(rq ) VALUES(V_JYR);
     END IF;

    V_COUNT := SQL%ROWCOUNT;
  END IF;

  --私募基金净佣金(月)
  IF I_CJCX = 'TMP_INF_PRIVATE_BRANCH_INC_DD' THEN
    V_CXMC := 'ODS : 私募基金净佣金(月)';
    MERGE INTO SRC_PIF.ADS_INF_PRIVATE_BRANCH_INC_DD M
    USING (SELECT * FROM TMP_INF_PRIVATE_BRANCH_INC_DD) N
    ON( M.INIT_MONTH = N.INIT_MONTH
        AND M.CLIENT_ID = N.CLIENT_ID
        AND M.BRANCH_ID = N.BRANCH_ID
        AND M.INIT_MONTH>=TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,-3),'yyyymm'))
      )
    WHEN MATCHED THEN UPDATE
      SET
          M.BRANCH_NAME = N.BRANCH_NAME,
          M.CLIENT_NAME = N.CLIENT_NAME,
          M.CLIENT_OPEN_DATE = N.CLIENT_OPEN_DATE,
          M.FUND_MANAGER = N.FUND_MANAGER,
          M.NET_COMMISSION = N.NET_COMMISSION,
          M.LAST_MONTH_NET_COMMISSION = N.LAST_MONTH_NET_COMMISSION,
          M.NET_COMMISSION_MOM_RATIO = N.NET_COMMISSION_MOM_RATIO,
          M.SERVICE_FEE = N.SERVICE_FEE,
          M.TRUSTEESHIP_INCOME = N.TRUSTEESHIP_INCOME,
          M.OUTSOURCE_INCOME = N.OUTSOURCE_INCOME,
          M.FINANCE_INTEREST = N.FINANCE_INTEREST,
          M.LOAN_DURATION = N.LOAN_DURATION,
          M.DATACOLUMN01 = N.DATACOLUMN01,
          M.DATACOLUMN02 = N.DATACOLUMN02,
          M.DATACOLUMN03 = N.DATACOLUMN03,
          M.DATACOLUMN04 = N.DATACOLUMN04,
          M.DATACOLUMN05 = N.DATACOLUMN05,
          M.DATACOLUMN06 = N.DATACOLUMN06,
          M.UPDATE_TIME = N.UPDATE_TIME,
          M.BUSI_MONTH = N.BUSI_MONTH
    WHEN NOT MATCHED THEN
      INSERT (INIT_MONTH,
              BRANCH_ID,
              BRANCH_NAME,
              CLIENT_ID,
              CLIENT_NAME,
              CLIENT_OPEN_DATE,
              FUND_MANAGER,
              NET_COMMISSION,
              LAST_MONTH_NET_COMMISSION,
              NET_COMMISSION_MOM_RATIO,
              SERVICE_FEE,
              TRUSTEESHIP_INCOME,
              OUTSOURCE_INCOME,
              FINANCE_INTEREST,
              LOAN_DURATION,
              DATACOLUMN01,
              DATACOLUMN02,
              DATACOLUMN03,
              DATACOLUMN04,
              DATACOLUMN05,
              DATACOLUMN06,
              UPDATE_TIME,
              BUSI_MONTH)
              VALUES
              (N.INIT_MONTH,
              N.BRANCH_ID,
              N.BRANCH_NAME,
              N.CLIENT_ID,
              N.CLIENT_NAME,
              N.CLIENT_OPEN_DATE,
              N.FUND_MANAGER,
              N.NET_COMMISSION,
              N.LAST_MONTH_NET_COMMISSION,
              N.NET_COMMISSION_MOM_RATIO,
              N.SERVICE_FEE,
              N.TRUSTEESHIP_INCOME,
              N.OUTSOURCE_INCOME,
              N.FINANCE_INTEREST,
              N.LOAN_DURATION,
              N.DATACOLUMN01,
              N.DATACOLUMN02,
              N.DATACOLUMN03,
              N.DATACOLUMN04,
              N.DATACOLUMN05,
              N.DATACOLUMN06,
              N.UPDATE_TIME,
              N.BUSI_MONTH);
        V_COUNT := SQL%ROWCOUNT;
   END IF;

  --私募基金净佣金(日)
  IF I_CJCX = 'ADS_INF_PRIVATE_NET_VALUE_DD' THEN
     V_CXMC := 'ODS : 私募基金净佣金(日)';
     MERGE INTO SRC_PIF.ADS_INF_PRIVATE_NET_VALUE_DD M
     USING (SELECT * FROM TMP_INF_PRIVATE_NET_VALUE_DD) N
     ON(M.CLIENT_ID = N.CLIENT_ID
        AND M.BRANCH_NO = N.BRANCH_NO
        AND M.INIT_DATE = N.INIT_DATE
        AND M.INIT_DATE >= TO_CHAR(SYSDATE-7,'YYYYMMDD')
        )
     WHEN MATCHED THEN UPDATE
       SET
         M.OPEN_DATE = N.OPEN_DATE,
         M.NET_COMMISSION = N.NET_COMMISSION,
      --   M.DATACOLUMN01 = N.DATACOLUMN01,
         M.DATACOLUMN02 = N.DATACOLUMN02,
         M.DATACOLUMN03 = N.DATACOLUMN03,
         M.DATACOLUMN04 = N.DATACOLUMN04,
         M.DATACOLUMN05 = N.DATACOLUMN05,
         M.DATACOLUMN06 = N.DATACOLUMN06,
         M.DATACOLUMN07 = N.DATACOLUMN07,
         M.DATACOLUMN08 = N.DATACOLUMN08,
         M.DATACOLUMN09 = N.DATACOLUMN09,
         M.DATACOLUMN10 = N.DATACOLUMN10,
         M.UPDATE_TIME = N.UPDATE_TIME,
         M.BUSI_DATE = N.BUSI_DATE ,
         M.TOTAL_ASSET = N.TOTAL_ASSET
     WHEN NOT MATCHED THEN
       INSERT(INIT_DATE,
              BRANCH_NO,
              CLIENT_ID,
              OPEN_DATE,
              NET_COMMISSION,
             -- DATACOLUMN01,
              DATACOLUMN02,
              DATACOLUMN03,
              DATACOLUMN04,
              DATACOLUMN05,
              DATACOLUMN06,
              DATACOLUMN07,
              DATACOLUMN08,
              DATACOLUMN09,
              DATACOLUMN10,
              UPDATE_TIME,
              BUSI_DATE,
              TOTAL_ASSET
              )
              VALUES
              (N.INIT_DATE,
              N.BRANCH_NO,
              N.CLIENT_ID,
              N.OPEN_DATE,
              N.NET_COMMISSION,
        --      N.DATACOLUMN01,
              N.DATACOLUMN02,
              N.DATACOLUMN03,
              N.DATACOLUMN04,
              N.DATACOLUMN05,
              N.DATACOLUMN06,
              N.DATACOLUMN07,
              N.DATACOLUMN08,
              N.DATACOLUMN09,
              N.DATACOLUMN10,
              N.UPDATE_TIME,
              N.BUSI_DATE,
              N.TOTAL_ASSET
              );
        V_COUNT := SQL%ROWCOUNT;
   END IF;

  --客户统计_全账户_日
  IF I_CJCX = 'TMP_T_STAT_KHH_R' THEN
     V_CXMC := 'ODS : 客户统计_全账户_日';
     MERGE INTO SRC_PIF.T_STAT_KHH_R M
     USING (SELECT * FROM TMP_T_STAT_KHH_R) N
     ON(M.RQ = N.RQ
        AND M.KHH = N.KHH
        AND M.YYB = N.YYB
        AND M.RQ >= TO_NUMBER(TO_CHAR(SYSDATE-7,'YYYYMMDD'))
        )
     WHEN MATCHED THEN UPDATE
       SET
          M.JYL = N.JYL,
          M.YJ = N.YJ,
          M.JYJ = N.JYJ,
          M.JYBS = N.JYBS,
          M.ZZC = N.ZZC,
          M.ZJYE = N.ZJYE,
          M.ZQSZ = N.ZQSZ,
          M.ZFZ = N.ZFZ,
          M.ZCJLR = N.ZCJLR,
          M.CRJE = N. CRJE,
          M.QCJE = N.QCJE,
          M.ZRZQSZ = M.ZRZQSZ,
          M.ZCZQSZ = N.ZCZQSZ,
          M.YK = N.YK,
          M.JYL_GJZH = N.JYL_GJZH,
          M.JYL_XYZH = N.JYL_XYZH,
          M.JYL_JRCP = N.JYL_JRCP,
          M.YJ_GJZH = N.YJ_GJZH,
          M.YJ_XYZH = N.YJ_XYZH,
          M.YJ_JRCP = N.YJ_JRCP,
          M.JYJ_GJZH = N.JYJ_GJZH,
          M.JYJ_XYZH = N.JYJ_XYZH,
          M.JYJ_JRCP = N.JYJ_JRCP,
          M.ZZC_GJZH = N.ZZC_GJZH,
          M.ZZC_XYZH = N.ZZC_XYZH,
          M.ZZC_JRCP = M.ZZC_JRCP,
          M.ZZC_GGQQ = N.ZZC_GGQQ ,
          M.ZJYE_GGQQ = N.ZJYE_GGQQ,
          M.ZQSZ_GGQQ = N.ZQSZ_GGQQ,
          M.JYL_GGQQ = N.JYL_GGQQ,
          M.YJ_GGQQ = N.YJ_GGQQ,
          M.JYJ_GGQQ = N.JYJ_GGQQ,
          M.ZZC_ZQL = N.ZZC_ZQL

     WHEN NOT MATCHED THEN
       INSERT(RQ,
              KHH,
              YYB,
              JYL,
              YJ,
              JYJ,
              JYBS,
              ZZC,
              ZJYE,
              ZQSZ,
              ZFZ,
              ZCJLR,
              CRJE,
              QCJE,
              ZRZQSZ,
              ZCZQSZ,
              YK,
              JYL_GJZH,
              JYL_XYZH,
              JYL_JRCP,
              YJ_GJZH,
              YJ_XYZH,
              YJ_JRCP,
              JYJ_GJZH,
              JYJ_XYZH,
              JYJ_JRCP,
              ZZC_GJZH,
              ZZC_XYZH,
              ZZC_JRCP,
              ZZC_GGQQ,
              ZJYE_GGQQ,
              ZQSZ_GGQQ,
              JYL_GGQQ,
              YJ_GGQQ,
              JYJ_GGQQ,
              ZZC_ZQL
              )
              VALUES
              (N.RQ,
                N.KHH,
                N.YYB,
                N.JYL,
                N.YJ,
                N.JYJ,
                N.JYBS,
                N.ZZC,
                N.ZJYE,
                N.ZQSZ,
                N.ZFZ,
                N.ZCJLR,
                N.CRJE,
                N.QCJE,
                N.ZRZQSZ,
                N.ZCZQSZ,
                N.YK,
                N.JYL_GJZH,
                N.JYL_XYZH,
                N.JYL_JRCP,
                N.YJ_GJZH,
                N.YJ_XYZH,
                N.YJ_JRCP,
                N.JYJ_GJZH,
                N.JYJ_XYZH,
                N.JYJ_JRCP,
                N.ZZC_GJZH,
                N.ZZC_XYZH,
                N.ZZC_JRCP,
                N.ZZC_GGQQ,
                N.ZJYE_GGQQ,
                N.ZQSZ_GGQQ,
                N.JYL_GGQQ,
                N.YJ_GGQQ,
                N.JYJ_GGQQ,
                N.ZZC_ZQL
              );
        V_COUNT := SQL%ROWCOUNT;
   END IF;


  --学院路-柜台当日产品净值 ct_ods_uf20_dds.PRODPRICE
   IF I_CJCX = 'TMP_PRODPRICE' THEN
      v_CXMC := '柜台  :当日产品净值';
      MERGE INTO SRC_PIF.DWD_PRD_PRODPRICE_DD M
      USING(SELECT * FROM TMP_PRODPRICE) N
      ON(M.PRODTA_NO = N.PRODTA_NO
         AND M.prod_code = N.prod_code
         AND m.init_date=n.init_date
         and m.init_date >= to_char(sysdate-7,'yyyymmdd')
         )
      WHEN MATCHED THEN UPDATE
        SET --m.id = n.id,
            --m.prodta_no = n.prodta_no,
            m.prod_type = n.prod_type,
            --m.prod_code = n.prod_code,
         --   m.prod_name = n.prod_name,
            --m.init_date = n.init_date,
            m.asset_price = to_char(n.asset_price),
            m.last_price = to_char(n.last_price),
            m.business_balance = to_char(n.business_balance),
            m.net_value = to_char(n.net_value),
            m.total_share = to_char(n.total_share),
            m.nav_total = to_char(n.nav_total),
            m.nav_date = n.nav_date,
            m.gold_rate = to_char(n.gold_rate),
            m.update_time = to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')
        --    m.is_trade_day_bool = n.is_trade_day_bool,
        --    m.busi_date = n.busi_date
      WHEN NOT MATCHED THEN
         INSERT ( id,
                  prodta_no,
                  prod_type,
                  prod_code,
                  prod_name,
                  init_date,
                  asset_price,
                  last_price,
                  business_balance,
                  net_value,
                  total_share,
                  nav_total,
                  nav_date,
                  gold_rate,
                  update_time,
                  is_trade_day_bool,
                  busi_date
                  )
           VALUES(null,
                  n.prodta_no,
                  n.prod_type,
                  n.prod_code,
                  null,
                  n.init_date,
                  to_char(n.asset_price),
                  to_char(n.last_price),
                  to_char(n.business_balance),
                  to_char(n.net_value),
                  to_char(n.total_share),
                  to_char(n.nav_total),
                  n.nav_date,
                  to_char(n.gold_rate),
                  to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
                  null,
                  null
              );
     V_COUNT := SQL%ROWCOUNT;

  END IF;




  INSERT INTO tpif_sjqx_log
    (id, RQ, CXDM, ZT, BZ, JLS,KSSJ,JSSJ,CXMC)
  VALUES
    (SEQ_TPIF_SJQX_LOG.NEXTVAL, to_char(SYSDATE,'yyyymmdd'), I_CJCX, 1, '成功', V_COUNT,v_bgdate,sysdate,v_CXMC);

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN

    ROLLBACK;

    V_ERR := SQLERRM;

    O_CODE := -1;
    O_NOTE := '执行【' || I_CJCX || '】数据清洗失败：' || V_ERR;

    INSERT INTO tpif_sjqx_log
       (id, RQ, CXDM, ZT, BZ, JLS,KSSJ,JSSJ,CXMC)
    VALUES
      (SEQ_TPIF_SJQX_LOG.NEXTVAL, to_char(SYSDATE,'yyyymmdd'), I_CJCX, -1, '失败：' || V_ERR, 0,v_bgdate,sysdate,v_CXMC);

    COMMIT;
END;
/

