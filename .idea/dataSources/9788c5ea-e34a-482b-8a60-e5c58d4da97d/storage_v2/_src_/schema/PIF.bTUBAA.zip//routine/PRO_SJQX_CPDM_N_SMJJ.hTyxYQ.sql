create PROCEDURE PRO_SJQX_CPDM_N_SMJJ(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2 --返回消息
                                                 ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：TPIF_CPDM_N_SMJJ 私募基金扩展属性数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-12     1.0.0    吴金锋              创建
          2021-05-11     1.0.1    高昆              因私募产品拆分而修改
  ***********************************************************************/

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO TPIF_CPDM_N_SMJJ M
  USING (SELECT B.ID AS CPID, --CPID
                A.IS_REG AS SFBA, --是否备案(1是;0否)
                A.IS_PRIVATE AS SFYGSM, --是否阳光私募作为基金管理人或投顾(1是;0否)
                A.FUND_TYPE_STRATEGY AS TZCL, --投资策略
                A.FUND_TYPE_STRATEGY_LEVEL1 AS YJTZCL, --一级投资策略分类
                A.FUND_TYPE_STRATEGY_LEVEL2 AS EJTZCL, --二级投资策略分类
                A.TERMINAL_STRATEGY AS YYTZCL, --应用投资策略分类
                DECODE(A.FUND_TYPE_QUANT, '量化', 1, '非量化', 2) AS LHSX, --量化属性
                DECODE(A.FUND_TYPE_HEDGING, '对冲', 1, '非对冲', 2) AS DCSX --对冲属性
           FROM SRC_PIF.T_FUND_INFO A, TPIF_CPDM_SMYY B
          WHERE A.FUND_ID = B.ZYNM) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.SFBA   = N.SFBA,
           M.SFYGSM = N.SFYGSM,
           M.TZCL   = N.TZCL,
           M.YJTZCL = N.YJTZCL,
           M.EJTZCL = N.EJTZCL,
           M.YYTZCL = N.YYTZCL,
           M.LHSX   = N.LHSX,
           M.DCSX   = N.DCSX
  WHEN NOT MATCHED THEN
    INSERT
      (ID, CPID, SFBA, SFYGSM, TZCL, YJTZCL, EJTZCL, YYTZCL, LHSX, DCSX)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_N_SMJJ'),
       N.CPID,
       N.SFBA,
       N.SFYGSM,
       N.TZCL,
       N.YJTZCL,
       N.EJTZCL,
       N.YYTZCL,
       N.LHSX,
       N.DCSX);

  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM_N_SMJJ 表清洗成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM_N_SMJJ 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM_N_SMJJ 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

