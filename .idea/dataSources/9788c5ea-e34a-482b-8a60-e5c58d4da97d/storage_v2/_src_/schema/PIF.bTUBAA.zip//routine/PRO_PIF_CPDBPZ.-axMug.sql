create PROCEDURE PRO_PIF_CPDBPZ(O_CODE         OUT NUMBER, --返回值
                                           O_NOTE         OUT VARCHAR2, --返回消息
                                           I_OPERATE_TYPE IN INTEGER, --操作类型1|新增;2|删除;3|清空
                                           I_PROD_ID      IN VARCHAR2, --产品ID
                                           I_USERID       IN NUMBER) IS
  /*
  **功能说明：产品对比配置
  **创建人：涂孟
  **创建日期：2020-05-08
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **涂孟       1.0.0     2020-05-08   创建
  **GAOKUN     1.0.1     2021-09-14   如果已满或已经加入，返回CODE 2，前端区别1和2
  */
  V_COUNT  INTEGER; --计数
  V_COUNT2 INTEGER; --计数
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --CHECK
  IF I_OPERATE_TYPE IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;

  --START
  O_NOTE := '业务处理';

  IF I_OPERATE_TYPE = 1 THEN
    --//:新增-----------------------------------------------------------------------
    IF I_PROD_ID IS NULL THEN
      O_NOTE := '系统异常:产品ID为空!';
      RETURN;
    END IF;
    --判断对比列表是否已满
    SELECT COUNT(1) INTO V_COUNT2 FROM PIF.TPIF_DBCPLB WHERE YH = I_USERID;
    IF V_COUNT2 >= 5 THEN
      O_NOTE := '对比栏已满！';
      O_CODE := 2;
      RETURN;
    ELSE
      --判断该产品是否已加入
      SELECT COUNT(1)
        INTO V_COUNT
        FROM PIF.TPIF_DBCPLB A
       WHERE A.CPID = I_PROD_ID
         AND YH = I_USERID;
      IF V_COUNT > 0 THEN
        O_NOTE := '该产品已加入对比！';
        O_CODE := 2;
        RETURN;
      ELSE
        INSERT INTO PIF.TPIF_DBCPLB
          (ID, CPID, CPDM, CPMC, YH)
          SELECT LIVEBOS.FUNC_NEXTID('TPIF_DBCPPLB'),
                 ID,
                 CPDM,
                 A.CPMC,
                 I_USERID
            FROM PIF.TPIF_CPDM A
           WHERE A.ID = I_PROD_ID;
        O_NOTE := '产品加入对比成功！';
      END IF;
    END IF;
  END IF;

  IF I_OPERATE_TYPE = 2 THEN
    --删除-----------------------------------------------------------------------
    IF I_PROD_ID IS NULL THEN
      O_NOTE := '系统异常:产品ID为空!';
      RETURN;
    END IF;
    DELETE FROM PIF.TPIF_DBCPLB
     WHERE CPID = I_PROD_ID
       AND YH = I_USERID;
    O_NOTE := '产品删除成功！';
  END IF;
  IF I_OPERATE_TYPE = 3 THEN
    --清空-----------------------------------------------------------------------
    DELETE FROM PIF.TPIF_DBCPLB WHERE YH = I_USERID;
    O_NOTE := '清空成功！';
  END IF;
  --RETURN
  COMMIT;
  O_CODE := 1;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_CPDBPZ;
/

