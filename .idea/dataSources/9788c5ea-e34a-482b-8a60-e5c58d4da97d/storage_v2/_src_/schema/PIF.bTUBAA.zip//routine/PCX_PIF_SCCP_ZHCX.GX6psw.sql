create PROCEDURE PCX_PIF_SCCP_ZHCX(O_CODE      OUT NUMBER,
                                              O_NOTE      OUT VARCHAR2,
                                              O_RESULT    OUT SYS_REFCURSOR,
                                              I_CURRENT   IN NUMBER, --页码
                                              I_PAGESIZE  IN NUMBER, --页长
                                              I_PAGING    IN NUMBER, --是否分页
                                              I_SORT      IN STRING, --排序规模
                                              I_TOTAL     IN OUT NUMBER, --记录总数
                                              I_USERID    IN NUMBER, --登录用户ID
                                              I_PROD_TYPE IN VARCHAR2, --产品类型   1：公募基金 2：私募基金 3：券商理财 4：银行理财  5：信托理财  6：保险理财
                                              I_PROD_NAME IN VARCHAR2, --产品代码/名称
                                              
                                              I_PROD_TERM       IN VARCHAR2, --  产品期限 0|一年以内;1|一年到两年;2|两年以上  不用
                                              I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级   不用
                                              I_FUND_CATEGORY   IN VARCHAR2, --  基金类别    1101|股票型;1103|混合型;1105|债券型;1107|保本型;1109|货币型;1199|其他型   不用
                                              I_ISSUE_MODE      IN VARCHAR2, --发行方式    STRING  N 1:证券投资基金 2:股权投资基金 3:创业投资基金 4:其他投资基金 5:私募公司 私募基金（PROD_TYPE=2）适用   不用
                                              I_INVEST_TYPE     IN VARCHAR2, --投资类型   STRING  N 1:FOF 2:QDII 3:债券型 4:混合型 5:股票型 6:货币市场型 券商理财（PROD_TYPE=3）适用   不用
                                              
                                              I_IS_COMPANY_SALL   IN VARCHAR2, --是否我司代销  1:是 0:否
                                              I_ISSUER            IN VARCHAR2, --发行机构=基金管理人
                                              I_FUND_MANAGER      IN VARCHAR2, --基金/投资经理
                                              I_PROD_FIRST_TYPE   IN VARCHAR2, --公募一级分类
                                              I_PROD_SECOND_TYPE  IN VARCHAR2, --公募二级分类
                                              I_BEGIN_DATE        IN VARCHAR2, --开始日期
                                              I_END_DATE          IN VARCHAR2, --结束日期
                                              I_TERMINAL_STRATEGY IN VARCHAR2 --私募一级策略
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心C5
  
  功能说明：市场产品--综合查询
  
  参数说明：
      入参：
            I_CURRENT         IN NUMBER, --页码
            I_PAGESIZE        IN NUMBER, --页长
            I_PAGING          IN NUMBER, --是否分页
            I_SORT            IN STRING, --排序规模
            I_TOTAL           IN OUT NUMBER, --记录总数
            I_USERID          IN NUMBER, --任务执行人ID
            I_PROD_TYPE       IN VARCHAR2, --产品类型
            I_PROD_NAME       IN VARCHAR2, --产品代码/名称
            
            I_PROD_TERM       IN VARCHAR2, --  产品期限 不用
            I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级 不用
            I_FUND_CATEGORY   IN VARCHAR2, --  基金类别 不用
            I_ISSUE_MODE      IN VARCHAR2, --发行方式   不用
            I_INVEST_TYPE     IN VARCHAR2, --投资类型   不用 
            
            I_IS_COMPANY_SALL IN VARCHAR2, --是否我司代销
            I_ISSUER          IN VARCHAR2, --发行机构=基金管理人
            I_FUND_MANAGER    IN VARCHAR2, --基金/投资经理
            I_PROD_FIRST_TYPE   IN VARCHAR2, --公募一级分类
            I_PROD_SECOND_TYPE  IN VARCHAR2, --公募二级分类
            I_BEGIN_DATE        IN VARCHAR2, --开始日期
            I_END_DATE          IN VARCHAR2, --结束日期
            I_TERMINAL_STRATEGY IN VARCHAR2 --私募一级策略
  
      出参：
            O_CODE   OUT   NUMBER,
            O_NOTE   OUT   VARCHAR2,
            O_RESULT OUT   SYS_REFCURSOR
  
        ----------------------------------------------------------
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020-07-14    1.0       WUJINFENG              新增
      2021-08-31    1.1        GAOKUN           初步修改避免报错，后续根据实
                                                 际需求修改优化
      2021-09-03    1.2        GAOKUN           根据财通需求修改                                           
  -------------------------------------------------------------------------------------------------*/
  V_SQL          VARCHAR2(4000);
  V_SORT         VARCHAR2(200);
  V_COLLIST      VARCHAR2(500);
  V_HASRECORDSET NUMBER;

  V_POSITION             NUMBER;
  V_SORT_COLUMN_ORIGINAL VARCHAR2(100);
  V_SORT_COLUMN_FINAL    VARCHAR2(100);
  V_COUNT                NUMBER;

BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '成功!';

  V_HASRECORDSET := 1;
  I_TOTAL        := -1;

  IF I_SORT IS NOT NULL THEN
    SELECT INSTR(I_SORT, ' ', 1, 1) INTO V_POSITION FROM DUAL; --获取第一个空格的位置
    SELECT SUBSTR(I_SORT, 1, V_POSITION - 1) --获取排序字段
      INTO V_SORT_COLUMN_ORIGINAL
      FROM DUAL;
  
    SELECT COUNT(1)
      INTO V_COUNT
      FROM DUAL
     WHERE V_SORT_COLUMN_ORIGINAL IN
           ('NVDAILYGROWTHRATE',
            'RRINSINGLEWEEK',
            'RRINSINGLEMONTH',
            'RRINTHREEMONTH',
            'RRINSIXMONTH',
            'RRINSINGLEYEAR',
            'RRINTWOYEAR',
            'RRINTHREEYEAR',
            'RRINFIVEYEAR',
            'RRSINCETHISYEAR',
            'RRSINCESTART',
            'ANNUALIZEDRRSINCESTART',
            'Y1_RETURN_A',
            'TOTAL_RETURN_A');
    --对于收益率等数据，转换成NUMBER型再排序
    IF V_COUNT = 1 THEN
      SELECT 'TO_NUMBER(' || V_SORT_COLUMN_ORIGINAL || ')'
        INTO V_SORT_COLUMN_FINAL
        FROM DUAL;
      V_SORT := V_SORT_COLUMN_FINAL || ' ' ||
                SUBSTR(I_SORT, V_POSITION + 1);
    ELSE
      V_SORT := I_SORT;
    END IF;
  
  END IF;

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不能为空!';
    RETURN;
  END IF;

  IF I_PROD_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_TYPE 不能为空!';
    RETURN;
  END IF;

  --1：公募基金
  IF I_PROD_TYPE = 1 THEN
    V_SQL := 'SELECT A.INNERCODE AS ID,
                        ''/OperateProcessor?operate=ViewDetail&Table=VINFO_JJGK&ID=''||A.ID||''&PARAMACTION=TRUE'' AS DETAILS_LINK_URL,
                        A.SECUCODE AS PROD_CODE,--基金代码
                        A.PRODFULLNAME AS PROD_NAME,--基金名称    
                        A.PRODABBNAME,--基金简称
                        (CASE WHEN A.IS_SELL =1 THEN ''是'' ELSE ''否'' END)  AS SFWSXS,--是否我司销售
                        (SELECT INVESTADVISORNAME FROM INFO.TINFO_JJGLRGK WHERE INVESTADVISORCODE=A.INVESTADVISORCODE)  AS INVESTADVISOR,--基金管理人
                        TO_CHAR(A.ESTABLISHMENTDATE,''YYYY-MM-DD'') AS ESTABLISHMENTDATE ,--成立日期
                        A.MANAGER, --基金经理
                        A.PROD_FIRST_TYPE_NAME,--一级分类
                        A.PROD_SECOND_TYPE_NAME,--二级分类
                        TO_CHAR(A.PRODSCALEAMOUNT/100000000,''FM9990.00'') AS PRODSCALEAMOUNT,--基金规模
                        NVL(TO_CHAR(B.TRADINGDAY,''YYYY-MM-DD''),TO_CHAR(C.TRADINGDAY,''YYYY-MM-DD'')) AS NAV_DATE,--净值日期
                        TO_CHAR(B.UNITNV,''FM9990.0000'') AS UNITNV,--单位净值
                        TO_CHAR(B.ACCUMULATEDUNITNV,''FM9990.0000'') AS ACCUMULATEDUNITNV,--累计净值
                        TO_CHAR(B.NVDAILYGROWTHRATE,''FM9990.00'') AS NVDAILYGROWTHRATE,--日涨跌幅
                        TO_CHAR(B.RRINSINGLEWEEK,''FM9990.00'') AS RRINSINGLEWEEK,--近一周涨跌幅
                        TO_CHAR(B.RRINSINGLEMONTH,''FM9990.00'') AS RRINSINGLEMONTH,--近一月
                        TO_CHAR(B.RRINTHREEMONTH,''FM9990.00'') AS RRINTHREEMONTH,--近三月
                        TO_CHAR(B.RRINSIXMONTH,''FM9990.00'') AS RRINSIXMONTH,--近六月
                        TO_CHAR(B.RRINSINGLEYEAR,''FM9990.00'') AS RRINSINGLEYEAR,--近一年
                        TO_CHAR(B.RRINTWOYEAR,''FM9990.00'') AS RRINTWOYEAR,--近两年
                        TO_CHAR(B.RRINTHREEYEAR,''FM9990.00'') AS RRINTHREEYEAR,--近三年
                        TO_CHAR(B.RRINFIVEYEAR,''FM9990.00'') AS RRINFIVEYEAR,--近五年
                        TO_CHAR(B.RRSINCETHISYEAR,''FM9990.00'') AS RRSINCETHISYEAR,--今年以来
                        TO_CHAR(B.RRSINCESTART,''FM9990.00'') AS RRSINCESTART,--成立以来
                        TO_CHAR(B.ANNUALIZEDRRSINCESTART,''FM9990.00'') AS ANNUALIZEDRRSINCESTART,--成立以来平均年化收益率
                        TO_CHAR(C.DAILYPROFIT,''FM9990.0000'') AS DAILYPROFIT,--万份收益
                        TO_CHAR(C.LATESTWEEKLYYIELD,''FM9990.0000'') AS LATESTWEEKLYYIELD,--七日年化收益率
                        D.APPLYINGTYPE--申购状态
                 FROM INFO.TINFO_JJGK A--基金概况表
                 LEFT JOIN INFO.TINFO_JJJZZXBX B--基金净值最新表现（不包括货币型基金）
                        ON A.SECUCODE = B.SECUCODE
                 LEFT JOIN INFO.TINFO_HBJJSYBX C--货币型基金收益表现（只存最新一期）
                        ON A.SECUCODE = C.SECUCODE
                 LEFT JOIN INFO.TINFO_GMJJSSZT D--公募基金申赎状态,取申购状态
                        ON A.SECUCODE = D.SECUCODE         
                 WHERE A.LISTEDSTATE !=5 '; --去除终止产品
  
    --I_PROD_NAME         IN VARCHAR2, --产品代码/名称
    IF I_PROD_NAME IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ( A.SECUCODE LIKE ''%' || I_PROD_NAME ||
               '%''  OR  A.PRODFULLNAME LIKE ''%' || I_PROD_NAME || '%'') ';
    END IF;
  
    --I_IS_COMPANY_SALL     IN VARCHAR2, --是否我司代销  1:是 0:否
    IF I_IS_COMPANY_SALL IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.IS_SELL= ' || I_IS_COMPANY_SALL;
    END IF;
  
    --I_ISSUER           IN VARCHAR2, --发行机构
    IF I_ISSUER IS NOT NULL THEN
      V_SQL := V_SQL ||
               ' AND EXISTS (SELECT 1 FROM INFO.TINFO_JJGLRGK WHERE INVESTADVISORCODE=A.INVESTADVISORCODE AND A.INVESTADVISORNAME LIKE  ''%' ||
               I_ISSUER || '%'')';
    END IF;
  
    --I_FUND_MANAGER     IN VARCHAR2 --基金/投资经理
    IF I_FUND_MANAGER IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.MANAGER  LIKE ''%' || I_FUND_MANAGER ||
               '%''';
    END IF;
  
    --I_PROD_FIRST_TYPE   一级分类
    IF I_PROD_FIRST_TYPE IS NOT NULL THEN
      V_SQL := V_SQL || ' AND INSTR(''' || I_PROD_FIRST_TYPE ||
               ''',(SELECT ID FROM PIF.TPIF_JRCPFL WHERE NAME=A.PROD_FIRST_TYPE_NAME AND ZT=1 AND GRADE=2))>0  ';
    END IF;
  
    --I_PROD_SECOND_TYPE   二级分类
    IF I_PROD_SECOND_TYPE IS NOT NULL THEN
      V_SQL := V_SQL || ' AND INSTR(''' || I_PROD_SECOND_TYPE ||
               ''',(SELECT ID FROM PIF.TPIF_JRCPFL WHERE NAME=A.PROD_SECOND_TYPE_NAME AND ZT=1 AND GRADE=3))>0  ';
    END IF;
  
    --I_BEGIN_DATE  开始日期
    IF I_BEGIN_DATE IS NOT NULL THEN
      V_SQL := V_SQL ||
               ' AND TO_CHAR(A.ESTABLISHMENTDATE,''YYYYMMDD'') >= ' ||
               I_BEGIN_DATE;
    END IF;
  
    --I_END_DATE   结束日期
    IF I_END_DATE IS NOT NULL THEN
      V_SQL := V_SQL || ' AND TO_CHAR(A.ESTABLISHMENTDATE,''YYYYMMDD'') <=' ||
               I_END_DATE;
    END IF;
  
    --默认排序 净值日期倒序，代码升序
    IF V_SORT IS NULL THEN
      V_SORT := ' NAV_DATE DESC NULLS LAST,PROD_CODE ASC ';
    END IF;
  
    V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_CODE,PROD_NAME,PRODABBNAME,SFWSXS,INVESTADVISOR,ESTABLISHMENTDATE,MANAGER,PROD_FIRST_TYPE_NAME,PROD_SECOND_TYPE_NAME,PRODSCALEAMOUNT,NAV_DATE,UNITNV,ACCUMULATEDUNITNV,NVDAILYGROWTHRATE,RRINSINGLEWEEK,RRINSINGLEMONTH,RRINTHREEMONTH,RRINSIXMONTH,RRINSINGLEYEAR,RRINTWOYEAR,RRINTHREEYEAR,RRINFIVEYEAR,RRSINCETHISYEAR,RRSINCESTART,ANNUALIZEDRRSINCESTART,DAILYPROFIT,LATESTWEEKLYYIELD,APPLYINGTYPE';
  
    --2：私募基金
  ELSIF I_PROD_TYPE = 2 THEN
  
    V_SQL := 'SELECT A.ID AS ID,
                  ''/OperateProcessor?operate=ViewDetail&Table=VPIF_SCSMJJXX&ID=''||A.ID||''&ParamAction=true'' AS DETAILS_LINK_URL,
                  A.REG_CODE AS PROD_CODE,--  基金代码
                  A.FUND_FULL_NAME AS PROD_NAME,--  基金名称
                  A.FUND_NAME,-- 基金简称
                  (CASE WHEN (SELECT COUNT(1) FROM TPIF_CPDM WHERE CPDM=A.REG_CODE)=1 THEN ''是'' ELSE ''否'' END) AS SFWSXS,--  是否我司销售
                  A.FUND_ISSUE_ORG,--  发行机构
                  A.FUND_CUSTODIAN,--  托管机构
                  TO_CHAR(TO_DATE(A.FOUNDATION_DATE,''YYYYMMDD''),''YYYY-MM-DD'')  AS FOUNDATION_DATE,-- 成立日期
                  A.FUND_MEMBER, -- 投资经理
                  A.TERMINAL_STRATEGY, --应用投资策略分类
                  TO_CHAR(B.STATISTIC_DATE,''YYYY-MM-DD'') AS STATISTIC_DATE,
                  TO_CHAR(B.NAV,''FM9990.0000'')  AS NAV,
                  TO_CHAR(B.ADDED_NAV,''FM9990.0000'') AS ADDED_NAV,
                  TO_CHAR(B.Y1_RETURN_A*100,''FM9990.00'')  AS Y1_RETURN_A,
                  TO_CHAR(B.TOTAL_RETURN_A*100,''FM9990.00'')  AS TOTAL_RETURN_A
           FROM PIF.TPIF_SCSMJJXX A
           LEFT JOIN INFO.T_FUND_ADJUSTED_PERFORMANCE B
                  ON A.ID=B.FUND_ID
           WHERE A.FUND_STATUS=1 ';
  
    --I_PROD_NAME       IN VARCHAR2, --产品代码/名称
    IF I_PROD_NAME IS NOT NULL THEN
      V_SQL := V_SQL || ' AND ( A.REG_CODE LIKE ''%' || I_PROD_NAME ||
               '%''  OR  A.FUND_FULL_NAME LIKE ''%' || I_PROD_NAME ||
               '%'') ';
    END IF;
  
    --I_IS_COMPANY_SALL IN VARCHAR2, --    是否我司代销  1:是 0:否
    IF I_IS_COMPANY_SALL IS NOT NULL THEN
      V_SQL := V_SQL ||
               ' AND (SELECT COUNT(1) FROM TPIF_CPDM WHERE CPDM=A.REG_CODE) = ' ||
               I_IS_COMPANY_SALL;
    END IF;
  
    --I_ISSUER          IN VARCHAR2, --   发行机构
    IF I_ISSUER IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.FUND_ISSUE_ORG  LIKE ''%' || I_ISSUER ||
               '%''';
    END IF;
  
    --I_FUND_MANAGER    IN VARCHAR2 --  基金/投资经理
    IF I_FUND_MANAGER IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.FUND_MEMBER  LIKE ''%' || I_FUND_MANAGER ||
               '%''';
    END IF;
  
    --I_BEGIN_DATE  开始日期
    IF I_BEGIN_DATE IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.FOUNDATION_DATE >=  ' || I_BEGIN_DATE;
    END IF;
  
    --I_END_DATE   结束日期
    IF I_END_DATE IS NOT NULL THEN
      V_SQL := V_SQL || ' AND A.FOUNDATION_DATE <= ' || I_END_DATE;
    END IF;
  
    --I_TERMINAL_STRATEGY  一级策略
    IF I_TERMINAL_STRATEGY IS NOT NULL THEN
      V_SQL := V_SQL ||
               ' AND A.TERMINAL_STRATEGY IN (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM = ''SCC_YYTZCLFL'' AND INSTR('','' ||''' ||
               I_TERMINAL_STRATEGY ||
               '''||  '','', '',''||IBM||'','') > 0) ';
    END IF;
  
    --默认排序 净值日期倒序，代码升序
    IF V_SORT IS NULL THEN
      V_SORT := ' STATISTIC_DATE DESC NULLS LAST,PROD_CODE ASC';
    END IF;
  
    V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_CODE,PROD_NAME,FUND_NAME,SFWSXS,FUND_ISSUE_ORG,FUND_CUSTODIAN,FOUNDATION_DATE,FUND_MEMBER,TERMINAL_STRATEGY,STATISTIC_DATE,NAV,ADDED_NAV,Y1_RETURN_A,TOTAL_RETURN_A';
  
    /* --3：券商理财VINFO_QSLCJCXX
    ELSIF I_PROD_TYPE = 3 THEN
    
        V_SQL := 'SELECT A.ID AS ID,
                       ''/OPERATEPROCESSOR?OPERATE=VIEWDETAIL&TABLE=VINFO_QSLCJCXX&ID=''||A.ID||''&PARAMACTION=TRUE'' AS DETAILS_LINK_URL,
                      F_INFO_OPERATION_CODE AS PROD_CODE,-- 产品代码
                      F_INFO_FULLNAME AS PROD_NAME,-- 产品名称
                      F_INFO_NAME,-- 产品简称
                      DECODE(SFWSXS,1,''是'',''否'') AS SFWSXS,--  是否我司销售
                      F_INFO_CORP_FUNDMANAGEMENTCOMP,--  管理人
                      F_INFO_CUSTODIANBANK,--  托管机构
                      SUBSTR(F_INFO_SETUPDATE,1,4)||''-''||SUBSTR(F_INFO_SETUPDATE,5,2)||''-''||SUBSTR(F_INFO_SETUPDATE,7,2) AS F_INFO_SETUPDATE,--  成立日期
                      SUBSTR(F_INFO_MATURITYDATE,1,4)||''-''||SUBSTR(F_INFO_MATURITYDATE,5,2)||''-''||SUBSTR(F_INFO_MATURITYDATE,7,2) AS F_INFO_MATURITYDATE,-- 到期日期
                      DECODE(F_INFO_STATUS,101001000,''已上市'',101002000,''摘牌'',101003000,''发行'') AS  F_INFO_STATUS,-- 存续状态
                      F_INFO_FIRSTINVESTTYPE,--  投资类型
                      F_ISSUE_TOTALUNIT,-- 发行份额
                      F_INFO_EXPECTEDRATEOFRETURN,-- 预期收益率
                      SYL_CLYL,--  成立以来收益率
                      NHSYL,-- 年化收益率
                      F_INFO_MINBUYAMOUNT -- 起点金额
                FROM INFO.TINFO_QSLCJCXX A
               WHERE 1 = 1 ';
                     
                      --I_PROD_NAME       IN VARCHAR2, --产品代码/名称
        IF I_PROD_NAME IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND ( A.F_INFO_OPERATION_CODE LIKE ''%' || I_PROD_NAME || '%''  OR  A.F_INFO_FULLNAME LIKE ''%' || I_PROD_NAME || '%'') ';
        
        END IF;
        
        --I_PROD_TERM       IN VARCHAR2, --  产品期限
        IF I_PROD_TERM IS NOT NULL THEN
          
                   
           IF I_PROD_TERM = 0 THEN 
          
              V_SQL := V_SQL || ' AND TO_DATE(A.F_INFO_MATURITYDATE,''YYYYMMDD'')-TO_DATE(A.F_INFO_SETUPDATE,''YYYYMMDD'')<=365 ' ; 
               
           ELSIF I_PROD_TERM = 1 THEN  
             
              V_SQL := V_SQL || ' AND TO_DATE(A.F_INFO_MATURITYDATE,''YYYYMMDD'')-TO_DATE(A.F_INFO_SETUPDATE,''YYYYMMDD'') BETWEEN 366 AND 730 ' ; 
    
           ELSE 
             
              V_SQL := V_SQL || ' AND TO_DATE(A.F_INFO_MATURITYDATE,''YYYYMMDD'')-TO_DATE(A.F_INFO_SETUPDATE,''YYYYMMDD'') >=731 ' ; 
              
           END IF; 
        
        END IF;
        
    
        --I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级  3|低;7|较低;10|中;15|较高;20|高
        IF I_PROD_RISK_LEVEL IS NOT NULL THEN
          
           --V_SQL := V_SQL || ' AND INSTR('';''||''' || I_PROD_TERM || '''||'';'','';''||A.RISKEVALUATION||'';'')>0 ' ;  
           NULL;          
        
        END IF;
    
        --I_INVEST_TYPE     IN VARCHAR2, --投资类型   STRING  N 1:FOF 2:QDII 3:债券型 4:混合型 5:股票型 6:货币市场型 券商理财（PROD_TYPE=3）适用
        IF I_INVEST_TYPE IS NOT NULL THEN 
          
           V_SQL := V_SQL || ' AND  A.F_INFO_FIRSTINVESTTYPE =  DECODE ( ' || I_INVEST_TYPE || ' ,1, ''FOF'',2,''QDII '',3,''债券型 '',4,''混合型 '',5,''股票型 '',6,''货币市场型'')  ';                     
        
        END IF;
        
        --I_IS_COMPANY_SALL IN VARCHAR2, --    是否我司代销  1:是 0:否
        IF I_IS_COMPANY_SALL IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.SFWSXS = '||I_IS_COMPANY_SALL ;            
        
        END IF;
        --I_ISSUER          IN VARCHAR2, --   发行机构
        IF I_ISSUER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.F_INFO_CORP_FUNDMANAGEMENTCOMP  LIKE ''%' || I_ISSUER || '%''' ;         
        
        END IF;
        --I_FUND_MANAGER    IN VARCHAR2 --  基金/投资经理
         IF I_FUND_MANAGER IS NOT NULL THEN
          
           --V_SQL := V_SQL || ' AND A.MANAGER  LIKE ''%' || I_FUND_MANAGER || '%''' ;  
           NULL;      
        
        END IF;
        IF V_SORT IS NULL THEN
           --排序
           V_SORT    := ' PROD_CODE,F_INFO_CORP_FUNDMANAGEMENTCOMP '; 
    
        END IF;
        
       -- V_SORT    := ' PROD_CODE,F_INFO_CORP_FUNDMANAGEMENTCOMP '; 
        V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_CODE,PROD_NAME,F_INFO_NAME,SFWSXS,F_INFO_CORP_FUNDMANAGEMENTCOMP,F_INFO_CUSTODIANBANK,F_INFO_SETUPDATE,F_INFO_MATURITYDATE,F_INFO_STATUS,F_INFO_FIRSTINVESTTYPE,F_ISSUE_TOTALUNIT,F_INFO_EXPECTEDRATEOFRETURN,SYL_CLYL,NHSYL,F_INFO_MINBUYAMOUNT';
    
    --4：银行理财VINFO_YHLCJBXX
    ELSIF I_PROD_TYPE = 4 THEN
    
          V_SQL := 'SELECT  A.ID AS ID,
                             ''/OPERATEPROCESSOR?OPERATE=VIEWDETAIL&TABLE=VINFO_YHLCJBXX&ID=''||A.ID||''&PARAMACTION=TRUE'' AS DETAILS_LINK_URL,
                            PROD_CODE,-- 产品代码
                            CHI_NAME AS PROD_NAME,--  中文名称
                            DECODE(SFWSXS,1,''是'',''否'') AS SFWSXS,--  是否我司销售
                            COM_ID,--  发行机构
                            FOUND_DT,--  成立日期
                            END_DT,--  到期日期
                            TYP_CODE,--  产品类型
                            RSK_LVL_CODE,--  风险等级
                            INV_PRD_D,-- 投资周期(天)
                            EXP_YLD_MAX,-- 预期收益率上限
                            EXP_YLD_MIN,-- 预期收益率下限
                            IS_ELY_TERM,-- 银行是否可提前终止
                            IS_ELY_REDEM,--  客户是否可以提前赎回
                            IS_PLGE,-- 是否能被质押
                            IS_STRU,-- 是否结构化产品
                            LNK_OBJ_TYP,-- 挂钩标的类型
                            INV_DESC --投资标的类型
                     FROM INFO.TINFO_YHLCCPJBJL A
                     WHERE 1 = 1 ';
                     
                      --I_PROD_NAME       IN VARCHAR2, --产品代码/名称
        IF I_PROD_NAME IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND ( A.PROD_CODE LIKE ''%' || I_PROD_NAME || '%''  OR  A.CHI_NAME LIKE ''%' || I_PROD_NAME || '%'') ';
        
        END IF;
        --I_PROD_TERM       IN VARCHAR2, --  产品期限
        IF I_PROD_TERM IS NOT NULL THEN
                   
           IF I_PROD_TERM = 0 THEN 
          
              V_SQL := V_SQL || ' AND A.TERM_D<=365  ' ; 
              
           ELSIF I_PROD_TERM = 1 THEN  
              
              V_SQL := V_SQL || ' AND  A.TERM_D BETWEEN 366 AND  730 ' ; 
          
           ELSE 
             
              V_SQL := V_SQL || ' AND A.TERM_D >=731 ' ; 
              
           END IF; 
        
        END IF;
    
        --I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级  3|低;7|较低;10|中;15|较高;20|高
        --10|低;20|偏低;30|中;40|偏高;50|高;99|无评价
        IF I_PROD_RISK_LEVEL IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND INSTR('';''||''' || REPLACE(I_PROD_RISK_LEVEL,'1','') || '''||'';'','';''||A.RSK_LVL_CODE||'';'')>0 ' ;            
        
        END IF;
        
        --I_IS_COMPANY_SALL IN VARCHAR2, --    是否我司代销  1:是 0:否
        IF I_IS_COMPANY_SALL IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.SFWSXS = '||I_IS_COMPANY_SALL ;            
        
        END IF;
        
        --I_ISSUER          IN VARCHAR2, --   发行机构
        IF I_ISSUER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.COM_NAME  LIKE ''%' || I_ISSUER || '%''' ;         
        
        END IF;
        \*--I_FUND_MANAGER    IN VARCHAR2 --  基金/投资经理
         IF I_FUND_MANAGER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.MANAGER  LIKE ''%' || I_FUND_MANAGER || '%''' ;         
        
        END IF;*\
        
         V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_CODE,PROD_NAME,SFWSXS,COM_ID,FOUND_DT,END_DT,TYP_CODE,RSK_LVL_CODE,INV_PRD_D,EXP_YLD_MAX,EXP_YLD_MIN,IS_ELY_TERM,IS_ELY_REDEM,IS_PLGE,IS_STRU,LNK_OBJ_TYP,INV_DESC';
    
    --5：信托理财
    ELSIF I_PROD_TYPE = 5 THEN
    
       V_SQL := 'SELECT A.ID AS ID,
                       ''/OPERATEPROCESSOR?OPERATE=VIEWDETAIL&TABLE=VINFO_XTLCJBXX&ID=''||A.ID||''&PARAMACTION=TRUE'' AS DETAILS_LINK_URL,
                      PROD_CODE,-- 产品代码
                      CHI_NAME AS PROD_NAME,--   中文名称
                      DECODE(SFWSXS,1,''是'',''否'') AS SFWSXS,--   是否我司销售
                      COM_NAME,--   发行机构
                      CUST_COM_NAME,--  托管人
                      FOUND_DT,--   成立日期
                      END_DT,--   终止日期
                      TYP_CODE,--   产品类型
                      INV_FLD_CODE,--   资金运用领域
                      RTN_TYP,--  收益类型
                      IS_STRU,--  是否结构化
                      INV_TYE,--  投资类型
                      TERM_TYP_CODE,--  期限类型
                      INV_CHAR ,--  投资特征
                      TRST_MNG ,--  信托经理
                      INV_MNG -- 投资经理
                   FROM INFO.TINFO_XTLCJBXXB A
                   WHERE 1 = 1 ';
                     
        --I_PROD_NAME       IN VARCHAR2, --产品代码/名称
        IF I_PROD_NAME IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND ( A.PROD_CODE LIKE ''%' || I_PROD_NAME || '%''  OR  A.CHI_NAME LIKE ''%' || I_PROD_NAME || '%'') ';
        
        END IF;
        --I_PROD_TERM       IN VARCHAR2, --  产品期限
        IF I_PROD_TERM IS NOT NULL THEN
          
                   
           IF I_PROD_TERM = 0 THEN 
          
              V_SQL := V_SQL || ' AND (NVL(A.END_DT,19000101) - A.FOUND_DT)<=365  ' ; 
              
           ELSIF I_PROD_TERM = 1 THEN  
              
              V_SQL := V_SQL || ' AND (NVL(A.END_DT,19000101) - A.FOUND_DT) BETWEEN 366 AND 730 ' ; 
          
           ELSE 
             
              V_SQL := V_SQL || ' AND (NVL(A.END_DT,19000101) - A.FOUND_DT) BETWEEN 366 AND >=731 ' ; 
              
           END IF; 
        
        END IF;
    
        --I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级  3|低;7|较低;10|中;15|较高;20|高
        IF I_PROD_RISK_LEVEL IS NOT NULL THEN
          
         --  V_SQL := V_SQL || ' AND INSTR('';''||''' || I_PROD_TERM || '''||'';'','';''||A.RISKEVALUATION||'';'')>0 ' ;   
         NULL;         
        
        END IF;
    
        --I_IS_COMPANY_SALL IN VARCHAR2, --    是否我司代销  1:是 0:否
        IF I_IS_COMPANY_SALL IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.SFWSXS = '||I_IS_COMPANY_SALL ;            
        
        END IF;
        --I_ISSUER          IN VARCHAR2, --   发行机构
        IF I_ISSUER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.COM_NAME  LIKE ''%' || I_ISSUER || '%''' ;         
        
        END IF;
        --I_FUND_MANAGER    IN VARCHAR2 --  基金/投资经理
         IF I_FUND_MANAGER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.INV_MNG  LIKE ''%' || I_FUND_MANAGER || '%''' ;         
        
        END IF;
            V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_CODE,PROD_NAME,SFWSXS,COM_NAME,CUST_COM_NAME,FOUND_DT,END_DT,TYP_CODE,INV_FLD_CODE,RTN_TYP,IS_STRU,INV_TYE,TERM_TYP_CODE,INV_CHAR,TRST_MNG,INV_MNG';
    
    --6：保险理财
    ELSE
         V_SQL := 'SELECT A.ID AS ID,
                         ''/OPERATEPROCESSOR?OPERATE=VIEWDETAIL&TABLE=VINFO_BXLCJBXX&ID=''||A.ID||''&PARAMACTION=TRUE'' AS DETAILS_LINK_URL,
                        CHI_NAME AS PROD_NAME,--  中文名称
                        DECODE(SFWSXS,1,''是'',''否'') AS SFWSXS,--   是否我司销售
                        COM_NAME,--   发行机构
                        CUST_COM_NAME,--  托管人
                        FOUND_DT,--   成立日期
                        DUR_END_DT,--   到期日期
                        MIN_COV,--  最低保额(万)
                        MIN_PREM,--   最低保费(元)
                        PAY_OPT,--  缴费方式
                        PAY_DUR,--  缴费期限
                        ISS_SZ,--   实际发行规模(份)
                        PERF_BEN,--   业绩比较基准
                        IN_PRD,--   保险期间
                        SALE_AREA,--  发售地区
                        SALE_CHNL--  销售渠道
                   FROM INFO.TINFO_BXLCJBXX A
                   WHERE 1 = 1 ';
                     
                     
                      --I_PROD_NAME       IN VARCHAR2, --产品代码/名称
        IF I_PROD_NAME IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.CHI_NAME LIKE ''%' || I_PROD_NAME || '%''';
        
        END IF;
        --I_PROD_TERM       IN VARCHAR2, --  产品期限
        IF I_PROD_TERM IS NOT NULL THEN
          
                 
           IF I_PROD_TERM = 0 THEN 
          
              V_SQL := V_SQL || ' AND (A.DUR_END_DT - A.FOUND_DT)<=365  ' ; 
              
           ELSIF I_PROD_TERM = 1 THEN  
              
              V_SQL := V_SQL || ' AND (A.DUR_END_DT - A.FOUND_DT) BETWEEN 366 AND 730 ' ; 
          
           ELSE 
             
              V_SQL := V_SQL || ' AND (A.DUR_END_DT - A.FOUND_DT) BETWEEN 366 AND >=731 ' ; 
              
           END IF; 
        
        END IF;
    
        --I_PROD_RISK_LEVEL IN VARCHAR2, --  风险等级  3|低;7|较低;10|中;15|较高;20|高
        IF I_PROD_RISK_LEVEL IS NOT NULL THEN
          
           --V_SQL := V_SQL || ' AND INSTR('';''||''' || I_PROD_TERM || '''||'';'','';''||A.RISKEVALUATION||'';'')>0 ' ;     
           NULL;       
        
        END IF;
    
      
        --I_IS_COMPANY_SALL IN VARCHAR2, --    是否我司代销  1:是 0:否
        IF I_IS_COMPANY_SALL IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.SFWSXS = '||I_IS_COMPANY_SALL ;            
        
        END IF;
        --I_ISSUER          IN VARCHAR2, --   发行机构
        IF I_ISSUER IS NOT NULL THEN
          
           V_SQL := V_SQL || ' AND A.COM_NAME  LIKE ''%' || I_ISSUER || '%''' ;         
        
        END IF;
        --I_FUND_MANAGER    IN VARCHAR2 --  基金/投资经理
         IF I_FUND_MANAGER IS NOT NULL THEN
          
           --V_SQL := V_SQL || ' AND A.MANAGER  LIKE ''%' || I_FUND_MANAGER || '%''' ;   
           NULL;      
        
        END IF;
           V_COLLIST := 'ID,DETAILS_LINK_URL,PROD_NAME,SFWSXS,COM_NAME,CUST_COM_NAME,FOUND_DT,DUR_END_DT,MIN_COV,MIN_PREM,PAY_OPT,PAY_DUR,ISS_SZ,PERF_BEN,IN_PRD,SALE_AREA,SALE_CHNL';
    
                       */
  END IF;
  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  IF V_SORT IS NULL THEN
    --排序
    V_SORT := ' ID DESC ';
  
  END IF;

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
  
END;
/

