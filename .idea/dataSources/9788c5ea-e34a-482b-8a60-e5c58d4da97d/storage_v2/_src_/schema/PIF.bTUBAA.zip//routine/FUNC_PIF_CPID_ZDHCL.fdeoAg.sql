create FUNCTION FUNC_PIF_CPID_ZDHCL( I_TJRQ IN NUMBER, --统计日期
                                                    I_KSRQ IN NUMBER,  --回测开始时间
                                                    I_CPID IN NUMBER  --产品ID
)RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算最大回测率

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        WUJINFENG   1.0.0    2020/01/15                新增
  --------------------------------------------------------------------------------*/
  V_ZDJZ    NUMBER:=0; ---最大净值
  V_ZDHC    NUMBER:=0; ---最大回撤

BEGIN
    FOR CUR_HC IN (SELECT LJJZ FROM TPIF_CPJZXX A
                    WHERE A.CPID = I_CPID
                      AND EXISTS (SELECT 1
                             FROM LIVEBOS.TXTJYR
                            WHERE ZRR = JYR
                              AND JYR = A.JZRQ
                              AND JYR >= I_KSRQ
                              AND JYR <= I_TJRQ) ORDER BY A.JZRQ ASC) LOOP

      IF CUR_HC.LJJZ >= V_ZDJZ THEN
        V_ZDJZ := CUR_HC.LJJZ;
      ELSIF (1 - CUR_HC.LJJZ / V_ZDJZ) * 100 > V_ZDHC THEN
        V_ZDHC := (1 - CUR_HC.LJJZ / V_ZDJZ) * 100;
     END IF;

    END LOOP;

    RETURN V_ZDHC;
EXCEPTION
  WHEN OTHERS THEN
    RETURN -999;
END;
/

