create PROCEDURE PCX_FJDB_QBFJ(O_CODE     OUT INTEGER, --返回值
                                          O_NOTE     OUT VARCHAR2, --返回信息
                                          O_RESULT   OUT SYS_REFCURSOR, --返回结果集
                                         
                                          
                                          I_USERID   IN NUMBER, --登陆用户ID
                                          I_OBJ_NAME IN VARCHAR2, --对象名称
                                          I_OBJ_COL  IN VARCHAR2, --附件列
                                          I_OBJ_ID   IN VARCHAR2 ---对象ID串 --3956,3955,3954,3953,3952
                                          ) AS
  /******************************************************************************
   项目名称：产品中心C5标准版本
   所属用户：PIF
   概要说明：附件打包-全部附件
  
    修订记录：
    修订日期       版本号       修订人             修改内容简要说明
    2020.08.04    V1.0.0        WUJINFENG                  新增
  ******************************************************************************/
  V_SQL          VARCHAR2(18000);
  V_DOC_PATH     VARCHAR2(200);

BEGIN

  --INIT
  O_CODE         := 1;
  O_NOTE         := '成功';

  --CHECK
  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_YHID 不能为空 ';
    RETURN;
  END IF;

  IF I_OBJ_NAME IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_OBJ_NAME 不能为空 ';
    RETURN;
  END IF;

  IF I_OBJ_COL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_OBJ_COL 不能为空 ';
    RETURN;
  END IF;

  IF I_OBJ_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_OBJ_ID 不能为空 ';
    RETURN;
  END IF;

  SELECT PARAMVALUE||I_OBJ_NAME||'/'
    INTO V_DOC_PATH
    FROM LIVEBOS.TSYSPARAM
   WHERE PARAMNAME = 'document-path';

  V_SQL := 'SELECT ID AS  ID, 
           ''' || I_OBJ_NAME || ''' AS OBJ_NAME,
           ''' || I_OBJ_COL  || ''' AS DOC_COL,
             ' || I_OBJ_COL  || '   AS DOC_NAME,
           ''' || V_DOC_PATH || ''' AS DOC_DIRECTORY
          FROM ' || I_OBJ_NAME || '
         WHERE INSTR('',''||''' || I_OBJ_ID ||  '''||'','','',''||ID||'','')>0  ';

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL ;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

