create PROCEDURE PCX_PIF_CPJM_CPFLGXS(O_CODE   OUT NUMBER,
                                                 O_NOTE   OUT VARCHAR2,
                                                 O_RESULT OUT SYS_REFCURSOR) AS
  /******************************************************************
  项目名称：产品中心-产品视图-产品分类【01】
  所属用户：PIF
  概要说明：查询产品分类关系树.
               i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                               并不是什么是否都需要分页,看情形而言.
               i_PageNo      --页码
               i_PageLength  --页长
               i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               i_Sort        --排序字段
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
      PIF.TFP_CPLX 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品分类关系树.
  
        1.查询产品分类关系树.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/10/28     1.0.1   guonanhua           新增.
      2014/11/18     1.0.1   戴文生              调整为查询产品展示分类数据.
      2015/06/01     1.0.2   刘浪浪              只显示启用的分类
  *********************************************************************************************************************/
  V_SQL    VARCHAR2(32767);
  v_err_msg varchar2(10000);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';
  --启用产品大类
  V_SQL := 'SELECT (CASE WHEN GRADE = 2 THEN CPDL ELSE ID END) AS ID,
                        NAME AS name ,
                        GRADE - 1 AS grade,
                        FID AS FID
                   FROM PIF.TPIF_CPZSFL
                  WHERE GRADE > 0
                  AND   ZT=1
                  ORDER BY grade, XSPX';

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    v_err_msg := SQLERRM ;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || v_err_msg FROM DUAL;
  
END PCX_PIF_CPJM_CPFLGXS;
/

