create PROCEDURE PRO_PIF_SMCPSH(O_CODE    OUT NUMBER,
                                           O_NOTE    OUT VARCHAR2,
                                           I_LX       IN NUMBER,   --1 单条审核 ，  2 批量审核
                                           I_ID      IN VARCHAR2,  --对象ID或ID串（批量审核用）
                                           I_SMCPID  IN NUMBER,    --被审核的那条记录的ID（单条审核用）
                                           I_USERID  IN NUMBER
                                           ) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募产品审核逻辑
                用于私募产品的审核和批量审核，选中记录，点击审核，将该记录的ID传进来
                到V_IDS中
      语法信息：


      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-03-05     1.0.0     高昆                创建
          2021-05-11     1.0.1     高昆              审核通过进入私募运营产品表 
                                                     废弃，不用了 
  ***********************************************************************/
  V_IDS VARCHAR2(2000);  --私募产品表记录ID串，逗号分隔

  V_YJFL  NUMBER;  --一级策略
  V_EJFL  NUMBER;  --二级策略
  V_SJFL  NUMBER;  --三级策略
--  V_DXCPDM  VARCHAR2(200);
  CUR_SMCP TPIF_SMCP%ROWTYPE;

  V_COUNT NUMBER;

  V_CPDM_SMYY_ID NUMBER;     --TPIF_CPDM_SMYY表修改的产品的id
  V_CPDM_SMYY_NEXT_ID NUMBER;  --TPIF_CPDM_SMYY表的next id
  V_CPDM_SMYY_IDS VARCHAR2(2000) := ''; --记录这次审核后，TPIF_CPDM_SMYY表里新增或修改的记录的id，后面cpdm表
                                      --更新数据时，只需针对这些记录更新，不用全表更新
BEGIN
  IF I_USERID IS NULL THEN
    O_NOTE := 'I_USERID不能为空！';
    O_CODE := -1;
    RETURN;
  END IF;

  IF I_LX IS NULL THEN
    O_NOTE := 'I_LX不能为空！';
    O_CODE := -1;
    RETURN;
  END IF;

  IF I_LX = 1 THEN     --单条审核
    IF I_SMCPID IS NULL THEN
      O_NOTE := 'I_SMCPID不能为空！';
      O_CODE := -1;
      RETURN;
    ELSE
      V_IDS := TO_CHAR(I_SMCPID);     --  900258
    END IF;
  ELSE                 --批量审核
    IF I_ID IS NULL THEN
      O_NOTE := 'I_ID不能为空！';
      O_CODE := -1;
      RETURN;
    ELSE                   --入参格式     [900258, 900025]
      V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_ID, ' ', ''), '[', ''), ']', ''), ',', ';');
    END IF;             --替换后格式      900258;900025
  END IF;

  FOR CUR_DYCPID IN( SELECT DYCPID ,WM_CONCAT(KHBH) AS KHBH FROM TPIF_SMCP WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0 GROUP BY DYCPID ) LOOP

       SELECT * INTO CUR_SMCP FROM TPIF_SMCP B WHERE B.DYCPID = CUR_DYCPID.DYCPID AND ID=V_IDS AND B.SHZT=2 ;

       V_YJFL:=CUR_SMCP.YJCL;
       V_EJFL:=CUR_SMCP.EJCL;
       V_SJFL:=CUR_SMCP.SJCL;
       /*V_DXCPDM := TRIM(CUR_SMCP.CPDM);
       -- 私募产品表里cpdm有值，需要对比cpdm表里所有清洗进来的代销产品（）
       IF V_DXCPDM IS NOT NULL THEN
         SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDM A WHERE A.DXCPDM = V_DXCPDM;
         IF V_COUNT > 0 THEN
           UPDATE TPIF_CPDM A
              SET A.ZYNM     = NVL(A.ZYNM, CUR_SMCP.DYCPID)
            WHERE A.DXCPDM = V_DXCPDM;
         END IF;
       END IF;*/
       SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM_SMYY A WHERE A.ZYNM = CUR_DYCPID.DYCPID /*AND CPXL=2 */;

       IF V_COUNT = 0 THEN   --TPIF_CPDM_SMYY表不存在
      --    V_CPDM_SMYY_NEXT_ID := LIVEBOS.FUNC_NEXTID('TPIF_CPDM_SMYY');
          SELECT SEQ_TPIF_CPDM_SMYY.NEXTVAL
            INTO V_CPDM_SMYY_NEXT_ID
            FROM DUAL;
          V_CPDM_SMYY_IDS := V_CPDM_SMYY_IDS||';'||V_CPDM_SMYY_NEXT_ID;  
                                                          -- 第一次  ''||';'||'123'   即 ';123'
          INSERT INTO TPIF_CPDM_SMYY                           -- 第二次  ';123'||';'||'124'
            (ID, --  ID                                   --    即   ';123;124'
             JRCPFL, -- 金融产品分类
             CPXL, -- 产品系列
             CPNBZT, -- 产品内部状态
             CPDM, -- 产品代码
             DXCPDM, -- 代销产品代码
             CPMC, -- 产品名称
             CLRQ, -- 产品成立日期
             SMCLYJFL,
             SMCLEJFL,
             SMCLSJFL,
             CPGLRID,
             ZYNM,
             CPYWLX,
             ZHXGR,
             ZHXGSJ,
             GLKHH)
          VALUES
            (V_CPDM_SMYY_NEXT_ID,
             '500100', --私募证券投资基金
             2,
             8, --已上架
             (SELECT REG_CODE
                FROM SRC_PIF.T_FUND_INFO B
               WHERE B.FUND_ID = CUR_SMCP.DYCPID),
             CUR_SMCP.CPDM,
             CUR_SMCP.CPMC,
             CUR_SMCP.CLRQ,
             V_YJFL,
             V_EJFL,
             V_SJFL,
             CUR_SMCP.JJGLR,
             CUR_SMCP.DYCPID,
             CUR_SMCP.YWLX,
             CUR_SMCP.ZHXGR,
             SYSDATE,
             CUR_DYCPID.KHBH);

       ELSE   --TPIF_CPDM_SMYY表 已存在
         SELECT ID INTO V_CPDM_SMYY_ID FROM TPIF_CPDM_SMYY  A WHERE A.ZYNM = CUR_DYCPID.DYCPID;
         V_CPDM_SMYY_IDS := V_CPDM_SMYY_IDS||';'||V_CPDM_SMYY_ID;

         UPDATE TPIF_CPDM_SMYY A
            SET A.SMCLYJFL = V_YJFL,
                A.SMCLEJFL = V_EJFL,
                A.SMCLSJFL = V_SJFL,
                A.CPGLRID  = NVL(CUR_SMCP.JJGLR, A.CPGLRID),
                A.ZYNM     = NVL(A.ZYNM, CUR_SMCP.DYCPID),
                A.CPYWLX   = CUR_SMCP.YWLX, --产品业务类型
                A.CPDM    =
                (SELECT REG_CODE
                   FROM SRC_PIF.T_FUND_INFO B
                  WHERE B.FUND_ID = CUR_SMCP.DYCPID),
                A.DXCPDM   = CUR_SMCP.CPDM,
                A.GLKHH    = CUR_DYCPID.KHBH
          WHERE A.ZYNM = CUR_SMCP.DYCPID;

       END IF ;

  END LOOP ;

  /******第二步 ：通过柜台基金信息表补充部分字段信息******/
  MERGE INTO PIF.TPIF_CPDM_SMYY M
  USING (SELECT PRODTA_NO, --  TA代码
                PROD_CODE, --  产品代码
                PROD_NAME, --  产品名称
                PRODSPELL_CODE, --  拼音代码
                IPO_BEGIN_DATE, --  募集开始日期
                IPO_END_DATE, --  募集结束日期
                PROD_BEGIN_DATE, --  产品成立日期
                PROD_END_DATE, --  产品结束日期
                PROM_BEGIN_DATE, --  推介开始日期
                PROM_END_DATE, --  推介结束日期
                PROD_TERM, --  产品期限
                PROD_STATUS, --  产品交易状态
                MONEY_TYPE, --   币种类别
                ISSUE_PRICE, --  发行价格
                PAR_VALUE, --  每份面值
                TRIM(CHARGE_TYPE) AS CHARGE_TYPE, --  基金收费方式
                TRIM(DIVIDEND_WAY) AS DIVIDEND_WAY, --  基金分红方式
                MIN_SHARE, --  个人最低认购金额
                PROD_MIN_BALA, --  产品最低募集金额
                PROD_MAX_BALA, --  产品最高募集金额
                PROD_REAL_BALA, --  产品实际募集金额
                YEAR_DAYS, --  产品年化天数
                PRODPRE_RATIO, --  产品预期年收益率
                PROD_RATIO_STR, --  产品预期年收益率文字描述

                PRODCOMPANY_NAME, --  产品注册登记机构名称
                PROD_MANAGER, --  产品管理人
                PROD_TRUSTEE, --  产品托管人

                TRIM(INVEST_TYPE) AS INVEST_TYPE, -- 产品投资类别
                TRIM(INCOME_TYPE) AS INCOME_TYPE, -- 产品收益类型
                TRIM(PROD_INVEST_TERM) AS PROD_INVEST_TERM, -- 产品投资期限
                TRIM(PRODRISK_LEVEL) AS PRODRISK_LEVEL, -- 产品风险等级
                TRIM(ASSESS_LEVEL) AS ASSESS_LEVEL, -- 产品评估等级
                TRIM(LOW_CORP_RISK_LEVEL) AS LOW_CORP_RISK_LEVEL, -- 最低风险等级
                TRIM(MIN_ASSET_NEED) AS MIN_ASSET_NEED, -- 投资者最低资产要求
                TRIM(EN_PROF_FLAG) AS EN_PROF_FLAG, -- 允许专业投资者类型

                CURRENT_AMOUNT_LOW, --持仓量的最低值
                MAX_SUBSCRIBE_NUM, --认购人数上限
                MIN_SWITCH_IN_BALANCE, --最低转换金额
                TRANS_LIMITSHARE, --最少转换份额
                SWITCH_UNIT, --转换单位
                REDEEM_LIMITSHARE, --赎回最低份额
                REDEMPTION_UNIT, --赎回最小单位
                TRIM(REDEEM_USE_FLAG) AS REDEEM_USE_FLAG, --赎回资金可用标志
                TRIM(MAX_ALLOTRATIO) AS MAX_ALLOTRATIO --每次最大可申购比例
           FROM SRC_PIF.DWD_PRD_PRODCODE_DD A
          WHERE TRIM(A.PRODCODE_TYPE) IS NOT NULL 
            AND EXISTS (SELECT 1
                   FROM TPIF_SMCP B
                  WHERE B.SHZT = 2
                    AND TRIM(B.CPDM) = TRIM(A.PROD_CODE)
                    AND TRIM(B.CPDM) IS NOT NULL)) N
  ON (TRIM(M.DXCPDM) = TRIM(N.PROD_CODE) AND TRIM(M.DXCPDM) IS NOT NULL AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || M.ID || ';') > 0)
                                                      --选择 这次审核后，TPIF_CPDM_SMYY表里新增或修改的记录
  WHEN MATCHED THEN
    UPDATE
       SET M.CPTA   = N.PRODTA_NO,
           M.CPMC   = N.PROD_NAME,
           M.PYDM   = N.PRODSPELL_CODE,
           M.MJKSRQ = N.IPO_BEGIN_DATE,
           M.MJJSRQ = N.IPO_END_DATE,
           M.CLRQ   = N.PROD_BEGIN_DATE,
           M.DQRQ   = N.PROD_END_DATE,
           M.TJQSRQ = N.PROM_BEGIN_DATE,
           M.TJZZRQ = N.PROM_END_DATE,
           M.CPQX   = N.PROD_TERM,
           M.CPJYZT = N.PROD_STATUS,
           M.HBZL   = N.MONEY_TYPE,
           M.FXJG   = N.ISSUE_PRICE,
           M.MFMZ   = N.PAR_VALUE,
           M.SFFS   = N.CHARGE_TYPE,
           M.FHFS   = N.DIVIDEND_WAY,
           M.QTJE   = N.MIN_SHARE,

           M.CPZDMJJE = N.PROD_MIN_BALA, --  产品最低募集金额
           M.CPZGMJJE = N.PROD_MAX_BALA, --  产品最高募集金额
           M.CPSJMJJE = N.PROD_REAL_BALA, --  产品实际募集金额

           M.NHTS    = N.YEAR_DAYS,
           M.YQSYL   = N.PRODPRE_RATIO,
           M.YQSYLMS = N.PROD_RATIO_STR,
           M.CPTAMC  = PRODCOMPANY_NAME,
           M.CPGLRID = NVL(M.CPGLRID,
                           (SELECT ID
                              FROM TPIF_JGDM A
                             WHERE (A.JGMC = N.PROD_MANAGER OR
                                   A.JGJC = N.PROD_MANAGER)
                               AND ROWNUM = 1)),
           M.CPTGR   = N.PROD_TRUSTEE,

           M.TZLB      = N.INVEST_TYPE,
           M.SYLX      = N.INCOME_TYPE,
           M.CPTZQX    = N.PROD_INVEST_TERM,
           M.CPFXDJ    = N.PRODRISK_LEVEL,
           M.CPPGDJ    = N.ASSESS_LEVEL,
           M.ZDFXDJ    = N.LOW_CORP_RISK_LEVEL,
           M.ZDZCYQ    = N.MIN_ASSET_NEED,
           M.YXZYTZZLX = N.EN_PROF_FLAG,

           M.CCLDZDZ   = N.CURRENT_AMOUNT_LOW, --持仓量的最低值
           M.RGRSSX    = MAX_SUBSCRIBE_NUM, --认购人数上限
           M.ZDZHJE    = N.MIN_SWITCH_IN_BALANCE, --最低转换金额
           M.ZSZHFE    = N.TRANS_LIMITSHARE, --最少转换份额
           M.ZHDW      = N.SWITCH_UNIT, --转换单位
           M.SHZDZ     = N.REDEEM_LIMITSHARE, --赎回最低份额
           M.SHZXDW    = N.REDEMPTION_UNIT, --赎回最小单位
           M.SHZJKYBZ  = N.REDEEM_USE_FLAG, --赎回资金可用标志
           M.MCZDKSGBL = N.MAX_ALLOTRATIO; --每次最大可申购比例

  /******第三步 ：从朝阳永续更新 ******/
  FOR CUR_FUND_ID IN(SELECT ID,CPID,ZYNM,CPGLRID,HBZL FROM TPIF_CPDM_SMYY WHERE ZYNM IS NOT NULL AND INSTR(V_CPDM_SMYY_IDS||';',';'||ID||';')>0 ) LOOP

        UPDATE TPIF_CPDM_SMYY M
           SET (M.CPJC,--产品简称
                M.DYCPQC,--对应产品全称
                M.BABH,
                M.BASJ,
                M.CPZHFS,--N
                M.CPTZBD,
                M.CPTGR,
                M.TZGW,
                M.TZFZR,
                M.TZFW,
                M.TZMB,
                M.TZFX,
                M.TZLN,
                M.CPDP,
                M.CPYJX,--N
                M.CPZSX,--N
                M.CPJJ,
                M.ZYNM,
                M.CPJD,
                M.DQRQ,
                M.CLRQ,
                M.HBZL,
                M.QTJE,
                M.CPZDMJJE,
                M.CPZGMJJE,
                M.CPSJMJJE,
                M.TJQSRQ,
                M.TJZZRQ,
                M.PYDM,
                M.CPGLRID
                )
                =
               (SELECT FUND_NAME, -- 基金简称
                       FUND_FULL_NAME,   --  对应产品全称
                       REG_CODE,
                       TO_CHAR(REG_TIME, 'YYYYMMDD') AS REG_TIME,
                       DECODE(FUND_TYPE_INVESTMENT_WAY,'FOF','3','MOM','4','TOF','2','TOL','5','TOT－一对多','1','伞形','7','链式基金','8','其他间接投资','6','FOF,其他间接投资','3;6','FOF,链式基金','3;8','其他间接投资,链式基金','6;8') AS FUND_TYPE_INVESTMENT_WAY,--
                       FUND_TYPE_TARGET,
                       --FUND_MANAGER_NOMINAL,
                       FUND_CUSTODIAN,
                       FUND_MANAGER,
                       FUND_MEMBER,
                       INVESTMENT_RANGE,
                       INVESTMENT_TARGET,
                       ORIENTATION,
                       INVESTMENT_IDEA,
                       APPRAISE,
                       PRECAUTIOUS_LINE, --  预警线(元)
                       STOP_LOSS_LINE, --止损线(元)
                       INSTRUCTION, --简介
                       FUND_ID,
                       (CASE WHEN FUND_STATUS='存续中' THEN 3 WHEN FUND_STATUS='已终止' THEN 5 END),
                      TO_CHAR(END_DATE,'YYYYMMDD'),
                      TO_CHAR(FOUNDATION_DATE,'YYYYMMDD'),
                      NVL(CUR_FUND_ID.HBZL,DECODE(CURRENCY,'人民币现钞',0,'美元现汇',1,'港元现汇',2)),
                      MIN_PURCHASE_AMOUNT,--最低认购金额(元)
                      ISSUING_SCALE,--  发行规模(元)
                      ISSUING_SCALE,--  发行规模(元)
                      REAL_FINANCING_SCALE,--  实际募集规模
                      TO_CHAR(RECOMMENDATION_START,'YYYYMMDD'),
                      TO_CHAR(RECOMMENDATION_END,'YYYYMMDD'),
                      FUND_NAME_PY,
                      NVL(CUR_FUND_ID.CPGLRID,(SELECT ID FROM TPIF_JGDM A WHERE A.JGMC = NVL(B.FUND_MANAGER_NOMINAL,B.FUND_MANAGER)))
                  FROM SRC_PIF.T_FUND_INFO B
                 WHERE FUND_ID = CUR_FUND_ID.ZYNM )
         WHERE M.ZYNM = CUR_FUND_ID.ZYNM ;

         SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM_SMYY A WHERE A.ID = CUR_FUND_ID.ID AND A.CPGLRID IS NULL ;

        IF V_COUNT >0  THEN  --产品管理人ID为空

             UPDATE TPIF_CPDM_SMYY M
               SET (M.CPGLRID)

               =(SELECT (SELECT ID FROM TPIF_JGDM A WHERE A.JGJC = NVL(B.FUND_MANAGER_NOMINAL,B.FUND_MANAGER))
                      FROM SRC_PIF.T_FUND_INFO B
                     WHERE FUND_ID = CUR_FUND_ID.ZYNM )
             WHERE M.ZYNM = CUR_FUND_ID.ZYNM ;

        END IF;

  END LOOP ;

  --产品阶段处理  2募集期 3 存续期 4 清盘期 5 结束期
    /*1  开放期
    2  认购期
    4  产品成立
    5  产品终止
    6  停止交易
    7  停止申购
    8  停止赎回*/
  UPDATE TPIF_CPDM_SMYY A
     SET A.CPJD = DECODE(A.CPJYZT, 1, 3, 2, 2, 4, 3, 5, 5, 3)
   WHERE A.CPJYZT IS NOT NULL
     AND NVL(A.CPJD, -1) <> 5
     AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || A.ID || ';') > 0;


  --通过朝阳永续更新修正金融产品分类
   /*100100  信托
     100101  私募公司
     100102  公募专户及子公司
     100103  券商集合理财
     100104  银行
     100105  期货资管
     100107  保险公司及其子公司的资产管理计划

     100101100 私募证券投资基金
     100101101 私募其他投资基金
     100101102 私募股权投资基金
     100101103 私募创业投资基金
     100101104 私募资产配置基金

   */
  MERGE INTO TPIF_CPDM_SMYY M
  USING (SELECT FUND_ID, TYPE_CODE
           FROM SRC_PIF.T_FUND_TYPE_MAPPING
          WHERE TYPE_CODE IN ('100100',
                              '100102',
                              '100103',
                              '100104',
                              '100105',
                              '100107',
                              '100101100',
                              '100101101',
                              '100101102',
                              '100101103',
                              '100101104')) N
  ON (M.ZYNM = N.FUND_ID AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || M.ID || ';') > 0)
  WHEN MATCHED THEN
    UPDATE
       SET M.JRCPFL = NVL(DECODE(N.TYPE_CODE,
                                 '100100',
                                 '600100',
                                 '100102',
                                 '300400',
                                 '100103',
                                 '100100',
                                 '100104',
                                 '800100',
                                 '100105',
                                 '700200',
                                 '100107',
                                 '900100',
                                 '100101100',
                                 '500100',
                                 '100101101',
                                 '500500',
                                 '100101102',
                                 '500200',
                                 '100101103',
                                 '500300',
                                 '100101104',
                                 '500400'),
                          M.JRCPFL),
           M.CPXL   = NVL(DECODE(N.TYPE_CODE,
                                 '100100',
                                 8,
                                 '100102',
                                 7,
                                 '100103',
                                 3,
                                 '100104',
                                 5,
                                 '100105',
                                 9,
                                 '100107',
                                 6,
                                 '100101100',
                                 2,
                                 '100101101',
                                 2,
                                 '100101102',
                                 2,
                                 '100101103',
                                 2,
                                 '100101104',
                                 2),
                          M.CPXL);

  --更新CPID和ID值一致方便后续维护
  UPDATE TPIF_CPDM_SMYY A SET A.CPID = A.ID WHERE A.CPID IS NULL AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || A.ID || ';') > 0;

/*  --产品期限 更新
  UPDATE TPIF_CPDM_SMYY A
     SET A.CPQX = TO_DATE(A.DQRQ, 'YYYYMMDD') - TO_DATE(A.CLRQ, 'YYYYMMDD')
   WHERE LENGTH(A.CLRQ) = 8
     AND LENGTH(A.DQRQ) = 8
     AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || A.ID || ';') > 0;*/

  --日期处理   为0的改为null
  UPDATE TPIF_CPDM_SMYY A
           SET A.MJKSRQ = (CASE WHEN  A.MJKSRQ = 0 THEN NULL ELSE A.MJKSRQ END),
               A.MJJSRQ = (CASE WHEN  A.MJJSRQ = 0 THEN NULL ELSE A.MJJSRQ END),
               A.CLRQ = (CASE WHEN  A.CLRQ = 0 THEN NULL ELSE A.CLRQ END),
               A.DQRQ = (CASE WHEN  A.DQRQ = 0 THEN NULL ELSE A.DQRQ END),
               A.TJQSRQ = (CASE WHEN  A.TJQSRQ = 0 THEN NULL ELSE A.TJQSRQ END),
               A.TJZZRQ = (CASE WHEN  A.TJZZRQ = 0 THEN NULL ELSE A.TJZZRQ END)
           WHERE  INSTR(V_CPDM_SMYY_IDS || ';', ';' || A.ID || ';') > 0;


  --适当性 ，适合投资者类型
  UPDATE TPIF_CPDM_SMYY A
         SET A.SHTZZLX = （CASE WHEN A.CPFXDJ=0 THEN '1;2;3;4;5'
                                WHEN A.CPFXDJ=1 THEN '2;3;4;5'
                                WHEN A.CPFXDJ=2 THEN '3;4;5'
                                WHEN A.CPFXDJ=3 THEN '4;5'
                                WHEN A.CPFXDJ=4 THEN '5'  END )
         WHERE A.CPFXDJ IS NOT NULL AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || A.ID || ';') > 0;


/*  --产品最新规模（元）
  MERGE INTO TPIF_CPDM_SMYY M
    USING(SELECT FUND_ID ,ASSET_SCALE
           FROM ( SELECT FUND_ID,
                         ASSET_SCALE,
                         ROW_NUMBER() OVER(PARTITION BY FUND_ID ORDER BY STATISTIC_DATE DESC) PX
                  FROM SRC_PIF.T_FUND_ASSET_SCALE
                  WHERE ASSET_SCALE > 0 )
           WHERE PX = 1
          ) N
    ON (M.ZYNM = N.FUND_ID AND INSTR(V_CPDM_SMYY_IDS || ';', ';' || M.ID || ';') > 0)
    WHEN MATCHED THEN UPDATE SET M.CPZXGM = N.ASSET_SCALE ;*/

  O_CODE := 1;
  O_NOTE := '成功';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;

END;
/

