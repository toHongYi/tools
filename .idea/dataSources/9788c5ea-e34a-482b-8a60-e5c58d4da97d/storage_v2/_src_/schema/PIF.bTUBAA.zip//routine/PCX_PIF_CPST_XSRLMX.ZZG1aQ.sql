create PROCEDURE PCX_PIF_CPST_XSRLMX(O_CODE           OUT NUMBER,
                                                O_NOTE           OUT VARCHAR2,
                                                O_RESULT         OUT SYS_REFCURSOR,
                                                I_CURRENT        IN NUMBER, --页码   
                                                I_PAGESIZE       IN NUMBER, --页长 
                                                I_PAGING         IN NUMBER, --是否分页 
                                                I_SORT           IN VARCHAR2, --排序规模 
                                                I_TOTAL          IN OUT NUMBER, --记录总数
                                                I_QUERY_DATE     IN VARCHAR2, --查询日期
                                                I_USERID         IN NUMBER,
                                                I_is_first_issue IN VARCHAR2 := 1
                                                
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品视图-产品销售日历明细
  
      语法信息：
           输入参数：     I_CURRENT  IN NUMBER, --页码   
                          I_PAGESIZE IN NUMBER, --页长 
                          I_PAGING   IN NUMBER, --是否分页 
                          I_SORT     IN STRING, --排序规模 
                          I_TOTAL    IN OUT NUMBER --记录总数  
                          I_QUERY_DATE IN STRING, --查询日期
                          I_USERID     IN NUMBER
           输出参数：   O_RESULT
      逻辑说明：
           1、
      ----------------------------------------------------------
      操作人    版本号      时间                      操作
        wujinfeng  1.0    2020/05/07                   新增
  ***********************************************************************/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;

BEGIN

  IF I_USERID IS NULL THEN
  
    O_CODE := -1;
    O_NOTE := '入参【I_USERID】不允许为空';
    RETURN;
  
  END IF;

  IF I_QUERY_DATE IS NULL THEN
  
    O_CODE := -1;
    O_NOTE := '入参【I_QUERY_DATE】不允许为空';
    RETURN;
  
  END IF;

  --否则返回结果集合
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  V_SQL := ' select prod_id,
       prod_code,
       prod_name,
       invManager,
       prodFirstType,
       manager,
       prod_type,
       subscribe_origin,
       prod_risk_level,
       perbenchmark,
       timeLimit,
       salesRevenue,
       wm_concat(openDayType) as openDayType,
       periods
  from (select dm.cpid as prod_id, --产品id
       dm.cpjc as prod_name, --产品简称
       dm.cpdm as prod_code, --产品代码
       dm.tzfzr as invManager, --投资经理
       (select note from livebos.txtdm where fldm=''PIF_CPXL_CPZX'' and ibm= dm.cpxl) as prodFirstType,--产品类型
       (select jgjc from TPIF_JGDM where dm.cpglrid = id) as manager, --管理人
       (select name from TPIF_JRCPFL where id = dm.jrcpfl) as prod_type, --一级分类
       (select coalesce(xs.grsczdje, xs.grzdsgje, xs.grzdrgje)
          from tpif_cpdm_p_gt_xskz xs
         where xs.cpid = dm.cpid) as subscribe_origin, /* 购买起点;优先取个人首次最低金额，然后申购，最后认购*/
       (select p.note
          from livebos.txtdm p
         where p.fldm = ''PIF_CPFXDJ_CPZX''
           and p.ibm = dm.cpfxdj) as prod_risk_level, --产品风险等级Rx
       null as perbenchmark, --业绩基准
       (select bwl
          from (select jl.bwl as bwl, rl.cpid as cpid
                  from TPIF_JYRL_GZJL jl, TPIF_JYRL rl
                 where to_char(rl.rq, ''yyyyMMdd'') = '||I_QUERY_DATE||'
                   and jl.shzt = 2
                   and instr('';'' || rl.gzjl ||'';'', '';'' || jl.id || '';'') > 0
                 order by jl.czrq desc)
         where rownum = 1
           and cpid = dm.cpid) as timeLimit, --期限
       to_char((select wm_concat(rate_type_des||''：''||replace(wm_concat(title),'','','';'')) from (
select cpid,rate_range||''，分成比例：''||devide_rate||''%，员工发放比例：''||staff_rate ||''%'' as title,rate_type_des from tpif_jjfcbl where if_executed = 1  order by rate_type,cpid asc,beginvalue asc
) a where a.cpid = dm.cpid group by rate_type_des)) as salesRevenue, --销售创收
       (select ywmc from TPIF_JYRL_YWLX where y.ywlx = id) as openDayType, --开放日类型
       null as periods --期数 
  from pif.tpif_cpdm dm, TPIF_JYRL y
 where to_char(y.rq, ''yyyyMMdd'') = '||I_QUERY_DATE||'
   and y.cpid = dm.cpid
union

select distinct cp.cpid as prod_id, --产品id
       cp.cpjc as prod_name, --产品简称
       cp.cpdm as prod_code, --产品代码
       cp.tzfzr as invManager, --投资经理
       (select note from livebos.txtdm where fldm=''PIF_CPXL_CPZX'' and ibm= cp.cpxl) as prodFirstType,--产品类型
       (select jgjc from TPIF_JGDM where cp.cpglrid = id) as manager, --管理人
       (select name from TPIF_JRCPFL where id = cp.jrcpfl) as prod_type, --一级分类
       (select coalesce(xs.grsczdje, xs.grzdsgje, xs.grzdrgje)
          from tpif_cpdm_p_gt_xskz xs
         where xs.cpid = cp.cpid) as subscribe_origin, /* 购买起点;优先取个人首次最低金额，然后申购，最后认购*/
       (select p.note
          from livebos.txtdm p
         where p.fldm = ''PIF_CPFXDJ_CPZX''
           and p.ibm = cp.cpfxdj) as prod_risk_level, --产品风险等级Rx
       dq.yjjz as perbenchmark, --业绩基准
       dq.bwl as timeLimit, --期限
 to_char((select wm_concat(rate_type_des||''：''||replace(wm_concat(title),'','','';'')) from (
select cpid,rate_range||''，分成比例：''||devide_rate||''%，员工发放比例：''||staff_rate ||''%'' as title,rate_type_des from tpif_jjfcbl where if_executed = 1  order by rate_type,cpid asc,beginvalue asc
) a where a.cpid = cp.cpid group by rate_type_des
)) as salesRevenue, --销售创收
       (case
         when (case
                when '||I_QUERY_DATE||' BETWEEN TO_CHAR(s.xsksrq, ''yyyyMMdd'') AND
                     TO_CHAR(s.xsjsrq, ''yyyyMMdd'') then
                 s.ywlx
                when '||I_QUERY_DATE||' BETWEEN dq.rgksrq AND dq.rgjsrq then
                 3
              end) = 1 then
          ''申购''
         when (case
                when '||I_QUERY_DATE||' BETWEEN TO_CHAR(s.xsksrq, ''yyyyMMdd'') AND
                     TO_CHAR(s.xsjsrq, ''yyyyMMdd'') then
                 s.ywlx
                when '||I_QUERY_DATE||' BETWEEN dq.rgksrq AND dq.rgjsrq then
                 3
              end) = 2 then
          ''赎回''
         when (case
                when '||I_QUERY_DATE||' BETWEEN TO_CHAR(s.xsksrq, ''yyyyMMdd'') AND
                     TO_CHAR(s.xsjsrq, ''yyyyMMdd'') then
                 s.ywlx
                when '||I_QUERY_DATE||' BETWEEN dq.rgksrq AND dq.rgjsrq then
                 3
              end) = 3 then
          ''认购''
       end) as openDayType, --开放日类型
       dq.qs as periods --期数 
 from pif.tpif_cpdm cp, LIVEBOS.TXTJYR a,TPIF_DQCP dq left join TPIF_DQCP_SSSZ s on dq.id = s.tpif_dqcp_id
 where ('||I_QUERY_DATE||' BETWEEN TO_CHAR(s.xsksrq, ''yyyyMMdd'') AND
       TO_CHAR(s.xsjsrq, ''yyyyMMdd''))
   and dq.cpid = cp.cpid
   and a.jyr in('||I_QUERY_DATE||'))
 group by prod_id,
          prod_code,
          prod_name,
          invManager,
          prodFirstType,
          manager,
          prod_type,
          subscribe_origin,
          prod_risk_level,
          perbenchmark,
          timeLimit,
          salesRevenue,
          periods';
  --AND a.SFCY='||(case when I_is_first_issue=0 then 2 else I_is_first_issue end);

  IF V_SORT IS NULL THEN
    V_SORT := 'prod_id DESC';
  END IF;
  V_COLLIST := 'prod_id,prod_code,prod_name,invManager,prodFirstType,manager,prod_type,subscribe_origin,prod_risk_level,perbenchmark,timeLimit,salesRevenue,openDayType,periods';

  DBMS_OUTPUT.PUT_LINE(V_SQL);
  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

