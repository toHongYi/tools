create PROCEDURE PRO_PIF_JYRL_JZJYR_TB(O_CODE   OUT NUMBER, --返回值
                                                  O_NOTE   OUT VARCHAR2, --返回消息
                                                  I_CPID   IN NUMBER, --产品ID
                                                  I_CPDM   IN VARCHAR2, --产品代码
                                                  I_RGKSRQ IN NUMBER, --认购开始日期
                                                  I_CPCLR  IN NUMBER, --产品成立日
                                                  I_CPBAR  IN NUMBER, --产品备案日
                                                  I_FBQQSR IN NUMBER, --封闭期起始日
                                                  I_FBQJSR IN NUMBER, --封闭期结束日
                                                  I_CPDQR  IN NUMBER, --产品到期日
                                                  I_QTJZR  IN NUMBER := NULL --其他基准日
                                                  ) IS
  /*
  **功能说明：基准交易日同步
  **创建人：王大一
  **创建日期：2016-11-03
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **王大一     V1.0.0    2016-11-03   创建
  **王大一     V1.0.1    2016-11-04   募集起始日改为认购开始日期
  */
  V_COUNT INTEGER; --计数变量
BEGIN
  O_CODE := 1;
  O_NOTE := '';
  BEGIN
    SELECT COUNT(0) INTO V_COUNT FROM TPIF_JYRL_JZJYR WHERE CPID = I_CPID;
  EXCEPTION
    WHEN OTHERS THEN
      V_COUNT := 0;
  END;

  IF I_CPID IS NULL THEN
    O_NOTE := '产品ID不能为空!';
    RETURN;
  END IF;

  IF V_COUNT = 0 THEN
    INSERT INTO TPIF_JYRL_JZJYR
      (ID, CPID, CPDM, RGKSRQ, CPCLR, CPBAR, FBQQSR, FBQJSR, CPDQR, QTJZR)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_JYRL_JZJYR'),
       I_CPID,
       I_CPDM,
       I_RGKSRQ,
       I_CPCLR,
       I_CPBAR,
       I_FBQQSR,
       I_FBQJSR,
       I_CPDQR,
       I_QTJZR);
  ELSE
    UPDATE TPIF_JYRL_JZJYR
       SET RGKSRQ = NVL(I_RGKSRQ, RGKSRQ),
           CPCLR  = NVL(I_CPCLR, CPCLR),
           CPBAR  = NVL(I_CPBAR, CPBAR),
           FBQQSR = NVL(I_FBQQSR, FBQQSR),
           FBQJSR = NVL(I_FBQJSR, FBQJSR),
           CPDQR  = NVL(I_CPDQR, CPDQR),
           QTJZR  = NVL(I_QTJZR, QTJZR)
     WHERE CPID = I_CPID;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_JZJYR_TB;
/

