create type pljson_null force under pljson_element
(
  constructor function pljson_null return self as result,
  overriding member function is_null return boolean,
  overriding member function value_of(max_byte_size number default null, max_char_size number default null) return varchar2
) not final

/

