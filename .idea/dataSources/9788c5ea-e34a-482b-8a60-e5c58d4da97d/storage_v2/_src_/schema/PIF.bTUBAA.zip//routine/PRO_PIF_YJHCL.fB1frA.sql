create PROCEDURE PRO_PIF_YJHCL(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2 --返回消息
                                          ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：白名单机构回访收发件-邮件后处理
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-11-03     1.0       HanQN              创建
  ***********************************************************************/
  V_COUNT NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';


  --收件记录更新私募白名单管理人
  UPDATE TPIF_SJJL S
     SET JGID =
         (SELECT JGID
            FROM TPIF_SMGLRBMD
           WHERE EMAIL = S.EMAIL
             AND ROWNUM = 1)
   WHERE JGID IS NULL;

  COMMIT;
  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '邮件后处理,未知错误'
                ELSE
                 '邮件后处理,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

