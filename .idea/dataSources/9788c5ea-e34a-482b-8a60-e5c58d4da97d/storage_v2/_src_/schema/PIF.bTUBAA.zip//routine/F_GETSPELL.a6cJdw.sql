create FUNCTION F_GETSPELL(P_CNSTR IN VARCHAR2,
                                            P_SIGN  IN NUMBER DEFAULT NULL --默认简拼 ，1|全拼（中间有空格）
                                            )
/******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取汉字拼音
        语法信息：
             输入参数：
             输出参数：
        逻辑说明：
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1     陈勇军             新增
    ***********************************************************************/
 RETURN VARCHAR2 AS
    LV_SPELL VARCHAR2(200);
BEGIN

    IF P_CNSTR IS NULL THEN

        RETURN '';

    END IF;
    IF (P_SIGN = 1) THEN
        --全拼
        SELECT HZPY.GETHZFULLPY(P_CNSTR) INTO LV_SPELL FROM DUAL;
    ELSE
        --简拼
        SELECT HZPY.HZPYCAP(P_CNSTR) INTO LV_SPELL FROM DUAL;
    END IF;
    RETURN(LOWER(LV_SPELL));
END;
/

