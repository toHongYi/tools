create PROCEDURE PRO_PIF_CPXSTJ(O_RESULT OUT SYS_REFCURSOR,
                                           I_USERID IN NUMBER, --用户ID
                                           I_KSRQ   IN NUMBER, --开始日期
                                           I_JSRQ   IN NUMBER, --结束日期
                                           I_FGS    IN NUMBER, --分公司ID
                                           I_LX     IN VARCHAR2 --1营业部、2分公司
                                           ) AS

  /******************************************************************
  项目名称：财通证券产品中心-产品销售统计
  所属用户：PIF
  概要说明：产品销售统计
  
  语法信息：
       输出参数：
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分
  
  修订记录：
      修订日期        版本号    修订人             修改内容简要说明
      2021-06-23      1.0      GAOKUN             新增.
  ********************************************************************/

  V_NOTE VARCHAR2(1000); --报错信息输出

BEGIN

  IF I_USERID IS NULL THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_CPXL ';

  IF I_LX = 1 THEN
  
    IF I_FGS IS NULL THEN
      INSERT INTO TEMP_CPXL
        (MC, GMQYL, SMQYL, QYL, GSL, HBL, QT, ZJ)
        SELECT *
          FROM (SELECT B.NAME, 1 AS LX, NVL(SUM(A.XSL), 0) AS XSL --1公募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1 --营业部
                        ) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A --产品代销月表-汇总统计
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.XSCPXL = 1 --公募
                   AND A.BQLXID = 900013 --权益类
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME, 2 AS LX, NVL(SUM(A.XSL), 0) AS XSL --2私募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1 --营业部
                        ) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.XSCPXL = 2 --私募
                   AND A.BQLXID = 900013 --权益类
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       (CASE
                         WHEN A.BQLXID = 900013 THEN
                          3 --3权益类(合计)
                         WHEN A.BQLXID = 900012 THEN
                          4 --4固收类
                         WHEN A.BQLXID = 900014 THEN
                          5 --5货币类
                       END) AS LX,
                       NVL(SUM(A.XSL), 0) AS XSL
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.BQLXID IN (900012, 900014, 900013) --固收类900012、货币类900014、权益类900013
                 GROUP BY B.NAME, A.BQLXID
                
                UNION
                
                SELECT B.NAME,
                       6 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --6其他
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.BQLXID IS NULL --其他
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       7 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --7总计(万元)
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                 GROUP BY B.NAME)
        
        PIVOT(MAX(XSL)
           FOR LX IN(1 AS "公募权益类",
                     2 AS "私募权益类",
                     3 AS "权益类(合计)",
                     4 AS "固收类",
                     5 AS "货币类",
                     6 AS "其他",
                     7 AS "总计(万元)"));
    
    ELSE
    
      INSERT INTO TEMP_CPXL
        (MC, GMQYL, SMQYL, QYL, GSL, HBL, QT, ZJ)
        SELECT *
          FROM (SELECT B.NAME, 1 AS LX, NVL(SUM(A.XSL), 0) AS XSL --1公募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1 --营业部
                         START WITH ID = I_FGS --入参 分公司ID
                        CONNECT BY PRIOR ID = FID) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A --产品代销月表-汇总统计
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.XSCPXL = 1 --公募
                   AND A.BQLXID = 900013 --权益类
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME, 2 AS LX, NVL(SUM(A.XSL), 0) AS XSL --2私募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1 --营业部
                         START WITH ID = I_FGS --入参 分公司ID
                        CONNECT BY PRIOR ID = FID) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ --入参  开始月份
                   AND A.YF <= I_JSRQ --入参  结束月份
                   AND A.XSCPXL = 2 --私募
                   AND A.BQLXID = 900013 --权益类
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       (CASE
                         WHEN A.BQLXID = 900013 THEN
                          3 --3权益类(合计)
                         WHEN A.BQLXID = 900012 THEN
                          4 --4固收类
                         WHEN A.BQLXID = 900014 THEN
                          5 --5货币类
                       END) AS LX,
                       NVL(SUM(A.XSL), 0) AS XSL
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1
                         START WITH ID = I_FGS
                        CONNECT BY PRIOR ID = FID) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB_HZTJ A
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IN (900012, 900014, 900013) --固收类900012、货币类900014、权益类900013
                 GROUP BY B.NAME, A.BQLXID
                
                UNION
                
                SELECT B.NAME,
                       6 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --6其他
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1
                         START WITH ID = I_FGS
                        CONNECT BY PRIOR ID = FID) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IS NULL --其他
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       7 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --7总计(万元)
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 1
                         START WITH ID = I_FGS
                        CONNECT BY PRIOR ID = FID) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.YYBID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                 GROUP BY B.NAME)
        
        PIVOT(MAX(XSL)
           FOR LX IN(1 AS "公募权益类",
                     2 AS "私募权益类",
                     3 AS "权益类(合计)",
                     4 AS "固收类",
                     5 AS "货币类",
                     6 AS "其他",
                     7 AS "总计(万元)"));
    
    END IF;
  
  ELSE
    IF I_FGS IS NULL THEN
      --分公司为空，查全部分公司
    
      INSERT INTO TEMP_CPXL
        (MC, GMQYL, SMQYL, QYL, GSL, HBL, QT, ZJ)
        SELECT *
          FROM (SELECT B.NAME,
                       1 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --1公募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID = 900013 --权益类
                   AND A.XSCPXL = 1 --公募
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       2 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --2私募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID = 900013 --权益类
                   AND A.XSCPXL = 2 --私募
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       (CASE
                         WHEN A.BQLXID = 900013 THEN
                          3 --3权益类(合计)
                         WHEN A.BQLXID = 900012 THEN
                          4 --4固收类
                         WHEN A.BQLXID = 900014 THEN
                          5 --5货币类
                       END) AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IN (900012, 900014, 900013) --固收类900012、货币类900014、权益类900013
                 GROUP BY B.NAME, A.BQLXID
                
                UNION
                
                SELECT B.NAME,
                       6 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --6其他
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IS NULL
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       7 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --7总计(万元)
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                 GROUP BY B.NAME)
        
        PIVOT(MAX(XSL)
           FOR LX IN(1 AS "公募权益类",
                     2 AS "私募权益类",
                     3 AS "权益类(合计)",
                     4 AS "固收类",
                     5 AS "货币类",
                     6 AS "其他",
                     7 AS "总计(万元)"));
    
    ELSE
      --分公司有值，查该分公司
    
      INSERT INTO TEMP_CPXL
        (MC, GMQYL, SMQYL, QYL, GSL, HBL, QT, ZJ)
        SELECT *
          FROM (SELECT B.NAME,
                       1 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --1公募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2
                           AND ID = I_FGS) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID = 900013 --权益类
                   AND A.XSCPXL = 1 --公募
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       2 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --2私募权益类
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2
                           AND ID = I_FGS) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID = 900013 --权益类
                   AND A.XSCPXL = 2 --私募
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       (CASE
                         WHEN A.BQLXID = 900013 THEN
                          3 --3权益类(合计)
                         WHEN A.BQLXID = 900012 THEN
                          4 --4固收类
                         WHEN A.BQLXID = 900014 THEN
                          5 --5货币类
                       END) AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2
                           AND ID = I_FGS) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IN (900012, 900014, 900013) --固收类900012、货币类900014、权益类900013
                 GROUP BY B.NAME, A.BQLXID
                
                UNION
                
                SELECT B.NAME,
                       6 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --6其他
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2
                           AND ID = I_FGS) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                   AND A.BQLXID IS NULL
                 GROUP BY B.NAME
                
                UNION
                
                SELECT B.NAME,
                       7 AS LX,
                       NVL(ROUND(SUM(A.XSL) / 10000, 2), 0) AS XSL --7总计(万元)
                  FROM (SELECT BRANCH_ID, NAME
                          FROM LIVEBOS.LBORGANIZATION
                         WHERE LX = 2
                           AND ID = I_FGS) B
                  LEFT JOIN DSC_STAT.TPIF_STAT_CPDXYB A --产品代销月表
                    ON A.FGSID = B.BRANCH_ID
                   AND A.YF >= I_KSRQ
                   AND A.YF <= I_JSRQ
                 GROUP BY B.NAME)
        
        PIVOT(MAX(XSL)
           FOR LX IN(1 AS "公募权益类",
                     2 AS "私募权益类",
                     3 AS "权益类(合计)",
                     4 AS "固收类",
                     5 AS "货币类",
                     6 AS "其他",
                     7 AS "总计(万元)"));
    
    END IF;
  END IF;

  IF I_LX = 2 AND I_FGS IS NOT NULL THEN
    --不需要 总计
    OPEN O_RESULT FOR
      SELECT MC,
             NVL(GMQYL, 0) AS GMQYL,
             NVL(SMQYL, 0) AS SMQYL,
             NVL(QYL, 0) AS QYL,
             NVL(GSL, 0) AS GSL,
             NVL(HBL, 0) AS HBL,
             NVL(QT, 0) AS QT,
             NVL(ZJ, 0) AS ZJ
        FROM TEMP_CPXL;
  
  
  ELSE
    --需要总计
  
    OPEN O_RESULT FOR
      SELECT MC,
             NVL(GMQYL, 0) AS GMQYL,
             NVL(SMQYL, 0) AS SMQYL,
             NVL(QYL, 0) AS QYL,
             NVL(GSL, 0) AS GSL,
             NVL(HBL, 0) AS HBL,
             NVL(QT, 0) AS QT,
             NVL(ZJ, 0) AS ZJ,
             1 SX --总计在最后
        FROM TEMP_CPXL
      UNION
      SELECT '总计' AS MC,
             SUM(GMQYL) AS GMQYL,
             SUM(SMQYL) AS SMQYL,
             SUM(QYL) AS QYL,
             SUM(GSL) AS GSL,
             SUM(HBL) AS HBL,
             SUM(QT) AS QT,
             SUM(ZJ) AS ZJ,
             0 SX
        FROM TEMP_CPXL
       ORDER BY SX DESC;
  
  
  END IF;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
  
  
END;
/

