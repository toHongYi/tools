create PROCEDURE PRO_PIF_CPXXSJDR_CPDJ( --产品信息数据导入
                                                  O_CODE OUT INT, --返回结果代码
                                                  O_NOTE OUT VARCHAR2, --返回结果说明
                                                  I_RQ   IN NUMBER, --日期
                                                  I_JGDM IN VARCHAR2, --机构代码
                                                  I_UID  IN NUMBER, --用户ID, TUSER.ID
                                                  I_IP   IN VARCHAR2 --操作站点
                                                  ) AS
    /******************************************************************************
     *
     *文件名称：PRO_PIF_CPXXSJDR_CPDJ
     *项目名称：海通产品中心
     *创建日期：2015-12-02
     *功能说明：TXT文件导入产品后产品登记处理
      I_RQ     IN NUMBER  --日期
      I_JGDM   IN VARCHAR2, --机构代码
      I_UID IN VARCHAR2, --用户ID, TUSER.ID

     *-------------------------------------------------------------------------------------------------------
     *修改者        版本号        修改日期         说明
     *孙远何        V1.0.1        2015-12-08       新增：TXT文件导入产品后产品登记处理
     *孙远何        V1.0.2        2016-03-07       修改：不处理产品分类、增加处理产品规模历史数据、新增日涨跌幅指标
     *孙远何        V1.0.3        2016-05-06       修改：产品规模、基金份额数值不保证正确性，导行情时不更新
     *孙远何        v1.0.4        2016-10-20       修改：去掉用V_IDS串作为PRO_PIF_CPXXSJDR_CPDJ更新的匹配项，直接用机构代码
     *牛玉洁        v1.0.5        2017-02-09       修改：滚动产品取产品id最小的记录
     *牛玉洁        v1.0.6        2017-02-22       修改：向产品净值表中插入 黄金宝金价 换算系数 等字段
     *牛玉洁        v1.0.7        2017-03-23       修改：向产品代码表中插入 黄金宝金价 字段
     *牛玉洁        v1.0.8        2017-06-30       修改：增加向otc推送万份收益率和7日年化收益率
     *牛玉洁        v1.0.9        2017-09-13       修改：增加fjxx的格式化
     *郭宇钒        V1.0.10       2018-08-30       修改：增加基金基金的日涨幅信息
     *易  洋        V1.0.11       2018-10-17       修改：产品净值表中增加CPDM的字段写入
    ---------------------------------------------------------------------------------------------------------*/

    V_ORGID  NUMBER(8);
    V_FXJG   NUMBER(8);

BEGIN

    O_CODE := 1;
    O_NOTE := '成功';

    --取发行机构
    SELECT ID INTO V_FXJG FROM tORG_CODE_INFO WHERE ORG_CODE = I_JGDM;
    SELECT ORGID INTO V_ORGID FROM livebos.TUSER WHERE ID = I_UID;


    --V_BQ := 'tPROD_NAV_INFO  ';
      /*基金单位净值
      累计基金单位净值
      货币基金万份收益
      货币基金七日年化收益率
      货币基金年收益率*/

    MERGE /*+APPEND*/
    INTO tPROD_NAV_INFO A
    USING (SELECT T1.ID CPID,
                  T2.JZRQ,  --基金净值日期
                  T2.JJJZ,--基金单位净值
                  T2.LJJZ,-- 累计基金净值
                  T2.HBJJWFSY, --货币基金万份收益
                  DECODE(T2.HBJJWFSYZF, 1, '-', '') HBJJWFSYZF, --货币基金万份收益正负 0-正  1-负
                  T2.HBJJQRNHSYL, --货币基金七日年化收益率
                  DECODE(T2.HBJJQRNHSYLZF, 1, '-', '') HBJJQRNHSYLZF, -- 货币基金七日年化收益率正负 0-正  1-负
                  T2.HBJJNSYL, --货币基金年收益率
                  DECODE(T2.HBJJNSYLZF, 1, '-', '')  HBJJNSYLZF --货币基金年益率正负 0-正  1-负
             FROM Tprod_Basic_Info T1, TPIF_CPDM_TMP_OF T2
            WHERE T1.PROD_MANAGER = V_FXJG
              AND T1.PROD_CODE = T2.CPDM
              AND T2.JJFXR = V_FXJG
              AND T1.ID IN (SELECT MIN(ID) FROM Tprod_Basic_Info GROUP BY PROD_CODE)) B
    ON (A.PROD_ID = B.CPID AND A.NAV_DATE = B.JZRQ)
    WHEN MATCHED THEN
        UPDATE
           SET A.UNIT_NAV    = NVL(B.JJJZ, A.UNIT_NAV),
               A.TOTAL_NAV    = NVL(B.LJJZ, A.TOTAL_NAV),
               A.D7_ANNUAL_YIELD_RATE   = NVL(TO_NUMBER(B.HBJJQRNHSYLZF || B.HBJJQRNHSYL), A.D7_ANNUAL_YIELD_RATE),
               A.UNIT_YIELD   = NVL(TO_NUMBER(B.HBJJWFSYZF || B.HBJJWFSY), A.UNIT_YIELD),
               A.YEAR_YIELD_RATE   = NVL(TO_NUMBER(B.HBJJNSYLZF || B.HBJJNSYL), A.YEAR_YIELD_RATE),
               A.CONFIRM_STATUS = 1,
               A.ENTRY_PERSON    = 0, 
               A.ENTRY_TIME = SYSDATE, 
               A.data_src = 1
              
    WHEN NOT MATCHED THEN
        INSERT
            (id, 
             prod_id, 
             nav_date, 
             unit_nav, 
             total_nav, 
             unit_yield, 
             d7_annual_yield_rate, 
             year_yield_rate, 
             data_src, 
             confirm_status, 
             entry_person, 
             entry_time
            )
        VALUES
            (livebos.FUNC_NEXTID('tPROD_NAV_INFO'),
             B.CPID,
             B.JZRQ,
             B.JJJZ,
             NVL(B.LJJZ, B.JJJZ),
             TO_NUMBER(B.HBJJWFSYZF || B.HBJJWFSY),
             TO_NUMBER(B.HBJJQRNHSYLZF || B.HBJJQRNHSYL),
             TO_NUMBER(B.HBJJWFSYZF || B.HBJJWFSY),
             1,
             1,
             0,
             sysdate
            );


    COMMIT;

    O_CODE := 1;
    O_NOTE := '07文件参数导入成功 ';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := '错误: ' || SQLERRM;

END PRO_PIF_CPXXSJDR_CPDJ;
/

