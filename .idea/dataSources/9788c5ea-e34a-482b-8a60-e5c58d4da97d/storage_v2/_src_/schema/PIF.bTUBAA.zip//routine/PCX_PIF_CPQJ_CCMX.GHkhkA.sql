create PROCEDURE PCX_PIF_CPQJ_CCMX(O_CODE    OUT NUMBER,
                                              O_NOTE    OUT VARCHAR2,
                                              O_RESULT  OUT SYS_REFCURSOR,
                                              I_USERID  IN NUMBER, --用户ID
                                              I_PROD_ID IN NUMBER, --产品ID
                                              I_TYPE    IN NUMBER -- 1|股票,2|债券
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询持仓明细
  所属用户：PIF
  概要说明：查询持仓明细.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询持仓明细.
        
        公募取聚源的数据，私募数据太少且旧，不要
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/29     1.0.0.1   TUMENG             新增.
      2021-12-10     1.0.0.2   GAOKUN           根据财通的表进行修改
  ************************************************************************/
  V_SQL      VARCHAR2(4000);
  V_COUNT    NUMBER;
  V_CPLX     NUMBER; --产品类型
  V_CPDM     VARCHAR2(200); --根据入参 CPID 从产品代码表获取产品代码
  V_MAINCODE VARCHAR2(200); --公募基金概况表的主代码
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  BEGIN
    --获取产品类型，产品代码
    SELECT CPXL, TRIM(CPDM)
      INTO V_CPLX, V_CPDM
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
      V_CPDM := '0';
  END;

  IF V_CPLX = 1 THEN
    --公募
    SELECT COUNT(1) --先根据SECUCODE判断是否有记录
      INTO V_COUNT
      FROM INFO.TINFO_JJGK
     WHERE SECUCODE = V_CPDM;
  
    IF V_COUNT > 0 THEN
      --有则取主代码
      SELECT MAINCODE
        INTO V_MAINCODE
        FROM INFO.TINFO_JJGK
       WHERE SECUCODE = V_CPDM;
    
    ELSE
      --没有则根据后端代码取
      BEGIN
        SELECT MAINCODE
          INTO V_MAINCODE
          FROM INFO.TINFO_JJGK
         WHERE APPLYINGCODEBACK = V_CPDM;
      EXCEPTION
        WHEN OTHERS THEN
          V_MAINCODE := '0';
      END;
    END IF;
  
    IF I_TYPE = 1 THEN
      --股票
      V_SQL := 'SELECT A.STOCKCODE AS CODE,
                       B.CHINAMEABBR AS NAME,
                       TO_CHAR(A.MARKETVALUE / 10000, ''FM99999990.0999'') AS MKTVALUE,
                       TO_CHAR(A.RATIOINNV * 100, ''FM9990.00'') AS OCCUPY_NAV_RATIO
                  FROM INFO.TINFO_JJZCGPZH A, INFO.TINFO_ZQZB B
                 WHERE A.SECUCODE = ''' || V_MAINCODE || '''
                   AND A.STOCKINNERCODE = B.INNERCODE
                   AND A.INVESTTYPE IN (1, 3) --1-综合投资，3-指数投资
                   AND A.REPORTDATE = (SELECT MAX(D.REPORTDATE)
                                         FROM INFO.TINFO_JJZCGPZH D
                                        WHERE D.SECUCODE = ''' ||
               V_MAINCODE || ''')
              ORDER BY A.RATIOINNV DESC';
    
    ELSE
      --债券
      V_SQL := 'SELECT A.BONDTRANSACTIONCODE AS CODE,
                       A.BONDABBR            AS NAME,
                       TO_CHAR(A.MARKETVALUE / 10000, ''FM99999990.0999'') AS MKTVALUE,
                       TO_CHAR(A.RATIOINNV * 100, ''FM9990.00'') AS OCCUPY_NAV_RATIO
                  FROM INFO.TINFO_JJZQZH A
                 WHERE A.SECUCODE = ''' || V_MAINCODE || '''
                   AND A.REPORTDATE = (SELECT MAX(B.REPORTDATE)
                                         FROM INFO.TINFO_JJZQZH B
                                        WHERE B.SECUCODE = ''' ||
               V_MAINCODE || '''
                                          AND B.IFINCONVERTIBLETERM = 0)
                  AND A.IFINCONVERTIBLETERM = 0 -- 0 重仓债券投资明细
             ORDER BY A.RATIOINNV ASC';
    END IF;
  
  ELSE
    V_SQL := 'SELECT NULL AS CODE,
                   NULL AS NAME,
                   NULL AS MKTVALUE,
                   NULL AS OCCUPY_NAV_RATIO
              FROM DUAL
             WHERE 1=0';
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_CCMX;
/

