create procedure pcx_pif_cpqj_hssyzs_out(o_code        out number,
                                                o_note        out varchar2,
                                                o_result      out sys_refcursor,
                                                i_userid in number, --用户ID
                                                i_ip    in varchar2,
                                                i_prod_id     in number, --产品ID
                                                i_granularity in number --粒度  1|一个月,2|三个月,3|半年,4|一年,5|今年以来,6|成立以来
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-累计收益走势
  所属用户：PIF
  概要说明：累计收益走势.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        累计收益走势.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/30     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql     varchar2(32767);
  v_s_nav   number(16, 4); --基准净值
  v_s_close number(16, 4); --基准沪深300
  v_date    number(8);
  v_t_date  number(8); --转换为交易日
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_prod_id is null then
    o_note := '产品ID不允许为空！';
    return;
  end if;
  if i_granularity is null then
    o_note := '粒度不允许为空！';
    return;
  end if;
    if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;
  if i_granularity = 1 then
    --一个月
    select to_number(to_char(add_months(sysdate, -1), 'yyyymmdd'))
      into v_date
      from dual;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;
  if i_granularity = 2 then
    --三个月
    select to_number(to_char(add_months(sysdate, -3), 'yyyymmdd'))
      into v_date
      from dual;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;
  if i_granularity = 3 then
    --半年
    select to_number(to_char(add_months(sysdate, -6), 'yyyymmdd'))
      into v_date
      from dual;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;
  if i_granularity = 4 then
    --一年
    select to_number(to_char(add_months(sysdate, -12), 'yyyymmdd'))
      into v_date
      from dual;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;
  if i_granularity = 5 then
    --今年以来
    select to_number(to_char(sysdate, 'yyyy') || '0101')
      into v_date
      from dual;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;
  if i_granularity = 6 then
    --成立以来
    select nvl(a.establish_day, 29991231)
      into v_date
      from pif.tprod_basic_info a
     where id = i_prod_id;
    select a.jyr into v_t_date from livebos.txtjyr a where a.zrr = v_date;
  end if;

  --取基准累计净值以及沪深300值
  begin
    select a.total_nav
      into v_s_nav
      from pif.tprod_nav_info a
     where a.prod_id = i_prod_id
       and a.nav_date = v_t_date;
  exception
    when others then
      o_note := '基准净值未取到！';
      return;
  end;
  begin
    select a.yesterday_close
      into v_s_close
      from pif.tindex_quota a
     where a.data_date = v_t_date
       and a.index_code = '399300';
  exception
    when others then
      o_note := '基准沪深300值未取到！';
      return;
  end;
  v_sql := 'select (total_nav-' || v_s_nav || ')/' || v_s_nav ||
           ' total_yeild_rate,
             (a.yesterday_close-' || v_s_close || ')/' ||
           v_s_close || ' close_yeild_rate ,
                   nav_date as nav_date
            from tprod_nav_info t,tindex_quota a
            where prod_id = ' || i_prod_id || '
            and t.nav_date = a.data_date
            and a.index_code = ''399300''
            and nav_date >= ' || v_date;
  dbms_output.put_line(v_sql);

  open o_result for v_sql;

  o_code := 0;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end pcx_pif_cpqj_hssyzs_out;
/

