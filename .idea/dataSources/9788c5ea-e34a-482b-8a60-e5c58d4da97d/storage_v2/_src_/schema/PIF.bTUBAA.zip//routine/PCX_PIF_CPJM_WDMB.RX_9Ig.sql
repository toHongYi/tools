create PROCEDURE PCX_PIF_CPJM_WDMB(O_CODE      OUT NUMBER,
                                              O_NOTE      OUT VARCHAR2,
                                              O_RESULT    OUT SYS_REFCURSOR,
                                              I_userID    IN NUMBER, --用户ID
                                              I_PROD_TYPE IN VARCHAR2 --产品分类ID,可为空. wujinfeng 0918调整为直接传模板ID
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品视图-我适用的模版
  所属用户：PIF
  概要说明：查询当前登录人所在部门适用的模版列表.
   
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
      PIF.TPIF_JRCPFL 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询当前登录人所在部门适用的模版列表.
  
        1.当前登录人所在部门适用的模版可能有多个，按照最近配置日期排序.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/10/29     4.0.0.1   guonanhua           新增.
  *********************************************************************************************************************/
  V_SQL    VARCHAR2(32767);
  V_ERRMSG VARCHAR2(300); --错误信息
  V_COUNT  NUMBER(12);
  V_MBIDS  VARCHAR2(2000);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_userid IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【用户ID】';
    RETURN;
  END IF;

  IF I_PROD_TYPE IS NULL THEN
    --验证是否存在适用于当前登录人的通用模版
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_TYMBDY WHERE MBZT = 1;
    IF V_COUNT = 0 THEN
      O_CODE := -2;
      O_NOTE := '系统异常：当前无启用的通用模版！';
      RETURN;
    ELSIF V_COUNT > 0 THEN
      V_MBIDS := '';
      IF I_userid = 0 THEN
        SELECT ';' || REPLACE(WM_CONCAT(ID), ',', ';')
          INTO V_MBIDS
          FROM TPIF_TYMBDY
         WHERE MBZT = 1;
      ELSE
        --级别:指定用户>组织角色>角色>组织>所有用户!
        FOR CUR IN (SELECT *
                      FROM TPIF_TYMBDY A
                     WHERE A.MBZT = 1
                       AND EXISTS (SELECT 1
                              FROM TPIF_TYMBDY_SYFW B
                             WHERE B.TPIF_TYMBDY_ID = A.ID
                               AND B.FWLX = 3)) LOOP
          FOR CUR_S IN (SELECT *
                          FROM TPIF_TYMBDY_SYFW
                         WHERE TPIF_TYMBDY_ID = CUR.ID
                           AND FWLX = 3) LOOP
            IF INSTR(';' || CUR_S.SYYH || ';', ';' || I_userid || ';') > 0 THEN
              V_MBIDS := V_MBIDS || ';' || CUR.ID;
            END IF;
          END LOOP;
        END LOOP;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_TYMBDY A
                       WHERE A.MBZT = 1
                         AND EXISTS (SELECT 1
                                FROM TPIF_TYMBDY_SYFW B
                               WHERE B.TPIF_TYMBDY_ID = A.ID
                                 AND B.FWLX = 4)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_TYMBDY_SYFW
                           WHERE TPIF_TYMBDY_ID = CUR.ID
                             AND FWLX = 4) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.LBMEMBER
               WHERE USERID = I_userid
                 AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0
                 AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_TYMBDY A
                       WHERE A.MBZT = 1
                         AND EXISTS (SELECT 1
                                FROM TPIF_TYMBDY_SYFW B
                               WHERE B.TPIF_TYMBDY_ID = A.ID
                                 AND B.FWLX = 2)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_TYMBDY_SYFW
                           WHERE TPIF_TYMBDY_ID = CUR.ID
                             AND FWLX = 2) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.LBMEMBER
               WHERE USERID = I_userid
                 AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_TYMBDY A
                       WHERE A.MBZT = 1
                         AND EXISTS (SELECT 1
                                FROM TPIF_TYMBDY_SYFW B
                               WHERE B.TPIF_TYMBDY_ID = A.ID
                                 AND B.FWLX = 1)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_TYMBDY_SYFW
                           WHERE TPIF_TYMBDY_ID = CUR.ID
                             AND FWLX = 1) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.TUSER
               WHERE ID = I_userid
                 AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_TYMBDY A
                       WHERE A.MBZT = 1
                         AND EXISTS (SELECT 1
                                FROM TPIF_TYMBDY_SYFW B
                               WHERE B.TPIF_TYMBDY_ID = A.ID
                                 AND B.FWLX = 0)) LOOP
            V_MBIDS := V_MBIDS || ';' || CUR.ID;
          END LOOP;
        END IF;
      END IF;
      V_MBIDS := SUBSTR(V_MBIDS, 2);
      IF V_MBIDS IS NULL THEN
        O_CODE := -2;
        O_NOTE := '当前无适用于您的分类模板,请联系管理员！';
        RETURN;
      ELSE
        V_SQL := ' SELECT  max(MB.ID) template_id,
                                   max(MB.MBBM) template_no,
                                   max(MB.MBMC) template_name
                             FROM PIF.TPIF_TYMBDY MB
                            WHERE INSTR('';' || V_MBIDS ||
                 ';'' ,'';''||MB.ID||'';'')>0 ';
      END IF;
    
    END IF;
  ELSE
   /* --验证业务是否有规则
    --SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_JRCPFL T WHERE T.ID = I_PROD_TYPE;
  
    \*IF V_COUNT = 0 THEN
        O_CODE := -1801;
        O_NOTE := '系统异常：没有配置此产品分类，请核实!';
        RETURN;
    END IF;*\
  
    --验证是否存在适用于当前登录人的分类模版
    SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_FLMBDY WHERE MBZT = 1;
    IF V_COUNT = 0 THEN
      O_CODE := -2;
      O_NOTE := '系统异常：当前无启用的分类模版！';
      RETURN;
    ELSIF V_COUNT > 0 THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_FLMBDY a
       WHERE MBZT = 1
        and a.id = I_PROD_TYPE ;
         --AND exists( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||CPDL||';',';'||column_value||';')>0 );
      IF V_COUNT = 0 THEN
        O_CODE := -3;
        O_NOTE := '系统异常：当前无此分类启用的分类模版！';
        RETURN;
      END IF;
      V_MBIDS := '';
      IF I_userid = 0 THEN
        SELECT ';' || REPLACE(WM_CONCAT(ID), ',', ';')
          INTO V_MBIDS
          FROM TPIF_FLMBDY A
         WHERE MBZT = 1
          and a.id = I_PROD_TYPE ;
         --  AND exists (select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||CPDL||';',';'||column_value||';')>0 );
      ELSE
        --级别:指定用户>组织角色>角色>组织>所有用户!
        FOR CUR IN (SELECT *
                      FROM TPIF_FLMBDY A
                     WHERE A.MBZT = 1
                      -- AND exists ( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||A.CPDL||';',';'||column_value||';')>0 )
                        and a.id = I_PROD_TYPE 
                       AND EXISTS (SELECT 1
                              FROM TPIF_FLMBDY_SYFW B
                             WHERE B.TPIF_FLMBDY_ID = A.ID
                               AND B.FWLX = 3)) LOOP
          FOR CUR_S IN (SELECT *
                          FROM TPIF_FLMBDY_SYFW
                         WHERE TPIF_FLMBDY_ID = CUR.ID
                           AND FWLX = 3) LOOP
            IF INSTR(';' || CUR_S.SYYH || ';', ';' || I_userid || ';') > 0 THEN
              V_MBIDS := V_MBIDS || ';' || CUR.ID;
            END IF;
          END LOOP;
        END LOOP;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_FLMBDY A
                       WHERE A.MBZT = 1
                         --AND exists( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||A.CPDL||';',';'||column_value||';')>0 )
                         and a.id = I_PROD_TYPE 
                         AND EXISTS (SELECT 1
                                FROM TPIF_FLMBDY_SYFW B
                               WHERE B.TPIF_FLMBDY_ID = A.ID
                                 AND B.FWLX = 4)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_FLMBDY_SYFW
                           WHERE TPIF_FLMBDY_ID = CUR.ID
                             AND FWLX = 4) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.LBMEMBER
               WHERE USERID = I_userid
                 AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0
                 AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_FLMBDY A
                       WHERE A.MBZT = 1
                         --AND exists( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||A.CPDL||';',';'||column_value||';')>0 )
                          and a.id = I_PROD_TYPE 
                         AND EXISTS (SELECT 1
                                FROM TPIF_FLMBDY_SYFW B
                               WHERE B.TPIF_FLMBDY_ID = A.ID
                                 AND B.FWLX = 2)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_FLMBDY_SYFW
                           WHERE TPIF_FLMBDY_ID = CUR.ID
                             AND FWLX = 2) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.LBMEMBER
               WHERE USERID = I_userid
                 AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_FLMBDY A
                       WHERE A.MBZT = 1
                        -- AND exists( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||A.CPDL||';',';'||column_value||';')>0 )
                          and a.id = I_PROD_TYPE 
                         AND EXISTS (SELECT 1
                                FROM TPIF_FLMBDY_SYFW B
                               WHERE B.TPIF_FLMBDY_ID = A.ID
                                 AND B.FWLX = 1)) LOOP
            FOR CUR_S IN (SELECT *
                            FROM TPIF_FLMBDY_SYFW
                           WHERE TPIF_FLMBDY_ID = CUR.ID
                             AND FWLX = 1) LOOP
              SELECT COUNT(1)
                INTO V_COUNT
                FROM LIvebos.TUSER
               WHERE ID = I_userid
                 AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0;
              IF V_COUNT > 0 THEN
                V_MBIDS := V_MBIDS || ';' || CUR.ID;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
        IF V_MBIDS IS NULL THEN
          FOR CUR IN (SELECT *
                        FROM TPIF_FLMBDY A
                       WHERE A.MBZT = 1
                         --AND exists( select 1 from table(split(I_PROD_TYPE,';'))  where instr(';'||A.CPDL||';',';'||column_value||';')>0 )
                          and a.id = I_PROD_TYPE 
                         AND EXISTS (SELECT 1
                                FROM TPIF_FLMBDY_SYFW B
                               WHERE B.TPIF_FLMBDY_ID = A.ID
                                 AND B.FWLX = 0)) LOOP
            V_MBIDS := V_MBIDS || ';' || CUR.ID;
          END LOOP;
        END IF;
      END IF;
      V_MBIDS := SUBSTR(V_MBIDS, 2);
      IF V_MBIDS IS NULL THEN
        O_CODE := -2;
        O_NOTE := '当前无适用于您的分类模板,请联系管理员！';
        RETURN;
      ELSE*/
        V_SQL := ' SELECT  max(MB.ID) template_id,
                                   max(MB.MBBM) template_no,
                                   max(MB.MBMC) template_name
                             FROM PIF.TPIF_FLMBDY MB
                            WHERE MB.id = '||I_PROD_TYPE ;
     -- END IF;
    --END IF;
  END IF;
  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || V_ERRMSG FROM DUAL;
  
END PCX_PIF_CPJM_WDMB;
/

