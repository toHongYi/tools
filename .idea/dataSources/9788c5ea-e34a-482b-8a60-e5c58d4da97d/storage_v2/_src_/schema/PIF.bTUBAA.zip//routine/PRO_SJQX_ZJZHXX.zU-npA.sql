create PROCEDURE PRO_SJQX_ZJZHXX(O_CODE OUT NUMBER, --返回值
                                            O_NOTE OUT VARCHAR2 --返回消息
                                            ) IS

  /******************************************************************
      所属用户：INFO
      功能说明：资金账号信息表 INFO.TINFO_ZJZHXX 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-09-15    1.0       WWH                创建
          2021-11-22    1.1       GAOKUN             获取邮箱
          2021-12-14    1.1.1     HANQN              现在字段所属OA营业部编号BRANCH_NO
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO INFO.TINFO_ZJZHXX T1
  USING (SELECT A.FUND_ACCOUNT AS FUND_ACCOUNT, --资金账号
                B.ID_KIND      AS ID_KIND, --证件类型
                B.ID_NO        AS ID_NO, --证件号码
                B.CLIENT_NAME  AS CLIENT_NAME, --客户姓名
                C.MOBILE_TEL   AS MOBILE_TEL, --电话号码
                E.ID           AS SSYYB, --营业部内部对象ID
                C.E_MAIL       AS YX, --邮箱
                A.CLIENT_ID    AS CLIENT_ID,
                A.MAIN_FLAG     AS MAIN_FLAG,
                A.FUNDACCT_STATUS AS FUNDACCT_STATUS,
                A.ASSET_PROP   AS ASSET_PROP,
                D.NEW_BRANCH_ID  AS BRANCH_NO, --FUNDACCOUNT.BRANCH_NO
                B.corp_risk_level AS corp_risk_level,
                B.CLIENT_STATUS AS CLIENT_STATUS
           FROM SRC_PIF.FUNDACCOUNT A
           LEFT JOIN SRC_PIF.CLIENT B
             ON A.CLIENT_ID = B.CLIENT_ID
           LEFT JOIN SRC_PIF.CLIENTINFO C
             ON A.CLIENT_ID = C.CLIENT_ID
           LEFT JOIN SRC_PIF.DIM_BRANCH_INFO D
             ON A.BRANCH_NO = D.BRANCH_ID
           LEFT JOIN LIVEBOS.LBORGANIZATION E
             ON D.NEW_BRANCH_ID = E.BRANCH_ID
           WHERE A.MAIN_FLAG='1' AND A.FUNDACCT_STATUS='0') T2
  ON (T1.ZJZH = T2.FUND_ACCOUNT)
  WHEN MATCHED THEN
    UPDATE
       SET T1.ZJLX      = T2.ID_KIND,
           T1.ZJHM      = T2.ID_NO,
           T1.KHXM      = T2.CLIENT_NAME,
           T1.DHHM      = T2.MOBILE_TEL,
           T1.SSYYB     = T2.SSYYB,
           T1.YX        = T2.YX,
           T1.BRANCH_NO = T2.BRANCH_NO,
           T1.CLIENT_ID = T2.CLIENT_ID,
           T1.MAIN_FLAG = T2.MAIN_FLAG,
           T1.FUNDACCT_STATUS = T2.FUNDACCT_STATUS,
           T1.ASSET_PROP = T2.ASSET_PROP,
           T1.FUND_ACCOUNT = T2.FUND_ACCOUNT,
           T1.CLIENT_NAME=T2.CLIENT_NAME,
           T1.ID_KIND=T2.ID_KIND,
           T1.ID_NO=T2.ID_NO,
           T1.CORP_RISK_LEVEL=T2.CORP_RISK_LEVEL,
           T1.MOBILE_TEL=T2.MOBILE_TEL,
           T1.CLIENT_STATUS=T2.CLIENT_STATUS
  WHEN NOT MATCHED THEN
    INSERT
      (T1.ZJZH,
       T1.ZJLX,
       T1.ZJHM,
       T1.KHXM,
       T1.DHHM,
       T1.SSYYB,
       T1.YX,
       T1.BRANCH_NO,
       T1.CLIENT_ID,
       T1.MAIN_FLAG,
       T1.ASSET_PROP,
       T1.FUND_ACCOUNT,
       T1.CLIENT_NAME,
       T1.ID_KIND,
       T1.ID_NO,
       T1.CORP_RISK_LEVEL,
       T1.MOBILE_TEL,
       T1.CLIENT_STATUS)
    VALUES
      (T2.FUND_ACCOUNT,
       T2.ID_KIND,
       T2.ID_NO,
       T2.CLIENT_NAME,
       T2.MOBILE_TEL,
       T2.SSYYB,
       T2.YX,
       T2.BRANCH_NO,
       T2.CLIENT_ID,
       T2.MAIN_FLAG,
       T2.ASSET_PROP,
       T2.FUND_ACCOUNT,
       T2.CLIENT_NAME,
       T2.ID_KIND,
       T2.ID_NO,
       T2.CORP_RISK_LEVEL,
       T2.MOBILE_TEL,
       T2.CLIENT_STATUS); 

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'INFO.TINFO_ZJZHXX 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'INFO.TINFO_ZJZHXX 表清洗,未知错误'
                ELSE
                 'INFO.TINFO_ZJZHXX,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

