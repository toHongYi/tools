create PROCEDURE PRO_PIF_SY_XXZX(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                I_ID      IN NUMBER, --消息ID   
                                                I_OPERATE IN NUMBER --操作1|修改为已阅
                                                ) IS

  /* -----------------------------------------------------------------------
  项目名称：   产品中心
  概要说明：查询员工消息提醒
                 I_USERID          IN NUMBER,--TUSER.ID
  语法信息：
       输出参数：
         成功返回员工消息提醒信息，失败返回 原因
  
  数据准备：
      1)CRMII.Lbnotification (消息通知)
      2)CRMII.Lbnotificationuser(消息通知从表)
      3)CRMII.tuser(用户)
  
  运行原理：
      ID,标题,内容,时间,类型,相关客户
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
   -----------------------------------------------------------------------*/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  v_HASRECORDSET number;
BEGIN

  IF I_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'ID不能为空!';
    RETURN;
  END IF;

  IF I_OPERATE = 1 THEN
  
    UPDATE livebos.LBNOTIFICATIONUSER A SET A.ISREAD = 1 WHERE A.ID = I_ID;
  
  END IF;
  COMMIT;
  O_CODE := 1;
  O_NOTE := '成功!';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

