create PROCEDURE PCX_PIF_CKJHCP(O_RESULT OUT SYS_REFCURSOR,
                                               I_ID     IN NUMBER --集合ID
                                               ) AS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：查看产品集合对应产品
        语法信息：
             输入参数：   I_ID     IN   NUMBER   --集合ID
             输出参数：   O_RESULT
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1    戴文生              新增
    ***********************************************************************/
    V_SQL VARCHAR2(2000); --动态sql
BEGIN
    IF I_ID IS NULL THEN
        OPEN O_RESULT FOR
            SELECT '入参[产品集合ID]为空!' AS "提示信息" FROM DUAL;
        RETURN;
    END IF;
    SELECT 'SELECT TPIF_CPDM.CPDM AS "产品代码",' || 'TPIF_CPDM.CPMC AS "产品名称",' ||
            '(SELECT NAME FROM TPIF_JRCPFL WHERE ID = TPIF_CPDM.JRCPFL) AS "产品分类",' ||
            '(SELECT WM_CONCAT(MC) FROM TPIF_PT WHERE INSTR('';''||TPIF_CPDM.PT||'';'','';''||ID||'';'')>0) AS "平台",' ||
            '(SELECT WM_CONCAT(MC) FROM TPIF_QD WHERE INSTR('';''||TPIF_CPDM.QD||'';'','';''||ID||'';'')>0) AS "渠道" ' 
           -- '(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_JRCPZT'' AND IBM = TPIF_CPDM.CPZT) AS "产品阶段",' ||
           -- '(SELECT NAME FROM livebos.TUSER WHERE ID = TPIF_CPDM.DJR) AS "登记人" '
           --||'TO_CHAR(TPIF_CPDM.DJSJ,''YYYY-MM-DD HH24:MI:SS'') AS "登记时间" '
            || ' FROM TPIF_CPDM WHERE CPNBZT >= 6 AND ' || SQLWHERE ||
            ' ORDER BY TPIF_CPDM.ID DESC'
      INTO V_SQL
      FROM TPIF_CPJH
     WHERE ID = I_ID;
    dbms_output.put_line(V_SQL);
    BEGIN
        OPEN O_RESULT FOR V_SQL;
    EXCEPTION
        WHEN OTHERS THEN
            OPEN O_RESULT FOR
                SELECT '产品集合配置异常!' AS "提示信息" FROM DUAL;
    END;
END PCX_PIF_CKJHCP;
/

