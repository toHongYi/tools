create PROCEDURE PRO_SJQX_GMJJYJZS(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2) AS
  /******************************************************************
        所属用户：PIF
        功能说明：
        
        公募基金业绩走势 TPIF_GMJJYJZS 清洗
    
        该表只存每个产品最新一期表现，只存代销的产品，同时存所要比较的指数的信息
    
        结果根据 聚源净值表 INFO.TINFO_JJJZ、
                 指数行情表 DSC_STAT.TPIF_STAT_ZSHQ  计算而来
    
        每天清空该表，然后重新计算最新一期数据
        
        主要是用于移动端页面的 累计收益走势折线图
        
        生成的json数组格式：
  [
      {
          "prodCode":"007119",
          "navDay":"2021-06-16",
          "intervalYield":"-0.0121",
          "ratioIndex":"-0.0237"
      },
      {
          "prodCode":"007119",
          "navDay":"2021-06-15",
          "intervalYield":"0.0175",
          "ratioIndex":"-0.0078"
      },
      {
          "prodCode":"007119",
          "navDay":"2021-06-11",
          "intervalYield":"0.0237",
          "ratioIndex":"0.0030"
      }  
  ]  --中间有个端午节，所以隔了三天
    
        语法信息：
             输入参数：   无
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：
    
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
           2021-09-28      1.0.0    GAOKUN               创建
           2021-12-20      1.0.1    GAOKUN          后端收费产品净值补充后进行修改
                                                    基金类型取产品代码表
    ***********************************************************************/
  V_RQ_J1Y  NUMBER(8); --近1月
  V_RQ_J3Y  NUMBER(8); --近3月
  V_RQ_J6Y  NUMBER(8); --近6月
  V_RQ_J1N  NUMBER(8); --近1年
  V_RQ_J2N  NUMBER(8); --近2年
  V_RQ_J3N  NUMBER(8); --近3年
  V_RQ_J5N  NUMBER(8); --近5年
  V_RQ_JNYL NUMBER(8); --今年以来
  --V_RQ_CLYL NUMBER(8); --成立以来

  V_DWJZ NUMBER; --要比较的单位净值
  V_LJJZ NUMBER; --要比较的累计净值
  V_KSRQ DATE; --开始日期
  V_JSPJ NUMBER; --要比较的今收盘价

  V_COUNT NUMBER;
  V_ZSDM  VARCHAR2(100); --指数代码,仅用于过程，表中不存
  --000300.SH 沪深300
  --000012.SH 国债指数
  -- -1 沪深50%+国债50%，自定义一个一定不重复的值

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --先清空该表
  DELETE FROM TPIF_GMJJYJZS;

  SELECT JYR --近1月
    INTO V_RQ_J1Y
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -1),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近3月
    INTO V_RQ_J3Y
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -3),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近6月
    INTO V_RQ_J6Y
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -6),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近1年
    INTO V_RQ_J1N
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -12),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近2年
    INTO V_RQ_J2N
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -24),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近3年
    INTO V_RQ_J3N
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -36),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT JYR --近5年
    INTO V_RQ_J5N
    FROM LIVEBOS.TXTJYR
   WHERE ZRR =
         (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                              -60),
                                   'YYYYMMDD'))
            FROM LIVEBOS.TXTJYR
           WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));

  SELECT MAX(JYR) --今年以来
    INTO V_RQ_JNYL
    FROM LIVEBOS.TXTJYR
   WHERE ZRR <= TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY') || '0101')
     AND ZRR = JYR;

  --新增数据，只存代销公募
  FOR CUR IN (SELECT CPDM, JRCPFL FROM TPIF_CPDM WHERE SJLY = 1) LOOP
  
    --判断有没有净值，有则计算收益率，没有直接下一只产品
    SELECT COUNT(1)
      INTO V_COUNT
      FROM INFO.TINFO_JJJZ
     WHERE SECUCODE = CUR.CPDM;
  
    IF V_COUNT = 0 THEN
      CONTINUE;
    ELSE
      --获取基金类别，根据类别和不同的指数进行对比 
      --债券型VS国债指数， 混合型VS(国债 50% + 沪深300 50%)， 其余的VS沪深300
      IF CUR.JRCPFL = 300600 THEN
        --债券型基金
        V_ZSDM := '000012.SH';
      ELSIF CUR.JRCPFL = 300500 THEN
        --混合型基金
        V_ZSDM := '-1';
      ELSE
        V_ZSDM := '000300.SH';
      END IF;
    
      --循环9次，计算收益率，语句基本是相同的，就是改了日期，成立以来、混合型需特殊处理
      FOR I IN 1 .. 9 LOOP
      
        BEGIN
          --查询开始日期、开始日期的单位净值、累计净值
          --如果I=9，计算成立以来的收益率，开始日期取净值表的最小日期
          IF I = 9 THEN
            SELECT X.ENDDATE, X.ACCUMULATEDUNITNV, X.UNITNV
              INTO V_KSRQ, V_LJJZ, V_DWJZ
              FROM INFO.TINFO_JJJZ X
             WHERE X.SECUCODE = CUR.CPDM
               AND X.ENDDATE = (SELECT MIN(T.ENDDATE)
                                  FROM INFO.TINFO_JJJZ T
                                 WHERE T.SECUCODE = CUR.CPDM);
          ELSE
            SELECT X.ENDDATE, X.ACCUMULATEDUNITNV, X.UNITNV
              INTO V_KSRQ, V_LJJZ, V_DWJZ
              FROM INFO.TINFO_JJJZ X
             WHERE X.SECUCODE = CUR.CPDM
               AND X.ENDDATE =
                   (SELECT MIN(T.ENDDATE)
                      FROM INFO.TINFO_JJJZ T
                     WHERE T.SECUCODE = CUR.CPDM
                       AND TO_NUMBER(TO_CHAR(T.ENDDATE, 'YYYYMMDD')) >=
                           DECODE(I,
                                  1,
                                  V_RQ_J1Y,
                                  2,
                                  V_RQ_J3Y,
                                  3,
                                  V_RQ_J6Y,
                                  4,
                                  V_RQ_J1N,
                                  5,
                                  V_RQ_JNYL,
                                  6,
                                  V_RQ_J2N,
                                  7,
                                  V_RQ_J3N,
                                  8,
                                  V_RQ_J5N));
          END IF;
        
          --获取开始日期的指数 今收盘价   
          --混合型需特殊处理
          IF V_ZSDM = '-1' THEN
            SELECT A.JSPJ + B.JSPJ
              INTO V_JSPJ
              FROM DSC_STAT.TPIF_STAT_ZSHQ A, DSC_STAT.TPIF_STAT_ZSHQ B
             WHERE A.SJRQ = TO_NUMBER(TO_CHAR(V_KSRQ, 'YYYYMMDD'))
               AND A.SJRQ = B.SJRQ
               AND A.ZSDM = '000300.SH' --沪深300
               AND B.ZSDM = '000012.SH'; --国债指数
          ELSE
            SELECT JSPJ
              INTO V_JSPJ
              FROM DSC_STAT.TPIF_STAT_ZSHQ
             WHERE SJRQ = TO_NUMBER(TO_CHAR(V_KSRQ, 'YYYYMMDD'))
               AND ZSDM = V_ZSDM;
          END IF;
        
          --向表中新增数据 ，混合型需要特殊处理              
          IF V_ZSDM = '-1' THEN
            INSERT INTO TPIF_GMJJYJZS
              (ID, PRODCODE, STATDIMENSION, INTERVALYIELD, UPDATETIME)
              SELECT LIVEBOS.FUNC_NEXTID('TPIF_GMJJYJZS'),
                     CUR.CPDM,
                     I,
                     '[' || RTRIM(XMLAGG(XMLPARSE(CONTENT SYL || ',' WELLFORMED)).GETCLOBVAL(),
                                  ',') || ']',
                     SYSDATE
                FROM (SELECT '{"prodCode":"' || SECUCODE || '","navDay":"' ||
                             NAVDAY || '","intervalYield":"' ||
                             TO_CHAR(INTERVALYIELD, 'FM9990.0000') ||
                             '","ratioIndex":"' ||
                             TO_CHAR(RATIOINDEX, 'FM9990.0000') || '"}' AS SYL
                        FROM (SELECT A.SECUCODE, /*产品代码*/
                                     TO_CHAR(A.ENDDATE, 'YYYY-MM-DD') AS NAVDAY, /*净值日期*/
                                     (CASE
                                       WHEN V_DWJZ IS NULL THEN
                                        NULL
                                       WHEN V_DWJZ = 0 THEN
                                        NULL
                                       ELSE
                                        ROUND((A.ACCUMULATEDUNITNV - V_LJJZ) / V_DWJZ, 4)
                                     END) AS INTERVALYIELD, /*区间收益率*/
                                     (CASE
                                       WHEN V_JSPJ IS NULL THEN
                                        NULL
                                       WHEN V_JSPJ = 0 THEN
                                        NULL
                                       ELSE
                                        ROUND((B.JSPJ + C.JSPJ - V_JSPJ) / V_JSPJ, 4)
                                     END) AS RATIOINDEX /*对比指标的区间收益率*/
                                FROM INFO.TINFO_JJJZ         A,
                                     DSC_STAT.TPIF_STAT_ZSHQ B, --取沪深300
                                     DSC_STAT.TPIF_STAT_ZSHQ C --取国债指数
                               WHERE A.SECUCODE = CUR.CPDM
                                 AND A.ENDDATE >= V_KSRQ
                                 AND A.ENDDATE <= TRUNC(SYSDATE)
                                 AND TO_NUMBER(TO_CHAR(A.ENDDATE, 'YYYYMMDD')) =
                                     B.SJRQ
                                 AND B.SJRQ = C.SJRQ
                                 AND B.ZSDM = '000300.SH' --沪深300
                                 AND C.ZSDM = '000012.SH' --国债指数
                               ORDER BY A.ENDDATE DESC));
          
          ELSE
            INSERT INTO TPIF_GMJJYJZS
              (ID, PRODCODE, STATDIMENSION, INTERVALYIELD, UPDATETIME)
              SELECT LIVEBOS.FUNC_NEXTID('TPIF_GMJJYJZS'),
                     CUR.CPDM,
                     I,
                     '[' || RTRIM(XMLAGG(XMLPARSE(CONTENT SYL || ',' WELLFORMED)).GETCLOBVAL(),
                                  ',') || ']',
                     SYSDATE
                FROM (SELECT '{"prodCode":"' || SECUCODE || '","navDay":"' ||
                             NAVDAY || '","intervalYield":"' ||
                             TO_CHAR(INTERVALYIELD, 'FM9990.0000') ||
                             '","ratioIndex":"' ||
                             TO_CHAR(RATIOINDEX, 'FM9990.0000') || '"}' AS SYL
                        FROM (SELECT A.SECUCODE, /*产品代码*/
                                     TO_CHAR(A.ENDDATE, 'YYYY-MM-DD') AS NAVDAY, /*净值日期*/
                                     (CASE
                                       WHEN V_DWJZ IS NULL THEN
                                        NULL
                                       WHEN V_DWJZ = 0 THEN
                                        NULL
                                       ELSE
                                        ROUND((A.ACCUMULATEDUNITNV - V_LJJZ) /
                                              V_DWJZ,
                                              4)
                                     END) AS INTERVALYIELD, /*区间收益率*/
                                     (CASE
                                       WHEN V_JSPJ IS NULL THEN
                                        NULL
                                       WHEN V_JSPJ = 0 THEN
                                        NULL
                                       ELSE
                                        ROUND((B.JSPJ - V_JSPJ) / V_JSPJ, 4)
                                     END) AS RATIOINDEX /*对比指标的区间收益率*/
                                FROM INFO.TINFO_JJJZ         A,
                                     DSC_STAT.TPIF_STAT_ZSHQ B
                               WHERE A.SECUCODE = CUR.CPDM
                                 AND A.ENDDATE >= V_KSRQ
                                 AND A.ENDDATE <= TRUNC(SYSDATE)
                                 AND TO_NUMBER(TO_CHAR(A.ENDDATE, 'YYYYMMDD')) =
                                     B.SJRQ
                                 AND B.ZSDM = V_ZSDM
                               ORDER BY A.ENDDATE DESC));
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      
      END LOOP;
    
    END IF;
  
  END LOOP;

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_GMJJYJZS 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_GMJJYJZS 表清洗,未知错误'
                ELSE
                 'TPIF_GMJJYJZS 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

