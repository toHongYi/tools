create PROCEDURE PRO_PIF_ZDXS_CPSX(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_OPER IN INTEGER, --操作类型1|上移;2|下移；3|置顶;4|取消置顶
                                               I_ID IN INTEGER --操作ID (重点销售产品管理ID)
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：重点销售产品管理-产品顺序
        语法信息：
             输入参数：I_USER IN INTEGER, --操作人
                       I_OPER IN INTEGER, --操作类型1|上移;2|下移;3|置顶；4|取消置顶
                       I_ZDCPGLID IN INTEGER --操作ID (重点销售产品管理ID)

             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-05-19     1.0.1     HQN                新增
            2021-06-29     1.0.2     HQN                增加I_OPER 3|置顶;4|取消置顶
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_CPKID INTEGER; --产品库id
    V_QXBZ  INTEGER; --权限标识
    V_ID    INTEGER;
    V_ZHID  INTEGER; --置换id
    V_ZHSX  INTEGER; --置换顺序
    V_ZSSX  INTEGER; --显示排序
    V_ZDSX  INTEGER; --置顶顺序
    V_OBJ   TPIF_CPBQMX%ROWTYPE; --表单记录
    V_SFZD  INTEGER; --是否置顶
    V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := 1;
    O_NOTE := '';


    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
     O_NOTE :='操作成功'; 
    
    --获取是否置顶，置顶顺序，展示顺序和产品库
    
    SELECT SFZD,ZDSX,ZSSX,CPKID INTO V_SFZD,V_ZDSX,V_ZSSX,V_CPKID
     FROM PIF.TPIF_ZDXS_CP WHERE ID=I_ID;
     
    IF I_OPER = 1 THEN --上移
 
       
      IF V_SFZD=1 AND V_ZDSX=1 THEN  --是置顶
        O_CODE:=-1;
        O_NOTE:='该产品已在置顶第一位，无需置顶';
        RETURN;
       END IF;
      
      IF V_SFZD=1 AND V_ZDSX>1 THEN
        SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND ZDSX=V_ZDSX-1 AND SFSC=0;
        UPDATE PIF.TPIF_ZDXS_CP SET ZDSX=V_ZDSX-1 WHERE ID=I_ID AND SFSC=0;
        UPDATE PIF.TPIF_ZDXS_CP SET ZDSX=V_ZDSX WHERE ID=V_ZHID AND SFSC=0;
      END IF;
      
      --非置顶
      IF V_SFZD=0 THEN 
        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=0 AND ZSSX<V_ZSSX AND SFSC=0;
        IF V_COUNT=0 THEN 
          O_CODE:=-1;
          O_NOTE:='该产品已在非置顶第一位，无法上移';
          RETURN;
        ELSE
          SELECT MAX(ZSSX) INTO V_ZHSX FROM TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=0 AND ZSSX<V_ZSSX AND SFSC=0;
          SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=0 AND ZSSX=V_ZHSX AND SFSC=0;
          UPDATE PIF.TPIF_ZDXS_CP SET ZSSX=V_ZHSX WHERE ID=I_ID AND SFSC=0;
          UPDATE PIF.TPIF_ZDXS_CP SET ZSSX=V_ZSSX WHERE ID=V_ZHID AND SFSC=0;
        END IF;
        
      END IF;  
       
    END IF;
    
    IF I_OPER = 2 THEN      --下移
       IF V_SFZD=1 THEN
         SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND  SFZD=1 AND ZDSX>V_ZDSX AND SFSC=0;
         IF V_COUNT =0 THEN
           O_CODE :=-1;
           O_NOTE :='该产品已在置顶最后一位，无法下移';
           RETURN;
         ELSE 
          SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND ZDSX=V_ZDSX+1 AND SFSC=0;
          UPDATE PIF.TPIF_ZDXS_CP SET ZDSX=V_ZDSX+1 WHERE ID=I_ID;
          UPDATE PIF.TPIF_ZDXS_CP SET ZDSX=V_ZDSX WHERE ID=V_ZHID;
         END IF;
       ELSIF V_SFZD=0 THEN
         SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND  SFZD=0 AND ZSSX>V_ZSSX AND SFSC=0;
         IF V_COUNT =0 THEN
           O_CODE :=-1;
           O_NOTE :='该产品已在非置顶最后一位，无法下移';
           RETURN;
         ELSE 
          SELECT MIN(ZSSX) INTO V_ZHSX FROM TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=0 AND ZSSX>V_ZSSX AND SFSC=0;
          SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND SFZD=0 AND ZSSX=V_ZHSX AND SFSC=0;
          UPDATE PIF.TPIF_ZDXS_CP SET ZSSX=V_ZHSX WHERE ID=I_ID;
          UPDATE PIF.TPIF_ZDXS_CP SET ZSSX=V_ZSSX WHERE ID=V_ZHID;
         END IF;
      END IF  ;
    END IF;
    
    
    IF I_OPER = 3 THEN      --置顶
      
      IF V_SFZD=1 THEN
        O_CODE:= 99;
        O_NOTE:= '该产品已置顶,无需重复置顶';
        RETURN;
      END IF;
      
      --产品库置顶产品数量
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_ZDXS_CP
       WHERE CPKID = V_CPKID
         AND SFSC = 0
         AND SFZD = 1;
      
      --置顶产品最多3条
      IF V_COUNT=3 THEN
        O_CODE:= -1;
        O_NOTE:= '指定产品库已有3条产品,无法置顶';
        RETURN;
      END IF;
      
      --置于置顶产品最后一位  
      UPDATE PIF.TPIF_ZDXS_CP
         SET SFZD = 1,
             ZDSX =
             (SELECT NVL(MAX(ZDSX), 0) + 1
                FROM PIF.TPIF_ZDXS_CP
               WHERE CPKID = V_CPKID
                 AND SFSC = 0)
       WHERE ID = I_ID;
      
    END IF;
    
    IF I_OPER = 4 THEN      --取消置顶
      IF V_SFZD=0 THEN 
         O_CODE:= 99;
         O_NOTE:= '非置顶产品,无需取消置顶';
         RETURN;
      END IF;
      
      UPDATE PIF.TPIF_ZDXS_CP 
         SET ZSSX=ZSSX-1 
       WHERE CPKID=V_CPKID AND ZSSX>V_ZSSX AND SFSC=0;
          
      UPDATE PIF.TPIF_ZDXS_CP 
         SET ZDSX=ZDSX-1 
       WHERE CPKID=V_CPKID AND SFZD=1 AND ZDSX>V_ZDSX; 
      
      --展示顺序置为1   
      UPDATE PIF.TPIF_ZDXS_CP 
         SET SFZD=0,
             ZDSX=NULL,
             ZSSX=(SELECT NVL(MAX(ZSSX),0)+1 FROM PIF.TPIF_ZDXS_CP WHERE CPKID=V_CPKID AND ID!=I_ID AND SFSC=0)
       WHERE ID=I_ID;

    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_ZDXS_CPSX;
/

