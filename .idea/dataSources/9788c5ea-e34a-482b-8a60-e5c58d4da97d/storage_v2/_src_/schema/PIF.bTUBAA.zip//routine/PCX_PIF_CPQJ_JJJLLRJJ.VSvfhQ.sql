create PROCEDURE PCX_PIF_CPQJ_JJJLLRJJ(O_CODE            OUT NUMBER,
                                                  O_NOTE            OUT VARCHAR2,
                                                  O_RESULT          OUT SYS_REFCURSOR,
                                                  I_USERID          IN NUMBER, --用户ID
                                                  I_FUND_MANAGER_NO IN VARCHAR2, --基金经理编号
                                                  I_PROD_ID         IN NUMBER) --产品ID
 AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询基金经理历任基金
  所属用户：PIF
  概要说明：查询基金经理历任基金.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金经理历任基金.
        
        公募 聚源： 基金经理基本资料 TPIF_JJJLJBZL
                   基金与基金经理关联表 TPIF_JJYJJJLGLB
               
        私募 朝阳永续： 私募投资经理 TPIF_SMTZJL
                       基金与投资经理关联表 TPIF_JJYTZJLGLB 
        
        该过程新增了入参，产品ID，传该全景产品ID，用于确定公募私募，
        
        因为公募私募基金经理表不同，且编号存在重叠，单纯根据编号无法
        
        确定取哪个表，所以加此入参，同时微服务接口、前端调用做相应修改               
                       
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/30     1.0.0.1   TUMENG             新增.
      20201118                 GAOKUN            根据财通的表进行修改
      2021-12-13     1.0.0.3   GAOKUN              加入参
  *************************************************************************/
  V_SQL  VARCHAR2(4000);
  V_CPLX NUMBER; --产品类型
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_FUND_MANAGER_NO IS NULL THEN
    O_NOTE := '基金经理编号不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  BEGIN
    --获取产品类型
    SELECT CPXL INTO V_CPLX FROM TPIF_CPDM WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
  END;

  IF V_CPLX = 1 THEN
    --公募
    V_SQL := 'SELECT JJJC AS FUND_NAME,
                   DRRQ || ''-'' || NVL(TO_CHAR(LRRQ), ''至今'') AS DUTY_TIME,
                   TO_CHAR(RZQJJZZZL * 100,''FM99999990.00'') AS PERIOD_YIELD_PAYBACK_RATIO
              FROM TPIF_JJYJJJLGLB
             WHERE JJJLID = ' || I_FUND_MANAGER_NO || '
          ORDER BY DRRQ DESC';
  
  ELSE
    V_SQL := 'SELECT FUND_NAME,
                     START_DATE || ''-'' || NVL(TO_CHAR(END_DATE), ''至今'') AS DUTY_TIME,
                     NULL AS PERIOD_YIELD_PAYBACK_RATIO
                FROM TPIF_JJYTZJLGLB
               WHERE USER_ID = ' || I_FUND_MANAGER_NO || '
            ORDER BY START_DATE DESC';
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_JJJLLRJJ;
/

