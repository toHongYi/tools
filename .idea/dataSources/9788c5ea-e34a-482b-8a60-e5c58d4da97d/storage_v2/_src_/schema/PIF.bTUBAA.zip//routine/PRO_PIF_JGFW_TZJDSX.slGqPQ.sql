create PROCEDURE PRO_PIF_JGFW_TZJDSX(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_JGFWID IN INTEGER --服务id
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：机构业务拓展-机构服务-调整节点顺序
        语法信息：
             输入参数：I_CPKID IN INTEGER --产品库id

             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-08-09     1.0.1     hanqiaonan                新增
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_ID    INTEGER;
    V_SX  INTEGER :=1; --显示排序
    V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := 1;
    O_NOTE := '';


    IF I_JGFWID IS NULL THEN
        O_CODE := '-1';
        O_NOTE := '机构服务ID不能为空!';
        RETURN;
    END IF;
    --START
     O_NOTE :='操作成功';

    --获取机构服务节点数
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_JGFWLCJD
     WHERE JGFWID = I_JGFWID;

    --重置节点顺序
    IF V_COUNT>0 THEN
      FOR CUR IN (SELECT * FROM TPIF_JGFWLCJD WHERE JGFWID=I_JGFWID ORDER BY SX)
        LOOP
        UPDATE TPIF_JGFWLCJD
          SET SX=V_SX
         WHERE ID=CUR.ID;
        V_SX:=V_SX+1;
       END LOOP;
    END IF;
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
                  
END PRO_PIF_JGFW_TZJDSX;
/

