create PROCEDURE PRO_PIF_CPZSFL(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;
                                               --5|变更升级节点;6|上移;7|下移;8|校验有效性;
                                               I_ID IN INTEGER, --操作ID
                                               I_OP IN VARCHAR2 := '' --其他参数
                                               ) IS
    /*
    **功能说明：产品展示分类管理
    **创建人：戴文生
    **创建日期：2014-12-01
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生     1.0.1     2014-12-01   创建
    **刘浪浪     1.0.2     2015/0601    巡检日志出错时对象写成金融产品分类
    */
    V_COUNT INTEGER; --计数变量
    V_ID    INTEGER;
    V_OBJ   TPIF_CPZSFL%ROWTYPE; --表单记录
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSPX  INTEGER; --显示排序
    --V_SCBZ    INTEGER; --日志删除标识
    --V_OPER    VARCHAR2(200); --操作方法
    V_NOTE VARCHAR2(2000); --描述信息
    --V_FDETAIL VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPZSFL WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF I_IP = '[check]' THEN
            IF I_ID IS NOT NULL THEN
                SELECT COUNT(1)
                  INTO V_COUNT
                  FROM TPIF_CPZSFL
                 WHERE ID = I_ID
                   AND TYPE = 2;
                IF V_COUNT > 0 THEN
                    O_NOTE := '叶子节点不允许新增下级节点!';
                    RETURN;
                END IF;
            END IF;
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[显示名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZSFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品展示分类]!';
            RETURN;
        END IF;
        IF V_COUNT > 0 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品展示分类]!';
            RETURN;
        END IF;
        IF V_OBJ.TYPE = 2 AND V_OBJ.JRCPFL IS NULL THEN
            O_NOTE := '[对应产品分类]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE ID = V_OBJ.JRCPFL
           AND TYPE = 2;
        IF V_COUNT = 0 AND V_OBJ.TYPE = 2 THEN
            O_NOTE := '[对应产品分类]请选择叶子分类!';
            RETURN;
        END IF;
        IF V_OBJ.FID IS NULL THEN
            UPDATE TPIF_CPZSFL
               SET FID     = 0,
                   GRADE   = 0,
                   TYPE    = 1,
                   FDNCODE = 0,
                   JRCPFL =
                   (CASE
                       WHEN TYPE != 2 THEN
                        ''
                       ELSE
                        JRCPFL
                   END),
                   XSPX    = 0
             WHERE ID = I_ID;
        ELSE
            FOR CUR IN (SELECT * FROM TPIF_CPZSFL WHERE ID = V_OBJ.FID) LOOP
                UPDATE TPIF_CPZSFL
                   SET GRADE   = CUR.GRADE + 1,
                       FDNCODE = CUR.FDNCODE || '.' || CUR.ID,
                       JRCPFL = (CASE
                                    WHEN TYPE != 2 THEN
                                     ''
                                    ELSE
                                     JRCPFL
                                END),
                       XSPX   =
                       (SELECT NVL(MAX(T.XSPX), 0) + 1
                          FROM TPIF_CPZSFL T
                         WHERE T.FID = V_OBJ.FID)
                 WHERE ID = I_ID;
            END LOOP;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前节点已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[显示名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZSFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品展示分类]!';
            RETURN;
        END IF;
        IF V_COUNT > 0 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品展示分类]!';
            RETURN;
        END IF;
        IF V_OBJ.TYPE = 2 AND V_OBJ.JRCPFL IS NULL THEN
            O_NOTE := '[对应产品分类]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE ID = V_OBJ.JRCPFL
           AND TYPE = 2;
        IF V_COUNT = 0 AND V_OBJ.TYPE = 2 THEN
            O_NOTE := '[对应产品分类]请选择叶子分类!';
            RETURN;
        END IF;
        UPDATE TPIF_CPZSFL
           SET JRCPFL = (CASE
                            WHEN TYPE != 2 THEN
                             ''
                            ELSE
                             JRCPFL
                        END)
         WHERE ID = I_ID;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前记录已[启用]!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_CPZSFL', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前产品展示分类已存在引用记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZSFL WHERE FID = I_ID;
        IF V_COUNT > 0 THEN
            O_NOTE := '当前节点存在下级节点!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_CPZSFL WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF I_OP = 1 THEN
            IF V_OBJ.ZT = 1 THEN
                O_NOTE := '当前节点已[启用]!';
                RETURN;
            END IF;
            UPDATE TPIF_CPZSFL SET ZT = 1 WHERE ID = I_ID;
        ELSIF I_OP = 2 THEN
            UPDATE TPIF_CPZSFL
               SET ZT = 1
             WHERE INSTR('.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.', '.' || ID || '.') > 0;
        END IF;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF I_OP = 1 THEN
            IF V_OBJ.ZT = -1 THEN
                O_NOTE := '当前节点已[禁用]!';
                RETURN;
            END IF;
            UPDATE TPIF_CPZSFL SET ZT = -1 WHERE ID = I_ID;
        ELSIF I_OP = 2 THEN
            UPDATE TPIF_CPZSFL
               SET ZT = -1
             WHERE INSTR('.' || FDNCODE || '.', '.' || V_OBJ.FDNCODE || '.') > 0;
        END IF;
    END IF;
    IF I_OPER = 5 THEN
        --变更上级节点-----------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPZSFL WHERE ID = I_OP) LOOP
            UPDATE TPIF_CPZSFL
               SET GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE INSTR('.' || FDNCODE || '.',
                         '.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.') > 0;
            UPDATE TPIF_CPZSFL
               SET FID     = I_OP,
                   GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE ID = I_ID;
        END LOOP;
        UPDATE TPIF_CPZSFL A
           SET A.XSPX =
               (SELECT NVL(MAX(T.XSPX), 0) + 1
                  FROM TPIF_CPZSFL T
                 WHERE T.FID = I_OP
                   AND T.ID != I_ID)
         WHERE A.ID = I_ID;
    END IF;
    IF I_OPER = 6 THEN
        --上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZSFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZSFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSPX < V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_CPZSFL T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MAX(A.XSPX)
                           FROM TPIF_CPZSFL A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSPX < V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPZSFL SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_CPZSFL SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 7 THEN
        --下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZSFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZSFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSPX > V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_CPZSFL T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MIN(A.XSPX)
                           FROM TPIF_CPZSFL A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSPX > V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPZSFL SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_CPZSFL SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 8 THEN
        --校验有效性-------------------------------------------------------------------
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZSFL WHERE ZT = 1;
        IF V_COUNT = 0 THEN
            V_NOTE := V_NOTE || '当前无[启用]节点;';
        END IF;
        FOR CUR IN (SELECT *
                      FROM TPIF_CPZSFL
                     WHERE TYPE = 2
                       AND ZT = 1) LOOP
            SELECT COUNT(1)
              INTO V_COUNT
              FROM TPIF_CPZSFL
             WHERE INSTR('.' || CUR.FDNCODE || '.', '.' || ID || '.') > 0
               AND ZT != 1;
            IF V_COUNT > 0 THEN
                V_NOTE := V_NOTE || '节点[' || CUR.NAME || ']存在非[启用]状态的上级节点;';
            END IF;
        END LOOP;
        LIVEBOS.PNEXTID('TPIF_XJRZ', V_ID);
        IF V_NOTE IS NULL THEN
            V_NOTE := '巡检正常!';
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_001'
                           AND ROWNUM = 1),
                       '<font color=green>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        ELSE
            V_NOTE := '巡检异常:' || V_NOTE;
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_001'
                           AND ROWNUM = 1),
                       '<font color=red>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        END IF;
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           5,
                           '变更升级节点',
                           6,
                           '上移',
                           7,
                           '下移',
                           '校验有效性') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
    IF I_OPER = 8 THEN
        O_NOTE := O_NOTE || V_NOTE;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPZSFL;

/

