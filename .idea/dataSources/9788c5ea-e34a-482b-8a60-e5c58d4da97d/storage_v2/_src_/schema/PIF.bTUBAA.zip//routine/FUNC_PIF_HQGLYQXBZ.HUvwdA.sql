create FUNCTION FUNC_PIF_HQGLYQXBZ(I_YHID IN VARCHAR2 --用户ID
                                                 ) RETURN INTEGER IS --返回权限标识 1|是,0|否

    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取管理员可操作标识
        语法信息：
             输入参数：   I_YHID  用户ID
             输出参数：   RETURN 返回权限标识
        逻辑说明：
             1、校验当前用户是否为管理员，如果为管理员则获取系统参数，判断当前开关；
             2、非管理员则直接允许操作；
             3、返回管理员可操作标识
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1    戴文生              新增
    ***********************************************************************/
    V_RETURN INTEGER; --返回字典掩码
    V_XZBZ   INTEGER; --系统参数限制标识
BEGIN
    --init
    --赋初始值
    V_RETURN := 0;
    --start
    --校验当前用户是否为管理员
    IF I_YHID = 0 THEN
        --如果为管理员则获取系统参数，判断当前开关
        BEGIN
            SELECT NVL(TO_NUMBER(PARAMVALUE),1) INTO V_XZBZ FROM LIVEBOS.TSYSPARAM WHERE PARAMNAME = 'pif.sys.admin.limit';
            EXCEPTION WHEN OTHERS THEN
              V_XZBZ := 1;
        END;
        IF V_XZBZ = 0 THEN
            V_RETURN := 1;
        END IF;
    ELSE
        --非管理员则直接允许操作；
        V_RETURN := 1;
    END IF;
    --return
    --最终返回
    RETURN(V_RETURN);
END FUNC_PIF_HQGLYQXBZ;
/

