create PROCEDURE PRO_SJQX_CP_FXTZHSY_CPZX(O_CODE OUT NUMBER, --返回值
                                                     O_NOTE OUT VARCHAR2, --返回消息
                                                     I_RQ   IN NUMBER --统计日期
                                                     ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：风险调整后收益-数据清洗逻辑
      语法信息：
           输入参数：   I_RQ    日期
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-15     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
  V_RQ   NUMBER;
  V_JSRQ NUMBER;  -- 取计算日期上一个交易日，作为统计区间结束时间
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --1. 确定 计算日期
  IF I_RQ IS NULL THEN
    --计算上个交易日的
    SELECT MAX(JYR)
      INTO V_RQ
      FROM LIVEBOS.TXTJYR A
     WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
  ELSE
    V_RQ := I_RQ;
  END IF;
  
  -- liliang 取计算日期上一个交易日，作为统计区间结束时间
  SELECT MAX(JYR)
    INTO V_JSRQ
    FROM LIVEBOS.TXTJYR
   WHERE JYR < I_RQ
     AND ZRR = JYR;

  --2. 清空表数据
--  EXECUTE IMMEDIATE 'TRUNCATE TABLE DSC_STAT.TEMP_TPIF_STAT_CP_FXTZHSY';
--  EXECUTE IMMEDIATE 'TRUNCATE TABLE PIF.TEMP_STAT_CP_FXTZHSY';

  --2.1 夏普比率
  PRO_SJQX_CP_FXTZHSY_XPBL_CPZX(V_CODE, V_NOTE, V_RQ, V_JSRQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.2 索提诺比率
  PRO_SJQX_CP_FXTZHSY_STNBL_CPZX(V_CODE, V_NOTE, V_RQ, V_JSRQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.3 卡玛比率
  PRO_SJQX_CP_FXTZHSY_KMBL_CPZX(V_CODE, V_NOTE, V_RQ, V_JSRQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --3.TEMP_STAT_CP_SYTZ 表数据加载到 TPIF_STAT_CP_SYTZ表中
  INSERT INTO DSC_STAT.TEMP_TPIF_STAT_CP_FXTZHSY
    (RQ,
     CPID,
     JZRQ,
     JYRQ,
     DWJZ,
     XPBL_3Y,
     XPBL_6Y,
     XPBL_1N,
     XPBL_3N,
     XPBL_5N,
     XPBL_CLYL,
     XPBL_JNYL,
     STNBL_3Y,
     STNBL_6Y,
     STNBL_1N,
     STNBL_3N,
     STNBL_5N,
     STNBL_CLYL,
     STNBL_JNYL,
     KMBL_3Y,
     KMBL_6Y,
     KMBL_1N,
     KMBL_3N,
     KMBL_5N,
     KMBL_CLYL,
     KMBL_JNYL)
    SELECT RQ,
           CPID,
           JZRQ,
           JYRQ,
           DWJZ,
           SUM(NVL(XPBL_3Y, 0)),
           SUM(NVL(XPBL_6Y, 0)),
           SUM(NVL(XPBL_1N, 0)),
           SUM(NVL(XPBL_3N, 0)),
           SUM(NVL(XPBL_5N, 0)),
           SUM(NVL(XPBL_CLYL, 0)),
           SUM(NVL(XPBL_JNYL, 0)),
           SUM(NVL(STNBL_3Y, 0)),
           SUM(NVL(STNBL_6Y, 0)),
           SUM(NVL(STNBL_1N, 0)),
           SUM(NVL(STNBL_3N, 0)),
           SUM(NVL(STNBL_5N, 0)),
           SUM(NVL(STNBL_CLYL, 0)),
           SUM(NVL(STNBL_JNYL, 0)),
           SUM(NVL(KMBL_3Y, 0)),
           SUM(NVL(KMBL_6Y, 0)),
           SUM(NVL(KMBL_1N, 0)),
           SUM(NVL(KMBL_3N, 0)),
           SUM(NVL(KMBL_5N, 0)),
           SUM(NVL(KMBL_CLYL, 0)),
           SUM(NVL(KMBL_JNYL, 0))
    
      FROM TEMP_STAT_CP_FXTZHSY
     WHERE RQ = V_JSRQ
     GROUP BY RQ, CPID, JZRQ, JYRQ, DWJZ;

  --COMMIT;
  O_CODE := 1;
  O_NOTE := 'DSC_STAT.TPIF_STAT_CP_FXTZHSY_CPZX 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := V_NOTE;
END;
/

