create PROCEDURE pro_pif_rwgl_rwcz(O_CODE   OUT NUMBER, --返回值
                                              O_NOTE   OUT VARCHAR2, --返回消息
                                              I_USERid IN INTEGER, --操作人
                                              I_IP     IN VARCHAR2, --操作IP
                                              I_OPER   IN INTEGER, --操作类型 0|新增；1|修改；2|取消任务；3|删除任务；4|任务分解；5|任务分配调整；6|任务确认
                                              I_ID     IN OUT NUMBER, --操作ID
                                              I_RWBT   in varchar2, --任务标题
                                              I_RWNR   in varchar2, --任务内容
                                              I_RWLX   in number, --任务类型
                                              I_KSRQ   in number, --开始日期
                                              I_JSRQ   in number, --结束日期
                                              I_RWLD   in number, --任务粒度
                                              I_RWHF   in number, --任务划分
                                              I_CPLB   in number, --产品类别
                                              I_CPID   in number, --产品ID
                                              I_FJMC   in varchar2, --附件名称
                                              I_MD5    in varchar2, --MD5
                                              I_CZC    in varchar2 --操作串
                                              ) IS
  /*
  **功能说明：任务主表管理
  **创建人：涂孟
  **创建日期：2020-07-20
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **涂孟                 2020-07-20   创建
  */
  V_COUNT  INTEGER; --计数变量
  V_ID     INTEGER;
  V_OBJ    TPIF_RWFPXX%ROWTYPE; --表单记录
  V_NOTE   VARCHAR2(2000); --描述信息
  V_RWZTMS varchar2(50); --任务状态描述
  V_CZC    varchar2(2000) := I_CZC;
  V_ZBID   varchar2(2000); --指标id
  V_MBL    varchar2(2000); --目标量
  V_CZC_S  varchar2(2000); --操作子串
  V_CZC_S2 varchar2(2000); --操作字串2 
  v_zrwid  number(16); --子任务id
  v_zrwzxr number(16); --子任务执行人
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_RWFPXX WHERE ID = I_ID;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --check
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --//:新增-----------------------------------------------------------------------
    IF I_USERid IS NULL THEN
      O_NOTE := '[用户ID]不允许为空!';
      RETURN;
    END IF;
    IF I_RWBT IS NULL THEN
      O_NOTE := '[任务标题]不允许为空!';
      RETURN;
    END IF;
    IF I_RWNR IS NULL THEN
      O_NOTE := '[任务内容]不允许为空!';
      RETURN;
    END IF;
    IF I_RWLX IS NULL THEN
      O_NOTE := '[任务类型]不允许为空!';
      RETURN;
    END IF;
    IF I_KSRQ IS NULL THEN
      O_NOTE := '[任务开始日期]不允许为空!';
      RETURN;
    END IF;
    IF I_JSRQ IS NULL THEN
      O_NOTE := '[任务结束日期]不允许为空!';
      RETURN;
    END IF;
    /*    IF I_RWLD IS NULL THEN
      O_NOTE := '[任务粒度]不允许为空!';
      RETURN;
    END IF;*/
    --任务标题不能重复
    select count(1) into v_count from TPIF_RWFPXX a where a.rwbt = i_rwbt;
    if v_count > 0 then
      o_note := '该任务标题已存在1';
      return;
    end if;
  
    --插入任务表记录，总任务执行对象总是总公司
    I_ID := livebos.func_nextid('TPIF_RWFPXX');
    insert into pif.TPIF_RWFPXX a
      (id,
       rwbt,
       rwnr,
       cjr,
       cjsj,
       rwzt,
       sfqr,
       rwcj,
       fj,
       fjlj,
       rwlx,
       rwld,
       rwksrq,
       rwjzrq,
       zxr,
       zxrmc,
       zxrlx,
       cpxf,
       cplx,
       glcp)
    values
      (I_ID,
       i_rwbt,
       i_rwnr,
       i_userid,
       sysdate,
       2,
       1,
       1,
       i_fjmc,
       '/OperateProcessor?Column=FJ&PopupWin=false&Table=TPIF_RWFPXX&&operate=Download&&Type=Attachment&ID=' || I_ID,
       i_rwlx,
       i_rwld,
       i_ksrq,
       i_jsrq,
       1,
       '天风证券股份有限公司',
       1, --公司
       i_rwhf,
       I_CPLB,
       i_cpid);
  
  END IF;
  IF I_OPER = 1 THEN
    --修改-----------------------------------------------------------------------
    IF I_USERid IS NULL THEN
      O_NOTE := '[用户ID]不允许为空!';
      RETURN;
    END IF;
    IF I_ID IS NULL THEN
      O_NOTE := '[记录ID]不允许为空!';
      RETURN;
    END IF;
    IF I_RWBT IS NULL THEN
      O_NOTE := '[任务标题]不允许为空!';
      RETURN;
    END IF;
    IF I_RWNR IS NULL THEN
      O_NOTE := '[任务内容]不允许为空!';
      RETURN;
    END IF;
    IF I_RWLX IS NULL THEN
      O_NOTE := '[任务类型]不允许为空!';
      RETURN;
    END IF;
    IF I_KSRQ IS NULL THEN
      O_NOTE := '[任务开始日期]不允许为空!';
      RETURN;
    END IF;
    IF I_JSRQ IS NULL THEN
      O_NOTE := '[任务结束日期]不允许为空!';
      RETURN;
    END IF;
    /*    IF I_RWLD IS NULL THEN
      O_NOTE := '[任务粒度]不允许为空!';
      RETURN;
    END IF;*/
    update TPIF_RWFPXX a
       set a.rwbt   = I_RWBT,
           a.rwnr   = I_RWNR,
           a.fj     = I_FJMC,
           a.rwlx   = I_RWLX,
           a.rwld   = I_RWLD,
           a.rwksrq = I_KSRQ,
           a.rwjzrq = I_JSRQ,
           a.cpxf   = I_RWHF,
           a.cplx   = I_CPLB,
           a.glcp   = I_CPID
     where a.id = I_ID;
  END IF;
  IF I_OPER = 2 THEN
    --取消任务-----------------------------------------------------------------------
    if I_ID is null then
      O_NOTE := '任务取消时，[操作ID]不允许为空！';
      return;
    end if;
    if v_obj.rwcj != 1 then
      O_NOTE := '子任务不允许取消！';
      return;
    end if;
    update pif.TPIF_RWFPXX a
       set a.rwzt = 1
     where id in (select t.id
                    from TPIF_RWFPXX t
                   start with t.id = i_id
                  connect by prior id = frw);
  END IF;
  IF I_OPER = 3 THEN
    --删除任务-----------------------------------------------------------------
    if I_ID is null then
      O_NOTE := '任务删除时，[操作ID]不允许为空！';
      return;
    end if;
    if v_obj.rwcj != 1 then
      O_NOTE := '子任务不允许删除！';
      return;
    end if;
    select note
      into V_RWZTMS
      from livebos.txtdm a
     where fldm = 'PIF_RWZT'
       and ibm = v_obj.rwzt;
    if v_obj.rwzt != 2 then
      O_NOTE := '任务' || v_rwztms || '，不允许删除！';
      return;
    end if;
    delete from pif.TPIF_RWFPXX where id = i_id;
  END IF;
  if i_oper = 5 then
    --任务分配调整
    --入参检验
    if I_ID is null then
      O_NOTE := '任务分配调整时，[操作ID]不允许为空！';
      return;
    end if;
    --先删除任务子表，以及对应任务指标关系
    delete from tpif_rwzbgx a
     where rwxx in (select id from tpif_rwfpxx where frw = i_id);
    delete from tpif_rwfpxx a where a.frw = i_id;
  end if;

  IF I_OPER in (4, 5) THEN
    --任务分解-------------------------------------------------------------------
    --入参检验
    if I_ID is null then
      O_NOTE := '任务分解时，[操作ID]不允许为空！';
      return;
    end if;
    --判断父任务指标个数，为下面循环做准备
    select count(1) into v_count from TPIF_RWZBGX a where a.rwxx = i_id;
    while V_CZC is not null loop
      v_zrwid := livebos.func_nextid('TPIF_RWFPXX');
      v_czc_s := substr(v_czc, 1, instr(v_czc, ',', 1, v_count) - 1);
      if v_czc_s is not null then
        v_zrwzxr := substr(v_czc_s, 1, instr(v_czc_s, '|', 1, 1) - 1);
        --新增子任务主表
        insert into pif.TPIF_RWFPXX a
          (id,
           rwbt,
           rwnr,
           cjr,
           cjsj,
           rwzt,
           sfqr,
           rwcj,
           frw,
           fj,
           fjlj,
           rwlx,
           rwld,
           rwksrq,
           rwjzrq,
           zxr,
           zxrmc,
           zxrlx,
           cpxf,
           cplx,
           glcp)
        values
          (v_zrwid,
           v_obj.rwbt || '-' ||
           (select name
              from livebos.lborganization jg
             where jg.id = v_zrwzxr),
           v_obj.rwnr,
           i_userid,
           sysdate,
           case when v_obj.rwcj = 2 then 3 else 2 end,
           case when v_obj.rwcj = 2 then 0 else 1 end,
           v_obj.rwcj + 1,
           i_id,
           v_obj.fj,
           v_obj.fjlj,
           v_obj.rwlx,
           v_obj.rwld,
           v_obj.rwksrq,
           v_obj.rwjzrq,
           v_zrwzxr,
           (select name
              from livebos.lborganization jg
             where jg.id = v_zrwzxr),
           v_obj.rwcj + 1,
           v_obj.cpxf,
           v_obj.cplx,
           v_obj.glcp);
        --新增子任务指标关系表记录
        while v_czc_s is not null loop
          v_czc_s2 := substr(v_czc_s, 1, instr(v_czc_s, ',', 1, 1) - 1);
          if v_czc_s2 is null then
            V_ZBID  := substr(v_czc_s,
                              instr(v_czc_s, '|', 1, 1) + 1,
                              instr(v_czc_s, '=', 1, 1) -
                              instr(v_czc_s, '|', 1, 1) - 1);
            V_MBL   := substr(v_czc_s, instr(v_czc_s, '=', 1, 1) + 1);
            v_czc_s := '';
            insert into TPIF_RWZBGX a
              (id, rwxx, zbxx, mbl)
            values
              (livebos.func_nextid('TPIF_RWZBGX'), v_zrwid, v_zbid, v_mbl);
          else
            V_ZBID  := substr(v_czc_s2,
                              instr(v_czc_s2, '|', 1, 1) + 1,
                              instr(v_czc_s2, '=', 1, 1) -
                              instr(v_czc_s2, '|', 1, 1) - 1);
            V_MBL   := substr(v_czc_s2, instr(v_czc_s2, '=', 1, 1) + 1);
            v_czc_s := substr(v_czc_s, instr(v_czc_s, ',', 1, 1) + 1);
            insert into TPIF_RWZBGX a
              (id, rwxx, zbxx, mbl)
            values
              (livebos.func_nextid('TPIF_RWZBGX'), v_zrwid, v_zbid, v_mbl);
          end if;
        end loop;
        v_czc := substr(v_czc, instr(v_czc, ',', 1, v_count) + 1);
      else
        v_zrwzxr := substr(v_czc, 1, instr(v_czc, '|', 1, 1) - 1);
        --新增子任务主表
        insert into pif.TPIF_RWFPXX a
          (id,
           rwbt,
           rwnr,
           cjr,
           cjsj,
           rwzt,
           sfqr,
           rwcj,
           frw,
           fj,
           fjlj,
           rwlx,
           rwld,
           rwksrq,
           rwjzrq,
           zxr,
           zxrmc,
           zxrlx,
           cpxf,
           cplx,
           glcp)
        values
          (v_zrwid,
           v_obj.rwbt || '-' ||
           (select name
              from livebos.lborganization jg
             where jg.id = v_zrwzxr),
           v_obj.rwnr,
           i_userid,
           sysdate,
           case when v_obj.rwcj = 2 then 3 else 2 end,
           case when v_obj.rwcj = 2 then 0 else 1 end,
           v_obj.rwcj + 1,
           i_id,
           v_obj.fj,
           v_obj.fjlj,
           v_obj.rwlx,
           v_obj.rwld,
           v_obj.rwksrq,
           v_obj.rwjzrq,
           v_zrwzxr,
           (select name
              from livebos.lborganization jg
             where jg.id = v_zrwzxr),
           v_obj.rwcj + 1,
           v_obj.cpxf,
           v_obj.cplx,
           v_obj.glcp);
        --新增子任务指标关系表记录
        while v_czc is not null loop
          v_czc_s2 := substr(v_czc, 1, instr(v_czc, ',', 1, 1) - 1);
          if v_czc_s2 is null then
            V_ZBID := substr(v_czc,
                             instr(v_czc, '|', 1, 1) + 1,
                             instr(v_czc, '=', 1, 1) -
                             instr(v_czc, '|', 1, 1) - 1);
            V_MBL  := substr(v_czc, instr(v_czc, '=', 1, 1) + 1);
            v_czc  := '';
            insert into TPIF_RWZBGX a
              (id, rwxx, zbxx, mbl)
            values
              (livebos.func_nextid('TPIF_RWZBGX'), v_zrwid, v_zbid, v_mbl);
          else
            V_ZBID := substr(v_czc_s2,
                             instr(v_czc_s2, '|', 1, 1) + 1,
                             instr(v_czc_s2, '=', 1, 1) -
                             instr(v_czc_s2, '|', 1, 1) - 1);
            V_MBL  := substr(v_czc_s2, instr(v_czc_s2, '=', 1, 1) + 1);
            v_czc  := substr(v_czc, instr(v_czc, ',', 1, 1) + 1);
            insert into TPIF_RWZBGX a
              (id, rwxx, zbxx, mbl)
            values
              (livebos.func_nextid('TPIF_RWZBGX'), v_zrwid, v_zbid, v_mbl);
          end if;
        end loop;
        v_czc := '';
      end if;
    end loop;
    --更新主表任务状态为已下达
    update TPIF_RWFPXX a set a.rwzt = 3 where a.id = i_id;
  
  end if;

  if i_oper = 6 then
    --任务确认-----------------------------------------------------------------------
    if I_ID is null then
      O_NOTE := '任务确认时，[操作ID]不允许为空！';
      return;
    end if;
    if v_obj.sfqr = 1 then
      O_NOTE := '该任务已确认！';
      return;
    end if;
  
    update tpif_rwfpxx a set a.sfqr = 1 where id = i_id;
  
  end if;

  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '取消任务',
                         3,
                         '删除任务',
                         4,
                         '任务分解',
                         5,
                         '任务分配调整',
                         6,
                         '任务确认') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
  commit;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    rollback;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END pro_pif_rwgl_rwcz;
/

