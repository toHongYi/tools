create PROCEDURE PRO_PIF_YYGL_CPSJSC(O_CODE   OUT NUMBER,
                                                    O_NOTE   OUT VARCHAR2,
                                                    I_CPSJLX IN NUMBER, --产品事件类型
                                                    I_DYGC   IN VARCHAR2, --调用过程
                                                    I_RZLX   IN NUMBER, --1|日常;2|重做;3|调整
                                                    I_KSRQ   IN NUMBER DEFAULT NULL, --开始日期
                                                    I_JSRQ   IN NUMBER DEFAULT NULL --结束日期
                                                    ) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：产品事件生成
          I_RQ    --日期
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
         关联调度
    运行原理：
          1.入参校验
         2.获取事件类型，执行事件调度。
           2.1获取事件类型。
           2.2生成产品事件。
    功能修订：
        简要说明：
          产品事件生成调度主过程
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/14     1.0.1     林嵩              运营管理调度主过程。
        2014/12/10     1.0.2     刘浪浪            增加日志类型入参以记录日志的来自的不同操作
        2015/01/27     1.0.3     刘浪浪            日期入参由VARCHAR2改为NUMBER
    *********************************************************************************************************************/
    V_KSRQ      NUMBER(8) DEFAULT I_KSRQ; --当前日期
    V_JSRQ      NUMBER(8) DEFAULT I_JSRQ; --结束日期
    V_SQL     VARCHAR2(500); --执行SQL
    V_RZLX    NUMBER(8) DEFAULT I_RZLX; --日志类型
    V_CURDATE DATE; --当前时间
BEGIN
    O_CODE := 1;
    O_NOTE := '成功';
    --1.***************************入参校验 ***************************
    IF I_CPSJLX IS NULL OR I_DYGC IS NULL THEN
        O_CODE := -1;
        O_NOTE := '事件类型与调用过程不允许为空!';
        RETURN;
    END IF;

    --当前变量赋值
    IF V_KSRQ IS NULL THEN
        V_KSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
    END IF;
    IF V_JSRQ IS NULL THEN
        V_JSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
    END IF;

    --2.***************************获取事件类型，执行事件调度。***************************
    V_CURDATE := SYSDATE;
    --2.1.***************************执行过程调度。***************************
    V_SQL := 'BEGIN ' || I_DYGC || '(:V1,:V2,:V3,:V4,:V5); END;';
    EXECUTE IMMEDIATE V_SQL
        USING OUT O_CODE, OUT O_NOTE, IN V_RZLX, IN V_KSRQ, IN V_JSRQ;
    --2.2.***************************失败时，更新类型信息。***************************
    IF O_CODE < 0 THEN
        --记录日志。
        PRO_PIF_YYGL_DJSJSCRZ(O_CODE,
                              O_NOTE,
                              I_CPSJLX,
                              V_KSRQ,
                              V_CURDATE,
                              SYSDATE,
                              -1,
                              0,
                              0,
                              SYSDATE - V_CURDATE,
                              O_NOTE,
                              V_RZLX);
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_CPSJSC;
/

