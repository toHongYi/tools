create PROCEDURE PRO_SJQX_CPDM_GL_JJHYTZ(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2 --返回消息
                                                    ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：基金行业投资-TPIF_CPDM_GL_JJHYTZ数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-16     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPDM_GL_JJHYTZ ';

  INSERT INTO TPIF_CPDM_GL_JJHYTZ
    (ID, --ID
     CPID, --产品ID
     BBQ, --报告期
     HYDM, --行业代码
     HYMC, --行业名称
     HYSZ, --行业市值(万元)
     ZZCJZBL, --占资产净值比例
     LRR,
     LRSJ)
    SELECT SEQ_TPIF_CPDM_GL_JJHYTZ.NEXTVAL,
           CPID, --产品ID
           BBQ, --报告期
           LIVEBOS.FUNC_PINYIN(HYMC), --行业代码
           HYMC, --行业名称
           ZQSZ, --行业市值(万元)
           ZZCJZBL,
           0,
           SYSDATE
      FROM (SELECT M.CPID,
                   M.BBQ,
                   M.HYMC,
                   SUM(M.ZQSZ) AS ZQSZ,
                   SUM(M.ZZCJZBL) AS ZZCJZBL
            
              FROM (SELECT B.CPID,
                           TO_CHAR(A.STATISTIC_DATE, 'YYYYMMDD') AS BBQ,
                           A.SW_LEVEL1 AS HYMC,
                           A.STOCK_A_VALUE AS ZQSZ,
                           A. STOCK_RATIO AS ZZCJZBL,
                           RANK() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) AS RK
                      FROM SRC_PIF.T_FUND_SHAREHOLDING A, PIF.TPIF_CPDM B
                     WHERE A.FUND_ID = B.ZYNM) M
             WHERE M.RK = 1
             GROUP BY M.CPID, M.BBQ, M.HYMC);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM_GL_JJHYTZ 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM_GL_JJHYTZ 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM_GL_JJHYTZ 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

