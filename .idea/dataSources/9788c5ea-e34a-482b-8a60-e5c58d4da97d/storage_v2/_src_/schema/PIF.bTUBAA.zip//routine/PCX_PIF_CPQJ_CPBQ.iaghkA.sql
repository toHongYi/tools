create PROCEDURE PCX_PIF_CPQJ_CPBQ(O_CODE    OUT NUMBER,
                                              O_NOTE    OUT VARCHAR2,
                                              O_RESULT  OUT SYS_REFCURSOR,
                                              I_USERID  IN NUMBER,
                                              I_PROD_ID IN NUMBER --产品ID
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询产品标签
  所属用户：PIF
  概要说明：查询产品标签.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品标签.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/05/08     1.0.0.1   TUMENG             新增.
  *********************************************************************************************************************/
  V_SQL VARCHAR2(32767);
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  V_SQL := ' SELECT T1.CPDM PROD_CODE,
                    T1.CPMC PROD_SIMP_NAME,
                    T2.BM LABEL_CODE,
                    T2.MC LABEL_NAME,
                    T3.XSSX DISPLAY_ORDER
             FROM PIF.TPIF_CPDM T1,
                  PIF.TPIF_CPBQ T2,
                  PIF.TPIF_CPBQMX T3
            WHERE T1.ID = T3.CPID
              AND T3.CPBQ = T2.ID
              AND T3.CPID = ' || I_PROD_ID;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_CPBQ;
/

