create PROCEDURE PRO_SJQX_CPJZFXZB_CPZX(O_CODE OUT NUMBER, --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   I_KSRQ IN NUMBER DEFAULT NULL,
                                                   I_JSRQ IN NUMBER DEFAULT NULL,
                                                   I_CPDM IN VARCHAR2 DEFAULT NULL) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品净值分析指标-产品中心-数据清洗逻辑
      语法信息：
           输入参数：    见参数定义
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
          2021-7-2       1.0.0     GAOKUN               新增
  ***********************************************************************/
  V_JSRQ NUMBER;
  V_KSRQ NUMBER;
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);
  V_CPID NUMBER(20);

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --根据输入的产品代码获取产品ID，如果入参CPDM为空，则CPID为空
  BEGIN
    SELECT CPID INTO V_CPID FROM TPIF_CPDM WHERE CPDM = I_CPDM; --获取CPID
  EXCEPTION
    WHEN OTHERS THEN
      V_CPID := NULL;
  END;

  IF ((I_KSRQ IS NULL) AND (I_JSRQ IS NULL)) THEN
    --如果开始日期和结束日期都为空，则都置为上个交易日，只计算上个交易日的指标
    SELECT MAX(JYR)
      INTO V_JSRQ
      FROM LIVEBOS.TXTJYR
     WHERE JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
    V_KSRQ := V_JSRQ;
  
  ELSIF ((I_KSRQ IS NOT NULL) AND (I_JSRQ IS NULL)) THEN
    --开始日期不为空，结束日期为空，则默认结束日期为上个交易日，计算开始日期到上个交易日的指标
    SELECT MAX(JYR)
      INTO V_JSRQ
      FROM LIVEBOS.TXTJYR
     WHERE JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
    V_KSRQ := I_KSRQ;
  
  ELSIF ((I_KSRQ IS NULL) AND (I_JSRQ IS NOT NULL)) THEN
    --开始日期为空，结束日期不为空，不符合输入，报错
    O_NOTE := '请输入开始日期！';
    RETURN;
  
  ELSIF ((I_KSRQ IS NOT NULL) AND (I_JSRQ IS NOT NULL)) THEN
    --如果开始日期和结束日期都不为空，判断输入是否合理，合理则计算日期之间的指标
    IF (I_KSRQ > I_JSRQ) THEN
      O_NOTE := '请输入正确的开始日期和结束日期！';
      RETURN;
    END IF;
    V_KSRQ := I_KSRQ;
    V_JSRQ := I_JSRQ;
  END IF;

  --EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_TPIF_CPJZXX'; --清空中间表数据
  --EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_TPIF_CPJZ';

  --产品中心净值数据导入计算用的中间表
  IF I_CPDM IS NULL THEN
    --如果入参产品代码为空，则计算全部
    INSERT INTO TEMP_TPIF_CPJZXX
      (CPID,
       JZRQ,
       DWJZ,
       LJJZ,
       FQJZ,
       NHSYL,
       WFSYL,
       RZF,
       QRZT,
       SJLY,
       FBR,
       CZSJ,
       NHSYL_D7,
       JYRQ)
      SELECT CPID,
             JZRQ,
             DWJZ,
             LJJZ,
             FQJZ,
             NHSYL,
             WFSYL,
             RZF,
             QRZT,
             SJLY,
             FBR,
             CZSJ,
             NHSYL_D7,
             JYRQ
        FROM TPIF_CPJZXX_CPZX;
  
    INSERT INTO TEMP_TPIF_CPJZ
      (ID,
       CPID,
       JYRQ,
       JZRQ,
       ZCZZ,
       ZCJZ,
       DWJZ,
       LJJZ,
       FQJZ,
       WFSYL,
       RZF,
       ZZF,
       NHSYL_D7,
       NHSYL,
       SJLY,
       QRZT,
       FBR,
       CZSJ)
      SELECT ID,
             CPID,
             JYRQ,
             JZRQ,
             ZCZZ,
             ZCJZ,
             DWJZ,
             LJJZ,
             FQJZ,
             WFSYL,
             RZF,
             ZZF,
             NHSYL_D7,
             NHSYL,
             SJLY,
             QRZT,
             FBR,
             CZSJ
        FROM TPIF_CPJZ;
  
  ELSE
    --如果入参产品代码有值，则只计算该产品的指标
    INSERT INTO TEMP_TPIF_CPJZXX
      (CPID,
       JZRQ,
       DWJZ,
       LJJZ,
       FQJZ,
       NHSYL,
       WFSYL,
       RZF,
       QRZT,
       SJLY,
       FBR,
       CZSJ,
       NHSYL_D7,
       JYRQ)
      SELECT CPID,
             JZRQ,
             DWJZ,
             LJJZ,
             FQJZ,
             NHSYL,
             WFSYL,
             RZF,
             QRZT,
             SJLY,
             FBR,
             CZSJ,
             NHSYL_D7,
             JYRQ
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = V_CPID;
  
    INSERT INTO TEMP_TPIF_CPJZ
      (ID,
       CPID,
       JYRQ,
       JZRQ,
       ZCZZ,
       ZCJZ,
       DWJZ,
       LJJZ,
       FQJZ,
       WFSYL,
       RZF,
       ZZF,
       NHSYL_D7,
       NHSYL,
       SJLY,
       QRZT,
       FBR,
       CZSJ)
      SELECT ID,
             CPID,
             JYRQ,
             JZRQ,
             ZCZZ,
             ZCJZ,
             DWJZ,
             LJJZ,
             FQJZ,
             WFSYL,
             RZF,
             ZZF,
             NHSYL_D7,
             NHSYL,
             SJLY,
             QRZT,
             FBR,
             CZSJ
        FROM TPIF_CPJZ
       WHERE CPID = V_CPID;
  END IF;

  --COMMIT;

  --EXECUTE IMMEDIATE 'TRUNCATE TABLE DSC_STAT.TEMP_TPIF_STAT_CP_SYTZ';
  --EXECUTE IMMEDIATE 'TRUNCATE TABLE DSC_STAT.TEMP_TPIF_STAT_CP_FXTZ';
  --EXECUTE IMMEDIATE 'TRUNCATE TABLE DSC_STAT.TEMP_TPIF_STAT_CP_FXTZHSY';

  FOR CUR_RQ IN (SELECT JYR
                   FROM LIVEBOS.TXTJYR
                  WHERE ZRR = JYR
                    AND ZRR >= V_KSRQ
                    AND ZRR <= V_JSRQ
                  ORDER BY ZRR ASC) LOOP
  
    PIF.PRO_SJQX_CP_SYTZ_CPZX(V_CODE, V_NOTE, CUR_RQ.JYR); --收益特征
    IF V_CODE = -1 THEN
      O_NOTE := V_NOTE;
      RETURN;
    END IF;
  
    PIF.PRO_SJQX_CP_FXTZ_CPZX(V_CODE, V_NOTE, CUR_RQ.JYR); --风险特征
    IF V_CODE = -1 THEN
      O_NOTE := V_NOTE;
      RETURN;
    END IF;
  
    PIF.PRO_SJQX_CP_FXTZHSY_CPZX(V_CODE, V_NOTE, CUR_RQ.JYR); --风险调整后收益
    IF V_CODE = -1 THEN
      O_NOTE := V_NOTE;
      RETURN;
    END IF;
  
  END LOOP;

  MERGE INTO DSC_STAT.TPIF_STAT_CP_SYTZ_HIS_CPZX A
  USING (SELECT * FROM DSC_STAT.TEMP_TPIF_STAT_CP_SYTZ) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ)
  WHEN MATCHED THEN
    UPDATE
       SET A.JZRQ          = B.JZRQ,
           A.JYRQ          = B.JYRQ,
           A.DWJZ          = B.DWJZ,
           A.LJJZ          = B.LJJZ,
           A.FQJZ          = B.FQJZ,
           A.QJSYL_1Y      = B.QJSYL_1Y,
           A.QJSYL_3Y      = B.QJSYL_3Y,
           A.QJSYL_6Y      = B.QJSYL_6Y,
           A.QJSYL_1N      = B.QJSYL_1N,
           A.QJSYL_3N      = B.QJSYL_3N,
           A.QJSYL_5N      = B.QJSYL_5N,
           A.QJSYL_CLYL    = B.QJSYL_CLYL,
           A.QJSYL_JNYL    = B.QJSYL_JNYL,
           A.QJNHSYL_1Y    = B.QJNHSYL_1Y,
           A.QJNHSYL_3Y    = B.QJNHSYL_3Y,
           A.QJNHSYL_6Y    = B.QJNHSYL_6Y,
           A.QJNHSYL_1N    = B.QJNHSYL_1N,
           A.QJNHSYL_3N    = B.QJNHSYL_3N,
           A.QJNHSYL_5N    = B.QJNHSYL_5N,
           A.QJNHSYL_CLYL  = B.QJNHSYL_CLYL,
           A.QJNHSYL_JNYL  = B.QJNHSYL_JNYL,
           A.QJSYSL_1Y     = B.QJSYSL_1Y,
           A.QJSYSL_3Y     = B.QJSYSL_3Y,
           A.QJSYSL_6Y     = B.QJSYSL_6Y,
           A.QJSYSL_1N     = B.QJSYSL_1N,
           A.QJSYSL_3N     = B.QJSYSL_3N,
           A.QJSYSL_CLYL   = B.QJSYSL_CLYL,
           A.QJSYSL_JNYL   = B.QJSYSL_JNYL,
           A.YLPJSYL_1Y    = B.YLPJSYL_1Y,
           A.YLPJSYL_3Y    = B.YLPJSYL_3Y,
           A.YLPJSYL_6Y    = B.YLPJSYL_6Y,
           A.YLPJSYL_1N    = B.YLPJSYL_1N,
           A.YLPJSYL_3N    = B.YLPJSYL_3N,
           A.YLPJSYL_CLYL  = B.YLPJSYL_CLYL,
           A.YLPJSYL_JNYL  = B.YLPJSYL_JNYL,
           A.DCZDSYL_1Y    = B.DCZDSYL_1Y,
           A.DCZDSYL_3Y    = B.DCZDSYL_3Y,
           A.DCZDSYL_6Y    = B.DCZDSYL_6Y,
           A.DCZDSYL_1N    = B.DCZDSYL_1N,
           A.DCZDSYL_3N    = B.DCZDSYL_3N,
           A.DCZDSYL_CLYL  = B.DCZDSYL_CLYL,
           A.DCZDSYL_JNYL  = B.DCZDSYL_JNYL,
           A.ZDLXYLCS_1Y   = B.ZDLXYLCS_1Y,
           A.ZDLXYLCS_3Y   = B.ZDLXYLCS_3Y,
           A.ZDLXYLCS_6Y   = B.ZDLXYLCS_6Y,
           A.ZDLXYLCS_1N   = B.ZDLXYLCS_1N,
           A.ZDLXYLCS_3N   = B.ZDLXYLCS_3N,
           A.ZDLXYLCS_CLYL = B.ZDLXYLCS_CLYL,
           A.ZDLXYLCS_JNYL = B.ZDLXYLCS_JNYL
  WHEN NOT MATCHED THEN
    INSERT
      (A.CPID,
       A.RQ,
       A.JZRQ,
       A.JYRQ,
       A.DWJZ,
       A.LJJZ,
       A.FQJZ,
       A.QJSYL_1Y,
       A.QJSYL_3Y,
       A.QJSYL_6Y,
       A.QJSYL_1N,
       A.QJSYL_3N,
       A.QJSYL_5N,
       A.QJSYL_CLYL,
       A.QJSYL_JNYL,
       A.QJNHSYL_1Y,
       A.QJNHSYL_3Y,
       A.QJNHSYL_6Y,
       A.QJNHSYL_1N,
       A.QJNHSYL_3N,
       A.QJNHSYL_5N,
       A.QJNHSYL_CLYL,
       A.QJNHSYL_JNYL,
       A.QJSYSL_1Y,
       A.QJSYSL_3Y,
       A.QJSYSL_6Y,
       A.QJSYSL_1N,
       A.QJSYSL_3N,
       A.QJSYSL_CLYL,
       A.QJSYSL_JNYL,
       A.YLPJSYL_1Y,
       A.YLPJSYL_3Y,
       A.YLPJSYL_6Y,
       A.YLPJSYL_1N,
       A.YLPJSYL_3N,
       A.YLPJSYL_CLYL,
       A.YLPJSYL_JNYL,
       A.DCZDSYL_1Y,
       A.DCZDSYL_3Y,
       A.DCZDSYL_6Y,
       A.DCZDSYL_1N,
       A.DCZDSYL_3N,
       A.DCZDSYL_CLYL,
       A.DCZDSYL_JNYL,
       A.ZDLXYLCS_1Y,
       A.ZDLXYLCS_3Y,
       A.ZDLXYLCS_6Y,
       A.ZDLXYLCS_1N,
       A.ZDLXYLCS_3N,
       A.ZDLXYLCS_CLYL,
       A.ZDLXYLCS_JNYL,
       A.CPDM)
    VALUES
      (B.CPID,
       B.RQ,
       B.JZRQ,
       B.JYRQ,
       B.DWJZ,
       B.LJJZ,
       B.FQJZ,
       B.QJSYL_1Y,
       B.QJSYL_3Y,
       B.QJSYL_6Y,
       B.QJSYL_1N,
       B.QJSYL_3N,
       B.QJSYL_5N,
       B.QJSYL_CLYL,
       B.QJSYL_JNYL,
       B.QJNHSYL_1Y,
       B.QJNHSYL_3Y,
       B.QJNHSYL_6Y,
       B.QJNHSYL_1N,
       B.QJNHSYL_3N,
       B.QJNHSYL_5N,
       B.QJNHSYL_CLYL,
       B.QJNHSYL_JNYL,
       B.QJSYSL_1Y,
       B.QJSYSL_3Y,
       B.QJSYSL_6Y,
       B.QJSYSL_1N,
       B.QJSYSL_3N,
       B.QJSYSL_CLYL,
       B.QJSYSL_JNYL,
       B.YLPJSYL_1Y,
       B.YLPJSYL_3Y,
       B.YLPJSYL_6Y,
       B.YLPJSYL_1N,
       B.YLPJSYL_3N,
       B.YLPJSYL_CLYL,
       B.YLPJSYL_JNYL,
       B.DCZDSYL_1Y,
       B.DCZDSYL_3Y,
       B.DCZDSYL_6Y,
       B.DCZDSYL_1N,
       B.DCZDSYL_3N,
       B.DCZDSYL_CLYL,
       B.DCZDSYL_JNYL,
       B.ZDLXYLCS_1Y,
       B.ZDLXYLCS_3Y,
       B.ZDLXYLCS_6Y,
       B.ZDLXYLCS_1N,
       B.ZDLXYLCS_3N,
       B.ZDLXYLCS_CLYL,
       B.ZDLXYLCS_JNYL,
       I_CPDM);

  MERGE INTO DSC_STAT.TPIF_STAT_CP_FXTZ_HIS_CPZX A
  USING (SELECT * FROM DSC_STAT.TEMP_TPIF_STAT_CP_FXTZ) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ)
  WHEN MATCHED THEN
    UPDATE
       SET A.JZRQ           = B.JZRQ,
           A.JYRQ           = B.JYRQ,
           A.DWJZ           = B.DWJZ,
           A.NHBDL_3Y       = B.NHBDL_3Y,
           A.NHBDL_6Y       = B.NHBDL_6Y,
           A.NHBDL_1N       = B.NHBDL_1N,
           A.NHBDL_3N       = B.NHBDL_3N,
           A.NHBDL_5N       = B.NHBDL_5N,
           A.NHBDL_CLYL     = B.NHBDL_CLYL,
           A.NHBDL_JNYL     = B.NHBDL_JNYL,
           A.NHXXBDL_3Y     = B.NHXXBDL_3Y,
           A.NHXXBDL_6Y     = B.NHXXBDL_6Y,
           A.NHXXBDL_1N     = B.NHXXBDL_1N,
           A.NHXXBDL_3N     = B.NHXXBDL_3N,
           A.NHXXBDL_5N     = B.NHXXBDL_5N,
           A.NHXXBDL_CLYL   = B.NHXXBDL_CLYL,
           A.NHXXBDL_JNYL   = B.NHXXBDL_JNYL,
           A.ZDHC_3Y        = B.ZDHC_3Y,
           A.ZDHC_6Y        = B.ZDHC_6Y,
           A.ZDHC_1N        = B.ZDHC_1N,
           A.ZDHC_3N        = B.ZDHC_3N,
           A.ZDHC_5N        = B.ZDHC_5N,
           A.ZDHC_CLYL      = B.ZDHC_CLYL,
           A.ZDHC_JNYL      = B.ZDHC_JNYL,
           A.KSBL_3Y        = B.KSBL_3Y,
           A.KSBL_6Y        = B.KSBL_6Y,
           A.KSBL_1N        = B.KSBL_1N,
           A.KSBL_3N        = B.KSBL_3N,
           A.KSBL_5N        = B.KSBL_5N,
           A.KSBL_CLYL      = B.KSBL_CLYL,
           A.KSBL_JNYL      = B.KSBL_JNYL,
           A.DCZDKSSYL_3Y   = B.DCZDKSSYL_3Y,
           A.DCZDKSSYL_6Y   = B.DCZDKSSYL_6Y,
           A.DCZDKSSYL_1N   = B.DCZDKSSYL_1N,
           A.DCZDKSSYL_3N   = B.DCZDKSSYL_3N,
           A.DCZDKSSYL_5N   = B.DCZDKSSYL_5N,
           A.DCZDKSSYL_CLYL = B.DCZDKSSYL_CLYL,
           A.DCZDKSSYL_JNYL = B.DCZDKSSYL_JNYL,
           A.ZDLXKSCS_3Y    = B.ZDLXKSCS_3Y,
           A.ZDLXKSCS_6Y    = B.ZDLXKSCS_6Y,
           A.ZDLXKSCS_1N    = B.ZDLXKSCS_1N,
           A.ZDLXKSCS_3N    = B.ZDLXKSCS_3N,
           A.ZDLXKSCS_5N    = B.ZDLXKSCS_5N,
           A.ZDLXKSCS_CLYL  = B.ZDLXKSCS_CLYL,
           A.ZDLXKSCS_JNYL  = B.ZDLXKSCS_JNYL,
           A.KSPJSYL_3Y     = B.KSPJSYL_3Y,
           A.KSPJSYL_6Y     = B.KSPJSYL_6Y,
           A.KSPJSYL_1N     = B.KSPJSYL_1N,
           A.KSPJSYL_3N     = B.KSPJSYL_3N,
           A.KSPJSYL_5N     = B.KSPJSYL_5N,
           A.KSPJSYL_CLYL   = B.KSPJSYL_CLYL,
           A.KSPJSYL_JNYL   = B.KSPJSYL_JNYL
    
  
  WHEN NOT MATCHED THEN
    INSERT
      (A.RQ,
       A.CPID,
       A.JZRQ,
       A.JYRQ,
       A.DWJZ,
       A.NHBDL_3Y,
       A.NHBDL_6Y,
       A.NHBDL_1N,
       A.NHBDL_3N,
       A.NHBDL_5N,
       A.NHBDL_CLYL,
       A.NHBDL_JNYL,
       A.NHXXBDL_3Y,
       A.NHXXBDL_6Y,
       A.NHXXBDL_1N,
       A.NHXXBDL_3N,
       A.NHXXBDL_5N,
       A.NHXXBDL_CLYL,
       A.NHXXBDL_JNYL,
       A.ZDHC_3Y,
       A.ZDHC_6Y,
       A.ZDHC_1N,
       A.ZDHC_3N,
       A.ZDHC_5N,
       A.ZDHC_CLYL,
       A.ZDHC_JNYL,
       A.KSBL_3Y,
       A.KSBL_6Y,
       A.KSBL_1N,
       A.KSBL_3N,
       A.KSBL_5N,
       A.KSBL_CLYL,
       A.KSBL_JNYL,
       A.DCZDKSSYL_3Y,
       A.DCZDKSSYL_6Y,
       A.DCZDKSSYL_1N,
       A.DCZDKSSYL_3N,
       A.DCZDKSSYL_5N,
       A.DCZDKSSYL_CLYL,
       A.DCZDKSSYL_JNYL,
       A.ZDLXKSCS_3Y,
       A.ZDLXKSCS_6Y,
       A.ZDLXKSCS_1N,
       A.ZDLXKSCS_3N,
       A.ZDLXKSCS_5N,
       A.ZDLXKSCS_CLYL,
       A.ZDLXKSCS_JNYL,
       A.KSPJSYL_3Y,
       A.KSPJSYL_6Y,
       A.KSPJSYL_1N,
       A.KSPJSYL_3N,
       A.KSPJSYL_5N,
       A.KSPJSYL_CLYL,
       A.KSPJSYL_JNYL,
       A.CPDM)
    VALUES
      (B.RQ,
       B.CPID,
       B.JZRQ,
       B.JYRQ,
       B.DWJZ,
       B.NHBDL_3Y,
       B.NHBDL_6Y,
       B.NHBDL_1N,
       B.NHBDL_3N,
       B.NHBDL_5N,
       B.NHBDL_CLYL,
       B.NHBDL_JNYL,
       B.NHXXBDL_3Y,
       B.NHXXBDL_6Y,
       B.NHXXBDL_1N,
       B.NHXXBDL_3N,
       B.NHXXBDL_5N,
       B.NHXXBDL_CLYL,
       B.NHXXBDL_JNYL,
       B.ZDHC_3Y,
       B.ZDHC_6Y,
       B.ZDHC_1N,
       B.ZDHC_3N,
       B.ZDHC_5N,
       B.ZDHC_CLYL,
       B.ZDHC_JNYL,
       B.KSBL_3Y,
       B.KSBL_6Y,
       B.KSBL_1N,
       B.KSBL_3N,
       B.KSBL_5N,
       B.KSBL_CLYL,
       B.KSBL_JNYL,
       B.DCZDKSSYL_3Y,
       B.DCZDKSSYL_6Y,
       B.DCZDKSSYL_1N,
       B.DCZDKSSYL_3N,
       B.DCZDKSSYL_5N,
       B.DCZDKSSYL_CLYL,
       B.DCZDKSSYL_JNYL,
       B.ZDLXKSCS_3Y,
       B.ZDLXKSCS_6Y,
       B.ZDLXKSCS_1N,
       B.ZDLXKSCS_3N,
       B.ZDLXKSCS_5N,
       B.ZDLXKSCS_CLYL,
       B.ZDLXKSCS_JNYL,
       B.KSPJSYL_3Y,
       B.KSPJSYL_6Y,
       B.KSPJSYL_1N,
       B.KSPJSYL_3N,
       B.KSPJSYL_5N,
       B.KSPJSYL_CLYL,
       B.KSPJSYL_JNYL,
       I_CPDM);

  MERGE INTO DSC_STAT.TPIF_STAT_CP_FXTZHSY_HIS_CPZX A
  USING (SELECT * FROM DSC_STAT.TEMP_TPIF_STAT_CP_FXTZHSY) B
  ON (A.CPID = B.CPID AND A.RQ = B.RQ)
  WHEN MATCHED THEN
    UPDATE
       SET A.JZRQ       = B.JZRQ,
           A.JYRQ       = B.JYRQ,
           A.DWJZ       = B.DWJZ,
           A.XPBL_3Y    = B.XPBL_3Y,
           A.XPBL_6Y    = B.XPBL_6Y,
           A.XPBL_1N    = B.XPBL_1N,
           A.XPBL_3N    = B.XPBL_3N,
           A.XPBL_5N    = B.XPBL_5N,
           A.XPBL_CLYL  = B.XPBL_CLYL,
           A.XPBL_JNYL  = B.XPBL_JNYL,
           A.STNBL_3Y   = B.STNBL_3Y,
           A.STNBL_6Y   = B.STNBL_6Y,
           A.STNBL_1N   = B.STNBL_1N,
           A.STNBL_3N   = B.STNBL_3N,
           A.STNBL_5N   = B.STNBL_5N,
           A.STNBL_CLYL = B.STNBL_CLYL,
           A.STNBL_JNYL = B.STNBL_JNYL,
           A.KMBL_3Y    = B.KMBL_3Y,
           A.KMBL_6Y    = B.KMBL_6Y,
           A.KMBL_1N    = B.KMBL_1N,
           A.KMBL_3N    = B.KMBL_3N,
           A.KMBL_5N    = B.KMBL_5N,
           A.KMBL_CLYL  = B.KMBL_CLYL,
           A.KMBL_JNYL  = B.KMBL_JNYL
    
  
  WHEN NOT MATCHED THEN
    INSERT
      (A.CPID,
       A.RQ,
       A.JZRQ,
       A.JYRQ,
       A.DWJZ,
       A.XPBL_3Y,
       A.XPBL_6Y,
       A.XPBL_1N,
       A.XPBL_3N,
       A.XPBL_5N,
       A.XPBL_CLYL,
       A.XPBL_JNYL,
       A.STNBL_3Y,
       A.STNBL_6Y,
       A.STNBL_1N,
       A.STNBL_3N,
       A.STNBL_5N,
       A.STNBL_CLYL,
       A.STNBL_JNYL,
       A.KMBL_3Y,
       A.KMBL_6Y,
       A.KMBL_1N,
       A.KMBL_3N,
       A.KMBL_5N,
       A.KMBL_CLYL,
       A.KMBL_JNYL,
       A.CPDM)
    VALUES
      (B.CPID,
       B.RQ,
       B.JZRQ,
       B.JYRQ,
       B.DWJZ,
       B.XPBL_3Y,
       B.XPBL_6Y,
       B.XPBL_1N,
       B.XPBL_3N,
       B.XPBL_5N,
       B.XPBL_CLYL,
       B.XPBL_JNYL,
       B.STNBL_3Y,
       B.STNBL_6Y,
       B.STNBL_1N,
       B.STNBL_3N,
       B.STNBL_5N,
       B.STNBL_CLYL,
       B.STNBL_JNYL,
       B.KMBL_3Y,
       B.KMBL_6Y,
       B.KMBL_1N,
       B.KMBL_3N,
       B.KMBL_5N,
       B.KMBL_CLYL,
       B.KMBL_JNYL,
       I_CPDM);

  COMMIT;
  O_CODE := 1;
  O_NOTE := '产品净值分析指标-产品中心-数据清洗逻辑 执行成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '产品净值分析指标-产品中心-数据清洗逻辑,未知错误'
                ELSE
                 '产品净值分析指标-产品中心-数据清洗逻辑,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

