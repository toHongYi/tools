create PROCEDURE PRO_PIF_MBTJZB(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;8|校验有效性
                                               I_ID   IN INTEGER --操作ID
                                               ) IS
    /*
    **功能说明：模板条件指标管理
    **创建人：戴文生
    **创建日期：2014-12-09
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生     1.0.1     2014-12-09    创建
    **刘浪浪     1.0.2     2015-08-07    增加巡检
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_MBTJZB%ROWTYPE; --表单记录
    V_ID    NUMBER(8);
    V_NOTE  VARCHAR2(500);
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';

    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_MBTJZB WHERE ID = I_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_OBJ := NULL;
    END;

    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    IF I_OPER = 0 THEN
        --//:新增
        IF V_OBJ.ZBDM IS NULL THEN
            O_NOTE := '[指标代码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.ZBMC IS NULL THEN
            O_NOTE := '[指标名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.ZBLB IS NULL THEN
            O_NOTE := '[指标类别]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_MBTJZB WHERE ZBDM = V_OBJ.ZBDM;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[指标代码]为[' || V_OBJ.ZBDM || ']的记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_MBTJZB WHERE ZBMC = V_OBJ.ZBMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[指标名称]为[' || V_OBJ.ZBMC || ']的记录!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --//:修改
        IF V_OBJ.ZBDM IS NULL THEN
            O_NOTE := '[指标代码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.ZBMC IS NULL THEN
            O_NOTE := '[指标名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.ZBLB IS NULL THEN
            O_NOTE := '[指标类别]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_MBTJZB WHERE ZBDM = V_OBJ.ZBDM;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[指标代码]为[' || V_OBJ.ZBDM || ']的记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_MBTJZB WHERE ZBMC = V_OBJ.ZBMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[指标名称]为[' || V_OBJ.ZBMC || ']的记录!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --//:删除
        SELECT FUNC_PIF_JYSFYY('TPIF_MBTJZB', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前指标已存在引用记录!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_MBTJZB WHERE ID = I_ID;
    END IF;

    IF I_OPER = 8 THEN
        --校验有效性
        FOR CUR_ZB IN (SELECT ID, XX, SX FROM TPIF_MBTJZBQJ) LOOP
            IF CUR_ZB.XX > CUR_ZB.SX THEN
                O_NOTE := '指标区间中存在下限比上限要大的区间!';
            END IF;
        END LOOP;

        V_NOTE := O_NOTE;

        LIVEBOS.PNEXTID('TPIF_XJRZ', V_ID);
        IF V_NOTE IS NULL THEN
            V_NOTE := '巡检正常!';
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_008'
                           AND ROWNUM = 1),
                       '<font color=green>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        ELSE
            V_NOTE := '巡检异常:' || V_NOTE;
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_008'
                           AND ROWNUM = 1),
                       '<font color=red>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        END IF;
    END IF;

    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', 8, '校验有效性') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_MBTJZB;

/

