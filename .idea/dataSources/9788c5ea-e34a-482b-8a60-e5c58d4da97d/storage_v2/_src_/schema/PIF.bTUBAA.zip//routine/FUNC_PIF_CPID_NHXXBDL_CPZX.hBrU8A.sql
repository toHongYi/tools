create FUNCTION FUNC_PIF_CPID_NHXXBDL_CPZX(I_TJRQ IN NUMBER, --统计日期
                                                      I_KSRQ IN NUMBER, --回测开始时间
                                                      I_CPID IN NUMBER --产品ID
                                                      ) RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算年化下行波动率
  
      ----------------------------------------------------------
        操作人      版本号       时间                      操作
        WUJINFENG   1.0.0     2020/01/15                新增
  --------------------------------------------------------------------------------*/
  V_FC    NUMBER;
  V_NHBDL NUMBER;
  V_JSTS  NUMBER;
  /*V_PJZF   NUMBER;*/
  V_ZRLJJZ NUMBER;
  V_JYRQ   NUMBER;
  V_SQL    VARCHAR2(1000);
BEGIN
  --变量初始化
  V_FC   := 0;
  V_JSTS := 0;
  /*  --获取平均涨幅
  SELECT AVG(RZF)
    INTO V_PJZF
    FROM TEMP_TPIF_CPJZXX
   WHERE CPID = I_CPID
     AND JZRQ >= I_KSRQ
     AND JZRQ <= I_TJRQ;*/

  /*  --获取交易天数
  SELECT COUNT(*)
    INTO V_JSTS
    FROM LIVEBOS.TXTJYR
   WHERE ZRR = JYR
     AND JYR > I_KSRQ
     AND JYR <= I_TJRQ;*/

  --循环计算当前产品的方差
  FOR CUR_FC IN (SELECT CPID, JZRQ, RZF
                   FROM TEMP_TPIF_CPJZXX A
                  WHERE A.CPID = I_CPID
                    AND EXISTS (SELECT 1
                           FROM LIVEBOS.TXTJYR
                          WHERE ZRR = JYR
                            AND JYR = A.JZRQ
                            AND JYR >= I_KSRQ
                            AND JYR <= I_TJRQ)) LOOP
  
    V_JSTS := V_JSTS + 1;
  
    --计算方差之和
    V_FC := POWER(LEAST(CUR_FC.RZF, 0), 2) + NVL(V_FC, 0);
  
  END LOOP;

  --获取年化下行波动率
  IF V_JSTS = 1 THEN
    V_NHBDL := 0;
  ELSE
    V_NHBDL := ROUND(POWER(V_FC * (1 / (V_JSTS - 1)) * 243, 0.5) * 100, 6);
  END IF;

  RETURN V_NHBDL;

EXCEPTION
  WHEN OTHERS THEN
    V_SQL := SQLERRM;
    RETURN - 999;
END;
/

