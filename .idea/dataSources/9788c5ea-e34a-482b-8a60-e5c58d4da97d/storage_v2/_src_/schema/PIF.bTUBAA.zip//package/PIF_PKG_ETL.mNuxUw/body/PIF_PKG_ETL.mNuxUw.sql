create PACKAGE BODY PIF_PKG_ETL IS

  --采集程序主调度
  PROCEDURE PRO_PIF_ETL_MAIN(O_CODE OUT NUMBER,
                             O_NOTE OUT VARCHAR2,
                             I_BID  IN NUMBER) --采集表IDIS
   AS

    V_CODE     NUMBER;
    V_NOTE     VARCHAR2(1000);
    V_TBBZZDZ  NUMBER;
    V_SQL      VARCHAR2(20000);
    V_ROWCOUNT NUMBER;
    V_RZID     NUMBER;

  BEGIN

    FOR CUR_RW IN (SELECT *
                     FROM TPIF_SJCJJK A
                    WHERE A.ZT = 1
                      AND A.ID = NVL(I_BID, A.ID)
                    ORDER BY XH ASC) LOOP

      --1.获取同步标志最大值
      PIF.PIF_PKG_ETL.PRO_PIF_ETL_BEGIN(V_CODE,
                                        V_NOTE,
                                        V_TBBZZDZ,
                                        V_RZID,
                                        CUR_RW.ID);

      IF V_CODE < 0 THEN

        UPDATE TPIF_SJCJRZ A
           SET A.JSSJ = SYSDATE,
               A.SJL  = 0,
               A.ZT   = -1,
               A.BZ   = '获取同步标志最大值失败：' || V_NOTE
         WHERE A.ID = V_RZID;
        COMMIT;
        CONTINUE;
      END IF;

      --2.业务处理
      --参数说明：
      -- V1 ：  OUT   O_CODE
      -- V2 :   OUT   O_NOTE
      -- V3 :   OUT   O_ROWCOUNT
      -- V4 :   IN   O_TBBZZDZ 同步标志最大值,增量采集可能会用到
      V_SQL := 'BEGIN PIF.PIF_PKG_ETL.' || CUR_RW.YWCLLJ ||
               '(:V1,:V2,:V3,:V4); END;';

      EXECUTE IMMEDIATE V_SQL
        USING OUT V_CODE, OUT V_NOTE, OUT V_ROWCOUNT, IN V_TBBZZDZ;

      IF V_CODE < 0 THEN

        UPDATE TPIF_SJCJRZ A
           SET A.JSSJ = SYSDATE,
               A.SJL  = 0,
               A.ZT   = -1,
               A.BZ   = '执行业务处理失败：' || V_NOTE
         WHERE A.ID = V_RZID;
        COMMIT;
        CONTINUE;
      END IF;

      --3.更新同步标志最大值
      PIF.PIF_PKG_ETL.PRO_PIF_ETL_END(V_CODE, V_NOTE, CUR_RW.ID);

      --4.记录采集日志
      PIF.PIF_PKG_ETL.PRO_PIF_ETL_LOG(V_RZID,
                                      V_ROWCOUNT,
                                      (CASE WHEN V_CODE > 0 THEN 2 ELSE - 1 END),
                                      V_NOTE);

    END LOOP;

    O_CODE := 1;
    O_NOTE := '成功！';

  EXCEPTION
    WHEN OTHERS THEN
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
  END;

  /**
   --采集程序开始日志
   --1.KETTLE采集前获取同步标志最大值作为增量采集的标志
   --2.记录采集日志
  **/
  PROCEDURE PRO_PIF_ETL_BEGIN(O_CODE    OUT NUMBER,
                              O_NOTE    OUT VARCHAR2,
                              O_TBBZZDZ OUT NUMBER, --同步标志最大值
                              O_RZID    OUT NUMBER, --日志ID
                              I_BID     IN NUMBER --采集表ID
                              )

   IS
    V_TBBZZDZ NUMBER := NULL;
    V_TBBZLX  NUMBER;
    V_RZID    NUMBER;
    V_TBFS    NUMBER;
  BEGIN
    --1|数字;2|数字日期;3|日期格式
    SELECT TBBZLX, TBFS
      INTO V_TBBZLX, V_TBFS
      FROM TPIF_SJCJJK A
     WHERE ID = I_BID;
    IF V_TBFS = 1 THEN
      IF V_TBBZLX = 1 THEN
        SELECT NVL(TBBZZDZ, 0)
          INTO V_TBBZZDZ
          FROM TPIF_SJCJJK A
         WHERE ID = I_BID;
      ELSIF V_TBBZLX = 2 THEN
        SELECT NVL(TBBZZDZ, 19990101)
          INTO V_TBBZZDZ
          FROM TPIF_SJCJJK A
         WHERE ID = I_BID;
      ELSE
        SELECT NVL(TBBZZDZ, 19990101121212)
          INTO V_TBBZZDZ
          FROM TPIF_SJCJJK A
         WHERE ID = I_BID;
      END IF;
    END IF;
    --记录数据采集日志,标明数据采集状态为进行中
    SELECT SEQ_TPIF_SJCJRZ.NEXTVAL INTO V_RZID FROM DUAL;
    INSERT INTO TPIF_SJCJRZ
      (ID, CJYB, KSSJ, JSSJ, SJL, ZT, BZ)

    VALUES
      (V_RZID, I_BID, SYSDATE, NULL, 0, 1, NULL);

    O_TBBZZDZ := V_TBBZZDZ; --增量采集时用到
    O_RZID    := V_RZID; --日志ID
    O_CODE    := 1;
    O_NOTE    := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
  END;

  /**
   --采集程序结束日志
   --1.KETTLE采集结束时记录采集日志，更新同步标志最大值
   --2.执行增量采集后的业务处理逻辑
  **/
  PROCEDURE PRO_PIF_ETL_END(O_CODE OUT NUMBER,
                            O_NOTE OUT VARCHAR2,
                            I_BID  IN NUMBER --采集表ID
                            )

   IS

    V_TBBZZDZ NUMBER := NULL;
    V_TBBZLX  NUMBER;
    V_BDM     VARCHAR2(200);
    V_ZLTBBZ  VARCHAR2(200);
    V_SQL     VARCHAR2(20000);
    V_TBFS    NUMBER;
  BEGIN

    O_CODE := 1;
    O_NOTE := '成功！';

    SELECT ZLTBBZ, TBBZLX, BDM, TBFS, TBBZZDZ
      INTO V_ZLTBBZ, V_TBBZLX, V_BDM, V_TBFS, V_TBBZZDZ
      FROM TPIF_SJCJJK A
     WHERE ID = I_BID;

    --1.更新同步标志最大值:TBBZZDZ
    /*    IF V_YWCLLJ IS NOT NULL THEN
      IF V_TBBZLX = 3 THEN
        V_SQL := 'SELECT MAX(TO_CHAR(' || V_ZLTBBZ ||
                 ',''yyyymmddhh24miss'')) FROM PUSH.' || I_BDM || '_TMP';
      ELSE
        V_SQL := 'SELECT MAX(' || V_ZLTBBZ || ' ) FROM PUSH.' || I_BDM ||
                 '_TMP';
      END IF;
    ELSE*/
    IF V_TBFS = 1 THEN

      IF V_TBBZLX = 3 THEN
        V_SQL := 'SELECT MAX(TO_CHAR(' || V_ZLTBBZ ||
                 ',''yyyymmddhh24miss'')) FROM SRC_PIF.' || V_BDM ||
                 ' WHERE TO_CHAR(' || V_ZLTBBZ ||
                 ',''yyyymmddhh24miss'') >= ' || V_TBBZZDZ;
      ELSE
        V_SQL := 'SELECT MAX(' || V_ZLTBBZ || ' ) FROM SRC_PIF.' || V_BDM ||
                 ' WHERE ' || V_ZLTBBZ || ' >= ' || V_TBBZZDZ;
      END IF;
      EXECUTE IMMEDIATE V_SQL
        INTO V_TBBZZDZ;

    END IF;
    UPDATE TPIF_SJCJJK A
       SET A.TBBZZDZ = V_TBBZZDZ, A.ZJTBSJ = SYSDATE
     WHERE A.ID = I_BID;

    /* --2.执行业务处理
    IF V_YWCLLJ IS NOT NULL THEN

      \***************************执行过程调度。*************************
         参数说明：
          V1 ：  OUT   O_CODE
          V2 :   OUT   O_NOTE
          V3 :   OUT   O_ROWCOUNT

      **\
      V_SQL := 'BEGIN PIF.PIF_PKG_ETL.' || V_YWCLLJ ||
               '(:V1,:V2,:V3); END;';
      EXECUTE IMMEDIATE V_SQL
        USING OUT O_CODE, OUT O_NOTE, OUT V_ROWCOUNT;
    END IF;

    --3.记录人数据采集日志 TPIF_SJCJRZ
    PIF.PIF_PKG_ETL.PRO_PIF_ETL_LOG(V_ID,
                                    V_ROWCOUNT,
                                    (CASE WHEN O_CODE > 0 THEN 2 ELSE - 1 END),
                                    O_NOTE);*/

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;

  END;

  /**
   记录采集日志通用过程
  **/
  PROCEDURE PRO_PIF_ETL_LOG(I_RZID IN NUMBER, --ID
                            I_SJL  IN NUMBER,
                            I_ZT   IN NUMBER,
                            I_BZ   IN VARCHAR2) AS

  BEGIN

    UPDATE TPIF_SJCJRZ A
       SET A.JSSJ = SYSDATE, A.SJL = I_SJL, A.ZT = I_ZT, A.BZ = I_BZ
     WHERE A.ID = I_RZID;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;

  --柜台-产品代码设置采集逻辑
  PROCEDURE PRO_PRODCODE(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODCODE';
    INSERT INTO SRC_PIF.PRODCODE
      (PRODTA_NO,
       PROD_CODE,
       PROD_TYPE,
       PROD_NAME,
       PRODALIAS_NAME,
       PRODCOMPANY_NAME,
       PRODSPELL_CODE,
       PROD_STATUS,
       MONEY_TYPE,
       IPO_BEGIN_DATE,
       IPO_END_DATE,
       IPO_BEGIN_TIME,
       IPO_END_TIME,
       PRE_END_DATE,
       PRE_END_TIME,
       PROD_BEGIN_DATE,
       PROD_END_DATE,
       PROD_MIN_BALA,
       PROD_MAX_BALA,
       PROM_BEGIN_DATE,
       PROM_END_DATE,
       SUBCONF_ENDDATE,
       SUBCONF_ENDTIME,
       PROD_REAL_BALA,
       PROMFARE_RATE,
       PROM_SCALE,
       PRODRISK_LEVEL,
       ASSESS_LEVEL,
       ISSUE_PRICE,
       PAR_VALUE,
       PRODPRE_RATIO,
       PROD_SPONSOR,
       PROD_MANAGER,
       PROD_TRUSTEE,
       TRUSTEE_BANK,
       PRODSUB_RATE,
       MAX_SUBSCRIBE_NUM,
       EN_ENTRUST_WAY,
       PRODCODE_CTRLSTR,
       PROD_TERM,
       INVEST_TYPE,
       INCOME_TYPE,
       INTEREST_FREQ,
       SUB_UNIT,
       ISSUE_DATE,
       OPEN_SHARE,
       MAX_PDSHARE,
       PRECISIONS,
       MIN_SHARE,
       ALLOT_LIMITSHARE,
       ORG_LOWLIMIT_BALANCE,
       ORG_APPEND_BALANCE,
       MIN_SHARE2,
       ALLOT_LIMITSHARE2,
       ORG_LOWLIMIT_BALANCE2,
       ORG_APPEND_BALANCE2,
       REDEMPTION_UNIT,
       MAX_ALLOTRATIO,
       MINSIZE,
       REDEEM_USE_FLAG,
       PROD_BACK_N,
       EN_CHANGE_CODE,
       TRANS_LIMITSHARE,
       MIN_SUBSCRIBE_BALANCE,
       MAX_SUBSCRIBE_BALANCE,
       PROD_TYPE_ASS,
       SUM_SUB_BALANCE,
       PRODRELATIVE_CODE,
       MIN_MERGEAMOUNT,
       MIN_SPLITAMOUNT,
       NAV,
       PER_MYRIAD_INCOME,
       MIN_ASSET_NEED,
       SWITCH_UNIT,
       CURRENT_AMOUNT_LOW,
       CTRLSTR_USEFLAGS,
       CHARGE_TYPE,
       REDEEM_LIMITSHARE,
       DIVIDEND_WAY,
       YEAR_DAYS,
       INTEREST_END_DATE,
       MIN_TIMER_BALANCE,
       MAX_TIMER_BALANCE,
       PROD_INTERNAL_CODE,
       EN_SPLIT_CODE,
       PAY_OVERTIME,
       PROD_OPEN_DATE_STR,
       PROD_RATIO_STR,
       HUGE_RATIO,
       TOTAL_SHARE,
       TOTAL_ASSET,
       QUOTA_VALID_TERM,
       PRODCODE_TYPE,
       SUB_RISK_URL,
       PROD_INTEREST,
       PROD_PUT_PRICE,
       SEVEN_INCOME_RATIO,
       REBUY_PROP,
       NAV_TOTAL,
       MODIFY_TIME,
       EN_PAY_KIND,
       TRIAL_DAYS,
       PER_ONESUB_MAX_BALANCE,
       ORG_ONESUB_MAX_BALANCE,
       PER_ONEAPP_MAX_BALANCE,
       ORG_ONEAPP_MAX_BALANCE,
       PERHOLD_UP_LIMIT,
       ORGAN_SUB_UNIT,
       MAX_PERRED_SHARE,
       MAX_ORGRED_SHARE,
       MAX_PERAPP_BALANCE,
       MAX_ORGAPP_BALANCE,
       MIN_PERFAPP_BALANCE,
       MIN_ORGFAPP_BALANCE,
       COOLING_PERIOD,
       ECONTRACT_VERSION,
       MIN_SWITCH_IN_BALANCE,
       PRODCODE_KIND,
       INTEREST_BEGIN_DATE,
       PER_APP_UNIT,
       ORG_APP_UNIT,
       FAAFILING_STATUS,
       TRIAL_REORDER_MAX_TIME,
       MAX_DEFICIT_RATE,
       PRESELL_BEGIN_DATE,
       PRESELL_END_DATE,
       PRESELL_BEGIN_TIME,
       PRESELL_END_TIME,
       BUY_PROCESS,
       PROD_ELIG_CTRLSTR,
       EN_PROF_FLAG,
       ELIGPAPER_VERSION,
       LOW_CORP_RISK_LEVEL,
       EN_INTERNAL_CONDITION,
       ADD_DATE,
       PROD_INVEST_TERM,
       BANK_RISK_LEVEL,
       ORGHOLD_UP_LIMIT,
       FUND_DELI_DATE,
       EN_COMPANY_NO,
       PROD_CONVERT_STATUS,
       ORG_MAX_PDSHARE,
       MODIFY_DATETIME,
       ORG_SUM_SUB_BALANCE,
       TRANSMIT_MIN_AMOUNT,
       MARKET_VALUE_DOWN,
       MIN_PRODCASH_BALANCE,
       EN_ID_KIND,
       MAX_PERFSUB_BALANCE,
       MAX_ORGFSUB_BALANCE)
      SELECT PRODTA_NO,
             PROD_CODE,
             PROD_TYPE,
             PROD_NAME,
             PRODALIAS_NAME,
             PRODCOMPANY_NAME,
             PRODSPELL_CODE,
             PROD_STATUS,
             MONEY_TYPE,
             IPO_BEGIN_DATE,
             IPO_END_DATE,
             IPO_BEGIN_TIME,
             IPO_END_TIME,
             PRE_END_DATE,
             PRE_END_TIME,
             PROD_BEGIN_DATE,
             PROD_END_DATE,
             PROD_MIN_BALA,
             PROD_MAX_BALA,
             PROM_BEGIN_DATE,
             PROM_END_DATE,
             SUBCONF_ENDDATE,
             SUBCONF_ENDTIME,
             PROD_REAL_BALA,
             PROMFARE_RATE,
             PROM_SCALE,
             PRODRISK_LEVEL,
             ASSESS_LEVEL,
             ISSUE_PRICE,
             PAR_VALUE,
             PRODPRE_RATIO,
             PROD_SPONSOR,
             PROD_MANAGER,
             PROD_TRUSTEE,
             TRUSTEE_BANK,
             PRODSUB_RATE,
             MAX_SUBSCRIBE_NUM,
             EN_ENTRUST_WAY,
             PRODCODE_CTRLSTR,
             PROD_TERM,
             INVEST_TYPE,
             INCOME_TYPE,
             INTEREST_FREQ,
             SUB_UNIT,
             ISSUE_DATE,
             OPEN_SHARE,
             MAX_PDSHARE,
             PRECISIONS,
             MIN_SHARE,
             ALLOT_LIMITSHARE,
             ORG_LOWLIMIT_BALANCE,
             ORG_APPEND_BALANCE,
             MIN_SHARE2,
             ALLOT_LIMITSHARE2,
             ORG_LOWLIMIT_BALANCE2,
             ORG_APPEND_BALANCE2,
             REDEMPTION_UNIT,
             MAX_ALLOTRATIO,
             MINSIZE,
             REDEEM_USE_FLAG,
             PROD_BACK_N,
             EN_CHANGE_CODE,
             TRANS_LIMITSHARE,
             MIN_SUBSCRIBE_BALANCE,
             MAX_SUBSCRIBE_BALANCE,
             PROD_TYPE_ASS,
             SUM_SUB_BALANCE,
             PRODRELATIVE_CODE,
             MIN_MERGEAMOUNT,
             MIN_SPLITAMOUNT,
             NAV,
             PER_MYRIAD_INCOME,
             MIN_ASSET_NEED,
             SWITCH_UNIT,
             CURRENT_AMOUNT_LOW,
             CTRLSTR_USEFLAGS,
             CHARGE_TYPE,
             REDEEM_LIMITSHARE,
             DIVIDEND_WAY,
             YEAR_DAYS,
             INTEREST_END_DATE,
             MIN_TIMER_BALANCE,
             MAX_TIMER_BALANCE,
             PROD_INTERNAL_CODE,
             EN_SPLIT_CODE,
             PAY_OVERTIME,
             PROD_OPEN_DATE_STR,
             PROD_RATIO_STR,
             HUGE_RATIO,
             TOTAL_SHARE,
             TOTAL_ASSET,
             QUOTA_VALID_TERM,
             PRODCODE_TYPE,
             SUB_RISK_URL,
             PROD_INTEREST,
             PROD_PUT_PRICE,
             SEVEN_INCOME_RATIO,
             REBUY_PROP,
             NAV_TOTAL,
             MODIFY_TIME,
             EN_PAY_KIND,
             TRIAL_DAYS,
             PER_ONESUB_MAX_BALANCE,
             ORG_ONESUB_MAX_BALANCE,
             PER_ONEAPP_MAX_BALANCE,
             ORG_ONEAPP_MAX_BALANCE,
             PERHOLD_UP_LIMIT,
             ORGAN_SUB_UNIT,
             MAX_PERRED_SHARE,
             MAX_ORGRED_SHARE,
             MAX_PERAPP_BALANCE,
             MAX_ORGAPP_BALANCE,
             MIN_PERFAPP_BALANCE,
             MIN_ORGFAPP_BALANCE,
             COOLING_PERIOD,
             ECONTRACT_VERSION,
             MIN_SWITCH_IN_BALANCE,
             PRODCODE_KIND,
             INTEREST_BEGIN_DATE,
             PER_APP_UNIT,
             ORG_APP_UNIT,
             FAAFILING_STATUS,
             TRIAL_REORDER_MAX_TIME,
             MAX_DEFICIT_RATE,
             PRESELL_BEGIN_DATE,
             PRESELL_END_DATE,
             PRESELL_BEGIN_TIME,
             PRESELL_END_TIME,
             BUY_PROCESS,
             PROD_ELIG_CTRLSTR,
             EN_PROF_FLAG,
             ELIGPAPER_VERSION,
             LOW_CORP_RISK_LEVEL,
             EN_INTERNAL_CONDITION,
             ADD_DATE,
             PROD_INVEST_TERM,
             BANK_RISK_LEVEL,
             ORGHOLD_UP_LIMIT,
             FUND_DELI_DATE,
             EN_COMPANY_NO,
             PROD_CONVERT_STATUS,
             ORG_MAX_PDSHARE,
             MODIFY_DATETIME,
             ORG_SUM_SUB_BALANCE,
             TRANSMIT_MIN_AMOUNT,
             MARKET_VALUE_DOWN,
             MIN_PRODCASH_BALANCE,
             EN_ID_KIND,
             MAX_PERFSUB_BALANCE,
             MAX_ORGFSUB_BALANCE

        FROM HS_PROD.PRODCODE@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品业务设置
  PROCEDURE PRO_PRODALLOWBUSIN(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODALLOWBUSIN';
    INSERT INTO SRC_PIF.PRODALLOWBUSIN
      (PROD_CODE,
       PROD_TYPE,
       PROD_STATUS,
       EN_PRODBUSI_TYPE,
       PRODTA_NO,
       MODIFY_TIME,
       EN_BRANCH_NO)
      SELECT PROD_CODE,
             PROD_TYPE,
             PROD_STATUS,
             EN_PRODBUSI_TYPE,
             PRODTA_NO,
             MODIFY_TIME,
             EN_BRANCH_NO

        FROM HS_PROD.PRODALLOWBUSIN@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品额度设置
  PROCEDURE PRO_PRODCONTROL(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODCONTROL';
    INSERT INTO SRC_PIF.PRODCONTROL
      (PROD_CODE,
       ORGAN_FLAG,
       MAX_SUB_QUATO,
       MIN_SUB_QUATO,
       ENTRUST_WAY,
       MAX_SHARE,
       BUSINESS_FLAG,
       PRODTA_NO,
       PERSON_UP_LIMITED,
       UP_LIMITED,
       CURR_LIMITED,
       DATE_UP_LIMITED,
       MODIFY_TIME,
       BRANCH_NO,
       DAY_USED_QUOTA)
      SELECT PROD_CODE,
             ORGAN_FLAG,
             MAX_SUB_QUATO,
             MIN_SUB_QUATO,
             ENTRUST_WAY,
             MAX_SHARE,
             BUSINESS_FLAG,
             PRODTA_NO,
             PERSON_UP_LIMITED,
             UP_LIMITED,
             CURR_LIMITED,
             DATE_UP_LIMITED,
             MODIFY_TIME,
             BRANCH_NO,
             DAY_USED_QUOTA

        FROM HS_PROD.PRODCONTROL@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品延迟交收设置
  PROCEDURE PRO_PRODDELAYDATE(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODDELAYDATE';
    INSERT INTO SRC_PIF.PRODDELAYDATE
      (PRODTA_NO,
       PROD_CODE,
       DELAY_TYPE,
       BUSINESS_FLAG,
       FARE_TYPE,
       ALLOW_FLAG,
       DATE_COUNT,
       JS_DATE,
       RESERVE,
       PAY_KIND)
      SELECT PRODTA_NO,
             PROD_CODE,
             DELAY_TYPE,
             BUSINESS_FLAG,
             FARE_TYPE,
             ALLOW_FLAG,
             DATE_COUNT,
             JS_DATE,
             RESERVE,
             PAY_KIND

        FROM HS_PROD.PRODDELAYDATE@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品折扣设置
  PROCEDURE PRO_PRODDISCOUNT(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODDISCOUNT';
    INSERT INTO SRC_PIF.PRODDISCOUNT
      (PRODTA_NO,
       PROD_CODE,
       BRANCH_NO,
       FUND_ACCOUNT,
       ROOM_CODE,
       ENTRUST_WAY,
       BUSINESS_FLAG,
       BALANCE_STEP,
       DISCOUNT_TYPE,
       DISCOUNT_RATE,
       SWITCH_PROD_CODE,
       REMARK)
      SELECT PRODTA_NO,
             PROD_CODE,
             BRANCH_NO,
             FUND_ACCOUNT,
             ROOM_CODE,
             ENTRUST_WAY,
             BUSINESS_FLAG,
             BALANCE_STEP,
             DISCOUNT_TYPE,
             DISCOUNT_RATE,
             SWITCH_PROD_CODE,
             REMARK

        FROM HS_PROD.PRODDISCOUNT@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品限额设置
  PROCEDURE PRO_PRODQUOT(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODQUOT';
    INSERT INTO SRC_PIF.PRODQUOT
      (PROD_CODE,
       EN_ENTRUST_WAY,
       MAX_SUBSCRIBE_NUM,
       CURRENT_QUOTA,
       ENABLE_QUOTA,
       USED_SUBSCRIBE_NUM,
       BRANCH_NO,
       PRODBRANCH_ZONE,
       PRODTA_NO)
      SELECT PROD_CODE,
             EN_ENTRUST_WAY,
             MAX_SUBSCRIBE_NUM,
             CURRENT_QUOTA,
             ENABLE_QUOTA,
             USED_SUBSCRIBE_NUM,
             BRANCH_NO,
             PRODBRANCH_ZONE,
             PRODTA_NO

        FROM HS_PROD.PRODQUOT@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品报送代码设置
  PROCEDURE PRO_PRODSENDCODE(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODSENDCODE';
    INSERT INTO SRC_PIF.PRODSENDCODE
      (PROD_CODE,
       PROD_NAME,
       PRODTA_NO,
       TA_NAME,
       RELATIVE_CODE,
       FULL_STATNAME,
       CSRC_ASSIGN_NO)
      SELECT PROD_CODE,
             PROD_NAME,
             PRODTA_NO,
             TA_NAME,
             RELATIVE_CODE,
             FULL_STATNAME,
             CSRC_ASSIGN_NO

        FROM HS_PROD.PRODSENDCODE@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品TA
  PROCEDURE PRO_PRODARG(O_CODE     OUT NUMBER,
                        O_NOTE     OUT VARCHAR2,
                        O_ROWCOUNT OUT NUMBER,
                        I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODARG';
    INSERT INTO SRC_PIF.PRODARG
      (PRODTA_NO,
       TA_NAME,
       TA_SHORTNAME,
       TA_STATUS,
       AGENCY_NO,
       TA_CTRLSTR,
       INIT_DATE,
       PROD_TYPE,
       FBACK_DATE,
       BBACK_DATE,
       AGENCY_NAME,
       EN_COMPANY_NO)
      SELECT PRODTA_NO,
             TA_NAME,
             TA_SHORTNAME,
             TA_STATUS,
             AGENCY_NO,
             TA_CTRLSTR,
             INIT_DATE,
             PROD_TYPE,
             FBACK_DATE,
             BBACK_DATE,
             AGENCY_NAME,
             EN_COMPANY_NO

        FROM HS_PROD.PRODARG@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-产品控制串
  PROCEDURE PRO_PRODCONTRLSTRUSE(O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.PRODCONTRLSTRUSE';
    INSERT INTO SRC_PIF.PRODCONTRLSTRUSE
      (PROD_TYPE, CTRLSTR_USEFLAGS, PRODTA_NO)
      SELECT PROD_TYPE, CTRLSTR_USEFLAGS, PRODTA_NO

        FROM HS_PROD.PRODCONTRLSTRUSE@UF20;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  PROCEDURE PRO_PRODPRICE(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER) AS

    V_NAV_DATE NUMBER;

  BEGIN

    V_NAV_DATE := I_TBBZZDZ;
    IF V_NAV_DATE IS NULL THEN
      V_NAV_DATE := 19990101;
    END IF;

    DELETE FROM SRC_PIF.PRODPRICE A WHERE A.NAV_DATE > V_NAV_DATE;
    INSERT INTO SRC_PIF.PRODPRICE
      (PRODTA_NO,
       PROD_TYPE,
       PROD_CODE,
       INIT_DATE,
       ASSET_PRICE,
       MONEY_TYPE,
       RATE_PRICE,
       BUSINESS_BALANCE,
       NET_VALUE,
       TOTAL_SHARE,
       NAV_TOTAL,
       NAV_DATE,
       GOLD_RATE,
       LAST_PRICE)
      SELECT PRODTA_NO,
             PROD_TYPE,
             PROD_CODE,
             INIT_DATE,
             ASSET_PRICE,
             MONEY_TYPE,
             RATE_PRICE,
             BUSINESS_BALANCE,
             NET_VALUE,
             TOTAL_SHARE,
             NAV_TOTAL,
             NAV_DATE,
             GOLD_RATE,
             LAST_PRICE

        FROM HS_PROD.PRODPRICE@UF20
       WHERE NAV_DATE > V_NAV_DATE;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-客户表
  PROCEDURE PRO_CLIENT(O_CODE     OUT NUMBER,
                       O_NOTE     OUT VARCHAR2,
                       O_ROWCOUNT OUT NUMBER,
                       I_TBBZZDZ  IN NUMBER) AS

    V_OPEN_DATE NUMBER;

  BEGIN

    V_OPEN_DATE := I_TBBZZDZ;
    IF V_OPEN_DATE IS NULL THEN
      V_OPEN_DATE := 19900101;
    END IF;

    DELETE FROM SRC_PIF.CLIENT A WHERE A.OPEN_DATE > V_OPEN_DATE;
    INSERT INTO SRC_PIF.CLIENT
      (CLIENT_ID,
       BRANCH_NO,
       DEV_BRANCH_NO,
       CLIENT_CARD,
       CLIENT_NAME,
       FULL_NAME,
       CORP_CLIENT_GROUP,
       CORP_RISK_LEVEL,
       ASSET_LEVEL,
       CLIENT_GENDER,
       NATIONALITY,
       ORGAN_FLAG,
       ID_KIND,
       ID_NO,
       ID_BEGINDATE,
       ID_ENDDATE,
       OPEN_DATE,
       CANCEL_DATE,
       CONFIRM_DATE,
       CLIENT_STATUS,
       POSITION_STR,
       AML_RISK_LEVEL,
       CORP_BEGIN_DATE,
       CORP_END_DATE,
       CORP_RISK_TYPE,
       CORP_RISK_COMFIRM)
      SELECT CLIENT_ID,
             BRANCH_NO,
             DEV_BRANCH_NO,
             CLIENT_CARD,
             CLIENT_NAME,
             FULL_NAME,
             CORP_CLIENT_GROUP,
             CORP_RISK_LEVEL,
             ASSET_LEVEL,
             CLIENT_GENDER,
             NATIONALITY,
             ORGAN_FLAG,
             ID_KIND,
             ID_NO,
             ID_BEGINDATE,
             ID_ENDDATE,
             OPEN_DATE,
             CANCEL_DATE,
             CONFIRM_DATE,
             CLIENT_STATUS,
             POSITION_STR,
             AML_RISK_LEVEL,
             CORP_BEGIN_DATE,
             CORP_END_DATE,
             CORP_RISK_TYPE,
             CORP_RISK_COMFIRM

        FROM HS_ASSET.CLIENT@UF20
       WHERE OPEN_DATE > V_OPEN_DATE;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-证券理财交割流水
  PROCEDURE PRO_SECUMDELIVER(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER) AS

    V_CURR_DATE NUMBER;

  BEGIN

    V_CURR_DATE := I_TBBZZDZ;
    IF V_CURR_DATE IS NULL THEN
      V_CURR_DATE := 19990101;
    END IF;

    DELETE FROM SRC_PIF.SECUMDELIVER A WHERE A.CURR_DATE > V_CURR_DATE;
    INSERT INTO SRC_PIF.SECUMDELIVER
      (INIT_DATE,
       SERIAL_NO,
       CURR_DATE,
       CURR_TIME,
       OP_BRANCH_NO,
       OPERATOR_NO,
       OP_ENTRUST_WAY,
       BUSINESS_FLAG,
       BRANCH_NO,
       PRODBRANCH_ZONE,
       FUND_ACCOUNT,
       CLIENT_ID,
       SECUM_ACCOUNT,
       PRODTA_NO,
       ALLOT_NO,
       PROD_CODE,
       PROD_NAME,
       MONEY_TYPE,
       ENTRUST_BALANCE,
       ENTRUST_AMOUNT,
       POST_AMOUNT,
       BUSINESS_PRICE,
       RATIO_SX,
       TA_FARE,
       SALE_FARE,
       OTHER_FARE,
       INTEREST,
       INTEREST_TAX,
       DELIVER_FLAG,
       DIVID_RATIO,
       CHARGE_TYPE,
       PRODRISK_LEVEL,
       RISK_LEVEL,
       PRODRISK_FLAG,
       MATCH_FLAG,
       FROZEN_CAUSE,
       RETURN_CODE,
       RETURN_MSG,
       FAILED_CAUSE,
       POSITION_STR,
       FARE0,
       FARE1,
       FARE2,
       FARE3,
       FAREX,
       STANDARD_FARE0,
       EXCHANGE_FARE,
       FARE_REMARK,
       EXCHANGE_FARE0,
       EXCHANGE_FARE1,
       EXCHANGE_FARE2,
       EXCHANGE_FARE3,
       EXCHANGE_FARE4,
       EXCHANGE_FARE5,
       EXCHANGE_FARE6,
       EXCHANGE_FAREX,
       REBATE_BALANCE,
       BROKERAGE,
       NAV,
       ENTRUST_NO,
       ENTRUST_DATE,
       BUSINESS_AMOUNT,
       BUSINESS_BALANCE,
       BUSINESS_TIME,
       BUSINESS_TIMES,
       REAL_STATUS,
       FARE_SX,
       BANK_NO,
       TRANS_ACCOUNT,
       PRODCODE_TYPE,
       GOLD_GRAM,
       POST_BALANCE,
       DIVID_DATE,
       REGISTER_DATE,
       CORP_RISK_LEVEL,
       TA_SERIALNO,
       PRODCODE_KIND,
       BFARE_TOTAL_BALANCE)
      SELECT INIT_DATE,
             SERIAL_NO,
             CURR_DATE,
             CURR_TIME,
             OP_BRANCH_NO,
             OPERATOR_NO,
             OP_ENTRUST_WAY,
             BUSINESS_FLAG,
             BRANCH_NO,
             PRODBRANCH_ZONE,
             FUND_ACCOUNT,
             CLIENT_ID,
             SECUM_ACCOUNT,
             PRODTA_NO,
             ALLOT_NO,
             PROD_CODE,
             PROD_NAME,
             MONEY_TYPE,
             ENTRUST_BALANCE,
             ENTRUST_AMOUNT,
             POST_AMOUNT,
             BUSINESS_PRICE,
             RATIO_SX,
             TA_FARE,
             SALE_FARE,
             OTHER_FARE,
             INTEREST,
             INTEREST_TAX,
             DELIVER_FLAG,
             DIVID_RATIO,
             CHARGE_TYPE,
             PRODRISK_LEVEL,
             RISK_LEVEL,
             PRODRISK_FLAG,
             MATCH_FLAG,
             FROZEN_CAUSE,
             RETURN_CODE,
             RETURN_MSG,
             FAILED_CAUSE,
             POSITION_STR,
             FARE0,
             FARE1,
             FARE2,
             FARE3,
             FAREX,
             STANDARD_FARE0,
             EXCHANGE_FARE,
             FARE_REMARK,
             EXCHANGE_FARE0,
             EXCHANGE_FARE1,
             EXCHANGE_FARE2,
             EXCHANGE_FARE3,
             EXCHANGE_FARE4,
             EXCHANGE_FARE5,
             EXCHANGE_FARE6,
             EXCHANGE_FAREX,
             REBATE_BALANCE,
             BROKERAGE,
             NAV,
             ENTRUST_NO,
             ENTRUST_DATE,
             BUSINESS_AMOUNT,
             BUSINESS_BALANCE,
             BUSINESS_TIME,
             BUSINESS_TIMES,
             REAL_STATUS,
             FARE_SX,
             BANK_NO,
             TRANS_ACCOUNT,
             PRODCODE_TYPE,
             GOLD_GRAM,
             POST_BALANCE,
             DIVID_DATE,
             REGISTER_DATE,
             CORP_RISK_LEVEL,
             TA_SERIALNO,
             PRODCODE_KIND,
             BFARE_TOTAL_BALANCE

        FROM HS_ASSET.SECUMDELIVER@UF20
       WHERE CURR_DATE > V_CURR_DATE;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  --柜台-证券理财份额表
  PROCEDURE PRO_SECUMSHARE(O_CODE     OUT NUMBER,
                           O_NOTE     OUT VARCHAR2,
                           O_ROWCOUNT OUT NUMBER,
                           I_TBBZZDZ  IN NUMBER) AS

    V_BUY_DATE NUMBER;

  BEGIN

    V_BUY_DATE := I_TBBZZDZ;
    IF V_BUY_DATE IS NULL THEN
      V_BUY_DATE := 19990101;
    END IF;

    DELETE FROM SRC_PIF.SECUMSHARE A WHERE A.BUY_DATE > V_BUY_DATE;
    INSERT INTO SRC_PIF.SECUMSHARE
      (FUND_ACCOUNT,
       CLIENT_ID,
       PRODTA_NO,
       SECUM_ACCOUNT,
       BRANCH_NO,
       PROD_CODE,
       BUY_DATE,
       NET_NO,
       MONEY_TYPE,
       ALLOT_NO,
       BEGIN_AMOUNT,
       CURRENT_AMOUNT,
       FROZEN_AMOUNT,
       DIVIDEND_WAY,
       CHARGE_TYPE,
       SECUM_MARKET_VALUE,
       POSITION_STR,
       PROD_COST_PRICE,
       INVEST_AMOUNT,
       SUM_BUY_AMOUNT,
       SUM_BUY_BALANCE,
       SUM_SELL_AMOUNT,
       SUM_SELL_BALANCE,
       TRANS_ACCOUNT,
       CORRECT_AMOUNT)
      SELECT FUND_ACCOUNT,
             CLIENT_ID,
             PRODTA_NO,
             SECUM_ACCOUNT,
             BRANCH_NO,
             PROD_CODE,
             BUY_DATE,
             NET_NO,
             MONEY_TYPE,
             ALLOT_NO,
             BEGIN_AMOUNT,
             CURRENT_AMOUNT,
             FROZEN_AMOUNT,
             DIVIDEND_WAY,
             CHARGE_TYPE,
             SECUM_MARKET_VALUE,
             POSITION_STR,
             PROD_COST_PRICE,
             INVEST_AMOUNT,
             SUM_BUY_AMOUNT,
             SUM_BUY_BALANCE,
             SUM_SELL_AMOUNT,
             SUM_SELL_BALANCE,
             TRANS_ACCOUNT,
             CORRECT_AMOUNT

        FROM HS_ASSET.SECUMSHARE@UF20
       WHERE BUY_DATE > V_BUY_DATE;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  /**
   基金概况采集后处理逻辑
  **/
  PROCEDURE PRO_MF_FUNDARCHIVES(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.mf_fundarchives';

    INSERT INTO SRC_PIF.MF_FUNDARCHIVES
      (ID,
       INNERCODE,
       ESTABLISHMENTDATE,
       LISTEDDATE,
       DURATION,
       STARTDATE,
       EXPIREDATE,
       MANAGER,
       INVESTADVISORCODE,
       TRUSTEECODE,
       WARRANTOR,
       TYPE,
       INVESTMENTTYPE,
       INVESTSTYLE,
       FOUNDEDSIZE,
       INVESTORIENTATION,
       INVESTTARGET,
       PERFORMANCEBENCHMARK,
       PROFITDISTRIBUTIONRULE,
       INVESTFIELD,
       BRIEFINTRO,
       XGRQ,
       JSID,
       APPLYINGCODEFRONT,
       APPLYINGCODEBACK,
       GUARANTEEDPERIOD,
       RISKRETURNCHARACTER,
       LOWESTSUMSUBSCRIBING,
       LOWESTSUMREDEMPTION,
       LSFRDESCRIPTION,
       LOWESTSUMFORHOLDING,
       LSFHDESCRIPTION,
       FUNDNATURE,
       FUNDTYPECODE,
       FUNDTYPE,
       CARRYOVERDATE,
       CARRYOVERDATEREMARK,
       CARRYOVERTYPE,
       REGINSTCODE,
       SECURITYCODE,
       DELIVERYDAYS,
       RISKRETURNCODE,
       FLOATTYPE,
       CUSTODYMARKET,
       OPERATIONPERIOD,
       OPERATIONPDUNITCODE,
       OPERATIONPDUNITNAME,
       IFINITIATINGFUND,
       CLASSIFICATIONFUNDTYPE,
       AGRBENCHMKRATEOFSHAREA,
       AGRBENCHMKRATEOFSHAREANOTES,
       REGULARSHARECONVERSIONNOTES,
       NONREGULARSHARECONVERSIONNOTES,
       EXAPPLYINGMARKET,
       EXAPPLYINGCODE,
       EXAPPLYINGABBR,
       SHAREPROPERTIES,
       STCLEARINGDATE,
       ENCLEARINGDATE,
       LOWESTSUMSUBLL,
       LOWESTSUMPURLL,
       MAINCODE,
       EXPROFITDISTRI,
       OTCPROFITDISTRI,
       IFFOF,
       IFPENSIONTARGET,
       PRCONFIRMATIONDATE)
      SELECT ID,
             INNERCODE,
             ESTABLISHMENTDATE,
             LISTEDDATE,
             DURATION,
             STARTDATE,
             EXPIREDATE,
             MANAGER,
             INVESTADVISORCODE,
             TRUSTEECODE,
             WARRANTOR,
             TYPE,
             INVESTMENTTYPE,
             INVESTSTYLE,
             FOUNDEDSIZE,
             INVESTORIENTATION,
             INVESTTARGET,
             PERFORMANCEBENCHMARK,
             PROFITDISTRIBUTIONRULE,
             INVESTFIELD,
             BRIEFINTRO,
             XGRQ,
             JSID,
             APPLYINGCODEFRONT,
             APPLYINGCODEBACK,
             GUARANTEEDPERIOD,
             RISKRETURNCHARACTER,
             LOWESTSUMSUBSCRIBING,
             LOWESTSUMREDEMPTION,
             LSFRDESCRIPTION,
             LOWESTSUMFORHOLDING,
             LSFHDESCRIPTION,
             FUNDNATURE,
             FUNDTYPECODE,
             FUNDTYPE,
             CARRYOVERDATE,
             CARRYOVERDATEREMARK,
             CARRYOVERTYPE,
             REGINSTCODE,
             SECURITYCODE,
             DELIVERYDAYS,
             RISKRETURNCODE,
             FLOATTYPE,
             CUSTODYMARKET,
             OPERATIONPERIOD,
             OPERATIONPDUNITCODE,
             OPERATIONPDUNITNAME,
             IFINITIATINGFUND,
             CLASSIFICATIONFUNDTYPE,
             AGRBENCHMKRATEOFSHAREA,
             AGRBENCHMKRATEOFSHAREANOTES,
             REGULARSHARECONVERSIONNOTES,
             NONREGULARSHARECONVERSIONNOTES,
             EXAPPLYINGMARKET,
             EXAPPLYINGCODE,
             EXAPPLYINGABBR,
             SHAREPROPERTIES,
             STCLEARINGDATE,
             ENCLEARINGDATE,
             LOWESTSUMSUBLL,
             LOWESTSUMPURLL,
             MAINCODE,
             EXPROFITDISTRI,
             OTCPROFITDISTRI,
             IFFOF,
             IFPENSIONTARGET,
             PRCONFIRMATIONDATE
        FROM JYDB.MF_FUNDARCHIVES@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;

  END;

  PROCEDURE PRO_MF_FUNDARCHIVESATTACH(O_CODE     OUT NUMBER,
                                      O_NOTE     OUT VARCHAR2,
                                      O_ROWCOUNT OUT NUMBER,
                                      I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_FUNDARCHIVESATTACH';

    INSERT INTO SRC_PIF.MF_FUNDARCHIVESATTACH
      (

       ID,
       INNERCODE,
       COMPANYCODE,
       INFOSOURCE,
       TYPECODE,
       TYPENAME,
       DATACODE,
       DATANAME,
       STARTDATE,
       ENDDATE,
       REMARK,
       UPDATETIME,
       JSID,
       DATAVALUE)
      SELECT ID,
             INNERCODE,
             COMPANYCODE,
             INFOSOURCE,
             TYPECODE,
             TYPENAME,
             DATACODE,
             DATANAME,
             STARTDATE,
             ENDDATE,
             REMARK,
             UPDATETIME,
             JSID,
             DATAVALUE
        FROM JYDB.MF_FUNDARCHIVESATTACH@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  --基金发行与上市
  PROCEDURE PRO_MF_ISSUEANDLISTING(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_ISSUEANDLISTING';
    INSERT INTO SRC_PIF.MF_ISSUEANDLISTING
      (ID,
       INNERCODE,
       INITIALINFOPUBLDATE,
       PROSPECTUSISSUEDDATE,
       LISTANNOUNCEMENTISSUEDATE,
       FUNDRAISINGMETHOD,
       FUNDTYPE,
       ISSUEOBJECT,
       ISSUESTARTDATE,
       ISSUEENDDATE,
       PARVALUE,
       UNITISSUEPRICE,
       UNITISSUEFEE,
       SHAREISSUED,
       INITIATORSUBSCRIBEVOLUME,
       INITIATORHOLDFLOATSHARES,
       INITIATORHOLDTERM,
       MINIINITIATORHOLDINGRATIO,
       FINSTITUTIONQUOTA,
       PUBLICOFFERSHARES,
       GENERALLEGALPERSONQUOTA,
       ABBRNAMEFORAPPLYING,
       APPLYINGCODE,
       APPLYINGUNIT,
       MINIMUMAPPLYING,
       MAXIMUMAPPLYING,
       APPLYINGTIMES,
       VALIDLAPPLYINGACCOUNTS,
       VALIDAPPLYINGVOL,
       OVERAPPLYINGMULTIPLES,
       FREEZEFUNDS,
       HITRATIO,
       LISTEDDATE,
       LISTEDPLACE,
       OUTSTANDINGSHARES,
       FIRSTDAYOPENPRICE,
       FIRSTDAYCOLSEPRICE,
       FIRSTDAYTURNOVERRATIO,
       ESTABLISHMENTDATE,
       APPLYOPENINGDATE,
       REDEEMOPENINGDATE,
       XGRQ,
       JSID,
       CURRENCYCODE,
       CURRENCYSTYLE,
       ISSUESTATE,
       ISSUECANCELDATE,
       ORGISSUESTARTDATE,
       ORGISSUEENDDATE,
       INITIALPARVALUE)
      SELECT ID,
             INNERCODE,
             INITIALINFOPUBLDATE,
             PROSPECTUSISSUEDDATE,
             LISTANNOUNCEMENTISSUEDATE,
             FUNDRAISINGMETHOD,
             FUNDTYPE,
             ISSUEOBJECT,
             ISSUESTARTDATE,
             ISSUEENDDATE,
             PARVALUE,
             UNITISSUEPRICE,
             UNITISSUEFEE,
             SHAREISSUED,
             INITIATORSUBSCRIBEVOLUME,
             INITIATORHOLDFLOATSHARES,
             INITIATORHOLDTERM,
             MINIINITIATORHOLDINGRATIO,
             FINSTITUTIONQUOTA,
             PUBLICOFFERSHARES,
             GENERALLEGALPERSONQUOTA,
             ABBRNAMEFORAPPLYING,
             APPLYINGCODE,
             APPLYINGUNIT,
             MINIMUMAPPLYING,
             MAXIMUMAPPLYING,
             APPLYINGTIMES,
             VALIDLAPPLYINGACCOUNTS,
             VALIDAPPLYINGVOL,
             OVERAPPLYINGMULTIPLES,
             FREEZEFUNDS,
             HITRATIO,
             LISTEDDATE,
             LISTEDPLACE,
             OUTSTANDINGSHARES,
             FIRSTDAYOPENPRICE,
             FIRSTDAYCOLSEPRICE,
             FIRSTDAYTURNOVERRATIO,
             ESTABLISHMENTDATE,
             APPLYOPENINGDATE,
             REDEEMOPENINGDATE,
             XGRQ,
             JSID,
             CURRENCYCODE,
             CURRENCYSTYLE,
             ISSUESTATE,
             ISSUECANCELDATE,
             ORGISSUESTARTDATE,
             ORGISSUEENDDATE,
             INITIALPARVALUE
        FROM JYDB.MF_ISSUEANDLISTING@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金分红
  PROCEDURE PRO_MF_DIVIDEND(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_DIVIDEND';
    INSERT INTO SRC_PIF.MF_DIVIDEND
      (ID,
       INNERCODE,
       INFOPUBLDATE,
       INFOSOURCE,
       ENDDATE,
       UNITPROFIT,
       UNITRETAINEDPROFIT,
       IFDISTRIBUTED,
       DIVIDENDRATIOBEFORETAX,
       ACTUALRATIOAFTERTAX,
       DIVIDENDSUM,
       REDATE,
       EXRIGHTDATE,
       EXECUTEDATE,
       SCHEMEMODIFICATION,
       XGRQ,
       JSID,
       REINVESTDAY,
       ACCOUNTDAY,
       REDEMPTIONDAY,
       UNITPROFITYTD,
       DIVIDENDSUMYTD,
       DIVIDENDTIMESYTD,
       DIVISUMSINCEINCEPTION,
       DIVITIMESSINCEINCEPION,
       EVENTPROCEDURECODE,
       EVENTPROCEDURE,
       EXRIGHTDATEEX,
       EXRIGHTDATECURBEX,
       EXECUTEDATEEX,
       EXECUTEDATECURBEX,
       DISTRIBUTABLEPROFITS,
       ALLOCATIONVALUE)
      SELECT ID,
             INNERCODE,
             INFOPUBLDATE,
             INFOSOURCE,
             ENDDATE,
             UNITPROFIT,
             UNITRETAINEDPROFIT,
             IFDISTRIBUTED,
             DIVIDENDRATIOBEFORETAX,
             ACTUALRATIOAFTERTAX,
             DIVIDENDSUM,
             REDATE,
             EXRIGHTDATE,
             EXECUTEDATE,
             SCHEMEMODIFICATION,
             XGRQ,
             JSID,
             REINVESTDAY,
             ACCOUNTDAY,
             REDEMPTIONDAY,
             UNITPROFITYTD,
             DIVIDENDSUMYTD,
             DIVIDENDTIMESYTD,
             DIVISUMSINCEINCEPTION,
             DIVITIMESSINCEINCEPION,
             EVENTPROCEDURECODE,
             EVENTPROCEDURE,
             EXRIGHTDATEEX,
             EXRIGHTDATECURBEX,
             EXECUTEDATEEX,
             EXECUTEDATECURBEX,
             DISTRIBUTABLEPROFITS,
             ALLOCATIONVALUE
        FROM JYDB.MF_DIVIDEND@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金管理人主要人员介绍
  PROCEDURE PRO_MF_ADVISORPERSONNEL(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_ADVISORPERSONNEL';
    INSERT INTO SRC_PIF.MF_ADVISORPERSONNEL
      (ID,
       INVESTADVISORCODE,
       INFOPUBLDATE,
       INFOSOURCE,
       MEDIA,
       NAME,
       GENDER,
       BIRTHDATE,
       EDUCATIONLEVEL,
       ACCESSIONDATE,
       DIMISSIONDATE,
       BACKGROUND,
       INCUMBENT,
       NOTES,
       XGRQ,
       JSID)
      SELECT ID,
             INVESTADVISORCODE,
             INFOPUBLDATE,
             INFOSOURCE,
             MEDIA,
             NAME,
             GENDER,
             BIRTHDATE,
             EDUCATIONLEVEL,
             ACCESSIONDATE,
             DIMISSIONDATE,
             BACKGROUND,
             INCUMBENT,
             NOTES,
             XGRQ,
             JSID
        FROM JYDB.MF_ADVISORPERSONNEL@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金管理人概况
  PROCEDURE PRO_MF_INVESTADVISOROUTLINE(O_CODE     OUT NUMBER,
                                        O_NOTE     OUT VARCHAR2,
                                        O_ROWCOUNT OUT NUMBER,
                                        I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_INVESTADVISOROUTLINE';
    INSERT INTO SRC_PIF.MF_INVESTADVISOROUTLINE
      (ID,
       INVESTADVISORCODE,
       INVESTADVISORNAME,
       INVESTADVISORABBRNAME,
       LEGALREPR,
       GENERALMANAGER,
       ESTABLISHMENTDATE,
       ORGANIZATIONFORM,
       REGCAPITAL,
       REGADDR,
       OFFICEADDR,
       ZIPCODE,
       EMAIL,
       CONTACTADDR,
       TEL,
       FAX,
       WEBSITE,
       LINKMAN,
       BACKGROUND,
       REGION,
       XGRQ,
       JSID,
       SERVICELINE,
       MATURITYENDDATE,
       TACODE,
       CSRCCODE)
      SELECT ID,
             INVESTADVISORCODE,
             INVESTADVISORNAME,
             INVESTADVISORABBRNAME,
             LEGALREPR,
             GENERALMANAGER,
             ESTABLISHMENTDATE,
             ORGANIZATIONFORM,
             REGCAPITAL,
             REGADDR,
             OFFICEADDR,
             ZIPCODE,
             EMAIL,
             CONTACTADDR,
             TEL,
             FAX,
             WEBSITE,
             LINKMAN,
             BACKGROUND,
             REGION,
             XGRQ,
             JSID,
             SERVICELINE,
             MATURITYENDDATE,
             TACODE,
             CSRCCODE
        FROM JYDB.MF_INVESTADVISOROUTLINE@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --公募基金经理基本资料
  PROCEDURE PRO_MF_PERSONALINFO(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.MF_PERSONALINFO M
    USING (SELECT ID,
                  PERSONALCODE,
                  CHINESENAME,
                  OTHERNAME,
                  ENGLISHNAME,
                  GENDER,
                  NATIONALITY,
                  BIRTHDATE,
                  BIRTHYMINFO,
                  EDUCATION,
                  IDCARDNUM,
                  PASSPORTNUM,
                  PRACTICEDATE,
                  EXPERIENCETIME,
                  PROQUALIFI,
                  BACKGROUND,
                  PERSONALDATA,
                  FILETYPE,
                  UPDATETIME,
                  JSID
             FROM JYDB.MF_PERSONALINFO@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.PERSONALCODE   = N.PERSONALCODE,
             M.CHINESENAME    = N.CHINESENAME,
             M.OTHERNAME      = N.OTHERNAME,
             M.ENGLISHNAME    = N.ENGLISHNAME,
             M.GENDER         = N.GENDER,
             M.NATIONALITY    = N.NATIONALITY,
             M.BIRTHDATE      = N.BIRTHDATE,
             M.BIRTHYMINFO    = N.BIRTHYMINFO,
             M.EDUCATION      = N.EDUCATION,
             M.IDCARDNUM      = N.IDCARDNUM,
             M.PASSPORTNUM    = N.PASSPORTNUM,
             M.PRACTICEDATE   = N.PRACTICEDATE,
             M.EXPERIENCETIME = N.EXPERIENCETIME,
             M.PROQUALIFI     = N.PROQUALIFI,
             M.BACKGROUND     = N.BACKGROUND,
             --M.PERSONALDATA = N.PERSONALDATA,
             M.FILETYPE   = N.FILETYPE,
             M.UPDATETIME = N.UPDATETIME,
             M.JSID       = N.JSID
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         PERSONALCODE,
         CHINESENAME,
         OTHERNAME,
         ENGLISHNAME,
         GENDER,
         NATIONALITY,
         BIRTHDATE,
         BIRTHYMINFO,
         EDUCATION,
         IDCARDNUM,
         PASSPORTNUM,
         PRACTICEDATE,
         EXPERIENCETIME,
         PROQUALIFI,
         BACKGROUND,
         PERSONALDATA,
         FILETYPE,
         UPDATETIME,
         JSID)
      VALUES
        (N.ID,
         N.PERSONALCODE,
         N.CHINESENAME,
         N.OTHERNAME,
         N.ENGLISHNAME,
         N.GENDER,
         N.NATIONALITY,
         N.BIRTHDATE,
         N.BIRTHYMINFO,
         N.EDUCATION,
         N.IDCARDNUM,
         N.PASSPORTNUM,
         N.PRACTICEDATE,
         N.EXPERIENCETIME,
         N.PROQUALIFI,
         N.BACKGROUND,
         N.PERSONALDATA,
         N.FILETYPE,
         N.UPDATETIME,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --公募基金经理(新)
  PROCEDURE PRO_MF_FUNDMANAGERNEW(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_FUNDMANAGERNEW';
    INSERT INTO SRC_PIF.MF_FUNDMANAGERNEW
      (ID,
       INNERCODE,
       INFOPUBLDATE,
       INFOSOURCE,
       PERSONALCODE,
       NAME,
       POSTNAME,
       INCUMBENT,
       ACCESSIONDATE,
       DIMISSIONDATE,
       MANAGEMENTTIME,
       PERFORMANCE,
       NOTES,
       UPDATETIME,
       JSID)
      SELECT ID,
             INNERCODE,
             INFOPUBLDATE,
             INFOSOURCE,
             PERSONALCODE,
             NAME,
             POSTNAME,
             INCUMBENT,
             ACCESSIONDATE,
             DIMISSIONDATE,
             MANAGEMENTTIME,
             PERFORMANCE,
             NOTES,
             UPDATETIME,
             JSID
        FROM JYDB.MF_FUNDMANAGERNEW@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --公募基金费率(新)
  PROCEDURE PRO_MF_CHARGERATENEW(O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.MF_CHARGERATENEW M
    USING (SELECT ID,
                  INNERCODE,
                  INFOPUBLDATE,
                  INFOSOURCE,
                  IFEXECUTED,
                  EXCUTEDATE,
                  CANCELDATE,
                  CHARGERATETYPE,
                  CHARGERATETYDES,
                  CHARGERATECUR,
                  CLIENTTYPE,
                  SHIFTINTARGET,
                  MINCHARGERATE,
                  MAXCHARGERATE,
                  FLOCHARGERATE,
                  CHARGERATEUNIT,
                  CHARGERATEDES,
                  CHARGERATEDIV,
                  DIVSTAND1,
                  DIVSTANDUNIT1,
                  STDIVSTAND1,
                  ENDIVSTAND1,
                  IFAPPLYSTART1,
                  IFAPPLYEND1,
                  DIVSTAND2,
                  DIVSTANDUNIT2,
                  STDIVSTAND2,
                  ENDIVSTAND2,
                  IFAPPLYSTART2,
                  IFAPPLYEND2,
                  DIVSTAND3,
                  DIVSTANDUNIT3,
                  STDIVSTAND3,
                  ENDIVSTAND3,
                  IFAPPLYSTART3,
                  IFAPPLYEND3,
                  NOTES,
                  XGRQ,
                  JSID,
                  DIVINTERVALDES
             FROM JYDB.MF_CHARGERATENEW@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE       = N.INNERCODE,
             M.INFOPUBLDATE    = N.INFOPUBLDATE,
             M.INFOSOURCE      = N.INFOSOURCE,
             M.IFEXECUTED      = N.IFEXECUTED,
             M.EXCUTEDATE      = N.EXCUTEDATE,
             M.CANCELDATE      = N.CANCELDATE,
             M.CHARGERATETYPE  = N.CHARGERATETYPE,
             M.CHARGERATETYDES = N.CHARGERATETYDES,
             M.CHARGERATECUR   = N.CHARGERATECUR,
             M.CLIENTTYPE      = N.CLIENTTYPE,
             M.SHIFTINTARGET   = N.SHIFTINTARGET,
             M.MINCHARGERATE   = N.MINCHARGERATE,
             M.MAXCHARGERATE   = N.MAXCHARGERATE,
             M.FLOCHARGERATE   = N.FLOCHARGERATE,
             M.CHARGERATEUNIT  = N.CHARGERATEUNIT,
             M.CHARGERATEDES   = N.CHARGERATEDES,
             M.CHARGERATEDIV   = N.CHARGERATEDIV,
             M.DIVSTAND1       = N.DIVSTAND1,
             M.DIVSTANDUNIT1   = N.DIVSTANDUNIT1,
             M.STDIVSTAND1     = N.STDIVSTAND1,
             M.ENDIVSTAND1     = N.ENDIVSTAND1,
             M.IFAPPLYSTART1   = N.IFAPPLYSTART1,
             M.IFAPPLYEND1     = N.IFAPPLYEND1,
             M.NOTES           = N.NOTES,
             M.XGRQ            = N.XGRQ,
             M.JSID            = N.JSID,
             M.DIVINTERVALDES  = N.DIVINTERVALDES
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         INFOPUBLDATE,
         INFOSOURCE,
         IFEXECUTED,
         EXCUTEDATE,
         CANCELDATE,
         CHARGERATETYPE,
         CHARGERATETYDES,
         CHARGERATECUR,
         CLIENTTYPE,
         SHIFTINTARGET,
         MINCHARGERATE,
         MAXCHARGERATE,
         FLOCHARGERATE,
         CHARGERATEUNIT,
         CHARGERATEDES,
         CHARGERATEDIV,
         DIVSTAND1,
         DIVSTANDUNIT1,
         STDIVSTAND1,
         ENDIVSTAND1,
         IFAPPLYSTART1,
         IFAPPLYEND1,
         DIVSTAND2,
         DIVSTANDUNIT2,
         STDIVSTAND2,
         ENDIVSTAND2,
         IFAPPLYSTART2,
         IFAPPLYEND2,
         DIVSTAND3,
         DIVSTANDUNIT3,
         STDIVSTAND3,
         ENDIVSTAND3,
         IFAPPLYSTART3,
         IFAPPLYEND3,
         NOTES,
         XGRQ,
         JSID,
         DIVINTERVALDES)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.INFOPUBLDATE,
         N.INFOSOURCE,
         N.IFEXECUTED,
         N.EXCUTEDATE,
         N.CANCELDATE,
         N.CHARGERATETYPE,
         N.CHARGERATETYDES,
         N.CHARGERATECUR,
         N.CLIENTTYPE,
         N.SHIFTINTARGET,
         N.MINCHARGERATE,
         N.MAXCHARGERATE,
         N.FLOCHARGERATE,
         N.CHARGERATEUNIT,
         N.CHARGERATEDES,
         N.CHARGERATEDIV,
         N.DIVSTAND1,
         N.DIVSTANDUNIT1,
         N.STDIVSTAND1,
         N.ENDIVSTAND1,
         N.IFAPPLYSTART1,
         N.IFAPPLYEND1,
         N.DIVSTAND2,
         N.DIVSTANDUNIT2,
         N.STDIVSTAND2,
         N.ENDIVSTAND2,
         N.IFAPPLYSTART2,
         N.IFAPPLYEND2,
         N.DIVSTAND3,
         N.DIVSTANDUNIT3,
         N.STDIVSTAND3,
         N.ENDIVSTAND3,
         N.IFAPPLYSTART3,
         N.IFAPPLYEND3,
         N.NOTES,
         N.XGRQ,
         N.JSID,
         N.DIVINTERVALDES);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --系统常量表（数据字典）
  PROCEDURE PRO_CT_SYSTEMCONST(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.CT_SYSTEMCONST';
    INSERT INTO SRC_PIF.CT_SYSTEMCONST
      (ID, LB, LBMC, MS, DM, XGRQ, JSID, FVALUE, IVALUE, DVALUE, CVALUE)
      SELECT ID,
             LB,
             LBMC,
             MS,
             DM,
             XGRQ,
             JSID,
             FVALUE,
             IVALUE,
             DVALUE,
             CVALUE
        FROM JYDB.CT_SYSTEMCONST@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --行业表
  PROCEDURE PRO_CT_INDUSTRY(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.CT_INDUSTRY';
    INSERT INTO SRC_PIF.CT_INDUSTRY
      (ID,
       INDUSTRYNUM,
       INDUSTRYNAME,
       INDUSTRYCODE,
       INDUSTRYPLATE,
       XGRQ,
       JSID)
      SELECT ID,
             INDUSTRYNUM,
             INDUSTRYNAME,
             INDUSTRYCODE,
             INDUSTRYPLATE,
             XGRQ,
             JSID
        FROM JYDB.CT_INDUSTRY@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金拆分折算
  PROCEDURE PRO_MF_SHARESSPLIT(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_SHARESSPLIT';
    INSERT INTO SRC_PIF.MF_SHARESSPLIT
      (ID,
       INNERCODE,
       INFOPUBLDATE,
       INFOSOURCE,
       INFOTYPE,
       SPLITDAY,
       SPLITRATIO,
       OUTCOMENOTICEISSUEDATE,
       CHANGEREGDATE,
       NV,
       SHARESBEFORE,
       SHARESAFTER,
       UNITNVBEFORE,
       UNITNVAFTER,
       ACCUMULATEDUNITNVBEFORE,
       ACCUMULATEDUNITNVAFTER,
       XGRQ,
       JSID,
       INNERCODEADD,
       SPLITRATIOADD,
       SHARESADD,
       SHARESADDCOMBINE,
       REMARK,
       ESSPLITRATIO,
       SPLITTYPE,
       ACTUALSPLITDAY,
       AFSPLITRATIO)
      SELECT ID,
             INNERCODE,
             INFOPUBLDATE,
             INFOSOURCE,
             INFOTYPE,
             SPLITDAY,
             SPLITRATIO,
             OUTCOMENOTICEISSUEDATE,
             CHANGEREGDATE,
             NV,
             SHARESBEFORE,
             SHARESAFTER,
             UNITNVBEFORE,
             UNITNVAFTER,
             ACCUMULATEDUNITNVBEFORE,
             ACCUMULATEDUNITNVAFTER,
             XGRQ,
             JSID,
             INNERCODEADD,
             SPLITRATIOADD,
             SHARESADD,
             SHARESADDCOMBINE,
             REMARK,
             ESSPLITRATIO,
             SPLITTYPE,
             ACTUALSPLITDAY,
             AFSPLITRATIO
        FROM JYDB.MF_SHARESSPLIT@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金托管人概况
  PROCEDURE PRO_MF_TRUSTEEOUTLINE(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_TRUSTEEOUTLINE';
    INSERT INTO SRC_PIF.MF_TRUSTEEOUTLINE
      (ID,
       TRUSTEECODE,
       TRUSTEENAME,
       LEGALREPR,
       TRUSTEEFUNCTIONARY,
       LINKMAN,
       ESTABLISHMENTDATE,
       ORGANIZATIONFORM,
       REGCAPITAL,
       REGADDR,
       OFFICEADDR,
       ZIPCODE,
       WEBSITE,
       EMAIL,
       CONTACTADDR,
       TEL,
       FAX,
       BACKGROUND,
       XGRQ,
       JSID)
      SELECT ID,
             TRUSTEECODE,
             TRUSTEENAME,
             LEGALREPR,
             TRUSTEEFUNCTIONARY,
             LINKMAN,
             ESTABLISHMENTDATE,
             ORGANIZATIONFORM,
             REGCAPITAL,
             REGADDR,
             OFFICEADDR,
             ZIPCODE,
             WEBSITE,
             EMAIL,
             CONTACTADDR,
             TEL,
             FAX,
             BACKGROUND,
             XGRQ,
             JSID
        FROM JYDB.MF_TRUSTEEOUTLINE@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金托管人主要人员介绍
  PROCEDURE PRO_MF_TRUSTEEPERSONNEL(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_TRUSTEEPERSONNEL';
    INSERT INTO SRC_PIF.MF_TRUSTEEPERSONNEL
      (ID,
       TRUSTEECODE,
       INFOPUBLDATE,
       INFOSOURCE,
       MEDIA,
       POSTNAME,
       NAME,
       GENDER,
       BIRTHDATE,
       EDUCATIONLEVEL,
       ACCESSIONDATE,
       DIMISSIONDATE,
       CONCURRENTPOST,
       BACKGROUND,
       INCUMBENT,
       NOTES,
       XGRQ,
       JSID)
      SELECT ID,
             TRUSTEECODE,
             INFOPUBLDATE,
             INFOSOURCE,
             MEDIA,
             POSTNAME,
             NAME,
             GENDER,
             BIRTHDATE,
             EDUCATIONLEVEL,
             ACCESSIONDATE,
             DIMISSIONDATE,
             CONCURRENTPOST,
             BACKGROUND,
             INCUMBENT,
             NOTES,
             XGRQ,
             JSID
        FROM JYDB.MF_TRUSTEEPERSONNEL@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --公募基金聚源分类
  PROCEDURE PRO_MF_JYFUNDTYPE(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.MF_JYFUNDTYPE';
    INSERT INTO SRC_PIF.MF_JYFUNDTYPE
      (ID,
       INNERCODE,
       STANDARD,
       EFFECTIVEDATE,
       CANCELDATE,
       IFEFFECTED,
       FIRSTASSETCATCODE,
       FIRSTASSETCATNAME,
       SECASSETCATCODE,
       SECASSETCATNAME,
       THIRDASSETCATCODE,
       THIRDASSETCATNAME,
       INSERTTIME,
       UPDATETIME,
       JSID)
      SELECT ID,
             INNERCODE,
             STANDARD,
             EFFECTIVEDATE,
             CANCELDATE,
             IFEFFECTED,
             FIRSTASSETCATCODE,
             FIRSTASSETCATNAME,
             SECASSETCATCODE,
             SECASSETCATNAME,
             THIRDASSETCATCODE,
             THIRDASSETCATNAME,
             INSERTTIME,
             UPDATETIME,
             JSID
        FROM JYDB.MF_JYFUNDTYPE@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --信托理财要素表
  PROCEDURE PRO_SF_TRPLANINFO(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.SF_TRPLANINFO M
    USING (SELECT ID,
                  INNERCODE,
                  PROSPUBLDATE,
                  POPULARIZESTDATE,
                  POPULARIZEEDDATE,
                  PARVALUE,
                  LEASTBUYSUM,
                  ISSUESIZEPLANNED,
                  SIZECOLLECTED,
                  SHARESCOLLECTED,
                  MATURITYPERIOD,
                  INCEPTIONDATE,
                  LASTTRADINGDATE,
                  CLEARINGDATE,
                  MATURITYDATE,
                  OPERATETYPE,
                  OPERATETYPEDESC,
                  IFTOT,
                  EXPANBEYIELD,
                  EXPANENYIELD,
                  ANNUALIZEDYTM,
                  PROFITDISTDESC,
                  TARGETCATEGORY,
                  TARGETCATEDESC,
                  INVESTMENTMANAGER,
                  IFSTRUCTURE,
                  ISSUEPLACEDESC,
                  SUBSCRIPTIONREMARK,
                  INVESTFIELD,
                  CREDITENHANCEMENT,
                  TRUSTCOMPANYCODE,
                  TRUSTCOMPANYNAME,
                  INVESTADVISERNAME,
                  DEPOSITORYBANKCODE,
                  DEPOSITORYBANKNAME,
                  BRIEFINFO,
                  UPDATETIME,
                  JSID,
                  INCOMETYPE,
                  AVGEXPANYIELD,
                  PROJECTNAME,
                  COUNTERPARTY,
                  PROJECTSITE,
                  INVESTSCOPE,
                  STRARRANGEMENT,
                  MATURITYUNIT
             FROM JYDB.SF_TRPLANINFO@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE          = N.INNERCODE,
             M.PROSPUBLDATE       = N.PROSPUBLDATE,
             M.POPULARIZESTDATE   = N.POPULARIZESTDATE,
             M.POPULARIZEEDDATE   = N.POPULARIZEEDDATE,
             M.PARVALUE           = N.PARVALUE,
             M.LEASTBUYSUM        = N.LEASTBUYSUM,
             M.ISSUESIZEPLANNED   = N.ISSUESIZEPLANNED,
             M.SIZECOLLECTED      = N.SIZECOLLECTED,
             M.SHARESCOLLECTED    = N.SHARESCOLLECTED,
             M.MATURITYPERIOD     = N.MATURITYPERIOD,
             M.INCEPTIONDATE      = N.INCEPTIONDATE,
             M.LASTTRADINGDATE    = N.LASTTRADINGDATE,
             M.CLEARINGDATE       = N.CLEARINGDATE,
             M.MATURITYDATE       = N.MATURITYDATE,
             M.OPERATETYPE        = N.OPERATETYPE,
             M.OPERATETYPEDESC    = N.OPERATETYPEDESC,
             M.IFTOT              = N.IFTOT,
             M.EXPANBEYIELD       = N.EXPANBEYIELD,
             M.EXPANENYIELD       = N.EXPANENYIELD,
             M.ANNUALIZEDYTM      = N.ANNUALIZEDYTM,
             M.PROFITDISTDESC     = N.PROFITDISTDESC,
             M.TARGETCATEGORY     = N.TARGETCATEGORY,
             M.TARGETCATEDESC     = N.TARGETCATEDESC,
             M.INVESTMENTMANAGER  = N.INVESTMENTMANAGER,
             M.IFSTRUCTURE        = N.IFSTRUCTURE,
             M.ISSUEPLACEDESC     = N.ISSUEPLACEDESC,
             M.SUBSCRIPTIONREMARK = N.SUBSCRIPTIONREMARK,
             M.INVESTFIELD        = N.INVESTFIELD,
             M.CREDITENHANCEMENT  = N.CREDITENHANCEMENT,
             M.TRUSTCOMPANYCODE   = N.TRUSTCOMPANYCODE,
             M.TRUSTCOMPANYNAME   = N.TRUSTCOMPANYNAME,
             M.INVESTADVISERNAME  = N.INVESTADVISERNAME,
             M.DEPOSITORYBANKCODE = N.DEPOSITORYBANKCODE,
             M.DEPOSITORYBANKNAME = N.DEPOSITORYBANKNAME,
             M.BRIEFINFO          = N.BRIEFINFO,
             M.UPDATETIME         = N.UPDATETIME,
             M.JSID               = N.JSID,
             M.INCOMETYPE         = N.INCOMETYPE,
             M.AVGEXPANYIELD      = N.AVGEXPANYIELD,
             M.PROJECTNAME        = N.PROJECTNAME,
             M.COUNTERPARTY       = N.COUNTERPARTY,
             M.PROJECTSITE        = N.PROJECTSITE,
             M.INVESTSCOPE        = N.INVESTSCOPE,
             M.STRARRANGEMENT     = N.STRARRANGEMENT,
             M.MATURITYUNIT       = N.MATURITYUNIT
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         PROSPUBLDATE,
         POPULARIZESTDATE,
         POPULARIZEEDDATE,
         PARVALUE,
         LEASTBUYSUM,
         ISSUESIZEPLANNED,
         SIZECOLLECTED,
         SHARESCOLLECTED,
         MATURITYPERIOD,
         INCEPTIONDATE,
         LASTTRADINGDATE,
         CLEARINGDATE,
         MATURITYDATE,
         OPERATETYPE,
         OPERATETYPEDESC,
         IFTOT,
         EXPANBEYIELD,
         EXPANENYIELD,
         ANNUALIZEDYTM,
         PROFITDISTDESC,
         TARGETCATEGORY,
         TARGETCATEDESC,
         INVESTMENTMANAGER,
         IFSTRUCTURE,
         ISSUEPLACEDESC,
         SUBSCRIPTIONREMARK,
         INVESTFIELD,
         CREDITENHANCEMENT,
         TRUSTCOMPANYCODE,
         TRUSTCOMPANYNAME,
         INVESTADVISERNAME,
         DEPOSITORYBANKCODE,
         DEPOSITORYBANKNAME,
         BRIEFINFO,
         UPDATETIME,
         JSID,
         INCOMETYPE,
         AVGEXPANYIELD,
         PROJECTNAME,
         COUNTERPARTY,
         PROJECTSITE,
         INVESTSCOPE,
         STRARRANGEMENT,
         MATURITYUNIT)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.PROSPUBLDATE,
         N.POPULARIZESTDATE,
         N.POPULARIZEEDDATE,
         N.PARVALUE,
         N.LEASTBUYSUM,
         N.ISSUESIZEPLANNED,
         N.SIZECOLLECTED,
         N.SHARESCOLLECTED,
         N.MATURITYPERIOD,
         N.INCEPTIONDATE,
         N.LASTTRADINGDATE,
         N.CLEARINGDATE,
         N.MATURITYDATE,
         N.OPERATETYPE,
         N.OPERATETYPEDESC,
         N.IFTOT,
         N.EXPANBEYIELD,
         N.EXPANENYIELD,
         N.ANNUALIZEDYTM,
         N.PROFITDISTDESC,
         N.TARGETCATEGORY,
         N.TARGETCATEDESC,
         N.INVESTMENTMANAGER,
         N.IFSTRUCTURE,
         N.ISSUEPLACEDESC,
         N.SUBSCRIPTIONREMARK,
         N.INVESTFIELD,
         N.CREDITENHANCEMENT,
         N.TRUSTCOMPANYCODE,
         N.TRUSTCOMPANYNAME,
         N.INVESTADVISERNAME,
         N.DEPOSITORYBANKCODE,
         N.DEPOSITORYBANKNAME,
         N.BRIEFINFO,
         N.UPDATETIME,
         N.JSID,
         N.INCOMETYPE,
         N.AVGEXPANYIELD,
         N.PROJECTNAME,
         N.COUNTERPARTY,
         N.PROJECTSITE,
         N.INVESTSCOPE,
         N.STRARRANGEMENT,
         N.MATURITYUNIT);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --私募基金基本信息
  PROCEDURE PRO_SF_POFBASICINFO(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.SF_POFBASICINFO M
    USING (SELECT ID,
                  INNERCODE,
                  PRODUCTNAME,
                  PRODUCTNAMEABBR,
                  CHISPELLING,
                  REGNUM,
                  REGDATE,
                  REGSTAGE,
                  REGSTATE,
                  VALUATIONDATE,
                  CURRENCY,
                  LEASTBUYSUM,
                  LEASTADDAMOUNT,
                  INVESTADVISORHOLD,
                  SUMCOLLECTED,
                  STARTDATE,
                  MATURITYPERIOD,
                  OPERATETYPE,
                  LISTEDSTATE,
                  INCOMETYPE,
                  ANNUALIZEDYTM,
                  CLEARINGDATE,
                  LOCKUPPERDES,
                  OPENPERDESC,
                  UNITNVUPDATEPERIOD,
                  RISKCONTROLDESC,
                  FUNDMANAGER,
                  MGTTYPE,
                  ISSUECHANNEL,
                  INVESTFIELD,
                  INVESTSTRATEGY,
                  SUBSTRATEGY,
                  IFSTRUCTURED,
                  REDEEMCHARGE,
                  INVESTMANAGER,
                  INVESTMANAGERCODE,
                  INVESTADVISER,
                  DEPOSITORYBANK,
                  DEPOSITORYBANKCODE,
                  STOCKBROKER,
                  STOCKBROKERCODE,
                  FUTURESBROKER,
                  FUTURESBROKERCODE,
                  INSERTTIME,
                  UPDATETIME,
                  JSID
             FROM JYDB.SF_POFBASICINFO@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE          = N.INNERCODE,
             M.PRODUCTNAME        = N.PRODUCTNAME,
             M.PRODUCTNAMEABBR    = N.PRODUCTNAMEABBR,
             M.CHISPELLING        = N.CHISPELLING,
             M.REGNUM             = N.REGNUM,
             M.REGDATE            = N.REGDATE,
             M.REGSTAGE           = N.REGSTAGE,
             M.REGSTATE           = N.REGSTATE,
             M.VALUATIONDATE      = N.VALUATIONDATE,
             M.CURRENCY           = N.CURRENCY,
             M.LEASTBUYSUM        = N.LEASTBUYSUM,
             M.LEASTADDAMOUNT     = N.LEASTADDAMOUNT,
             M.INVESTADVISORHOLD  = N.INVESTADVISORHOLD,
             M.SUMCOLLECTED       = N.SUMCOLLECTED,
             M.STARTDATE          = N.STARTDATE,
             M.MATURITYPERIOD     = N.MATURITYPERIOD,
             M.OPERATETYPE        = N.OPERATETYPE,
             M.LISTEDSTATE        = N.LISTEDSTATE,
             M.INCOMETYPE         = N.INCOMETYPE,
             M.ANNUALIZEDYTM      = N.ANNUALIZEDYTM,
             M.CLEARINGDATE       = N.CLEARINGDATE,
             M.LOCKUPPERDES       = N.LOCKUPPERDES,
             M.OPENPERDESC        = N.OPENPERDESC,
             M.UNITNVUPDATEPERIOD = N.UNITNVUPDATEPERIOD,
             M.RISKCONTROLDESC    = N.RISKCONTROLDESC,
             M.FUNDMANAGER        = N.FUNDMANAGER,
             M.MGTTYPE            = N.MGTTYPE,
             M.ISSUECHANNEL       = N.ISSUECHANNEL,
             M.INVESTFIELD        = N.INVESTFIELD,
             M.INVESTSTRATEGY     = N.INVESTSTRATEGY,
             M.SUBSTRATEGY        = N.SUBSTRATEGY,
             M.IFSTRUCTURED       = N.IFSTRUCTURED,
             M.REDEEMCHARGE       = N.REDEEMCHARGE,
             M.INVESTMANAGER      = N.INVESTMANAGER,
             M.INVESTMANAGERCODE  = N.INVESTMANAGERCODE,
             M.INVESTADVISER      = N.INVESTADVISER,
             M.DEPOSITORYBANK     = N.DEPOSITORYBANK,
             M.DEPOSITORYBANKCODE = N.DEPOSITORYBANKCODE,
             M.STOCKBROKER        = N.STOCKBROKER,
             M.STOCKBROKERCODE    = N.STOCKBROKERCODE,
             M.FUTURESBROKER      = N.FUTURESBROKER,
             M.FUTURESBROKERCODE  = N.FUTURESBROKERCODE,
             M.INSERTTIME         = N.INSERTTIME,
             M.UPDATETIME         = N.UPDATETIME,
             M.JSID               = N.JSID
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         PRODUCTNAME,
         PRODUCTNAMEABBR,
         CHISPELLING,
         REGNUM,
         REGDATE,
         REGSTAGE,
         REGSTATE,
         VALUATIONDATE,
         CURRENCY,
         LEASTBUYSUM,
         LEASTADDAMOUNT,
         INVESTADVISORHOLD,
         SUMCOLLECTED,
         STARTDATE,
         MATURITYPERIOD,
         OPERATETYPE,
         LISTEDSTATE,
         INCOMETYPE,
         ANNUALIZEDYTM,
         CLEARINGDATE,
         LOCKUPPERDES,
         OPENPERDESC,
         UNITNVUPDATEPERIOD,
         RISKCONTROLDESC,
         FUNDMANAGER,
         MGTTYPE,
         ISSUECHANNEL,
         INVESTFIELD,
         INVESTSTRATEGY,
         SUBSTRATEGY,
         IFSTRUCTURED,
         REDEEMCHARGE,
         INVESTMANAGER,
         INVESTMANAGERCODE,
         INVESTADVISER,
         DEPOSITORYBANK,
         DEPOSITORYBANKCODE,
         STOCKBROKER,
         STOCKBROKERCODE,
         FUTURESBROKER,
         FUTURESBROKERCODE,
         INSERTTIME,
         UPDATETIME,
         JSID)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.PRODUCTNAME,
         N.PRODUCTNAMEABBR,
         N.CHISPELLING,
         N.REGNUM,
         N.REGDATE,
         N.REGSTAGE,
         N.REGSTATE,
         N.VALUATIONDATE,
         N.CURRENCY,
         N.LEASTBUYSUM,
         N.LEASTADDAMOUNT,
         N.INVESTADVISORHOLD,
         N.SUMCOLLECTED,
         N.STARTDATE,
         N.MATURITYPERIOD,
         N.OPERATETYPE,
         N.LISTEDSTATE,
         N.INCOMETYPE,
         N.ANNUALIZEDYTM,
         N.CLEARINGDATE,
         N.LOCKUPPERDES,
         N.OPENPERDESC,
         N.UNITNVUPDATEPERIOD,
         N.RISKCONTROLDESC,
         N.FUNDMANAGER,
         N.MGTTYPE,
         N.ISSUECHANNEL,
         N.INVESTFIELD,
         N.INVESTSTRATEGY,
         N.SUBSTRATEGY,
         N.IFSTRUCTURED,
         N.REDEEMCHARGE,
         N.INVESTMANAGER,
         N.INVESTMANAGERCODE,
         N.INVESTADVISER,
         N.DEPOSITORYBANK,
         N.DEPOSITORYBANKCODE,
         N.STOCKBROKER,
         N.STOCKBROKERCODE,
         N.FUTURESBROKER,
         N.FUTURESBROKERCODE,
         N.INSERTTIME,
         N.UPDATETIME,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --私募基金经理基本资料
  PROCEDURE PRO_SF_POFMANAGERINFO(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    EXECUTE IMMEDIATE 'TRUNCATE TABLE SRC_PIF.SF_POFMANAGERINFO';
    INSERT INTO SRC_PIF.SF_POFMANAGERINFO
      (ID,
       PERSONALCODE,
       NAME,
       GENDER,
       BIRTHDATE,
       EDUCATION,
       PRACTICEDATE,
       POSITION,
       PRIZE,
       MAINPRODUCT,
       PRIVATEYEAR,
       COMPANYNAME,
       COMPANYCODE,
       MARKET,
       GOODSTRATEGY,
       ASSETMGTSCALE,
       PLACEMENT,
       PROQUALIFI,
       BACKGROUND,
       INSERTTIME,
       UPDATETIME,
       JSID)
      SELECT ID,
             PERSONALCODE,
             NAME,
             GENDER,
             BIRTHDATE,
             EDUCATION,
             PRACTICEDATE,
             POSITION,
             PRIZE,
             MAINPRODUCT,
             PRIVATEYEAR,
             COMPANYNAME,
             COMPANYCODE,
             MARKET,
             GOODSTRATEGY,
             ASSETMGTSCALE,
             PLACEMENT,
             PROQUALIFI,
             BACKGROUND,
             INSERTTIME,
             UPDATETIME,
             JSID
        FROM JYDB.SF_POFMANAGERINFO@JYZX;

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --私募基金费率信息表
  PROCEDURE PRO_SF_POFRATEINFO(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.SF_POFRATEINFO M
    USING (SELECT ID,
                  INNERCODE,
                  OFFERBUYEXP,
                  SUBSCRIBEEXP,
                  REDEEMEXPENSE,
                  MANAGEMENTEXP,
                  TRUSTEEEXPENSE,
                  PERFORMDRAW,
                  ISSETHIGHLEVEL,
                  ISHASHILLYIELD,
                  HILLYIELD,
                  OUTSOURCEEXP,
                  OTHEREXPENSE,
                  INSERTTIME,
                  UPDATETIME,
                  JSID
             FROM JYDB.SF_POFRATEINFO@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE      = N.INNERCODE,
             M.OFFERBUYEXP    = N.OFFERBUYEXP,
             M.SUBSCRIBEEXP   = N.SUBSCRIBEEXP,
             M.REDEEMEXPENSE  = N.REDEEMEXPENSE,
             M.MANAGEMENTEXP  = N.MANAGEMENTEXP,
             M.TRUSTEEEXPENSE = N.TRUSTEEEXPENSE,
             M.PERFORMDRAW    = N.PERFORMDRAW,
             M.ISSETHIGHLEVEL = N.ISSETHIGHLEVEL,
             M.ISHASHILLYIELD = N.ISHASHILLYIELD,
             M.HILLYIELD      = N.HILLYIELD,
             M.OUTSOURCEEXP   = N.OUTSOURCEEXP,
             M.OTHEREXPENSE   = N.OTHEREXPENSE,
             M.INSERTTIME     = N.INSERTTIME,
             M.UPDATETIME     = N.UPDATETIME,
             M.JSID           = N.JSID
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         OFFERBUYEXP,
         SUBSCRIBEEXP,
         REDEEMEXPENSE,
         MANAGEMENTEXP,
         TRUSTEEEXPENSE,
         PERFORMDRAW,
         ISSETHIGHLEVEL,
         ISHASHILLYIELD,
         HILLYIELD,
         OUTSOURCEEXP,
         OTHEREXPENSE,
         INSERTTIME,
         UPDATETIME,
         JSID)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.OFFERBUYEXP,
         N.SUBSCRIBEEXP,
         N.REDEEMEXPENSE,
         N.MANAGEMENTEXP,
         N.TRUSTEEEXPENSE,
         N.PERFORMDRAW,
         N.ISSETHIGHLEVEL,
         N.ISHASHILLYIELD,
         N.HILLYIELD,
         N.OUTSOURCEEXP,
         N.OTHEREXPENSE,
         N.INSERTTIME,
         N.UPDATETIME,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --理财产品主表
  PROCEDURE PRO_SF_PLANMAIN(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.SF_PLANMAIN M
    USING (SELECT ID,
                  INNERCODE,
                  COMPANYCODE,
                  PLANCODE,
                  CHINAME,
                  PLANABBR,
                  CHISPELLING,
                  PLANCATEGORY,
                  PLANSTATE,
                  UPDATETIME,
                  JSID,
                  GILCODE,
                  GILLEVEL
             FROM JYDB.SF_PLANMAIN@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE    = N.INNERCODE,
             M.COMPANYCODE  = N.COMPANYCODE,
             M.PLANCODE     = N.PLANCODE,
             M.CHINAME      = N.CHINAME,
             M.PLANABBR     = N.PLANABBR,
             M.CHISPELLING  = N.CHISPELLING,
             M.PLANCATEGORY = N.PLANCATEGORY,
             M.PLANSTATE    = N.PLANSTATE,
             M.UPDATETIME   = N.UPDATETIME,
             M.JSID         = N.JSID,
             M.GILCODE      = N.GILCODE,
             M.GILLEVEL     = N.GILLEVEL
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         COMPANYCODE,
         PLANCODE,
         CHINAME,
         PLANABBR,
         CHISPELLING,
         PLANCATEGORY,
         PLANSTATE,
         UPDATETIME,
         JSID,
         GILCODE,
         GILLEVEL)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.COMPANYCODE,
         N.PLANCODE,
         N.CHINAME,
         N.PLANABBR,
         N.CHISPELLING,
         N.PLANCATEGORY,
         N.PLANSTATE,
         N.UPDATETIME,
         N.JSID,
         N.GILCODE,
         N.GILLEVEL);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --证券主表
  PROCEDURE PRO_SECUMAIN(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.SECUMAIN M
    USING (SELECT ID,
                  INNERCODE,
                  COMPANYCODE,
                  SECUCODE,
                  CHINAME,
                  CHINAMEABBR,
                  ENGNAME,
                  ENGNAMEABBR,
                  SECUABBR,
                  CHISPELLING,
                  SECUMARKET,
                  SECUCATEGORY,
                  LISTEDDATE,
                  LISTEDSECTOR,
                  LISTEDSTATE,
                  XGRQ,
                  JSID,
                  ISIN
             FROM JYDB.SECUMAIN@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE    = N.INNERCODE,
             M.COMPANYCODE  = N.COMPANYCODE,
             M.SECUCODE     = N.SECUCODE,
             M.CHINAME      = N.CHINAME,
             M.CHINAMEABBR  = N.CHINAMEABBR,
             M.ENGNAME      = N.ENGNAME,
             M.ENGNAMEABBR  = N.ENGNAMEABBR,
             M.SECUABBR     = N.SECUABBR,
             M.CHISPELLING  = N.CHISPELLING,
             M.SECUMARKET   = N.SECUMARKET,
             M.SECUCATEGORY = N.SECUCATEGORY,
             M.LISTEDDATE   = N.LISTEDDATE,
             M.LISTEDSECTOR = N.LISTEDSECTOR,
             M.LISTEDSTATE  = N.LISTEDSTATE,
             M.XGRQ         = N.XGRQ,
             M.JSID         = N.JSID,
             M.ISIN         = N.ISIN
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         COMPANYCODE,
         SECUCODE,
         CHINAME,
         CHINAMEABBR,
         ENGNAME,
         ENGNAMEABBR,
         SECUABBR,
         CHISPELLING,
         SECUMARKET,
         SECUCATEGORY,
         LISTEDDATE,
         LISTEDSECTOR,
         LISTEDSTATE,
         XGRQ,
         JSID,
         ISIN)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.COMPANYCODE,
         N.SECUCODE,
         N.CHINAME,
         N.CHINAMEABBR,
         N.ENGNAME,
         N.ENGNAMEABBR,
         N.SECUABBR,
         N.CHISPELLING,
         N.SECUMARKET,
         N.SECUCATEGORY,
         N.LISTEDDATE,
         N.LISTEDSECTOR,
         N.LISTEDSTATE,
         N.XGRQ,
         N.JSID,
         N.ISIN);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --证券主表_香港 聚源库
  PROCEDURE PRO_HK_SECUMAIN(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.HK_SECUMAIN M
    USING (SELECT ID,
                  INNERCODE,
                  COMPANYCODE,
                  SECUCODE,
                  CHINAME,
                  CHINAMEABBR,
                  ENGNAME,
                  ENGNAMEABBR,
                  SECUABBR,
                  CHISPELLING,
                  SECUMARKET,
                  SECUCATEGORY,
                  LISTEDDATE,
                  LISTEDSECTOR,
                  LISTEDSTATE,
                  FORMERNAME,
                  DELISTINGDATE,
                  TRADINGUNIT,
                  TRACURRUNIT,
                  ISIN,
                  INSERTTIME,
                  XGRQ,
                  JSID
             FROM JYDB.HK_SECUMAIN@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE     = N.INNERCODE,
             M.COMPANYCODE   = N.COMPANYCODE,
             M.SECUCODE      = N.SECUCODE,
             M.CHINAME       = N.CHINAME,
             M.CHINAMEABBR   = N.CHINAMEABBR,
             M.ENGNAME       = N.ENGNAME,
             M.ENGNAMEABBR   = N.ENGNAMEABBR,
             M.SECUABBR      = N.SECUABBR,
             M.CHISPELLING   = N.CHISPELLING,
             M.SECUMARKET    = N.SECUMARKET,
             M.SECUCATEGORY  = N.SECUCATEGORY,
             M.LISTEDDATE    = N.LISTEDDATE,
             M.LISTEDSECTOR  = N.LISTEDSECTOR,
             M.LISTEDSTATE   = N.LISTEDSTATE,
             M.FORMERNAME    = N.FORMERNAME,
             M.DELISTINGDATE = N.DELISTINGDATE,
             M.TRADINGUNIT   = N.TRADINGUNIT,
             M.TRACURRUNIT   = N.TRACURRUNIT,
             M.ISIN          = N.ISIN,
             M.INSERTTIME    = N.INSERTTIME,
             M.XGRQ          = N.XGRQ,
             M.JSID          = N.JSID
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         COMPANYCODE,
         SECUCODE,
         CHINAME,
         CHINAMEABBR,
         ENGNAME,
         ENGNAMEABBR,
         SECUABBR,
         CHISPELLING,
         SECUMARKET,
         SECUCATEGORY,
         LISTEDDATE,
         LISTEDSECTOR,
         LISTEDSTATE,
         FORMERNAME,
         DELISTINGDATE,
         TRADINGUNIT,
         TRACURRUNIT,
         ISIN,
         INSERTTIME,
         XGRQ,
         JSID)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.COMPANYCODE,
         N.SECUCODE,
         N.CHINAME,
         N.CHINAMEABBR,
         N.ENGNAME,
         N.ENGNAMEABBR,
         N.SECUABBR,
         N.CHISPELLING,
         N.SECUMARKET,
         N.SECUCATEGORY,
         N.LISTEDDATE,
         N.LISTEDSECTOR,
         N.LISTEDSTATE,
         N.FORMERNAME,
         N.DELISTINGDATE,
         N.TRADINGUNIT,
         N.TRACURRUNIT,
         N.ISIN,
         N.INSERTTIME,
         N.XGRQ,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金行业投资
  PROCEDURE PRO_MF_INVESTINDUSTRY(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_INVESTINDUSTRY M
    USING (SELECT ID,
                  INNERCODE,
                  INFOPUBLDATE,
                  REPORTDATE,
                  INVESTTYPE,
                  INDUSTRYCODE,
                  INDUSTRYNAME,
                  MARKETVALUE,
                  RATIOINNV,
                  XGRQ,
                  JSID,
                  INDUSTANDARD,
                  INDUDISCCODE
             FROM JYDB.MF_INVESTINDUSTRY@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE    = N.INNERCODE,
             M.INFOPUBLDATE = N.INFOPUBLDATE,
             M.REPORTDATE   = N.REPORTDATE,
             M.INVESTTYPE   = N.INVESTTYPE,
             M.INDUSTRYCODE = N.INDUSTRYCODE,
             M.INDUSTRYNAME = N.INDUSTRYNAME,
             M.MARKETVALUE  = N.MARKETVALUE,
             M.RATIOINNV    = N.RATIOINNV,
             M.XGRQ         = N.XGRQ,
             M.JSID         = N.JSID,
             M.INDUSTANDARD = N.INDUSTANDARD,
             M.INDUDISCCODE = N.INDUDISCCODE
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         INFOPUBLDATE,
         REPORTDATE,
         INVESTTYPE,
         INDUSTRYCODE,
         INDUSTRYNAME,
         MARKETVALUE,
         RATIOINNV,
         XGRQ,
         JSID,
         INDUSTANDARD,
         INDUDISCCODE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.INFOPUBLDATE,
         N.REPORTDATE,
         N.INVESTTYPE,
         N.INDUSTRYCODE,
         N.INDUSTRYNAME,
         N.MARKETVALUE,
         N.RATIOINNV,
         N.XGRQ,
         N.JSID,
         N.INDUSTANDARD,
         N.INDUDISCCODE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金资产配置
  PROCEDURE PRO_MF_ASSETALLOCATION(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_ASSETALLOCATION M
    USING (SELECT ID,
                  INNERCODE,
                  INFOPUBLDATE,
                  REPORTDATE,
                  ASSETTYPE,
                  MARKETVALUE,
                  RATIOINTOTALASSET,
                  RATIOINNV,
                  XGRQ,
                  JSID,
                  ASSETTYPECODE
             FROM JYDB.MF_ASSETALLOCATION@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE         = N.INNERCODE,
             M.INFOPUBLDATE      = N.INFOPUBLDATE,
             M.REPORTDATE        = N.REPORTDATE,
             M.ASSETTYPE         = N.ASSETTYPE,
             M.MARKETVALUE       = N.MARKETVALUE,
             M.RATIOINTOTALASSET = N.RATIOINTOTALASSET,
             M.RATIOINNV         = N.RATIOINNV,
             M.XGRQ              = N.XGRQ,
             M.JSID              = N.JSID,
             M.ASSETTYPECODE     = N.ASSETTYPECODE
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         INFOPUBLDATE,
         REPORTDATE,
         ASSETTYPE,
         MARKETVALUE,
         RATIOINTOTALASSET,
         RATIOINNV,
         XGRQ,
         JSID,
         ASSETTYPECODE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.INFOPUBLDATE,
         N.REPORTDATE,
         N.ASSETTYPE,
         N.MARKETVALUE,
         N.RATIOINTOTALASSET,
         N.RATIOINNV,
         N.XGRQ,
         N.JSID,
         N.ASSETTYPECODE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金重仓股票组合
  PROCEDURE PRO_MF_KEYSTOCKPORTFOLIO(O_CODE     OUT NUMBER,
                                     O_NOTE     OUT VARCHAR2,
                                     O_ROWCOUNT OUT NUMBER,
                                     I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_KEYSTOCKPORTFOLIO M
    USING (SELECT ID,
                  INNERCODE,
                  REPORTDATE,
                  SERIALNUMBER,
                  STOCKINNERCODE,
                  SHARESHOLDING,
                  MARKETVALUE,
                  RATIOINNV,
                  INVESTTYPE,
                  XGRQ,
                  JSID,
                  INFOPUBLDATE,
                  INFOSOURCE,
                  CHANGEOFSHARESHOLDING
             FROM JYDB.MF_KEYSTOCKPORTFOLIO@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE             = N.INNERCODE,
             M.REPORTDATE            = N.REPORTDATE,
             M.SERIALNUMBER          = N.SERIALNUMBER,
             M.STOCKINNERCODE        = N.STOCKINNERCODE,
             M.SHARESHOLDING         = N.SHARESHOLDING,
             M.MARKETVALUE           = N.MARKETVALUE,
             M.RATIOINNV             = N.RATIOINNV,
             M.INVESTTYPE            = N.INVESTTYPE,
             M.XGRQ                  = N.XGRQ,
             M.JSID                  = N.JSID,
             M.INFOPUBLDATE          = N.INFOPUBLDATE,
             M.INFOSOURCE            = N.INFOSOURCE,
             M.CHANGEOFSHARESHOLDING = N.CHANGEOFSHARESHOLDING
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         REPORTDATE,
         SERIALNUMBER,
         STOCKINNERCODE,
         SHARESHOLDING,
         MARKETVALUE,
         RATIOINNV,
         INVESTTYPE,
         XGRQ,
         JSID,
         INFOPUBLDATE,
         INFOSOURCE,
         CHANGEOFSHARESHOLDING)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.REPORTDATE,
         N.SERIALNUMBER,
         N.STOCKINNERCODE,
         N.SHARESHOLDING,
         N.MARKETVALUE,
         N.RATIOINNV,
         N.INVESTTYPE,
         N.XGRQ,
         N.JSID,
         N.INFOPUBLDATE,
         N.INFOSOURCE,
         N.CHANGEOFSHARESHOLDING);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金债券组合明细
  PROCEDURE PRO_MF_BONDPORTIFOLIODETAIL(O_CODE     OUT NUMBER,
                                        O_NOTE     OUT VARCHAR2,
                                        O_ROWCOUNT OUT NUMBER,
                                        I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_BONDPORTIFOLIODETAIL M
    USING (SELECT ID,
                  INNERCODE,
                  REPORTDATE,
                  SERIALNUMBER,
                  BONDCODE,
                  HOLDVOLUME,
                  MARKETVALUE,
                  RATIOINNV,
                  IFINCONVERTIBLETERM,
                  XGRQ,
                  JSID,
                  INFOPUBLDATE
             FROM JYDB.MF_BONDPORTIFOLIODETAIL@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE           = N.INNERCODE,
             M.REPORTDATE          = N.REPORTDATE,
             M.SERIALNUMBER        = N.SERIALNUMBER,
             M.BONDCODE            = N.BONDCODE,
             M.HOLDVOLUME          = N.HOLDVOLUME,
             M.MARKETVALUE         = N.MARKETVALUE,
             M.RATIOINNV           = N.RATIOINNV,
             M.IFINCONVERTIBLETERM = N.IFINCONVERTIBLETERM,
             M.XGRQ                = N.XGRQ,
             M.JSID                = N.JSID,
             M.INFOPUBLDATE        = N.INFOPUBLDATE
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         REPORTDATE,
         SERIALNUMBER,
         BONDCODE,
         HOLDVOLUME,
         MARKETVALUE,
         RATIOINNV,
         IFINCONVERTIBLETERM,
         XGRQ,
         JSID,
         INFOPUBLDATE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.REPORTDATE,
         N.SERIALNUMBER,
         N.BONDCODE,
         N.HOLDVOLUME,
         N.MARKETVALUE,
         N.RATIOINNV,
         N.IFINCONVERTIBLETERM,
         N.XGRQ,
         N.JSID,
         N.INFOPUBLDATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金净值
  PROCEDURE PRO_MF_NETVALUE(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_NETVALUE M
    USING (SELECT ID,
                  INNERCODE,
                  INFOPUBLDATE,
                  INFOSOURCE,
                  ENDDATE,
                  NV,
                  UNITNV,
                  ACCUMULATEDUNITNV,
                  DAILYPROFIT,
                  LATESTWEEKLYYIELD,
                  NVDAILYGROWTHRATE,
                  NVWEEKLYGROWTHRATE,
                  DISCOUNTRATIO,
                  XGRQ,
                  JSID,
                  INVOLVEDDAYS
             FROM JYDB.MF_NETVALUE@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE          = N.INNERCODE,
             M.INFOPUBLDATE       = N.INFOPUBLDATE,
             M.INFOSOURCE         = N.INFOSOURCE,
             M.ENDDATE            = N.ENDDATE,
             M.NV                 = N.NV,
             M.UNITNV             = N.UNITNV,
             M.ACCUMULATEDUNITNV  = N.ACCUMULATEDUNITNV,
             M.DAILYPROFIT        = N.DAILYPROFIT,
             M.LATESTWEEKLYYIELD  = N.LATESTWEEKLYYIELD,
             M.NVDAILYGROWTHRATE  = N.NVDAILYGROWTHRATE,
             M.NVWEEKLYGROWTHRATE = N.NVWEEKLYGROWTHRATE,
             M.DISCOUNTRATIO      = N.DISCOUNTRATIO,
             M.XGRQ               = N.XGRQ,
             M.JSID               = N.JSID,
             M.INVOLVEDDAYS       = N.INVOLVEDDAYS


    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         INFOPUBLDATE,
         INFOSOURCE,
         ENDDATE,
         NV,
         UNITNV,
         ACCUMULATEDUNITNV,
         DAILYPROFIT,
         LATESTWEEKLYYIELD,
         NVDAILYGROWTHRATE,
         NVWEEKLYGROWTHRATE,
         DISCOUNTRATIO,
         XGRQ,
         JSID,
         INVOLVEDDAYS)

      VALUES
        (N.ID,
         N.INNERCODE,
         N.INFOPUBLDATE,
         N.INFOSOURCE,
         N.ENDDATE,
         N.NV,
         N.UNITNV,
         N.ACCUMULATEDUNITNV,
         N.DAILYPROFIT,
         N.LATESTWEEKLYYIELD,
         N.NVDAILYGROWTHRATE,
         N.NVWEEKLYGROWTHRATE,
         N.DISCOUNTRATIO,
         N.XGRQ,
         N.JSID,
         N.INVOLVEDDAYS);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  --基金复权净值
  PROCEDURE PRO_MF_FUNDNETVALUERE(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_FUNDNETVALUERE M
    USING (SELECT ID,
                  INNERCODE,
                  TRADINGDAY,
                  UNITNV,
                  GROWTHRATEFACTOR,
                  UNITNVRESTORED,
                  NVDAILYGROWTHRATE,
                  NVRDAILYGROWTHRATE,
                  UPDATETIME,
                  JSID
             FROM JYDB.MF_FUNDNETVALUERE@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE          = N.INNERCODE,
             M.TRADINGDAY         = N.TRADINGDAY,
             M.UNITNV             = N.UNITNV,
             M.GROWTHRATEFACTOR   = N.GROWTHRATEFACTOR,
             M.UNITNVRESTORED     = N.UNITNVRESTORED,
             M.NVDAILYGROWTHRATE  = N.NVDAILYGROWTHRATE,
             M.NVRDAILYGROWTHRATE = N.NVRDAILYGROWTHRATE,
             M.UPDATETIME         = N.UPDATETIME,
             M.JSID               = N.JSID
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         TRADINGDAY,
         UNITNV,
         GROWTHRATEFACTOR,
         UNITNVRESTORED,
         NVDAILYGROWTHRATE,
         NVRDAILYGROWTHRATE,
         UPDATETIME,
         JSID)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.TRADINGDAY,
         N.UNITNV,
         N.GROWTHRATEFACTOR,
         N.UNITNVRESTORED,
         N.NVDAILYGROWTHRATE,
         N.NVRDAILYGROWTHRATE,
         N.UPDATETIME,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  --基金净值最新表现
  PROCEDURE PRO_MF_NETVALUEPERFORMANCE(O_CODE     OUT NUMBER,
                                       O_NOTE     OUT VARCHAR2,
                                       O_ROWCOUNT OUT NUMBER,
                                       I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_NETVALUEPERFORMANCE M
    USING (SELECT ID,
                  INNERCODE,
                  TRADINGDAY,
                  UNITNV,
                  RRINSELECTEDWEEK,
                  RRINSINGLEWEEK,
                  RRINSELECTEDMONTH,
                  RRINSINGLEMONTH,
                  RRINTHREEMONTH,
                  RRINSIXMONTH,
                  RRSINCETHISYEAR,
                  RRINSINGLEYEAR,
                  RRINTWOYEAR,
                  ANNUALIZEDRRINTWOYEAR,
                  RRINTHREEYEAR,
                  ANNUALIZEDRRINTHREEYEAR,
                  RRINFIVEYEAR,
                  ANNUALIZEDRRINFIVEYEAR,
                  RRINTENYEAR,
                  ANNUALIZEDRRINTENYEAR,
                  RRSINCESTART,
                  ANNUALIZEDRRSINCESTART,
                  UPDATETIME,
                  JSID,
                  NVDAILYGROWTHRATE
             FROM JYDB.MF_NETVALUEPERFORMANCE@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE               = N.INNERCODE,
             M.TRADINGDAY              = N.TRADINGDAY,
             M.UNITNV                  = N.UNITNV,
             M.RRINSELECTEDWEEK        = N.RRINSELECTEDWEEK,
             M.RRINSINGLEWEEK          = N.RRINSINGLEWEEK,
             M.RRINSELECTEDMONTH       = N.RRINSELECTEDMONTH,
             M.RRINSINGLEMONTH         = N.RRINSINGLEMONTH,
             M.RRINTHREEMONTH          = N.RRINTHREEMONTH,
             M.RRINSIXMONTH            = N.RRINSIXMONTH,
             M.RRSINCETHISYEAR         = N.RRSINCETHISYEAR,
             M.RRINSINGLEYEAR          = N.RRINSINGLEYEAR,
             M.RRINTWOYEAR             = N.RRINTWOYEAR,
             M.ANNUALIZEDRRINTWOYEAR   = N.ANNUALIZEDRRINTWOYEAR,
             M.RRINTHREEYEAR           = N.RRINTHREEYEAR,
             M.ANNUALIZEDRRINTHREEYEAR = N.ANNUALIZEDRRINTHREEYEAR,
             M.RRINFIVEYEAR            = N.RRINFIVEYEAR,
             M.ANNUALIZEDRRINFIVEYEAR  = N.ANNUALIZEDRRINFIVEYEAR,
             M.RRINTENYEAR             = N.RRINTENYEAR,
             M.ANNUALIZEDRRINTENYEAR   = N.ANNUALIZEDRRINTENYEAR,
             M.RRSINCESTART            = N.RRSINCESTART,
             M.ANNUALIZEDRRSINCESTART  = N.ANNUALIZEDRRSINCESTART,
             M.UPDATETIME              = N.UPDATETIME,
             M.JSID                    = N.JSID,
             M.NVDAILYGROWTHRATE       = N.NVDAILYGROWTHRATE


    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         TRADINGDAY,
         UNITNV,
         RRINSELECTEDWEEK,
         RRINSINGLEWEEK,
         RRINSELECTEDMONTH,
         RRINSINGLEMONTH,
         RRINTHREEMONTH,
         RRINSIXMONTH,
         RRSINCETHISYEAR,
         RRINSINGLEYEAR,
         RRINTWOYEAR,
         ANNUALIZEDRRINTWOYEAR,
         RRINTHREEYEAR,
         ANNUALIZEDRRINTHREEYEAR,
         RRINFIVEYEAR,
         ANNUALIZEDRRINFIVEYEAR,
         RRINTENYEAR,
         ANNUALIZEDRRINTENYEAR,
         RRSINCESTART,
         ANNUALIZEDRRSINCESTART,
         UPDATETIME,
         JSID,
         NVDAILYGROWTHRATE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.TRADINGDAY,
         N.UNITNV,
         N.RRINSELECTEDWEEK,
         N.RRINSINGLEWEEK,
         N.RRINSELECTEDMONTH,
         N.RRINSINGLEMONTH,
         N.RRINTHREEMONTH,
         N.RRINSIXMONTH,
         N.RRSINCETHISYEAR,
         N.RRINSINGLEYEAR,
         N.RRINTWOYEAR,
         N.ANNUALIZEDRRINTWOYEAR,
         N.RRINTHREEYEAR,
         N.ANNUALIZEDRRINTHREEYEAR,
         N.RRINFIVEYEAR,
         N.ANNUALIZEDRRINFIVEYEAR,
         N.RRINTENYEAR,
         N.ANNUALIZEDRRINTENYEAR,
         N.RRSINCESTART,
         N.ANNUALIZEDRRSINCESTART,
         N.UPDATETIME,
         N.JSID,
         N.NVDAILYGROWTHRATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  --基金净值历史表现
  PROCEDURE PRO_MF_NETVALUEPERFORMANCEHIS(O_CODE     OUT NUMBER,
                                          O_NOTE     OUT VARCHAR2,
                                          O_ROWCOUNT OUT NUMBER,
                                          I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.MF_NETVALUEPERFORMANCEHIS M
    USING (SELECT ID,
                  INNERCODE,
                  TRADINGDAY,
                  UNITNV,
                  RRINSELECTEDWEEK,
                  RRINSINGLEWEEK,
                  RRINSELECTEDMONTH,
                  RRINSINGLEMONTH,
                  RRINTHREEMONTH,
                  RRINSIXMONTH,
                  RRSINCETHISYEAR,
                  RRINSINGLEYEAR,
                  RRINTWOYEAR,
                  ANNUALIZEDRRINTWOYEAR,
                  RRINTHREEYEAR,
                  ANNUALIZEDRRINTHREEYEAR,
                  RRINFIVEYEAR,
                  ANNUALIZEDRRINFIVEYEAR,
                  RRINTENYEAR,
                  ANNUALIZEDRRINTENYEAR,
                  RRSINCESTART,
                  ANNUALIZEDRRSINCESTART,
                  UPDATETIME,
                  JSID,
                  NVDAILYGROWTHRATE
             FROM JYDB.MF_NETVALUEPERFORMANCEHIS@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE               = N.INNERCODE,
             M.TRADINGDAY              = N.TRADINGDAY,
             M.UNITNV                  = N.UNITNV,
             M.RRINSELECTEDWEEK        = N.RRINSELECTEDWEEK,
             M.RRINSINGLEWEEK          = N.RRINSINGLEWEEK,
             M.RRINSELECTEDMONTH       = N.RRINSELECTEDMONTH,
             M.RRINSINGLEMONTH         = N.RRINSINGLEMONTH,
             M.RRINTHREEMONTH          = N.RRINTHREEMONTH,
             M.RRINSIXMONTH            = N.RRINSIXMONTH,
             M.RRSINCETHISYEAR         = N.RRSINCETHISYEAR,
             M.RRINSINGLEYEAR          = N.RRINSINGLEYEAR,
             M.RRINTWOYEAR             = N.RRINTWOYEAR,
             M.ANNUALIZEDRRINTWOYEAR   = N.ANNUALIZEDRRINTWOYEAR,
             M.RRINTHREEYEAR           = N.RRINTHREEYEAR,
             M.ANNUALIZEDRRINTHREEYEAR = N.ANNUALIZEDRRINTHREEYEAR,
             M.RRINFIVEYEAR            = N.RRINFIVEYEAR,
             M.ANNUALIZEDRRINFIVEYEAR  = N.ANNUALIZEDRRINFIVEYEAR,
             M.RRINTENYEAR             = N.RRINTENYEAR,
             M.ANNUALIZEDRRINTENYEAR   = N.ANNUALIZEDRRINTENYEAR,
             M.RRSINCESTART            = N.RRSINCESTART,
             M.ANNUALIZEDRRSINCESTART  = N.ANNUALIZEDRRSINCESTART,
             M.UPDATETIME              = N.UPDATETIME,
             M.JSID                    = N.JSID,
             M.NVDAILYGROWTHRATE       = N.NVDAILYGROWTHRATE
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         TRADINGDAY,
         UNITNV,
         RRINSELECTEDWEEK,
         RRINSINGLEWEEK,
         RRINSELECTEDMONTH,
         RRINSINGLEMONTH,
         RRINTHREEMONTH,
         RRINSIXMONTH,
         RRSINCETHISYEAR,
         RRINSINGLEYEAR,
         RRINTWOYEAR,
         ANNUALIZEDRRINTWOYEAR,
         RRINTHREEYEAR,
         ANNUALIZEDRRINTHREEYEAR,
         RRINFIVEYEAR,
         ANNUALIZEDRRINFIVEYEAR,
         RRINTENYEAR,
         ANNUALIZEDRRINTENYEAR,
         RRSINCESTART,
         ANNUALIZEDRRSINCESTART,
         UPDATETIME,
         JSID,
         NVDAILYGROWTHRATE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.TRADINGDAY,
         N.UNITNV,
         N.RRINSELECTEDWEEK,
         N.RRINSINGLEWEEK,
         N.RRINSELECTEDMONTH,
         N.RRINSINGLEMONTH,
         N.RRINTHREEMONTH,
         N.RRINSIXMONTH,
         N.RRSINCETHISYEAR,
         N.RRINSINGLEYEAR,
         N.RRINTWOYEAR,
         N.ANNUALIZEDRRINTWOYEAR,
         N.RRINTHREEYEAR,
         N.ANNUALIZEDRRINTHREEYEAR,
         N.RRINFIVEYEAR,
         N.ANNUALIZEDRRINFIVEYEAR,
         N.RRINTENYEAR,
         N.ANNUALIZEDRRINTENYEAR,
         N.RRSINCESTART,
         N.ANNUALIZEDRRSINCESTART,
         N.UPDATETIME,
         N.JSID,
         N.NVDAILYGROWTHRATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;
  --基金行情表现
  PROCEDURE PRO_QT_FUNDSPERFORMANCE(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER) AS
  BEGIN
    MERGE INTO SRC_PIF.QT_FUNDSPERFORMANCE M
    USING (SELECT ID,
                  INNERCODE,
                  TRADINGDAY,
                  PREVCLOSEPRICE,
                  OPENPRICE,
                  HIGHPRICE,
                  LOWPRICE,
                  CLOSEPRICE,
                  AVGPRICE,
                  CHANGEOFPRICE,
                  CHANGEPCT,
                  TURNOVERRATE,
                  TURNOVERVOLUME,
                  TURNOVERVALUE,
                  VIBRATIONRANGE,
                  DISCOUNT,
                  DISCOUNTRATIO,
                  PREVCLOSEPRICERW,
                  OPENPRICERW,
                  HIGHPRICERW,
                  LOWPRICERW,
                  CLOSEPRICERW,
                  HIGHESTCLOSEPRICERW,
                  LOWESTCLOSEPRICERW,
                  AVGPRICERW,
                  CHANGEOFPRICERW,
                  CHANGEPCTRW,
                  TURNOVERRATERW,
                  AVGTURNOVERRATERW,
                  RANGEPCTRW,
                  TURNOVERVOLUMERW,
                  TURNOVERVALUERW,
                  DISCOUNTRW,
                  DISCOUNTRATIORW,
                  HIGHPRICERWDATE,
                  LOWPRICERWDATE,
                  HIGHESTCLOSEPRICERWDATE,
                  LOWESTCLOSEPRICERWDATE,
                  CHANGEPCTTOINDEXRW,
                  PREVCLOSEPRICERM,
                  OPENPRICERM,
                  HIGHPRICERM,
                  LOWPRICERM,
                  CLOSEPRICERM,
                  HIGHESTCLOSEPRICERM,
                  LOWESTCLOSEPRICERM,
                  AVGPRICERM,
                  CHANGEOFPRICERM,
                  CHANGEPCTRM,
                  TURNOVERRATERM,
                  AVGTURNOVERRATERM,
                  RANGEPCTRM,
                  TURNOVERVOLUMERM,
                  TURNOVERVALUERM,
                  DISCOUNTRM,
                  DISCOUNTRATIORM,
                  HIGHPRICERMDATE,
                  LOWPRICERMDATE,
                  HIGHESTCLOSEPRICERMDATE,
                  LOWESTCLOSEPRICERMDATE,
                  CHANGEPCTTOINDEXRM,
                  PREVCLOSEPRICERY,
                  OPENPRICERY,
                  HIGHPRICERY,
                  LOWPRICERY,
                  CLOSEPRICERY,
                  HIGHESTCLOSEPRICERY,
                  LOWESTCLOSEPRICERY,
                  AVGPRICERY,
                  CHANGEOFPRICERY,
                  CHANGEPCTRY,
                  TURNOVERRATERY,
                  AVGTURNOVERRATERY,
                  RANGEPCTRY,
                  TURNOVERVOLUMERY,
                  TURNOVERVALUERY,
                  DISCOUNTRY,
                  DISCOUNTRATIORY,
                  HIGHPRICERYDATE,
                  LOWPRICERYDATE,
                  HIGHESTCLOSEPRICERYDATE,
                  LOWESTCLOSEPRICERYDATE,
                  CHANGEPCTTOINDEXRY,
                  UPDATETIME,
                  JSID
             FROM JYDB.QT_FUNDSPERFORMANCE@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)
    WHEN MATCHED THEN
      UPDATE
         SET M.INNERCODE               = N.INNERCODE,
             M.TRADINGDAY              = N.TRADINGDAY,
             M.PREVCLOSEPRICE          = N.PREVCLOSEPRICE,
             M.OPENPRICE               = N.OPENPRICE,
             M.HIGHPRICE               = N.HIGHPRICE,
             M.LOWPRICE                = N.LOWPRICE,
             M.CLOSEPRICE              = N.CLOSEPRICE,
             M.AVGPRICE                = N.AVGPRICE,
             M.CHANGEOFPRICE           = N.CHANGEOFPRICE,
             M.CHANGEPCT               = N.CHANGEPCT,
             M.TURNOVERRATE            = N.TURNOVERRATE,
             M.TURNOVERVOLUME          = N.TURNOVERVOLUME,
             M.TURNOVERVALUE           = N.TURNOVERVALUE,
             M.VIBRATIONRANGE          = N.VIBRATIONRANGE,
             M.DISCOUNT                = N.DISCOUNT,
             M.DISCOUNTRATIO           = N.DISCOUNTRATIO,
             M.PREVCLOSEPRICERW        = N.PREVCLOSEPRICERW,
             M.OPENPRICERW             = N.OPENPRICERW,
             M.HIGHPRICERW             = N.HIGHPRICERW,
             M.LOWPRICERW              = N.LOWPRICERW,
             M.CLOSEPRICERW            = N.CLOSEPRICERW,
             M.HIGHESTCLOSEPRICERW     = N.HIGHESTCLOSEPRICERW,
             M.LOWESTCLOSEPRICERW      = N.LOWESTCLOSEPRICERW,
             M.AVGPRICERW              = N.AVGPRICERW,
             M.CHANGEOFPRICERW         = N.CHANGEOFPRICERW,
             M.CHANGEPCTRW             = N.CHANGEPCTRW,
             M.TURNOVERRATERW          = N.TURNOVERRATERW,
             M.AVGTURNOVERRATERW       = N.AVGTURNOVERRATERW,
             M.RANGEPCTRW              = N.RANGEPCTRW,
             M.TURNOVERVOLUMERW        = N.TURNOVERVOLUMERW,
             M.TURNOVERVALUERW         = N.TURNOVERVALUERW,
             M.DISCOUNTRW              = N.DISCOUNTRW,
             M.DISCOUNTRATIORW         = N.DISCOUNTRATIORW,
             M.HIGHPRICERWDATE         = N.HIGHPRICERWDATE,
             M.LOWPRICERWDATE          = N.LOWPRICERWDATE,
             M.HIGHESTCLOSEPRICERWDATE = N.HIGHESTCLOSEPRICERWDATE,
             M.LOWESTCLOSEPRICERWDATE  = N.LOWESTCLOSEPRICERWDATE,
             M.CHANGEPCTTOINDEXRW      = N.CHANGEPCTTOINDEXRW,
             M.PREVCLOSEPRICERM        = N.PREVCLOSEPRICERM,
             M.OPENPRICERM             = N.OPENPRICERM,
             M.HIGHPRICERM             = N.HIGHPRICERM,
             M.LOWPRICERM              = N.LOWPRICERM,
             M.CLOSEPRICERM            = N.CLOSEPRICERM,
             M.HIGHESTCLOSEPRICERM     = N.HIGHESTCLOSEPRICERM,
             M.LOWESTCLOSEPRICERM      = N.LOWESTCLOSEPRICERM,
             M.AVGPRICERM              = N.AVGPRICERM,
             M.CHANGEOFPRICERM         = N.CHANGEOFPRICERM,
             M.CHANGEPCTRM             = N.CHANGEPCTRM,
             M.TURNOVERRATERM          = N.TURNOVERRATERM,
             M.AVGTURNOVERRATERM       = N.AVGTURNOVERRATERM,
             M.RANGEPCTRM              = N.RANGEPCTRM,
             M.TURNOVERVOLUMERM        = N.TURNOVERVOLUMERM,
             M.TURNOVERVALUERM         = N.TURNOVERVALUERM,
             M.DISCOUNTRM              = N.DISCOUNTRM,
             M.DISCOUNTRATIORM         = N.DISCOUNTRATIORM,
             M.HIGHPRICERMDATE         = N.HIGHPRICERMDATE,
             M.LOWPRICERMDATE          = N.LOWPRICERMDATE,
             M.HIGHESTCLOSEPRICERMDATE = N.HIGHESTCLOSEPRICERMDATE,
             M.LOWESTCLOSEPRICERMDATE  = N.LOWESTCLOSEPRICERMDATE,
             M.CHANGEPCTTOINDEXRM      = N.CHANGEPCTTOINDEXRM,
             M.PREVCLOSEPRICERY        = N.PREVCLOSEPRICERY,
             M.OPENPRICERY             = N.OPENPRICERY,
             M.HIGHPRICERY             = N.HIGHPRICERY,
             M.LOWPRICERY              = N.LOWPRICERY,
             M.CLOSEPRICERY            = N.CLOSEPRICERY,
             M.HIGHESTCLOSEPRICERY     = N.HIGHESTCLOSEPRICERY,
             M.LOWESTCLOSEPRICERY      = N.LOWESTCLOSEPRICERY,
             M.AVGPRICERY              = N.AVGPRICERY,
             M.CHANGEOFPRICERY         = N.CHANGEOFPRICERY,
             M.CHANGEPCTRY             = N.CHANGEPCTRY,
             M.TURNOVERRATERY          = N.TURNOVERRATERY,
             M.AVGTURNOVERRATERY       = N.AVGTURNOVERRATERY,
             M.RANGEPCTRY              = N.RANGEPCTRY,
             M.TURNOVERVOLUMERY        = N.TURNOVERVOLUMERY,
             M.TURNOVERVALUERY         = N.TURNOVERVALUERY,
             M.DISCOUNTRY              = N.DISCOUNTRY,
             M.DISCOUNTRATIORY         = N.DISCOUNTRATIORY,
             M.HIGHPRICERYDATE         = N.HIGHPRICERYDATE,
             M.LOWPRICERYDATE          = N.LOWPRICERYDATE,
             M.HIGHESTCLOSEPRICERYDATE = N.HIGHESTCLOSEPRICERYDATE,
             M.LOWESTCLOSEPRICERYDATE  = N.LOWESTCLOSEPRICERYDATE,
             M.CHANGEPCTTOINDEXRY      = N.CHANGEPCTTOINDEXRY,
             M.UPDATETIME              = N.UPDATETIME,
             M.JSID                    = N.JSID


    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         TRADINGDAY,
         PREVCLOSEPRICE,
         OPENPRICE,
         HIGHPRICE,
         LOWPRICE,
         CLOSEPRICE,
         AVGPRICE,
         CHANGEOFPRICE,
         CHANGEPCT,
         TURNOVERRATE,
         TURNOVERVOLUME,
         TURNOVERVALUE,
         VIBRATIONRANGE,
         DISCOUNT,
         DISCOUNTRATIO,
         PREVCLOSEPRICERW,
         OPENPRICERW,
         HIGHPRICERW,
         LOWPRICERW,
         CLOSEPRICERW,
         HIGHESTCLOSEPRICERW,
         LOWESTCLOSEPRICERW,
         AVGPRICERW,
         CHANGEOFPRICERW,
         CHANGEPCTRW,
         TURNOVERRATERW,
         AVGTURNOVERRATERW,
         RANGEPCTRW,
         TURNOVERVOLUMERW,
         TURNOVERVALUERW,
         DISCOUNTRW,
         DISCOUNTRATIORW,
         HIGHPRICERWDATE,
         LOWPRICERWDATE,
         HIGHESTCLOSEPRICERWDATE,
         LOWESTCLOSEPRICERWDATE,
         CHANGEPCTTOINDEXRW,
         PREVCLOSEPRICERM,
         OPENPRICERM,
         HIGHPRICERM,
         LOWPRICERM,
         CLOSEPRICERM,
         HIGHESTCLOSEPRICERM,
         LOWESTCLOSEPRICERM,
         AVGPRICERM,
         CHANGEOFPRICERM,
         CHANGEPCTRM,
         TURNOVERRATERM,
         AVGTURNOVERRATERM,
         RANGEPCTRM,
         TURNOVERVOLUMERM,
         TURNOVERVALUERM,
         DISCOUNTRM,
         DISCOUNTRATIORM,
         HIGHPRICERMDATE,
         LOWPRICERMDATE,
         HIGHESTCLOSEPRICERMDATE,
         LOWESTCLOSEPRICERMDATE,
         CHANGEPCTTOINDEXRM,
         PREVCLOSEPRICERY,
         OPENPRICERY,
         HIGHPRICERY,
         LOWPRICERY,
         CLOSEPRICERY,
         HIGHESTCLOSEPRICERY,
         LOWESTCLOSEPRICERY,
         AVGPRICERY,
         CHANGEOFPRICERY,
         CHANGEPCTRY,
         TURNOVERRATERY,
         AVGTURNOVERRATERY,
         RANGEPCTRY,
         TURNOVERVOLUMERY,
         TURNOVERVALUERY,
         DISCOUNTRY,
         DISCOUNTRATIORY,
         HIGHPRICERYDATE,
         LOWPRICERYDATE,
         HIGHESTCLOSEPRICERYDATE,
         LOWESTCLOSEPRICERYDATE,
         CHANGEPCTTOINDEXRY,
         UPDATETIME,
         JSID)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.TRADINGDAY,
         N.PREVCLOSEPRICE,
         N.OPENPRICE,
         N.HIGHPRICE,
         N.LOWPRICE,
         N.CLOSEPRICE,
         N.AVGPRICE,
         N.CHANGEOFPRICE,
         N.CHANGEPCT,
         N.TURNOVERRATE,
         N.TURNOVERVOLUME,
         N.TURNOVERVALUE,
         N.VIBRATIONRANGE,
         N.DISCOUNT,
         N.DISCOUNTRATIO,
         N.PREVCLOSEPRICERW,
         N.OPENPRICERW,
         N.HIGHPRICERW,
         N.LOWPRICERW,
         N.CLOSEPRICERW,
         N.HIGHESTCLOSEPRICERW,
         N.LOWESTCLOSEPRICERW,
         N.AVGPRICERW,
         N.CHANGEOFPRICERW,
         N.CHANGEPCTRW,
         N.TURNOVERRATERW,
         N.AVGTURNOVERRATERW,
         N.RANGEPCTRW,
         N.TURNOVERVOLUMERW,
         N.TURNOVERVALUERW,
         N.DISCOUNTRW,
         N.DISCOUNTRATIORW,
         N.HIGHPRICERWDATE,
         N.LOWPRICERWDATE,
         N.HIGHESTCLOSEPRICERWDATE,
         N.LOWESTCLOSEPRICERWDATE,
         N.CHANGEPCTTOINDEXRW,
         N.PREVCLOSEPRICERM,
         N.OPENPRICERM,
         N.HIGHPRICERM,
         N.LOWPRICERM,
         N.CLOSEPRICERM,
         N.HIGHESTCLOSEPRICERM,
         N.LOWESTCLOSEPRICERM,
         N.AVGPRICERM,
         N.CHANGEOFPRICERM,
         N.CHANGEPCTRM,
         N.TURNOVERRATERM,
         N.AVGTURNOVERRATERM,
         N.RANGEPCTRM,
         N.TURNOVERVOLUMERM,
         N.TURNOVERVALUERM,
         N.DISCOUNTRM,
         N.DISCOUNTRATIORM,
         N.HIGHPRICERMDATE,
         N.LOWPRICERMDATE,
         N.HIGHESTCLOSEPRICERMDATE,
         N.LOWESTCLOSEPRICERMDATE,
         N.CHANGEPCTTOINDEXRM,
         N.PREVCLOSEPRICERY,
         N.OPENPRICERY,
         N.HIGHPRICERY,
         N.LOWPRICERY,
         N.CLOSEPRICERY,
         N.HIGHESTCLOSEPRICERY,
         N.LOWESTCLOSEPRICERY,
         N.AVGPRICERY,
         N.CHANGEOFPRICERY,
         N.CHANGEPCTRY,
         N.TURNOVERRATERY,
         N.AVGTURNOVERRATERY,
         N.RANGEPCTRY,
         N.TURNOVERVOLUMERY,
         N.TURNOVERVALUERY,
         N.DISCOUNTRY,
         N.DISCOUNTRATIORY,
         N.HIGHPRICERYDATE,
         N.LOWPRICERYDATE,
         N.HIGHESTCLOSEPRICERYDATE,
         N.LOWESTCLOSEPRICERYDATE,
         N.CHANGEPCTTOINDEXRY,
         N.UPDATETIME,
         N.JSID);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金临时公告
  PROCEDURE PRO_MF_INTERIMBULLETIN(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER) AS

  BEGIN
    MERGE INTO SRC_PIF.MF_INTERIMBULLETIN M
    USING (SELECT ID,
                  BULLETINDATE,
                  INFOTITLE,
                  DETAIL,
                  BULLETINTYPE,
                  MARKET,
                  MEDIA,
                  XGRQ,
                  JSID,
                  RECORDDATE
             FROM JYDB.MF_INTERIMBULLETIN@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)

    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         BULLETINDATE,
         INFOTITLE,
         DETAIL,
         BULLETINTYPE,
         MARKET,
         MEDIA,
         XGRQ,
         JSID,
         RECORDDATE)
      VALUES
        (N.ID,
         N.BULLETINDATE,
         N.INFOTITLE,
         N.DETAIL,
         N.BULLETINTYPE,
         N.MARKET,
         N.MEDIA,
         N.XGRQ,
         N.JSID,
         N.RECORDDATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --基金公告原文
  PROCEDURE PRO_MF_ANNOUNCEMENT(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER)

   AS

  BEGIN
    MERGE INTO SRC_PIF.MF_ANNOUNCEMENT M
    USING (SELECT ID,
                  INNERCODE,
                  INFOPUBLDATE,
                  MEDIA,
                  CATEGORY,
                  INFOTITLE,
                  SERIALNUMBER,
                  SUBTITLE,
                  CONTENT,
                  XGRQ,
                  JSID,
                  RECORDDATE,
                  ENDDATE
             FROM JYDB.MF_ANNOUNCEMENT@JYZX
            WHERE JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)

    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         INFOPUBLDATE,
         MEDIA,
         CATEGORY,
         INFOTITLE,
         SERIALNUMBER,
         SUBTITLE,
         CONTENT,
         XGRQ,
         JSID,
         RECORDDATE,
         ENDDATE)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.INFOPUBLDATE,
         N.MEDIA,
         N.CATEGORY,
         N.INFOTITLE,
         N.SERIALNUMBER,
         N.SUBTITLE,
         N.CONTENT,
         N.XGRQ,
         N.JSID,
         N.RECORDDATE,
         N.ENDDATE);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

  --指数行情  INNERCODE IN(3145 ,4978,1,1055,7542,11089)
  PROCEDURE PRO_QT_INDEXQUOTE(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER) AS

  BEGIN

    MERGE INTO SRC_PIF.QT_INDEXQUOTE M
    USING (SELECT ID,
                  INNERCODE,
                  TRADINGDAY,
                  PREVCLOSEPRICE,
                  OPENPRICE,
                  HIGHPRICE,
                  LOWPRICE,
                  CLOSEPRICE,
                  TURNOVERVOLUME,
                  TURNOVERVALUE,
                  TURNOVERDEALS,
                  CHANGEPCT,
                  XGRQ,
                  JSID,
                  NEGOTIABLEMV
             FROM JYDB.QT_INDEXQUOTE@JYZX
            WHERE INNERCODE IN(3145,4978,1,1055,7542,11089) AND JSID > I_TBBZZDZ) N
    ON (M.ID = N.ID)

    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         INNERCODE,
         TRADINGDAY,
         PREVCLOSEPRICE,
         OPENPRICE,
         HIGHPRICE,
         LOWPRICE,
         CLOSEPRICE,
         TURNOVERVOLUME,
         TURNOVERVALUE,
         TURNOVERDEALS,
         CHANGEPCT,
         XGRQ,
         JSID,
         NEGOTIABLEMV)
      VALUES
        (N.ID,
         N.INNERCODE,
         N.TRADINGDAY,
         N.PREVCLOSEPRICE,
         N.OPENPRICE,
         N.HIGHPRICE,
         N.LOWPRICE,
         N.CLOSEPRICE,
         N.TURNOVERVOLUME,
         N.TURNOVERVALUE,
         N.TURNOVERDEALS,
         N.CHANGEPCT,
         N.XGRQ,
         N.JSID,
         N.NEGOTIABLEMV);

    O_ROWCOUNT := SQL%ROWCOUNT;
    O_CODE     := 1;
    O_NOTE     := '成功！';
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_ROWCOUNT := 0;
      O_CODE     := -1;
      O_NOTE     := '错误：' || SQLERRM;
  END;

END;

/

