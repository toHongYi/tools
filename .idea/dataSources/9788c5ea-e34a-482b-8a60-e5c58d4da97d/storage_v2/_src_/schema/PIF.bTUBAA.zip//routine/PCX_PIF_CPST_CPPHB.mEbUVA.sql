create PROCEDURE PCX_PIF_CPST_CPPHB(O_CODE             OUT NUMBER,
                                               O_NOTE             OUT VARCHAR2,
                                               O_RESULT           OUT SYS_REFCURSOR,
                                               I_STATISTIC_PERIOD IN NUMBER, --统计周期:1|近1月2|近3月3|近6月4|近1年5|近3年
                                               I_TYPE             IN NUMBER --类型:2|产品销量榜3|保有量贡献榜4|营业部日均资产规模5|管理人日均资产规模
                                               
                                               ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：产品视图-产品排行榜
             参数说明：
                  入参：
                         I_STATISTIC_PERIOD IN NUMBER, --统计周期:1|近1月2|近3月3|近6月4|近1年5|近3年
                         I_TYPE             IN NUMBER --类型:1|产品销量榜2|保有量贡献榜3|定投销量榜4|自选关注榜
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
        LIUTX      1.1    2021/10/12                   调整销量，调整收入为保有量
        liutx      1.2    2021/12/9                    新增 4|营业部日均资产规模5|管理人日均资产规模
  -----------------------------------------------------------------------------------------------*/
  V_SQL VARCHAR2(10000);
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_STATISTIC_PERIOD IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_STATISTIC_PERIOD不能为空!';
    RETURN;
  END IF;

  IF I_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TYPE不能为空!';
    RETURN;
  END IF;
  --2|产品销量榜
  IF I_TYPE = 2 THEN
  
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.XSL DESC) AS RANK,';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.XSL DESC) AS RANK,';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.XSL DESC) AS RANK,';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 4 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.XSL DESC) AS RANK,';
    
      --近3年
    ELSE
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.XSL DESC) AS RANK,';
    
    END IF;
  
    V_SQL := V_SQL ||
             'B.ID AS PROD_ID,
     B.CPDM AS PROD_CODE,
     B.CPMC AS PROD_NAME,
     (SELECT NAME FROM TPIF_JRCPFL WHERE ID=B.JRCPFL) AS PROD_TYPE,--产品类型
     (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=B.CPFXDJ) AS PROD_RISK_LEVEL，--产品风险等级
      B.CLRQ AS ESTABLISH_DATE, 
      B.DQRQ AS EXPIRE_DATE, 
      B.CPQX AS PROD_TERM, 
      --TO_CHAR(A.DWJZ,''FM99990.0999'') AS UNIT_NAV, ';
  
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := V_SQL || '  
      A.XSL AS SALE_SCALE,
      0 AS  SALE_INCOME,
      0 AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(XSL) / 10000, 2) XSL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF = TO_CHAR(SYSDATE,''YYYYMM'')
         GROUP BY CPDM) A';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
      V_SQL := V_SQL || '  
      A.XSL AS SALE_SCALE,
      0 AS  SALE_INCOME,
      0 AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(XSL) / 10000, 2) XSL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-2),''YYYYMM'')
         GROUP BY CPDM) A';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
      V_SQL := V_SQL || '  
      A.XSL AS SALE_SCALE,
      0 AS  SALE_INCOME,
      0 AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(XSL) / 10000, 2) XSL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-5),''YYYYMM'')
         GROUP BY CPDM) A';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 4 THEN
      V_SQL := V_SQL || '  
      A.XSL AS SALE_SCALE,
      0 AS  SALE_INCOME,
      0 AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(XSL) / 10000, 2) XSL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-11),''YYYYMM'')
         GROUP BY CPDM) A';
    
      --近3年
    ELSE
      V_SQL := V_SQL || '  
      A.XSL AS SALE_SCALE,
      0 AS  SALE_INCOME,
      0 AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(XSL) / 10000, 2) XSL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-35),''YYYYMM'')
         GROUP BY CPDM) A';
    
    END IF;
  
    V_SQL := V_SQL || '  ,TPIF_CPDM B
    WHERE A.CPDM= B.CPDM
      AND B.CPNBZT = 8';
  
    OPEN O_RESULT FOR 'SELECT * FROM (' || V_SQL || ')  WHERE RANK <=10  ORDER BY RANK ASC ';
  
    --3|保有量贡献榜
  ELSIF I_TYPE = 3 THEN
  
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.NBYL DESC) AS RANK,';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.NBYL DESC) AS RANK,';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.NBYL DESC) AS RANK,';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 4 THEN
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.NBYL DESC) AS RANK,';
    
      --近3年
    ELSE
    
      V_SQL := ' SELECT row_number()over(ORDER BY A.NBYL DESC) AS RANK,';
    
    END IF;
  
    V_SQL := V_SQL || 'B.ID AS PROD_ID,
       B.CPDM AS PROD_CODE,
       B.CPMC AS PROD_NAME,
       (SELECT NAME FROM TPIF_JRCPFL WHERE ID=B.JRCPFL) AS PROD_TYPE,--产品类型
       (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=B.CPFXDJ) AS PROD_RISK_LEVEL，--产品风险等级
        B.CLRQ AS ESTABLISH_DATE, 
        B.DQRQ AS EXPIRE_DATE, 
        B.CPQX AS PROD_TERM, 
        --TO_CHAR(A.DWJZ,''FM99990.0999'') AS UNIT_NAV,
        0 AS SALE_SCALE, ';
  
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := V_SQL || ' 
        A.NBYL AS  SALE_INCOME,
        (SELECT COUNT(*) FROM TPIF_WGZDCP WHERE CPID=B.CPID) AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(NBYL) / 10000, 2) NBYL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF = TO_CHAR(SYSDATE,''YYYYMM'')
         GROUP BY CPDM)  A';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
      V_SQL := V_SQL || ' 
        A.NBYL AS  SALE_INCOME,
        (SELECT COUNT(*) FROM TPIF_WGZDCP WHERE CPID=B.CPID) AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(NBYL) / 10000, 2) NBYL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-2),''YYYYMM'')
         GROUP BY CPDM)  A';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
      V_SQL := V_SQL || ' 
        A.NBYL AS  SALE_INCOME,
        (SELECT COUNT(*) FROM TPIF_WGZDCP WHERE CPID=B.CPID) AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(NBYL) / 10000, 2) NBYL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-5),''YYYYMM'')
         GROUP BY CPDM)  A';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
      V_SQL := V_SQL || ' 
        A.NBYL AS  SALE_INCOME,
        (SELECT COUNT(*) FROM TPIF_WGZDCP WHERE CPID=B.CPID) AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(NBYL) / 10000, 2) NBYL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-11),''YYYYMM'')
         GROUP BY CPDM)  A';
    
      --近3年
    ELSE
      V_SQL := V_SQL || ' 
        A.NBYL AS  SALE_INCOME,
        (SELECT COUNT(*) FROM TPIF_WGZDCP WHERE CPID=B.CPID) AS CONCERN_NUM
     FROM (SELECT CPDM, ROUND(SUM(NBYL) / 10000, 2) NBYL
          FROM DSC_STAT.TPIF_STAT_CPDXYB
         WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE,-35),''YYYYMM'')
         GROUP BY CPDM)  A';
    
    END IF;
  
    V_SQL := V_SQL || ',TPIF_CPDM B
      WHERE A.CPDM= B.CPDM
        AND B.CPNBZT = 8';
  
    OPEN O_RESULT FOR 'SELECT * FROM (' || V_SQL || ')  WHERE RANK <=10 ORDER BY RANK ASC ';
  
    --4|营业部日均资产规模
  ELSIF I_TYPE = 4 THEN
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := 'SELECT *
  FROM (SELECT FZJG PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
          FROM DSC_STAT.TPIF_STAT_ZC
         WHERE FZJGDM != 0
           AND TJYF = TO_CHAR(SYSDATE,''YYYYMM'')
         GROUP BY FZJG)
 ORDER BY SALE_SCALE DESC';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
      V_SQL := 'SELECT *
  FROM (SELECT FZJG PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
          FROM DSC_STAT.TPIF_STAT_ZC
         WHERE FZJGDM != 0
           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-2),''YYYYMM'')
         GROUP BY FZJG)
 ORDER BY SALE_SCALE DESC';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
      V_SQL := 'SELECT *
  FROM (SELECT FZJG PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
          FROM DSC_STAT.TPIF_STAT_ZC
         WHERE FZJGDM != 0
           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-5),''YYYYMM'')
         GROUP BY FZJG)
 ORDER BY SALE_SCALE DESC';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 4 THEN
      V_SQL := 'SELECT *
  FROM (SELECT FZJG PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
          FROM DSC_STAT.TPIF_STAT_ZC
         WHERE FZJGDM != 0
           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-11),''YYYYMM'')
         GROUP BY FZJG)
 ORDER BY SALE_SCALE DESC';
    
      --近3年
    ELSE
      V_SQL := 'SELECT *
  FROM (SELECT FZJG PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
          FROM DSC_STAT.TPIF_STAT_ZC
         WHERE FZJGDM != 0
           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-35),''YYYYMM'')
         GROUP BY FZJG)
 ORDER BY SALE_SCALE DESC';
    
    END IF;
  
    OPEN O_RESULT FOR 'SELECT ROWNUM AS RANK ,A.* FROM (' || V_SQL || ') A WHERE ROWNUM <=10  ORDER BY  RANK ASC ';
  
    --5|管理人日均资产规模
  ELSIF I_TYPE = 5 THEN
  
    --近1月
    IF I_STATISTIC_PERIOD = 1 THEN
    
      V_SQL := 'SELECT *
                  FROM (SELECT CPGLRMC PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
                          FROM DSC_STAT.TPIF_STAT_ZC
                         WHERE CPGLRMC IS NOT NULL
                           AND FZJGDM != 0
                           AND TJYF = TO_CHAR(SYSDATE, '' YYYYMM '')
                         GROUP BY CPGLRMC)
                 ORDER BY SALE_SCALE DESC';
    
      --近3月
    ELSIF I_STATISTIC_PERIOD = 2 THEN
      V_SQL := 'SELECT *
                  FROM (SELECT CPGLRMC PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
                          FROM DSC_STAT.TPIF_STAT_ZC
                         WHERE CPGLRMC IS NOT NULL
                           AND FZJGDM != 0
                           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-2),''YYYYMM'')
                         GROUP BY CPGLRMC)
                   ORDER BY SALE_SCALE DESC';
    
      --近半年
    ELSIF I_STATISTIC_PERIOD = 3 THEN
      V_SQL := 'SELECT *
                  FROM (SELECT CPGLRMC PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
                          FROM DSC_STAT.TPIF_STAT_ZC
                         WHERE CPGLRMC IS NOT NULL
                           AND FZJGDM != 0
                           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-5),''YYYYMM'')
                         GROUP BY CPGLRMC)
                   ORDER BY SALE_SCALE DESC';
    
      --近1年
    ELSIF I_STATISTIC_PERIOD = 4 THEN
      V_SQL := 'SELECT *
                  FROM (SELECT CPGLRMC PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
                          FROM DSC_STAT.TPIF_STAT_ZC
                         WHERE CPGLRMC IS NOT NULL
                           AND FZJGDM != 0
                           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-11),''YYYYMM'')
                         GROUP BY CPGLRMC)
                   ORDER BY SALE_SCALE DESC';
    
      --近3年
    ELSE
      V_SQL := 'SELECT *
                  FROM (SELECT CPGLRMC PROD_NAME, ROUND(SUM(NRJZC) / 10000, 2) AS SALE_SCALE
                          FROM DSC_STAT.TPIF_STAT_ZC
                         WHERE CPGLRMC IS NOT NULL
                           AND FZJGDM != 0
                           AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE,-35),''YYYYMM'')
                         GROUP BY CPGLRMC)
                   ORDER BY SALE_SCALE DESC';
    
    END IF;
  
    OPEN O_RESULT FOR 'SELECT ROWNUM AS RANK ,A.* FROM (' || V_SQL || ') A WHERE ROWNUM <=10  ORDER BY  RANK ASC ';
  
  END IF;
  DBMS_OUTPUT.put_line('SELECT ROWNUM as rank ,a.* FROM (' || V_SQL ||
                       ') a WHERE ROWNUM <=10  ORDER BY  RANK ASC ');

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

