create PROCEDURE PRO_PIF_YYGL_YYBPLXZ(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2,
                                              I_IDS  IN VARCHAR2, --ID串
                                              I_KYRS IN NUMBER,
                                              I_KYJE IN NUMBER,
                                              I_CPGLID IN NUMBER --产品管理ID

                                              ) AS
 /******************************************************************
      所属用户：PIF
      功能说明：对产品下的营业部限额，批量新增
      语法信息：
           输入参数：     I_CPGLID  产品预约管理ID
                                 I_CZR   操作人
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                              
      逻辑说明：                          
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WEIWENHAO        营业部批量新增
  ***********************************************************************/


V_COUNT NUMBER; --计数
V_KYJE NUMBER(16,2); --可约金额
V_KYRS NUMBER; --可约人数
V_IDS   VARCHAR2(5000);
V_LEN   NUMBER; --长度
V_NUM   NUMBER := 1;
V_CPGLID NUMBER;
V_ID    NUMBER;
V_FLAG NUMBER;
SUM_YYJE NUMBER; --批量新增总额度
SUM_YYRS NUMBER; --批量新增总人数
V_CPYY_YYJE NUMBER; --现有营业部总额度
V_CPYY_YYRS NUMBER; --现有营业部总人数
MAX_YYRS NUMBER; --产品设置最大额度
MAX_YYJE NUMBER; --产品设置最大预约人数
V_GLCPID NUMBER; --关联产品ID
V_COUNT_IDS NUMBER; --ID数量

    BEGIN
  O_CODE := -1;
  O_NOTE := '';
  V_IDS  := ';'||I_IDS || ';';
  V_CPGLID:=I_CPGLID;
  V_KYJE:=I_KYJE;
  V_KYRS:=I_KYRS;


  --获取需要插入的ID数量
  SELECT LENGTH(V_IDS) - LENGTH(REPLACE(V_IDS, ';'))-1
    INTO V_COUNT_IDS
    FROM DUAL;
SELECT GLCPID INTO V_GLCPID FROM TPIF_YYCPGL  WHERE ID = V_CPGLID;
SELECT COUNT(1)  INTO  V_COUNT FROM TPIF_YYCPGL WHERE GLCPID = V_CPGLID;
--查询该产品是否进行关联
  --获取产品预约总额度
  SELECT YYZRS,YYZED,GLCPID INTO MAX_YYRS,MAX_YYJE,V_GLCPID FROM TPIF_YYCPGL  WHERE ID = V_CPGLID;
  
IF  V_GLCPID  IS NOT NULL THEN
  --产品有关联，获取本批次和共享批次的营业部独享额度
  SELECT SUM(ZKYED),SUM(ZKYRS) INTO V_CPYY_YYJE,V_CPYY_YYRS FROM  PIF.TPIF_YYBXE WHERE CPGLID 
  IN (SELECT ID FROM TPIF_YYCPGL WHERE (ID =V_GLCPID OR GLCPID = V_GLCPID) );

  
  
IF V_CPYY_YYJE IS NULL THEN
  V_CPYY_YYJE:=0;
END IF;
IF V_CPYY_YYRS IS NULL THEN
    V_CPYY_YYRS:=0;
    END IF;
ELSIF(V_COUNT >0) THEN    

    SELECT SUM(ZKYED),SUM(ZKYRS) INTO V_CPYY_YYJE,V_CPYY_YYRS FROM  PIF.TPIF_YYBXE WHERE CPGLID 
  IN (SELECT ID FROM TPIF_YYCPGL WHERE (ID =V_CPGLID OR GLCPID = V_CPGLID) );


ELSE 

--获取本批次该产品营业部独享额度
SELECT SUM(ZKYED),SUM(ZKYRS)  INTO V_CPYY_YYJE,V_CPYY_YYRS FROM PIF.TPIF_YYBXE WHERE CPGLID =V_CPGLID;
   END IF; 
IF V_CPYY_YYJE IS NULL THEN
  V_CPYY_YYJE:=0;
END IF;
IF V_CPYY_YYRS IS NULL THEN
    V_CPYY_YYRS:=0;
    END IF;

SUM_YYJE:=V_KYJE * V_COUNT_IDS;
SUM_YYRS:=V_KYRS * V_COUNT_IDS;
  

   IF V_COUNT_IDS = 1 THEN
     SELECT COUNT(1) INTO V_FLAG FROM PIF.TPIF_YYBXE WHERE CPGLID = V_CPGLID AND YYBID =I_IDS;
     IF V_FLAG >0 THEN
        O_NOTE := '所加入的营业部已设置，请勿重复设置!';
        ROLLBACK;
        RETURN;
      END IF;

  INSERT INTO PIF.TPIF_YYBXE
      (ID,
       YYBID,
       ZKYED,
       ZKYRS,
       CPGLID,
       YYRS,
       YYJE,
       CCKHYYJE,
       CCKHYYSL)
  VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_YYBXE'),
       I_IDS,
       V_KYJE,
       V_KYRS,
       V_CPGLID,
       0,
       0,
       0,
       0);

  ELSE
    WHILE V_NUM <= V_COUNT_IDS LOOP
      SELECT INSTR(V_IDS, ';', 1, V_NUM+1) -
             INSTR(V_IDS, ';', 1, V_NUM) -1
        INTO V_LEN
        FROM DUAL;

      SELECT TO_NUMBER(SUBSTR(V_IDS,
                              INSTR(V_IDS, ';', 1, V_NUM)+1,
                              V_LEN))
        INTO V_ID
        FROM DUAL;
 SELECT COUNT(1) INTO V_FLAG FROM PIF.TPIF_YYBXE WHERE CPGLID = V_CPGLID AND YYBID =V_ID;
         IF V_FLAG >0 THEN
        O_NOTE := '所加入的营业部已设置，请勿重复设置!';
        ROLLBACK;
        RETURN;
      END IF;

        INSERT INTO PIF.TPIF_YYBXE
      (ID,
       YYBID,
       ZKYED,
       ZKYRS,
       CPGLID,
       YYRS,
       YYJE,
       CCKHYYJE,
       CCKHYYSL)
  VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_YYBXE'),
       V_ID,
         V_KYJE,
       V_KYRS,
       V_CPGLID,
       0,
       0,
       0,
       0);
        V_NUM:=V_NUM+1;
        END LOOP;
  END IF;
--产品预约额度为0即为无限制
IF MAX_YYJE <>0 THEN
  
  IF SUM_YYJE >(MAX_YYJE-V_CPYY_YYJE) THEN
    O_NOTE:='设置预约额度大于产品总额度!';
    ROLLBACK;
    RETURN;
    END IF;
END IF;
    IF SUM_YYRS >(MAX_YYRS-V_CPYY_YYRS) THEN
       O_NOTE:='设置预约人数大于产品总可预约人数!';
       ROLLBACK;
       RETURN;
    END IF;




    O_CODE:= 199;
O_NOTE := '批量新增成功!';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
           ROLLBACK;
END;
/

