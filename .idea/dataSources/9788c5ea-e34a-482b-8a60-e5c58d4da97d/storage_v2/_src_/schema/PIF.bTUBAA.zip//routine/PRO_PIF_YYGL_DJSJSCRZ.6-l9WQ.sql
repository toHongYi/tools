create PROCEDURE PRO_PIF_YYGL_DJSJSCRZ(O_CODE   OUT NUMBER,
                                                      O_NOTE   OUT VARCHAR2,
                                                      I_SJLX   VARCHAR2, --事件类型
                                                      I_ZXRQ   NUMBER, --执行日期
                                                      I_ZXKSSJ DATE, --执行开始时间
                                                      I_ZXJSSJ DATE, --执行结束时间
                                                      I_ZXZT   INTEGER, --执行状态
                                                      I_CLSJS  NUMBER, --处理事件数
                                                      I_CGSJS  NUMBER, --成功事件数
                                                      I_HS     NUMBER, --耗时
                                                      I_ZXJG   VARCHAR2, --执行结果
                                                      I_RZLX   IN NUMBER --1|日常;2|重做;3|调整
                                                      ) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：登记事件生成日志
            I_SJLX   VARCHAR2,--事件类型
            I_ZXRQ  NUMBER,--执行日期
            I_ZXKSSJ  DATE,--执行开始时间
            I_ZXJSSJ  DATE,--执行结束时间
            I_ZXZT INTEGER,--执行状态
            I_CLSJS  NUMBER, --处理事件数
            I_CGSJS NUMBER, --成功事件数
            I_HS  NUMBER,--耗时
            I_ZXJG  NUMBER --执行结果
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
         关联调度
    运行原理：
          1.入参校验
          --1.1入参校验
          --1.2初始赋值
          2.更新产品事件类型。
          3.生成产品事件生成日志。
    功能修订：
        简要说明：
          登记事件生成日志
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/14     1.0.1     林嵩               登记事件生成日志。
        2014/12/10     1.0.2     刘浪浪            日志增加日志类型字段
    *********************************************************************************************************************/
    V_RQ NUMBER(8) DEFAULT I_ZXRQ; --当前日期
BEGIN

    O_CODE := 1;
    O_NOTE := '成功';
    --1.***************************入参校验 ***************************
    --当前变量赋值
    IF V_RQ IS NULL THEN
        V_RQ := TO_CHAR(SYSDATE, 'yyyymmdd');
    END IF;
    --更新事件类型
    UPDATE TPIF_CPSJLX A
       SET A.ZJZXRQ   = V_RQ,
           A.ZJZXKSSJ = I_ZXKSSJ,
           A.ZJZXJSSJ = I_ZXJSSJ,
           A.CLSJS    = I_CLSJS,
           A.HS       = I_HS,
           A.ZJZXJG   = I_ZXJG,
           A.CGSJS    = I_CGSJS,
           A.ZJZXZT   = I_ZXZT
     WHERE ID = I_SJLX;
    --记录日志。
    INSERT INTO TPIF_SJLXSCRZ
        (ID, CPSJLX, ZXRQ, ZXKSSJ, ZXJSSJ, CLSJS, HS, ZXJG, CGSJS, ZXZT, RZLX)
        SELECT SEQ_TPIF_SJLXSCRZ.NEXTVAL,
               A.ID,
               A.ZJZXRQ,
               A.ZJZXKSSJ,
               A.ZJZXJSSJ,
               A.CLSJS,
               A.HS,
               A.ZJZXJG,
               A.CGSJS,
               A.ZJZXZT,
               I_RZLX
          FROM TPIF_CPSJLX A
         WHERE A.ID = I_SJLX;
    --.提交数据
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_DJSJSCRZ;
/

