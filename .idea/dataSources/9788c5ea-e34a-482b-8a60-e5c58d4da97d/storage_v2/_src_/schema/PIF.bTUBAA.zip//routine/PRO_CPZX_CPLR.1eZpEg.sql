create PROCEDURE     PRO_CPZX_CPLR(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2,
                                              I_ID   IN NUMBER) AS
  /******************************************************************************
  *
  *文件名称：PRO_CPZX_FXDJPF
  *项目名称：东方c产品中心,  录入产品
  *
  *创建人员：yc
  *创建日期：20170512
  *功能说明：产品风险等级评分

    *------------------------------------------------------------------------------
    *
    *修改者        版本号        修改日期        说明
    * 杨超         1.0.0        20170531        创建
    * 杨超         1.0.0        20170623       修改新增字段，并调整写法。
    *xuubaohua                  20170817       新增update录入时间
    *倪森波                     20180326       pb，新增字段
    *许龙全                     20190326        产品标签改造
    ******************************************************************************/
  V_COUNT  NUMBER(10);
  V_COUNT1 NUMBER(10);
  V_COUNT2 NUMBER(10);
  --V_COUNT3 NUMBER(10);
  V_COUNT4 NUMBER(10);
  --V_COUNT5 NUMBER(10);
  V_COUNT6 NUMBER(10);
  --V_CPID NUMBER(10);
  V_LRLX NUMBER(10);
  V_CPMC VARCHAR2(100);
  V_CPDL NUMBER(10);
  V_CPLX NUMBER(10);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';
  
  SELECT NVL(CPMC, 0), LRLX
    INTO V_CPMC, V_LRLX
    FROM PIF.LC_CPXZ_SDXJ
   WHERE ID = I_ID;
  
  --SELECT COUNT(*) INTO V_COUNT1 FROM PIF.TPIF_CPBQB WHERE A.CPMC=V_CPMC
  ------------------------------ 5 私募企业金融产品属性是否存在
  SELECT COUNT(*)
    INTO V_COUNT4
    FROM pif.TPIF_CPDM_SMQYJR A
   WHERE A.cpmc = V_CPMC;

  --------------插入产品总表
  select count(*) into V_COUNT6 from pif.TPIF_CPDMZB where cpmc = V_CPMC;

  --FOR Y IN (SELECT * FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID) LOOP
    /*UPDATE PIF.TPIF_CPFLB SET CPDM=(SELECT CPDM FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
                              TZQTLX=Y.TZQTLX,
                              JEXX=Y.JEXX,
                              JESX=Y.*/
    
    
  for X in (select * from PIF.LC_CPXZ_SDXJ WHERE ID = I_ID) LOOP
    if V_COUNT6 = 1 THEN
      --更新产品费率表
      /*UPDATE PIF.TPIF_CPFLB A
      SET (TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ)=(SELECT TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ
                                                       FROM PIF.LC_CPXZ_SDXJ_CPFL B
                                                       WHERE B.LC_CPXZ_SDXJ_ID=I_ID
                                                       AND A.FLLX=B.FLLX)
      WHERE A.CPMC=(SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID);
      UPDATE PIF.TPIF_CPFLB SET CPDM=X.CPDM WHERE CPMC=X.CPMC;*/
      DELETE PIF.TPIF_CPFLB WHERE CPMC=X.CPMC;
      
      INSERT INTO PIF.TPIF_CPFLB (ID,CPDM,CPMC,FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ)
      SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPFLB'),
             (SELECT CPDM FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ
      FROM PIF.LC_CPXZ_SDXJ_CPFL B
      WHERE B.LC_CPXZ_SDXJ_ID=I_ID;
      --更新产品标签表
      UPDATE PIF.TPIF_CPBQB A
      SET (BQZ,BZ)=(SELECT CASE WHEN BQZDX IS NOT NULL THEN TO_CHAR(BQZDX)
                                ELSE BQZBDXXZ END,BZ
                    FROM PIF.LC_CPXZ_SDXJ_CPBQ B
                    WHERE B.LC_CPXZ_SDXJ_ID=I_ID
                    AND A.BQMC=B.BQMC)
      WHERE A.CPMC=X.CPMC;
      UPDATE PIF.TPIF_CPBQB SET CPDM=X.CPDM WHERE CPMC=X.CPMC;
      --更新产品代码总表
      UPDATE PIF.TPIF_CPDMZB 
     SET CPDM = X.CPDM,--产品代码 
         --CPMC           ,--产品全称
         --LRLX           ,--录入类型
         --CPLX           ,--产品大类
         TZPZ = X.TZPZ,--投资品种
         TZQX = X.TZQX,--投资期限
         FXDJ = X.FXDJ,--风险等级
         CPZT = X.CPZT,--(CASE WHEN X.LRLX = 5 THEN NULL ELSE X.CPZT END)           ,--产品状态
         CLR = X.CLR,--(CASE WHEN X.LRLX = 5 THEN NULL ELSE X.CLR END),--成立日         
         DQR = X.DQR,--(CASE WHEN X.LRLX = 5 THEN NULL ELSE X.DQR END),--到期日    
         SYL = X.SYL,--收益率
         ZDYQSYL = (CASE WHEN X.LRLX = 5 THEN NULL ELSE X.ZDYQSYL END),--最低预期收益率(%)         
         ZGYQSYL = (CASE WHEN X.LRLX = 5 THEN NULL ELSE X.ZGYQSYL END),--最高预期收益率(%)        
         RGQD = (CASE WHEN X.LRLX = 5 THEN NULL ELSE X.RGQD END)          ,--认购起点(万元)         
         SFCZMDM = X.SFCZMDM,--是否存在母代码
         MCPDM = X.MCPDM,--母产品代码         
         MCPMC = X.MCPMC,--母产品名称         
         SHZT = 2,--审核状态         
         CPJZ = X.CPJZ,--产品净值
         --CPGM_FE        ,--产品规模_份额(万份)         
         --CPGM_JE        ,--产品规模_金额         
         --JJJL           ,--基金经理         
         --QYFL           ,--是否为权益类
         --HJFL           ,--是否为货币基金         
         --WINDFL         ,--WIND分类         
         --SYPZFL         ,--是否收益凭证         
         --ABSFL          ,--是否ABS产品
         --JYNSYL         ,--近一年收益率         
         --JXGZ           ,--计息规则         
         --KFZT           ,--开放状态         
         --GLRLX = X.GLRLX,--管理人类型
         --TZFW = X.TZFW,--投资范围         
         --FGYQRGQD = X.FGYQRGQD,--法规要求认购起点         
         --CPXS = X.CPXS,--产品形式         
         --GLRSFWDFZQHZGS = X.GLRSFWDFZQHZGS,--管理人是否为东方证券或子公司
         --SFDFZQWB = X.SFDFZQWB,--是否东方证券外包         
         --SFDFZQTG = X.SFDFZQTG,--是否东方证券托管         
         --SFGPCWSC = X.SFGPCWSC       ,--是否挂牌场外市场         
         --SFKZR = X.SFKZR          ,--是否可转让
         --SFZDCP = X.SFZDCP         ,--是否重点产品         
         ZDDYNF = X.ZDDYNF         ,--重点对应年份         
         CPJC = X.CPJC           ,--产品简称         
         CPRGDM = X.CPRGDM         ,--产品认购代码
         CPHGDM = X.CPHGDM         ,--产品换购代码         
         CPJYDM = X.CPJYDM         ,--产品交易代码         
         CPJL = X.CPJL           ,--产品经理         
         CPJLBH = X.CPJLBH         ,--产品经理编号
         CPZJZH = X.CPZJZH         ,--产品资金账号         
         ZYJYDYBH = X.ZYJYDYBH       ,--租用交易单元编号         
         CPGLR = X.CPGLR          ,--产品管理人         
         CPTZJL = X.CPTZJL         ,--产品投资经理
         CPGLRLXR = X.CPGLRLXR       ,--产品管理人联系人         
         CPGLRLXRLXFS = X.CPGLRLXRLXFS   ,--产品管理人联系人联系方式         
         CPTGR = X.CPTGR          ,--产品托管人         
         CPWBFWS = X.CPWBFWS        ,--产品外包服务商
         ZQJJSQC = X.ZQJJSQC        ,--证券经纪商全称         
         QHJJSQC = X.QHJJSQC        ,--期货经纪商全称         
         QXR = X.QXR            ,--起息日         
         DFR = X.DFR            ,--兑付日
         KFQ = X.KFQ            ,--开放期         
         FBQ = X.FBQ            ,--封闭期         
         RGKSRQ = X.RGKSRQ         ,--认购开始日期         
         RGJSRQ = X.RGJSRQ         ,--认购结束日期
         SGKSRQ = X.SGKSRQ,
         SGJSRQ = X.SGJSRQ,
         --RGFL = X.RGFL           ,--认购费率         
         --SGFL = X.SGFL           ,--申购费率         
         --SHFL = X.SHFL           ,--赎回费率         
         GLRGLFL = X.GLRGLFL        ,--管理人管理费率
         TGFL = X.TGFL           ,--托管费率         
         WBFWFL = X.WBFWFL         ,--外包服务费率         
         GTFWFL = X.GTFWFL         ,--柜台服务费率         
         GLRYJBC = X.GLRYJBC        ,--管理人业绩报酬
         GDXSFWFL = X.GDXSFWFL       ,--固定销售服务费率         
         FDXSFWFL = X.FDXSFWFL       ,--浮动销售服务费率         
         CWGWFL = X.CWGWFL         ,--财务顾问费率         
         DBZXCS = X.DBZXCS         ,--担保增信措施
         DXFS = X.DXFS           ,--代销方式         
         --SFZZJJGT = X.SFZZJJGT       ,--是否种子基金跟投 改为标签
         GTGM = X.GTGM           ,--跟投规模(万元)        
         --SFGPHG = X.SFGPHG         ,--是否股票换购         
         --SFDT = X.SFDT           ,--是否定投
         FQFZJG = X.FQFZJG         ,--发起分支机构         
         CXQ = X.CXQ            ,--存续期         
         KFGZ = X.KFGZ           ,--开放规则         
         RGFS = X.RGFS           ,--认购方式
         GGBL = X.GGBL           ,--杠杆比例         
         YJJZ = X.YJJZ           ,--业绩基准         
         NDJXTS = X.NDJXTS         ,--年度计息天数         
         GGBD = X.GGBD           ,--挂钩标的
         GRRGQD = X.GRRGQD         ,--个人认购起点         
         GRRGZJQD = X.GRRGZJQD       ,--个人认购追加起点         
         GRSGQD = X.GRSGQD         ,--个人申购起点         
         XSFS = X.XSFS           ,--销售方式
         GRSGZJQD = X.GRSGZJQD       ,--个人申购追加起点         
         JGRGQD = X.JGRGQD         ,--机构认购起点         
         JGRGZJQD = X.JGRGZJQD       ,--机构认购追加起点         
         JGSGQD = X.JGSGQD         ,--机构申购起点
         JGSGZJQD = X.JGSGZJQD       ,--机构申购追加起点         
         GRSHFEXX = X.GRSHFEXX       ,--个人赎回份额下限         
         GRSHHZDCYJE = X.GRSHHZDCYJE    ,--个人赎回后最低持有金额         
         JGSHFEXX = X.JGSHFEXX       ,--机构赎回份额下限
         JGSHHZDCYJE = X.JGSHHZDCYJE    ,--机构赎回后最低持有金额         
         YJX = X.YJX            ,--预警线         
         PCX = X.PCX            ,--平仓线         
         BZ = X.BZ             ,--备注
         FXRLX = X.FXRLX          ,--发行人类型         
         SYTZ = X.SYTZ           ,--收益特征         
         SFJGHJRCP = X.SFJGHJRCP      ,--是否结构化金融产品         
         SFGFXJRCP = X.SFGFXJRCP       --是否高风险金融产品   
       WHERE cpmc = V_CPMC;
      COMMIT;
      
      
    END IF;

    if V_COUNT6 = 0 THEN
      --新增产品费率表
      INSERT INTO PIF.TPIF_CPFLB (ID,CPDM,CPMC,FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ)
      SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPFLB'),
             (SELECT CPDM FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ
      FROM PIF.LC_CPXZ_SDXJ_CPFL B
      WHERE B.LC_CPXZ_SDXJ_ID=I_ID;
      --新增产品标签表
      INSERT INTO PIF.TPIF_CPBQB (ID,CPDM,CPMC,BQMC,BQZ,BZ)
      SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPBQB'),
             (SELECT CPDM FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
             BQMC,
             CASE WHEN BQZDX IS NOT NULL THEN TO_CHAR(BQZDX)
                  ELSE BQZBDXXZ END,BZ
      FROM PIF.LC_CPXZ_SDXJ_CPBQ B
      WHERE B.LC_CPXZ_SDXJ_ID=I_ID;
      --新增产品代码总表
      insert into pif.TPIF_CPDMZB
        (
         ID             ,         CPDM           ,         CPMC           ,         LRLX           ,
         CPLX           ,         TZPZ           ,         TZQX           ,         FXDJ           ,
         CPZT           ,         CLR            ,         DQR            ,       /*SYL            ,*/
         ZDYQSYL        ,         ZGYQSYL        ,         RGQD           ,         SFCZMDM        ,
         MCPDM          ,         MCPMC          ,         SHZT           ,         CPJZ           ,
       /*CPGM_FE        ,         CPGM_JE        ,         JJJL           ,         QYFL           ,
         HJFL           ,         WINDFL         ,         SYPZFL         ,         ABSFL          ,
         JYNSYL         ,         JXGZ           ,         KFZT           ,         GLRLX          ,
         TZFW           ,         FGYQRGQD       ,         CPXS           ,         GLRSFWDFZQHZGS ,
         SFDFZQWB       ,         SFDFZQTG       ,         SFGPCWSC       ,         SFKZR          ,
         SFZDCP         ,*/       ZDDYNF         ,         CPJC           ,         CPRGDM         ,
         CPHGDM         ,         CPJYDM         ,         CPJL           ,         CPJLBH         ,
         CPZJZH         ,         ZYJYDYBH       ,         CPGLR          ,         CPTZJL         ,
         CPGLRLXR       ,         CPGLRLXRLXFS   ,         CPTGR          ,         CPWBFWS        ,
         ZQJJSQC        ,         QHJJSQC        ,         QXR            ,         DFR            ,
         KFQ            ,         FBQ            ,         RGKSRQ         ,         RGJSRQ         ,
       /*RGFL           ,         SGFL           ,         SHFL           ,*/       GLRGLFL        ,
         TGFL           ,         WBFWFL         ,         GTFWFL         ,         GLRYJBC        ,
         GDXSFWFL       ,         FDXSFWFL       ,         CWGWFL         ,         DBZXCS         ,
         DXFS           ,         SFZZJJGT       ,         SFGPHG         ,         SFDT           ,
         FQFZJG         ,         CXQ            ,         KFGZ           ,         RGFS           ,
         GGBL           ,         YJJZ           ,         NDJXTS         ,         GGBD           ,
         GRRGQD         ,         GRRGZJQD       ,         GRSGQD         ,         XSFS           ,
         GRSGZJQD       ,         JGRGQD         ,         JGRGZJQD       ,         JGSGQD         ,
         JGSGZJQD       ,         GRSHFEXX       ,         GRSHHZDCYJE    ,         JGSHFEXX       ,
         JGSHHZDCYJE    ,         YJX            ,         PCX            ,         BZ             ,
         FXRLX          ,         SYTZ           ,         SFJGHJRCP      ,         SFGFXJRCP      ,
         SGKSRQ         ,         SGJSRQ         ,         GTGM           )
  SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPDMZB'),--ID
         CPDM           ,--产品代码 
         CPMC           ,--产品全称
         LRLX           ,--录入类型
         CPLX           ,--产品大类
         TZPZ           ,--投资品种
         TZQX           ,--投资期限
         FXDJ           ,--风险等级
         CPZT           ,--产品状态
         CLR            ,--成立日         
         DQR            ,--到期日    
         --SYL            ,
         ZDYQSYL        ,--最低预期收益率(%)         
         ZGYQSYL        ,--最高预期收益率(%)        
         RGQD           ,--认购起点(万元)         
         SFCZMDM        ,--是否存在母代码
         MCPDM          ,--母产品代码         
         MCPMC          ,--母产品名称         
         2              ,--审核状态         
         CPJZ           ,--产品净值
         --CPGM_FE        ,         
         --CPGM_JE        ,         
         --JJJL           ,         
         --QYFL           ,
         --HJFL           ,         
         --WINDFL         ,         
         --SYPZFL         ,         
         --ABSFL          ,
         --JYNSYL         ,         
         --JXGZ           ,         
         --KFZT           ,         
         --GLRLX          ,--管理人类型
         --TZFW           ,--投资范围         
         --FGYQRGQD       ,--法规要求认购起点         
         --CPXS           ,--产品形式         
         --GLRSFWDFZQHZGS ,--管理人是否为东方证券或子公司
         --SFDFZQWB       ,--是否东方证券外包         
         --SFDFZQTG       ,--是否东方证券托管         
         --SFGPCWSC       ,--是否挂牌场外市场         
         --SFKZR          ,--是否可转让
         --SFZDCP         ,--是否重点产品         
         ZDDYNF         ,--重点对应年份         
         CPJC           ,--产品简称         
         CPRGDM         ,--产品认购代码
         CPHGDM         ,--产品换购代码         
         CPJYDM         ,--产品交易代码         
         CPJL           ,--产品经理         
         CPJLBH         ,--产品经理编号
         CPZJZH         ,--产品资金账号         
         ZYJYDYBH       ,--租用交易单元编号         
         CPGLR          ,--产品管理人         
         CPTZJL         ,--产品投资经理
         CPGLRLXR       ,--产品管理人联系人         
         CPGLRLXRLXFS   ,--产品管理人联系人联系方式         
         CPTGR          ,--产品托管人         
         CPWBFWS        ,--产品外包服务商
         ZQJJSQC        ,--证券经纪商全称         
         QHJJSQC        ,--期货经纪商全称         
         QXR            ,--起息日         
         DFR            ,--兑付日
         KFQ            ,--开放期         
         FBQ            ,--封闭期         
         RGKSRQ         ,--认购开始日期         
         RGJSRQ         ,--认购结束日期
         --RGFL           ,--认购费率         
         --SGFL           ,--申购费率         
         --SHFL           ,--赎回费率         
         GLRGLFL        ,--管理人管理费率
         TGFL           ,--托管费率         
         WBFWFL         ,--外包服务费率         
         GTFWFL         ,--柜台服务费率         
         GLRYJBC        ,--管理人业绩报酬
         GDXSFWFL       ,--固定销售服务费率         
         FDXSFWFL       ,--浮动销售服务费率         
         CWGWFL         ,--财务顾问费率         
         DBZXCS         ,--担保增信措施
         DXFS           ,--代销方式         
         SFZZJJGT       ,--是否种子基金跟投         
         SFGPHG         ,--是否股票换购         
         SFDT           ,--是否定投
         FQFZJG         ,--发起分支机构         
         CXQ            ,--存续期         
         KFGZ           ,--开放规则         
         RGFS           ,--认购方式
         GGBL           ,--杠杆比例         
         YJJZ           ,--业绩基准         
         NDJXTS         ,--年度计息天数         
         GGBD           ,--挂钩标的
         GRRGQD         ,--个人认购起点         
         GRRGZJQD       ,--个人认购追加起点         
         GRSGQD         ,--个人申购起点         
         XSFS           ,--销售方式
         GRSGZJQD       ,--个人申购追加起点         
         JGRGQD         ,--机构认购起点         
         JGRGZJQD       ,--机构认购追加起点         
         JGSGQD         ,--机构申购起点
         JGSGZJQD       ,--机构申购追加起点         
         GRSHFEXX       ,--个人赎回份额下限         
         GRSHHZDCYJE    ,--个人赎回后最低持有金额         
         JGSHFEXX       ,--机构赎回份额下限
         JGSHHZDCYJE    ,--机构赎回后最低持有金额         
         YJX            ,--预警线         
         PCX            ,--平仓线         
         BZ             ,--备注
         FXRLX          ,--发行人类型         
         SYTZ           ,--收益特征         
         SFJGHJRCP      ,--是否结构化金融产品         
         SFGFXJRCP      , --是否高风险金融产品    
         SGKSRQ         ,--申购开始日期
         SGJSRQ         , --申购结束日期
         GTGM            --跟投规模
          FROM PIF.LC_CPXZ_SDXJ
         WHERE ID = I_ID;
      COMMIT;
    end if;



   -----------------企业金融中每一级别插入总表

      for JB in (select * from PIF.LC_CPXZ_SDXJ_JJFEQK WHERE LC_CPXZ_SDXJ_ID = I_ID) loop

    IF V_LRLX =5 THEN
      --若产品费率已存在，先删除
      SELECT COUNT(*) INTO V_COUNT1 FROM PIF.TPIF_CPFLB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      IF V_COUNT1>=1 THEN
      DELETE PIF.TPIF_CPFLB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      END IF;
      --新增产品费率表
      INSERT INTO PIF.TPIF_CPFLB (ID,CPDM,CPMC,FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ)
      SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPFLB'),
             JB.CPDM_NEW,
             jb.CPMC||'('||jb.lb||')',
             FLLX,TZQTLX,JEXX,JESX,CYQXXX,CYQXSX,CYQXDW,FL,BDRQ,BZ
      FROM PIF.LC_CPXZ_SDXJ_CPFL B
      WHERE B.LC_CPXZ_SDXJ_ID=I_ID;
      
      --若产品标签已存在，先删除
      SELECT COUNT(*) INTO V_COUNT2 FROM PIF.TPIF_CPBQB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      IF V_COUNT1>=1 THEN
      DELETE PIF.TPIF_CPBQB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      END IF;
      --新增产品标签表
      INSERT INTO PIF.TPIF_CPBQB (ID,CPDM,CPMC,BQMC,BQZ,BZ)
      SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPBQB'),
             JB.CPDM_NEW,             
             jb.CPMC||'('||jb.lb||')',
             BQMC,
             CASE WHEN BQZDX IS NOT NULL THEN TO_CHAR(BQZDX)
                  ELSE BQZBDXXZ END,BZ
      FROM PIF.LC_CPXZ_SDXJ_CPBQ B
      WHERE B.LC_CPXZ_SDXJ_ID=I_ID;
      
      SELECT COUNT(*) INTO V_COUNT FROM PIF.TPIF_CPDMZB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      IF V_COUNT>=1 THEN
        DELETE PIF.TPIF_CPDMZB WHERE CPMC=jb.CPMC||'('||jb.lb||')';
      END IF;
      --新增产品代码总表
      insert into pif.TPIF_CPDMZB
        (
         ID             ,         CPDM           ,         CPMC           ,         LRLX           ,
         CPLX           ,         TZPZ           ,         TZQX           ,         FXDJ           ,
         CPZT           ,         CLR            ,         DQR            ,         ZDYQSYL        ,         
         ZGYQSYL        ,         RGQD           ,         SFCZMDM        ,         MCPDM          ,         
         MCPMC          ,         SHZT           ,         CPJZ           ,       /*GLRLX          ,
         TZFW           ,         FGYQRGQD       ,         CPXS           ,         GLRSFWDFZQHZGS ,
         SFDFZQWB       ,         SFDFZQTG       ,         SFGPCWSC       ,         SFKZR          ,
         SFZDCP         ,*/       ZDDYNF         ,         CPJC           ,         CPRGDM         ,
         CPHGDM         ,         CPJYDM         ,         CPJL           ,         CPJLBH         ,
         CPZJZH         ,         ZYJYDYBH       ,         CPGLR          ,         CPTZJL         ,
         CPGLRLXR       ,         CPGLRLXRLXFS   ,         CPTGR          ,         CPWBFWS        ,
         ZQJJSQC        ,         QHJJSQC        ,         QXR            ,         DFR            ,
         KFQ            ,         FBQ            ,         RGKSRQ         ,         RGJSRQ         ,
       /*RGFL           ,         SGFL           ,         SHFL           ,*/       GLRGLFL        ,
         TGFL           ,         WBFWFL         ,         GTFWFL         ,         GLRYJBC        ,
         GDXSFWFL       ,         FDXSFWFL       ,         CWGWFL         ,         DBZXCS         ,
         DXFS           ,         SFZZJJGT       ,         SFGPHG         ,         SFDT           ,
         FQFZJG         ,         CXQ            ,         KFGZ           ,         RGFS           ,
         GGBL           ,         YJJZ           ,         NDJXTS         ,         GGBD           ,
         GRRGQD         ,         GRRGZJQD       ,         GRSGQD         ,         XSFS           ,
         GRSGZJQD       ,         JGRGQD         ,         JGRGZJQD       ,         JGSGQD         ,
         JGSGZJQD       ,         GRSHFEXX       ,         GRSHHZDCYJE    ,         JGSHFEXX       ,
         JGSHHZDCYJE    ,         YJX            ,         PCX            ,         BZ             ,
         FXRLX          ,         SYTZ           ,         SFJGHJRCP      ,         SFGFXJRCP      ,
         SGKSRQ         ,         SGJSRQ         ,         GTGM           )
  SELECT CRMII.FUNC_NEXTID('pif.TPIF_CPDMZB'),--ID
         JB.CPDM_NEW    ,--产品代码 
         jb.CPMC||'('||jb.lb||')',--产品全称
         LRLX           ,--录入类型
         CPLX           ,--产品大类
         TZPZ           ,--投资品种
         TZQX           ,--投资期限
         FXDJ           ,--风险等级
         JB.CPZT        ,--产品状态
         JB.CLR         ,--成立日         
         JB.DQR         ,--到期日   
         ZDYQSYL        ,--最低预期收益率(%)         
         ZGYQSYL        ,--最高预期收益率(%)        
         RGQD           ,--认购起点(万元)         
         SFCZMDM        ,--是否存在母代码
         MCPDM          ,--母产品代码         
         MCPMC          ,--母产品名称         
         2              ,--审核状态         
         CPJZ           ,--产品净值       
         --GLRLX          ,--管理人类型
         --TZFW           ,--投资范围         
         --FGYQRGQD       ,--法规要求认购起点         
         --CPXS           ,--产品形式         
         --GLRSFWDFZQHZGS ,--管理人是否为东方证券或子公司
         --SFDFZQWB       ,--是否东方证券外包         
         --SFDFZQTG       ,--是否东方证券托管         
         --SFGPCWSC       ,--是否挂牌场外市场         
         --SFKZR          ,--是否可转让
         --SFZDCP         ,--是否重点产品         
         ZDDYNF         ,--重点对应年份         
         CPJC           ,--产品简称         
         CPRGDM         ,--产品认购代码
         CPHGDM         ,--产品换购代码         
         CPJYDM         ,--产品交易代码         
         CPJL           ,--产品经理         
         CPJLBH         ,--产品经理编号
         CPZJZH         ,--产品资金账号         
         ZYJYDYBH       ,--租用交易单元编号         
         CPGLR          ,--产品管理人         
         CPTZJL         ,--产品投资经理
         CPGLRLXR       ,--产品管理人联系人         
         CPGLRLXRLXFS   ,--产品管理人联系人联系方式         
         CPTGR          ,--产品托管人         
         CPWBFWS        ,--产品外包服务商
         ZQJJSQC        ,--证券经纪商全称         
         QHJJSQC        ,--期货经纪商全称         
         QXR            ,--起息日         
         DFR            ,--兑付日
         KFQ            ,--开放期         
         FBQ            ,--封闭期         
         RGKSRQ         ,--认购开始日期         
         RGJSRQ         ,--认购结束日期
         --RGFL           ,--认购费率         
         --SGFL           ,--申购费率         
         --SHFL           ,--赎回费率         
         GLRGLFL        ,--管理人管理费率
         TGFL           ,--托管费率         
         WBFWFL         ,--外包服务费率         
         GTFWFL         ,--柜台服务费率         
         GLRYJBC        ,--管理人业绩报酬
         GDXSFWFL       ,--固定销售服务费率         
         FDXSFWFL       ,--浮动销售服务费率         
         CWGWFL         ,--财务顾问费率         
         DBZXCS         ,--担保增信措施
         DXFS           ,--代销方式         
         SFZZJJGT       ,--是否种子基金跟投         
         SFGPHG         ,--是否股票换购         
         SFDT           ,--是否定投
         FQFZJG         ,--发起分支机构         
         CXQ            ,--存续期         
         KFGZ           ,--开放规则         
         RGFS           ,--认购方式
         GGBL           ,--杠杆比例         
         YJJZ           ,--业绩基准         
         NDJXTS         ,--年度计息天数         
         GGBD           ,--挂钩标的
         GRRGQD         ,--个人认购起点         
         GRRGZJQD       ,--个人认购追加起点         
         GRSGQD         ,--个人申购起点         
         XSFS           ,--销售方式
         GRSGZJQD       ,--个人申购追加起点         
         JGRGQD         ,--机构认购起点         
         JGRGZJQD       ,--机构认购追加起点         
         JGSGQD         ,--机构申购起点
         JGSGZJQD       ,--机构申购追加起点         
         GRSHFEXX       ,--个人赎回份额下限         
         GRSHHZDCYJE    ,--个人赎回后最低持有金额         
         JGSHFEXX       ,--机构赎回份额下限
         JGSHHZDCYJE    ,--机构赎回后最低持有金额         
         YJX            ,--预警线         
         PCX            ,--平仓线         
         BZ             ,--备注
         FXRLX          ,--发行人类型         
         SYTZ           ,--收益特征         
         SFJGHJRCP      ,--是否结构化金融产品         
         SFGFXJRCP      ,--是否高风险金融产品 
         SGKSRQ         ,--申购开始日期
         SGJSRQ         , --申购结束日期
         GTGM            --跟投规模
    FROM PIF.LC_CPXZ_SDXJ
   WHERE ID = I_ID;
  COMMIT;

  end if;
  end LOOP;
    --------------------线下导入公募产品只进行状态变更
    -------------------线上录入公募产品
    --------------------线下导入信托产品只进行状态变更
    -------------------线上录入信托产品
    --------------------线下导入资管产品只进行状态变更
    -------------------线上录入资管产品
    --------------------线下导入OTC产品只进行状态变更
    --------------------线shang导入OTC产品
    --------------------线下导入私募企业金融产品只进行状态变更
    IF V_LRLX = 5 AND V_COUNT4 >= 1 THEN
      UPDATE PIF.TPIF_CPDM_SMQYJR
          SET SHZT = 2,
             YWBM = X.SMYWBM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),

             CPJL = X.CPJL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CPDM = X.CPDM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             ----CPMC=X. CPMC ,---- PIF.LC_CPXZ_SDXJ where  WHERE ID = I_ID),
             SMJJGLR = X.CPGLR ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),

             SYL     = X.SYL ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             ZDYQSYL = X.ZDYQSYL ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             ZGYQSYL = X.ZGYQSYL ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             RGQD    = X.RGQD ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             GTFWF = X.GTFWFL,
             DJBM    = X.DJBM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             SMJJTGR = decode(x.cptgr,'东方证券股份有限公司',7021734,NULL),--X.CPTGR ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             SFWWSBG =(SELECT BQZDX-37 FROM PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID AND BQMC=5),-- X.SFWWSBG ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),

             SZ    = X.SMSZ ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             DW    = X.SMDW ,---- PIF.LC_CPXZ_SDXJ WHERE ID = I_ID),
             WBFWS = X.CPWBFWS ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             ZQJJS = X.ZQJJSQC ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             QHJJS = X.QHJJSQC ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             HBZL  = X.HBZL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CLR   = X.CLR ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             DQR   = X.DQR ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CXQX  = X.CXQ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             KFRQ  = X.KFRQ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             KFGZ  = X.KFGZ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             FBQ   = X.FBQ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CPGM  = X.SMCPGM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             GGBL  = X.SMGGBL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             DXJG  = X.DXJG ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
                  JRCPFL    = X. CPlx,---- PIF.LC_CPXZ_SDXJ
                                               --where  ID = I_ID),
             DXFELX  = X.DXFELX ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             MBJZSY  = X.MBJZSY ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             TZJL    = X.CPTZJL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             GLF     = X.GLRGLFL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             TGF     = X.TGFL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             WBFWF   = X.WBFWFL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CWGWF   = X.CWGWFL ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             XSFFW   = X.XSFFW ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             RGFL    = (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=1) ,--20190329
             SGFL    = (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=2) ,--20190329
             SHFL    = (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=3) ,--20190329
             TZFW    =(SELECT BQZBDXXZ FROM PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID AND BQMC=2),-- X.SMTZFW,--(SELECT BQZBDXXZ FROM PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID AND BQMC=2),--20190329
             FPFS    = X.FPFS ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             TZXZ    = X.TZXZ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             YJX     = X.YJX ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             ZSX     = X.PCX ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             DBZXCS  = X.DBZXCS ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             FHJG    = X.FHJG ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             TZQX    = X.TZQX ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             TZPZ    = X.TZPZ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             FXDJ    = X.FXDJ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             BZ      = X.BZ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             CPZT    = X.CPZT ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             YYBKHFF = X.YYBKHFF ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             FFRQ    = X.FFRQ ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             -----SHZT    = X. SHZT ,---- PIF.LC_CPXZ_SDXJ where  ID = I_ID),
             SFCZMDM = X.SFCZMDM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID),
             MCPDM   = X.MCPDM ,---- PIF.LC_CPXZ_SDXJ where ID = I_ID) ,
                      /*    YQSY =
                                                               X. YQSY ,---- PIF.LC_CPXZ_SDXJ where  ID = I_ID) ,*/
                       MCPMC =  X.MCPMC ---- PIF.LC_CPXZ_SDXJ where ID = I_ID)
       WHERE cpmc = V_CPMC;
      COMMIT;
    END IF;

    -------------------线上录入私募企业金融产品
    IF V_LRLX = 5 AND V_COUNT4 = 0 THEN
      INSERT INTO PIF.TPIF_CPDM_SMQYJR（ID, YWBM, CPJL, CPDM, CPMC, SMJJGLR, DJBM,
      SMJJTGR, SFWWSBG, WBFWS, ZQJJS, QHJJS, HBZL,/* CLR, DQR,*/ CXQX, KFRQ, KFGZ,
       FBQ, CPGM, GGBL, DXJG, JRCPFL, DXFELX, MBJZSY, TZJL, GLF, TGF, WBFWF,
        CWGWF, XSFFW, RGFL, SGFL, SHFL, TZFW, FPFS, TZXZ, YJX, ZSX, DBZXCS,
         FHJG, TZQX, TZPZ, FXDJ, BZ, /*CPZT*/ YYBKHFF, FFRQ, SHZT, /*FJID,*/ SFCZMDM, MCPDM, ---YQSY,
      MCPMC, SZ, DW,SYL, ZDYQSYL, ZGYQSYL, RGQD,GTFWF）
        SELECT CRMII.FUNC_NEXTID('PIF.TPIF_CPDM_SMQYJR'),
               SMYWBM,
               CPJL, CPDM, CPMC, CPGLR, DJBM, 
               CASE WHEN CPTGR='东方证券股份有限公司' THEN 7021734
                    ELSE NULL END CPTGR,
               (SELECT BQZDX-37 FROM PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID AND BQMC=5), 
               CPWBFWS, ZQJJSQC, QHJJSQC, HBZL,/* CLR, DQR,*/
               CXQ, KFRQ, KFGZ, FBQ, SMCPGM, SMGGBL, DXJG, CPLX, DXFELX, MBJZSY, CPTZJL, GLRGLFL,
               TGFL, WBFWFL, CWGWFL, XSFFW, 
               (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=1), 
               (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=2), 
               (SELECT FL FROM PIF.LC_CPXZ_SDXJ_CPFL WHERE LC_CPXZ_SDXJ_ID=I_ID AND FLLX=3), 
               (SELECT BQZBDXXZ FROM PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID AND BQMC=2),
               FPFS, TZXZ, YJX, PCX, DBZXCS,
                FHJG, TZQX, TZPZ, FXDJ, BZ, /*CPZT,*/ YYBKHFF, FFRQ, 2,
              --- ID,
                SFCZMDM, MCPDM, ----YQSY,
               MCPMC,
               SMSZ,
               SMDW,SYL,
               ZDYQSYL,
               ZGYQSYL,
               RGQD,GTFWFL
          FROM PIF.LC_CPXZ_SDXJ
         WHERE ID = I_ID;
      COMMIT;

    END IF;
    --------------------线下导入私募PB金融产品只进行状态变更
    -------------------线上录入私募PB金融产品
  END LOOP;
  
  UPDATE  PIF.LC_CPXZ_SDXJ SET LRSJ=SYSDATE , SHZT=2  WHERE ID = I_ID;
  --UPDATE  PIF.Lc_Cpxz_Sdxj_Cpfj_Tcpfjb a SET  SHZT=2  WHERE a.lc_cpxz_sdxj_id = I_ID;
  UPDATE  PIF.LC_CPXZ_SDXJ_SCHTSMJ_TCPFJB a SET  SHZT=2  WHERE a.lc_cpxz_sdxj_id = I_ID;
  UPDATE  PIF.LC_CPXZ_SDXJ_SCQTFJ_TCPFJB a SET  SHZT=2  WHERE a.lc_cpxz_sdxj_id = I_ID;
  UPDATE  PIF.LC_CPXZ_SDXJ_SCDXXY_TCPFJB a SET  SHZT=2  WHERE a.lc_cpxz_sdxj_id = I_ID;
  
  --INSERT INTO PIF.LC_CPXZ_SDXJ_CPFJ_TCPFJB(ID,F1,F2,WBID)
  --SELECT FUNC_NEXTID('LC_CPXZ_SDXJ_CPFJ_TCPFJB'),T.F1,T.F2,T.ID  FROM LC_TEST_FJ_F2 T WHERE  LC_TEST_FJ_ID =I_ID;
  
  --产品附件记录
  INSERT INTO PIF.LC_CPXZ_SDXJ_CPFJ_TCPFJB(ID,FJLX,CPMC,FJMC,WJNR,DJR,DJRQ,SHZT,LC_CPXZ_SDXJ_ID)
  SELECT CRMII.FUNC_NEXTID('LC_CPXZ_SDXJ_CPFJ_TCPFJB'),
         2,
         (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
         FJMC,
         WJNR,
         DJR,
         DJRQ,
         SHZT,
         LC_CPXZ_SDXJ_ID
  FROM PIF.LC_CPXZ_SDXJ_SCHTSMJ_TCPFJB WHERE lc_cpxz_sdxj_id =I_ID;
  
  INSERT INTO PIF.LC_CPXZ_SDXJ_CPFJ_TCPFJB(ID,FJLX,CPMC,FJMC,WJNR,DJR,DJRQ,SHZT,LC_CPXZ_SDXJ_ID)
  SELECT CRMII.FUNC_NEXTID('LC_CPXZ_SDXJ_CPFJ_TCPFJB'),
         4,
         (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
         FJMC,
         WJNR,
         DJR,
         DJRQ,
         SHZT,
         LC_CPXZ_SDXJ_ID
  FROM PIF.LC_CPXZ_SDXJ_SCQTFJ_TCPFJB WHERE  lc_cpxz_sdxj_id =I_ID;
  
  INSERT INTO PIF.LC_CPXZ_SDXJ_CPFJ_TCPFJB(ID,FJLX,CPMC,FJMC,WJNR,DJR,DJRQ,SHZT,LC_CPXZ_SDXJ_ID)
  SELECT CRMII.FUNC_NEXTID('LC_CPXZ_SDXJ_CPFJ_TCPFJB'),
         3,
         (SELECT CPMC FROM PIF.LC_CPXZ_SDXJ WHERE ID=I_ID),
         FJMC,
         WJNR,
         DJR,
         DJRQ,
         SHZT,
         LC_CPXZ_SDXJ_ID
  FROM PIF.LC_CPXZ_SDXJ_SCDXXY_TCPFJB WHERE  lc_cpxz_sdxj_id =I_ID;
  COMMIT;
  
  --20190517新增产品大类（一级分类）
  SELECT CPLX INTO V_CPLX FROM PIF.TPIF_CPDMZB WHERE INSTR(CPMC,V_CPMC)>0;
  IF V_CPLX>=100070 AND V_CPLX<=100079 THEN
    UPDATE PIF.TPIF_CPDMZB SET CPDL=100070 WHERE INSTR(CPMC,V_CPMC)>0;
  ELSE 
    UPDATE PIF.TPIF_CPDMZB SET CPDL=100800 WHERE INSTR(CPMC,V_CPMC)>0;
  END IF;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
END PRO_CPZX_CPLR;
/

