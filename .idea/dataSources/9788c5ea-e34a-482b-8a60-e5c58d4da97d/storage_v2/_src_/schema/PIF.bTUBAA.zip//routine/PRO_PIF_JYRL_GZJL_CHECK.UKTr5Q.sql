create PROCEDURE PRO_PIF_JYRL_GZJL_CHECK(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_DDGZ INTEGER, --定点规则
                                               I_RQ   VARCHAR2 --日期
                                               ) IS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      20161020       2.0.0     王大一             迁移并修改
  *********************************************************************************************************************/
  V_COUNT INTEGER; --计数变量
  V_MRZ   VARCHAR2(500);

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --check
  SELECT GZMC INTO V_MRZ FROM TPIF_JYRL_DDGZ WHERE ID = I_DDGZ;
  IF (I_DDGZ = 13 OR I_DDGZ = 14) THEN
    SELECT INSTR(I_RQ, ',') INTO V_COUNT FROM DUAL;
    IF (V_COUNT > 0) THEN
      O_NOTE := V_MRZ || '不能填多个日期！';
      RETURN;
    END IF;
  END IF;
  O_CODE := 1;
  O_NOTE := '';
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_GZJL_CHECK;
/

