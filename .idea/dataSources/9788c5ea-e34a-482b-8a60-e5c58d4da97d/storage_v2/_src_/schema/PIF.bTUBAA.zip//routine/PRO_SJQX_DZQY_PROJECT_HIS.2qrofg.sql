create PROCEDURE PRO_SJQX_DZQY_PROJECT_HIS
(
    O_CODE OUT NUMBER, --返回值
    O_NOTE OUT VARCHAR2 --返回消息
) IS

    /******************************************************************
        所属用户：PIF
        功能说明：电子签约项目表 PIF.DZQY_PROJECT_INVESTOR_HISTORY 数据清洗逻辑
        语法信息：
             输入参数：   无
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2022-1-5       1.0       HANQN              创建
            
    ***********************************************************************/

BEGIN
    O_CODE := -1;
    O_NOTE := '';

   MERGE INTO DZQY_PROJECT_INVESTOR_HIS_TEST T
  USING (SELECT FUND_CODE, 
                FUND_NAME, 
                TO_DATE(CREATE_TIME,'yyyy-mm-dd hh24:mi:ss') AS ZZ_CREATE_DATE, 
                STATUS, 
                FUND_INVESTOR_ID
           FROM SRC_PIF.PROJECT_HISTORY_INFO
         ) S
  ON (T.FUND_CODE = S.FUND_CODE AND T.FUND_INVESTOR_ID = S.FUND_INVESTOR_ID)
  WHEN NOT MATCHED THEN
    INSERT(T.ID, 
           T.FUND_CODE, 
           T.FUND_NAME, 
           T.FUND_INVESTOR_ID, 
           T.ZZ_CREATE_DATE, 
           T.STATUS, 
           T.CREATE_DATE, 
           T.LAST_MODIFIED_DATE, 
           T.DELETED_FLAG
      )
    VALUES
      (LIVEBOS.FUNC_NEXTID('DZQY_PROJECT_INVESTOR_HIS_TEST'),
       S.FUND_CODE, 
       S.FUND_NAME, 
       S.FUND_INVESTOR_ID, 
       S.ZZ_CREATE_DATE, 
       S.STATUS, 
       SYSDATE, 
       SYSDATE, 
       2);

    COMMIT;
    O_CODE := 1;
    O_NOTE := 'DZQY_PROJECT_INVESTOR_HISTORY 表清洗成功';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       'DZQY_PROJECT_INVESTOR_HISTORY  表清洗,未知错误'
                      ELSE
                       'DZQY_PROJECT_INVESTOR_HISTORY ,在 ' || O_NOTE ||
                       ' 时出现异常'
                  END) || ':' || SQLERRM;
END;
/

