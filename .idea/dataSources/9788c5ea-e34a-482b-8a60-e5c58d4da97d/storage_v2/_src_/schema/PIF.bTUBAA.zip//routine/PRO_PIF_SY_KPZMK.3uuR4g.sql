create PROCEDURE PRO_PIF_SY_KPZMK(O_CODE         OUT NUMBER,
                                             O_NOTE         OUT VARCHAR2,
                                             I_USERID       IN NUMBER, --登陆用户ID
                                             I_DISPLAYPARAM IN VARCHAR2 -- 显示参数

                                             ) AS

  /*--------------------------------------------------------------------------------------------

  项目名称：产品中心

         功能说明：首页-首页可配置模块更新
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID

                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                          TYPE  消息类别
                          TOTAL_RECORD_NUM  总记录数
                          ALREADY_DEAL_NUM  已阅/已处理数
                          TIPS  提示信息
                          URL 明细链接URL


        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        刘浪浪    1.0.1    2015/01/26                   新增

  -------------------------------------------------------------------------------------------------*/
  V_MKID NUMBER;
  V_XSCS VARCHAR2(500);

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';
  
  DELETE FROM TEST_PARA;
  INSERT INTO TEST_PARA(PARAM_VALES) VALUES(I_DISPLAYPARAM);
  COMMIT;

  DELETE FROM TPIF_SYMKPZ WHERE YH = I_USERID;

  FOR CUR_JSON IN (SELECT COLUMN_VALUE AS JSON FROM TABLE(SPLIT(RTRIM(I_DISPLAYPARAM,','),'}')) WHERE COLUMN_VALUE IS NOT NULL ) LOOP

    SELECT PARSEJSON(CUR_JSON.JSON, 'i'),

           LTRIM(LTRIM(CUR_JSON.JSON, ','), '{')

      INTO V_MKID, V_XSCS
      FROM DUAL;

    INSERT INTO TPIF_SYMKPZ
      (ID, YH, MKID, XSCS)
    VALUES
      (SEQ_TPIF_SYMKPZ.NEXTVAL, I_USERID, V_MKID, '{'||V_XSCS||'}');


  END LOOP;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;

END;
/

