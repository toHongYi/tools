create PROCEDURE PRO_PIF_FWCPSJ(O_CODE         OUT NUMBER, --返回值
                                         O_NOTE         OUT VARCHAR2, --返回消息
                                         I_CPID         IN NUMBER,
                                         I_SPJG         IN INTEGER, --审批结果1|通过;2|不通过
                                         I_USERID       IN NUMBER,
                                         I_SHYJ         IN VARCHAR2
                                         ) IS
  /*
  **功能说明：服务产品上架审核
  **创建人：wujifneng
  **创建日期：2020-07-27
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者          版本号     修改日期     说明
  **wujinfeng       1.0.0     2020-07-27   创建
  */
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --CHECK
  IF I_USERID IS NULL THEN
    O_NOTE := '系统异常:入参 i_userid 为空!';
    RETURN;
  END IF;

  IF I_CPID IS NULL THEN
    O_NOTE := '系统异常:I_CPID为空!';
    RETURN;
  END IF;


  IF I_SPJG IS NULL THEN
    O_NOTE := '系统异常:I_SPJG为空!';
    RETURN;
  END IF;

  --START

    --//:审批结果1|通过;-----------------------------------------------------------------------

    IF I_SPJG = 1 THEN


       UPDATE TPIF_CPDM A SET A.CPNBZT=8,
                              A.SJSJ=SYSDATE,
                              A.SJCZR=I_USERID
                           WHERE A.ID = I_CPID ;

    --审批结果2|不通过
    ELSE
       UPDATE TPIF_CPDM A SET A.CPNBZT=1
                           WHERE A.ID = I_CPID ;




   INSERT INTO PIF.TPIF_FWCPSPLS(id,
      cpid,
      spr,
      spsj,
      spjg,
      spyj
    )
    values(
    LIVEBOS.FUNC_NEXTID('TPIF_FWCPSPLS'),
    I_CPID,
    I_USERID,
    sysdate,
    2,
    I_SHYJ);

    END IF ;

  COMMIT;
  O_NOTE := '成功';
  O_CODE := 1;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_FWCPSJ;
/

