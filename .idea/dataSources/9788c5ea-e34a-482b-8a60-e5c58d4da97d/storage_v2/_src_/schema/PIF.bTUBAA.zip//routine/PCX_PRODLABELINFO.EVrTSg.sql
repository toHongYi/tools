create PROCEDURE pcx_ProdLabelInfo(O_CODE       OUT NUMBER,
                                              O_NOTE       OUT VARCHAR2,
                                              O_RESULT     OUT SYS_REFCURSOR,
                                              I_USER       IN INTEGER, --操作人
                                              I_IP         IN VARCHAR2, --访问IP
                                              I_PROD_ID    IN NUMBER, --产品ID
                                              I_PROD_CODE  IN VARCHAR2, --产品代码
                                              I_LABEL_NAME IN VARCHAR2 --标签名称 权益类产品、货币基金、收益凭证、ABS产品

                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品标签信息查询
      语法信息：
           输入参数：    I_PROD_ID    IN NUMBER,    --产品ID
                         I_PROD_CODE  IN VARCHAR2,  --产品代码
                         I_LABEL_NAME IN VARCHAR2   --标签名称
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000020');
  V_COUNT NUMBER;
  V_JKLX  NUMBER;
  V_CPID  NUMBER;
  V_CPDM  VARCHAR2(200);
  V_CPMC  VARCHAR2(200);
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;


  BEGIN
    SELECT ID, PROD_CODE, PROD_FULLNAME
      INTO V_CPID, V_CPDM, V_CPMC
      FROM PIF.TPROD_BASIC_INFO A
     WHERE A.PROD_CODE = NVL(I_PROD_CODE, A.PROD_CODE)
       AND A.ID = NVL(I_PROD_ID, A.ID)
       AND ROWNUM<2;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_CODE := 1004;
      O_NOTE := '无法匹配产品信息';
      GOTO BOTTOM;
  END;

  IF I_LABEL_NAME IS NOT NULL THEN

    OPEN O_RESULT FOR
      SELECT V_CPDM     AS PROD_CODE, --产品代码
             V_CPMC     AS PROD_NAME, --产品名称
             LABEL_CODE AS LABEL_CODE, --标签代码
             LABEL_NAME AS LABEL_NAME, --标签名称
             1          AS LABEL_STATUS --标签状态
        FROM PIF.TPROD_LABEL A,
             (SELECT PROD_LABEL
                FROM PIF.tPROD_LABEL_DETAILS
               WHERE PROD_ID = V_CPID) B
       WHERE A.ID = B.PROD_LABEL
         AND A.LABEL_NAME LIKE '%' || I_LABEL_NAME || '%';

  ELSE

    OPEN O_RESULT FOR
      SELECT V_CPDM     AS PROD_CODE, --产品代码
             V_CPMC     AS PROD_NAME, --产品名称
             LABEL_CODE AS LABEL_CODE, --标签代码
             LABEL_NAME AS LABEL_NAME, --标签名称
             (CASE
               WHEN B.PROD_LABEL IS NULL THEN
                0
               ELSE
                1
             END)       AS LABEL_STATUS --标签状态
        FROM PIF.TPROD_LABEL A,
             (SELECT PROD_LABEL
                FROM PIF.tPROD_LABEL_DETAILS
               WHERE PROD_ID = V_CPID) B
       WHERE A.ID = B.PROD_LABEL(+);

  END IF;

  O_CODE := 0;
  O_NOTE := '查询成功';

   <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
      SELECT NULL AS PROD_CODE, --产品代码
             NULL AS PROD_NAME, --产品名称
             NULL AS LABEL_CODE, --标签代码
             NULL AS LABEL_NAME, --标签名称
             NULL AS LABEL_STATUS --标签状态
      FROM DUAL
     WHERE 1 = 2;
  END IF ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

