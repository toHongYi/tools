create PROCEDURE P_TRAN_JJGK(O_CODE OUT NUMBER, --返回值
                                        O_NOTE OUT VARCHAR2 --返回消息
                                        ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：基金概况数据表 INFO.TINFO_JJGK 数据清洗逻辑
                              PIF.TPIF_GMJJGKFB  数据清洗逻辑
                              PIF.TPIF_CPDM 修改基金经理、管理人等
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
    
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2016/03/02     1.0.0      WBJ                创建
          2017/04/22     1.0.1      SUNYUANHE          修改：唯一约束缓存INNERCODE
          2017/05/25     1.0.2      SUNYUANHE          修改：将INFO表的基金管理人和基金托管人数据写入TPIF_CPDM中
          2017/08/22     1.0.3      SUNYUANHE          清洗基金管理人时，对INFO.TINFO_JJGK对SECUCODE为6位限制
          2021/06/02     1.0.4      HANQIAONAN         修改：代码不在INFO.TINFO_JJGK的产品名称以柜台更新
          2021-06-10     1.0.5      GAOKUN             清洗至PIF下
          2021-6-30      1.0.6      GAOKUN             补充产品代码表的数据来源和ID
          2021-10-15     1.0.7      GAOKUN             更新基金概况表的一级分类、二级分类、是否代销、管理人、托管人                                                        
          2021-11-29     1.0.8      GAOKUN             新增根据后端代码匹配
          2021-12-20     1.0.9      GAOKUN             更新产品代码表成立日期、募集开始/结束日期
  ***********************************************************************/

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --将更新完的资讯数据插入到INFO表中
  MERGE INTO INFO.TINFO_JJGK T1
  USING (SELECT T.ID,
                T.INNERCODE,
                T.ESTABLISHMENTDATE,
                T.LISTEDDATE,
                T.DURATION,
                T.STARTDATE,
                T.EXPIREDATE,
                T.MANAGER,
                T.INVESTADVISORCODE,
                (SELECT INVESTADVISORNAME
                   FROM INFO.TINFO_JJGLRGK
                  WHERE INVESTADVISORCODE = T.INVESTADVISORCODE) INVESTADVISORNAME,
                T.TRUSTEECODE,
                (SELECT TRUSTEENAME
                   FROM INFO.TINFO_JJTGRGK
                  WHERE TRUSTEECODE = T.TRUSTEECODE) TRUSTEENAME,
                T.WARRANTOR,
                T.TYPE,
                T.INVESTMENTTYPE,
                T.INVESTSTYLE,
                T.FOUNDEDSIZE,
                T.INVESTORIENTATION,
                T.INVESTTARGET,
                T.PERFORMANCEBENCHMARK,
                T.PROFITDISTRIBUTIONRULE,
                T.INVESTFIELD,
                NULL AS BRIEFINTRO,
                T.XGRQ,
                T.JSID,
                T.APPLYINGCODEFRONT,
                T.APPLYINGCODEBACK,
                T.GUARANTEEDPERIOD,
                T.RISKRETURNCHARACTER,
                T.LOWESTSUMSUBSCRIBING,
                T.LOWESTSUMREDEMPTION,
                T.LSFRDESCRIPTION,
                T.LOWESTSUMFORHOLDING,
                T.LSFHDESCRIPTION,
                T.FUNDNATURE,
                T.FUNDTYPECODE,
                T.FUNDTYPE,
                T.CARRYOVERDATE,
                T.CARRYOVERDATEREMARK,
                T.CARRYOVERTYPE,
                T.REGINSTCODE,
                T.SECURITYCODE, --基金交易代码(交易所交易代码)
                T.DELIVERYDAYS,
                T.RISKRETURNCODE,
                T.FLOATTYPE,
                T.CUSTODYMARKET,
                T.OPERATIONPERIOD,
                T.OPERATIONPDUNITCODE,
                T.OPERATIONPDUNITNAME,
                T.IFINITIATINGFUND,
                T.CLASSIFICATIONFUNDTYPE,
                T.AGRBENCHMKRATEOFSHAREA,
                T.AGRBENCHMKRATEOFSHAREANOTES,
                T.REGULARSHARECONVERSIONNOTES,
                T.NONREGULARSHARECONVERSIONNOTES,
                T.EXAPPLYINGMARKET,
                T.EXAPPLYINGCODE,
                T.EXAPPLYINGABBR,
                T.SHAREPROPERTIES,
                T.STCLEARINGDATE,
                T.ENCLEARINGDATE,
                T.LOWESTSUMSUBLL,
                T.LOWESTSUMPURLL,
                T.MAINCODE, --基金主代码
                P.SECUCODE, --基金代码，=交易代码
                P.CHINAME AS PRODFULLNAME, --产品全称
                P.CHINAMEABBR AS PRODABBNAME, --产品简称
                P.LISTEDSTATE AS LISTEDSTATE --上市状态
           FROM SRC_PIF.MF_FUNDARCHIVES T
           LEFT JOIN INFO.TINFO_ZQZB P
             ON T.INNERCODE = P.INNERCODE) T2
  ON (T1.INNERCODE = T2.INNERCODE)
  WHEN MATCHED THEN
    UPDATE
       SET T1.ID = T2.ID,
           --T1.INNERCODE                    = T2.INNERCODE,
           T1.ESTABLISHMENTDATE              = T2.ESTABLISHMENTDATE,
           T1.LISTEDDATE                     = T2.LISTEDDATE,
           T1.DURATION                       = T2.DURATION,
           T1.STARTDATE                      = T2.STARTDATE,
           T1.EXPIREDATE                     = T2.EXPIREDATE,
           T1.MANAGER                        = T2.MANAGER,
           T1.INVESTADVISORCODE              = T2.INVESTADVISORCODE,
           T1.INVESTADVISORNAME              = T2.INVESTADVISORNAME,
           T1.TRUSTEECODE                    = T2.TRUSTEECODE,
           T1.TRUSTEENAME                    = T2.TRUSTEENAME,
           T1.WARRANTOR                      = T2.WARRANTOR,
           T1.TYPE                           = T2.TYPE,
           T1.INVESTMENTTYPE                 = T2.INVESTMENTTYPE,
           T1.INVESTSTYLE                    = T2.INVESTSTYLE,
           T1.FOUNDEDSIZE                    = T2.FOUNDEDSIZE,
           T1.INVESTORIENTATION              = T2.INVESTORIENTATION,
           T1.INVESTTARGET                   = T2.INVESTTARGET,
           T1.PERFORMANCEBENCHMARK           = T2.PERFORMANCEBENCHMARK,
           T1.PROFITDISTRIBUTIONRULE         = T2.PROFITDISTRIBUTIONRULE,
           T1.INVESTFIELD                    = T2.INVESTFIELD,
           T1.BRIEFINTRO                     = T2.BRIEFINTRO,
           T1.XGRQ                           = T2.XGRQ,
           T1.JSID                           = T2.JSID,
           T1.APPLYINGCODEFRONT              = T2.APPLYINGCODEFRONT,
           T1.APPLYINGCODEBACK               = T2.APPLYINGCODEBACK,
           T1.GUARANTEEDPERIOD               = T2.GUARANTEEDPERIOD,
           T1.RISKRETURNCHARACTER            = T2.RISKRETURNCHARACTER,
           T1.LOWESTSUMSUBSCRIBING           = T2.LOWESTSUMSUBSCRIBING,
           T1.LOWESTSUMREDEMPTION            = T2.LOWESTSUMREDEMPTION,
           T1.LSFRDESCRIPTION                = T2.LSFRDESCRIPTION,
           T1.LOWESTSUMFORHOLDING            = T2.LOWESTSUMFORHOLDING,
           T1.LSFHDESCRIPTION                = T2.LSFHDESCRIPTION,
           T1.FUNDNATURE                     = T2.FUNDNATURE,
           T1.FUNDTYPECODE                   = T2.FUNDTYPECODE,
           T1.FUNDTYPE                       = T2.FUNDTYPE,
           T1.CARRYOVERDATE                  = T2.CARRYOVERDATE,
           T1.CARRYOVERDATEREMARK            = T2.CARRYOVERDATEREMARK,
           T1.CARRYOVERTYPE                  = T2.CARRYOVERTYPE,
           T1.REGINSTCODE                    = T2.REGINSTCODE,
           T1.SECURITYCODE                   = T2.SECURITYCODE,
           T1.DELIVERYDAYS                   = T2.DELIVERYDAYS,
           T1.RISKRETURNCODE                 = T2.RISKRETURNCODE,
           T1.FLOATTYPE                      = T2.FLOATTYPE,
           T1.CUSTODYMARKET                  = T2.CUSTODYMARKET,
           T1.OPERATIONPERIOD                = T2.OPERATIONPERIOD,
           T1.OPERATIONPDUNITCODE            = T2.OPERATIONPDUNITCODE,
           T1.OPERATIONPDUNITNAME            = T2.OPERATIONPDUNITNAME,
           T1.IFINITIATINGFUND               = T2.IFINITIATINGFUND,
           T1.CLASSIFICATIONFUNDTYPE         = T2.CLASSIFICATIONFUNDTYPE,
           T1.AGRBENCHMKRATEOFSHAREA         = T2.AGRBENCHMKRATEOFSHAREA,
           T1.AGRBENCHMKRATEOFSHAREANOTES    = T2.AGRBENCHMKRATEOFSHAREANOTES,
           T1.REGULARSHARECONVERSIONNOTES    = T2.REGULARSHARECONVERSIONNOTES,
           T1.NONREGULARSHARECONVERSIONNOTES = T2.NONREGULARSHARECONVERSIONNOTES,
           T1.EXAPPLYINGMARKET               = T2.EXAPPLYINGMARKET,
           T1.EXAPPLYINGCODE                 = T2.EXAPPLYINGCODE,
           T1.EXAPPLYINGABBR                 = T2.EXAPPLYINGABBR,
           T1.SHAREPROPERTIES                = T2.SHAREPROPERTIES,
           T1.STCLEARINGDATE                 = T2.STCLEARINGDATE,
           T1.ENCLEARINGDATE                 = T2.ENCLEARINGDATE,
           T1.LOWESTSUMSUBLL                 = T2.LOWESTSUMSUBLL,
           T1.LOWESTSUMPURLL                 = T2.LOWESTSUMPURLL,
           T1.MAINCODE                       = T2.MAINCODE,
           T1.SECUCODE                       = T2.SECUCODE,
           T1.PRODFULLNAME                   = T2.PRODFULLNAME,
           T1.PRODABBNAME                    = T2.PRODABBNAME,
           T1.LISTEDSTATE                    = T2.LISTEDSTATE
    
  
  WHEN NOT MATCHED THEN
    INSERT
      (T1.ID,
       T1.INNERCODE,
       T1.ESTABLISHMENTDATE,
       T1.LISTEDDATE,
       T1.DURATION,
       T1.STARTDATE,
       T1.EXPIREDATE,
       T1.MANAGER,
       T1.INVESTADVISORCODE,
       T1.INVESTADVISORNAME,
       T1.TRUSTEECODE,
       T1.TRUSTEENAME,
       T1.WARRANTOR,
       T1.TYPE,
       T1.INVESTMENTTYPE,
       T1.INVESTSTYLE,
       T1.FOUNDEDSIZE,
       T1.INVESTORIENTATION,
       T1.INVESTTARGET,
       T1.PERFORMANCEBENCHMARK,
       T1.PROFITDISTRIBUTIONRULE,
       T1.INVESTFIELD,
       T1.BRIEFINTRO,
       T1.XGRQ,
       T1.JSID,
       T1.APPLYINGCODEFRONT,
       T1.APPLYINGCODEBACK,
       T1.GUARANTEEDPERIOD,
       T1.RISKRETURNCHARACTER,
       T1.LOWESTSUMSUBSCRIBING,
       T1.LOWESTSUMREDEMPTION,
       T1.LSFRDESCRIPTION,
       T1.LOWESTSUMFORHOLDING,
       T1.LSFHDESCRIPTION,
       T1.FUNDNATURE,
       T1.FUNDTYPECODE,
       T1.FUNDTYPE,
       T1.CARRYOVERDATE,
       T1.CARRYOVERDATEREMARK,
       T1.CARRYOVERTYPE,
       T1.REGINSTCODE,
       T1.SECURITYCODE,
       T1.DELIVERYDAYS,
       T1.RISKRETURNCODE,
       T1.FLOATTYPE,
       T1.CUSTODYMARKET,
       T1.OPERATIONPERIOD,
       T1.OPERATIONPDUNITCODE,
       T1.OPERATIONPDUNITNAME,
       T1.IFINITIATINGFUND,
       T1.CLASSIFICATIONFUNDTYPE,
       T1.AGRBENCHMKRATEOFSHAREA,
       T1.AGRBENCHMKRATEOFSHAREANOTES,
       T1.REGULARSHARECONVERSIONNOTES,
       T1.NONREGULARSHARECONVERSIONNOTES,
       T1.EXAPPLYINGMARKET,
       T1.EXAPPLYINGCODE,
       T1.EXAPPLYINGABBR,
       T1.SHAREPROPERTIES,
       T1.STCLEARINGDATE,
       T1.ENCLEARINGDATE,
       T1.LOWESTSUMSUBLL,
       T1.LOWESTSUMPURLL,
       T1.MAINCODE,
       T1.SECUCODE,
       T1.PRODFULLNAME,
       T1.PRODABBNAME,
       T1.LISTEDSTATE)
    VALUES
      (T2.ID,
       T2.INNERCODE,
       T2.ESTABLISHMENTDATE,
       T2.LISTEDDATE,
       T2.DURATION,
       T2.STARTDATE,
       T2.EXPIREDATE,
       T2.MANAGER,
       T2.INVESTADVISORCODE,
       T2.INVESTADVISORNAME,
       T2.TRUSTEECODE,
       T2.TRUSTEENAME,
       T2.WARRANTOR,
       T2.TYPE,
       T2.INVESTMENTTYPE,
       T2.INVESTSTYLE,
       T2.FOUNDEDSIZE,
       T2.INVESTORIENTATION,
       T2.INVESTTARGET,
       T2.PERFORMANCEBENCHMARK,
       T2.PROFITDISTRIBUTIONRULE,
       T2.INVESTFIELD,
       T2.BRIEFINTRO,
       T2.XGRQ,
       T2.JSID,
       T2.APPLYINGCODEFRONT,
       T2.APPLYINGCODEBACK,
       T2.GUARANTEEDPERIOD,
       T2.RISKRETURNCHARACTER,
       T2.LOWESTSUMSUBSCRIBING,
       T2.LOWESTSUMREDEMPTION,
       T2.LSFRDESCRIPTION,
       T2.LOWESTSUMFORHOLDING,
       T2.LSFHDESCRIPTION,
       T2.FUNDNATURE,
       T2.FUNDTYPECODE,
       T2.FUNDTYPE,
       T2.CARRYOVERDATE,
       T2.CARRYOVERDATEREMARK,
       T2.CARRYOVERTYPE,
       T2.REGINSTCODE,
       T2.SECURITYCODE,
       T2.DELIVERYDAYS,
       T2.RISKRETURNCODE,
       T2.FLOATTYPE,
       T2.CUSTODYMARKET,
       T2.OPERATIONPERIOD,
       T2.OPERATIONPDUNITCODE,
       T2.OPERATIONPDUNITNAME,
       T2.IFINITIATINGFUND,
       T2.CLASSIFICATIONFUNDTYPE,
       T2.AGRBENCHMKRATEOFSHAREA,
       T2.AGRBENCHMKRATEOFSHAREANOTES,
       T2.REGULARSHARECONVERSIONNOTES,
       T2.NONREGULARSHARECONVERSIONNOTES,
       T2.EXAPPLYINGMARKET,
       T2.EXAPPLYINGCODE,
       T2.EXAPPLYINGABBR,
       T2.SHAREPROPERTIES,
       T2.STCLEARINGDATE,
       T2.ENCLEARINGDATE,
       T2.LOWESTSUMSUBLL,
       T2.LOWESTSUMPURLL,
       T2.MAINCODE,
       T2.SECUCODE,
       T2.PRODFULLNAME,
       T2.PRODABBNAME,
       T2.LISTEDSTATE);

  --更新基金概况表的一级分类和二级分类
  MERGE INTO INFO.TINFO_JJGK A
  USING (SELECT PROD_CODE, PROD_FIRST_TYPE_NAME, PROD_SECOND_TYPE_NAME
           FROM SRC_PIF.CHINAMUTUALFUNDSECTOR) B
  ON (A.SECUCODE = B.PROD_CODE)
  WHEN MATCHED THEN
    UPDATE
       SET A.PROD_FIRST_TYPE_NAME  = B.PROD_FIRST_TYPE_NAME,
           A.PROD_SECOND_TYPE_NAME = B.PROD_SECOND_TYPE_NAME;

  --更新基金概况表的是否代销字段
  UPDATE INFO.TINFO_JJGK A
     SET A.IS_SELL =
         (SELECT COUNT(1) FROM TPIF_CPDM B WHERE B.CPDM = A.SECUCODE);

  --更新基金概况表的基金管理人ID字段，ID取自TPIF_JGDM机构代码表，根据机构名称匹配
  MERGE INTO INFO.TINFO_JJGK A
  USING (SELECT ID, JGMC FROM TPIF_JGDM) B
  ON (A.INVESTADVISORNAME = B.JGMC)
  WHEN MATCHED THEN
    UPDATE SET A.FUND_MANAGER_NOMINAL = B.ID;

  --更新基金概况表的基金托管人ID字段，ID取自TPIF_JGDM机构代码表，根据机构名称匹配
  MERGE INTO INFO.TINFO_JJGK A
  USING (SELECT ID, JGMC FROM TPIF_JGDM) B
  ON (A.TRUSTEENAME = B.JGMC)
  WHEN MATCHED THEN
    UPDATE SET A.FUND_CUSTODIAN = B.ID;

  --补充产品代码表的数据源及ID，用于和聚源匹配
  --可以理解，产品代码表SJLY=1的产品为公募产品
  UPDATE PIF.TPIF_CPDM A
     SET A.SJLY  = 1, --1聚源
         A.SJYID =
         (SELECT B.INNERCODE
            FROM INFO.TINFO_JJGK B
           WHERE B.SECUCODE = A.CPDM)
   WHERE EXISTS (SELECT 1 FROM INFO.TINFO_JJGK C WHERE C.SECUCODE = A.CPDM);

  --对于用SECUCODE没匹配到的数据，用后端代码再匹配一次，匹配到的话，只更新数据来源
  UPDATE PIF.TPIF_CPDM A
     SET A.SJLY = 1 --1聚源
   WHERE EXISTS (SELECT 1
            FROM INFO.TINFO_JJGK C
           WHERE C.APPLYINGCODEBACK = A.CPDM
             AND C.SECUCODE != A.CPDM
             AND C.LISTEDSTATE != 5);

  --更新产品代码表中公募基金(SJLY=1 聚源 ,不包含后端收费产品)的
  --产品名称、对应产品全称、基金管理人名称、基金托管人名称、基金经理名称
  --成立日期、募集开始日期、募集结束日期
  MERGE INTO PIF.TPIF_CPDM T1
  USING (SELECT T.SECUCODE,
                T.PRODFULLNAME,
                T.PRODABBNAME,
                T.INVESTADVISORNAME,
                T.TRUSTEENAME,
                /*(CASE
                  WHEN T.FUNDTYPECODE = 1101 THEN
                   300400 --股票型
                  WHEN T.FUNDTYPECODE = 1103 THEN
                   300500 --混合型
                  WHEN T.FUNDTYPECODE = 1105 THEN
                   300600 --债券型
                  WHEN T.FUNDTYPECODE = 1107 THEN
                   300700 --保本型
                  WHEN T.FUNDTYPECODE = 1109 THEN
                   300900 --货币型
                  WHEN T.FUNDTYPECODE = 1199 THEN
                   309000 --其他型
                END) AS FUNDTYPECODE,*/
                T.MANAGER,
                TO_NUMBER(TO_CHAR(T.ESTABLISHMENTDATE, 'YYYYMMDD')) AS CLRQ， --成立日期
                TO_NUMBER(TO_CHAR(A.ISSUESTARTDATE, 'YYYYMMDD')) AS MJKSRQ, --募集开始日期
                TO_NUMBER(TO_CHAR(A.ISSUEENDDATE, 'YYYYMMDD')) AS MJJSRQ --募集结束日期
           FROM INFO.TINFO_JJGK T
           LEFT JOIN INFO.TINFO_GMJJFXYSS A --公募基金发行与上市
             ON T.INNERCODE = A.INNERCODE) T2
  ON (T1.CPDM = T2.SECUCODE AND T1.SJLY = 1)
  WHEN MATCHED THEN
    UPDATE
       SET T1.CPMC    = T2.PRODFULLNAME,
           T1.CPJC    = T2.PRODABBNAME,  -- 20211230  公募名称取聚源
           T1.DYCPQC  = T2.PRODFULLNAME,
           T1.CPGLRMC = T2.INVESTADVISORNAME,
           T1.CPTGRMC = T2.TRUSTEENAME,
           
           --           T1.CPXL    = 1, --产品系列 1公募
           --           T1.JRCPFL  = T2.FUNDTYPECODE, --金融产品分类
           T1.TZFZR  = T2.MANAGER, --基金经理（用产品代码表的TZFZR投资负责人字段）
           T1.CLRQ   = T2.CLRQ,
           T1.MJKSRQ = T2.MJKSRQ,
           T1.MJJSRQ = T2.MJJSRQ;

  -- 只更新CPGLRID为空的信息       
  UPDATE PIF.TPIF_CPDM B
     SET B.CPGLRID =
         (SELECT ID
            FROM (SELECT T.ID,
                         T.JGMC,
                         T.JGJC,
                         ROW_NUMBER() OVER(PARTITION BY T.JGMC ORDER BY T.BASFYX DESC) ROW_NUMBER
                    FROM TPIF_JGDM T)
           WHERE ROW_NUMBER = 1
             AND (JGMC = B.CPGLRMC OR JGJC = B.CPGLRMC))
   WHERE B.CPGLRID IS NULL;

  --只更新CPTGR为空的数据
  UPDATE PIF.TPIF_CPDM B
     SET B.CPTGR =
         (SELECT ID
            FROM (SELECT T.ID,
                         T.JGMC,
                         T.JGJC,
                         ROW_NUMBER() OVER(PARTITION BY T.JGMC ORDER BY T.BASFYX DESC) ROW_NUMBER
                    FROM TPIF_JGDM T)
           WHERE ROW_NUMBER = 1
             AND (JGMC = B.CPTGRMC OR JGJC = B.CPTGRMC))
   WHERE B.CPTGR IS NULL;

  --更新CPTGRMC为空的数据，简称
  UPDATE PIF.TPIF_CPDM B
     SET B.CPTGRMC =
         (SELECT JGJC FROM TPIF_JGDM WHERE ID = B.CPTGR)
   WHERE B.CPTGRMC IS NULL;

  /*  --公募基金 产品名称为空用产品简称更新
  --（如果CPXL正确，按说公募的名称会在上一步中从聚源匹配）
  UPDATE PIF.TPIF_CPDM T
     SET T.CPMC = T.CPJC
   WHERE CPXL = 1
     AND CPMC IS NULL
     AND CPJC IS NOT NULL;*/

  /*  --不在聚源公募基金表中，在柜台产品表中的产品，更新名称
  UPDATE PIF.TPIF_CPDM T
     SET T.CPMC = T.CPJC
   WHERE EXISTS (SELECT 1
            FROM SRC_PIF.DWD_PRD_PRODCODE_DD A
           WHERE T.CPDM = A.PROD_CODE
             AND T.CPTA = A.PRODTA_NO)
     AND NOT EXISTS
   (SELECT 1 FROM INFO.TINFO_JJGK WHERE SECUCODE = T.CPDM);*/

  /*    --更新产品代码表:基金概况表的部分数据
  UPDATE PIF.TPIF_CPDM T1
     SET (T1.RYBH, T1.JJJLMC) =
         (SELECT T2.RYBH, T2.JJJLMC
            FROM (SELECT A.PERSONALCODE AS RYBH,
                         A.NAME AS JJJLMC,
                         C.SECUCODE,
                         ROW_NUMBER() OVER(PARTITION BY A.SECUCODE ORDER BY A.INFOPUBLDATE DESC) RN
                    FROM INFO.TINFO_JJGK C, INFO.TINFO_JJJLNEW A
                   WHERE A.SECUCODE = C.SECUCODE
                     AND A.INCUMBENT = 1
                     AND A.POSTNAME = 1) T2
           WHERE RN = 1
             AND T1.CPDM = T2.SECUCODE)
   WHERE T1.CPFLEJBM = '0202';
  COMMIT;*/

  /*    --更新产品代码表:基金管理人、托管人数据
  MERGE INTO PIF.TPIF_CPDM T
  USING (SELECT JJ.APPLYINGCODEBACK,
                JJ.APPLYINGCODEFRONT,
                JJ.INVESTADVISORCODE,
                JJ.TRUSTEECODE,
                B.INVESTADVISORNAME  AS CPGLR,
                C.TRUSTEENAME        AS CPZCTGR,
                C.TRUSTEENAME        AS CPFETGR
           FROM INFO.TINFO_JJGK JJ, INFO.TINFO_JJGLRGK B, INFO.TINFO_JJTGRGK C
          WHERE JJ.INVESTADVISORCODE = B.INVESTADVISORCODE(+)
            AND JJ.TRUSTEECODE = C.TRUSTEECODE(+)
            AND LENGTH(JJ.APPLYINGCODEFRONT) = 6 --限制基金代码长度为6(末尾跟J字母的不取)
            AND LENGTH(JJ.SECUCODE) = 6) T2
  ON (T.CPDM = T2.APPLYINGCODEBACK OR T.CPDM = T2.APPLYINGCODEFRONT)
  WHEN MATCHED THEN
      UPDATE
         SET T.CPGLR   = NVL(T2.CPGLR, T.CPGLR),
             T.CPZCTGR = NVL(T2.CPZCTGR, T.CPZCTGR),
             T.CPFETGR = NVL(T2.CPFETGR, T.CPFETGR)
       WHERE T.CPFLEJBM = '0202';*/

  --清洗至PIF 下的 公募基金概况附表，2021.06+ 基金经理、基金管理人详情页用到
  MERGE INTO PIF.TPIF_GMJJGKFB A
  USING (SELECT B.SECUCODE,
                B.CHINAMEABBR, --基金简称
                C.MC AS JJGSMC,
                C.ID AS JJGSID,
                (CASE
                  WHEN A.FUNDTYPECODE = 1101 THEN
                   300400 --股票型
                  WHEN A.FUNDTYPECODE = 1103 THEN
                   300500 --混合型
                  WHEN A.FUNDTYPECODE = 1105 THEN
                   300600 --债券型
                  WHEN A.FUNDTYPECODE = 1107 THEN
                   300700 --保本型
                  WHEN A.FUNDTYPECODE = 1109 THEN
                   300900 --货币型
                  WHEN A.FUNDTYPECODE = 1199 THEN
                   309000 --其他型
                END) AS FUNDTYPECODE
           FROM INFO.TINFO_JJGK A, --公募基金概况
                INFO.TINFO_ZQZB B, --证券主表
                PIF.TPIF_JJGLR  C --公募基金管理人
          WHERE A.INNERCODE = B.INNERCODE
            AND A.INVESTADVISORCODE = C.SJYID) B
  ON (A.JJDM = B.SECUCODE)
  WHEN MATCHED THEN
    UPDATE
       SET A.JJJC    = B.CHINAMEABBR,
           A.JJGLRMC = B.JJGSMC,
           A.JJGLRID = B.JJGSID,
           A.JRCPFL  = B.FUNDTYPECODE,
           A.GXSJ    = SYSDATE --修改时间
    
  
  WHEN NOT MATCHED THEN
    INSERT
      (A.ID,
       A.JJDM,
       A.JJJC,
       A.JJGLRMC,
       A.JJGLRID,
       A.SJLY, --数据来源 
       A.XZSJ, --新增时间
       A.JRCPFL)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_GMJJGKFB'),
       B.SECUCODE,
       B.CHINAMEABBR,
       B.JJGSMC,
       B.JJGSID,
       1, --1聚源
       SYSDATE,
       B.FUNDTYPECODE);

  --是否本公司代销  先全部置为0，
  UPDATE PIF.TPIF_GMJJGKFB A SET A.SFBGSDX = 0;
  --后修复代销状态
  UPDATE PIF.TPIF_GMJJGKFB A
     SET A.SFBGSDX = 1
   WHERE EXISTS (SELECT 1
            FROM TPIF_CPDM B
           WHERE B.CPDM = A.JJDM
             AND B.SJLY = 1);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'INFO.TINFO_JJGK & PIF.TPIF_GMJJGKFB 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1; --运行失败
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'INFO.TINFO_JJGK & PIF.TPIF_GMJJGKFB 表清洗,未知错误'
                ELSE
                 'INFO.TINFO_JJGK & PIF.TPIF_GMJJGKFB 表清洗,在 ' || O_NOTE ||
                 ' 时出现异常'
              END) || ':' || SQLERRM;
    ROLLBACK;
  
END P_TRAN_JJGK;
/

