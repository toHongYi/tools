create procedure pcx_pif_cpqj_tlpm_out(o_code        out number,
                                              o_note        out varchar2,
                                              o_result      out sys_refcursor,
                                              i_userid  in number,
                                              i_ip      in varchar2,
                                              i_prod_id     in number, --产品ID
                                              i_granularity in number, --粒度  1|一个月,2|三个月,3|半年,4|一年,5|今年以来,6|成立以来
                                              i_type        in number --查询类别 1|近一周,2|近一月,3|近三月,4|近半年,5|近一年
                                              ) as
  /******************************************************************
  项目名称：产品中心-产品全景-同类排名
  所属用户：PIF
  概要说明：同类排名.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        同类排名.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/05/08     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql  varchar2(32767);
  v_date number(8);
  v_col  varchar2(100); --查询列
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_prod_id is null then
    o_note := '产品ID不允许为空！';
    return;
  end if;
  if i_granularity is null then
    o_note := '粒度不允许为空！';
    return;
  end if;
   if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;
  --取查询列
  select case i_type
           when 1 then
            'SIMILAR_RANK_RECENTWEEK'
           when 2 then
            'SIMILAR_RANK_RECENTMONTH'
           when 3 then
            'SIMILAR_RANK_RECENTQUARTER'
           when 4 then
            'SIMILAR_RANK_RECENTHALFYEAR'
           when 5 then
            'SIMILAR_RANK_RECENTYEAR'
           else
            'SIMILAR_RANK_RECENTQUARTER'
         end
    into v_col
    from dual;
  --取查询月份
  if i_granularity = 1 then
    --一个月
    select to_number(to_char(add_months(sysdate, -1), 'yyyymmdd'))
      into v_date
      from dual;
  end if;
  if i_granularity = 2 then
    --三个月
    select to_number(to_char(add_months(sysdate, -3), 'yyyymmdd'))
      into v_date
      from dual;
  end if;
  if i_granularity = 3 then
    --半年
    select to_number(to_char(add_months(sysdate, -6), 'yyyymmdd'))
      into v_date
      from dual;
  end if;
  if i_granularity = 4 then
    --一年
    select to_number(to_char(add_months(sysdate, -12), 'yyyymmdd'))
      into v_date
      from dual;
  end if;
  if i_granularity = 5 then
    --今年以来
    select to_number(to_char(sysdate, 'yyyy') || '0101')
      into v_date
      from dual;
  end if;
  if i_granularity = 6 then
    --成立以来
    select nvl(a.establish_day, 29991231)
      into v_date
      from pif.tprod_basic_info a
     where id = i_prod_id;
  end if;
  v_sql := 'select trade_date trade_date,
                    ' || v_col || ' similar_rank
            from tTFUND_PERFORMANCE
            where prod_id = ' || i_prod_id || '
            and trade_date >= ' || v_date;
  dbms_output.put_line(v_sql);
  open o_result for v_sql;

  o_code := 0;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end pcx_pif_cpqj_tlpm_out;
/

