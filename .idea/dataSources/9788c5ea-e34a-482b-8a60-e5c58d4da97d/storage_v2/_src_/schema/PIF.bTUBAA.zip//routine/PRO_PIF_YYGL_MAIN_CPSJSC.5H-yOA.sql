create PROCEDURE PRO_PIF_YYGL_MAIN_CPSJSC(O_CODE OUT NUMBER,
                                                         O_NOTE OUT VARCHAR2,
                                                         I_RQ   NUMBER DEFAULT NULL --日期
                                                         ) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：产品事件生成
          I_RQ    --日期
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
         关联调度
    运行原理：
          1.入参校验
         2.获取事件类型，执行事件调度。
           2.1获取事件类型。
           2.2生成产品事件。
    功能修订：
        简要说明：
          产品事件生成调度主过程
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/14     1.0.1     林嵩              运营管理调度主过程。
        2014/12/10     1.0.2     刘浪浪            事件生成对应日志的默认类型为日常
        2015/01/27     1.0.3     刘浪浪            日期入参由VARCHAR2改为NUMBER
    *********************************************************************************************************************/
    V_KSRQ NUMBER(8) DEFAULT I_RQ; --当前日期
    V_JSRQ NUMBER(8); --结束日期

BEGIN
    O_CODE := 1;
    O_NOTE := '成功';
    --1.***************************入参校验 ***************************
    --当前变量赋值
    IF V_KSRQ IS NULL THEN
        V_KSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
    END IF;

     --默认取结束日期为3个月末
    SELECT TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(V_KSRQ, 'YYYYMMDD'), 3)), 'YYYYMMDD')
      INTO V_JSRQ
      FROM DUAL;

    --2.***************************获取事件类型，执行事件调度。***************************
    --2.1、删除开始日后已生成数据
    DELETE FROM TPIF_CPSJ WHERE SJKSSJ >= TO_DATE(V_KSRQ, 'YYYYMMDD');
    COMMIT;
    --2.2、生成新的数据
    FOR CUR_SJLX IN (SELECT A.ID, A.DYGC
                       FROM TPIF_CPSJLX A
                      WHERE A.DYGC IS NOT NULL ) LOOP
        PRO_PIF_YYGL_CPSJSC(O_CODE, O_NOTE, CUR_SJLX.ID, CUR_SJLX.DYGC, 1, V_KSRQ,V_JSRQ);
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_MAIN_CPSJSC;
/

