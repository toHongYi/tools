create PROCEDURE PCX_PIF_JJJLQJ_ZCHY(O_CODE   OUT NUMBER, --返回值
                                                O_NOTE   OUT VARCHAR2, --返回信息
                                                O_RESULT OUT SYS_REFCURSOR, --返回的数据集合
                                                I_USERID     IN NUMBER, --登陆用户ID，预留，便于后面文档查询的权限控制
                                                I_MANAGER_ID IN NUMBER --基金经理ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-基金经理全景-重仓行业
  所属用户：PIF
  概要说明：查询基金经理的重仓行业

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
       输入参数：
          I_USERID        登陆用户ID，预留，便于后面文档查询的权限控制
          I_MANAGER_ID    基金经理ID

  运行原理：


  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/06    1.0.0     杨啸天             新增.
  *****************************************************************************/

BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';
  --条件检验
  IF I_MANAGER_ID IS NULL THEN
    O_NOTE := '产品经理ID不允许为空！';
    RETURN;
  END IF;

  --查询四个季度占资产净值比例前五的五个行业
  OPEN O_RESULT FOR
    SELECT QUARTER, INDUSTRY_NAME, ASSETS_RATE
      FROM (SELECT BBQ QUARTER, --报告季度
                   HYMC INDUSTRY_NAME, --行业名称
                   ZZCJZBL*100 ASSETS_RATE, --占资产净值比例
                   DENSE_RANK() OVER(ORDER BY BBQ DESC) PX1,
                   ROW_NUMBER() OVER(PARTITION BY BBQ ORDER BY ZZCJZBL DESC) PX2
              FROM DSC_STAT.TPIF_STAT_JJJL_ZCHY A
             WHERE A.JJJLID = I_MANAGER_ID)
     WHERE PX1 <= 4
       AND PX2 <= 5;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;

END PCX_PIF_JJJLQJ_ZCHY;
/

