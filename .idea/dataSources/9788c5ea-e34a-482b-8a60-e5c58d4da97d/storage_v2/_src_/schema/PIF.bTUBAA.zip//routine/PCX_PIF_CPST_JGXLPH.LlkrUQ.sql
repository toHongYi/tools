create PROCEDURE PCX_PIF_CPST_JGXLPH(O_CODE             OUT NUMBER,
                                                    O_NOTE             OUT VARCHAR2,
                                                    O_RESULT           OUT SYS_REFCURSOR,
                                                    I_STATISTIC_PERIOD IN NUMBER  --统计周期:1|近1月2|近3月3|近半年4|近1年

                                                    ) AS

  /*--------------------------------------------------------------------------------------------

  项目名称：产品中心

         功能说明：产品视图-机构销量排行
             参数说明：
                  入参：
                         I_STATISTIC_PERIOD IN NUMBER, --统计周期:1|近1月2|近3月3|近半年4|近1年

                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,


        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增

  -----------------------------------------------------------------------------------------------*/
 
  V_QSYF NUMBER(6);
  V_JSYF NUMBER(6);
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_STATISTIC_PERIOD IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_STATISTIC_PERIOD不能为空!';
    RETURN;
  END IF;

  V_JSYF := TO_CHAR(SYSDATE - 1, 'YYYYMM');
  --产品销量榜

  --近1月
  IF I_STATISTIC_PERIOD = 1 THEN

    V_QSYF := TO_CHAR(ADD_MONTHS(TO_DATE(V_JSYF, 'YYYYMM'), -1), 'YYYYMM');

    --近3月
  ELSIF I_STATISTIC_PERIOD = 2 THEN

    V_QSYF := TO_CHAR(ADD_MONTHS(TO_DATE(V_JSYF, 'YYYYMM'), -3), 'YYYYMM');

    --近半年
  ELSIF I_STATISTIC_PERIOD = 3 THEN

    V_QSYF := TO_CHAR(ADD_MONTHS(TO_DATE(V_JSYF, 'YYYYMM'), -6), 'YYYYMM');

    --近1年
  ELSE

    V_QSYF := TO_CHAR(ADD_MONTHS(TO_DATE(V_JSYF, 'YYYYMM'), -12), 'YYYYMM');

  END IF;

  OPEN O_RESULT FOR
    SELECT ORG_ID,ORG_NAME,SALE_SCALE

    FROM(

      SELECT B.ID AS ORG_ID,
           B.NAME AS ORG_NAME,
           ROUND(SUM(A.XSGM) / 10000, 4) AS SALE_SCALE

      FROM DSC_STAT.TPIF_STAT_CPDM_XSTJ_Y A, LIVEBOS.LBORGANIZATION B
     WHERE A.JGDM = B.ID
       AND A.SJRQ between V_QSYF and V_JSYF
     GROUP BY B.ID, B.NAME
     ORDER BY SALE_SCALE DESC ) WHERE ROWNUM<=10;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;

END;
/

