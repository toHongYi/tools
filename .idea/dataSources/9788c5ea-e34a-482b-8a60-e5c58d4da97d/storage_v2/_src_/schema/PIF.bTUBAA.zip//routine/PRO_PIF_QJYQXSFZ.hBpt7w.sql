create PROCEDURE PRO_PIF_QJYQXSFZ(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_USER IN INTEGER, --操作人
                                                 I_IP   IN VARCHAR2, --操作IP
                                                 I_OPER IN INTEGER,--操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;6|上移;7|下移;
                                                 I_ID IN INTEGER --操作ID
                                                 ) IS
    /*
    **功能说明：页签显示分组管理
    **创建人：戴文生
    **创建日期：2014-12-01
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生              2014-12-01    创建
    */
    V_COUNT INTEGER; --计数变量
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSPX  INTEGER; --显示排序
    V_OBJ   TPIF_QJYQXSFZ%ROWTYPE; --表单记录
    V_MBZT INTEGER;
    V_SQL VARCHAR2(8000);
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_QJYQXSFZ WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT NVL(MBZT,0) INTO V_MBZT FROM TPIF_CPQJMBDY WHERE ID = V_OBJ.QJMB;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF V_OBJ.FZBM IS NULL THEN
            O_NOTE := '[分组编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FZMC IS NULL THEN
            O_NOTE := '[分组名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.XSLS IS NULL THEN
            O_NOTE := '[显示列数]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_QJYQXSFZ WHERE QJMB = V_OBJ.QJMB  AND FZBM = V_OBJ.FZBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[分组编码]--'||V_OBJ.FZBM||'!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_QJYQXSFZ WHERE QJMB = V_OBJ.QJMB  AND XSPX = V_OBJ.XSPX;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[显示顺序]--'||V_OBJ.XSPX||'!';
            RETURN;
        END IF;
        IF TRIM(V_OBJ.XSTJ) IS NOT NULL THEN
            BEGIN
                V_SQL := 'SELECT COUNT(1) FROM DUAL WHERE 1 = 1 AND '|| REPLACE(V_OBJ.XSTJ,'{CPID}',' 0 ');
                EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                EXCEPTION WHEN OTHERS THEN
                    O_NOTE := '[显示条件]配置异常!';
                    RETURN;
            END;
        END IF;
        IF V_OBJ.XSPX IS NULL THEN
            UPDATE TPIF_QJYQXSFZ
               SET XSPX = (SELECT NVL(MAX(T.XSPX), 0) + 1
                             FROM TPIF_QJYQXSFZ T
                            WHERE T.QJMB = V_OBJ.QJMB )
             WHERE ID = I_ID;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 AND V_MBZT = 1 THEN
            O_NOTE := '当前分组及模板已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.FZBM IS NULL THEN
            O_NOTE := '[分组编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FZMC IS NULL THEN
            O_NOTE := '[分组名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.XSLS IS NULL THEN
            O_NOTE := '[显示列数]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_QJYQXSFZ WHERE QJMB = V_OBJ.QJMB  AND FZBM = V_OBJ.FZBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[分组编码]--'||V_OBJ.FZBM||'!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_QJYQXSFZ WHERE QJMB = V_OBJ.QJMB  AND XSPX = V_OBJ.XSPX;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[显示顺序]--'||V_OBJ.XSPX||'!';
            RETURN;
        END IF;
        IF TRIM(V_OBJ.XSTJ) IS NOT NULL THEN
            BEGIN
                V_SQL := 'SELECT COUNT(1) FROM DUAL WHERE 1 = 1 AND '|| REPLACE(V_OBJ.XSTJ,'{CPID}',' 0 ');
                EXECUTE IMMEDIATE V_SQL INTO V_COUNT;
                EXCEPTION WHEN OTHERS THEN
                    O_NOTE := '[显示条件]配置异常!';
                    RETURN;
            END;
        END IF;
        IF V_OBJ.XSPX IS NULL THEN
            UPDATE TPIF_QJYQXSFZ
               SET XSPX = (SELECT NVL(MAX(T.XSPX), 0) + 1
                             FROM TPIF_QJYQXSFZ T
                            WHERE T.QJMB = V_OBJ.QJMB )
             WHERE ID = I_ID;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 AND V_MBZT = 1 THEN
            O_NOTE := '当前分组及模板已启用,不允许执行[删除]操作!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_QJYQXSFZ', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前分组已存在引用记录!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_QJYQXSFZ WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前分组已[启用]!';
            RETURN;
        END IF;
        UPDATE TPIF_QJYQXSFZ SET ZT = 1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF V_OBJ.ZT = -1 THEN
            O_NOTE := '当前分组已[禁用]!';
            RETURN;
        END IF;
        IF V_MBZT = 1 THEN
            O_NOTE := '当前主模板定义记录已[启用]!';
            RETURN;
        END IF;
        UPDATE TPIF_QJYQXSFZ SET ZT = -1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 6 THEN
        --上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_QJYQXSFZ
         WHERE QJMB = V_OBJ.QJMB 
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前页签范围内不存在其他分组!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_QJYQXSFZ
         WHERE QJMB = V_OBJ.QJMB 
           AND ID != I_ID
           AND XSPX < V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前分组已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_QJYQXSFZ T
         WHERE T.QJMB = V_OBJ.QJMB 
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MAX(A.XSPX)
                           FROM TPIF_QJYQXSFZ A
                          WHERE A.QJMB = V_OBJ.QJMB 
                            AND A.ID != I_ID
                            AND A.XSPX < V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_QJYQXSFZ SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_QJYQXSFZ SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 7 THEN
        --下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_QJYQXSFZ
         WHERE QJMB = V_OBJ.QJMB 
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前页签范围内不存在其他分组!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_QJYQXSFZ
         WHERE QJMB = V_OBJ.QJMB 
           AND ID != I_ID
           AND XSPX > V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前分组已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_QJYQXSFZ T
         WHERE T.QJMB = V_OBJ.QJMB 
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MIN(A.XSPX)
                           FROM TPIF_QJYQXSFZ A
                          WHERE A.QJMB = V_OBJ.QJMB 
                            AND A.ID != I_ID
                            AND A.XSPX > V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_QJYQXSFZ SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_QJYQXSFZ SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           6,
                           '上移',
                           '下移') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_QJYQXSFZ;

/

