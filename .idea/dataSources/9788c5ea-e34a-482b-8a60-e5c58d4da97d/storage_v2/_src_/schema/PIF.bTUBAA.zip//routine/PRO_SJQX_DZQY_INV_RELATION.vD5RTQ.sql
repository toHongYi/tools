create PROCEDURE PRO_SJQX_DZQY_INV_RELATION
(
    O_CODE OUT NUMBER, --返回值
    O_NOTE OUT VARCHAR2 --返回消息
) IS

    /******************************************************************
        所属用户：PIF
        功能说明：电子签约投资人关联项目表 PIF.DZQY_INVESTOR_PROJECT_RELATION 数据清洗逻辑
        语法信息：
             输入参数：   无
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2022-1-5       1.0       HANQN              创建

    ***********************************************************************/

BEGIN
    O_CODE := -1;
    O_NOTE := '';

  MERGE INTO DZQY_INVESTOR_PROJECT_RE_TEST T
  USING (SELECT A.FUND_CODE, 
                A.OPERATOR_NO, 
                A.INVESTOR_NO, 
                A.TYPE AS INVESTOR_TYPE, 
                DECODE(A.RISKMATCH,1,1,2) AS RISK_MATCH, 
                A.RECORDHASH AS DOUBLE_RECORD_HASH, 
                CASE WHEN A.IS_PUSH =1 THEN SYSDATE ELSE NULL END AS PUSH_DATE, 
                A.FUND_INVESTOR_ID, 
                NVL(A.SIGN_PROCESS_FLAG,0) AS SIGN_PROCESS_FLAG, 
                B.PROD_CODE
           FROM SRC_PIF.PROD_INVESTOR_RELATIONS A,
                SRC_PIF.PROD_PROJ_INFO B
           WHERE A.FUND_CODE=B.FUND_CODE
         ) S 
  ON (T.FUND_CODE = S.FUND_CODE AND T.INVESTOR_NO = S.INVESTOR_NO)
  WHEN NOT MATCHED THEN
    INSERT(t.id, 
           t.fund_code, 
           t.prod_code, 
           t.create_date, 
           t.last_modified_date, 
           t.deleted_flag, 
           t.operator_no, 
           t.investor_no, 
           t.double_record_hash, 
           t.fund_investor_id, 
           t.investor_type, 
           t.risk_match, 
           t.push_date, 
           t.sign_process_flag 
      )
    VALUES
      (LIVEBOS.FUNC_NEXTID('DZQY_INVESTOR_PROJECT_RE_TEST'),
       s.fund_code, 
       s.prod_code, 
       SYSDATE, 
       SYSDATE,
       2, 
       s.operator_no, 
       s.investor_no, 
       s.double_record_hash,
       s.fund_investor_id, 
       s.investor_type, 
       s.risk_match, 
       s.push_date, 
       s.sign_process_flag 
       );

    COMMIT;
    O_CODE := 1;
    O_NOTE := 'DZQY_INVESTOR_PROJECT_RELATION 表清洗成功';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       'DZQY_INVESTOR_PROJECT_RELATION 表清洗,未知错误'
                      ELSE
                       'DZQY_INVESTOR_PROJECT_RELATION ,在 ' || O_NOTE ||
                       ' 时出现异常'
                  END) || ':' || SQLERRM;
END;
/

