create procedure pro_check_xxzccpdm(o_code out number,
                                             o_note out varchar2,
                                             i_CPDM  in varchar2) is

  /*
      项目：中信建投
      过程作用：校验产品代码如果存在多代码，需用斜杠分割，代码由字母数字组合
      创建人                  版本                 说明                 时间

  */

  v_count number(10);

begin

   if i_CPDM is null then
    o_code := -1;
    o_note := '产品代码必填！';
    return;
     end if;

  for x in (select column_value from table(split(i_CPDM, '/'))) loop
    select count(1)
      into v_count
      from dual
     where regexp_like(x.column_value,'^[0-9A-Za-z]+$');
    if v_count > 0 then
      o_code := 1;
      o_note := '检验成功！';
    else
      o_code := -1;
      o_note := '填写内容不符合要求！';
      return;
    end if;
  end loop;
exception
  when others then
    o_code := -1;
    o_note := sqlerrm;
    return;
end pro_check_xxzccpdm;
/

