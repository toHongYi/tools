create PROCEDURE PCX_KHBF_LB(O_CODE    OUT NUMBER,--错误代码
                                        O_NOTE    OUT VARCHAR2,--错误消息
                                        O_RESULT  OUT SYS_REFCURSOR,--返回结果集
                                        I_CURRENT    IN NUMBER, --页码
                                        I_PAGESIZE   IN NUMBER, --页长
                                        I_PAGING     IN NUMBER, --是否分页
                                        I_SORT       IN STRING, --排序规模
                                        I_TOTAL      IN OUT NUMBER, --记录总数

                                        I_USERID     IN INTEGER, --用户ID
                                        I_MY_VISIT   IN NUMBER,--1是，0否，不传=否=全部
                                        I_KEYWORD    IN VARCHAR2 --关键词
                                        )AS
                                        
/******************************************************************
  项目名称：财通证券运营展业平台-客户拜访
  所属用户：PIF
  概要说明：客户拜访列表查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分
          I_MY_VISIT  是否只查看自己的拜访记录，1是，0否，不传=否=查看全部拜访记录
          I_KEYWORD   关键词，需求名称搜索关键词

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   GAOKUN            新增.
  ********************************************************************/                                        

  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
BEGIN

  --初始化
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  --条件检验
  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '登陆用户ID不允许为空！';
    RETURN;
  END IF;

  V_SQL:=
  'SELECT A.ID,
       A.JGMC||TO_CHAR(TO_DATE(A.JLRQ,''YYYYMMDD''),''MM-DD'')||''拜访记录''  COMM_SUBJECT,   
       A.JLRQ  COMM_DATE,
       A.JLDXLX COMM_OBJECT_TYPE,
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.NOTE)), '','', '';'')
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = ''PIF_JLDXLX''
           AND INSTR('';'' || A.JLDXLX || '';'', '';'' || B.IBM || '';'') > 0) COMM_OBJECT_TYPE_NAME,
       A.JLDX COMM_OBJECT,
       A.DYJLXS COMM_FORM,
       A.JGID VISIT_ORG_ID,
       A.JGMC ORG_NAME,
       A.JGXZ ORG_PROP,
       A.GSZJGLGM CORP_FUND_MANAGE_SCALE,
       A.GSHXTYTD CORP_CORE_RESEARCH_PERSON,
       A.JGHXCL ORG_CORE_POLICY,
       A.QTQKSM OTHER_CONDITION_DESC,
       C.XQMC REQUEST_NAME,
       
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.BM)), '','', '';'')
          FROM TPIF_XQLX B
         WHERE INSTR('';'' || C.XQLX || '';'','';'' || B.ID || '';'') > 0 ) REQUEST_TYPE,
       
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.MC)), '','', '';'')
          FROM tpif_xqlx B
         WHERE INSTR('';'' || C.XQLX || '';'','';'' || B.ID || '';'') > 0)  REQUEST_TYPE_NAME,
         
       C.FBRQ PUBLISH_DATE,
       C.SJYWDY INVOLVE_BUSINESS_UNIT,
       (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.NOTE)), '','', '';'')
          FROM LIVEBOS.TXTDM B
         WHERE B.FLDM = ''PIF_SJYWDY''
           AND INSTR('';'' || C.SJYWDY || '';'', '';'' || B.IBM ||'';'') > 0) INVOLVE_BUSINESS_NAME,
       C.YWXQSM  BUSINESS_REQUEST_DESC,
       C.XQMZQK REQUEST_SATISFY_CONDITION,
       A.JGGDFX ORG_MARKET_VIEW_SHARING,
       A.HYZXFX INDUSTRY_INFO_SHARING,
       (SELECT NAME FROM LIVEBOS.TUSER WHERE ID=A.DJR) REG_PERSON,
       A.DJRQ REG_DATE，
       A.BMMC  GROUP_NAME,
       A.DKLX  CHECKIN_TYPE,
       A.DD    LOCATION_TITLE,
       A.WZMX  LOCATION_DETAIL,
       A.DKSJ  CHECKIN_TIME,
       A.SFHXZC IS_CORE_PROPERTY,
       A.FJMC FILE_NAME,
       A.OSSURL OSS_URL,
       A.WZLJ ARTICLE_LINK,
       A.SCLX SKIP_TYPE
       
  FROM PIF.TPIF_BFJL A,TPIF_XQXX C
 WHERE  A.YWXQ=C.ID'||' AND A.JGMC LIKE ''%'||I_KEYWORD||'%'' ';

 IF I_MY_VISIT =1 THEN
   V_SQL:=V_SQL||' AND A.DJR='||I_USERID;
 END IF;

 IF V_SORT IS NULL THEN
    V_SORT := 'COMM_DATE DESC';
  END IF;

  DBMS_OUTPUT.PUT_LINE(V_SQL);

  V_COLLIST := 'ID,COMM_SUBJECT,COMM_DATE,COMM_OBJECT_TYPE,COMM_OBJECT_TYPE_NAME,COMM_OBJECT,COMM_FORM,VISIT_ORG_ID,ORG_NAME,ORG_PROP,CORP_FUND_MANAGE_SCALE,CORP_CORE_RESEARCH_PERSON,ORG_CORE_POLICY,OTHER_CONDITION_DESC,REQUEST_NAME,REQUEST_TYPE,REQUEST_TYPE_NAME,PUBLISH_DATE,INVOLVE_BUSINESS_UNIT,INVOLVE_BUSINESS_NAME,BUSINESS_REQUEST_DESC,REQUEST_SATISFY_CONDITION,ORG_MARKET_VIEW_SHARING,INDUSTRY_INFO_SHARING,REG_PERSON,REG_DATE,GROUP_NAME,CHECKIN_TYPE,LOCATION_TITLE,LOCATION_DETAIL,CHECKIN_TIME,IS_CORE_PROPERTY,FILE_NAME,OSS_URL,ARTICLE_LINK,SKIP_TYPE';
  
  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;

END;
/

