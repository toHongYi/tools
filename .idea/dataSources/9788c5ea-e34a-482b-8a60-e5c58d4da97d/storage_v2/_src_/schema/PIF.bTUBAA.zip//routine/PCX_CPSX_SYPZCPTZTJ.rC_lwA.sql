create procedure pcx_cpsx_sypzcptztj(cur_result out types.cursortype,
                                                i_rq    in number ) is
  /*  项目：中信建投产品中心
      功能作用： 收益凭证产品台账统计

      作者      版本    创建时间      说明
      侯金铂    1.0.0   20190211      创建

  */
    v_sql   varchar2(2000);

begin

    v_sql := 'select '''|| i_rq ||''' as 日期,
             sum(a.rgzje) 认购总金额
        from tpif_sypzcptz a
      where '||i_rq||' >= clrq and '||i_rq||' <= dqrq ' ;

    open cur_result for v_sql;


exception
  when others then
    rollback;
    v_sql := 'SELECT ' || sqlerrm || ' FROM DUAL';
    open cur_result for v_sql;

end pcx_cpsx_sypzcptztj;
/

