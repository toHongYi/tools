create procedure PRO_CPYY_TEST( O_CODE OUT NUMBER,   --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                    I_ID IN NUMBER
                                                   )IS

V_ID NUMBER;

  BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';



  SELECT   ID INTO   V_ID  FROM TPIF_YYCPGL  WHERE ID =I_ID;

  COMMIT;

    EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
ROLLBACK;
END;
/

