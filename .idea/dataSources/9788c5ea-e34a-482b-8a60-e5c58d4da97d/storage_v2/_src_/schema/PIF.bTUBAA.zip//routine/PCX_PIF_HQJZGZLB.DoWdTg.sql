create PROCEDURE PCX_PIF_HQJZGZLB(CUR_RESULT OUT TYPES.CURSORTYPE, --返回结果集
                                                 I_TYEP     IN VARCHAR2 --0|未有净值数据;1|一月内无净值数据;2|一月内净值无维护
                                                 ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：获取产品净值跟踪列表
        语法信息：
             输入参数：   I_TYEP     IN INTEGER --0|未有净值数据;1|一月内无净值数据;2|一月内净值无维护;3|一月内无净值更新
             输出参数：   CUR_RESULT OUT TYPES.CURSORTYPE, --返回结果集
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-25     1.0.1    陈勇军                创建
    ***********************************************************************/
    V_PDRQ INTEGER; --判断日期
    V_SQL  VARCHAR2(2000);
    V_NOTE VARCHAR2(2000);
BEGIN
    --init
    SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMMDD')) INTO V_PDRQ FROM DUAL;
    --start
    V_SQL := 'SELECT ID,CPID,CPDM,CPMC,JRCPFL,CLRQ,DQRQ,JZRQ,CPJZ,LJJZ FROM TPIF_CPDM WHERE CPNBZT = 8 ';
    IF I_TYEP = 0 THEN
        V_SQL := V_SQL || ' AND JZRQ IS NULL ';
    END IF;
    IF I_TYEP IN (1,3) THEN
        V_SQL := V_SQL || ' AND NVL(JZRQ,0) < ' || V_PDRQ;
    END IF;
/*    IF I_TYEP IN (2,3) THEN
        V_SQL := V_SQL || ' AND NVL(ZJWHRQ,0) < ' || V_PDRQ;
    END IF;*/
    V_SQL := V_SQL || ' ORDER BY CPID DESC';
    OPEN CUR_RESULT FOR V_SQL;
EXCEPTION
    WHEN OTHERS THEN
        V_NOTE := SQLERRM;
        OPEN CUR_RESULT FOR
            SELECT '异常信息:' || V_NOTE FROM DUAL;
END PCX_PIF_HQJZGZLB;
/

