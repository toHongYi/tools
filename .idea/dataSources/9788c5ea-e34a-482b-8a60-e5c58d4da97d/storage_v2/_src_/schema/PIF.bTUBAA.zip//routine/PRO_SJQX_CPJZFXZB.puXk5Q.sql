create PROCEDURE PRO_SJQX_CPJZFXZB(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2, --返回消息
                                              I_RQ   IN NUMBER DEFAULT NULL) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品净值分析指标-数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-06     1.0       吴金锋              创建
          2020-12-14               GAOKUN               XIU GAI
  ***********************************************************************/
  V_JSRQ NUMBER;
  V_KSRQ NUMBER;
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_RQ IS NULL THEN
    --计算上个交易日的
    SELECT MAX(JYR)
      INTO V_JSRQ
      FROM LIVEBOS.TXTJYR A
     WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
  ELSE
    V_JSRQ := I_RQ;
  END IF;
  --只跑一天的数据，默认上一个交易日，支持手动输入日期
  PIF.PRO_SJQX_CP_SYTZ(V_CODE, V_NOTE, V_JSRQ);
  PIF.PRO_SJQX_CP_FXTZ(V_CODE, V_NOTE, V_JSRQ);
  PIF.PRO_SJQX_CP_FXTZHSY(V_CODE, V_NOTE, V_JSRQ);

  /*  SELECT MAX(JYR)
     INTO V_KSRQ
     FROM LIVEBOS.TXTJYR A          --改为最近3天 
    WHERE A.JYR < TO_CHAR(TO_DATE(V_JSRQ, 'YYYYMMDD') - 7,'YYYYMMDD');
  
  FOR CUR_RQ IN(SELECT JYR FROM LIVEBOS.TXTJYR  WHERE ZRR=JYR AND ZRR >= V_KSRQ AND ZRR<=V_JSRQ ORDER BY ZRR ASC ) LOOP
     
     PIF.PRO_SJQX_CP_SYTZ(V_CODE,V_NOTE,CUR_RQ.JYR);
     PIF.PRO_SJQX_CP_FXTZ(V_CODE,V_NOTE,CUR_RQ.JYR);
     PIF.PRO_SJQX_CP_FXTZHSY(V_CODE,V_NOTE,CUR_RQ.JYR);
  
  END LOOP ;*/

  COMMIT;
  O_CODE := 1;
  O_NOTE := '产品净值分析指标-数据清洗逻辑 执行成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '产品净值分析指标-数据清洗逻辑,未知错误'
                ELSE
                 '产品净值分析指标-数据清洗逻辑,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

