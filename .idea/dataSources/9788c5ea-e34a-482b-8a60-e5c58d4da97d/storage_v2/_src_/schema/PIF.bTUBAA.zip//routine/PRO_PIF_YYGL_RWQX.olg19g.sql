create PROCEDURE PRO_PIF_YYGL_RWQX(O_CODE   OUT NUMBER,
                                                  O_NOTE   OUT VARCHAR2,
                                                  I_USERID IN NUMBER, --系统登录人ID
                                                  I_IP     IN VARCHAR2, --登录IP地址
                                                  i_task_id   IN NUMBER, --运营任务ID
                                                  i_CANCEL_REASON IN VARCHAR2 --取消原因
                                                  ) AS

    /*--------------------------------------------------------------------------------------------
    
    项目名称：海通证券产品中心
    
           功能说明：任务取消
               参数说明：
                    入参：
                         I_USERID   IN NUMBER,       --系统登录人ID
                         I_IP       IN VARCHAR2,     --登录IP地址
                         i_task_id     IN NUMBER        --运营任务ID
    
    
                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,
    
    
          ----------------------------------------------------------
          操作人   版本号    时间                         操作
          刘浪浪   1.0.1   2014/11/18                  新增
          刘浪浪   1.0.2   2014/12/18                  只有在处理中的任务才能取消
    
    -------------------------------------------------------------------------------------------------*/
    V_COUNT NUMBER(8);
BEGIN

    O_CODE := 1;
    O_NOTE := '成功!';

    IF i_task_id IS NULL THEN
        O_CODE := -1;
        O_NOTE := '运营任务ID不能为空!';
        RETURN;
    END IF;

    IF I_USERID IS NULL THEN
        O_CODE := -1;
        O_NOTE := '系统登录人ID不能为空!';
        RETURN;
    END IF;

    IF I_IP IS NULL THEN
        O_CODE := -1;
        O_NOTE := '系统登录人IP不能为空!';
        RETURN;
    END IF;

    UPDATE TPIF_CPYYRW
       SET ZXZT = -1
     WHERE ZXZT = 0
       AND ID = i_task_id; --将任务的执行状态置为“取消”

    V_COUNT := SQL%ROWCOUNT;
    --处理条数大于0则记录执行明细等
    IF V_COUNT > 0 THEN
        INSERT INTO TPIF_CPYYRWZXMX
            (ID, CPYYRW, ZXRY, CZLX, ZXSJ, ZXRWSM) --记录调整说明
            SELECT livebos.FUNC_NEXTID('TPIF_CPYYRWZXMX'),
                   i_task_id,
                   I_USERID,
                   -1,
                   SYSDATE,
                   i_CANCEL_REASON
              FROM DUAL;
    
       /* livebos.PRO_CZRZDJ(O_CODE, --登记操作日志
                         O_NOTE,
                         I_USERID,
                         'TPIF_CPYYRW',
                         'UPDATE',
                         i_task_id,
                         '取消运营任务',
                         I_IP,
                         '28009',
                         '');*/
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        ROLLBACK;
    
END PRO_PIF_YYGL_RWQX;
/

