create PROCEDURE PCX_PIF_SCCP_ZSL(O_CODE      OUT NUMBER,
                                             O_NOTE      OUT VARCHAR2,
                                             O_RESULT    OUT SYS_REFCURSOR,
                                             I_USERID    IN NUMBER,
                                             I_PROD_TYPE IN VARCHAR2 --接口返回的PROD_TYPE
                                             ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 市场产品-展示列
  
  
      语法信息：
           输入参数：   I_USERID     IN NUMBER , --登录用户ID
                       I_PROD_TYPE  IN NUMBER   --接口返回的PROD_TYPE
           输出参数：   O_RESULT
  
      逻辑说明：
           
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-14    1.0       WUJINFENG              新增
          2021-08-31    1.1        GAOKUN           初步修改避免报错，后续根据实
                                                     际需求修改优化
  ***********************************************************************/
  --V_SQL VARCHAR2(2000);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_TYPE IS NULL THEN
    O_NOTE := '入参 I_PROD_TYPE 不允许为空！';
    RETURN;
  END IF;

  --公募基金INFO.TINFO_JJGK
  IF I_PROD_TYPE = 1 THEN
  
    OPEN O_RESULT FOR
      SELECT 1 AS DISPLAY_ORDER, --显示顺序
             'PROD_CODE' AS FIELD_ID, --列标识
             '产品代码' AS DISPLAY_NAME --列中文描述
        FROM DUAL
      UNION ALL
      SELECT 2 AS DISPLAY_ORDER,
             'PROD_NAME' AS FIELD_ID,
             '产品名称' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 3 AS DISPLAY_ORDER,
             'PRODABBNAME' AS FIELD_ID,
             '基金简称' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 4 AS DISPLAY_ORDER,
             'SFWSXS' AS FIELD_ID,
             '是否我司销售' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 5 AS DISPLAY_ORDER,
             'PROD_FIRST_TYPE_NAME' AS FIELD_ID,
             '一级分类' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 6 AS DISPLAY_ORDER,
             'PROD_SECOND_TYPE_NAME' AS FIELD_ID,
             '二级分类' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 7 AS DISPLAY_ORDER,
             'NAV_DATE' AS FIELD_ID,
             '净值日期' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 8 AS DISPLAY_ORDER,
             'UNITNV' AS FIELD_ID,
             '单位净值' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 9 AS DISPLAY_ORDER,
             'ACCUMULATEDUNITNV' AS FIELD_ID,
             '累计净值' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 10 AS DISPLAY_ORDER,
             'NVDAILYGROWTHRATE' AS FIELD_ID,
             '日增长率(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 11 AS DISPLAY_ORDER,
             'RRINSINGLEWEEK' AS FIELD_ID,
             '近1周(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 12 AS DISPLAY_ORDER,
             'RRINSINGLEMONTH' AS FIELD_ID,
             '近1月(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 13 AS DISPLAY_ORDER,
             'RRINTHREEMONTH' AS FIELD_ID,
             '近3月(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 14 AS DISPLAY_ORDER,
             'RRINSIXMONTH' AS FIELD_ID,
             '近6月(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 15 AS DISPLAY_ORDER,
             'RRINSINGLEYEAR' AS FIELD_ID,
             '近1年(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 16 AS DISPLAY_ORDER,
             'RRINTWOYEAR' AS FIELD_ID,
             '近2年(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 17 AS DISPLAY_ORDER,
             'RRINTHREEYEAR' AS FIELD_ID,
             '近3年(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 18 AS DISPLAY_ORDER,
             'RRINFIVEYEAR' AS FIELD_ID,
             '近5年(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 19 AS DISPLAY_ORDER,
             'RRSINCETHISYEAR' AS FIELD_ID,
             '今年以来(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 20 AS DISPLAY_ORDER,
             'RRSINCESTART' AS FIELD_ID,
             '成立以来(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 21 AS DISPLAY_ORDER,
             'ANNUALIZEDRRSINCESTART' AS FIELD_ID,
             '平均年化收益率(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 22 AS DISPLAY_ORDER,
             'DAILYPROFIT' AS FIELD_ID,
             '万份基金收益' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 23 AS DISPLAY_ORDER,
             'LATESTWEEKLYYIELD' AS FIELD_ID,
             '七日年化收益率(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION
      SELECT 24 AS DISPLAY_ORDER,
             'PRODSCALEAMOUNT' AS FIELD_ID,
             '基金规模(亿元)' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 25 AS DISPLAY_ORDER,
             'MANAGER' AS FIELD_ID,
             '基金经理' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 26 AS DISPLAY_ORDER,
             'INVESTADVISOR' AS FIELD_ID,
             '基金管理人' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 27 AS DISPLAY_ORDER,
             'ESTABLISHMENTDATE' AS FIELD_ID,
             '成立日期' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 28 AS DISPLAY_ORDER,
             'APPLYINGTYPE' AS FIELD_ID,
             '申购状态' AS DISPLAY_NAME
        FROM DUAL;
  
  
    --私募基金PIF.TPIF_SCSMJJXX
  ELSIF I_PROD_TYPE = 2 THEN
    OPEN O_RESULT FOR
      SELECT 1 AS DISPLAY_ORDER,
             'PROD_CODE' AS FIELD_ID,
             '产品代码' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 2 AS DISPLAY_ORDER,
             'PROD_NAME' AS FIELD_ID,
             '产品名称' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 3 AS DISPLAY_ORDER,
             'FUND_NAME' AS FIELD_ID,
             '基金简称' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 4 AS DISPLAY_ORDER,
             'SFWSXS' AS FIELD_ID,
             '是否我司销售' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 5 AS DISPLAY_ORDER,
             'TERMINAL_STRATEGY' AS FIELD_ID,
             '策略分类' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 6 AS DISPLAY_ORDER,
             'STATISTIC_DATE' AS FIELD_ID,
             '净值日期' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 7 AS DISPLAY_ORDER,
             'NAV' AS FIELD_ID,
             '单位净值' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 8 AS DISPLAY_ORDER,
             'ADDED_NAV' AS FIELD_ID,
             '累计净值' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 9 AS DISPLAY_ORDER,
             'Y1_RETURN_A' AS FIELD_ID,
             '近一年年化收益率(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 10 AS DISPLAY_ORDER,
             'TOTAL_RETURN_A' AS FIELD_ID,
             '成立以来年化收益率(%)' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 11 AS DISPLAY_ORDER,
             'FUND_MEMBER' AS FIELD_ID,
             '基金经理' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 12 AS DISPLAY_ORDER,
             'FUND_ISSUE_ORG' AS FIELD_ID,
             '基金管理人' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 13 AS DISPLAY_ORDER,
             'FUND_CUSTODIAN' AS FIELD_ID,
             '基金托管人' AS DISPLAY_NAME
        FROM DUAL
      UNION ALL
      SELECT 14 AS DISPLAY_ORDER,
             'FOUNDATION_DATE' AS FIELD_ID,
             '成立日期' AS DISPLAY_NAME
        FROM DUAL;
  
  
    /*  
      --券商理财 INFO.TINFO_QSLCJCXX
    ELSIF I_PROD_TYPE = 3 THEN
      OPEN O_RESULT FOR
        SELECT 1 AS DISPLAY_ORDER,
               'PROD_CODE' AS FIELD_ID,
               '产品代码' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 2 AS DISPLAY_ORDER,
               'PROD_NAME' AS FIELD_ID,
               '产品名称' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 3 AS DISPLAY_ORDER,
               'F_INFO_NAME' AS FIELD_ID,
               '产品简称' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 4 AS DISPLAY_ORDER,
               'SFWSXS' AS FIELD_ID,
               '是否我司销售' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 5 AS DISPLAY_ORDER,
               'F_INFO_CORP_FUNDMANAGEMENTCOMP' AS FIELD_ID,
               '管理人' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 6 AS DISPLAY_ORDER,
               'F_INFO_CUSTODIANBANK' AS FIELD_ID,
               '托管机构' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 7 AS DISPLAY_ORDER,
               'F_INFO_SETUPDATE' AS FIELD_ID,
               '成立日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 8 AS DISPLAY_ORDER,
               'F_INFO_MATURITYDATE' AS FIELD_ID,
               '到期日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 9 AS DISPLAY_ORDER,
               'F_INFO_STATUS' AS FIELD_ID,
               '存续状态' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 10 AS DISPLAY_ORDER,
               'F_INFO_FIRSTINVESTTYPE' AS FIELD_ID,
               '投资类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 11 AS DISPLAY_ORDER,
               'F_ISSUE_TOTALUNIT' AS FIELD_ID,
               '发行份额' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 12 AS DISPLAY_ORDER,
               'F_INFO_EXPECTEDRATEOFRETURN' AS FIELD_ID,
               '预期收益率' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 13 AS DISPLAY_ORDER,
               'SYL_CLYL' AS FIELD_ID,
               '成立以来收益率' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 14 AS DISPLAY_ORDER,
               'NHSYL' AS FIELD_ID,
               '年化收益率' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 15 AS DISPLAY_ORDER,
               'F_INFO_MINBUYAMOUNT' AS FIELD_ID,
               '起点金额' AS DISPLAY_NAME
          FROM DUAL;
    
    
      --银行理财 INFO.TINFO_YHLCCPJBJL
    ELSIF I_PROD_TYPE = 4 THEN
      OPEN O_RESULT FOR
        SELECT 1 AS DISPLAY_ORDER,
               'PROD_CODE' AS FIELD_ID,
               '产品代码' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 2 AS DISPLAY_ORDER,
               'PROD_NAME' AS FIELD_ID,
               '产品名称' AS DISPLAY_NAME
          FROM DUAL
        
        UNION ALL
        SELECT 3 AS DISPLAY_ORDER,
               'SFWSXS' AS FIELD_ID,
               '是否我司销售' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 4 AS DISPLAY_ORDER,
               'COM_ID' AS FIELD_ID,
               '发行机构' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 5 AS DISPLAY_ORDER,
               'FOUND_DT' AS FIELD_ID,
               '成立日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 6 AS DISPLAY_ORDER,
               'END_DT' AS FIELD_ID,
               '到期日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 7 AS DISPLAY_ORDER,
               'TYP_CODE' AS FIELD_ID,
               '产品类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 8 AS DISPLAY_ORDER,
               'RSK_LVL_CODE' AS FIELD_ID,
               '风险等级' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 9 AS DISPLAY_ORDER,
               'INV_PRD_D' AS FIELD_ID,
               '投资周期(天)' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 10 AS DISPLAY_ORDER,
               'EXP_YLD_MAX' AS FIELD_ID,
               '预期收益率上限' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 11 AS DISPLAY_ORDER,
               'EXP_YLD_MIN' AS FIELD_ID,
               '预期收益率下限' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 12 AS DISPLAY_ORDER,
               'IS_ELY_TERM' AS FIELD_ID,
               '银行是否可提前终止' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 13 AS DISPLAY_ORDER,
               'IS_ELY_REDEM' AS FIELD_ID,
               '客户是否可以提前赎回' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 14 AS DISPLAY_ORDER,
               'IS_PLGE' AS FIELD_ID,
               '是否能被质押' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 15 AS DISPLAY_ORDER,
               'IS_STRU' AS FIELD_ID,
               '是否结构化产品' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 16 AS DISPLAY_ORDER,
               'LNK_OBJ_TYP' AS FIELD_ID,
               '挂钩标的类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 17 AS DISPLAY_ORDER,
               'INV_DESC' AS FIELD_ID,
               '投资标的类型' AS DISPLAY_NAME
          FROM DUAL;
    
    
      --信托理财INFO.TINFO_XTLCJBXXB
    ELSIF I_PROD_TYPE = 5 THEN
      OPEN O_RESULT FOR
        SELECT 1 AS DISPLAY_ORDER,
               'PROD_CODE' AS FIELD_ID,
               '产品代码' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 2 AS DISPLAY_ORDER,
               'PROD_NAME' AS FIELD_ID,
               '产品名称' AS DISPLAY_NAME
          FROM DUAL
        
        UNION ALL
        SELECT 3 AS DISPLAY_ORDER,
               'SFWSXS' AS FIELD_ID,
               '是否我司销售' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 4 AS DISPLAY_ORDER,
               'COM_NAME' AS FIELD_ID,
               '发行机构' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 5 AS DISPLAY_ORDER,
               'CUST_COM_NAME' AS FIELD_ID,
               '托管人' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 6 AS DISPLAY_ORDER,
               'FOUND_DT' AS FIELD_ID,
               '成立日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 7 AS DISPLAY_ORDER,
               'END_DT' AS FIELD_ID,
               '终止日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 8 AS DISPLAY_ORDER,
               'TYP_CODE' AS FIELD_ID,
               '产品类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 9 AS DISPLAY_ORDER,
               'INV_FLD_CODE' AS FIELD_ID,
               '资金运用领域' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 10 AS DISPLAY_ORDER,
               'RTN_TYP' AS FIELD_ID,
               '收益类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 11 AS DISPLAY_ORDER,
               'IS_STRU' AS FIELD_ID,
               '是否结构化' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 12 AS DISPLAY_ORDER,
               'INV_TYE' AS FIELD_ID,
               '投资类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 13 AS DISPLAY_ORDER,
               'TERM_TYP_CODE' AS FIELD_ID,
               '期限类型' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 14 AS DISPLAY_ORDER,
               'INV_CHAR' AS FIELD_ID,
               '投资特征' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 15 AS DISPLAY_ORDER,
               'TRST_MNG' AS FIELD_ID,
               '信托经理' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 16 AS DISPLAY_ORDER,
               'INV_MNG' AS FIELD_ID,
               '投资经理' AS DISPLAY_NAME
          FROM DUAL;
    
    
      --保险理财INFO.TINFO_BXLCJBXX
    ELSE
    
      OPEN O_RESULT FOR
      
        SELECT 1 AS DISPLAY_ORDER,
               'PROD_NAME' AS FIELD_ID,
               '产品名称' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 2 AS DISPLAY_ORDER,
               'SFWSXS' AS FIELD_ID,
               '是否我司销售' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        
        SELECT 3 AS DISPLAY_ORDER,
               'COM_NAME' AS FIELD_ID,
               '发行机构' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 4 AS DISPLAY_ORDER,
               'CUST_COM_NAME' AS FIELD_ID,
               '托管人' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 5 AS DISPLAY_ORDER,
               'FOUND_DT' AS FIELD_ID,
               '成立日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 6 AS DISPLAY_ORDER,
               'DUR_END_DT' AS FIELD_ID,
               '到期日期' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 7 AS DISPLAY_ORDER,
               'MIN_COV' AS FIELD_ID,
               '最低保额(万)' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 8 AS DISPLAY_ORDER,
               'MIN_PREM' AS FIELD_ID,
               '最低保费(元)' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 9 AS DISPLAY_ORDER,
               'PAY_OPT' AS FIELD_ID,
               '缴费方式' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 10 AS DISPLAY_ORDER,
               'PAY_DUR' AS FIELD_ID,
               '缴费期限' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 11 AS DISPLAY_ORDER,
               'ISS_SZ' AS FIELD_ID,
               '实际发行规模(份)' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 12 AS DISPLAY_ORDER,
               'PERF_BEN' AS FIELD_ID,
               '业绩比较基准' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 13 AS DISPLAY_ORDER,
               'IN_PRD' AS FIELD_ID,
               '保险期间' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 14 AS DISPLAY_ORDER,
               'SALE_AREA' AS FIELD_ID,
               '发售地区' AS DISPLAY_NAME
          FROM DUAL
        UNION ALL
        SELECT 15 AS DISPLAY_ORDER,
               'SALE_CHNL' AS FIELD_ID,
               '销售渠道' AS DISPLAY_NAME
          FROM DUAL;
    */
  END IF;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
  
END;
/

