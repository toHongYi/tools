create PROCEDURE PRO_PIF_JYRL_CLGZRGXQJ(O_CODE OUT NUMBER, --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   I_KSRQ IN NUMBER, --开始年份
                                                   I_JSRQ IN NUMBER --结束年份
                                                   ) IS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：处理工作日表要更新的时间区间

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-07-26     V1.0      谢莉莉             创建
      2016-10-19     V2.0      王大一             托管系统迁移改造接入产品中心
   *********************************************************************************************************************/

  V_MAXPZR VARCHAR(30); --最大配置日
  V_MINPZR VARCHAR(30); --最小配置日
  V_JSKSRQ VARCHAR(30); --开始日期
  V_JSJSRQ VARCHAR(30); --结束日期

BEGIN
  O_CODE := 1;
  O_NOTE := '操作成功！';
  --取得配置最大值和最小值
  SELECT VALUE INTO V_MINPZR FROM TPIF_JYRL_YF WHERE PZX = 'GZBKSNF';
  SELECT VALUE INTO V_MAXPZR FROM TPIF_JYRL_YF WHERE PZX = 'GZBJSNF';

  V_JSKSRQ := SUBSTR(TO_CHAR(I_KSRQ), 0, 4);
  V_JSJSRQ := SUBSTR(TO_CHAR(I_JSRQ), 0, 4);

  --星期表中的最大值和最小值与入参比较得出要更新的时间区间
  IF (V_JSKSRQ < V_MINPZR) THEN
    PRO_PIF_JYRL_SXGZRB(O_CODE, O_NOTE, V_JSKSRQ, V_MINPZR);
    --更新开发配置表
    IF (O_CODE = 1) THEN
      UPDATE TPIF_JYRL_YF SET VALUE = V_JSKSRQ WHERE PZX = 'GZBKSNF';
    END IF;
  END IF;
  IF (V_MAXPZR < V_JSJSRQ) THEN
    PRO_PIF_JYRL_SXGZRB(O_CODE, O_NOTE, V_MAXPZR, V_JSJSRQ);
    --更新开发配置表
    IF (O_CODE = 1) THEN
      UPDATE TPIF_JYRL_YF SET VALUE = V_JSJSRQ WHERE PZX = 'GZBJSNF';
    END IF;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_CLGZRGXQJ;
/

