create PROCEDURE PCX_PIF_SY_CPGG(O_CODE     OUT NUMBER,
                                                O_NOTE     OUT VARCHAR2,
                                                O_RESULT   OUT SYS_REFCURSOR,
                                                I_CURRENT  IN NUMBER, --页码   
                                                I_PAGESIZE IN NUMBER, --页长 
                                                I_PAGING   IN NUMBER, --是否分页 
                                                I_SORT     IN STRING, --排序规模 
                                                I_TOTAL    IN OUT NUMBER, --记录总数
                                                I_USERID   IN NUMBER
                                                
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品公告查询
  
      语法信息：
           输入参数：     I_CURRENT  IN NUMBER, --页码   
                          I_PAGESIZE IN NUMBER, --页长 
                          I_PAGING   IN NUMBER, --是否分页 
                          I_SORT     IN STRING, --排序规模 
                          I_TOTAL    IN OUT NUMBER --记录总数  
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
  V_BEGIN_DATE   NUMBER;
BEGIN

  IF I_USERID IS NULL THEN
  
    O_CODE := -1;
    O_NOTE := '入参【I_USERID】不允许为空';
    RETURN;
  
  END IF;

  --否则返回结果集合
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  --后期根据实际情况调整
  --V_BEGIN_DATE := TO_CHAR(SYSDATE - 31, 'YYYYMMDD');
/*
  V_SQL := ' SELECT  A.ID AS NOTICE_ID,
                     A.GGRQ as NOTICE_DATE,
                     A.CPID AS PROD_ID, --产品id
                     A.ID, --公告ID
                     A.GGBT AS NOTICE_TITLE, --公告标题
                     A.GGNR AS NOTICE_CONTENT, --公告内容
                     A.GGFWLJ AS NOTICE_VISIT_LINK --公告访问链接 
                FROM PIF.TPIF_CPGGK A';
              -- WHERE A.GGRQ >=' || V_BEGIN_DATE; */
              
              V_SQL := ' SELECT  A.ID AS NOTICE_ID,
                     A.GGRQ as NOTICE_DATE,
                     A.CPID AS PROD_ID, --产品id
                     A.ID, --公告ID
                     A.GGBT AS NOTICE_TITLE, --公告标题
                     A.GGNR AS NOTICE_CONTENT, --公告内容
                     (SELECT CASE WHEN  A.OSSURL IS NOT NULL THEN  (SELECT PARAMVALUE FROM LIVEBOS.TSYSPARAM WHERE PARAMNAME=''cpzx.oss.url'')||OSSURL ELSE A.GGFWLJ END AS URL FROM PIF.TPIF_CPGGK WHERE ID=A.ID) AS NOTICE_VISIT_LINK--公告访问链接 
                FROM PIF.TPIF_CPGGK A  WHERE    ZT =1 ';
              -- WHERE A.GGRQ >=' || V_BEGIN_DATE;


  IF V_SORT IS NULL THEN
    V_SORT := 'NOTICE_DATE DESC';
  END IF;
  V_COLLIST := 'NOTICE_DATE,PROD_ID,NOTICE_ID,NOTICE_TITLE,NOTICE_CONTENT,NOTICE_VISIT_LINK';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

