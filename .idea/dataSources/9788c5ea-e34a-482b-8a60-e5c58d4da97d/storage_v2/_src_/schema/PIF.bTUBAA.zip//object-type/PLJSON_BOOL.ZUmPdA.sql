create type pljson_bool force under pljson_element (

  num number(1),

  constructor function pljson_bool (b in boolean) return self as result,
  overriding member function is_bool return boolean,
  overriding member function value_of(max_byte_size number default null, max_char_size number default null) return varchar2,

  overriding member function get_bool return boolean
) not final

/

