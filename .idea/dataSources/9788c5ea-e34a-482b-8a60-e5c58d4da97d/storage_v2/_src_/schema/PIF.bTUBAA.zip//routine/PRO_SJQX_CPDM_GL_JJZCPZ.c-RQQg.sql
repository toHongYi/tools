create PROCEDURE PRO_SJQX_CPDM_GL_JJZCPZ(O_CODE OUT NUMBER, --返回值
                                                  O_NOTE OUT VARCHAR2 --返回消息
                                                  ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：基金资产配置-TPIF_CPDM_GL_JJZCPZ数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-16     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  ---FUND_ID,STATISTIC_DATE
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPDM_GL_JJZCPZ ' ;
  

  INSERT INTO TPIF_CPDM_GL_JJZCPZ(ID,        --ID
                                  CPID,      --产品ID
                                  BBQ,       --报告期
                                  ZCZLMC,    --资产种类名称
                                  ZCSZ,      --资产市值(元)
                                  ZZCJZBL,   --占资产净值比例
                                  LRR,       --操作人
                                  LRSJ       --操作时间
                                  )
                                  
   SELECT  SEQ_TPIF_CPDM_GL_JJZCPZ.NEXTVAL,
           CPID,
           BBQ,
           ZCZLMC,
           ZCSZ,
           ZZCJZBL,
           0,
           SYSDATE
   FROM ( --股票
           SELECT  B.CPID,
                   TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS BBQ,
                  '股票' AS ZCZLMC,
                   A.STOCK_SUM	 AS ZCSZ,
                   A.STOCK_RATIO AS ZZCJZBL,
                   ROW_NUMBER() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) PX
           FROM SRC_PIF.T_FUND_ASSET_DATA A,PIF.TPIF_CPDM B
           WHERE A.FUND_ID = B.ZYNM
           --债券
           UNION ALL
           SELECT  B.CPID,
                   TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS BBQ,
                  '债券' AS ZCZLMC,
                   A.BOND_SUM	 AS ZCSZ,
                   A.BOND_RATIO AS ZZCJZBL,
                   ROW_NUMBER() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) PX
           FROM SRC_PIF.T_FUND_ASSET_DATA A,PIF.TPIF_CPDM B
           WHERE A.FUND_ID = B.ZYNM
           
           --基金
           UNION ALL                          
           SELECT  B.CPID,
                   TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS BBQ,
                  '基金' AS ZCZLMC,
                   A.FUND_SUM	 AS ZCSZ,
                   A.FUND_RATIO AS ZZCJZBL,
                   ROW_NUMBER() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) PX
           FROM SRC_PIF.T_FUND_ASSET_DATA A,PIF.TPIF_CPDM B
           WHERE A.FUND_ID = B.ZYNM

          --现金
          UNION ALL 
          SELECT  B.CPID,
                   TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS BBQ,
                  '现金' AS ZCZLMC,
                   A.CASH_SUM	 AS ZCSZ,
                   A.CASH_RATIO AS ZZCJZBL,
                   ROW_NUMBER() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) PX
           FROM SRC_PIF.T_FUND_ASSET_DATA A,PIF.TPIF_CPDM B
           WHERE A.FUND_ID = B.ZYNM

          --其他
            UNION ALL  
            SELECT  B.CPID,
                   TO_CHAR(A.STATISTIC_DATE,'YYYYMMDD') AS BBQ,
                  '其他' AS ZCZLMC,
                   A.OTHER_SUM	 AS ZCSZ,
                   A.OTHER_RATIO AS ZZCJZBL,
                   ROW_NUMBER() OVER(PARTITION BY B.CPID ORDER BY A.STATISTIC_DATE DESC) PX
           FROM SRC_PIF.T_FUND_ASSET_DATA A,PIF.TPIF_CPDM B
           WHERE A.FUND_ID = B.ZYNM
    ) WHERE PX = 1 ;

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM_GL_JJZCPZ 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM_GL_JJZCPZ 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM_GL_JJZCPZ 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

