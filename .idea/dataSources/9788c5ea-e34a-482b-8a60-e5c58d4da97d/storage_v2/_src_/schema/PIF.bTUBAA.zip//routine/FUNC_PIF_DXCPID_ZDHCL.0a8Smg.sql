create FUNCTION FUNC_PIF_DXCPID_ZDHCL( I_TJRQ IN NUMBER, --统计日期
                                                    I_KSRQ IN NUMBER,  --回测开始时间
                                                    I_CPID IN NUMBER  --产品ID

)RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算最大回撤率（代销产品表使用）

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        gaokun   1.0.0    2021/02/20                   新增
  --------------------------------------------------------------------------------*/
  V_ZXJZ    NUMBER; ---最小净值
  V_YHC     NUMBER; ---预回撤
  V_HC      NUMBER; ---回撤

BEGIN
   --循环计算组合方案的回撤并对比出最大回撤
    FOR CUR_HC IN (SELECT * FROM TPIF_DXCPJZXX A
                    WHERE A.CPID = I_CPID
                      AND EXISTS (SELECT 1
                             FROM LIVEBOS.TXTJYR
                            WHERE ZRR = JYR
                              AND JYR = A.JZRQ
                              AND JYR >= I_KSRQ
                              AND JYR <= I_TJRQ) ORDER BY A.JZRQ ASC) LOOP

      --获取当前计算的净值日期后的最小净值
      SELECT MIN(A.LJJZ)
        INTO V_ZXJZ
        FROM TPIF_DXCPJZXX A
       WHERE A.cpid = I_CPID
         AND EXISTS (SELECT 1
                FROM LIVEBOS.TXTJYR
               WHERE ZRR = JYR
                 AND JYR = A.JZRQ
                 AND JYR >= CUR_HC.JZRQ --时间大于等于当前计算的净值日期
                 AND JYR <= I_TJRQ);

      --计算单个预回撤
      V_YHC := (V_ZXJZ / CUR_HC.LJJZ - 1) * 100;

      --空值处理
      V_HC := COALESCE(V_HC, V_YHC);

      --一一比较获取最小回撤
      V_HC := LEAST(V_HC, V_YHC);
    END LOOP;

    --获得最大回撤绝对值
    V_HC := ABS(V_HC);

    RETURN V_HC;
EXCEPTION
  WHEN OTHERS THEN
    RETURN -999;
END;
/

