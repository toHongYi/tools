create PROCEDURE PRO_PIF_XTPP_GMCP(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              I_RQ     IN NUMBER DEFAULT NULL, --日期
                                              I_N_REDO IN INT DEFAULT 0) AS
  /******************************************************************
  项目名称：PIF  产品中心-跑批调度
  所属用户：PIF
  概要说明：系统调度公募产品信息清洗过程  2021.03
          I_RQ    --日期
  语法信息：
       输出参数：
          O_CODE   成功返回 成功，失败返回-1
          O_NOTE   成功返回操作成功，失败返回错误信息

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
  *********************************************************************************************************************/
  V_RQ   NUMBER(8) DEFAULT I_RQ; --当前日期
  V_KSRQ DATE;
BEGIN

  O_CODE := 1;
  O_NOTE := '成功';
  --1.***************************入参校验 ***************************
  --当前变量赋值

  V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
  /*
  --********************产品标签每日更新跑批*************************
  V_KSRQ := SYSDATE ;
  PIF.PRO_PIF_JHSX(O_CODE, O_NOTE,0,'127.0.0.1',1,'');
  --记录日志
   PRO_SJQX_LOG('PRO_PIF_JHSX','产品标签每日更新',V_KSRQ,SYSDATE,O_CODE,O_NOTE) ;*/

  --1.********************TINFO_XTCLB 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_XTCLB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_XTCLB',
               'TINFO_XTCLB表公募产品每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --2.********************TINFO_HYB 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_HYB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_HYB',
               'TINFO_HYB表公募产品每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

/*  --3.********************TPIF_CPDM 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_CPDM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_CPDM',
               'TPIF_CPDM表公募产品每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --4.********************TINFO_ZQZB 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_ZQZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_ZQZB',
               'TINFO_ZQZB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --7.********************TINFO_JJGLRGK 表清洗*******************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGLRGK(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGLRGK',
               'TINFO_JJGLRGK表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --5.********************TINFO_JJGK 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGK(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGK',
               'TINFO_JJGK表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --23.********************TINFO_GMJJJLJBZL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJJLJBZL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJJLJBZL',
               'TINFO_GMJJJLJBZL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --6.********************TINFO_JJTGRGK 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJTGRGK(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJTGRGK',
               'TINFO_JJTGRGK表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);



  --8.********************TINFO_JJFEBD 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJFEBD(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJFEBD',
               'TINFO_JJFEBD表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --9.********************TINFO_JJGGYW 表清洗 *************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGGYW(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGGYW',
               'TINFO_JJGGYW表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --10.********************TINFO_JJJZ 表清洗**************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJZ(O_CODE , O_NOTE ,'','');
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJZ',
               'TINFO_JJJZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --11.********************TINFO_FQJZ 表清洗*******************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJFQJZ(O_CODE, O_NOTE ,'' ,'');
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJFQJZ',
               'TINFO_FQJZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --12.********************TINFO_JJFH 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJFH(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJFH',
               'TINFO_JJFH表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --13.********************TINFO_JJJLNEW 表清洗 ************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJLNEW(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJLNEW',
               'TINFO_JJJLNEW表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --14.********************TINFO_JJFLNEW 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJFLNEW(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJFLNEW',
               'TINFO_JJFLNEW表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --15.********************TINFO_JJHYTZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJHYTZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJHYTZ',
               'TINFO_JJHYTZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --16.********************TINFO_JJZCPZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJZCPZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJZCPZ',
               'TINFO_JJZCPZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --17.********************TINFO_JJZCGPZH 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJZCGPZH(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJZCGPZH',
               'TINFO_JJZCGPZH表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --18.********************TINFO_JJJZZXBX 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJZZXBX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJZZXBX',
               'TINFO_JJJZZXBX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --19.********************TINFO_JJJZLSBX 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJZLSBX(O_CODE, O_NOTE ,'' ,'');
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJZLSBX',
               'TINFO_JJJZLSBX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --20.********************TINFO_JJZSHBLSBX 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJZSHBLSBX( O_CODE, O_NOTE ,'' ,'') ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJZSHBLSBX',
               'TINFO_JJZSHBLSBX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --21.********************TINFO_JGJBZL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JGJBZL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JGJBZL',
               'TINFO_JGJBZL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --22.********************TINFO_JJGKFB 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGKFB( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGKFB',
               'TINFO_JJGKFB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);



  --24.********************TINFO_GMJJGGYWFWB 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJGGYWFWB( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJGGYWFWB',
               'TINFO_GMJJGGYWFWB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --25.********************TINFO_GMJJGGYWFWBFB 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJGGYWFWBFB( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJGGYWFWBFB',
               'TINFO_GMJJGGYWFWBFB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --26.********************TINFO_GMJJGGWBB 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJGGWBB( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJGGWBB',
               'TINFO_GMJJGGWBB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --27.********************TINFO_GMJJFXYSS 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJFXYSS( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJFXYSS',
               'TINFO_GMJJFXYSS表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --28.********************TPIF_CPDM_P_GT_YCJS 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_CPDM_P_GT_YCJS( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_CPDM_P_GT_YCJS',
               'TPIF_CPDM_P_GT_YCJS表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --29.********************TPIF_CPDM_P_GT_ZKSZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_CPDM_P_GT_ZKSZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_CPDM_P_GT_ZKSZ',
               'TPIF_CPDM_P_GT_ZKSZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --30.********************TINFO_GMJJFXDJB 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJFXDJB( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJFXDJB',
               'TINFO_GMJJFXDJB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --31.********************TPIF_CPDM_P_GT_XSKZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_CPDM_P_GT_XSKZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_CPDM_P_GT_XSKZ',
               'TPIF_CPDM_P_GT_XSKZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --32.********************INFO.TINFO_JJZQZH 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJZQZH( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJZQZH',
               'TINFO_JJZQZH表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --33.********************TINFO_GMJJHJQK 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJHJQK( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJHJQK',
               'TINFO_GMJJHJQK表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --34.********************TINFO_HBJJJZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_HBJJJZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_HBJJJZ',
               'TINFO_HBJJJZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --35.********************TINFO_GMJJBDL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJBDL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJBDL',
               'TINFO_GMJJBDL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

   --36.********************TINFO_GMJJZDHC 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJZDHC( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJZDHC',
               'TINFO_GMJJZDHC表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --37.********************TINFO_GMJJZDHCXFTS 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJZDHCXFTS( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJZDHCXFTS',
               'TINFO_GMJJZDHCXFTS表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --38.********************TINFO_GMJJXPBL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJXPBL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJXPBL',
               'TINFO_GMJJXPBL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --39.********************TINFO_HBJJSYBX 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_HBJJSYBX( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_HBJJSYBX',
               'TINFO_HBJJSYBX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --40.********************TPIF_JJJLJBZL数据补齐逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJLJBZL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJLJBZL',
               'TPIF_JJJLJBZL数据补齐每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --41.********************PIF.TPIF_JJJLHYCCBZ 数据清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJLHYCCBZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJLHYCCBZ',
               'TPIF_JJJLHYCCBZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --41.********************TPIF_JJGLR数据补齐清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGLR( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGLR',
               'TPIF_JJGLR数据补齐清洗逻辑',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --42.********************TPIF_JJGLRGPCCMX 清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGLRGPCCMX( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGLRGPCCMX',
               'TPIF_JJGLRGPCCMX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --43.********************PIF.TPIF_JJGLRHYPZ 数据清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJGLRHYPZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJGLRHYPZ',
               'TPIF_JJGLRHYPZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

   --44.********************TPIF_JJYJJJLGLB数据补齐清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_MF_FUNDMANAGERRANK( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_MF_FUNDMANAGERRANK',
               'TPIF_JJYJJJLGLB数据补齐每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --45.********************TPIF_GMJJGKFB数据补齐清洗逻辑************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_MF_FUNDRETURNRANK( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_MF_FUNDRETURNRANK',
               'TPIF_GMJJGKFB数据补齐每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --46.********************TINFO_GMJJSTNBL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJSTNBL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJSTNBL',
               'TINFO_GMJJSTNBL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --47.********************TINFO_GMJJKMBL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJKMBL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJKMBL',
               'TINFO_GMJJKMBL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --48.********************PIF.TPIF_JJJLGPCCBZ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJLGPCCBZ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJLGPCCBZ',
               'PIF.TPIF_JJJLGPCCBZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --49.********************INFO.TINFO_JJJZ_GK 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_JJJZ_GK( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_JJJZ_GK',
               'INFO.TINFO_JJJZ_GK表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --50.********************INFO.TINFO_GMJJSSZT 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJSSZT( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJSSZT',
               'INFO.TINFO_GMJJSSZT表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --51.********************INFO.TINFO_GMJJXXBL 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJXXBL( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJXXBL',
               'INFO.TINFO_GMJJXXBL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --52.********************INFO.TINFO_GMJJALPHA 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJALPHA( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJALPHA',
               'INFO.TINFO_GMJJALPHA表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

   --53.********************INFO.TINFO_GMJJBETA 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_GMJJBETA( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('P_TRAN_GMJJBETA',
               'INFO.TINFO_GMJJBETA表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --.********************INFO.TINFO_GMJJBETA 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_JJJZ_HD( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_JJJZ_HD',
               '后端收费产品净值相关数据每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --54.********************TPIF_GMJJFXPJ 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_GMJJFXPJ( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_GMJJFXPJ',
               'TPIF_GMJJFXPJ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --55.********************TPIF_GMJJSYYGM 表清洗************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_GMJJSYYGM( O_CODE, O_NOTE) ;
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_GMJJSYYGM',
               'TPIF_GMJJSYYGM表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --56.********************公募基金业绩走势 清洗*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_GMJJYJZS(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_GMJJYJZS',
               '公募基金业绩走势',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

 --57.********************基金净值衍生指标 清洗*************
  V_KSRQ := SYSDATE;
  P_TRAN_TPIF_CPJZ_YSZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_TPIF_CPJZ_YSZB',
               '基金净值衍生指标',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  O_NOTE:='清洗成功';
  --提交数据
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
      RETURN;
    END;
END PRO_PIF_XTPP_GMCP;
/

