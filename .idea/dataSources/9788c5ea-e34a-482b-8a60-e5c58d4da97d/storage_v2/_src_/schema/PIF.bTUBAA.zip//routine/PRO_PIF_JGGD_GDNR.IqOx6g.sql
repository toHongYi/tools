create PROCEDURE PRO_PIF_JGGD_GDNR(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2,
                                              I_ID   IN NUMBER, --机构观点的ID
                                              I_TYPE IN NUMBER, --1|新增，2|修改，3|删除
                                              I_USER IN NUMBER --用户ID
                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：机构业务拓展----机构观观点内容管理
      语法信息：
           输入参数：I_ID   IN NUMBER, --机构观点的ID
                     I_TYPE IN NUMBER, --1|新增，2|修改，3|删除
                     I_USER IN NUMBER --用户ID
  
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-08-11     1.0.0     HANQIAONAN            新增
  ***********************************************************************/
  V_COUNT NUMBER := 0;

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  IF I_TYPE IS NULL OR I_TYPE NOT IN (1, 2, 3) THEN
    O_CODE := -1;
    O_NOTE := '操作类型不存在';
    RETURN;
  END IF;

  IF I_USER IS NULL THEN
    O_CODE := -1;
    O_NOTE := '用户不存在';
    RETURN;
  END IF;

  --是否存在流程节点，若存在则插入流程节点表
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_JGGD WHERE ID = I_ID;

  IF V_COUNT = 0 THEN
    O_CODE := -1;
    O_NOTE := '机构观点不存在';
    RETURN;
  END IF;
  --新增
  IF I_TYPE = 1 THEN
    INSERT INTO TPIF_JGGDNR
      (ID, JGGDID, NRYS, GDNR, FJ, OSSURL, WBLJ, CJR, CJSJ, SFSC)
      SELECT LIVEBOS.FUNC_NEXTID('TPIF_JGGDNR'),
             I_ID,
             NRYS,
             GDNR,
             FJ,
             OSSURL,
             WBLJ,
             I_USER,
             SYSDATE,
             0
        FROM TPIF_JGGD
       WHERE ID = I_ID;
  END IF;

  --修改
  IF I_TYPE = 2 THEN
    UPDATE TPIF_JGGDNR
       SET SFSC = 1, SCR = I_USER, SCSJ = SYSDATE
     WHERE JGGDID = I_ID
       AND SFSC = 0;
    --插入新节点
    INSERT INTO TPIF_JGGDNR
      (ID, JGGDID, NRYS, GDNR, FJ, OSSURL, WBLJ, CJR, CJSJ, SFSC)
      SELECT LIVEBOS.FUNC_NEXTID('TPIF_JGGDNR'),
             I_ID,
             NRYS,
             GDNR,
             FJ,
             OSSURL,
             WBLJ,
             I_USER,
             SYSDATE,
             0
        FROM TPIF_JGGD
       WHERE ID = I_ID;
  END IF;

  --删除
  IF I_TYPE = 3 THEN
    UPDATE TPIF_JGGDNR
       SET SFSC = 1, SCR = I_USER, SCSJ = SYSDATE
     WHERE JGGDID = I_ID
       AND SFSC = 0;
  END IF;

  O_CODE := 199;
  O_NOTE := '新增成功';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

