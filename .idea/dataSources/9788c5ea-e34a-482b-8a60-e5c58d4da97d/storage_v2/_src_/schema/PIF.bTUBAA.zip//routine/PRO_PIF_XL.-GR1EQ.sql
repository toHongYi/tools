create PROCEDURE PRO_PIF_XL(O_CODE OUT NUMBER, --返回值
                                       O_NOTE OUT VARCHAR2 --返回消息
                                       ) IS
  /******************************************************************
  项目名称：财通
  所属用户：PIF
  概要说明：销量重新采集数据，执行过程
  备注：
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明      
      2021-12-30     V1.0      LTX             增加
   *********************************************************************************************************************/
  v_sql varchar2(1000);
BEGIN
  O_CODE := 1;
  O_NOTE := '操作成功！';

  --清除表数据
  v_sql := 'truncate table DSC_STAT.TPIF_STAT_CPDXYB';
  execute immediate v_sql;
  v_sql := 'truncate table DSC_STAT.TPIF_STAT_CPDXYB_HZTJ';
  execute immediate v_sql;
  --循环

  FOR MONTH IN (SELECT DISTINCT NY
                  FROM LIVEBOS.TXTJYR
                 WHERE NY >= 202001
                   AND NY <= 202112) LOOP
  
    PRO_SJQX_STAT_CPDXYB(O_CODE, O_NOTE, MONTH.NY);
  END LOOP;

  PRO_SJQX_CPXSFL_CPZX(O_CODE, O_NOTE);

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_XL;
/

