create PROCEDURE PCX_PIF_SY_CPXLFB(O_CODE          OUT NUMBER,
                                              O_NOTE          OUT VARCHAR2,
                                              O_RESULT        OUT SYS_REFCURSOR,
                                              I_TYPE          IN NUMBER, --类型:1:销量，2：保有量
                                              I_TIME_INTERVAL IN NUMBER --统计周期: 1：近1年
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：产品首页-产品销量分布统计
             参数说明：
                  入参：
                         I_TYPE           IN NUMBER --类型:1:销量，2：保有量
                         I_TIME_INTERVAL  IN NUMBER --统计周期: 1：近1年
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
        liutx      1.1    2021/10/12                   调整，收入改成保有量
  
  -----------------------------------------------------------------------------------------------*/
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  --临时屏蔽
  --RETURN;

  IF I_TIME_INTERVAL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TIME_INTERVAL不能为空!';
    RETURN;
  END IF;

  IF I_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TYPE不能为空!';
    RETURN;
  END IF;
  --1:销量
  IF I_TYPE = 1 THEN
  
    --近1年
    IF I_TIME_INTERVAL = 1 THEN
    
      --PROD_TYPE 产品类型
      --PROD_TYPE_DESC  产品类型描述
      --AMOUNT  金额
    
      OPEN O_RESULT FOR
        SELECT (CASE
                 WHEN PX < 5 THEN
                  PROD_TYPE
                 ELSE
                  99
               END) AS PROD_TYPE,
               (CASE
                 WHEN PX < 5 THEN
                  PROD_TYPE_DESC
                 ELSE
                  '其他'
               END) AS PROD_TYPE_DESC,
               ROUND(SUM(AMOUNT) / 100000000, 6) AS AMOUNT
          FROM (SELECT ROW_NUMBER() OVER(ORDER BY SUM(A.XSL) DESC) AS PX,
                       B.CPXL AS PROD_TYPE, --产品类型
                       (SELECT NOTE
                          FROM LIVEBOS.TXTDM
                         WHERE FLDM = 'PIF_CPXL_CPZX'
                           AND IBM = B.CPXL) AS PROD_TYPE_DESC,
                       SUM(A.XSL) AS AMOUNT --金额
                  FROM --TPIF_CPJZ_YSZB 
                       DSC_STAT.TPIF_STAT_CPDXYB A,
                       TPIF_CPDM                 B
                 WHERE SUBSTR(YF, 1, 4) = TO_CHAR(SYSDATE, 'YYYY')
                   AND A.CPDM = B.CPDM
                   AND B.CPNBZT = 8
                   AND B.CPXL > 0
                 GROUP BY B.CPXL
                
                )
         GROUP BY (CASE
                    WHEN PX < 5 THEN
                     PROD_TYPE
                    ELSE
                     99
                  END),
                  (CASE
                    WHEN PX < 5 THEN
                     PROD_TYPE_DESC
                    ELSE
                     '其他'
                  END)
         ORDER BY AMOUNT DESC;
    
    END IF;
  
    --2|保有量
  ELSIF I_TYPE = 2 THEN
  
    --近1年
    IF I_TIME_INTERVAL = 1 THEN
    
      OPEN O_RESULT FOR
        SELECT (CASE
                 WHEN PX < 5 THEN
                  PROD_TYPE
                 ELSE
                  99
               END) AS PROD_TYPE,
               (CASE
                 WHEN PX < 5 THEN
                  PROD_TYPE_DESC
                 ELSE
                  '其他'
               END) AS PROD_TYPE_DESC,
               ROUND(SUM(AMOUNT) / 100000000, 6) AS AMOUNT
          FROM (SELECT ROW_NUMBER() OVER(ORDER BY SUM(A.NBYL) DESC) AS PX,
                       B.CPXL AS PROD_TYPE, --产品类型
                       (SELECT NOTE
                          FROM LIVEBOS.TXTDM
                         WHERE FLDM = 'PIF_CPXL_CPZX'
                           AND IBM = B.CPXL) AS PROD_TYPE_DESC,
                       SUM(A.NBYL) AS AMOUNT --金额
                  FROM --TPIF_CPJZ_YSZB
                       DSC_STAT.TPIF_STAT_CPDXYB A,
                       TPIF_CPDM                 B
                 WHERE SUBSTR(YF, 1, 4) = TO_CHAR(SYSDATE, 'YYYY')
                   AND A.CPDM = B.CPDM
                   AND B.CPNBZT = 8
                   AND B.CPXL > 0
                 GROUP BY B.CPXL
                
                )
         GROUP BY (CASE
                    WHEN PX < 5 THEN
                     PROD_TYPE
                    ELSE
                     99
                  END),
                  (CASE
                    WHEN PX < 5 THEN
                     PROD_TYPE_DESC
                    ELSE
                     '其他'
                  END)
         ORDER BY AMOUNT DESC;
    
    END IF;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

