create PROCEDURE PRO_PIF_FMQDKDR(O_CODE OUT NUMBER,
                                            O_NOTE OUT VARCHAR2,
                                            I_USER IN NUMBER) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：负面清单库导入模板
      语法信息：
           输入参数：
           输出参数：
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人         修改内容简要说明
          2019-08-15     1.0       WUJINFENG              新增
  ***********************************************************************/
  V_COUNT NUMBER;
  V_NUM   NUMBER := 0;
  --V_JGMC  VARCHAR2(200);

BEGIN

  --校验
  FOR CUR IN (SELECT * FROM PIF.TPIF_FMQDKDR A) LOOP
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PIF.TPIF_FMQDKDR
     WHERE ID <> CUR.ID
       AND TRIM(JGMC) = TRIM(CUR.JGMC);

    IF V_COUNT > 0 THEN
      --SELECT GLRMC INTO V_JGMC FROM PIF.TPIF_HZQD WHERE ID = CUR.JGMC ;
      O_CODE := -1;
      O_NOTE := '机构名称[' || CUR.JGMC || ']存在多条记录,请检查';
      RETURN;
    END IF;

    INSERT INTO PIF.TPIF_FMQDK
      (id, jgmc, tzjl, fmxx, wtyy, jycs, zt, lrr, lrsj)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_FMQDK'),
       CUR.Jgmc,
       CUR.Tzjl,
       CUR.Fmxx,
       CUR.wtyy,
       CUR.jycs,
       0,
       I_USER,
       SYSDATE);

    V_NUM := V_NUM + 1;

  END LOOP;

  --清除临时表数据
  DELETE FROM PIF.TPIF_FMQDKDR;

  O_CODE := 199;
  O_NOTE := '成功导入【' || V_NUM || '】条数据！！！';

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := O_NOTE || SQLERRM;

END;
/

