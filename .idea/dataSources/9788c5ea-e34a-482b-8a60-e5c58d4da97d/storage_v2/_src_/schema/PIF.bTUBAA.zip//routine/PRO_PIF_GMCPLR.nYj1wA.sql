create PROCEDURE PRO_PIF_GMCPLR(O_CODE  OUT NUMBER,
                                           O_NOTE  OUT VARCHAR2,
                                           I_USER  IN NUMBER,
                                           I_CPDM  IN VARCHAR, --产品代码
                                           I_CPMC  IN VARCHAR, --产品名称
                                           I_CPLX  IN NUMBER,
                                           I_GLRID IN NUMBER,
                                           I_TA    IN NUMBER,
                                           I_DT    IN NUMBER,
                                           I_FXDJ  IN NUMBER,
                                           I_FL    IN NUMBER --1:产品尽职调查 2：产品参数设置
                                           ) AS

  /*--------------------------------------------------------------------------------------------

  项目名称：华西证券金融管理平台

         功能说明：公募基金产品尽职调查和参数设置


        ----------------------------------------------------------
        操作人   版本号     时间                       操作
        LTX     1.0      20191016                    新增
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER;
  v_glrwd number;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  --1:产品尽职调查
  IF I_FL = 1 THEN

    SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDM WHERE CPDM = I_CPDM;
    IF V_COUNT > 0 THEN

        UPDATE PIF.TPIF_CPDM
       SET CPXL    = I_CPLX,
          -- JRCPFL  = I_JRCPFL,
           CPGLRID    = I_GLRID,
           --CPTGR = I_CPTGR,
           CPMC = I_CPMC
     WHERE CPDM = I_CPDM ;

    ELSE

      INSERT INTO PIF.TPIF_CPDM
        (ID,
         CPID,
         CPDM,
         CPMC,
         CPJC,
         CPNBZT,
         PT,
         CPXL,
         JRCPFL,
         CPGLRID,

         RKSJ,
         RKCZR)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM'),
         NULL,
         I_CPDM,
         I_CPMC,
         I_CPMC,
         2,
         3,
         I_CPLX,
         DECODE(I_CPLX, 1, '300100', 2, '500100'),
         I_GLRID,
         SYSDATE,
         I_USER);

      UPDATE PIF.TPIF_CPDM SET CPID = ID WHERE CPDM = I_CPDM;

    END IF;

  --2：产品参数设置
  ELSE
    FOR CUR_CP IN(SELECT SUBSTR(COLUMN_VALUE,1,6) AS CPDM FROM TABLE(SPLIT(I_CPDM,';'))) LOOP

      SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDM WHERE CPDM = CUR_CP.CPDM;
      IF V_COUNT > 0 THEN

        UPDATE PIF.TPIF_CPDM
           SET --SFZCDT    = I_DT,
              -- SFKTDT    = I_DT,
               CPTA    = (SELECT A.TABM FROM TPIF_TADM A WHERE A.ID = I_TA),
               CPTAMC  = (SELECT A.TAMC FROM TPIF_TADM A WHERE A.ID = I_TA),
               CPFXDJ = I_FXDJ
               
              -- PJFX      = I_FXDJ,
              -- PJRQ      = TO_CHAR(SYSDATE, 'YYYYMMDD')
         WHERE CPDM = CUR_CP.CPDM;

      ELSE

        INSERT INTO PIF.TPIF_CPDM
        (ID,
         CPID,
         CPDM,
         CPMC,
         CPJC,
         CPNBZT,
         PT,
         CPXL,
         JRCPFL,
         CPGLRID,
         CPTA,
         CPTAMC,
         CPFXDJ,
         RKSJ,
         RKCZR)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM'),
         NULL,
         I_CPDM,
         I_CPMC,
         I_CPMC,
         2,
         3,
         I_CPLX,
         DECODE(I_CPLX, 1, '300100', 2, '500100'),
         I_GLRID,
         (SELECT A.TABM FROM TPIF_TADM A WHERE A.ID = I_TA),
         (SELECT A.TAMC FROM TPIF_TADM A WHERE A.ID = I_TA),
         I_FXDJ,
         SYSDATE,
         I_USER);

        UPDATE PIF.TPIF_CPDM SET CPID = ID WHERE CPDM = CUR_CP.CPDM;

       

      END IF;
    END LOOP ;
  END IF;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败,' || SQLERRM;
END;
/

