create PROCEDURE pcx_ProdRecentYieldRate(O_CODE          OUT NUMBER,
                                              O_NOTE          OUT VARCHAR2,
                                              O_RESULT        OUT SYS_REFCURSOR,
                                              I_PROD_CODE     IN VARCHAR2 --产品代码

                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：最近产品七日年化收益率、万份收益查询

      语法信息：
           输入参数：    I_PROD_CODE     IN VARCHAR2, --产品代码
                         I_BEGIN_DATE    IN NUMBER, --开始日期（含）
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-05-19     1.0       CR              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000021');
  V_COUNT     NUMBER;
  V_JKLX      NUMBER;
BEGIN

  /*IF I_BEGIN_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_BEGIN_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_END_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_END_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;*/

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;


  OPEN O_RESULT FOR
    SELECT DATA_DATE, --数据日期
           UNIT_YIELD, --货币基金万份收益
           D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
      FROM (SELECT B.NAV_DATE             AS DATA_DATE, --数据日期
                   B.UNIT_YIELD, --货币基金万份收益
                   B.D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
              FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_NAV_INFO B
             WHERE A.ID = B.PROD_ID
               AND A.ID =
                   (SELECT ID
                      FROM PIF.TPROD_BASIC_INFO
                     WHERE PROD_CODE = NVL(I_PROD_CODE, PROD_CODE))
               AND B.UNIT_YIELD IS NOT NULL
             ORDER BY B.NAV_DATE DESC)
      WHERE ROWNUM=1;

  O_CODE := 0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT NULL AS DATA_DATE, --数据日期
           NULL AS UNIT_YIELD, --货币基金万份收益
           NULL AS D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
     FROM DUAL
     WHERE 1 = 2;
  END IF ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

