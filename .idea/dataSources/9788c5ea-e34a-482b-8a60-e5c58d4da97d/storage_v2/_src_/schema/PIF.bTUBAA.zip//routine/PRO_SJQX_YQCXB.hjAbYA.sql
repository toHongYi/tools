create PROCEDURE PRO_SJQX_YQCXB(O_CODE OUT NUMBER, --返回值
                                            O_NOTE OUT VARCHAR2 --返回消息
                                            ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：我关注的舆情 TPIF_YQCXB 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：  O_CODE  返回值
                      O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-17     1.0       吴金锋              创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_JJJC  VARCHAR2(200);
  V_JJQC  VARCHAR2(200);
  V_JGMC  VARCHAR2(200);
  V_JGJC  VARCHAR2(200);
  V_TXFS  VARCHAR2(2000);

  V_CODE NUMBER;
  V_NOTE VARCHAR2(200);

  V_FSF          NUMBER; --邮件或短信发送方
  V_TITLE        VARCHAR2(2000);--邮件主题
  V_CONTENT      VARCHAR2(2000);--邮件正文
  V_LBMESSAGE_ID NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  
  FOR CUR_JG IN (SELECT DISTINCT CPGLRID FROM TPIF_CPDM ) LOOP
  
    SELECT JGJC, JGMC INTO V_JGJC, V_JGMC
      FROM TPIF_JGDM A
     WHERE A.ID = CUR_JG.CPGLRID;
  
   --匹配逻辑暂定为  通过 机构名称、机构简称 去资讯表中的PAGE_TITLE字段模糊匹配
   FOR CUR_NEW IN (SELECT * FROM SRC_PIF.NEWS A WHERE A.PAGE_TITLE LIKE '%' || V_JGJC || '%' OR A.PAGE_TITLE LIKE '%' || V_JGMC || '%') LOOP
    
      --判断舆情是否已经存在
      SELECT COUNT(*)
        INTO V_COUNT
        FROM TPIF_YQCXB B
       WHERE B.ID = CUR_NEW.SEQ;
    
      IF V_COUNT = 0 THEN
      
        INSERT INTO TPIF_YQCXB
          ( YH, QYLX, YQID, BT, LY, YQLJ, ZQSJ, GXSJ, RKSJ, RKRQ)
          SELECT 
                 0,
                 2,
                 CUR_NEW.SEQ,
                 CUR_NEW.PAGE_TITLE,
                 CUR_NEW.PUBLISH_SOURCE,
                 CUR_NEW.DATA_URL,
                 TO_CHAR(TO_DATE('1970-01-01 08:00:00',  'YYYY-MM-DD HH:MI:SS') + CUR_NEW.CRAWL_TIME / (60 * 60 * 24), 'YYYY-MM-DD HH24:MI:SS'),
                 CUR_NEW.UPDATED_AT,
                 SYSDATE,
                 TO_CHAR(SYSDATE, 'YYYYMMDD')
            FROM TPIF_CPDM
           WHERE CPGLRID = CUR_JG.CPGLRID;
      
      ELSE
      
        UPDATE TPIF_YQCXB A
           SET A.YH = 0
         WHERE A.ID = CUR_NEW.SEQ;
      
      END IF;
    
    END LOOP;
  
  END LOOP;
  
  

  O_CODE := 1;
  O_NOTE := 'TPIF_YQCXB 表清洗成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_YQCXB 表清洗,未知错误'
                ELSE
                 'TPIF_YQCXB 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

