create PROCEDURE PRO_KHBF_XZ(O_CODE OUT NUMBER,    --错误代码
                                        O_NOTE OUT VARCHAR2,  --错误消息
                                        I_USERID IN NUMBER,   --登陆用户ID
                                        I_JLRQ IN NUMBER,     --交流日期
                                        I_JLDXLX IN VARCHAR2,   --交流对象类型
                                        I_JLDX IN VARCHAR2,   --交流对象
                                        I_DYJLXS IN NUMBER,   --调研交流形式
                                        I_JGID IN NUMBER,     --拜访机构ID
                                        I_JGMC IN VARCHAR2,   --机构名称
                                        I_JGXZ IN NUMBER,     --机构性质
                                        I_GSZJGLGM IN NUMBER,  --公司资金管理规模
                                        I_GSHXTYRY IN VARCHAR2,  --公司核心投研人员
                                        I_JGHXCL IN VARCHAR2,    --机构核心策略
                                        I_QTQKSM IN VARCHAR2,    --其他情况说明
                                        I_XQMC IN VARCHAR2,      --需求名称
                                        I_XQLX IN VARCHAR2,        --需求类型
                                        I_FBRQ IN NUMBER,        --发布日期
                                        I_JZRQ IN NUMBER,        --截止日期
                                        I_XQZT IN NUMBER,        --需求状态
                                        I_SJYWDY IN VARCHAR2,    --涉及业务单元
                                        I_YWXQSM IN VARCHAR2,    --业务需求说明
                                        I_XQMZQK IN VARCHAR2,    --公司对机构需求满足情况
                                        I_JGGDFX IN VARCHAR2,    --机构观点分享
                                        I_HYZXFX IN VARCHAR2,     --行业资讯分享
                                        
                                        I_GROUP_NAME	IN VARCHAR2,  --部门名称
                                        I_CHECKIN_TYPE	IN VARCHAR2,  --打卡类型
                                        I_CHECKIN_TIME	IN VARCHAR2,  --打卡时间
                                        I_LOCATION_TITLE	IN VARCHAR2,  --地点
                                        I_LOCATION_DETAIL	IN VARCHAR2,   --位置明细
                                        
                                        I_IS_CORE_PROPERTY IN VARCHAR2, --是否核心资产
                                        I_ARTICLE_LINK IN VARCHAR2, --文章链接
                                        I_SKIP_TYPE IN VARCHAR2 --上传类型

                                        ) AS
                                        
/******************************************************************
  项目名称：财通证券运营展业平台-客户拜访
  所属用户：PIF
  概要说明：客户拜访记录新增

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
       输入参数：
          见参数定义部分   

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   GAOKUN            新增.
  ********************************************************************/

V_ID NUMBER;          --记录需求表的ID
--V_COUNT NUMBER :=0;   --用于判断需求表的需求名称是否存在，存在则无法新增
V_JGMC VARCHAR2(200);      --通过机构ID获取机构名称
V_JGXZ NUMBER;             --通过机构ID获取机构性质
V_YJBM NUMBER;             --一级部门
BEGIN
  O_CODE :=1;
  O_NOTE :='成功！';
  
  IF I_USERID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='登录用户ID不能为空！';
    RETURN;
  END IF;
  
  
 --一级部门 
  SELECT (CASE
           WHEN B.GRADE >= 5 THEN
            B.FID
           ELSE
            B.ID
       END)  INTO V_YJBM
FROM   LIVEBOS.TUSER A
LEFT   JOIN LIVEBOS.LBORGANIZATION B
ON     A.ORGID = B.ID
WHERE  A.ID = I_USERID;
/*
  IF I_JLRQ IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='交流日期不能为空！';
    RETURN;
  END IF;

  IF I_JLDXLX IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='交流对象类型不能为空！';
    RETURN;
  END IF;

  IF I_JLDX IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='交流对象不能为空！';
    RETURN;
  END IF;

  IF I_DYJLXS IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='调研交流形式不能为空！';
    RETURN;
  END IF;

  IF I_JGID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='机构ID不能为空！';
    RETURN;
  END IF;

  IF I_GSZJGLGM IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='公司资金管理规模不能为空！';
    RETURN;
  END IF;

  IF I_GSHXTYRY IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='公司核心投研人员不能为空！';
    RETURN;
  END IF;

  IF I_XQMC IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='需求名称不能为空！';
    RETURN;
  END IF;

  IF I_XQLX IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='需求类型不能为空！';
    RETURN;
  END IF;

  IF I_XQZT IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='需求状态不能为空！';
    RETURN;
  END IF;    */

/*  SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_XQXX
  WHERE TRIM(XQMC)=TRIM(I_XQMC);

  IF V_COUNT = 1 THEN
    O_CODE :=-1;
    O_NOTE :='需求名称已存在！';
    RETURN;
  END IF;  */

  V_ID := LIVEBOS.FUNC_NEXTID('TPIF_XQXX');
  SELECT JGMC,GSFL INTO V_JGMC,V_JGXZ FROM PIF.TPIF_JGDM WHERE ID=I_JGID;

  INSERT INTO PIF.TPIF_XQXX(ID,
                        XQMC,
                        XQLX,
                        JGMC,
                        FBRQ,
                    --   JZRQ,
                    --   XQZT,
                        SJYWDY,
                        YWXQSM,
                        --XQMZQK,
                        DJR,
                        DJRQ,
                        YJBM)
  VALUES(V_ID,
         I_XQMC,
         
         (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.ID)), ',', ';')     --输入 '5;4;1;3;2'
          FROM TPIF_XQLX B                                       --改为 '1;2;3;4;5'
         WHERE INSTR(';' || I_XQLX || ';', ';' || B.BM || ';') > 0),
         
         NVL(I_JGMC,V_JGMC),
         NVL(I_FBRQ,TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD'))),
     --    I_JZRQ,
     --    I_XQZT,
         
         (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.IBM)), ',', ';')     --输入 '5;4;1;3;2'
          FROM LIVEBOS.TXTDM B                                    --改为 '1;2;3;4;5'
         WHERE B.FLDM = 'PIF_SJYWDY'
           AND INSTR(';' || I_SJYWDY || ';', ';' || B.IBM || ';') > 0),
         
         I_YWXQSM,
         --I_XQMZQK,
         I_USERID,
         SYSDATE,
         V_YJBM);




  INSERT INTO  PIF.TPIF_BFJL(ID,
                              JLRQ,
                              JLDXLX,
                              JLDX,
                              DYJLXS,
                              JGID,
                              JGMC,
                              JGXZ,
                              GSZJGLGM,
                              GSHXTYTD,
                              JGHXCL,
                              JGGDFX,
                              QTQKSM,
                         --     HYZXFX,
                              YWXQ,
                              DJR,
                              DJRQ,
                              
                              BMMC,
                              DKLX,
                              DD,
                              WZMX,
                              DKSJ,
                              
                              SFHXZC,
                              WZLJ,
                              SCLX,
                              YJBM
                              
                              )
   VALUES(LIVEBOS.FUNC_NEXTID('TPIF_BFJL'),
          I_JLRQ,
          (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.IBM)), ',', ';')     --输入 '5;4;1;3;2'
          FROM LIVEBOS.TXTDM B                                    --改为 '1;2;3;4;5'
         WHERE B.FLDM = 'PIF_JLDXLX'
           AND INSTR(';' || I_JLDXLX || ';', ';' || B.IBM || ';') > 0),
          I_JLDX,
          I_DYJLXS,
          I_JGID,
          NVL(I_JGMC,V_JGMC),
          NVL(I_JGXZ,V_JGXZ),
          I_GSZJGLGM,
          I_GSHXTYRY,
          I_JGHXCL,
          I_JGGDFX,
          I_QTQKSM,
    --      I_HYZXFX,
          V_ID,
          I_USERID,
          SYSDATE,
          
          I_GROUP_NAME,
          I_CHECKIN_TYPE,
          I_LOCATION_TITLE,
          I_LOCATION_DETAIL,
          TO_DATE(I_CHECKIN_TIME,'YYYYMMDDHH24MISS'),
          
          I_IS_CORE_PROPERTY,
          I_ARTICLE_LINK,
          I_SKIP_TYPE,
          V_YJBM
          );

    COMMIT;
--    DBMS_OUTPUT.PUT_LINE('拜访记录新增成功！');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;

END;
/

