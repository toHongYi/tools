create PROCEDURE PCX_JGHX_JGLB(O_CODE    OUT NUMBER,--错误代码
                                          O_NOTE    OUT VARCHAR2,--错误消息
                                          O_RESULT  OUT SYS_REFCURSOR,--返回结果集
                                          I_CURRENT    IN NUMBER, --页码
                                          I_PAGESIZE   IN NUMBER, --页长
                                          I_PAGING     IN NUMBER, --是否分页
                                          I_SORT       IN STRING, --排序规模
                                          I_TOTAL      IN OUT NUMBER, --记录总数

                                          I_USERID     IN INTEGER, --用户ID
                                          I_KEYWORD    IN VARCHAR2 --关键词
                                          )AS

/******************************************************************
  项目名称：财通证券运营展业平台-H5机构画像
  所属用户：PIF
  概要说明：机构列表查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分
          I_KEYWORD   关键词，机构简称搜索关键词

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/17     1.0.0.1   GAOKUN            新增.
  ********************************************************************/

  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
BEGIN

  --初始化
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  --条件检验
  IF I_USERID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '登陆用户ID不允许为空！';
    RETURN;
  END IF;
  
 /* IF LIVEBOS.FUNC_GETAUTH(I_USERID, 'APP_TPIF_JG360_CK') != 1 THEN
    O_CODE := 99;
    O_NOTE := '没有执行该操作的权限！';
    RETURN;
  END IF; */

  V_SQL:=
  'SELECT  A.ORG_ID,
           A.ORG_NAME,
           REGEXP_COUNT(A.MANAGE_FUND_ID,'','') + 1 FUND_AMOUNT,
           DECODE(A.ASSET_MGT_SCALE_RANGE,''1'',''<10亿'',''2'',''10-20亿'',''3'',''20-50亿'',''4'',''50-100亿'',''5'',''>100亿'') ASSET_MGT_SCALE_RANGE
      FROM SRC_PIF.T_FUND_ORG A';
  IF I_KEYWORD IS NOT NULL THEN
     
       V_SQL:= V_SQL || ' WHERE ORG_NAME LIKE  '''||I_KEYWORD||'%''';
  END IF;    
      
  IF V_SORT = '00' THEN      --不传-默认-不排序
    V_SORT := '';
  ELSIF   V_SORT = '01' THEN                       --1数量升序    --2数量降序
    V_SORT := ' DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') ASC NULLS LAST';
  ELSIF   V_SORT = '02' THEN       
    V_SORT := ' DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') DESC NULLS LAST';
  ELSIF   V_SORT = '10' THEN      
    V_SORT := ' FUND_AMOUNT ASC NULLS LAST';
  ELSIF   V_SORT = '11' THEN      
    V_SORT := ' FUND_AMOUNT ASC NULLS LAST,DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') ASC NULLS LAST';
  ELSIF   V_SORT = '12' THEN       
    V_SORT := ' FUND_AMOUNT ASC NULLS LAST,DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') DESC NULLS LAST';   
  ELSIF   V_SORT = '20' THEN       
    V_SORT := ' FUND_AMOUNT DESC NULLS LAST';
  ELSIF   V_SORT = '21' THEN      
    V_SORT := ' FUND_AMOUNT DESC NULLS LAST,DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') ASC NULLS LAST';         
  ELSIF   V_SORT = '22' THEN       
    V_SORT := ' FUND_AMOUNT DESC NULLS LAST,DECODE(ASSET_MGT_SCALE_RANGE,''<10亿'',''1'',''10-20亿'',''2'',''20-50亿'',''3'',''50-100亿'',''4'',''>100亿'',''5'') DESC NULLS LAST';    
  END IF;

 -- DBMS_OUTPUT.PUT_LINE(V_SQL);

  V_COLLIST := 'ORG_ID,ORG_NAME,FUND_AMOUNT,ASSET_MGT_SCALE_RANGE';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := '查询失败:' || SQLERRM;

END;
/

