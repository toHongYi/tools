create procedure pcx_pif_cpqj_cpqjgk_out(o_code    out number,
                                                o_note    out varchar2,
                                                o_result  out sys_refcursor,
                                                i_userid in number, --用户ID
                                                i_ip    in varchar2,
                                                i_prod_id in number --产品ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-查询产品概况
  所属用户：PIF
  概要说明：查询产品概况.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品概况.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   tumeng             新增.
  *********************************************************************************************************************/
  v_sql varchar2(32767);
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_prod_id is null then
    o_note := '产品ID不允许为空！';
    return;
  end if;
  if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;

  v_sql := ' SELECT T1.PROD_CODE,
                    T1.PROD_SIMP_NAME,
                    T1.PROD_FULLNAME,
                    T1.PROD_MAIN_CATEGORY,
                    T1.ESTABLISH_DAY,
                    (SELECT NOTE FROM LIVEBOS.TXTDM A WHERE A.FLDM =  ''D_PROD_RISK_LEVEL'' AND A.IBM = T1.PROD_RISK_LEVEL) PROD_RISK_LEVEL,
                    (SELECT STATUS_NAME FROM tPROD_STATUS_INFO WHERE ID = T1.PROD_STATUS) PROD_STATUS,
                    to_char(T1.PROD_SCALE_AMOUNT,''FM99999999999990.0000''）PROD_SCALE_AMOUNT,
                    T1.RAISE_PERIOD_SCALE_LOW_AMT FUND_AMOUNT,
                    (SELECT ORG_NAME FROM tORG_CODE_INFO WHERE ID = T1.PROD_MANAGER) PROD_MANAGER, --内部对象，是否考虑转换
                    T1.PROD_TRUSTEE,
                    T1.FUND_MANAGER,
                    to_char(T1.UNIT_NAV,''FM9990.0000''）UNIT_NAV,
                    to_char(T1.TOTAL_NAV,''FM9990.0000''）TOTAL_NAV,
                    T2.YIELD_RATE_QUARTER,
                    T2.YIELD_RATE_HALFYEAR,
                    T2.YIELD_RATE_THREE_YEAR,
                    T4.JLYXSSR SALE_SCALE_HALFYEAR ,
                    T4.JYNXSSR SALE_SCALE_ONE_YEAR ,
                    T3.RATING_STAR_CX,
                    T3.ATING_STAR_ZS RATING_STAR_ZS,
                    T3.RATING_STAR_JAJX
               FROM  PIF.TPROD_BASIC_INFO T1
               LEFT JOIN PIF.TTFUND_PERFORMANCE T2
               ON T1.ID = T2.PROD_ID
               LEFT JOIN PIF.TPROD_EXTEND_INFO T3
               ON T1.ID = T3.PROD_ID
               LEFT JOIN PIF.TPIF_CPJZ_YSZB T4
               ON T1.ID = T4.CPID
               WHERE T1.ID = ' || i_prod_id;

  open o_result for v_sql;

  o_code := 0;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;

end pcx_pif_cpqj_cpqjgk_out;
/

