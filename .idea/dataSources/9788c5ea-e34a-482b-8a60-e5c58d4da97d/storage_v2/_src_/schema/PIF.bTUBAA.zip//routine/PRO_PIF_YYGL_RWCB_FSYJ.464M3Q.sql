create PROCEDURE PRO_PIF_YYGL_RWCB_FSYJ(O_CODE     OUT NUMBER,
                                                   O_NOTE     OUT VARCHAR2,
                                                   i_task_exec     IN VARCHAR2, --运营任务ID串
                                                   I_USERID   IN VARCHAR2, --系统登录用户ID
                                                   I_IP       IN VARCHAR2, --操作IP
                                                   I_INFOTYPE IN NUMBER --信息类型|2代表邮件
                                                   ) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：海通证券产品中心

           功能说明：发送催办邮件
               参数说明：
                    入参：
                         i_task_exec       IN NUMBER            --运营任务ID
                         I_USERID     IN VARCHAR2,     --系统登录用户ID
                         I_IP         IN VARCHAR2, --操作IP
                         I_INFOTYPE   IN NUMBER,       --信息类型|2代表邮件

                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,


          ----------------------------------------------------------
          操作人   版本号       时间                      操作
          刘浪浪   1.0.1   2014/11/17                  新增
          刘浪浪   1.0.2   2014/11/20                  修改短信模板内容
          刘浪浪   1.0.3   2014/11/29                  增加短信提醒和催办的操作类型
          刘浪浪   1.0.4   2014/12/18                  去掉操作类型和邮件接收人，支持批量发送邮件

    -------------------------------------------------------------------------------------------------*/
    V_TITLE        VARCHAR2(500);
    V_CONTENT      VARCHAR2(3000);
    V_ZXSM         VARCHAR2(1000);
    V_RECVUSERNAME VARCHAR2(500);
    V_RECVUSERID   VARCHAR2(500);
    V_MXID         NUMBER(16);
    V_CZLX         NUMBER(16);
BEGIN

    O_CODE := 1;
    O_NOTE := '成功!';

    IF i_task_exec IS NULL THEN
        O_CODE := -1;
        O_NOTE := '运营任务ID不能为空!';
        RETURN;
    END IF;

    IF I_USERID IS NULL THEN
        O_CODE := -1;
        O_NOTE := '邮件发送人不能为空!';
        RETURN;
    END IF;

    IF I_INFOTYPE IS NULL THEN
        O_CODE := -1;
        O_NOTE := '信息类型不能为空!';
        RETURN;
    END IF;

    --批量发送邮件
    FOR YYRW IN (SELECT ID
                   FROM TPIF_CPYYRW
                  WHERE ID IN
                        (SELECT TO_NUMBER(REGEXP_SUBSTR(i_task_exec, '([^,]+)', 1, ROWNUM)) RWID
                           FROM DUAL
                         CONNECT BY ROWNUM < LENGTH(REGEXP_REPLACE(i_task_exec, '[^,]', '')) + 2)
                    AND ZXZT = 0) LOOP

        SELECT T.ZXRY,
               CASE
                   WHEN TO_NUMBER(TO_CHAR(T.YJZXWCSJ, 'YYYYMMDDHH24MISS')) <
                        TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')) THEN
                    1
                   ELSE
                    2
               END CZLX
          INTO V_RECVUSERID, V_CZLX
          FROM TPIF_CPYYRW T
         WHERE T.ID = YYRW.ID; --获取任务对应人员的ID串和邮件类型

        SELECT WM_CONCAT(T.NAME) --获取执行人员名称连接串
          INTO V_RECVUSERNAME
          FROM livebos.TUSER T
         WHERE INSTR(';' || V_RECVUSERID || ';', ';' || T.ID || ';') > 0;

        --拼接任务的标题以及内容
        SELECT A.LXMC,
               '[' ||
               (SELECT '(' || CPDM || ')' || CPMC FROM TPIF_CPDM WHERE ID = B.CPID) ||
               ']的[' || A.LXMC || ']的预计执行完成时间为[' ||
               TO_CHAR(B.YJZXWCSJ, 'YYYY/MM/DD HH24:MI:SS') || '],' || CASE
                   WHEN B.YJZXKSSJ >= SYSDATE THEN
                    '即将到期'
                   ELSE
                    '已过期'
               END || ',请尽快办理!'
          INTO V_TITLE, V_CONTENT
          FROM TPIF_CPSJLX A, TPIF_CPYYRW B
         WHERE A.ID = B.CPSJLX
           AND B.ID = YYRW.ID;

        V_ZXSM := '{' || V_RECVUSERNAME || '},' || V_CONTENT; --获取执行明细操作说明

        V_MXID := livebos.FUNC_NEXTID('TPIF_CPYYRWZXMX');

        INSERT INTO TPIF_CPYYRWZXMX
            (ID, CPYYRW, ZXRY, CZLX, ZXSJ, ZXRWSM) --生成执行任务明细
            SELECT V_MXID, YYRW.ID, I_USERID, DECODE(V_CZLX, 1, 3, 2, 4), SYSDATE, V_ZXSM
              FROM DUAL;

      /*  livebos.PRO_CZRZDJ(O_CODE, --登记操作日志
                         O_NOTE,
                         I_USERID,
                         'TPIF_CPYYRWZXMX',
                         'ADD',
                         V_MXID,
                         '新增',
                         I_IP,
                         '28008',
                         '');
*/
        livebos.PRO_FWGL_DXFS(O_CODE, --发送邮件提醒
                            O_NOTE,
                            I_USERID,
                            I_INFOTYPE,
                            2,
                            V_RECVUSERID,
                            NULL,
                            V_TITLE,
                            V_CONTENT);
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        ROLLBACK;

END PRO_PIF_YYGL_RWCB_FSYJ;

/

