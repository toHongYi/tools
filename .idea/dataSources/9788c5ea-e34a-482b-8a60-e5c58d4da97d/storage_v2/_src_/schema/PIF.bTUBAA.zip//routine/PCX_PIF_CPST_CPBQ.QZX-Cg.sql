create PROCEDURE PCX_PIF_CPST_CPBQ(O_CODE       OUT NUMBER,
                                              O_NOTE       OUT VARCHAR2,
                                              O_RESULT     OUT SYS_REFCURSOR,
                                              I_QUERY_TYPE IN VARCHAR2, --查询类型  1|关键字查询；2|热搜标签查询
                                              I_LABLE_TYPE IN VARCHAR2, --标签类型  1|系统标签： 2|手工标签
                                              I_KEY_WORD   IN VARCHAR2 --关键字
                                              
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：产品视图-产品标签查询
             参数说明：
                  入参：
                        I_QUERY_TYPE IN VARCHAR2, --查询类型  1|关键字查询；2|热搜标签查询
                        I_LABLE_TYPE IN VARCHAR2, --标签类型  1|系统标签： 2|手工标签
                        I_KEY_WORD   IN VARCHAR2, --关键字
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
  
  -----------------------------------------------------------------------------------------------*/

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_QUERY_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_QUERY_TYPE不能为空!';
    RETURN;
  END IF;

  IF I_QUERY_TYPE = 1 THEN
  
    IF I_KEY_WORD IS NULL THEN
      O_CODE := -1;
      O_NOTE := '按关键字搜索时【I_KEY_WORD】不能为空!';
      RETURN;
    END IF;
  
    OPEN O_RESULT FOR
      SELECT A.ID         AS LABLE_ID, -- 标签ID
             A.MC         AS LABLE_NAME -- 标签名称
        FROM TPIF_CPBQ A
       WHERE A.ZT = 1
         AND (I_LABLE_TYPE IS NULL OR A.YSFS = I_LABLE_TYPE)
         AND A.MC LIKE '%' || I_KEY_WORD || '%';
  
    --热搜标签查询
  ELSE
    OPEN O_RESULT FOR
      SELECT A.CPBQ AS LABLE_ID, -- 标签ID
             B.MC   AS LABLE_NAME -- 标签名称
        FROM TPIF_RSCPBQ A, TPIF_CPBQ B
       WHERE A.CPBQ = B.ID
         AND B.ZT = 1
       ORDER BY A.SSCS DESC;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

