create PROCEDURE PCX_PIF_CPJM_CPSXDB(O_CODE         OUT NUMBER,
                                                O_NOTE         OUT VARCHAR2,
                                                O_RESULT          OUT SYS_REFCURSOR,
                                                I_USERID         IN NUMBER, --用户ID
                                                I_template_id         IN NUMBER, --模版ID
                                                I_PROD_ID         IN VARCHAR2 --进行比对的产品ID,多个以 ; 分隔
                                              ) AS
    /******************************************************************
    项目名称：产品中心-产品视图-产品属性对比
    所属用户：PIF
    概要说明：根据当前分类模版，查询出需要比对的产品属性.
                 i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                                 并不是什么是否都需要分页,看情形而言.
                 i_PageNo      --页码
                 i_PageLength  --页长
                 i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                                 在翻页的时候,可以提高效率.
                 i_Sort        --排序字段
                 V_MBID         IN NUMBER, --分类模版ID
                 I_PROD_ID         IN VARCHAR2 --进行比对的产品ID,多个以 ; 分隔
    语法信息：
         输出参数：
            o_Code          返回值
            o_Note          返回信息
            o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
            o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
    
    数据准备：
        PIF.TFP_CPLX 产品类型
    
    运行原理：
          参见：简要说明
    功能修订：
        简要说明：
          查询根据当前分类模版，查询出需要比对的产品属性.
    
          1.根据当前分类模版，查询出需要比对的产品属性.
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/05     4.0.0.1   guonanhua           新增.
    *********************************************************************************************************************/
    V_SQL     VARCHAR2(32767);
    V_ERRMSG  VARCHAR2(300); --错误信息
    --V_CXZD      VARCHAR2(5000); --查询字段

BEGIN
    O_CODE         := 1;
    O_NOTE         := '成功';

    IF I_USERID IS NULL THEN
        O_CODE := -1801;
        O_NOTE := '系统异常:用户ID为空';
        RETURN;
    END IF;

    IF I_PROD_ID IS NULL THEN
        O_CODE := -1801;
        O_NOTE := '请输入的必填参数【产品ID】';
        RETURN;
    END IF;

    --验证是否存在此模版
/*    IF I_template_id IS NOT NULL THEN
        V_MBID := I_template_id;
        SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_FLMBDY MB WHERE MB.ID = V_MBID AND MB.MBZT = 1;
        IF V_COUNT = 0 THEN
           O_CODE := -2;
           O_NOTE := '错误：没有此分类模版,请核实！';
           RETURN;
         end if;
    end if ;*/
     /*   ELSIF V_COUNT > 0 THEN
           EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA_BIG';
          --1. 根据模版ID得到对比字段
          FOR V2 IN (SELECT T.FLMB, T.ID, T.XSMC, T.XSSX, T.YWDX, T.CPSX, T.SFYC, T.MS, T.IDBZ
                       FROM PIF.TPIF_FLMBDBPZ T
                      WHERE T.FLMB = V_MBID AND T.ZT = 1) LOOP
          
              SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME
                INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME
                FROM PIF.TPIF_FIELD T1
               WHERE T1.tablename = V2.YWDX AND T1.ID = V2.CPSX;

               --时间类型，进行格式化
              IF V_TYPE = 13 THEN
                  V_ZDSX := ' TO_CHAR(TO_DATE(' || V2.CPSX ||
                            ',''YYYYMMDD''),''YYYY-MM-DD'') ';
              ELSIF V_TYPE = 3 THEN
                  V_ZDSX := ' TO_CHAR(' || V2.CPSX || ',''YYYY-MM-DD'') ';
                  --内部对象
              ELSIF V_TYPE = 6 THEN
                  V_ZDSX := '(SELECT ' || V2.MS || ' FROM PIF.' || V_REFCODE ||'  WHERE '||V2.IDBZ||' = '|| V2.CPSX ||')';
              ELSIF V_TYPE = 16 THEN
                  V_ZDSX := '(SELECT WM_CONCAT(' || V2.MS || ') FROM PIF.' || V_REFCODE 
                            ||'  WHERE INSTR('';''||'|| V2.CPSX ||'||'';'','';''||'||V2.IDBZ||'||'';'') >0 )';
                --字典型
              ELSIF V_TYPE = 7 THEN
                  V_ZDSX := '(SELECT  NOTE  FROM livebos.TXTDM T WHERE T.FLDM = ''' || V_REFCODE || ''' AND T.IBM = '|| V2.CPSX ||')' ;
              ELSIF V_TYPE = 15 THEN
                  V_ZDSX := '(SELECT  WM_CONCAT(NOTE)  FROM livebos.TXTDM T WHERE T.FLDM = ''' 
                            || V_REFCODE || ''' AND INSTR('';''||'|| V2.CPSX ||'||'';'','';''||T.IBM||'';'') >0 )';
              ELSE
                  V_ZDSX := V2.CPSX;
              END IF;        
              INSERT INTO TEMPDATA_BIG
                  (N1, N2, C1, C2,C3)
                  SELECT V2.XSSX, V2.FLMB, V_ZDSX, V2.XSMC,V_CXZH  FROM DUAL;  
          END LOOP;
       END IF;
    ELSE
       --
       V_MBID := '';
       IF I_USERID = 0 THEN
          SELECT A.ID INTO V_MBID 
            FROM TPIF_FLMBDY A
           WHERE A.MBZT = 1 
             AND A.ZHXGRQ = (SELECT MAX(B.ZHXGRQ) FROM TPIF_FLMBDY B WHERE B.MBZT = 1)
             AND ROWNUM = 1;
       ELSE
           --级别:指定用户>组织角色>角色>组织>所有用户!
           IF V_MBID IS NULL THEN
              FOR CUR IN (SELECT * 
                            FROM TPIF_FLMBDY A
                           WHERE A.MBZT = 1 
                             AND EXISTS(SELECT 1 
                                          FROM TPIF_FLMBDY_SYFW B 
                                         WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 3)) LOOP
                   FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 3) LOOP
                       IF INSTR(';' || CUR_S.SYYH || ';', ';' || I_USERID || ';') > 0 AND V_MBID IS NULL THEN
                           V_MBID := CUR.ID;
                       END IF;
                   END LOOP;
              END LOOP;
           END IF;
           IF V_MBID IS NULL THEN
              FOR CUR IN (SELECT * 
                            FROM TPIF_FLMBDY A
                           WHERE A.MBZT = 1 
                             AND EXISTS(SELECT 1 
                                          FROM TPIF_FLMBDY_SYFW B 
                                         WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 4)) LOOP
                  FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 4) LOOP
                      SELECT COUNT(1) INTO V_COUNT 
                        FROM livebos.LBMEMBER
                       WHERE USERID = I_USERID AND ROLEID = CUR_S.SYJS AND ORGID = CUR_S.SYBM;
                      IF V_COUNT > 0 AND V_MBID IS NULL THEN
                          V_MBID := CUR.ID;
                      END IF;
                  END LOOP;
               END LOOP;
           END IF;
           IF V_MBID IS NULL THEN
               FOR CUR IN (SELECT * 
                             FROM TPIF_FLMBDY A
                            WHERE A.MBZT = 1 
                              AND EXISTS(SELECT 1 
                                           FROM TPIF_FLMBDY_SYFW B 
                                          WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 2)) LOOP
                  FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 2) LOOP
                      SELECT COUNT(1) INTO V_COUNT 
                        FROM livebos.LBMEMBER
                       WHERE USERID = I_USERID AND ROLEID = CUR_S.SYJS;
                      IF V_COUNT > 0 AND V_MBID IS NULL THEN
                          V_MBID := CUR.ID;
                      END IF;
                  END LOOP;
              END LOOP;
           END IF;
           IF V_MBID IS NULL THEN
              FOR CUR IN (SELECT * 
                            FROM TPIF_FLMBDY A
                           WHERE A.MBZT = 1 
                             AND EXISTS(SELECT 1 
                                          FROM TPIF_FLMBDY_SYFW B 
                                         WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 1)) LOOP
                  FOR CUR_S IN (SELECT * FROM TPIF_FLMBDY_SYFW WHERE TPIF_FLMBDY_ID = CUR.ID AND FWLX = 1) LOOP
                      SELECT COUNT(1) INTO V_COUNT 
                        FROM livebos.TUSER
                       WHERE ID = I_USERID
                         AND ORGID = CUR_S.SYBM;
                      IF V_COUNT > 0 AND V_MBID IS NULL THEN
                          V_MBID := CUR.ID;
                      END IF;
                  END LOOP;
              END LOOP;
           END IF;
           IF V_MBID IS NULL THEN
              FOR CUR IN (SELECT * 
                            FROM TPIF_FLMBDY A
                           WHERE A.MBZT = 1 
                             AND EXISTS(SELECT 1 
                                          FROM TPIF_FLMBDY_SYFW B 
                                         WHERE B.TPIF_FLMBDY_ID = A.ID AND B.FWLX = 0)) LOOP
                  IF V_MBID IS NULL THEN
                      V_MBID := CUR.ID;
                  END IF;
              END LOOP;
           END IF;
       END IF;
       
       SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_FLMBDY MB WHERE MB.ID = V_MBID AND MB.MBZT = 1;
        IF V_COUNT = 0 THEN
           O_CODE := -2;
           O_NOTE := '错误：没有此分类模版,请核实！';
           RETURN;
        ELSIF V_COUNT > 0 THEN
           EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMPDATA_BIG';
          --1. 根据模版ID得到对比字段
          FOR V2 IN (SELECT T.TYMB, T.ID, T.XSMC, T.XSSX, T.YWDX, T.CPSX, T.SFYC, T.MS, T.IDBZ
                       FROM PIF.TPIF_TYMBDBPZ T
                      WHERE T.TYMB = V_MBID AND T.ZT = 1) LOOP
          
              SELECT T1.TYPE, T1.NAME, T1.REFCODE, T1.TABLENAME, T1.length
                INTO V_TYPE, V_CPSX, V_REFCODE, V_TABLENAME, V_LENGTH
                FROM PIF.TPIF_FIELD T1
               WHERE T1.tablename = V2.YWDX AND T1.ID = V2.CPSX;

               --时间类型，进行格式化
              IF V_TYPE = 13 THEN
                  V_ZDSX := ' TO_CHAR(TO_DATE(' || V2.CPSX ||
                            ',''YYYYMMDD''),''YYYY-MM-DD'') ';
              ELSIF V_TYPE = 3 THEN
                  V_ZDSX := ' TO_CHAR(' || V2.CPSX || ',''YYYY-MM-DD'') ';
                  --内部对象
              ELSIF V_TYPE = 6 THEN
                  V_ZDSX := '(SELECT ' || V2.MS || ' FROM PIF.' || V_REFCODE ||'  WHERE '||V2.IDBZ||' = '|| V2.CPSX ||')';
              ELSIF V_TYPE = 16 THEN
                  V_ZDSX := '(SELECT WM_CONCAT(' || V2.MS || ') FROM PIF.' || V_REFCODE 
                            ||'  WHERE INSTR('';''||'|| V2.CPSX ||'||'';'','';''||'||V2.IDBZ||'||'';'') >0 )';
                --字典型
              ELSIF V_TYPE = 7 THEN
                  V_ZDSX := '(SELECT  NOTE  FROM livebos.TXTDM T WHERE T.FLDM = ''' || V_REFCODE || ''' AND T.IBM = '|| V2.CPSX ||')' ;
              ELSIF V_TYPE = 15 THEN
                  V_ZDSX := '(SELECT  WM_CONCAT(NOTE)  FROM livebos.TXTDM T WHERE T.FLDM = ''' 
                            || V_REFCODE || ''' AND INSTR('';''||'|| V2.CPSX ||'||'';'','';''||T.IBM||'';'') >0 )';
              ELSE
                  IF INSTR(V_LENGTH,'.')>0 THEN
                      V_ZDSX := ' TO_CHAR('||V2.CPSX||',''FM999,999,999,999,990.009999'') ' ;
                  ELSE
                      V_ZDSX := V2.CPSX;
                  END IF;
              END IF;        
              INSERT INTO TEMPDATA_BIG
                  (N1, N2, C1, C2,C3)
                  SELECT V2.XSSX, V2.TYMB, V_ZDSX, V2.XSMC,V_CXZH  FROM DUAL;  
          END LOOP;
       END IF;
    END IF;
    --2 返回最终的结果列表
    SELECT WM_CONCAT(A.CXLB)
      INTO V_CXZD
      FROM (SELECT XSSX, T.CPSX || ' ' || T.XSMC CXLB
              FROM (SELECT N1 XSSX, C1 CPSX, C2 XSMC
                      FROM TEMPDATA_BIG T
                     WHERE T.N2 = V_MBID
                       AND T.N1 NOT IN (SELECT T.N1
                                          FROM TEMPDATA_BIG T
                                         WHERE T.N2 = V_MBID
                                           AND ( T.C2 LIKE '%(%'
                                                 OR T.C2 LIKE '%)%' 
                                                 OR T.C2 LIKE '%[%'
                                                 OR T.C2 LIKE '%]%' ))
                    UNION ALL
                    SELECT N1 XSSX, C1 CPSX, '"' || C2 || '"' XSMC
                      FROM TEMPDATA_BIG T
                     WHERE T.N2 = V_MBID
                       AND ( T.C2 LIKE '%(%'
                             OR T.C2 LIKE '%)%' 
                             OR T.C2 LIKE '%[%'
                             OR T.C2 LIKE '%]%' )) T
             ORDER BY XSSX) A;

    --3 根据配置得到显示列表，用于分页查询
    IF I_template_id IS NOT NULL THEN
        SELECT WM_CONCAT(A.CXLB)
          INTO V_COL
          FROM (SELECT XSSX, T.XSMC CXLB
                  FROM (SELECT T.XSSX, T.CPSX, T.XSMC
                          FROM TPIF_FLMBDBPZ T
                         WHERE T.FLMB = V_MBID 
                           AND T.ZT = 1
                           AND T.XSSX NOT IN (SELECT XSSX
                                                FROM TPIF_FLMBDBPZ T
                                               WHERE T.FLMB = V_MBID
                                                 AND ( T.XSMC LIKE '%(%'
                                                       OR T.XSMC LIKE '%)%' 
                                                       OR T.XSMC LIKE '%[%'
                                                       OR T.XSMC LIKE '%]%' ))
                        UNION ALL
                        SELECT T.XSSX, T.CPSX, '"' || T.XSMC || '"' XSMC
                          FROM TPIF_FLMBDBPZ T
                         WHERE T.FLMB = V_MBID
                           AND T.ZT = 1
                           AND ( T.XSMC LIKE '%(%'
                                 OR T.XSMC LIKE '%)%' 
                                 OR T.XSMC LIKE '%[%'
                                 OR T.XSMC LIKE '%]%' )) T
                 ORDER BY XSSX) A;
     ELSE
         SELECT WM_CONCAT(A.CXLB)
          INTO V_COL
          FROM (SELECT XSSX, T.XSMC CXLB
                  FROM (SELECT T.XSSX, T.CPSX, T.XSMC
                          FROM TPIF_TYMBDBPZ T
                         WHERE T.TYMB = V_MBID
                           AND T.ZT = 1
                           AND T.XSSX NOT IN (SELECT XSSX
                                                FROM TPIF_TYMBDBPZ T
                                               WHERE T.TYMB = V_MBID
                                                 AND ( T.XSMC LIKE '%(%'
                                                       OR T.XSMC LIKE '%)%' 
                                                       OR T.XSMC LIKE '%[%'
                                                       OR T.XSMC LIKE '%]%' ))
                        UNION ALL
                        SELECT T.XSSX, T.CPSX, '"' || T.XSMC || '"' XSMC
                          FROM TPIF_TYMBDBPZ T
                         WHERE T.TYMB = V_MBID
                           AND T.ZT = 1
                           AND ( T.XSMC LIKE '%(%'
                                 OR T.XSMC LIKE '%)%' 
                                 OR T.XSMC LIKE '%[%'
                                 OR T.XSMC LIKE '%]%' )) T
                 ORDER BY XSSX) A;
     END IF;
*/
    --4 组装查询sql           
/*    SELECT 'SELECT TPIF_CPDM.ID 产品ID ' || (CASE WHEN V_CXZD IS NOT NULL THEN ','||V_CXZD ELSE NULL END)
             || ' FROM PIF.TPIF_CPDM '||(SELECT REPLACE(WM_CONCAT( 'LEFT JOIN PIF.'||BM||' ON TPIF_CPDM.ID = '||BM||'.CPID'),',',' ') 
                                           FROM PIF.TPIF_CPJMDX 
                                          WHERE DXLX > 1 AND ZT = 1 
                                            AND BM IN (SELECT DISTINCT(YWDX) BM FROM TPIF_TYMBDBPZ UNION ALL
                                                     SELECT DISTINCT(YWDX) BM FROM TPIF_FLMBDBPZ))
             ||' WHERE TPIF_CPDM.ID IN (' || I_PROD_ID || ')'  INTO V_SQL
          FROM DUAL; */
          
          
      V_SQL := 'select  prod_code,'    --产品代码
             ||' prod_fullname as prod_name,' --产品名称
             ||' (select status_name from pif.tPROD_STATUS_INFO b where b.id = prod_status) as prod_status,'  --产品状态
             ||' subscribe_begin_date,'  --认购开始日期
             ||' establish_day as establish_date,' --成立日期
             ||' expire_date,' --到期日期
             ||' prod_term,' --产品期限
             ||' (SELECT  NOTE  FROM livebos.TXTDM WHERE FLDM =''D_PROD_INVEST_VARIETY'' and IBM =invest_variety)  as invest_variety,'--投资品种
             ||' (SELECT  NOTE  FROM livebos.TXTDM WHERE FLDM =''D_PROD_RISK_LEVEL'' and IBM =prod_risk_level) as prod_risk_level,'--风险等级
             ||' highest_expected_yield_rate as expected_yield_rate ' --预期收益率
             ||' from pif.tprod_basic_info '
             ||' WHERE AUDIT_STATUS=2 ' 
             ||' and id in (' || I_PROD_ID || ')' ;

    OPEN O_RESULT FOR V_SQL;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE   := -1;
        O_NOTE   := '查询失败';
        V_ERRMSG := SQLERRM;
        OPEN O_RESULT FOR
            SELECT 'PCX_PIF_CPJM_CPSXDB出错！错误：' || V_ERRMSG FROM DUAL;
    
END PCX_PIF_CPJM_CPSXDB;


/

