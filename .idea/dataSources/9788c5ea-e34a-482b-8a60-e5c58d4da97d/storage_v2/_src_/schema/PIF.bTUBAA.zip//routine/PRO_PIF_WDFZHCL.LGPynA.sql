create PROCEDURE PRO_PIF_WDFZHCL(O_CODE OUT NUMBER,
                                            O_NOTE OUT VARCHAR2,
                                            I_WDID IN NUMBER, --文档ID
                                            I_GLID IN NUMBER, --产品ID
                                            I_GLLX IN NUMBER, --1 产品 2 产品系列  3 管理机构 4 服务协议
                                            I_WDFL IN NUMBER, --文档分类
                                            I_WDGS IN VARCHAR2, --文档格式
                                            I_MBID IN NUMBER DEFAULT NULL) AS

    /*--------------------------------------------------------------------------------------------
    
    项目名称：华西证券金融管理平台
    
           功能说明：产品文档复制后处理
              
    
          ----------------------------------------------------------
          操作人   版本号     时间                       操作
          wujinfeng   1.0    20160506
    -------------------------------------------------------------------------------------------------*/

    V_FBWDSL NUMBER(8); --1|单个；2|多个
    V_CNT    NUMBER(8); --记录条数
    V_BM     VARCHAR2(256);
    V_FJ     VARCHAR2(256);

BEGIN
    O_CODE := 1;
    O_NOTE := '成功';

    --判断文件是否为空
    SELECT A.FJ INTO V_FJ FROM PIF.TPIF_CPWDK A WHERE A.ID = I_WDID;
    --如果为空的话直接删除
    IF V_FJ IS NULL THEN
        DELETE FROM PIF.TPIF_CPWDK WHERE ID = I_WDID;
    ELSE
    
        --判断发布文件格式
        SELECT FBWDSL INTO V_FBWDSL FROM PIF.TPIF_CPWDFL WHERE ID = I_WDFL; --获取文档分类的同类文档操作方式
    
        --发布文档个数为单个，先设置当前有效版本为无效，然后插入新版本      
        IF V_FBWDSL = 1 THEN
        
            SELECT COUNT(ID)
              INTO V_CNT
              FROM PIF.TPIF_CPWDK
             WHERE NVL(GLID, 0) = NVL(I_GLID, 0)
               AND WDFL = I_WDFL
                  --  AND WDGS = I_WDGS
                  --  AND NVL(MBID, 0) = NVL(I_MBID, 0)
               AND NVL(GLLX, 1) = I_GLLX
               AND ID <> I_WDID;
            IF V_CNT >= 1 THEN
                SELECT MIN(NVL(BM, ID))
                  INTO V_BM
                  FROM PIF.TPIF_CPWDK
                 WHERE NVL(GLID, 0) = NVL(I_GLID, 0)
                   AND WDFL = I_WDFL
                      --  AND WDGS = I_WDGS
                      --  AND NVL(MBID, 0) = NVL(I_MBID, 0)
                   AND NVL(GLLX, 1) = I_GLLX
                      --  AND SFYX = 0
                   AND ID <> I_WDID;
                --存在此旧版本文档
                UPDATE PIF.TPIF_CPWDK --将旧版本的同类文档置为无效
                   SET SFYX = 0, BM = V_BM
                 WHERE SFYX = 1
                   AND GLID = I_GLID
                   AND WDFL = I_WDFL
                      --  AND WDGS = I_WDGS
                      --  AND NVL(MBID, 0) = NVL(I_MBID, 0)
                   AND NVL(GLLX, 1) = I_GLLX
                   AND ID <> I_WDID;
            
                --更新当前产品版本号   
                UPDATE PIF.TPIF_CPWDK A
                   SET A.BM  = V_BM,
                       A.BBH =
                       (SELECT PIF.FUNC_GET_WDBBH(1, V_FJ, BBH)
                          FROM PIF.TPIF_CPWDK
                         WHERE ID = (SELECT MAX(ID)
                                       FROM PIF.TPIF_CPWDK
                                      WHERE NVL(GLID, 0) = NVL(I_GLID, 0)
                                        AND WDFL = I_WDFL
                                           --  AND WDGS = I_WDGS
                                           --  AND NVL(MBID, 0) = NVL(I_MBID, 0)
                                        AND NVL(GLLX, 1) = I_GLLX
                                        AND ID <> I_WDID))
                 WHERE A.ID = I_WDID;
            
                /* 
                DELETE FROM PIF.TPIF_CPWDK A 
                WHERE  WDFL = I_WDFL
                   --AND WDGS = I_WDGS
                   AND NVL(MBID, 0) = NVL(I_MBID, 0)
                   AND NVL(GLLX, 0) = 1 
                   AND ID <> I_WDID;*/
            ELSE
                UPDATE PIF.TPIF_CPWDK
                   SET BM = ID
                 WHERE ID = I_WDID
                   AND BM IS NULL;
            END IF;
        
        ELSE
        
            SELECT COUNT(ID)
              INTO V_CNT
              FROM PIF.TPIF_CPWDK
             WHERE NVL(GLID, 0) = NVL(I_GLID, 0)
               AND WDFL = I_WDFL
                  -- AND WDGS = I_WDGS
                  -- AND NVL(MBID, 0) = NVL(I_MBID, 0)
               AND NVL(GLLX, 1) = I_GLLX
               AND ID <> I_WDID;
        
            IF V_CNT >= 1 THEN
            
                UPDATE PIF.TPIF_CPWDK A
                   SET A.BM  = ID,
                       A.BBH =
                       (SELECT PIF.FUNC_GET_WDBBH(1, V_FJ, BBH)
                          FROM PIF.TPIF_CPWDK
                         WHERE ID = (SELECT MAX(ID)
                                       FROM PIF.TPIF_CPWDK
                                      WHERE NVL(GLID, 0) = NVL(I_GLID, 0)
                                        AND WDFL = I_WDFL
                                           -- AND WDGS = I_WDGS
                                           -- AND NVL(MBID, 0) = NVL(I_MBID, 0)
                                        AND NVL(GLLX, 1) = I_GLLX
                                        AND ID <> I_WDID))
                 WHERE ID = I_WDID;
            
            ELSE
            
                UPDATE PIF.TPIF_CPWDK
                   SET BM = ID
                 WHERE ID = I_WDID
                   AND BM IS NULL;
            
            END IF;
        
        END IF;
    
    END IF;
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := '失败,' || SQLERRM;
        ROLLBACK;
END;
/

