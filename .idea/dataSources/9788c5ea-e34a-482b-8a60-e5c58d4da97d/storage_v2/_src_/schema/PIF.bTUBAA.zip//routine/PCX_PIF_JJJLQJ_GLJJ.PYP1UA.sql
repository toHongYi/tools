create PROCEDURE PCX_PIF_JJJLQJ_GLJJ(O_CODE       OUT NUMBER,
                                                O_NOTE       OUT VARCHAR2,
                                                O_RESULT     OUT SYS_REFCURSOR,
                                                I_CURRENT    IN NUMBER, --页码
                                                I_PAGESIZE   IN NUMBER, --页长
                                                I_PAGING     IN NUMBER, --是否分页
                                                I_SORT       IN STRING, --排序规模
                                                I_TOTAL      IN OUT NUMBER, --记录总数
                                                I_USERID     IN INTEGER, --用户ID
                                                I_MANAGER_ID IN NUMBER, --基金经理ID
                                                I_STATE      IN NUMBER --任职状态
                                                ) AS
  /******************************************************************
  项目名称：产品中心-基金经理全景-管理基金
  所属用户：PIF
  概要说明：查询基金经理管理的基金
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        I_STATE = 0  在职，当前管理基金
        I_STATE = 1  离职，历任管理基金
        
        0 离职;1	在职
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/06    1.0.0.1   杨啸天             新增.
  *********************************************************************************************************************/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
BEGIN

  --初始化
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  --条件检验
  IF I_MANAGER_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '基金经理ID不允许为空！';
    RETURN;
  END IF;

  IF I_STATE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '任职状态不允许为空！';
    RETURN;
  END IF;

  V_SQL := 'SELECT B.JJJC FUND_NAME,
         DECODE(B.JJLB,
                1101,
                ''股票型'',
                1103,
                ''混合型'',
                1105,
                ''债券型'',
                1107,
                ''保本型'',
                1109,
                ''货币型'',
                1110,
                ''QDII'',
                1199,
                ''其他型'',
                ''其他型'') FUND_TYPE,
         TO_CHAR(TO_DATE(A.RZKSRQ, ''YYYYMMDD''), ''YYYY/MM/DD'') || ''-'' ||
         NVL(TO_CHAR(TO_DATE(A.RZJSRQ, ''YYYYMMDD''), ''YYYY/MM/DD''), ''至今'') TERM_TIME,
         TO_CHAR(NVL(TO_DATE(RZJSRQ, ''YYYYMMDD''),TRUNC(SYSDATE)) - 
                 TO_DATE(RZKSRQ, ''YYYYMMDD'')) TERM_DAY,
         to_char(RQSYHBL,''FM999990.0099'')  TERM_RATE
    FROM DSC_STAT.TPIF_STAT_JJJL_LRJJ A, DSC_STAT.TPIF_STAT_JJ B 
   WHERE A.JJID = B.ID
     AND A.JJJLID = ' || I_MANAGER_ID || '
     AND A.RZZT = '  || I_STATE;

  IF V_SORT IS NULL THEN
    V_SORT := 'FUND_NAME DESC';
  END IF;

  V_COLLIST := 'FUND_NAME,FUND_TYPE,TERM_TIME,TERM_DAY,TERM_RATE';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END PCX_PIF_JJJLQJ_GLJJ;
/

