create FUNCTION FUNC_GET_CP_LASTNDAYS_JZRQ(I_CPID IN NUMBER,
                                                      I_NDAYS IN NUMBER,
                                        ) RETURN NUMBER IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：获取
      语法信息：
           输入参数：

           输出参数：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明

  ***********************************************************************/
  CP_JZRQ NUMBER;
BEGIN
CP_JZRQ := SELECT nvl(MAX(JYRQ), -1)
                  FROM PIF.TPIF_CPJZ
                 WHERE CPID = I_CPID
                   AND JYRQ <=
                       (SELECT MAX(ZRR)
                          FROM LIVEBOS.TXTJYR
                         WHERE NZ =
                               (SELECT NZ
                                  FROM LIVEBOS.TXTJYR
                                 WHERE ZRR = TO_CHAR(sysdate - I_NDAYS, 'YYYYMMDD'))
                           AND ZRR = JYR)

  RETURN(CP_JZRQ);
END;
/

