create FUNCTION FUNC_PIF_JYSFYY(I_TABLENAME IN VARCHAR2, --关联对象
                                               I_ID        IN VARCHAR2 --关联对象ID标识
                                               ) RETURN INTEGER IS
    RESULT INTEGER; --返回值：1|是;0|否
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：校验关联对象是否存在引用记录
        语法信息：
             输入参数：   I_TABLENAME IN VARCHAR2, --关联对象
                          I_ID        IN VARCHAR2 --关联对象ID标识
             输出参数：   RESULT INTEGER; --返回值：1|是;0|否
        逻辑说明：
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-15     1.0.2    徐阳                创建
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_SQL   VARCHAR2(1000); --构造语句
BEGIN
    --init
    RESULT := 0;
    --check
    --表名入参为空校验
    IF I_TABLENAME IS NULL THEN
        RETURN(RESULT);
    END IF;
    --数据ID标识为空校验
    IF I_ID IS NULL THEN
        RETURN(RESULT);
    END IF;
    --start
    --校验入参表是否存在
    SELECT COUNT(1) INTO V_COUNT FROM livebos.TTABLEOBJ WHERE REFTABLE = I_TABLENAME;
    IF V_COUNT = 0 THEN
        RETURN(RESULT);
    END IF;
    --默认对PIF查询是否存在引用数据
    FOR CUR IN (SELECT TABLENAME, NAME
                  FROM livebos.TTABLEOBJ
                 WHERE REFTABLE = I_TABLENAME
                   AND EXISTS (SELECT 1
                          FROM livebos.TTABLE
                         WHERE TABLENAME = I_TABLENAME
                           AND TYPE = 0
                           AND DATASOURCENAME = 'PIF')) LOOP
        BEGIN
            V_SQL := 'SELECT COUNT(1) FROM PIF.' || CUR.TABLENAME ||
                     ' WHERE INSTR('';''||' || CUR.NAME || '||'';'','';' || I_ID ||
                     ';'')>0';
            EXECUTE IMMEDIATE V_SQL
                INTO V_COUNT;
        EXCEPTION
            WHEN OTHERS THEN
                V_COUNT := 0;
        END;
        --存在则返回已被引用
        IF V_COUNT > 0 THEN
            RESULT := 1;
            RETURN(RESULT);
        END IF;
    END LOOP;
    --return
    RETURN(RESULT);
END FUNC_PIF_JYSFYY;
/

