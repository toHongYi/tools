create PROCEDURE PRO_PIF_WDGL_WDSCGZ(O_CODE OUT NUMBER,
                                                    O_NOTE OUT VARCHAR2,
                                                    
                                                    I_USERID        IN NUMBER, --登陆用户ID
                                                    I_PROD_IDS      IN VARCHAR2, --产品ID串
                                                    I_ORG_IDS       IN VARCHAR2, --机构ID串
                                                    I_DOC_TYPE_IDS  IN VARCHAR2, --文档分类ID串
                                                    I_PROD_TYPE_IDS IN VARCHAR2 --产品分类ID串
                                                    ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：文档管理-我的收藏规则更新 
  
  
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
  
  
  
        ----------------------------------------------------------
        操作人       版本号      时间                        操作
        WUJINFENG    1.0        2020/06/29                  新增
        HANQIAONNAN  1.0.1      2021/10/11                  删除收藏规则为空的记录
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;

  SELECT COUNT(*) INTO V_COUNT FROM TPIF_WDSZGZ A WHERE A.YH = I_USERID;

  IF V_COUNT > 0 THEN
  
    UPDATE TPIF_WDSZGZ A
       SET A.CPID = I_PROD_IDS,
           A.JGID = I_ORG_IDS,
           A.WDFL = I_DOC_TYPE_IDS,
           A.CPXL = I_PROD_TYPE_IDS
     WHERE A.YH = I_USERID;
  
  ELSE
  
    INSERT INTO TPIF_WDSZGZ
      (ID, YH, CPID, JGID, WDFL, CPXL)
    
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_WDSZGZ'),
       I_USERID,
       I_PROD_IDS,
       I_ORG_IDS,
       I_DOC_TYPE_IDS,
       I_PROD_TYPE_IDS);
  
  END IF;
  
  --收藏规则为空数据删除
  DELETE FROM TPIF_WDSZGZ WHERE CPID IS NULL AND JGID IS NULL AND WDFL IS NULL AND CPXL IS NULL;
  
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
  
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
  
END;
/

