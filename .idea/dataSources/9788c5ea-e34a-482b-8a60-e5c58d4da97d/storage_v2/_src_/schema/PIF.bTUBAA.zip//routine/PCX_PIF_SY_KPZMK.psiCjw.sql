create PROCEDURE PCX_PIF_SY_KPZMK(O_CODE   OUT NUMBER,
                                             O_NOTE   OUT VARCHAR2,
                                             O_RESULT OUT SYS_REFCURSOR,
                                             I_TYPE   IN VARCHAR2 := '1', --查询类型 1:查询所有， 2：查询只显示的
                                             I_USERID IN NUMBER --登陆用户ID
                                             ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：首页-首页可配置模块查询
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                          TYPE  消息类别
                          TOTAL_RECORD_NUM  总记录数
                          ALREADY_DEAL_NUM  已阅/已处理数
                          TIPS  提示信息
                          URL 明细链接URL
  
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        刘浪浪    1.0.1    2015/01/26                   新增
  
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  SELECT COUNT(*) INTO V_COUNT FROM TPIF_SYMKPZ WHERE YH = I_USERID;

  IF I_TYPE = '1' THEN
  
    IF V_COUNT > 0 THEN
      OPEN O_RESULT FOR
        SELECT A.ID AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               (CASE
                 WHEN B.MKID IS NULL THEN
                  0
                 ELSE
                  1
               END) AS ISSHOW,
               NVL(B.XSCS, A.MRXSCS) AS DISPLAYPARAM,
               A.CXLX AS QUERYTYPE
          FROM TPIF_SYMK A, TPIF_SYMKPZ B
         WHERE A.ID = B.MKID(+);
    ELSE
    
      OPEN O_RESULT FOR
        SELECT A.ID     AS ID,
               A.XSTB   AS ICON,
               A.MKMC   AS NAME,
               A.MRZS   AS ISSHOW,
               A.MRXSCS AS DISPLAYPARAM,
               A.CXLX   AS QUERYTYPE
          FROM TPIF_SYMK A;
    
    END IF;
  ELSE
  
    IF V_COUNT > 0 THEN
    
      OPEN O_RESULT FOR
        SELECT A.ID   AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               1      AS ISSHOW,
               B.XSCS AS DISPLAYPARAM,
               A.CXLX AS QUERYTYPE
          FROM TPIF_SYMK A, TPIF_SYMKPZ B
         WHERE A.ID = B.MKID;
    ELSE
    
      OPEN O_RESULT FOR
        SELECT A.ID     AS ID,
               A.XSTB   AS ICON,
               A.MKMC   AS NAME,
               A.MRZS   AS ISSHOW,
               A.MRXSCS AS DISPLAYPARAM,
               A.CXLX   AS QUERYTYPE
          FROM TPIF_SYMK A
         WHERE A.MRZS = 1;
    
    END IF;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

