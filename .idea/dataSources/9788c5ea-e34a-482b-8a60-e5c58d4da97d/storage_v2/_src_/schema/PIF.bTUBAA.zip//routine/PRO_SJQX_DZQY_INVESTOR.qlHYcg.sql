create PROCEDURE PRO_SJQX_DZQY_INVESTOR(O_CODE OUT NUMBER, --返回值
                                                   O_NOTE OUT VARCHAR2 --返回消息
                                                   ) IS

  /******************************************************************
      所属用户：PIF
      功能说明：电子签约投资人表 PIF.DZQY_INVESTOR 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5       1.0       HANQN              创建
  
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO DZQY_INVESTOR_TEST T
  USING (SELECT INVESTOR_NO,
                NAME,
                MOBILE,
                CARDTYPE AS CARD_TYPE,
                CARDNO AS CARD_NO,
                TYPE,
                RISKLEVEL AS RISK_LEVEL,
                ITOACCOUNT AS ITO_ACCOUNT,
                ITOTOKEN AS ITO_TOKEN,
                BRANCH_NO,
                TO_DATE(TO_CHAR(PUSH_DATE) || TO_CHAR(PUSH_TIME,'FM099999'),'YYYYMMDDHH24MISS') AS PUSH_DATE,
                FUND_ACCOUNT,
                DECODE(PROFESSION_FLAG, 1, 1, 2) AS PROFESSION_FLAG,
                DECODE(SOURCE_DEL_FLAG,1,1,2) AS DELETED_FLAG
           FROM SRC_PIF.PROD_INVESTOR_INFO
           ) S
  ON (T.INVESTOR_NO = S.INVESTOR_NO)
   WHEN MATCHED THEN
     UPDATE
        SET T.FUND_ACCOUNT    = S.FUND_ACCOUNT,
            T.NAME            = S.NAME,
            T.MOBILE          = S.MOBILE,
            T.TYPE            = S.TYPE,
            T.CARD_TYPE       = S.CARD_TYPE,
            T.CARD_NO         = S.CARD_NO,
            T.RISK_LEVEL      = S.RISK_LEVEL,
            T.BRANCH_NO       = S.BRANCH_NO,
            T.PROFESSION_FLAG = S.PROFESSION_FLAG,
            T.ITO_ACCOUNT     = S.ITO_ACCOUNT,
            T.ITO_TOKEN       = S.ITO_TOKEN,
            T.PUSH_DATE       = S.PUSH_DATE,
            T.DELETED_FLAG    = S.DELETED_FLAG
   WHEN NOT MATCHED THEN
     INSERT
       (T.ID,
        T.FUND_ACCOUNT,
        T.INVESTOR_NO,
        T.NAME,
        T.MOBILE,
        T.TYPE,
        T.CARD_TYPE,
        T.CARD_NO,
        T.RISK_LEVEL,
        T.BRANCH_NO,
        T.PROFESSION_FLAG,
        T.ITO_ACCOUNT,
        T.ITO_TOKEN,
        T.PUSH_DATE,
        T.CREATE_DATE,
        T.LAST_MODIFIED_DATE,
        T.DELETED_FLAG)
     VALUES
       (LIVEBOS.FUNC_NEXTID('DZQY_INVESTOR_TEST'),
        S.FUND_ACCOUNT,
        S.INVESTOR_NO,
        S.NAME,
        S.MOBILE,
        S.TYPE,
        S.CARD_TYPE,
        S.CARD_NO,
        S.RISK_LEVEL,
        S.BRANCH_NO,
        S.PROFESSION_FLAG,
        S.ITO_ACCOUNT,
        S.ITO_TOKEN,
        S.PUSH_DATE,
        SYSDATE,
        SYSDATE,
        S.DELETED_FLAG);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'PIF.DZQY_INVESTOR 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'PIF.DZQY_INVESTOR  表清洗,未知错误'
                ELSE
                 'PIF.DZQY_INVESTOR ,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

