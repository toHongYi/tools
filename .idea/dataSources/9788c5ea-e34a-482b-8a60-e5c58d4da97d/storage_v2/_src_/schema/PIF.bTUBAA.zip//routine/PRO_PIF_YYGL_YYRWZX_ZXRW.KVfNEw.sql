create PROCEDURE PRO_PIF_YYGL_YYRWZX_ZXRW(O_CODE            OUT NUMBER,
                                                         O_NOTE            OUT VARCHAR2,
                                                         I_USERID          IN NUMBER, --操作用户
                                                         I_IP              IN VARCHAR2, --操作IP
                                                         I_OPERATE_TASK_ID IN NUMBER, --运营任务ID
                                                         I_EXEC_DESC       IN VARCHAR2 --执行说明
                                                         ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：海通证券产品中心
  
         功能说明：执行任务
             参数说明：
                  入参：
                       I_USERID IN  NUMBER,   --操作用户
                       I_IP     IN  VARCHAR2, --操作IP
                       I_OPERATE_TASK_ID   IN NUMBER     --运营任务ID
                       I_EXEC_DESC IN VARCHAR2 --执行说明
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
  
  
        ----------------------------------------------------------
        操作人       版本号         时间                        操作
        刘浪浪       1.0.1     2014/11/17                  新增
  
  -------------------------------------------------------------------------------------------------*/
  V_MXID NUMBER(16); --运营任务执行明细ID
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '用户ID不能为空!';
    RETURN;
  END IF;

  IF I_IP IS NULL THEN
    --操作IP不能为空
    O_CODE := -1;
    O_NOTE := '操作IP不能为空!';
    RETURN;
  END IF;

  IF I_OPERATE_TASK_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '运营任务ID不能为空!';
    RETURN;
  END IF;

  UPDATE TPIF_CPYYRW
     SET (ZXZT, SJWCSJ) =
         (SELECT 1, SYSDATE FROM DUAL)
   WHERE ID = I_OPERATE_TASK_ID;

  /* CRMII.PRO_CZRZDJ(O_CODE, --登记操作日志
  O_NOTE,
  I_USERID,
  'TPIF_CPYYRW',
  'UPDATE',
  I_OPERATE_TASK_ID,
  '修改',
  I_IP,
  '28009',
  '');*/

  V_MXID := LIVEBOS.FUNC_NEXTID('TPIF_CPYYRWZXMX'); --获取执行明细表的ID

  INSERT INTO TPIF_CPYYRWZXMX
    (ID, CPYYRW, ZXRY, CZLX, ZXSJ, ZXRWSM) --生成执行任务明细
    SELECT V_MXID, I_OPERATE_TASK_ID, I_USERID, 1, SYSDATE, I_EXEC_DESC
      FROM DUAL;

  /*    LIVEBOS.PRO_CZRZDJ(O_CODE, --登记操作日志
  O_NOTE,
  I_USERID,
  'TPIF_CPYYRWZXMX',
  'ADD',
  V_MXID,
  '新增',
  I_IP,
  '28008',
  '');*/
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    ROLLBACK;
  
END PRO_PIF_YYGL_YYRWZX_ZXRW;
/

