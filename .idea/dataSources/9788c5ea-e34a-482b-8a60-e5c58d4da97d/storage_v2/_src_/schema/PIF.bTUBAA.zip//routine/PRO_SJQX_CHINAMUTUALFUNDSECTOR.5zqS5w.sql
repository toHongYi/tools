create PROCEDURE PRO_SJQX_CHINAMUTUALFUNDSECTOR(O_CODE OUT NUMBER,
                                                           O_NOTE OUT VARCHAR2) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      WIND产品标签清洗
  
      语法信息：
           输入参数：
  
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-08-26     1.0.0    李 良                  XIN ZENG
          2021-10-11     1.0.1    GAOKUN                补充CPID
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  -- 李良临时处理，产品中心先评审了，但是没录入产品代码，但是上线到了柜台，导致重新写产品代码记录

   UPDATE PIF.TPIF_SALE_PROD_TYPE_INFO M
      SET M.PROD_CODE =
          (SELECT CPDM
             FROM PIF.TPIF_CPDM N
            WHERE M.CPID = N.CPID
              AND TRIM(N.CPDM) IS NOT NULL)
    WHERE TRIM(M.PROD_CODE) IS NULL;
   
  MERGE INTO PIF.TPIF_SALE_PROD_TYPE_INFO M
  USING (SELECT CPDM, CPMC, CPID
           FROM PIF.TPIF_CPDM A
          WHERE NOT EXISTS (SELECT 1
                   FROM PIF.TPIF_SALE_PROD_TYPE_INFO B
                  WHERE B.PROD_CODE = A.CPDM)
            AND A.CPDM IS NOT NULL) N
  ON (M.PROD_CODE = N.CPDM)
  WHEN NOT MATCHED THEN
    INSERT
      (ID, PROD_CODE, PROD_NAME, XGR, XGSJ, CPID)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_SALE_PROD_TYPE_INFO'),
       N.CPDM,
       N.CPMC,
       0,
       SYSDATE,
       N.CPID);
  -- 更新WIND公募产品分类
  MERGE INTO PIF.TPIF_SALE_PROD_TYPE_INFO M
  USING (SELECT A.PROD_CODE,
                A.PROD_FIRST_TYPE_NAME,
                A.PROD_SECOND_TYPE_NAME,
                B.CPMC,
                B.CPID
           FROM SRC_PIF.CHINAMUTUALFUNDSECTOR A, PIF.TPIF_CPDM B
          WHERE A.PROD_CODE = B.CPDM
            AND A.CUR_SIGN = 1) N
  ON (M.PROD_CODE = N.PROD_CODE)
  WHEN MATCHED THEN
    UPDATE
       SET M.PROD_FIRST_TYPE  = N.PROD_FIRST_TYPE_NAME,
           M.PROD_SECOND_TYPE = N.PROD_SECOND_TYPE_NAME,
           M.PROD_TYPE        = '公募',
           M.PROD_TYPE_CODE   = 1,
           M.CPID             = N.CPID
  WHEN NOT MATCHED THEN
    INSERT
      (ID,
       PROD_CODE,
       PROD_NAME,
       PROD_FIRST_TYPE,
       PROD_SECOND_TYPE,
       PROD_TYPE_CODE,
       PROD_TYPE,
       CPID)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_SALE_PROD_TYPE_INFO'),
       N.PROD_CODE,
       N.CPMC,
       N.PROD_FIRST_TYPE_NAME,
       N.PROD_SECOND_TYPE_NAME,
       1,
       '公募',
       N.CPID);

  -- 处理报送类型的字典翻译
  UPDATE PIF.TPIF_SALE_PROD_TYPE_INFO A
  -- ISSUE_SOURCE_CODE 发行来源
     SET A.ISSUE_SOURCE_CODE       =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.ISSUE_SOURCE
             AND B.FLDM = 'PIF_ISSUE_SOURCE'),
         A.PROD_KIND_CODE          =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.PROD_KIND
             AND B.FLDM = 'PIF_PROD_KIND'),
         A.TRANSMIT_PROD_TYPE_CODE =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.TRANSMIT_PROD_TYPE
             AND B.FLDM = 'PIF_TRANSMIT_PROD_TYPE'),
         A.PROD_PUBLISHER_CODE     =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.PROD_PUBLISHER
             AND B.FLDM = 'PIF_PROD_PUBLISHER'),
         A.PROD_INCOME_FEATURE_CODE =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.PROD_INCOME_FEATURE
             AND B.FLDM = 'PIF_PROD_INCOME_FEATURE'),
         A.PROD_INCOME_TYPE_CODE   =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.PROD_INCOME_TYPE
             AND B.FLDM = 'PIF_PROD_INCOME_TYPE'),
         A.PROD_TYPE_CODE          =
         (SELECT IBM
            FROM LIVEBOS.TXTDM B
           WHERE B.NOTE = A.PROD_TYPE
             AND B.FLDM = 'PIF_CPXL_CPZX'),
         A.PROD_FIRST_TYPE_CODE    =
         (SELECT B.FLBM
            FROM PIF.TPIF_JRCPFL B
           WHERE A.PROD_FIRST_TYPE = B.NAME
             AND B.GRADE = 2),
         A.PROD_SECOND_TYPE_CODE   =
         (SELECT B.FLBM
            FROM PIF.TPIF_JRCPFL B
           WHERE A.PROD_SECOND_TYPE = B.NAME
             AND B.GRADE = 3)
  -- WHERE A.PROD_FIRST_TYPE_CODE IS NULL
  ;

  MERGE INTO PIF.TPIF_CPDM M
  USING (SELECT D.PROD_TYPE_CODE,
                D.PROD_FIRST_TYPE_CODE,
                PROD_CODE,
                --D.PROD_SELL_TYPE_CODE,
                PROD_NAME
           FROM TPIF_SALE_PROD_TYPE_INFO D
          WHERE D.PROD_TYPE_CODE IS NOT NULL) N
  ON (M.CPDM = N.PROD_CODE)
  WHEN MATCHED THEN
    UPDATE
       SET M.CPXL = N.PROD_TYPE_CODE, M.JRCPFL = N.PROD_FIRST_TYPE_CODE
    /*           , M.XSSC   = CASE
      WHEN N.PROD_SELL_TYPE_CODE NOT IN (1, 2, 3) THEN
       1
      ELSE
       N.PROD_SELL_TYPE_CODE
    END*/
    
    ;

  -- TODO 产品标签

  -- 更新私募资管计划的产品标签
  MERGE INTO TPIF_CPBQMX T
  USING (SELECT A.CPDM, A.CPID, C.ID AS CPBQ, C.BQLX, C.MC AS BQMC
           FROM TPIF_CPDM A,
                PIF.TPIF_SALE_PROD_TYPE_INFO B,
                (SELECT X.ID, X.MC, X.BQLX
                   FROM TPIF_CPBQ X
                  WHERE X.BQLX IN
                        (SELECT Y.ID
                           FROM PIF.TPIF_BQLX Y
                          WHERE Y.BQLXBM IN ('CPZX_SMZGJH', 'CPZX_SMTZJJ'))) C
          WHERE A.CPDM = B.PROD_CODE
            AND B.PROD_TYPE_CODE IN ('3', '2')
            AND C.MC = B.PROD_SECOND_TYPE) S
  ON (T.CPID = S.CPID AND T.CPBQ IN (SELECT X.ID
                                       FROM TPIF_CPBQ X
                                      WHERE X.BQLX IN
                                            (SELECT Y.ID
                                               FROM PIF.TPIF_BQLX Y
                                              WHERE Y.BQLXBM IN
                                                    ('CPZX_SMZGJH',
                                                     'CPZX_SMTZJJ')))) --产品和标签
  WHEN MATCHED THEN
    UPDATE SET T.CPBQ = S.CPBQ, T.CZSJ = SYSDATE, T.BQLX = S.BQLX
  WHEN NOT MATCHED THEN
    INSERT
      (T.ID, T.CPBQ, T.CPID, T.XSSX, T.YSLY, T.CZSJ, T.BQLX) --XSSX显示顺序，目前看没用，YSLY映射来源，1|系统标签;2|手工标签;
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPBQMX'),
       S.CPBQ,
       S.CPID,
       S.CPID,
       1,
       SYSDATE,
       S.BQLX);


  COMMIT;
  O_CODE := 1;
  O_NOTE := '新增成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

