create PROCEDURE PRO_PIF_CPSJLX_RLZS(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    I_USER IN INTEGER, --操作人
                                                    I_IP   IN VARCHAR2, --操作IP
                                                    I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|上移;4|下移
                                                    I_ID   IN INTEGER --操作ID
                                                    ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品日历展示事件维护
        语法信息：
             输入参数：
             输出参数：   O_RESULT  返回结果
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-25     1.0.1    徐阳                创建
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPSJLX_RLZS%ROWTYPE; --表单记录
    V_ZSSX    NUMBER(8); --展示顺序
    V_CZBM  VARCHAR2(200); --操作编码
    V_CZSM  VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    SELECT * INTO V_OBJ FROM TPIF_CPSJLX_RLZS WHERE ID = I_ID;
    SELECT DECODE(I_OPER, 0, '301701', 1, '301702', 2, '301703', 3, '301704', 4, '301705', '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', 3, '上移',4, '下移', '') || ']_' ||
           V_OBJ.CPSJLX
      INTO V_CZSM
      FROM DUAL;

    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';

    IF I_OPER = 0 THEN
        --//:新增
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPSJLX_RLZS
         WHERE RLLX = V_OBJ.RLLX
           AND CPSJLX = V_OBJ.CPSJLX;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在相同的记录!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --//:修改
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPSJLX_RLZS
         WHERE RLLX = V_OBJ.RLLX
           AND CPSJLX = V_OBJ.CPSJLX;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在相同的记录!';
            RETURN;
        END IF;
    END IF;

    IF I_OPER = 2 THEN
        --//:删除

        DELETE TPIF_CPSJLX_RLZS WHERE ID = I_ID;
    END IF;

    IF I_OPER = 3 THEN
        --//:上移
        --获取小于该顺序的日历类型的展示顺序
        SELECT MAX(ZSSX)
          INTO V_ZSSX
          FROM TPIF_CPSJLX_RLZS
         WHERE RLLX = V_OBJ.RLLX
           AND ZSSX < V_OBJ.ZSSX;
        IF V_ZSSX IS NULL THEN
            O_CODE := 1;
            O_NOTE := '没有上级节点';
            RETURN;
        END IF;

        --下移上级节点
        UPDATE TPIF_CPSJLX_RLZS
           SET ZSSX = V_OBJ.ZSSX
         WHERE RLLX = V_OBJ.RLLX
           AND ZSSX = V_ZSSX;

        --上移当前节点
        UPDATE TPIF_CPSJLX_RLZS SET ZSSX = V_ZSSX WHERE ID = V_OBJ.ID;

    END IF;

    IF I_OPER = 4 THEN

        --获取大于该顺序的日历类型的展示顺序
        SELECT MIN(ZSSX)
          INTO V_ZSSX
          FROM TPIF_CPSJLX_RLZS
         WHERE RLLX = V_OBJ.RLLX
           AND ZSSX > V_OBJ.ZSSX;

        IF V_ZSSX IS NULL THEN
            O_CODE := 1;
            O_NOTE := '没有下级节点';
            RETURN;
        END IF;

        --上移下级节点
        UPDATE TPIF_CPSJLX_RLZS
           SET ZSSX = V_OBJ.ZSSX
         WHERE RLLX = V_OBJ.RLLX
           AND ZSSX = V_ZSSX;

        --下移当前节点
        UPDATE TPIF_CPSJLX_RLZS SET ZSSX = V_ZSSX WHERE ID = V_OBJ.ID;

    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE,O_NOTE,I_USER,I_IP,V_CZBM,V_OBJ.ID,V_CZSM);
    IF O_CODE < 0 THEN RETURN; ELSE O_CODE := -1; O_NOTE := ''; END IF;
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', 3， '上移', 4, '下移') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
        ROLLBACK;
END PRO_PIF_CPSJLX_RLZS;
/

