create PROCEDURE PRO_PIF_ZZHTGLLS(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_ID   IN NUMBER, --流程ID
                                             I_LCZT IN NUMBER, --流程状态 1|提交;2|驳回;3|结束
                                             I_SQLC IN NUMBER --1|合同申请;2|合同寄回;3|总部寄出;4|合同入库
                                             ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：纸质合同管理流水
      语法信息：
           输入参数：
                       I_ID   IN NUMBER, --流程ID
                       I_LCZT IN NUMBER, --流程状态 1|提交;2|驳回;3|结束
                       I_SQLC   IN NUMBER --1|合同申请;2|合同寄回;3|总部寄出;4|合同入库
                       当申请流程是4|合同入库，流程状态（1，新增，2，修改，3，删除，4，导入）
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-11-18     1.0.0    LTX                 创建
  ***********************************************************************/

  V_OBJ  TPIF_CPDM%ROWTYPE; --表单记录
  V_OBJ1 PIF.LC_HTSQ%ROWTYPE;
  V_OBJ2 LC_HTJH%ROWTYPE; --合同寄回流程记录
  V_OBJ3 LC_ZBJCLC%ROWTYPE;
  V_OBJ4 TPIF_CPHT%ROWTYPE;

  V_COUNT NUMBER; --寄回(转寄)合同数量

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_SQLC = 1 THEN
    --合同申请
    SELECT * INTO V_OBJ1 FROM PIF.LC_HTSQ WHERE ID = I_ID;
    SELECT * INTO V_OBJ FROM TPIF_CPDM WHERE ID = V_OBJ1.CPID;
    --驳回不修改上一步状态和营业部
    IF I_LCZT != 2 THEN
      UPDATE PIF.TPIF_CPHT
         SET SYBZT = ZT
       WHERE INSTR(';' || V_OBJ1.HTID || ';', ';' || ID || ';') > 0;

      UPDATE PIF.TPIF_CPHT
         SET YYBID = V_OBJ1.YYB, ZT = DECODE(I_LCZT, 1, 2, 3, 3)
       WHERE INSTR(';' || V_OBJ1.HTID || ';', ';' || ID || ';') > 0;

    ELSE
      UPDATE PIF.TPIF_CPHT
         SET ZT = SYBZT
       WHERE INSTR(';' || V_OBJ1.HTID || ';', ';' || ID || ';') > 0;
    END IF;
    COMMIT;

    FOR CUR IN (SELECT REGEXP_SUBSTR(V_OBJ1.HTID, '[^;]+', 1, LEVEL, 'i') AS HTBH
                  FROM DUAL T
                CONNECT BY LEVEL <=
                           LENGTH(V_OBJ1.HTID) -
                           LENGTH(REGEXP_REPLACE(V_OBJ1.HTID, ';', '')) + 1) LOOP

      SELECT *
        INTO V_OBJ4
        FROM TPIF_CPHT
       WHERE CPID = V_OBJ1.CPID
         AND ID = CUR.HTBH;

      INSERT INTO PIF.TPIF_HTLSCX
        (ID,
         CPID,
         CPDM,
         HTID,
         HTQSZT,
         YYB,
         SQBH,
         SQLC,
         KDDH,
         CZSJ,
         LCZT,
         HTZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
         V_OBJ1.CPID,
         V_OBJ.CPDM,
         CUR.HTBH,
         V_OBJ4.QSZT,
         V_OBJ1.YYB,
         V_OBJ1.SQBH,
         '合同申请流程',
         V_OBJ1.KDDH,
         SYSDATE,
         DECODE(I_LCZT, 1, '提交', 2, '驳回', 3, '结束'),
         DECODE(I_LCZT, 1, 2, 2, V_OBJ4.SYBZT, 3, 3));

    END LOOP;
  ELSIF I_SQLC = 2 THEN
    --合同寄回

    SELECT * INTO V_OBJ2 FROM LC_HTJH WHERE ID = I_ID;
    SELECT * INTO V_OBJ FROM TPIF_CPDM WHERE ID = V_OBJ2.CPID;

    --寄回合同流程 申请类型=1寄回
    IF V_OBJ2.SQLX = 1 THEN

      --寄回合同数量
      SELECT COUNT(1)
        INTO V_COUNT
        FROM LC_HTJH_JHHTXX
       WHERE LC_HTJH_ID = I_ID;
      UPDATE LC_HTJH SET JCSL = V_COUNT WHERE ID = I_ID;

      FOR CUR IN (SELECT * FROM LC_HTJH_JHHTXX WHERE LC_HTJH_ID = I_ID) LOOP
        --寄回合同信息表格循环

        IF I_LCZT = 1 THEN
          --寄回 营业部提交,仅修改合同的
          UPDATE TPIF_CPHT
             SET SYBZT = ZT, --上一步状态 =当前状态
                 ZT    = 4, --状态 总部待签收
                 YYBID = V_OBJ2.YYBID --该合同关联至该营业部名下(实际上当前已经在该营业部下)
          --CZR = V_OBJ2.SQR,--操作人 流程发起人
          --CZSJ = SYSDATE--操作时间
           WHERE ID = CUR.CPHT
             AND SFSC = 0; --未删除

        ELSIF I_LCZT = 2 THEN
          --寄回 总部驳回
          UPDATE PIF.TPIF_CPHT
             SET ZT = SYBZT --状态还原回去
          --CZR   = V_OBJ2.SQR,--操作人 流程发起人
          --CZSJ  = SYSDATE--操作时间
           WHERE ID = CUR.CPHT
             AND SFSC = 0;

        ELSE
          -- 寄回 总部通过(结束)
          UPDATE TPIF_CPHT
             SET SYBZT = ZT,
                 ZT    = DECODE(CUR.HTQSZT, 1, 1, 5), --状态 如果签署状态空白，则合同状态已入库，其余 总部签收
                 YYBID = V_OBJ2.YYBID, --关联至该营业部名下
                 QSZT  = CUR.HTQSZT, --签署状态
                 KHH   = CUR.KHH, --客户号
                 KHXM  = CUR.KHXM, --客户姓名
                 EMAIL = CUR.KHYX, --客户邮箱
                 SM    = CUR.SM --说明
          --CZR = V_OBJ2.SQR,--操作人 流程发起人
          --CZSJ = SYSDATE--操作时间
           WHERE ID = CUR.CPHT
             AND SFSC = 0;
        END IF;

        SELECT * INTO V_OBJ4 FROM TPIF_CPHT WHERE ID = CUR.CPHT;

        INSERT INTO PIF.TPIF_HTLSCX
          (ID,
           CPID,
           CPDM,
           HTID,
           HTQSZT,
           YYB,
           SQBH,
           SQLC,
           KDDH,
           CZSJ,
           LCZT,
           HTZT)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
           CUR.CPID,
           V_OBJ.CPDM,
           CUR.CPHT,
           CUR.HTQSZT,
           V_OBJ2.YYBID,
           V_OBJ2.SQBH,
           '合同寄回流程',
           V_OBJ2.KDDH,
           SYSDATE,
           DECODE(I_LCZT, 1, '提交', 2, '驳回', 3, '结束'),
           V_OBJ4.ZT);
      END LOOP;

      --寄回合同流程 申请类型=2转寄
    ELSE

      --转寄合同数量
      UPDATE LC_HTJH
         SET JCSL = REGEXP_COUNT(ZJHT, ';') + 1
       WHERE ID = I_ID;

      IF I_LCZT = 1 THEN
        --转寄 营业部提交
        UPDATE TPIF_CPHT
           SET SYBZT = ZT, --上一步状态 =当前状态
               ZT    = 6, --状态 转寄营业部待签收
               YYBID = V_OBJ2.JSYYBID --该合同关联至转寄营业部名下
        --CZR = V_OBJ2.SQR,--操作人 流程发起人
        --CZSJ = SYSDATE--操作时间
         WHERE INSTR(';' || V_OBJ2.ZJHT || ';', ';' || ID || ';') > 0 --更新选择的转寄合同
           AND SFSC = 0; --未删除

      ELSIF I_LCZT = 2 THEN
        --转寄 营业部驳回
        UPDATE PIF.TPIF_CPHT
           SET ZT    = SYBZT, --状态还原回去
               YYBID = V_OBJ2.YYBID --关联营业部 还原回去
        --CZR   = V_OBJ2.SQR,--操作人 流程发起人
        --CZSJ  = SYSDATE--操作时间
         WHERE INSTR(';' || V_OBJ2.ZJHT || ';', ';' || ID || ';') > 0
           AND SFSC = 0;

      ELSE
        --转寄 营业部通过(结束)
        UPDATE TPIF_CPHT
           SET SYBZT = ZT,
               ZT    = 3, --状态 营业部签收
               YYBID = V_OBJ2.JSYYBID --该合同关联至转寄营业部
        --CZR = V_OBJ2.SQR,--操作人 流程发起人
        --CZSJ = SYSDATE--操作时间
         WHERE INSTR(';' || V_OBJ2.ZJHT || ';', ';' || ID || ';') > 0
           AND SFSC = 0;
      END IF;

      FOR CUR IN (SELECT REGEXP_SUBSTR(V_OBJ2.ZJHT, '[^;]+', 1, LEVEL, 'i') AS HTBH
                    FROM DUAL T
                  CONNECT BY LEVEL <=
                             LENGTH(V_OBJ2.ZJHT) -
                             LENGTH(REGEXP_REPLACE(V_OBJ2.ZJHT, ';', '')) + 1) LOOP

        SELECT * INTO V_OBJ4 FROM TPIF_CPHT WHERE ID = CUR.HTBH;

        INSERT INTO PIF.TPIF_HTLSCX
          (ID,
           CPID,
           CPDM,
           HTID,
           HTQSZT,
           YYB,
           SQBH,
           SQLC,
           KDDH,
           CZSJ,
           LCZT,
           HTZT)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
           V_OBJ2.CPID,
           V_OBJ.CPDM,
           CUR.HTBH,
           V_OBJ4.QSZT,
           DECODE(I_LCZT, --流程状态
                  1, V_OBJ2.JSYYBID, --提交，写转寄营业部
                  2, V_OBJ2.YYBID, --驳回，写申请营业部
                  3, V_OBJ2.JSYYBID), --结束，写转寄营业部
           V_OBJ2.SQBH,
           '合同转寄流程',
           V_OBJ2.KDDH,
           SYSDATE,
           DECODE(I_LCZT, 1, '提交', 2, '驳回', 3, '结束'),
           V_OBJ4.ZT);

      END LOOP;

    END IF;

  ELSIF I_SQLC = 3 THEN

    SELECT * INTO V_OBJ3 FROM LC_ZBJCLC WHERE ID = I_ID;
    SELECT * INTO V_OBJ FROM TPIF_CPDM WHERE ID = V_OBJ3.CPID;
    --寄给管理人
    IF V_OBJ3.JCLX = 1 THEN
      UPDATE TPIF_CPHT
         SET ZT = 7
       WHERE INSTR(';' || V_OBJ3.HTXZ || ';', ';' || ID || ';') > 0;

      FOR CUR IN (SELECT REGEXP_SUBSTR(V_OBJ3.HTXZ, '[^;]+', 1, LEVEL, 'i') AS HTBH
                    FROM DUAL T
                  CONNECT BY LEVEL <=
                             LENGTH(V_OBJ3.HTXZ) -
                             LENGTH(REGEXP_REPLACE(V_OBJ3.HTXZ, ';', '')) + 1) LOOP

        SELECT *
          INTO V_OBJ4
          FROM TPIF_CPHT
         WHERE CPID = V_OBJ3.CPID
           AND ID = CUR.HTBH;

        INSERT INTO PIF.TPIF_HTLSCX
          (ID,
           CPID,
           CPDM,
           HTID,
           HTQSZT,
           YYB,
           SQBH,
           SQLC,
           KDDH,
           CZSJ,
           LCZT,
           HTZT)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
           V_OBJ3.CPID,
           V_OBJ.CPDM,
           CUR.HTBH,
           V_OBJ4.QSZT,
           V_OBJ3.YYB,
           V_OBJ3.SQBH,
           '总部寄给管理人流程',
           V_OBJ3.KDDH,
           SYSDATE,
           '结束',
           V_OBJ4.ZT);

      END LOOP;
    ELSE
      --驳回不修改上一步状态和营业部
      IF I_LCZT != 2 THEN
        UPDATE PIF.TPIF_CPHT
           SET SYBZT = ZT
         WHERE INSTR(';' || V_OBJ3.HTXZ || ';', ';' || ID || ';') > 0;

        UPDATE PIF.TPIF_CPHT
           SET YYBID = V_OBJ3.YYB, ZT = DECODE(I_LCZT, 1, 2, 3, 3)
         WHERE INSTR(';' || V_OBJ3.HTXZ || ';', ';' || ID || ';') > 0;

      ELSE
        UPDATE PIF.TPIF_CPHT
           SET ZT = SYBZT
         WHERE INSTR(';' || V_OBJ3.HTXZ || ';', ';' || ID || ';') > 0;
      END IF;
      COMMIT;

      FOR CUR IN (SELECT REGEXP_SUBSTR(V_OBJ3.HTXZ, '[^;]+', 1, LEVEL, 'i') AS HTBH
                    FROM DUAL T
                  CONNECT BY LEVEL <=
                             LENGTH(V_OBJ3.HTXZ) -
                             LENGTH(REGEXP_REPLACE(V_OBJ3.HTXZ, ';', '')) + 1) LOOP

        SELECT *
          INTO V_OBJ4
          FROM TPIF_CPHT
         WHERE CPID = V_OBJ3.CPID
           AND ID = CUR.HTBH;

        INSERT INTO PIF.TPIF_HTLSCX
          (ID,
           CPID,
           CPDM,
           HTID,
           HTQSZT,
           YYB,
           SQBH,
           SQLC,
           KDDH,
           CZSJ,
           LCZT,
           HTZT)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
           V_OBJ3.CPID,
           V_OBJ.CPDM,
           CUR.HTBH,
           V_OBJ4.QSZT,
           V_OBJ3.YYB,
           V_OBJ3.SQBH,
           '总部寄出流程',
           V_OBJ3.KDDH,
           SYSDATE,
           DECODE(I_LCZT, 1, '提交', 2, '驳回', 3, '结束'),
           DECODE(I_LCZT, 1, 2, 2, V_OBJ4.SYBZT, 3, 3));

      END LOOP;

    END IF;

  ELSIF I_SQLC = 4 THEN
    SELECT * INTO V_OBJ4 FROM TPIF_CPHT WHERE ID = I_ID;
    IF I_LCZT = 1 THEN
      INSERT INTO PIF.TPIF_HTLSCX
        (ID, CPID, CPDM, HTID, SQLC, CZSJ, HTZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
         V_OBJ4.CPID,
         V_OBJ4.CPDM,
         I_ID,
         '新增产品合同',
         SYSDATE,
         1);
    ELSIF I_LCZT = 2 THEN
      INSERT INTO PIF.TPIF_HTLSCX
        (ID, CPID, CPDM, HTID, SQLC, CZSJ, HTZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
         V_OBJ4.CPID,
         V_OBJ4.CPDM,
         I_ID,
         '修改产品合同',
         SYSDATE,
         V_OBJ4.ZT);
    ELSIF I_LCZT = 3 THEN
      INSERT INTO PIF.TPIF_HTLSCX
        (ID, CPID, CPDM, HTID, SQLC, CZSJ, HTZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
         V_OBJ4.CPID,
         V_OBJ4.CPDM,
         I_ID,
         '删除产品合同',
         SYSDATE,
         V_OBJ4.ZT);

    END IF;

  END IF;

  COMMIT;
  O_CODE := 199;
  O_NOTE := '执行成功!';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_ZZHTGLLS;
/

