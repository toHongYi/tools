create PROCEDURE PCX_PIF_YYGL_YYRWGKTJ_ZYCD(O_CODE   OUT NUMBER,
                                                       O_NOTE   OUT VARCHAR2,
                                                       O_RESULT OUT SYS_REFCURSOR,
                                                       /* I_query_type   IN NUMBER, --1|任务执行人;2|运营管理人
                                                                                                                I_USERID IN NUMBER, --执行人ID
                                                                                                                I_data_interval   IN NUMBER, --1|日;2|周;3|月
                                                                                                                I_qury_date     IN VARCHAR2 --查询如期*/
                                                       I_query_type    IN NUMBER, --1|任务执行人;2|运营管理人
                                                       I_userid        IN NUMBER, --执行人ID
                                                       I_data_interval IN NUMBER, --1|日;2|周;3|月
                                                       I_qury_date     IN VARCHAR2 --查询如期*/
                                                       
                                                       ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：海通证券产品中心
  
         功能说明：按重要程度统计
             参数说明：
                  入参：
                       I_query_type   IN NUMBER, --1|任务执行人;2|运营管理人
                       I_USERID IN NUMBER, --执行人ID
                       I_data_interval   IN NUMBER, --1|日;2|周;3|月
                       I_qury_date     IN NUMBER  --查询如期
  
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT SYS_REFCURSOR
  
  
        ----------------------------------------------------------
        操作人   版本号         时间                     操作
        刘浪浪   1.0.1     2014/11/18                  新增
        刘浪浪   1.0.2     2014/11/22                  修改逻辑
        刘浪浪   1.0.3     2014/12/04                  增加总数量已经已完成数量的统计
  
  -------------------------------------------------------------------------------------------------*/
  V_SQL1 VARCHAR2(4000); --完成数量
  V_SQL2 VARCHAR2(4000); --总数量
  V_SQL  VARCHAR2(4000);
  V_RQ   VARCHAR2(50);
  V_KSRQ NUMBER(8);
  V_JSRQ NUMBER(8);
  V_NZ NUMBER;

BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';
  V_RQ   := I_qury_date;

  IF I_query_type IS NULL THEN
    O_CODE := -1;
    O_NOTE := '查询类型不能为空!';
    RETURN;
  END IF;

  IF I_data_interval IS NULL OR I_qury_date IS NULL THEN
    O_CODE := -1;
    O_NOTE := '时间区间或日期不能为空!';
    RETURN;
  END IF;

  V_SQL1 := 'SELECT A.ZYCD,COUNT(ZYCD) SL FROM TPIF_CPYYRW A WHERE 1=1';

  IF I_data_interval = 1 THEN
    --当日
    V_SQL1 := V_SQL1 || ' AND TO_NUMBER(TO_CHAR(A.YJZXKSSJ,''YYYYMMDD''))=' ||
              TO_NUMBER(REPLACE(V_RQ, '/', ''));
  ELSIF I_data_interval = 2 THEN
    --本周
    select nz into V_NZ from livebos.txtjyr a where a.zrr = V_RQ ;
    
    select MIN(ZRR),MAX(ZRR) into V_KSRQ,V_JSRQ from livebos.txtjyr WHERE NZ=V_NZ ; --时间区间开始日期

  
    V_SQL1 := V_SQL1 ||
              ' AND (TO_NUMBER(TO_CHAR(A.YJZXKSSJ,''YYYYMMDD'')) BETWEEN ' ||
              V_KSRQ || ' AND ' || V_JSRQ || ')';
  ELSE
    --本月
    V_KSRQ := TO_NUMBER(REPLACE(V_RQ, '/', '') || '01');
    V_JSRQ := TO_NUMBER(REPLACE(V_RQ, '/', '') || '31');
    V_SQL1 := V_SQL1 ||
              ' AND (TO_NUMBER(TO_CHAR(A.YJZXKSSJ,''YYYYMMDD'')) BETWEEN ' ||
              V_KSRQ || ' AND ' || V_JSRQ || ')';
  END IF;

  IF I_query_type = 1 THEN
    --任务执行人查询
  
    IF I_USERID IS NULL THEN
      O_CODE := -1;
      O_NOTE := '执行人查询时,执行人ID不能为空!';
      RETURN;
    END IF;
  
    V_SQL1 := V_SQL1 || ' AND INSTR('';''||A.ZXRY || '';'','';' || I_USERID ||
              ';'')>0'; --筛选执行人信息
  END IF;

  V_SQL2 := V_SQL1 || ' AND A.ZXZT=1';

  V_SQL1 := V_SQL1 || ' GROUP BY A.ZYCD';
  V_SQL2 := V_SQL2 || ' GROUP BY A.ZYCD';

  V_SQL := 'SELECT C.ZYCD  as important_level,
                     C.NOTE important_level_desc,
                     NVL(B.SL,0) already_finish_task,
                     NVL(A.SL,0) total_task,
                     TO_CHAR(DECODE(A.SL,0,0,NVL(B.SL/A.SL*100,0)),''FM990.00'') progress
                     FROM ' || '(' || V_SQL1 ||
           ') A,
                          (' || V_SQL2 ||
           ') B,
                          (SELECT IBM ZYCD,NOTE FROM livebos.TXTDM WHERE FLDM=''PIF_ZYCD'') C
                     WHERE C.ZYCD=B.ZYCD(+)
                     AND   C.ZYCD=A.ZYCD(+)
                     ORDER BY C.ZYCD';

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END PCX_PIF_YYGL_YYRWGKTJ_ZYCD;
/

