create PROCEDURE PRO_SJQX_SSCC(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2 --返回消息
                                          ) IS

  /******************************************************************
      所属用户：INFO
      功能说明：实时持仓表 DSC_STAT.TPIF_SSCC 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-09-16   1.0       WWH            创建
  
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO PIF.TPIF_SSCC M
  USING (SELECT E.ID,
                A.POSITION_STR,
                (SELECT NAME FROM TPIF_JRCPFL WHERE ID = B.JRCPFL) CL,
                (SELECT JGJC FROM TPIF_JGDM WHERE ID = B.CPGLRID) GLR,
                B.TZFZR,
                A.PROD_CODE,
                B.CPMC,
                B.CPJC,
                (SELECT NVL(PIF.FUNC_PIF_GET_OPENDAYRANGE(D.CPID, (SELECT MIN(TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')))
                                                              FROM PIF.TPIF_JYRL_HB
                                                             WHERE CPID =
                                                                   D.CPID
                                                               AND TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')) = D.RQ
                                                               AND YWLX = 6), 6), PIF.FUNC_PIF_GET_OPENDAYRANGE(D.CPID, (SELECT MIN(TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')))
                                                               FROM PIF.TPIF_JYRL_HB
                                                              WHERE CPID =
                                                                    D.CPID
                                                                AND TO_NUMBER(TO_CHAR(RQ, 'yyyymmdd')) = D.RQ
                                                                AND YWLX = 7), 7)) AS RECENTLYREDEEMOPEN
                   FROM (SELECT *
                           FROM (SELECT B.CPID,
                                        A.YWLX,
                                        TO_CHAR(A.RQ, 'yyyymmdd') RQ,
                                        ROW_NUMBER() OVER(PARTITION BY A.CPID ORDER BY A.YWLX ASC, A.RQ DESC NULLS LAST) AS RNN
                                   FROM PIF.TPIF_JYRL_GZJL B, PIF.TPIF_JYRL A
                                  WHERE INSTR(';' || A.GZJL || ';', ';' || B.ID || ';') > 0
                                    AND A.YWLX IN (6, 7)
                                    AND TO_CHAR(A.RQ, 'yyyymmdd') <=
                                        TO_CHAR(SYSDATE, 'yyyymmdd'))
                          WHERE RNN = 1) D
                  WHERE D.CPID = B.CPID) XSRQ,
                B.CPJZ,
                A.CURRENT_AMOUNT
           FROM SRC_PIF.SECUMREAL A
           LEFT JOIN PIF.TPIF_CPDM B
             ON A.PROD_CODE = B.CPDM
           LEFT JOIN (SELECT E.ID, N.NEW_BRANCH_ID, N.BRANCH_ID
                       FROM SRC_PIF.DIM_BRANCH_INFO N
                       LEFT JOIN LIVEBOS.LBORGANIZATION E
                         ON N.NEW_BRANCH_ID = E.BRANCH_ID) E
             ON A.BRANCH_NO = E.BRANCH_ID
          WHERE B.CPNBZT = 8) N
  ON (M.ID = N.POSITION_STR)
  WHEN MATCHED THEN
    UPDATE
       SET M.YYB  = N.ID,
           M.CL   = N.CL,
           M.GLR  = N.GLR,
           M.TZJL = N.TZFZR,
           M.CPDM = N.PROD_CODE,
           M.CPMC = N.CPMC,
           M.CPJC = N.CPJC,
           M.XSQJ = N.XSRQ,
           M.CPJZ = N.CPJZ,
           M.BYFE = N.CURRENT_AMOUNT
  WHEN NOT MATCHED THEN
    INSERT
      (ID, YYB, CL, GLR, TZJL, CPDM, CPMC, CPJC, XSQJ, CPJZ, BYFE)
    VALUES
      (N.POSITION_STR,
       N.ID,
       N.CL,
       N.GLR,
       N.TZFZR,
       N.PROD_CODE,
       N.CPMC,
       N.CPJC,
       N.XSRQ,
       N.CPJZ,
       N.CURRENT_AMOUNT);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'DSC_STAT.TPIF_SSCC  表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'DSC_STAT.TPIF_SSCC  表清洗,未知错误'
                ELSE
                 'DSC_STAT.TPIF_SSCC ,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

