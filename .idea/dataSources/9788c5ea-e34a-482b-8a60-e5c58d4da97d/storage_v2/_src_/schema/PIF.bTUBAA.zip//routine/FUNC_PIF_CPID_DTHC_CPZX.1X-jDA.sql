create FUNCTION FUNC_PIF_CPID_DTHC_CPZX(I_KSRQ IN NUMBER,
                                                   I_JSRQ IN NUMBER,
                                                   I_LX   IN NUMBER,
                                                   I_DM   IN VARCHAR2)
  RETURN NUMBER AS

  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算产品或指标的动态回撤
  
    I_KSRQ：开始日期
    I_JSRQ:计算这一天的回撤，从开始日期（闭区间）到结束日期（开区间）这个区间的最大值
                            与 结束日期这一天的值进行计算
  
    I_LX： 1产品、2指标
    I_DM： 类型为1时表示产品代码，为2时表示指标代码  '000300.SH'
  
    返回I_JSRQ这一天的回撤
  ----------------------------------------------------------------------------------
        操作人   版本号       时间                      操作
        高昆     1.0.0      2021-7-19                  新增
  --------------------------------------------------------------------------------*/
  V_ZDJZ NUMBER; ---最大净值
  V_DQJZ NUMBER; --当前净值

  V_ZDSPJ NUMBER; --最大收盘价
  V_DQSPJ NUMBER; --当前收盘价

  V_SQL VARCHAR2(1000);
  V_HC  NUMBER; ---回撤
BEGIN
  IF I_KSRQ = I_JSRQ THEN
    --如果开始日期=结束日期，则回撤为0
    V_HC := 0;
  ELSE
    IF I_LX = 1 THEN
      --产品
    
      BEGIN
        --取该天的累计净值
        SELECT LJJZ
          INTO V_DQJZ
          FROM TPIF_CPJZXX_CPZX
         WHERE CPDM = I_DM
           AND JZRQ = I_JSRQ;
      EXCEPTION
        WHEN OTHERS THEN
          V_DQJZ := 0;
      END;
    
      BEGIN
        --取该区间内的最大累计净值
        SELECT MAX(LJJZ)
          INTO V_ZDJZ
          FROM TPIF_CPJZXX_CPZX
         WHERE CPDM = I_DM
           AND JZRQ >= I_KSRQ
           AND JZRQ < I_JSRQ;
      EXCEPTION
        WHEN OTHERS THEN
          V_ZDJZ := 0;
      END;
    
      --计算回撤
      IF V_DQJZ >= V_ZDJZ THEN
        V_HC := 0;
      ELSE
        SELECT (CASE
                 WHEN V_DQJZ = 0 THEN
                  NULL
                 WHEN V_ZDJZ = 0 THEN
                  NULL
                 ELSE
                  ROUND(1-V_DQJZ / V_ZDJZ, 6)
               END)
          INTO V_HC
          FROM DUAL;
      END IF;
    
    ELSIF I_LX = 2 THEN
      --指数
    
      BEGIN
        --取该天的今收盘价
        SELECT JSPJ
          INTO V_DQSPJ
          FROM DSC_STAT.TPIF_STAT_ZSHQ
         WHERE ZSDM = I_DM
           AND SJRQ = I_JSRQ;
      EXCEPTION
        WHEN OTHERS THEN
          V_DQSPJ := 0;
      END;
    
      BEGIN
        --取该区间的最大收盘价
        SELECT MAX(JSPJ)
          INTO V_ZDSPJ
          FROM DSC_STAT.TPIF_STAT_ZSHQ
         WHERE ZSDM = I_DM
           AND SJRQ >= I_KSRQ
           AND SJRQ < I_JSRQ;
      EXCEPTION
        WHEN OTHERS THEN
          V_ZDSPJ := 0;
      END;
    
      --计算回撤
      IF V_DQSPJ >= V_ZDSPJ THEN
        V_HC := 0;
      ELSE
        SELECT (CASE
                 WHEN V_DQSPJ = 0 THEN
                  NULL
                 WHEN V_ZDSPJ = 0 THEN
                  NULL
                 ELSE
                  ROUND(1 - V_DQSPJ / V_ZDSPJ, 6)
               END)
          INTO V_HC
          FROM DUAL;
      END IF;
    
    END IF;
  
  END IF;

  RETURN V_HC;
EXCEPTION
  WHEN OTHERS THEN
    V_SQL := SQLERRM;
    RETURN - 999;
END;
/

