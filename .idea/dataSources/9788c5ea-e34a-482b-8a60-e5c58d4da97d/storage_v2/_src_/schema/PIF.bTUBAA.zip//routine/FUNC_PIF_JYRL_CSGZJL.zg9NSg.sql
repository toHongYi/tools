create FUNCTION FUNC_PIF_JYRL_CSGZJL(I_YXJYR IN NUMBER, --运行交易日
                                                    I_CPID  IN NUMBER --产品ID
                                                    ) RETURN NUMBER AS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：获取需重新生成的规则记录

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-12-27     V1.0      王大一             创建
    *********************************************************************************************************************/

    V_GZJL NUMBER; --返回规则记录

BEGIN
    ------------------------------处理开放日、业绩报酬计提日规则的顺序问题-------------------------------
    --处理开放日
    IF I_YXJYR = 2 OR I_YXJYR = 7 THEN
        BEGIN
            SELECT ID
              INTO V_GZJL
              FROM TPIF_JYRL_GZJL T
             WHERE T.CPID = I_CPID
               AND T.SHZT = 2
               AND T.DDGZ = (SELECT ID FROM TPIF_JYRL_DDGZ WHERE BH = 'R54');
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                V_GZJL := 0;
        END;
        --处理业绩报酬计提日
    ELSIF I_YXJYR = 12 THEN
        BEGIN
            SELECT ID
              INTO V_GZJL
              FROM TPIF_JYRL_GZJL T
             WHERE T.CPID = I_CPID
               AND T.SHZT = 2
               AND T.DDGZ = (SELECT ID FROM TPIF_JYRL_DDGZ WHERE BH = 'R53');
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                V_GZJL := 0;
        END;
    ELSE
        V_GZJL := 0;
    END IF;
    RETURN V_GZJL;
END FUNC_PIF_JYRL_CSGZJL;
/

