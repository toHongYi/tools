create PROCEDURE PRO_PIF_YQDY(O_CODE   OUT NUMBER, --返回值
                                         O_NOTE   OUT VARCHAR2, --返回消息

                                         I_LX      IN NUMBER,   --1:机构批量关注 2:取消机构关注  3:产品关注  4 取消产品关注
                                         I_IDS     IN VARCHAR2, --机构id串，产品id串
                                         I_USER    IN NUMBER,   --登录用户
                                         I_CPID    IN NUMBER DEFAULT NULL
                                         ) IS

  /******************************************************************
      项目名称：产品中心--舆情订阅
      所属用户：PIF
      功能说明：产品中心--舆情订阅后台处理逻辑
      语法信息：
           输入参数：   。。。。
           输出参数：   O_CODE    返回值
                       O_NOTE    返回消息


      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-07     1.0.0    WUJINFENG                创建
  ***********************************************************************/
  V_COUNT  INTEGER; --计数变量

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --1:机构批量关注
  IF I_LX = 1 THEN

     SELECT COUNT(*) INTO V_COUNT FROM TPIF_YQGZR WHERE ID = I_USER ;
     IF V_COUNT = 0  THEN
         INSERT INTO TPIF_YQGZR (id, yhmc, bm, lrr, lrsj)
         SELECT A.ID,
                A.NAME,
                A.ORGID,
                A.ID,
                SYSDATE
         FROM LIVEBOS.TUSER A
         WHERE A.ID =  I_USER;
     END IF;

     --进入循环，遍历ID串的值
     FOR CUR_ID IN (SELECT COLUMN_VALUE AS DXID
                           FROM TABLE(SPLIT(replace(replace(replace(I_IDS ,'[',''),']',''),' ',''), ','))) LOOP

            SELECT COUNT(*)
              INTO V_COUNT
              FROM PIF.TPIF_YQGZR_JG A
             WHERE A.JGDM = to_number(CUR_ID.DXID)
               AND A.YQGZR = I_USER;


            IF V_COUNT = 0 THEN

               INSERT INTO PIF.TPIF_YQGZR_JG( ID,
                                              YQGZR,
                                              JGDM,
                                              JGMC,
                                              JGJC,
                                              CLRQ,
                                              FRDB
                                              )
                SELECT LIVEBOS.FUNC_NEXTID('TPIF_YQGZR_JG'),
                       I_USER,
                       A.ID,
                       A.JGMC,
                       A.JGJC,
                       A.CLRQ,
                       A.FRDB
                 FROM TPIF_JGDM A
                WHERE A.ID =  CUR_ID.DXID ;

            END IF;

     END LOOP;
     O_NOTE := '加关注成功';

  END IF;
  
    --2:取消机构关注
  IF I_LX = 2 THEN
    
  
    DELETE FROM PIF.TPIF_YQGZR_JG A WHERE A.JGDM = I_IDS AND A.YQGZR = I_USER;
    
    O_NOTE := '取消关注成功';
  END IF;

  --3:产品关注 
  IF I_LX = 3 THEN

     SELECT COUNT(*) INTO V_COUNT FROM TPIF_YQGZR WHERE ID = I_USER ;
     IF V_COUNT = 0  THEN
         INSERT INTO TPIF_YQGZR (id, yhmc, bm, lrr, lrsj)
         SELECT A.ID,
                A.NAME,
                A.ORGID,
                A.ID,
                SYSDATE
         FROM LIVEBOS.TUSER A
         WHERE A.ID =  I_USER;
     END IF;

     --进入循环，遍历ID串的值
   
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_YQGZR_CP A
       WHERE A.CPID = NVL(I_CPID ,to_number(I_IDS))
         AND A.YQGZR = I_USER;


      IF V_COUNT = 0 THEN

         INSERT INTO PIF.TPIF_YQGZR_CP( id, 
                                        yqgzr, 
                                        cpid, 
                                        babh, 
                                        jjjc, 
                                        jjqc, 
                                        jjglr

                                        )
          SELECT LIVEBOS.FUNC_NEXTID('TPIF_YQGZR_CP'),
                 I_USER,
                 A.ID,
                 A.REG_CODE,
                 A.FUND_NAME,
                 A.FUND_FULL_NAME,
                 A.FUND_MANAGER
           FROM TPIF_SCSMJJXX A
          WHERE A.ID =  NVL(I_CPID ,to_number(I_IDS)) ;

      END IF;

     O_NOTE := '加关注成功';

  END IF;
  
    --4:取消产品关注
  IF I_LX = 4 THEN
    
  
    DELETE FROM PIF.TPIF_YQGZR_cp A WHERE A.CPID = NVL(I_CPID ,to_number(I_IDS)) AND A.YQGZR = I_USER;
    
    O_NOTE := '取消关注成功';
  END IF;
  
 
  COMMIT;
  O_CODE := 199;
  


EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK ;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

