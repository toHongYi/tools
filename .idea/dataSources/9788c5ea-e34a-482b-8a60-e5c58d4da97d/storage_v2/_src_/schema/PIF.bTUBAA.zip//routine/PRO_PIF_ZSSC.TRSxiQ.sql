create PROCEDURE PRO_PIF_ZSSC(O_CODE  OUT NUMBER,
                                         O_NOTE  OUT VARCHAR2,
                                         I_TABLE IN VARCHAR2) AS
  /*--------------------------------------------------------------------------------------------

  项目名称：表注释生成

         功能说明：
             参数说明：
                  入参：
                        I_TABLE IN VARCHAR2   --表名


                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2

        ----------------------------------------------------------
        操作人   版本号     时间                         操作
      SHAOJIANJIE  1.0.1     2016/10/18                新增
      杨啸天       1.0.2     2021/01/13                修改：添加了针对其他用户，可输入INFO.TPIF_CPDM进行注释生成
  -------------------------------------------------------------------------------------------------*/
  V_SQL   VARCHAR2(4000);
  V_TABLE VARCHAR2(30);
  V_OWNER VARCHAR2(30);

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  --数据初始化
  SELECT SUBSTR(UPPER(I_TABLE), INSTR(UPPER(I_TABLE), '.') + 1),
         SUBSTR(UPPER(I_TABLE), 0, INSTR(UPPER(I_TABLE), '.') - 1)
    INTO V_TABLE, V_OWNER
    FROM DUAL;

  DECLARE
    --类型定义
    CURSOR C_TAB IS
      SELECT T.TABLE_NAME,
             T.OWNER,
             T.TABLE_DESCRIBE,
             T.COLUMN_NAME,
             T.DESCRIBE
        FROM (SELECT A.TABLE_NAME,
                     A.OWNER,
                     (SELECT DESCRIBE
                        FROM LIVEBOS.TTABLE M
                       WHERE UPPER(M.TABLENAME) = A.TABLE_NAME) TABLE_DESCRIBE,
                     A.COLUMN_NAME,
                     B.DESCRIBE
                FROM ALL_TAB_COLS A
                LEFT JOIN LIVEBOS.TTABLEOBJ B
                  ON (A.TABLE_NAME = UPPER(B.TABLENAME) AND
                     A.COLUMN_NAME = UPPER(B.NAME))
               WHERE A.TABLE_NAME = UPPER(V_TABLE)
                 AND (V_OWNER IS NULL OR V_OWNER = A.OWNER)
               ORDER BY A.TABLE_NAME, A.COLUMN_ID) T
       WHERE EXISTS (SELECT 1
                FROM LIVEBOS.TTABLE K
               WHERE UPPER(K.TABLENAME) = T.TABLE_NAME);
    --定义一个游标变量
    C_ROW C_TAB%ROWTYPE;
  BEGIN
    OPEN C_TAB;
    LOOP
      --提取一行数据到C_ROW
      FETCH C_TAB
        INTO C_ROW;
      EXIT WHEN C_TAB%NOTFOUND;
      V_SQL := 'COMMENT ON column ' || C_ROW.OWNER || '.' ||
               C_ROW.TABLE_NAME || '.' || C_ROW.COLUMN_NAME || ' IS ' || '''' ||
               C_ROW.DESCRIBE || '''';
      DBMS_OUTPUT.PUT_LINE(V_SQL);
      EXECUTE IMMEDIATE V_SQL;
    END LOOP;
    CLOSE C_TAB;
  END;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
END;

/

