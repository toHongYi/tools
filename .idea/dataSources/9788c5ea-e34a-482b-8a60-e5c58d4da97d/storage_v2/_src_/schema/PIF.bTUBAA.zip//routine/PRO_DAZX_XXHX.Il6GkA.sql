create PROCEDURE PRO_DAZX_XXHX  (O_CODE                    OUT INTEGER,       --返回值
                                            O_NOTE                    OUT VARCHAR2,      --返回信息
                                            I_LCBDID                  IN VARCHAR2,       ---流程ID
                                            I_LCBD                    IN VARCHAR2,       ---流程对象
                                            I_FJZD                    IN VARCHAR2,       ---附件字段
                                            I_USER                    IN INTEGER,           ---用户ID
                                            I_SCSJ                    IN VARCHAR2,      ---上传时间
                                            I_WJMC                    IN VARCHAR2,      ----文件名称
                                            I_WJID                    IN INTEGER       ---返回文件ID
                                                        
                                            ) AS
    /******************************************************************************
     项目名称：产品中心
     所属用户：pif
     概要说明：档案中心-档案中心返回信息回写

      修订记录：
      修订日期           版本号       修订人             修改内容简要说明
      2021.03.05        V1.0.0        李骐                海通迁移过来
      
    ******************************************************************************/
    V_LCBD   VARCHAR2(100);
    V_CNT     VARCHAR2(100);
    V_SQL     VARCHAR2(100);
BEGIN
    DBMS_OUTPUT.ENABLE (buffer_size=>null);
    --init
    O_CODE         := 1;
    O_NOTE         := '成功!';
    --check
    --输入参数判断
  IF (I_LCBDID IS NULL) OR (I_LCBD IS NULL) OR (I_USER IS NULL) OR (I_SCSJ IS NULL) OR (I_FJZD IS NULL) OR (I_WJID IS NULL) OR (I_WJMC IS NULL)
     THEN
    O_NOTE := '传入参数错误!';
    RETURN;
  END IF;

  --工作流表单判断
  SELECT LOWER(SUBSTR(I_LCBD, 1, 2)) || UPPER(SUBSTR(I_LCBD, 3))
    INTO V_LCBD
    FROM DUAL;
  SELECT COUNT(1) INTO V_CNT FROM LIVEBOS.tTABLE WHERE TABLENAME = V_LCBD;
  IF V_CNT = 0 THEN
    O_NOTE := '流程表单[' || V_LCBD || ']不存在!';
    RETURN;
  END IF;

  --工作流记录判断
  V_SQL := 'SELECT COUNT(1) FROM ' || V_LCBD || ' WHERE ID = ' || I_LCBDID;
  EXECUTE IMMEDIATE V_SQL
    INTO V_CNT;
  IF V_CNT = 0 THEN
    O_NOTE := '流程表单记录[' || I_LCBDID || ']不存在!';
    RETURN;
  END IF;

  INSERT INTO pif.TPIF_DAZX_WJXX
    (ID,
     DAZXWJID,
     WJMC,
     SSDX,
     SSDXID,
     FJZD,
     SCSJ,
     SCZ
     
     )
    VALUES(LIVEBOS.FUNC_NEXTID('TPIF_DAZX_WJXX'),
           I_WJID,
           I_WJMC,
           I_LCBD,
           I_LCBDID,
           I_FJZD,
           I_SCSJ,
           I_USER
           
           );
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_DAZX_XXHX;
/

