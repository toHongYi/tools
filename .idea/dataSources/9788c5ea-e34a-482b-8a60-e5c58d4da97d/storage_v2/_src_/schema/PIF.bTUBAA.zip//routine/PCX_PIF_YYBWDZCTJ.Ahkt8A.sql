create PROCEDURE PCX_PIF_YYBWDZCTJ(O_RESULT OUT SYS_REFCURSOR,
                                              I_LX IN NUMBER,
                                              I_RQ IN NUMBER) AS

/* -----------------------------------------------------------------------
   项目：财通产品中心
   过程名称 :  PCX_PIF_YYBWDZCTJ
   功能简述：  营业部维度资产统计

   输入： I_LX IN NUMBER          1-只看分公司，0-下到营业部
          I_RQ IN NUMBER         日期

   输出：O_RESULT OUT SYS_REFCURSOR


   ------------------------------------------------------------------------
   操作人           操作时间       版本            操作
   gaokun           20201103       1.0           新增
  -----------------------------------------------------------------------*/



V_NOTE VARCHAR2(1000);

BEGIN
  IF I_LX = 1  THEN
    OPEN O_RESULT FOR
    SELECT
           (SELECT NAME FROM LIVEBOS.lbOrganization WHERE ID=A.FGS) V_FGS,
           SUM(NLJCLGM) SUM_NLJCLGM,
           SUM(NLJCLGM)-SUM(TQNLJCLGM) TQNLJCLGMCZ,
           ((SUM(NLJCLGM)-SUM(TQNLJCLGM))/SUM(TQNLJCLGM))*100  NLJCLGMTB,
           ((SUM(NLJCLGM)-SUM(SYNLJCLGM))/SUM(SYNLJCLGM))*100 NLJCLGMHB,
           AVG(NRJZC) AVG_NRJZC,
           AVG(DYRJZC) AVG_DYRJZC,
           ((AVG(DYRJZC)-AVG(SYRJZC))/AVG(SYRJZC))*100 YRJZCHB
    FROM DSC_STAT.TPIF_STAT_CP_XSGM_M  A
    WHERE RQ = I_RQ
    GROUP BY A.FGS;
  ELSE
    OPEN O_RESULT FOR
    SELECT
           (SELECT NAME FROM LIVEBOS.lbOrganization WHERE ID=A.FGS) V_FGS,
           (SELECT NAME FROM LIVEBOS.lbOrganization WHERE ID=A.YYB) V_YYB,
           SUM(NLJCLGM) SUM_NLJCLGM,
           SUM(NLJCLGM)-SUM(TQNLJCLGM) TQNLJCLGMCZ,
           ((SUM(NLJCLGM)-SUM(TQNLJCLGM))/SUM(TQNLJCLGM))*100 NLJCLGMTB,
           ((SUM(NLJCLGM)-SUM(SYNLJCLGM))/SUM(SYNLJCLGM))*100 NLJCLGMHB,
           AVG(NRJZC) AVG_NRJZC,
           AVG(DYRJZC) AVG_DYRJZC,
           ((AVG(DYRJZC)-AVG(SYRJZC))/AVG(SYRJZC))*100 YRJZCHB
    FROM DSC_STAT.TPIF_STAT_CP_XSGM_M  A
    WHERE RQ = I_RQ
    GROUP BY A.YYB,A.FGS
    ORDER BY V_FGS;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;

END;
/

