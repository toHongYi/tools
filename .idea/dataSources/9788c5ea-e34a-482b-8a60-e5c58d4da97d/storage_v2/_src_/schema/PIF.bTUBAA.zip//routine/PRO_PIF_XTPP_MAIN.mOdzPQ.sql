create PROCEDURE     PRO_PIF_XTPP_MAIN(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              I_RQ     IN NUMBER DEFAULT NULL, --日期
                                              I_N_REDO IN INT DEFAULT 0) AS
  /******************************************************************
  项目名称：PIF  产品中心-跑批调度
  所属用户：PIF
  概要说明：系统调度主过程
          I_RQ    --日期
  语法信息：
       输出参数：
          O_CODE     成功返回 成功，失败返回-1
          O_NOTE     成功返回操作成功，失败返回错误信息

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
  *********************************************************************************************************************/
  V_RQ   NUMBER(8) DEFAULT I_RQ; --当前日期
  V_KSRQ DATE;

  V_CODE NUMBER;
  V_NOTE VARCHAR2(2000);
BEGIN

  O_CODE := 1;
  O_NOTE := '成功';
  --1.***************************入参校验 ***************************
  --当前变量赋值

  V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
  /*
  --２.********************产品标签每日更新跑批*************************
  V_KSRQ := SYSDATE ;
  PIF.PRO_PIF_JHSX(O_CODE, O_NOTE,0,'127.0.0.1',1,'');
  --记录日志
   PRO_SJQX_LOG('PRO_PIF_JHSX','产品标签每日更新',V_KSRQ,SYSDATE,O_CODE,O_NOTE) ;*/

  --3.********************TUSER 用户表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_TUSER(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_TUSER',
               'TUSER表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --4.********************LBORGANIZATION 组织机构表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_LBORGANIZATION(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_LBORGANIZATION',
               'LBORGANIZATION表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --5.**************TPIF_JGDM 机构代码表清洗，从朝阳永续取数据******************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_JGDM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_JGDM',
               'TPIF_JGDM表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

/*  --6.********************私募运营 TPIF_SMCP表 数据新增*******************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_SMCP(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMCP',
               'TPIF_SMCP表数据新增',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/


  --7.********************产品中心 TPIF_CPDM 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_CPDM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_CPDM',
               'TPIF_CPDM表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --8.********************产品中心 TPIF_CPJZ 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_CPJZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPJZ',
               'TPIF_CPJZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --.********************私募经纪户 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_SMJJHWH(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMJJHWH',
               'TPIF_SMJJHWH表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --.********************私募代销产品 表清洗*************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_SMDXCPWH(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMDXCPWH',
               'TPIF_SMDXCPWH表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);


  --9.********************私募运营 TPIF_CPJZ_SMYY 表清洗***********************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_CPJZ_SMYY(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPJZ_SMYY',
               'TPIF_CPJZ_SMYY表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --10.*****************重点销售产品首发库产品从柜台清洗************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_ZDXS_XFCP(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_ZDXS_XFCP',
               'TPIF_ZDXS_CP相关表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --11.********************市场私募基金信息-TPIF_SCSMJJXX ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_SCSMJJXX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SCSMJJXX',
               'TPIF_SCSMJJXX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --12.********************私募投资经理 TPIF_SMTZJL 表清洗 *************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_SMTZJL(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMTZJL',
               'TPIF_SMTZJL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  /*  --10.********************TPIF_CPDM_GL_XSFL 销售费率表清洗**************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_CPDM_GL_XSFL(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPDM_GL_XSFL',
               'TPIF_CPDM_GL_XSFL表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --13.*************TPIF_CPDM_N_SMJJ 私募基金扩展属性表清洗**********
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPDM_N_SMJJ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPDM_N_SMJJ',
               'TPIF_CPDM_N_SMJJ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --14.********************DSC_STAT.TPIF_STAT_ZSHQ 指数行情表数据加工************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_ZSHQ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_ZSHQ',
               'DSC_STAT.TPIF_STAT_ZSHQ 指数行情表数据加工',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --.**************INFO.T_FUND_ADJUSTED_PERFORMANCE 私募基金业绩表现*********
  V_KSRQ := SYSDATE;
  PRO_SJQX_SMJJYJBX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMJJYJBX',
               'INFO.T_FUND_ADJUSTED_PERFORMANCE 私募基金业绩表现',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --.**************INFO.T_FUND_ADJUSTED_RISK 私募基金自适应风险指标 *********
  V_KSRQ := SYSDATE;
  PRO_SJQX_SMJJFXZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMJJFXZB',
               'INFO.T_FUND_ADJUSTED_RISK 私募基金业绩表现',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  /*  --13.********************产品业绩表现 TPIF_STAT_CP_YJBX ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_CP_YJBXL(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_CP_YJBXL',
               'TPIF_STAT_CP_YJBX表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  /*  --14.********************产品风险指标 TPIF_STAT_CP_FXZB ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_CP_FXZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_CP_FXZB',
               'TPIF_STAT_CP_FXZB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  /*  --15.********************基金重仓股票-TPIF_CPDM_GL_JJZCGP ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPDM_GL_JJZCGP(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPDM_GL_JJZCGP',
               'TPIF_CPDM_GL_JJZCGP表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  /*  --16.********************基金行业投资-TPIF_CPDM_GL_JJHYTZ ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPDM_GL_JJHYTZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPDM_GL_JJHYTZ',
               'TPIF_CPDM_GL_JJHYTZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  /*  --17.********************基金资产配置-TPIF_CPDM_GL_JJZCPZ ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPDM_GL_JJZCPZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPDM_GL_JJZCPZ',
               'TPIF_CPDM_GL_JJZCPZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --18.********************我关注的舆情 TPIF_WGZDYQ 历史数据清除 ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_WGZDYQ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('TPIF_WGZDYQ',
               'TPIF_WGZDYQ 历史数据清除',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  /*  --20.********************产品净值分析指标计算-DSC_STAT.TPIF_STAT_CP_************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPJZFXZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPJZFXZB',
               'DSC_STAT.TPIF_STAT_CP_*表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --21.********************指数增强代表产品超额中间表-计算-DSC_STAT.TPIF_STAT_BB_DBCPCETJ************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CP_BB_DBCPCETJ(O_CODE, O_NOTE, NULL);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CP_BB_DBCPCETJ',
               'DSC_STAT.TPIF_STAT_BB_DBCPCETJ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

/*  --22.********************代销产品代码表清洗-TPIF_DXCPDMB************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_DXCPDM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_DXCPDM',
               'TPIF_DXCPDMB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/
-- 20210825liliang
/*  --23.********************代销产品净值清洗-TPIF_DXCPJZ************************
  V_KSRQ := SYSDATE;
  PIF.PRO_SJQX_DXCPJZ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_DXCPJZ',
               'TPIF_DXCPJZ表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --24.********************代销产品净值分析指标计算-DSC_STAT.TPIF_STAT_DXCP_************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_DXCPJZFXZB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_DXCPJZFXZB',
               'DSC_STAT.TPIF_STAT_DXCP_*表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  /*    --25.********************-PIF.TPIF_ZB_CP_FXZB************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CP_FXZB( O_CODE, O_NOTE) ;
   --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CP_FXZB',
               'PIF.TPIF_ZB_CP_FXZB表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --26.********************-DSC_STAT.TPIF_STAT_YYBSR 营业部收入************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_YYBSRTJ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_YYBSRTJ',
               'DSC_STAT.TPIF_STAT_YYBSR表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --27.********************-DSC_STAT.TPIF_STAT_CP_XSGM 产品销售规模明细************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_CPXSGM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_CPXSGM',
               'DSC_STAT.TPIF_STAT_CP_XSGM表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --28.********************-DSC_STAT.TPIF_STAT_ZC 资产统计************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_ZC(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_ZC',
               'DSC_STAT.TPIF_STAT_ZC表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  /*     --29.********************-PIF_DXCPJSQZF_CT 私募代销产品-较上期涨幅-计算************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_SMDXCPDM_JSQZF_CT( O_CODE, O_NOTE);
   --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMDXCPDM_JSQZF_CT',
               'PIF_DXCPJSQZF_CT表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE); */

  --30.********************-DSC_STAT.TPIF_STAT_CPDXYB相关表 产品代销月表************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_STAT_CPDXYB(O_CODE, O_NOTE, NULL);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_STAT_CPDXYB',
               'DSC_STAT.TPIF_STAT_CPDXYB相关表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --31.********************-PIF.TPIF_CPZXCPXSCS 相关表 产品中心产品销售参数************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_TPIF_CPZXCPXSCS(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_TPIF_CPZXCPXSCS',
               'PIF.TPIF_CPZXCPXSCS相关表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --32.********************-PIF.TPIF_CNCPDMB 相关表 产品中心场内产品代码表************************
  V_KSRQ := SYSDATE;
  PRO_SJQX_TPIF_CNCPDMB(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_TPIF_CNCPDMB',
               'PIF.TPIF_CNCPDMB相关表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --********************产品中心 净值相关指标 计算************************
  V_KSRQ := SYSDATE;
  --开始日期和结束日期都传空，计算上个交易日
  FOR CUR_CP IN (SELECT DISTINCT CPDM FROM TPIF_CPZXJZ) LOOP
    PRO_SJQX_CPJZFXZB_CPZX(V_CODE, V_NOTE, NULL, NULL, CUR_CP.CPDM);
  END LOOP;
  PRO_SJQX_LOG('PRO_SJQX_CPJZFXZB_CPZX',
               '净值相关指标表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --********************产品中心净值相关指标 历史表---->  最新表*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_ZXFXZB_CPZX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_ZXFXZB_CPZX',
               '净值相关指标表：历史-->最新',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);


/*  --********************产品中心销售分类更新*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPXSFL_CPZX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPXSFL_CPZX',
               '产品中心销售分类更新',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);*/

  --********************产品中心公募聚源最新净值更新*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_MF_NETVALUE_LATEST(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_MF_NETVALUE_LATEST',
               '产品中心公募聚源最新净值更新',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --********************产品中心 收益凭证产品清洗*************************
  V_KSRQ := SYSDATE;
  PIF.P_TRAN_INCOME_RECEIPTS_CPDM(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('P_TRAN_INCOME_RECEIPTS_CPDM',
               'IC_BASE_INFO表每日清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --********************公募产品分类清洗*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CHINAMUTUALFUNDSECTOR(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CHINAMUTUALFUNDSECTOR',
               '公募产品分类清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --********************产品中心收益类型更新*************
  V_KSRQ := SYSDATE;
  PRO_SJQX_CPSYLX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_CPSYLX',
               '产品中心收益类型更新',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

 --********************产品预约持仓数据 清洗*************
 V_KSRQ := SYSDATE;
  PRO_SJQX_KHCCSJ(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_KHCCSJ',
               '产品预约持仓数据',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

 --********************资金账号数据 清洗*************
 V_KSRQ := SYSDATE;
  PRO_SJQX_ZJZHXX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_ZJZHXX',
               '资金账号数据',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

 --********************产品预约-购买记录 清洗*************
 V_KSRQ := SYSDATE;
  PRO_SJQX_KHGMJL(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_KHGMJL',
               '购买记录清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);


 --********************数据权限清洗************************
 V_KSRQ := SYSDATE;
  PRO_SJQX_SJQX(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SJQX',
               '数据权限清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

 --********************私募机构白名单清洗*************
 V_KSRQ := SYSDATE;
  PRO_SJQX_SMGLRBMD(O_CODE, O_NOTE);
  --记录日志
  PRO_SJQX_LOG('PRO_SJQX_SMGLRBMD',
               '私募机构白名单清洗',
               V_KSRQ,
               SYSDATE,
               O_CODE,
               O_NOTE);

  --提交数据
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      O_CODE := -1;
      O_NOTE := '错误：' || SQLERRM;
      RETURN;
    END;
END PRO_PIF_XTPP_MAIN;
/

