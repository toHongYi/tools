create PROCEDURE PRO_PIF_CPBXMX(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型1|批量新增;2|批量删除;3|清空;4|上移;5|下移
                                               I_BQID IN INTEGER, --操作ID (新增/清空时对应标签ID)
                                               I_IDS  IN VARCHAR2 --操作ID串(1|产品IDS;2|明细IDS;4|明细ID;5|明细ID)
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品标签明细管理
        语法信息：
             输入参数：I_USER IN INTEGER, --操作人
                       I_IP   IN VARCHAR2, --操作IP
                       I_OPER IN INTEGER, --操作类型1|批量新增;2|批量删除;3|清空;4|上移;5|下移
                       I_BQID IN INTEGER, --操作ID (新增/清空时对应标签ID)
                       I_IDS  IN VARCHAR2 --操作ID串(1|产品IDS;2|明细IDS;4|明细ID;5|明细ID)
             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     1.0.1    戴文生              新增
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_QXBZ  INTEGER; --权限标识
    V_ID    INTEGER;
    V_IDS   VARCHAR2(8000);
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSSX  INTEGER; --显示排序
    V_OBJ   tPROD_LABEL_DETAILS%ROWTYPE; --表单记录
    --V_SCBZ    INTEGER; --日志删除标识
    V_CZBM VARCHAR2(200); --操作编码
    V_CZSM VARCHAR2(2000); --日志操作明细 
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM tPROD_LABEL_DETAILS WHERE ID = I_IDS;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  1,
                  '900101',
                  2,
                  '900102',
                  3,
                  '900103',
                  4,
                  '900104',
                  5,
                  '900105',
                  '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER,
                         1,
                         '批量新增',
                         2,
                         '批量删除',
                         3,
                         '清空',
                         4,
                         '上移',
                         5,
                         '下移',
                         '') || ']_BQ:' || I_BQID || '/CP:' ||I_IDS
      INTO V_CZSM
      FROM DUAL;
    --check
    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 1 THEN
        --//:批量新增-----------------------------------------------------------------------
        SELECT NVL(MAX(XSSX),0)+1 INTO V_XSSX FROM tPROD_LABEL_DETAILS WHERE PROD_LABEL = I_BQID ;
        FOR CUR IN (SELECT ID
                      FROM tPROD_BASIC_INFO
                     WHERE INSTR(';' || I_IDS || ';', ';' || ID || ';') > 0 ORDER BY PROD_CODE ASC) LOOP
            SELECT COUNT(1)
              INTO V_COUNT
              FROM tPROD_LABEL_DETAILS
             WHERE PROD_LABEL = I_BQID
               AND CPID = CUR.ID;
            IF V_COUNT = 0 THEN
                LIVEBOS.PNEXTID('tPROD_LABEL_DETAILS', V_ID);
                INSERT INTO tPROD_LABEL_DETAILS
                    (ID, PROD_LABEL, CPID, YSLY, CZSJ, XSSX)
                VALUES
                    (V_ID, I_BQID, CUR.ID, 1, SYSDATE, V_XSSX);
                UPDATE LIVEBOS.TSEQUENCE
                   SET ID =
                       (SELECT NVL(MAX(ID), 0) FROM tPROD_LABEL_DETAILS)
                 WHERE NAME = 'tPROD_LABEL_DETAILS';
                V_XSSX := V_XSSX + 1 ;
            END IF;
        END LOOP;
    END IF;
    IF I_OPER = 2 THEN
        --//:批量删除-----------------------------------------------------------------------
        V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''), ']', ''),
                         ',',
                         ';');
        DELETE tPROD_LABEL_DETAILS WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0;
    END IF;
    IF I_OPER = 3 THEN
        --//:清空-----------------------------------------------------------------------
        DELETE tPROD_LABEL_DETAILS WHERE PROD_LABEL = I_BQID;
    END IF;
    IF I_OPER = 4 THEN
        --//:上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM tPROD_LABEL_DETAILS
         WHERE PROD_LABEL = V_OBJ.PROD_LABEL
           AND ID != I_IDS;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM tPROD_LABEL_DETAILS
         WHERE PROD_LABEL = V_OBJ.PROD_LABEL
           AND ID != I_IDS
           AND XSSX < V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前产品已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM tPROD_LABEL_DETAILS T
         WHERE T.PROD_LABEL = V_OBJ.PROD_LABEL
           AND T.ID != I_IDS
           AND T.XSSX = (SELECT MAX(A.XSSX)
                           FROM tPROD_LABEL_DETAILS A
                          WHERE A.PROD_LABEL = V_OBJ.PROD_LABEL
                            AND A.ID != I_IDS
                            AND A.XSSX < V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE tPROD_LABEL_DETAILS SET XSSX = V_XSSX WHERE ID = I_IDS;
        UPDATE tPROD_LABEL_DETAILS SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 5 THEN
        --//:下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM tPROD_LABEL_DETAILS
         WHERE PROD_LABEL = V_OBJ.PROD_LABEL
           AND ID != I_IDS;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM tPROD_LABEL_DETAILS
         WHERE PROD_LABEL = V_OBJ.PROD_LABEL
           AND ID != I_IDS
           AND XSSX > V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前产品已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM tPROD_LABEL_DETAILS T
         WHERE T.PROD_LABEL = V_OBJ.PROD_LABEL
           AND T.ID != I_IDS
           AND T.XSSX = (SELECT MIN(A.XSSX)
                           FROM tPROD_LABEL_DETAILS A
                          WHERE A.PROD_LABEL = V_OBJ.PROD_LABEL
                            AND A.ID != I_IDS
                            AND A.XSSX > V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE tPROD_LABEL_DETAILS SET XSSX = V_XSSX WHERE ID = I_IDS;
        UPDATE tPROD_LABEL_DETAILS SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, I_BQID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           1,
                           '批量新增',
                           2,
                           '批量删除',
                           3,
                           '清空',
                           4,
                           '上移',
                           5,
                           '下移',
                           '') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPBQMX;
/

