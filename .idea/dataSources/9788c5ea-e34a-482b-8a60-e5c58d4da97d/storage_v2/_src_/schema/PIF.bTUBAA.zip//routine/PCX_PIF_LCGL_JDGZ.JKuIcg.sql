create PROCEDURE PCX_PIF_LCGL_JDGZ(O_CODE    OUT NUMBER,
                                              O_NOTE    OUT VARCHAR2,
                                              O_RESULT  OUT SYS_REFCURSOR,
                                              I_PROD_ID IN NUMBER --产品ID
                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 流程管理-产品进度跟踪查询 (查询具体产品以及产品步骤明细)
  
      语法信息：
           输入参数：   I_PROD_ID    IN NUMBER, --产品ID
                     
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  IF I_PROD_ID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_ID 不允许为空！';
    RETURN;
  END IF;

  /*   ID  流程ID  
      PROCESS_NAME  流程名称 
      PROCESS_LEVEL 流程级别
      PROCESS_STATUS  流程状态
  */

  --先写死，用于给客户演示，后面完善

  OPEN O_RESULT FOR
    SELECT 1 AS ID,
           '代销主协议' AS PROCESS_NAME,
           1 AS PROCESS_LEVEL,
           2 AS PROCESS_STATUS
      FROM DUAL
    
    UNION ALL
    
    SELECT 2 AS ID,
           '代销补充协议' AS PROCESS_NAME,
           2 AS PROCESS_LEVEL,
           2 AS PROCESS_STATUS
      FROM DUAL
    
    UNION ALL
    
    SELECT 3 AS ID,
           '产品尽职调查' AS PROCESS_NAME,
           3 AS PROCESS_LEVEL,
           1 AS PROCESS_STATUS
      FROM DUAL
    
    UNION ALL
    SELECT 4 AS ID,
           '重点代销审批' AS PROCESS_NAME,
           4 AS PROCESS_LEVEL,
           1 AS PROCESS_STATUS
      FROM DUAL;

  /*  FOR CUR_INFO IN(SELECT * FROM TPIF_CPDM A 
                    WHERE INSTR( ';'||I_PROD_TYPE||';',';'||A.CPXL||';')>0 
                      AND (I_PROD_MANAGER IS NULL OR A.CPGLRID = I_PROD_MANAGER)
                      AND (I_PROD_NAME IS NULL OR A.CPMC LIKE '%'||I_PROD_NAME||'%' OR A.CPDM LIKE '%'||I_PROD_NAME||'%')
                      AND A.CPXL>0
                      AND A.CPGLRID IS NOT NULL ) LOOP 
                      
                      NULL;
  
  END LOOP ;
     */
  ---YXXPDLJ

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

