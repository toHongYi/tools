create PROCEDURE PRO_PIF_JGFW_JDSX(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2, --返回消息
                                              I_USER IN INTEGER, --操作人
                                              I_OPER IN INTEGER, --操作类型1|上移;2|下移
                                              I_ID   IN INTEGER --操作ID (机构服务节点ID)
                                              ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：重点销售产品管理-产品顺序
      语法信息：
           输入参数：I_USER IN INTEGER, --操作人
                     I_OPER IN INTEGER, --操作类型1|上移;2|下移
                     I_ID IN INTEGER --操作ID (机构服务节点ID)

           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-08-09     1.0.1     hanqiaonan          新增
  ***********************************************************************/
  V_COUNT  INTEGER; --计数变量
  V_JGFWID INTEGER; --机构服务id
  V_ZHID   INTEGER; --置换id
  V_SX     INTEGER; --顺序
BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '';

  IF I_OPER IS NULL THEN
    O_CODE := '-1';
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '操作成功';

  --获取是否置顶，置顶顺序，展示顺序和产品库

  SELECT JGFWID, SX INTO V_JGFWID, V_SX FROM TPIF_JGFWLCJD WHERE ID = I_ID;

  IF I_OPER = 1 THEN
    --上移
    IF V_SX = 1 THEN
      --第一位
      O_CODE := 199;
      O_NOTE := '置顶节点不能上移';
      RETURN;
    END IF;
    --获取置换节点id
    SELECT ID INTO V_ZHID FROM TPIF_JGFWLCJD WHERE SX = V_SX - 1 AND JGFWID=V_JGFWID;
    UPDATE TPIF_JGFWLCJD SET SX = V_SX - 1 WHERE ID = I_ID AND JGFWID=V_JGFWID ;
    UPDATE TPIF_JGFWLCJD SET SX = V_SX WHERE ID = V_ZHID AND JGFWID=V_JGFWID ;
  END IF;

  IF I_OPER = 2 THEN
    --下移
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_JGFWLCJD WHERE SX > V_SX AND JGFWID=V_JGFWID;
    IF V_COUNT = 0 THEN
      O_CODE := 199;
      O_NOTE := '末位节点不能下移';
      RETURN;
    END IF;
    --获取置换节点id
    SELECT ID INTO V_ZHID FROM TPIF_JGFWLCJD WHERE SX = V_SX + 1 AND JGFWID=V_JGFWID;
    UPDATE TPIF_JGFWLCJD SET SX = V_SX + 1 WHERE ID = I_ID AND JGFWID=V_JGFWID;
    UPDATE TPIF_JGFWLCJD SET SX = V_SX WHERE ID = V_ZHID AND JGFWID=V_JGFWID;
  END IF;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;

END PRO_PIF_JGFW_JDSX;
/

