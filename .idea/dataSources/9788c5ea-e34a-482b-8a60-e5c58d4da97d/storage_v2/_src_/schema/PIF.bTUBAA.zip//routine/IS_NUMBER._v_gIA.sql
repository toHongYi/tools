create function is_number(str varchar2) return number is
begin
  if regexp_like(str, '^[0-9]+$') then
    return 1;
  else
    return 0;
  end if;
end;
/

