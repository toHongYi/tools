create FUNCTION FUNC_PIF_JYRL_QJGJYR(I_DATE IN DATE, --要判断的日期
                                                I_BTW  IN NUMBER --间隔工作日数
                                                ) RETURN DATE AS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：取间隔节假日

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-06-27     V1.0      谢莉莉             创建
      2016-10-18     V2.0      王大一             移植并修改
  *********************************************************************************************************************/

  V_DATE  DATE; --返回日期
  V_JJRGZ NUMBER; --间隔工作日数
  V_I     NUMBER; --节假日规则
  V_FLAG  NUMBER; --标志

BEGIN
  V_DATE  := I_DATE;
  V_JJRGZ := I_BTW;
  V_FLAG  := 0;

  IF (V_JJRGZ > 0) THEN
    V_I := 1;
  ELSE
    V_I := -1;
  END IF;

  while (V_JJRGZ != 0 or FUNC_PIF_JYRL_JJRPD(V_DATE) > 0) loop
    --判断日期是否是节假日
    while (FUNC_PIF_JYRL_JJRPD(V_DATE) > 0) loop
      V_DATE := V_DATE + V_I;
      V_FLAG := 1;
    end loop;

    IF (V_FLAG = 0) THEN
      V_DATE := V_DATE + V_I;
    END IF;

    IF (V_JJRGZ > 0 and FUNC_PIF_JYRL_JJRPD(V_DATE) = 0) THEN
      V_JJRGZ := V_JJRGZ - 1;
      V_FLAG  := 0;
    ELSIF (V_JJRGZ < 0 and FUNC_PIF_JYRL_JJRPD(V_DATE) = 0) THEN
      V_JJRGZ := V_JJRGZ + 1;
      V_FLAG  := 0;
    END IF;
  end loop;
  RETURN V_DATE;
END FUNC_PIF_JYRL_QJGJYR;
/

