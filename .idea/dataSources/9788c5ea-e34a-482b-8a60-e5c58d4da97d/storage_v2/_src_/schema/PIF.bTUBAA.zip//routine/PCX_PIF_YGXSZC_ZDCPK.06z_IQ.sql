create PROCEDURE pcx_pif_ygxszc_zdcpk(O_CODE     OUT NUMBER,
                                                O_NOTE     OUT VARCHAR2,
                                                O_RESULT   OUT SYS_REFCURSOR,
                                                I_CURRENT  IN NUMBER, --页码
                                                I_PAGESIZE IN NUMBER, --页长
                                                I_PAGING   IN NUMBER, --是否分页
                                                I_SORT     IN STRING, --排序规模
                                                I_TOTAL    IN OUT NUMBER, --记录总数
                                                I_USERID   IN NUMBER,
                                                I_TYPE     in number,     --1\首发公募;2|首发非公募;3|持营公募；4|持营非公募
                                                I_SJ       in number      --1近一周/2近一月/3近三月/4近一年
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：重点产品库

      语法信息：
           输入参数：     I_CURRENT  IN NUMBER, --页码
                          I_PAGESIZE IN NUMBER, --页长
                          I_PAGING   IN NUMBER, --是否分页
                          I_SORT     IN STRING, --排序规模
                          I_TOTAL    IN OUT NUMBER --记录总数
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-16     1.0       TUMENG              新增
  ***********************************************************************/
  V_SQL          VARCHAR2(32767);
  V_SQL_WHREE    VARCHAR2(32767) := '';
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
  V_RQ           number(8) := to_number(to_char(sysdate,'yyyymmdd'));
  V_BDATE        number(8);
  V_EDATE        number(8);
  V_ND           number(4);
  V_ZH           number(6);
  V_YF           number(6);
BEGIN


  --否则返回结果集合
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;
  --按当前时间取时间区间
  ----1近一周/2近一月/3近三月/4近一年
  
  if I_SJ =  1 then 
      V_EDATE := to_char(sysdate-7,'yyyymmdd') ;
  elsif I_SJ =  2 then 
     V_EDATE := to_char(sysdate-30,'yyyymmdd') ;
  elsif I_SJ =  3 then 
     V_EDATE := to_char(sysdate-90,'yyyymmdd') ;
  else  
     V_EDATE := to_char(sysdate-260,'yyyymmdd') ;     
   end if;
 

  --业务处理
  V_SQL := ' select id as id,
                    cpdm as prod_code,
                    cpmc as prod_name,
                    (select note from livebos.txtdm where fldm = ''PIF_CPFXDJ_CPZX'' and ibm = cpfxdj)  as risk_level,
                    cpfxdj as risk_level_id,
                    (select note from livebos.txtdm where fldm = ''PIF_CPJD'' and ibm = cpjd) as prod_stage,
                    qsrq as sale_start_date,
                    jsrq as sale_end_date,
                    to_char(qtje,''fm999999990.09'') as init_invest_amount,
                    (select note from livebos.txtdm where fldm = ''PIF_XSDJ'' and ibm = ZDXSDJ) as sale_level,
                    (select note from livebos.txtdm where fldm = ''PIF_XSLD'' and ibm = JYXSLD) as suggest_sale_efforts,
                    xsfw as sale_area,
                    XSZC as sale_policy
              from TPIF_CPDM_ZDXS ';
  V_SQL_WHREE := ' where zt = 1 ';
  IF I_TYPE = 1 then
    V_SQL_WHREE := V_SQL_WHREE ||  ' and cpxl = 1 and sfcy = 1';
  elsif I_TYPE = 2 then
    V_SQL_WHREE := V_SQL_WHREE ||  ' and cpxl != 1 and sfcy = 1';
  elsif I_TYPE = 3 then
    V_SQL_WHREE := V_SQL_WHREE ||  ' and cpxl = 1 and sfcy = 2';
  elsif I_TYPE = 4 then
    V_SQL_WHREE := V_SQL_WHREE || ' and cpxl != 1 and sfcy = 2';
  end if;
  v_sql := v_sql || V_SQL_WHREE || ' and (/*JSRQ >=  '|| V_BDATE || ' and */ QSRQ >= ' || V_EDATE || ' )';

  dbms_output.put_line(V_SQL);

  IF V_SORT IS NULL THEN
    V_SORT := 'id DESC';
  END IF;
  V_COLLIST := 'id,prod_code,prod_name,risk_level,risk_level_id,prod_stage,sale_start_date,sale_end_date,init_invest_amount,sale_level,suggest_sale_efforts,sale_area,sale_policy';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

exception 
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

