create PROCEDURE pcx_ProdYieldRate(O_CODE          OUT NUMBER,
                                              O_NOTE          OUT VARCHAR2,
                                              O_RECORD_NUMBER OUT NUMBER,
                                              O_RESULT        OUT SYS_REFCURSOR,
                                              I_USER          IN INTEGER, --操作人
                                              I_IP            IN VARCHAR2, --访问IP
                                              I_PROD_ID       IN NUMBER, --产品ID
                                              I_PROD_CODE     IN VARCHAR2, --产品代码
                                              I_BEGIN_DATE    IN NUMBER, --开始日期（含）
                                              I_END_DATE      IN NUMBER, --结束日期（含）
                                              I_PAGE_NO       IN NUMBER, --页码
                                              I_PAGE_LONG     IN NUMBER --页长

                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品七日年化收益率、万份收益查询

      语法信息：
           输入参数：    I_PROD_CODE     IN VARCHAR2, --产品代码
                         I_BEGIN_DATE    IN NUMBER, --开始日期（含）
                         I_END_DATE      IN NUMBER, --结束日期（含）
                         I_PAGE_NO       IN NUMBER, --页码
                         I_PAGE_LONG     IN NUMBER --页长
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-03-26     1.0       WUJINFENG              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000009');
  V_COUNT     NUMBER;
  V_JKLX      NUMBER;
  V_PAGE_NO   NUMBER;
  V_PAGE_LONG NUMBER;
BEGIN
  IF I_IP IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_IP】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_PROD_CODE IS NULL AND I_PROD_ID IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_PROD_CODE】和【I_PROD_ID】不能同时为空';
    GOTO BOTTOM;
  END IF;

  /*IF I_BEGIN_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_BEGIN_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;

  IF I_END_DATE IS NULL THEN
    O_CODE := 1001;
    O_NOTE := '入参【I_END_DATE】不允许为空';
    GOTO BOTTOM;
  END IF;*/

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;



  V_PAGE_NO   := NVL(I_PAGE_NO, 1); --默认第1页
  V_PAGE_LONG := NVL(I_PAGE_LONG, 50); --默认每页50条记录

  SELECT COUNT(*)
    INTO O_RECORD_NUMBER
    FROM PIF.TPROD_NAV_INFO A
   WHERE A.NAV_DATE BETWEEN I_BEGIN_DATE AND I_END_DATE
     AND A.PROD_ID =
         (SELECT ID
            FROM PIF.TPROD_BASIC_INFO
           WHERE ID = NVL(I_PROD_ID, ID)
             AND PROD_CODE = NVL(I_PROD_CODE, PROD_CODE))
     AND A.UNIT_YIELD IS NOT NULL;


  IF V_PAGE_NO > CEIL(O_RECORD_NUMBER / V_PAGE_LONG) THEN
    V_PAGE_NO := CEIL(O_RECORD_NUMBER / V_PAGE_LONG);
  END IF;

  OPEN O_RESULT FOR
    SELECT PROD_CODE, --产品代码
           PROD_NAME, --产品名称
           DATA_DATE, --数据日期
           UNIT_YIELD, --货币基金万份收益
           D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
      FROM (SELECT ROWNUM                 AS XH,
                   A.PROD_CODE            AS PROD_CODE, --产品代码
                   A.PROD_FULLNAME        AS PROD_NAME, --产品名称
                   B.NAV_DATE             AS DATA_DATE, --数据日期
                   B.UNIT_YIELD, --货币基金万份收益
                   B.D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
              FROM PIF.TPROD_BASIC_INFO A, PIF.TPROD_NAV_INFO B
             WHERE A.ID = B.PROD_ID
               AND A.ID =
                   (SELECT ID
                      FROM PIF.TPROD_BASIC_INFO
                     WHERE ID = NVL(I_PROD_ID, ID)
                       AND PROD_CODE = NVL(I_PROD_CODE, PROD_CODE))
               AND B.NAV_DATE BETWEEN I_BEGIN_DATE AND I_END_DATE
               AND B.UNIT_YIELD IS NOT NULL
             ORDER BY B.NAV_DATE ASC)
     WHERE XH > (V_PAGE_NO - 1) * V_PAGE_LONG
       AND XH <= V_PAGE_NO * V_PAGE_LONG;

  O_CODE := 0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT NULL AS PROD_CODE, --产品代码
           NULL AS PROD_NAME, --产品名称
           NULL AS DATA_DATE, --数据日期
           NULL AS UNIT_YIELD, --货币基金万份收益
           NULL AS D7_ANNUAL_YIELD_RATE --货币基金七日年化收益率
     FROM DUAL
     WHERE 1 = 2;
  END IF ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

