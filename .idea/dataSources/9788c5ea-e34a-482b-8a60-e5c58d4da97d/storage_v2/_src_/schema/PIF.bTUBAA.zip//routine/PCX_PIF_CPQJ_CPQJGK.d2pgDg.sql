create PROCEDURE PCX_PIF_CPQJ_CPQJGK(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                O_RESULT  OUT SYS_REFCURSOR,
                                                I_USERID  IN NUMBER, --用户ID
                                                I_PROD_ID IN NUMBER --产品ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询产品概况
  所属用户：PIF
  概要说明：查询产品概况.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品概况.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2021-12-3      1.0.0   GAOKUN           根据财通的表进行修改
  ********************************************************************/
  V_SQL  VARCHAR2(4000);
  V_CPLX NUMBER; --产品类型
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';
  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;
  IF I_USERID IS NULL THEN
    O_NOTE := '用户ID不允许为空！';
    RETURN;
  END IF;

  SELECT CPXL INTO V_CPLX FROM TPIF_CPDM WHERE CPID = I_PROD_ID;

  V_SQL := 'SELECT A.CPID AS ID,
                 A.CPDM AS PROD_CODE,
                 A.CPJC AS PROD_SIMP_NAME,
                 A.CPMC AS PROD_FULLNAME,
                 (SELECT X.NOTE FROM LIVEBOS.TXTDM X WHERE X.FLDM=''PIF_CPXL_CPZX'' AND X.IBM=A.CPXL) AS PROD_MAIN_CATEGORY,--产品类型
                 (SELECT Y.NAME FROM TPIF_JRCPFL Y WHERE Y.ID=A.JRCPFL ) AS PROD_TYPE,--一级分类
                 TO_CHAR(TO_DATE(A.CLRQ,''YYYYMMDD''),''YYYY-MM-DD'') AS ESTABLISH_DAY,
                 (SELECT Z.NOTE FROM LIVEBOS.TXTDM Z WHERE Z.FLDM=''PIF_CPFXDJ_CPZX'' AND Z.IBM=A.CPFXDJ) AS PROD_RISK_LEVEL,
                 (SELECT V.NOTE FROM LIVEBOS.TXTDM V WHERE V.FLDM=''PIF_JZJYCPZT'' AND V.IBM=A.CPJYZT) AS PROD_STATUS,--产品交易状态
                 ROUND(A.CPZXGM/10000,2) AS PROD_SCALE_AMOUNT,
                 NULL AS FUND_AMOUNT,
                 A.CPGLRMC AS PROD_MANAGER,--管理人
                 A.CPTGRMC AS PROD_TRUSTEE,--托管人
                 A.TZFZR AS FUND_MANAGER,--基金经理
                 TO_CHAR(A.CPJZ,''FM9990.0000'') AS UNIT_NAV,
                 TO_CHAR(TO_DATE(A.JZRQ,''YYYYMMDD''),''YYYY-MM-DD'') AS NAV_DATE,
                 TO_CHAR(A.LJJZ,''FM9990.0000'') AS TOTAL_NAV,
                 A.PJXJ_CX AS RATING_STAR_CX,--晨星评级
                 A.PJXJ_ZS AS RATING_STAR_ZS,--招商评级
                 A.PJXJ_YH AS RATING_STAR_JAJX,--济安评级
                 NULL AS SALE_SCALE_HALFYEAR,--近6月销量
                 NULL AS SALE_SCALE_ONE_YEAR,--近1年销量
                 ';

  IF V_CPLX = 1 THEN
    --公募
    V_SQL := V_SQL || 'TO_CHAR(B.NVDAILYGROWTHRATE,''FM9990.00'') AS UNIT_NAV_CHG,--日涨幅
                       TO_CHAR(NVL(B.RRSINCETHISYEAR,D.RRSINCETHISYEAR),''FM9990.00'') AS NAV_CHG_THISYEAR,--今年以来涨跌幅
                       TO_CHAR(NVL(B.RRSINCESTART,D.RRSINCESTART),''FM9990.00'') AS YIELD_RATE_SINCE_FOUND,--成立以来涨跌幅
                       TO_CHAR(NVL(B.RRINTHREEMONTH,D.RRINTHREEMONTH),''FM9990.00'') AS YIELD_RATE_QUARTER,--近3月涨跌幅
                       TO_CHAR(NVL(B.RRINSIXMONTH,D.RRINSIXMONTH),''FM9990.00'') AS YIELD_RATE_HALFYEAR,--近6月涨跌幅
                       TO_CHAR(NVL(B.RRINTHREEYEAR,D.RRINTHREEYEAR),''FM9990.00'') AS YIELD_RATE_THREE_YEAR,--近3年涨跌幅
                       TO_CHAR(C.JYNZDHC,''FM9990.00'') AS MAX_DRAWDOWN_ONEYEAR,--近1年最大回撤
                       TO_CHAR(C.JSNZDHC,''FM9990.00'') AS MAX_DRAWDOWN_THREE_YEAR,--近3年最大回撤
                       TO_CHAR(C.CLYLZDHC,''FM9990.00'') AS MAX_DRAWDOWN_SINCE_FOUND--成立以来最大回撤
    FROM PIF.TPIF_CPDM A
    LEFT JOIN INFO.TINFO_JJJZZXBX B
           ON A.CPDM=B.SECUCODE 
    LEFT JOIN PIF.TPIF_CPJZ_YSZB C
           ON A.CPDM=C.CPDM
    LEFT JOIN INFO.TINFO_HBJJSYBX D
           ON A.CPDM=D.SECUCODE       
    WHERE A.CPID=' || I_PROD_ID;
  ELSE
    --其余的
    V_SQL := V_SQL || 'TO_CHAR(D.RZF,''FM9990.00'') AS UNIT_NAV_CHG,--日涨幅
                       TO_CHAR(B.QJSYL_JNYL,''FM9990.00'') AS NAV_CHG_THISYEAR,--今年以来涨跌幅
                       TO_CHAR(B.QJSYL_CLYL,''FM9990.00'') AS YIELD_RATE_SINCE_FOUND,--成立以来涨跌幅
                       TO_CHAR(B.QJSYL_3Y,''FM9990.00'') AS YIELD_RATE_QUARTER,--近3月涨跌幅
                       TO_CHAR(B.QJSYL_6Y,''FM9990.00'') AS YIELD_RATE_HALFYEAR,--近6月涨跌幅
                       TO_CHAR(B.QJSYL_3N,''FM9990.00'') AS YIELD_RATE_THREE_YEAR,--近3年涨跌幅
                       TO_CHAR(C.JYNZDHC,''FM9990.00'') AS MAX_DRAWDOWN_ONEYEAR,--近1年最大回撤
                       TO_CHAR(C.JSNZDHC,''FM9990.00'') AS MAX_DRAWDOWN_THREE_YEAR,--近3年最大回撤
                       TO_CHAR(C.CLYLZDHC,''FM9990.00'') AS MAX_DRAWDOWN_SINCE_FOUND--成立以来最大回撤
    FROM PIF.TPIF_CPDM A
    LEFT JOIN DSC_STAT.TPIF_STAT_CP_SYTZ_CPZX  B
           ON A.CPDM=B.CPDM
    LEFT JOIN PIF.TPIF_CPJZ_YSZB C
           ON A.CPDM=C.CPDM
    LEFT JOIN PIF.TPIF_CPZXJZ D
           ON A.CPDM=D.CPDM
    WHERE A.CPID=' || I_PROD_ID;
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;

END PCX_PIF_CPQJ_CPQJGK;
/

