create type pljson_path_segment as object (
  indx number(32),
  name varchar2(4000)
) final

/

