create PROCEDURE PRO_KHBF_SC(O_CODE OUT NUMBER,    --错误代码
                                        O_NOTE OUT VARCHAR2,  --错误消息
                                        I_USER_ID IN NUMBER,  --登陆用户ID
                                        I_VISIT_ID IN NUMBER  --拜访记录ID 
                                        ) AS
                                        
/******************************************************************
  项目名称：财通证券运营展业平台-客户拜访
  所属用户：PIF
  概要说明：客户拜访记录删除

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
       输入参数：
          见参数定义部分   

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   gaokun            新增.
  ********************************************************************/                                        
                                        
BEGIN
  O_CODE :=1;
  O_NOTE := '成功！';

  IF I_USER_ID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='登陆用户ID不允许为空！';
    RETURN;
  END IF;

  IF I_VISIT_ID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='拜访记录ID不允许为空！';
    RETURN;
  END IF;
  
  --1删除该拜访记录中的需求信息
  DELETE FROM PIF.TPIF_XQXX A
   WHERE A.ID = (select ywxq from PIF.TPIF_BFJL B where B.ID = I_VISIT_ID);
  
  --2删除该条拜访记录
  DELETE FROM PIF.TPIF_BFJL A
  WHERE A.ID=I_VISIT_ID;

  COMMIT;
--  DBMS_OUTPUT.PUT_LINE('成功删除该条拜访记录！');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;

END;
/

