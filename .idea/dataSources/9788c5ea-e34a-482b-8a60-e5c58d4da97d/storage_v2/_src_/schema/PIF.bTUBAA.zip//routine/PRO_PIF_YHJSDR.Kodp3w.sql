create PROCEDURE PRO_PIF_YHJSDR(O_CODE   OUT NUMBER, --返回值
                                           O_NOTE   OUT VARCHAR2, --返回消息
                                           I_ROLECODE IN VARCHAR2 --角色编码
                                           ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：用户角色导入
      语法信息：
           输入参数：I_ROLEID IN INTEGER --角色id
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-12-20     1.0.1     HANQN              新增
  ***********************************************************************/
  V_COUNT INTEGER; --计数变量
  V_ORGID INTEGER;
  V_YHID  NUMBER(32); --用户id
  V_JSORG INTEGER;
  V_ROLEID NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  
  --CHECK
  SELECT COUNT(1) INTO V_COUNT FROM LIVEBOS.LBROLE WHERE ROLECODE = I_ROLECODE;
  IF V_COUNT = 0 THEN
    O_CODE := -1;
    O_NOTE := '角色不存在';
    RETURN;
  END IF;
  --获取角色ID
  SELECT ID INTO V_ROLEID FROM LIVEBOS.LBROLE WHERE ROLECODE = I_ROLECODE;
  
  
  --定义导入用户表
  FOR CUR IN (SELECT * FROM tqtfzr WHERE zt IS NULL AND sfzd=1) LOOP
    SELECT COUNT(1)
      INTO V_COUNT
      FROM LIVEBOS.TUSER
     WHERE NAME = TRIM(CUR.NAME);
    IF V_COUNT = 0 THEN
      O_CODE := -1;
      O_NOTE := '用户不存在';
      CONTINUE;
    END IF;
    SELECT ID INTO V_YHID FROM LIVEBOS.TUSER WHERE NAME = TRIM(CUR.NAME);
  
    SELECT COUNT(1)
      INTO V_COUNT
      FROM LIVEBOS.LBMEMBER
     WHERE USERID = V_YHID
       AND ROLEID = V_ROLEID;
    IF V_COUNT > 0 THEN
      CONTINUE;
    END IF;
  
    SELECT COUNT(1) INTO V_COUNT FROM LIVEBOS.TUSER A,LIVEBOS.LBORGANIZATION B WHERE A.ORGID=B.ID AND  A.ID = V_YHID;
    IF V_COUNT =0 THEN 
      CONTINUE;
    END IF;
    SELECT ORGID INTO V_ORGID FROM LIVEBOS.TUSER WHERE ID=V_YHID;

    
    --获取角色部门
    SELECT COUNT(1)
      INTO V_COUNT
      FROM LIVEBOS.LBORGANIZATION
     WHERE ID = 301
     START WITH ID = V_ORGID
    CONNECT BY PRIOR FID = ID;
    IF V_COUNT > 0 THEN
      --是否分支机构
      SELECT ID INTO V_JSORG FROM 
        ( SELECT ID,lx
        FROM LIVEBOS.LBORGANIZATION
       WHERE BRANCH_ID IS NOT NULL
       START WITH ID = V_ORGID     
      CONNECT BY PRIOR FID = ID ORDER BY lx ) WHERE ROWNUM=1;
      
    ELSE
      SELECT CASE
               WHEN T.GRADE = 3 THEN
                FID
               ELSE
                T.ID
             END AS ID
        INTO V_JSORG
        FROM LIVEBOS.LBORGANIZATION T
       WHERE ID = V_ORGID;
    END IF;
    
    INSERT INTO livebos.lbmember
      (id, userid, roleid, orgid, modidate)
    VALUES
      (livebos.func_nextid('LBMEMBER'), V_YHID, V_ROLEID, V_JSORG, SYSDATE);
    
    UPDATE tqtfzr SET ZT=1 WHERE ID=CUR.ID; 
      
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_YHJSDR;
/

