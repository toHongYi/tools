create PROCEDURE PCX_DAZX_FJHQ  (O_CODE                    OUT INTEGER,       --返回值
                                            O_NOTE                    OUT VARCHAR2,      --返回信息
                                            O_RESULT                  OUT SYS_REFCURSOR, --返回结果集
                                            I_LCBDID                  IN VARCHAR2,   ---流程ID
                                            I_LCBD                    IN VARCHAR2,   ---流程对象
                                            I_FJZD                    IN VARCHAR2,   ---附件字段
                                            I_USER                    IN INTEGER         ---用户ID
                                            ) AS
    /******************************************************************************
     项目名称：产品中心
     所属用户：pif
     概要说明：档案中心-附件获取

      修订记录：
      修订日期           版本号       修订人             修改内容简要说明
      2021.03.05         V1.0.0       李骐               海通迁移过来
       
    ******************************************************************************/
    V_SQL     VARCHAR2(18000);
    V_LCBD   VARCHAR2(500);
    V_CNT    VARCHAR2(500);

BEGIN
    DBMS_OUTPUT.ENABLE (buffer_size=>null);
    --init
    O_CODE         := 1;
    O_NOTE         := '成功!';
    --check
    --输入参数判断
  IF (I_LCBDID IS NULL) OR (I_LCBD IS NULL) OR (I_USER IS NULL) OR (I_FJZD IS NULL)
     THEN
    O_NOTE := '传入参数错误!';
    RETURN;
  END IF;

  --工作流表单判断
  SELECT LOWER(SUBSTR(I_LCBD, 1, 2)) || UPPER(SUBSTR(I_LCBD, 3))
    INTO V_LCBD
    FROM DUAL;
  SELECT COUNT(1) INTO V_CNT FROM LIVEBOS.tTABLE WHERE TABLENAME = V_LCBD;
  IF V_CNT = 0 THEN
    O_NOTE := '流程表单[' || V_LCBD || ']不存在!';
    RETURN;
  END IF;

  --工作流记录判断
  V_SQL := 'SELECT COUNT(1) FROM ' || V_LCBD || ' WHERE ID = ' || I_LCBDID;
  EXECUTE IMMEDIATE V_SQL
    INTO V_CNT;
  IF V_CNT = 0 THEN
    O_NOTE := '流程表单记录[' || I_LCBDID || ']不存在!';
    RETURN;
  END IF;

    V_SQL   := 'SELECT ID  记录ID,'||''''||I_LCBD||''''||' AS 对象,'||''''||I_FJZD||''''||' AS 附件字段,SYSDATE AS 上传时间,'||I_USER||' AS 上传者  FROM POSS.'||I_LCBD||' WHERE ID = '||I_LCBDID||' ';


--    DBMS_OUTPUT.PUT_LINE(V_SQL);
    OPEN O_RESULT FOR  V_SQL ;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
END PCX_DAZX_FJHQ;
/

