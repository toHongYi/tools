create PROCEDURE PRO_SJQX_CPDM(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2 --返回消息
                                         ) IS
    /******************************************************************
        所属用户：PIF
        功能说明：TPIF_CPDM数据清洗逻辑
        语法信息：
             输入参数：   无
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2020-11-09     1.0       吴金锋              创建
                                                      废弃，不用了
    ***********************************************************************/
   V_GLRBM VARCHAR2(100);
   V_GLRWD NUMBER;
   V_COUNT NUMBER;
   V_JB    NUMBER;
   V_YJFL  NUMBER;
   V_EJFL  NUMBER;
   V_SJFL  NUMBER;
   V_CPGLRID NUMBER;
   CUR_SMCP TPIF_SMCP%ROWTYPE;

BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    
    
   /******第一步 ：从 TPIF_SMCP 表插入更新 产品代码、名称、产品策略类型、基金管理人、成立日期 ******/ 
   FOR CUR_DYCPID IN( SELECT  DYCPID ,wm_concat(KHBH) as khbh FROM TPIF_SMCP WHERE SHZT = 2 group by DYCPID ) LOOP
                                
                                
       SELECT * INTO CUR_SMCP FROM TPIF_SMCP B WHERE B.DYCPID = CUR_DYCPID.DYCPID AND ROWNUM=1 AND B.SHZT=2 ;
     
       V_YJFL:=CUR_SMCP.YJCL;
       V_EJFL:=CUR_SMCP.EJCL;
       V_SJFL:=CUR_SMCP.SJCL;
       SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDM A WHERE A.ZYNM = CUR_DYCPID.DYCPID /*AND CPXL=2 */;
       
/*       IF CUR_SMCP.CLLX IS NOT NULL THEN
       
           select grade INTO V_JB from TPIF_SMCLFL where id=CUR_SMCP.CLLX;
           
           IF V_JB = 1 THEN
             V_YJFL := CUR_SMCP.CLLX;
             V_EJFL := null;
             V_SJFL := null;
           ELSIF V_JB = 2 THEN
             select fid INTO V_YJFL from TPIF_SMCLFL where id=CUR_SMCP.CLLX; 
             V_EJFL := CUR_SMCP.CLLX;
             V_SJFL := null;
           ELSE
             V_SJFL := CUR_SMCP.CLLX;
             select fid INTO V_EJFL from TPIF_SMCLFL where id=V_SJFL; 
             select fid INTO V_YJFL from TPIF_SMCLFL where id=V_EJFL; 
           --V_EJFL := CUR_SMCP.CLLX;
             
           END IF ;
       
       END IF ;*/

       IF V_COUNT = 0 THEN
          
            INSERT INTO TPIF_CPDM (ID    ,--  ID
                                   JRCPFL,-- 金融产品分类
                                   CPXL  ,-- 产品系列 
                                   CPNBZT,-- 产品内部状态
                                   CPDM,  -- 产品代码
                                   DXCPDM,-- 代销产品代码
                                   CPMC,  -- 产品名称
                                   CLRQ,  -- 产品成立日期
                                   SMCLYJFL,
                                   SMCLEJFL,
                                   SMCLSJFL,
                                   CPGLRID,
                                   ZYNM,
                                   CPYWLX,
                              --     SJSJ,
                              --    SJCZR,
                                   ZHXGR,
                                   ZHXGSJ,
                                   GLKHH
                                   )
                      VALUES(LIVEBOS.FUNC_NEXTID('TPIF_CPDM'),
                             '500100',   --私募证券投资基金
                             2,
                             8, --已上架
                             (SELECT REG_CODE FROM src_pif.T_FUND_INFO B WHERE B.FUND_ID=CUR_SMCP.DYCPID),
                             CUR_SMCP.CPDM,
                             CUR_SMCP.CPMC,
                             CUR_SMCP.CLRQ,
                             V_YJFL,
                             V_EJFL,
                             V_SJFL,
                             CUR_SMCP.JJGLR,
                             CUR_SMCP.DYCPID,
                             CUR_SMCP.YWLX,
                        --     SYSDATE,
                        --     0,
                             CUR_SMCP.ZHXGR,
                             SYSDATE,
                             CUR_DYCPID.KHBH
                              );
       
       
       ELSE
         
            UPDATE TPIF_CPDM A SET A.SMCLYJFL = V_YJFL,
                                   A.SMCLEJFL = V_EJFL,
                                   A.SMCLSJFL = V_SJFL,
                                   A.CPGLRID = NVL(CUR_SMCP.JJGLR,A.CPGLRID),
                                   A.ZYNM = NVL(A.ZYNM,CUR_SMCP.DYCPID),
                                   A.CPYWLX	=  CUR_SMCP.YWLX, --产品业务类型
                                   A.CPDM = (SELECT REG_CODE FROM src_pif.T_FUND_INFO B WHERE B.FUND_ID=CUR_SMCP.DYCPID),
                                   A.DXCPDM = CUR_SMCP.CPDM,
                                   a.glkhh = CUR_DYCPID.KHBH
                                   --CPTX	产品投向
                                   --CPYRGM	产品引入规模（元）
                                   --GGBL	杠杆比例
                            WHERE A.ZYNM = CUR_SMCP.DYCPID ;
       
       END IF ;

   END LOOP ;
   
   /******第二步 ：集中交易--基金信息表:prodcode,只取私募******/
    MERGE INTO PIF.TPIF_CPDM M
    USING(SELECT  PRODTA_NO ,          --  TA代码
                  PROD_CODE ,          --  产品代码
                  PROD_NAME ,          --  产品名称
                  PRODSPELL_CODE,      --  拼音代码
                  IPO_BEGIN_DATE,      --  募集开始日期
                  IPO_END_DATE,        --  募集结束日期
                  PROD_BEGIN_DATE,     --  产品成立日期
                  PROD_END_DATE,       --  产品结束日期
                  PROM_BEGIN_DATE,     --  推介开始日期
                  PROM_END_DATE,       --  推介结束日期
                  PROD_TERM,           --  产品期限
                  PROD_STATUS,         --  产品交易状态
                  MONEY_TYPE,	         --	 币种类别
                  ISSUE_PRICE,         --  发行价格
                  PAR_VALUE,           --  每份面值
                  TRIM(CHARGE_TYPE) AS CHARGE_TYPE,     --  基金收费方式
                  TRIM(DIVIDEND_WAY) AS DIVIDEND_WAY,   --  基金分红方式
                  MIN_SHARE,           --  个人最低认购金额
                  PROD_MIN_BALA,       --  产品最低募集金额
                  PROD_MAX_BALA,       --  产品最高募集金额
                  PROD_REAL_BALA,      --  产品实际募集金额
                  YEAR_DAYS ,          --  产品年化天数
                  PRODPRE_RATIO,       --  产品预期年收益率
                  PROD_RATIO_STR,      --  产品预期年收益率文字描述
                  
                  PRODCOMPANY_NAME,    --  产品注册登记机构名称
                  PROD_MANAGER,        --  产品管理人
                  PROD_TRUSTEE,        --  产品托管人
                  
                  TRIM(INVEST_TYPE) AS INVEST_TYPE,        -- 产品投资类别
                  TRIM(INCOME_TYPE) AS INCOME_TYPE,        -- 产品收益类型
                  TRIM(PROD_INVEST_TERM) AS PROD_INVEST_TERM, -- 产品投资期限
                  TRIM(PRODRISK_LEVEL) AS PRODRISK_LEVEL,     -- 产品风险等级
                  TRIM(ASSESS_LEVEL) AS ASSESS_LEVEL,         -- 产品评估等级 
                  TRIM(LOW_CORP_RISK_LEVEL) AS LOW_CORP_RISK_LEVEL,-- 最低风险等级
                  TRIM(MIN_ASSET_NEED) AS MIN_ASSET_NEED,     -- 投资者最低资产要求
                  TRIM(EN_PROF_FLAG) AS EN_PROF_FLAG,         -- 允许专业投资者类型
                 
                  CURRENT_AMOUNT_LOW,   --持仓量的最低值
                  MAX_SUBSCRIBE_NUM,    --认购人数上限
                  MIN_SWITCH_IN_BALANCE,--最低转换金额
                  TRANS_LIMITSHARE,     --最少转换份额
                  SWITCH_UNIT,          --转换单位
                  REDEEM_LIMITSHARE,    --赎回最低份额
                  REDEMPTION_UNIT,      --赎回最小单位
                  TRIM(REDEEM_USE_FLAG) AS REDEEM_USE_FLAG, --赎回资金可用标志
                  TRIM(MAX_ALLOTRATIO) AS  MAX_ALLOTRATIO   --每次最大可申购比例
         FROM SRC_PIF.DWD_PRD_PRODCODE_DD A 
          WHERE A.PRODCODE_TYPE='j' 
            AND EXISTS( SELECT 1 FROM TPIF_SMCP B WHERE B.SHZT=2 AND B.CPDM = A.PROD_CODE AND B.CPDM IS NOT NULL)) N
     ON(M.DXCPDM = N.PROD_CODE AND M.DXCPDM IS NOT NULL)
     WHEN MATCHED THEN UPDATE SET
         M.CPTA   = N.PRODTA_NO,
         M.CPMC   = N.PROD_NAME,
         M.PYDM   = N.PRODSPELL_CODE,
         M.MJKSRQ = N.IPO_BEGIN_DATE,
         M.MJJSRQ = N.IPO_END_DATE,
         M.CLRQ = N.PROD_BEGIN_DATE,
         M.DQRQ = N.PROD_END_DATE,
         M.TJQSRQ = N.PROM_BEGIN_DATE,
         M.TJZZRQ = N.PROM_END_DATE,
         M.CPQX = N.PROD_TERM,
         M.CPJYZT = N.PROD_STATUS,
         M.HBZL = N.MONEY_TYPE,
         M.FXJG = N.ISSUE_PRICE,
         M.MFMZ = N.PAR_VALUE,
         M.SFFS = N.CHARGE_TYPE,
         M.FHFS = N.DIVIDEND_WAY,
         M.QTJE = N.MIN_SHARE,
         
         M.CPZDMJJE = N.PROD_MIN_BALA, --  产品最低募集金额
         M.CPZGMJJE = N.PROD_MAX_BALA, --  产品最高募集金额
         M.CPSJMJJE = N.PROD_REAL_BALA,--  产品实际募集金额
         
         M.NHTS = N.YEAR_DAYS,
         M.YQSYL = N.PRODPRE_RATIO,
         M.YQSYLMS = N.PROD_RATIO_STR,
         M.CPTAMC = PRODCOMPANY_NAME,
         M.CPGLRID =nvl(M.CPGLRID, (select id from tpif_jgdm a where (a.jgmc = N.PROD_MANAGER or a.jgjc=N.PROD_MANAGER) and rownum=1)),
         M.CPTGR = N.PROD_TRUSTEE,

         M.TZLB = N.INVEST_TYPE,
         M.SYLX = N.INCOME_TYPE,
         M.CPTZQX = N.PROD_INVEST_TERM,
         M.CPFXDJ = N.PRODRISK_LEVEL,
         M.CPPGDJ = N.ASSESS_LEVEL,
         M.ZDFXDJ = N.LOW_CORP_RISK_LEVEL,
         M.ZDZCYQ = N.MIN_ASSET_NEED,
         M.YXZYTZZLX = N.EN_PROF_FLAG,
         
         M.CCLDZDZ = N.CURRENT_AMOUNT_LOW,--持仓量的最低值
         M.RGRSSX = MAX_SUBSCRIBE_NUM,--认购人数上限
         M.ZDZHJE = N.MIN_SWITCH_IN_BALANCE,--最低转换金额
         M.ZSZHFE = N.TRANS_LIMITSHARE,--最少转换份额
         M.ZHDW = N.SWITCH_UNIT,--转换单位
         M.SHZDZ = N.REDEEM_LIMITSHARE,--赎回最低份额
         M.SHZXDW = N.REDEMPTION_UNIT,--赎回最小单位
         M.SHZJKYBZ = N.REDEEM_USE_FLAG,--赎回资金可用标志
         M.MCZDKSGBL = N.MAX_ALLOTRATIO --每次最大可申购比例
         
   /*  WHEN NOT MATCHED THEN
       INSERT(ID    ,--  ID
              JRCPFL,-- 金融产品分类
              CPXL  ,-- 产品系列 
              CPNBZT,-- 产品内部状态
              CPTA,  --ta代码
              CPDM,  --产品代码
              CPMC,  --产品名称
              PYDM,  --拼音代码
              MJKSRQ,--  募集开始日期
              MJJSRQ,--  募集结束日期
              CLRQ,  --  产品成立日期
              DQRQ,  --  产品结束日期
              TJQSRQ, --  推介开始日期
              TJZZRQ, --  推介结束日期
              CPQX,   --  产品期限
              CPJYZT, --  产品交易状态
              HBZL,   --	 币种类别
              FXJG,   --  发行价格
              MFMZ,   --  每份面值
              SFFS,   --  基金收费方式
              FHFS,   --  基金分红方式
              QTJE,   --  起投金额
              CPZDMJJE, --  产品最低募集金额
              CPZGMJJE, --  产品最高募集金额
              CPSJMJJE ,--  产品实际募集金额
              NHTS,    --  产品年化天数
              YQSYL,   --  产品预期年收益率
              YQSYLMS, --  产品预期年收益率文字描述
              CPTAMC,  --  产品注册登记机构名称
              CPTGR,   --  产品托管人
              TZLB,       -- 产品投资类别
              SYLX,       -- 产品收益类型
              CPTZQX,     -- 产品投资期限
              CPFXDJ,     -- 产品风险等级
              CPPGDJ,     -- 产品评估等级
              ZDFXDJ,     -- 最低风险等级
              ZDZCYQ,     -- 投资者最低资产要求
              YXZYTZZLX,  -- 允许专业投资者类型
              CCLDZDZ ,--持仓量的最低值
              RGRSSX , --认购人数上限
              ZDZHJE , --最低转换金额
              ZSZHFE , --最少转换份额
              ZHDW  ,  --转换单位
              SHZDZ,   --赎回最低份额
              SHZXDW,  --赎回最小单位
              SHZJKYBZ,  --赎回资金可用标志
              MCZDKSGBL, --每次最大可申购比例
              SJSJ,
              SJCZR,
              CPGLRID
              )
        VALUES(livebos.FUNC_NEXTID('TPIF_CPDM'),
                '500100',   --私募证券投资基金
                2,
                8, --已上架
                N.PRODTA_NO,           --  产品ta
                N.PROD_CODE,           --  产品代码
                N.PROD_NAME ,          --  产品名称
                N.PRODSPELL_CODE,      --  拼音代码
                N.IPO_BEGIN_DATE,      --  募集开始日期
                N.IPO_END_DATE,        --  募集结束日期
                N.PROD_BEGIN_DATE,     --  产品成立日期
                N.PROD_END_DATE,       --  产品结束日期
                N.PROM_BEGIN_DATE,     --  推介开始日期
                N.PROM_END_DATE,       --  推介结束日期
                N.PROD_TERM,           --  产品期限
                N.PROD_STATUS,         --  产品交易状态
                N.MONEY_TYPE,	         --	 币种类别
                N.ISSUE_PRICE,         --  发行价格
                N.PAR_VALUE,           --  每份面值
                N.CHARGE_TYPE,         --  基金收费方式
                N.DIVIDEND_WAY,        --  基金分红方式
                N.MIN_SHARE,           --  个人最低认购金额
                N.PROD_MIN_BALA,       --  产品最低募集金额
                N.PROD_MAX_BALA,       --  产品最高募集金额
                N.PROD_REAL_BALA,      --  产品实际募集金额
                N.YEAR_DAYS ,          --  产品年化天数
                N.PRODPRE_RATIO,       --  产品预期年收益率
                N.PROD_RATIO_STR,      --  产品预期年收益率文字描述
                N.PRODCOMPANY_NAME,    --  产品注册登记机构名称
                N.PROD_TRUSTEE,        --  产品托管人
                N.INVEST_TYPE,         -- 产品投资类别
                N.INCOME_TYPE,         -- 产品收益类型。
                N.PROD_INVEST_TERM,    -- 产品投资期限
                N.PRODRISK_LEVEL,      -- 产品风险等级
                N.ASSESS_LEVEL,        -- 产品评估等级 
                N.LOW_CORP_RISK_LEVEL, -- 最低风险等级
                N.MIN_ASSET_NEED,      -- 投资者最低资产要求
                N.EN_PROF_FLAG,        -- 允许专业投资者类型
                N.CURRENT_AMOUNT_LOW,   --持仓量的最低值
                N.MAX_SUBSCRIBE_NUM,    --认购人数上限
                N.MIN_SWITCH_IN_BALANCE,--最低转换金额
                N.TRANS_LIMITSHARE,     --最少转换份额
                N.SWITCH_UNIT,          --转换单位
                N.REDEEM_LIMITSHARE,    --赎回最低份额
                N.REDEMPTION_UNIT,      --赎回最小单位
                N.REDEEM_USE_FLAG,      --赎回资金可用标志
                N.MAX_ALLOTRATIO,        --每次最大可申购比例
                sysdate,0,
                (select id from tpif_jgdm a where (a.jgmc = N.PROD_MANAGER or a.jgjc=N.PROD_MANAGER) and rownum=1)
          )*/;

  
   

    /******第三步 ：从朝阳永续更新 ******/ 
    FOR CUR_FUND_ID IN(SELECT * FROM TPIF_CPDM WHERE ZYNM IS NOT NULL) LOOP
        
        UPDATE TPIF_CPDM M
           SET (M.CPJC,
                M.DYCPQC,
                M.BABH,
                M.BASJ,
                M.CPZHFS,--N
                M.CPTZBD,
                M.CPTGR,
                M.TZGW,
                M.TZFZR,
                M.TZFW,
                M.TZMB,
                M.TZFX,
                M.TZLN,
                M.CPDP,
                M.CPYJX,--N
                M.CPZSX,--N
                M.CPJJ,
                M.ZYNM,
                M.CPJD,
                M.DQRQ,
                M.CLRQ,
                M.HBZL,
                M.QTJE,
                M.CPZDMJJE,
                M.CPZGMJJE,
                M.CPSJMJJE,
                M.TJQSRQ,
                M.TJZZRQ,
                M.PYDM,
                M.CPGLRID
                )
               
                =
               (SELECT FUND_NAME, -- 基金简称
                       FUND_FULL_NAME,   --  对应产品全称 
                       reg_code,
                       TO_CHAR(reg_time, 'YYYYMMDD') AS reg_time,
                       DECODE(FUND_TYPE_INVESTMENT_WAY,'FOF','3','MOM','4','TOF','2','TOL','5','TOT－一对多','1','伞形','7','链式基金','8','其他间接投资','6','FOF,其他间接投资','3;6','FOF,链式基金','3;8','其他间接投资,链式基金','6;8') AS FUND_TYPE_INVESTMENT_WAY,--
                       FUND_TYPE_TARGET,
                       --FUND_MANAGER_NOMINAL,
                       FUND_CUSTODIAN,
                       FUND_MANAGER,
                       FUND_MEMBER,
                       INVESTMENT_RANGE,
                       INVESTMENT_TARGET,
                       ORIENTATION,
                       INVESTMENT_IDEA,
                       APPRAISE,
                       PRECAUTIOUS_LINE, --  预警线(元)
                       STOP_LOSS_LINE, --止损线(元)
                       INSTRUCTION, --简介
                       FUND_ID,
                       (CASE WHEN FUND_STATUS='存续中' THEN 3 WHEN FUND_STATUS='已终止' THEN 5 END),
                      TO_CHAR(END_DATE,'YYYYMMDD'),
                      TO_CHAR(FOUNDATION_DATE,'YYYYMMDD'),
                      NVL(CUR_FUND_ID.HBZL,DECODE(CURRENCY,'人民币现钞',0,'美元现汇',1,'港元现汇',2)),
                      MIN_PURCHASE_AMOUNT,--最低认购金额(元)
                      ISSUING_SCALE,--	发行规模(元)
                      ISSUING_SCALE,--	发行规模(元)
                      REAL_FINANCING_SCALE,--	实际募集规模
                      TO_CHAR(RECOMMENDATION_START,'YYYYMMDD'),		
                      TO_CHAR(RECOMMENDATION_END,'YYYYMMDD'),
                      FUND_NAME_PY,
                      NVL(CUR_FUND_ID.CPGLRID,(SELECT ID FROM TPIF_JGDM A WHERE A.JGMC = nvl(B.FUND_MANAGER_NOMINAL,b.fund_manager)))
                  FROM SRC_PIF.T_FUND_INFO B
                 WHERE FUND_ID = CUR_FUND_ID.ZYNM )
         WHERE M.ZYNM = CUR_FUND_ID.ZYNM ;
         
         SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDM A WHERE A.ID = CUR_FUND_ID.ID AND A.CPGLRID IS NULL ;
         
         IF V_COUNT >0  THEN
           
             UPDATE TPIF_CPDM M
               SET (M.CPGLRID)
               
               =(SELECT (SELECT ID FROM TPIF_JGDM A WHERE A.JGJC = NVL(B.FUND_MANAGER_NOMINAL,B.FUND_MANAGER))
                      FROM SRC_PIF.T_FUND_INFO B
                     WHERE FUND_ID = CUR_FUND_ID.ZYNM )
             WHERE M.ZYNM = CUR_FUND_ID.ZYNM ;
           
        END IF;   
           
           

    END LOOP ;

   
   --产品阶段处理  2募集期 3 存续期 4 清盘期 5 结束期
    /*1	开放期
    2	认购期
    4	产品成立
    5	产品终止
    6	停止交易
    7	停止申购
    8	停止赎回*/
    UPDATE TPIF_CPDM A SET A.CPJD =DECODE(A.CPJYZT,1,3,2,2,4,3,5,5,3)
    WHERE A.CPJYZT IS NOT NULL
      AND NVL(A.CPJD,-1) <> 5 ;
   
   --通过朝阳永续更新修正金融产品分类
   
   /*100100  信托  
     100101  私募公司 
     100102  公募专户及子公司 
     100103  券商集合理财 
     100104  银行 
     100105  期货资管 
     100107  保险公司及其子公司的资产管理计划
     
     100101100 私募证券投资基金
     100101101 私募其他投资基金
     100101102 私募股权投资基金 
     100101103 私募创业投资基金
     100101104 私募资产配置基金

   */
   MERGE INTO TPIF_CPDM M
   USING( SELECT FUND_ID,TYPE_CODE FROM src_pif.t_fund_type_mapping 
           WHERE TYPE_CODE IN('100100','100102','100103','100104','100105','100107','100101100','100101101','100101102','100101103','100101104') 
        ) N
   ON( M.ZYNM = N.FUND_ID)
   WHEN MATCHED THEN UPDATE 
     SET M.JRCPFL =NVL( DECODE(N.TYPE_CODE,'100100','600100','100102','300400','100103','100100','100104','800100','100105','700200','100107','900100','100101100','500100','100101101','500500','100101102','500200','100101103','500300','100101104','500400'),M.JRCPFL),
         M.CPXL = NVL(DECODE(N.TYPE_CODE,'100100',8,'100102',7,'100103',3,'100104',5,'100105',9,'100107',6,'100101100',2,'100101101',2,'100101102',2,'100101103',2,'100101104', 2), M.CPXL)
     
  ;
  

  
     --更新CPID和ID值一致方便后续维护
     UPDATE TPIF_CPDM A SET A.CPID = A.ID WHERE A.CPID IS NULL  ;

    --产品期限 更新
    UPDATE TPIF_CPDM A SET A.CPQX = TO_DATE(A.DQRQ,'YYYYMMDD') - TO_DATE(A.CLRQ,'YYYYMMDD')
    WHERE LENGTH(A.CLRQ)=8 AND LENGTH(DQRQ)=8;

    --日期处理
    UPDATE TPIF_CPDM A
           SET A.MJKSRQ = (CASE WHEN  A.MJKSRQ = 0 THEN NULL ELSE A.MJKSRQ END),
               A.MJJSRQ = (CASE WHEN  A.MJJSRQ = 0 THEN NULL ELSE A.MJJSRQ END),
               A.CLRQ = (CASE WHEN  A.CLRQ = 0 THEN NULL ELSE A.CLRQ END),
               A.DQRQ = (CASE WHEN  A.DQRQ = 0 THEN NULL ELSE A.DQRQ END),
               A.TJQSRQ = (CASE WHEN  A.TJQSRQ = 0 THEN NULL ELSE A.TJQSRQ END),
               A.TJZZRQ = (CASE WHEN  A.TJZZRQ = 0 THEN NULL ELSE A.TJZZRQ END) ;
         

    --适当性 ，适合投资者类型
    UPDATE TPIF_CPDM A
         SET A.SHTZZLX = （CASE WHEN A.CPFXDJ=0 THEN '1;2;3;4;5'
                                WHEN A.CPFXDJ=1 THEN '2;3;4;5'
                                WHEN A.CPFXDJ=2 THEN '3;4;5'
                                WHEN A.CPFXDJ=3 THEN '4;5'
                                WHEN A.CPFXDJ=4 THEN '5'  END )
         WHERE A.CPFXDJ IS NOT NULL ;
         
         
    --CPZXGM
    
    MERGE INTO TPIF_CPDM M
    USING(SELECT FUND_ID ,ASSET_SCALE 
           FROM ( SELECT FUND_ID,
                         ASSET_SCALE,
                         ROW_NUMBER() OVER(PARTITION BY FUND_ID ORDER BY STATISTIC_DATE DESC) PX
                  FROM SRC_PIF.T_FUND_ASSET_SCALE 
                  WHERE ASSET_SCALE > 0 )
           WHERE PX = 1
          ) N
    ON (M.ZYNM = N.FUND_ID)
    WHEN MATCHED THEN UPDATE SET M.CPZXGM = N.ASSET_SCALE ;
         


    O_CODE := 1;
    O_NOTE := 'TPIF_CPDM 表清洗成功';
    commit;
EXCEPTION
    WHEN OTHERS THEN
        rollback ;
        O_CODE := -1;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       'TPIF_CPDM 表清洗,未知错误'
                      ELSE
                       'TPIF_CPDM 表清洗,在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END ;
/

