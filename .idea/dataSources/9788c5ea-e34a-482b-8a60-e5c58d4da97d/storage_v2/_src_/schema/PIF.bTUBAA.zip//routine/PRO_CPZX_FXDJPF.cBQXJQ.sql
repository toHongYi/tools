create PROCEDURE     PRO_CPZX_FXDJPF(O_CODE OUT NUMBER,
                                                O_NOTE OUT VARCHAR2,
                                                I_ID   in number) AS
  /******************************************************************************
  *
  *文件名称：PRO_CPZX_FXDJPF
  *项目名称：东方c产品中心
  *
  *创建人员：yc
  *创建日期：20170512
  *功能说明：产品风险等级评分
  ******************************************************************************/
  V_FXDF    number(10,4);
  V_LRLX    number(10);
  V_count   number(10);
  V_SFGFXCP number(10);
  V_CPMC    varchar(100);
  V_ZF     NUMBER(8);--增加分值
  V_JF     NUMBER(8);--扣减分值
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  select SFGFXCP, CPMC, lrlx
    into V_SFGFXCP, V_CPMC, V_LRLX
    from pif.LC_CPXZ_SDXJ
   where id = I_id;
   --------------------------FJMC
   update pif.LC_CPXZ_SDXJ_CPFJ_TCPFJB set CPMC=V_CPMC where LC_CPXZ_SDXJ_ID=I_id;
   commit;
   

  ------------------非OTC录入清空OTC默认值
  /*IF V_LRLX <> 4 then
    update pif.LC_CPXZ_SDXJ
       set DJJG       = null,
           FXRMC      = null,
           SYPZMZ     = null,
           FXJG       = null,
           DGKHZGRGJE = null,
           NFJXTS     = null,
           FXCS       = null,
           TZZRSSX    = null,
           MJFS       = null,
           MJZJYT     = null,
           FXFS       = null,
           DFFS       = null,
           CD         = null,
           FESH       = null,
           TQSH       = null,
           FEZR       = null,
          CLR       = null,
           DQR        = null,
           RGQ        = null,
           DFR        = null
     where id = I_ID;
    commit;
  
  end if;*/ --20190325 

  ------------------非私募录入清空私募默认值
  IF V_LRLX =5 THEN --IF V_LRLX not in (2, 5, 6) then --20190325 
    update pif.LC_CPXZ_SDXJ
       set CLR = null, DQR = null, KFRQ = null, FFRQ = null--, CLSJ = null
     where id = I_ID;
    commit;
  
  end if;



 --计算管理人增减分因素。
   SELECT  nvl(SUM(ZJLX * DYFZ),0) INTO  V_ZF--加分项
     FROM PIF.LC_CPXZ_SDXJ A, PIF.TPIF_GLRFXCPZJF B
    WHERE A.ID = I_ID
      AND INSTR(';' || A.JJGLRJFX || ';', ';' || B.ID || ';') > 0;
      
   SELECT nvl(SUM(ZJLX * DYFZ),0) INTO  V_JF--扣分项
     FROM PIF.LC_CPXZ_SDXJ A, PIF.TPIF_GLRFXCPZJF B
    WHERE A.ID = I_ID
      AND INSTR(';' || A.JJGLRKFX || ';', ';' || B.ID || ';') > 0;


  -------------------一般金融产品风险评估因素
  IF V_SFGFXCP = 2 then
    select nvl(a.FXRXX, 0) + nvl(SFJWFX, 0) + nvl(GLRGWYJ, 0) +
           nvl(TJSFBLYTZZ, 0) + nvl(TZAP, 0) + nvl(JCZCZK, 0) +
           nvl(DBPJZZK, 0) + nvl(FXSYTZ, 0) + nvl(TZZKNSS, 0) +
           nvl(FHRYDF, 0)+NVL(SFGKMJ,0)
      into V_FXDF
      from (select (case
                     when FXRXX = 1 then
                      30+V_ZF+V_JF
                     when FXRXX = 2 then
                      35+V_ZF+V_JF
                     when FXRXX = 3 then
                      35+V_ZF+V_JF
                     when FXRXX = 4 then
                      40+V_ZF+V_JF
                     when FXRXX = 5 then
                      30+V_ZF+V_JF
                     when FXRXX = 6 then
                      35+V_ZF+V_JF
                     when FXRXX = 7 then
                     85+V_ZF+V_JF--- 60  ---20170607 XG
                     when FXRXX = 8 then
                      95+V_ZF+V_JF---75 ---20170607 XG
                     when FXRXX = 9 then
                      5+V_ZF+V_JF
                     when FXRXX = 10 then
                      30+V_ZF+V_JF
                   end) * 0.15 FXRXX,
                   (case
                     when SFJWFX = 1 then
                      100
                     when SFJWFX = 2 then
                      0
                   end) * 0.02 SFJWFX,

                   (case
                     when GLRGWYJ = 1 then
                      80---40 --20170607 XG
                     when GLRGWYJ = 2 then
                      55 --30  --20170607 XG
                     when GLRGWYJ = 3 then
                     25--- 20  --20170607 XG
                     when GLRGWYJ = 4 then
                      0
                   end) * 0.02 GLRGWYJ,
                   (case
                     when TJSFBLYTZZ = 1 then
                      30
                     when TJSFBLYTZZ = 2 then
                      10
                   end) * 0.02 TJSFBLYTZZ,
                   
                   
                   (case
                     when TZAP = 1 then
                      0
                     when TZAP = 2 then
                      25
                      when TZAP = 3 then
                      35----20170620 xz
                     when TZAP = 4 then
                      40
                     when TZAP = 5 then
                     75-- 80
                     
                         when TZAP = 6 then
                     25
                     when TZAP = 7 then
                      85
                     when TZAP = 8 then
                      85
                     when TZAP = 9 then
                      35
                     when TZAP = 10 then
                      65
                       when TZAP = 11 then
                      65
                       when TZAP = 12 then
                      70
                       when TZAP = 13 then
                      80
                   end) * 0.13 TZAP,
                                    (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end) * 0.15 JCZCZK,
                   
                   (case
                     when DBPJZZK = 1 then
                      10
                     when DBPJZZK = 2 then
                      70
                      
                     when DBPJZZK = 3 then
                                           (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end)
                      when DBPJZZK = 4 then
                        
                                           (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end)
                   
                    when DBPJZZK = 5 then 70 --20170607 XG
                   when DBPJZZK = 6 then 70 end-------------------新增类型5
                   ) * 0.12 DBPJZZK,
                   
                   ((case
                     when FXSYTZ = 1 then
                      0
                     when FXSYTZ = 2 then
                      5
                     when FXSYTZ = 3 then
                      15
                     when FXSYTZ = 4 then
                      25
                     when FXSYTZ = 5 then
                      35
                     when FXSYTZ = 6 then
                      10
                     when FXSYTZ = 7 then
                      70---45
                     when FXSYTZ = 8 then
                      25 --20170607 XG
                     when FXSYTZ = 9 then
                      35 --20170607 XG
                   end) + (case
                     when LDXTX = 1 then
                      0
                     when LDXTX = 2 then
                      15
                     when LDXTX = 3 then
                      45
                   end)) * 0.35 FXSYTZ,

                   (case
                     when TZZKNSS = 1 then
                      10
                     when TZZKNSS = 2 then
                      25
                   end) * 0.03 TZZKNSS,
                   (case
                     when SFGKMJ = 1 then
                      100
                     when SFGKMJ = 2 then
                      0
                   end) * 0.005 SFGKMJ,
                   FHRYDF * 0.005 FHRYDF
              from pif.LC_CPXZ_SDXJ
             where id = I_ID) a;

    -----变更风险得分与等级
    update pif.LC_CPXZ_SDXJ
       set ZF   = V_FXDF,
         shzt=1,
           FXDJ = (select case
                            when V_FXDF >= 0 and V_FXDF <= 18 then
                             1
                            when V_FXDF > 18 and V_FXDF <= 28 then
                             2
                            when V_FXDF > 28 and V_FXDF <= 43 then
                             3
                            when V_FXDF > 43 and V_FXDF <= 53 then
                             4
                            when V_FXDF > 53 then
                             5
                          end
                     from dual)
     where id = I_ID;
    commit;
  end if;

  -------复杂或高风险金融产重点评估因素

  IF V_SFGFXCP = 1 then

    select nvl(a.FXRXX, 0) + nvl(SFJWFX, 0) + nvl(GLRGWYJ, 0) +
           nvl(TJSFBLYTZZ, 0) + nvl(TZAP, 0) + nvl(JCZCZK, 0) +
           nvl(DBPJZZK, 0) + nvl(FXSYTZ, 0) + nvl(TZZKNSS, 0) +
           nvl(FHRYDF, 0) + nvl(CPJEDJGG, 0) + nvl(CPXXFS, 0)
           + NVL(SFGKMJ,0) +
           nvl(KHKNSS, 0) + (case
                               when nvl(CPGG, 0) > 0 then
                                nvl(CPGG, 0)
                               else
                                0
                             end)
      into V_FXDF
      from (

            --------复杂特有评测因素
            select (case
                      when CPJEDJGG = 1 then
                       40
                      when CPJEDJGG = 2 then
                       50
                      when CPJEDJGG = 3 then
                       10
                    end) * 0.02 CPJEDJGG,
                    (case
                      when CPXXFS = 1 then
                       5
                      when CPXXFS = 2 then
                       80
                    end) * 0.1 CPXXFS,
                    (case
                      when KHKNSS = 1 then
                       b.FXSYTZ
                      when KHKNSS = 2 then
                       ZGSSBJ
                    end) * 0.1 KHKNSS,

                    (case
                       when CPGG = 1 then
                        b.FXSYTZ
                       when CPGG = 2 then
                        b.FXSYTZ + a.GGBL / 30 * 10
                       when CPGG = 3 then
                        (case
                       when b.FXSYTZ >
                            b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 then
                        (case
                       when b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 < 0 then
                        0
                       else
                        b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5
                     end) else b.FXSYTZ end)
                    ------MAX(MIN(b.FXSYTZ,,b.FXSYTZ+(YXX/(YXX+LHY)-0.7)/0.1*5),0)

                     when CPGG = 4 then(case
                      when b.FXSYTZ <
                           b.FXSYTZ +
                           (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 then
                       (case
                      when b.FXSYTZ +
                           (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 < 0 then
                       0
                      else
                       b.FXSYTZ +
                       (YXX / (YXX + LHY) - 0.7) / 0.1 * 5
                    end) else b.FXSYTZ end)
                    -----MAX(b.FXSYTZ,b.FXSYTZ+(YXX/(YXX+LHY)-0.7)/0.1*5)

                     when CPGG = 5 then b.FXSYTZ + a.GGBL / 30 * 10 +

                     (case
                      when b.FXSYTZ >
                           b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 then
                       (case
                      when b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5 < 0 then
                       0
                      else
                       b.FXSYTZ + (YXX / (YXX + LHY) - 0.7) / 0.1 * 5
                    end) else b.FXSYTZ end)

                    ----MAX(MIN( b.FXSYTZ, b.FXSYTZ+(YXX/(YXX+LHY)-0.7)/0.1*5),0)

                     when CPGG = 6 then b.FXSYTZ + a.GGBL / 30 * 10 + (case
                      when b.FXSYTZ <
                           b.FXSYTZ +
                           (YXX /
                           (YXX + LHY) - 0.7) / 0.1 * 5 then
                       (case
                      when b.FXSYTZ +
                           (YXX /
                           (YXX + LHY) - 0.7) / 0.1 * 5 < 0 then
                       0
                      else
                       b.FXSYTZ +
                       (YXX /
                       (YXX + LHY) - 0.7) / 0.1 * 5
                    end) else b.FXSYTZ end)
                    ---MAX( b.FXSYTZ, b.FXSYTZ+(YXX/(YXX+LHY)-0.7)/0.1*5)
                     end) * 0.07 CPGG,
                    -------------------------- yiban
               (case
                     when FXRXX = 1 then
                      30+V_ZF+V_JF
                     when FXRXX = 2 then
                      35+V_ZF+V_JF
                     when FXRXX = 3 then
                      35+V_ZF+V_JF
                     when FXRXX = 4 then
                      40+V_ZF+V_JF
                     when FXRXX = 5 then
                      30+V_ZF+V_JF
                     when FXRXX = 6 then
                      35+V_ZF+V_JF
                     when FXRXX = 7 then
                     85+V_ZF+V_JF--- 60  ---20170607 XG
                     when FXRXX = 8 then
                      95+V_ZF+V_JF---75 ---20170607 XG
                     when FXRXX = 9 then
                      5+V_ZF+V_JF
                     when FXRXX = 10 then
                      30+V_ZF+V_JF
                   end) * 0.1 FXRXX,
                   (case
                     when SFJWFX = 1 then
                      100
                     when SFJWFX = 2 then
                      0
                   end) * 0.02 SFJWFX,

                   (case
                     when GLRGWYJ = 1 then
                      80---40 --20170607 XG
                     when GLRGWYJ = 2 then
                      55 --30  --20170607 XG
                     when GLRGWYJ = 3 then
                     25--- 20  --20170607 XG
                     when GLRGWYJ = 4 then
                      0
                   end) * 0.01 GLRGWYJ,
                   (case
                     when TJSFBLYTZZ = 1 then
                      30
                     when TJSFBLYTZZ = 2 then
                      10
                   end) * 0.01 TJSFBLYTZZ,
               
                   (case
                     when TZAP = 1 then
                      0
                     when TZAP = 2 then
                      25
                      when TZAP = 3 then
                      35----20170620 xz
                     when TZAP = 4 then
                      40
                     when TZAP = 5 then
                     75-- 80
                     
                         when TZAP = 6 then
                     25
                     when TZAP = 7 then
                      85
                     when TZAP = 8 then
                      85
                     when TZAP = 9 then
                      35
                     when TZAP = 10 then
                      65
                       when TZAP = 11 then
                      65
                       when TZAP = 12 then
                      70
                       when TZAP = 13 then
                      80
                   end) * 0.1 TZAP,
                   (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end) * 0.13 JCZCZK,
                   
                   (case
                     when DBPJZZK = 1 then
                      10
                     when DBPJZZK = 2 then
                      70
                      
                     when DBPJZZK = 3 then
                                          (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end)
                      when DBPJZZK = 4 then
                        
                                          (case
                  when JCZCZK = 1 then
                      0
                     when JCZCZK = 2 then
                      25
                        when JCZCZK = 3 then
                      35-------------20170620 xz
                     when JCZCZK = 4 then
                      15----40   新需求修改数值
                      when JCZCZK = 5 then
                      40
                     when JCZCZK = 6 then
                      65
                     when JCZCZK = 7 then
                      65
                     when JCZCZK =8 then
                      75
                      
                     when JCZCZK = 9 then
                      65
                     when JCZCZK = 10 then
                      35
                     when JCZCZK = 11 then
                      75
                      when JCZCZK = 12 then
                      70
                   end)
                   
                    when DBPJZZK = 5 then 70 --20170607 XG
                   when DBPJZZK = 6 then 70 end-------------------新增类型5
                   ) * 0.1 DBPJZZK,
                   
                    ((case
                     when a.FXSYTZ = 1 then
                      0
                     when a.FXSYTZ = 2 then
                      5
                     when a.FXSYTZ = 3 then
                      15
                     when a.FXSYTZ = 4 then
                      25
                     when a.FXSYTZ = 5 then
                      35
                     when a.FXSYTZ = 6 then
                      10
                     when a.FXSYTZ = 7 then
                      70---45
                     when a.FXSYTZ = 8 then
                      25 --20170607 XG
                     when a.FXSYTZ = 9 then
                      35 --20170607 XG
                   end) + (case
                     when LDXTX = 1 then
                      0
                     when LDXTX = 2 then
                      15
                     when LDXTX = 3 then
                      45
                   end)) * 0.21 FXSYTZ,

                   (case
                     when TZZKNSS = 1 then
                      10
                     when TZZKNSS = 2 then
                      25
                   end) * 0.02 TZZKNSS,
                   (case
                     when SFGKMJ = 1 then
                      100
                     when SFGKMJ = 2 then
                      0
                   end) * 0.005 SFGKMJ,
                   FHRYDF * 0.005 FHRYDF

              from pif.LC_CPXZ_SDXJ a
              join

             (select id,
                     ((case
                       when FXSYTZ = 1 then
                        0
                       when FXSYTZ = 2 then
                        5
                       when FXSYTZ = 3 then
                        15
                       when FXSYTZ = 4 then
                        25
                       when FXSYTZ = 5 then
                        35
                       when FXSYTZ = 6 then
                        10
                       when FXSYTZ = 7 then
                        70--45
                       when FXSYTZ = 8 then
                        25
                       when FXSYTZ = 9 then
                        35
                     end) + (case
                       when LDXTX = 1 then
                        0
                       when LDXTX = 2 then
                        15
                       when LDXTX = 3 then
                        45
                     end)) FXSYTZ
                from pif.LC_CPXZ_SDXJ
               where id = I_ID) b on a.id = b.id) a;
 
               
    --------变更风险得分与等级
    update pif.LC_CPXZ_SDXJ
       set zf   = V_FXDF,
        shzt=1,
           FXDJ = (select case
                            when V_FXDF >= 0 and V_FXDF <= 18 then
                             1
                            when V_FXDF > 18 and V_FXDF <= 28 then
                             2
                            when V_FXDF > 28 and V_FXDF <= 43 then
                             3
                            when V_FXDF > 43 and V_FXDF <= 53 then
                             4
                            when V_FXDF > 53 then
                             5
                          end
                     from dual)
     where id = I_ID;
    commit;
  end if;

  ---end if;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
END PRO_CPZX_FXDJPF;
/

