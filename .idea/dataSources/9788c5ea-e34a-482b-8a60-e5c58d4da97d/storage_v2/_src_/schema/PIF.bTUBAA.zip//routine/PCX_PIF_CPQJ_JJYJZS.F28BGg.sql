create PROCEDURE PCX_PIF_CPQJ_JJYJZS(O_CODE        OUT NUMBER,
                                                O_NOTE        OUT VARCHAR2,
                                                O_RESULT      OUT SYS_REFCURSOR,
                                                I_USERID      IN NUMBER,
                                                I_PROD_ID     IN NUMBER, --产品ID
                                                I_GRANULARITY IN NUMBER --粒度  
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-基金净值走势
  所属用户：PIF
  概要说明：基金净值走势.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
       
       输入参数：
          I_USERID
          I_PROD_ID 
          I_GRANULARITY  粒度，1|近3月,2|近6月,3|近1年,4|近3年,5|近5年
                         同数据字典--时间粒度,同对比页面的走势图
           
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        基金净值走势.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/30     1.0.0.1   TUMENG             新增.
      2020/11/30     1.0.0.2   GAOKUN            根据财通情况进行部分修改
      2021-12-9      1.0.0.3   GAOKUN            根据财通情况进行修改
  **************************************************************************/
  V_SQL     VARCHAR2(4000);
  V_DATE    NUMBER(8); --走势图开始日期
  V_COUNT   NUMBER := 1; --判断净值表是否有该产品净值，默认1=有
  V_COUNT_2 NUMBER; --判断该开始日期是否有该产品净值
  V_ZZJZRQ  NUMBER(8); --该产品在净值表中的最早日期
  V_CPLX    NUMBER; --产品类型 1公募取聚源， 其余的取柜台净值
  V_CPDM    VARCHAR2(200); --产品代码
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  IF I_GRANULARITY IS NULL THEN
    O_NOTE := '粒度不允许为空！';
    RETURN;
  END IF;

  --获取开始日期
  IF I_GRANULARITY = 1 THEN
    --近3月
    SELECT JYR
      INTO V_DATE
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -3),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
  ELSIF I_GRANULARITY = 2 THEN
    --近6月
    SELECT JYR
      INTO V_DATE
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -6),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
  ELSIF I_GRANULARITY = 3 THEN
    --近1年
    SELECT JYR
      INTO V_DATE
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -12),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
  ELSIF I_GRANULARITY = 4 THEN
    --近3年
    SELECT JYR
      INTO V_DATE
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -36),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  
  ELSIF I_GRANULARITY = 5 THEN
    --近5年
    SELECT JYR
      INTO V_DATE
      FROM LIVEBOS.TXTJYR
     WHERE ZRR =
           (SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(MAX(JYR), 'YYYYMMDD'),
                                                -60),
                                     'YYYYMMDD'))
              FROM LIVEBOS.TXTJYR
             WHERE ZRR < TO_NUMBER(TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')));
  END IF;

  BEGIN
    --获取产品类型，产品代码
    SELECT CPXL, TRIM(CPDM)
      INTO V_CPLX, V_CPDM
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
      V_CPDM := '0';
  END;

  IF V_CPLX = 1 THEN
    --公募
    --判断净值表是否有该产品数据，如果有，则取该产品最早净值日期
    SELECT TO_NUMBER(TO_CHAR(MIN(ENDDATE), 'YYYYMMDD'))
      INTO V_ZZJZRQ
      FROM INFO.TINFO_JJJZ
     WHERE SECUCODE = V_CPDM;
  
    IF V_ZZJZRQ IS NULL THEN
      --如果V_ZZJZRQ为空，则表示没净值
      V_ZZJZRQ := 29991231; --给一个很大的日期
      V_COUNT  := 0; --无净值
    END IF;
  
    IF V_COUNT > 0 THEN
      --有净值
      --如果开始日期比该产品在净值表中有数据的最早日期  还早，那么更新开始日期
      IF V_DATE < V_ZZJZRQ THEN
        V_DATE := V_ZZJZRQ;
      END IF;
    
      --判断这一天是否有净值
      SELECT COUNT(1)
        INTO V_COUNT_2
        FROM INFO.TINFO_JJJZ
       WHERE SECUCODE = V_CPDM
         AND TO_NUMBER(TO_CHAR(ENDDATE, 'YYYYMMDD')) = V_DATE;
    
      --如果没有，则该天之前的最大的一天
      IF V_COUNT_2 = 0 THEN
        SELECT TO_NUMBER(TO_CHAR(MAX(ENDDATE), 'YYYYMMDD'))
          INTO V_DATE
          FROM INFO.TINFO_JJJZ
         WHERE SECUCODE = V_CPDM
           AND TO_NUMBER(TO_CHAR(ENDDATE, 'YYYYMMDD')) < V_DATE;
      END IF;
      
    END IF;
  
    V_SQL := 'SELECT TO_CHAR(UNITNV,''FM9990.0000'') AS UNIT_NAV,
              TO_CHAR(ACCUMULATEDUNITNV,''FM9990.0000'') AS TOTAL_NAV,
              TO_CHAR(ENDDATE,''YYYY-MM-DD'') AS NAV_DATE
              FROM INFO.TINFO_JJJZ 
             WHERE SECUCODE=''' || V_CPDM || '''
               AND TO_NUMBER(TO_CHAR(ENDDATE,''YYYYMMDD''))>=' ||
             V_DATE || '
          ORDER BY ENDDATE ASC';
  
  ELSE
    --其余的
    SELECT MIN(JZRQ)
      INTO V_ZZJZRQ --获取该产品在净值表中的最早净值日期 ,没取到则为默认29991231
      FROM TPIF_CPJZXX_CPZX --产品净值信息_产品中心
     WHERE CPID = I_PROD_ID;
  
    IF V_ZZJZRQ IS NULL THEN
      V_ZZJZRQ := 29991231;
      V_COUNT  := 0;
    END IF;
    
    IF V_COUNT > 0 THEN
    
      IF V_DATE < V_ZZJZRQ THEN
        --如果开始日期比该产品在净值表中有数据的最早日期  还早，那么更新开始日期
        V_DATE := V_ZZJZRQ;
      END IF;
    
      SELECT COUNT(1)
        INTO V_COUNT_2
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = I_PROD_ID
         AND JZRQ = V_DATE;
    
      IF V_COUNT_2 = 0 THEN
        SELECT MAX(JZRQ)
          INTO V_DATE
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = I_PROD_ID
           AND JZRQ < V_DATE;
      END IF;
    
    END IF;
  
    V_SQL := 'SELECT TO_CHAR(DWJZ,''FM9990.0000'') AS UNIT_NAV,
                     TO_CHAR(LJJZ,''FM9990.0000'') AS TOTAL_NAV,
                     TO_CHAR(TO_DATE(JZRQ,''YYYYMMDD''),''YYYY-MM-DD'') AS NAV_DATE
                FROM TPIF_CPJZXX_CPZX 
               WHERE CPID=' || I_PROD_ID || '
                 AND JZRQ>=' || V_DATE || '
            ORDER BY JZRQ ASC';
  
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE UNIT_NAV FROM DUAL;
  
  
END PCX_PIF_CPQJ_JJYJZS;
/

