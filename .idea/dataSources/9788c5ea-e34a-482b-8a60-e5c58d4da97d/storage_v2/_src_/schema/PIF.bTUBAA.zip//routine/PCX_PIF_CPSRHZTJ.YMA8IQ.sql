create PROCEDURE PCX_PIF_CPSRHZTJ(O_RESULT OUT SYS_REFCURSOR,
                                             I_TJLX   IN NUMBER,
                                             I_KSRQ   IN NUMBER,
                                             I_JSRQ   IN NUMBER,
                                             I_CPXL   IN NUMBER,
                                             I_XSJG   IN NUMBER,
                                             I_SFZDDX IN NUMBER, --0否；1是
                                             I_XSLX   IN VARCHAR2, --1首发；2持营
                                             I_USERID IN NUMBER) AS
  /* -----------------------------------------------------------------------
   过程名称 :  PCX_PIF_CPSRHZTJ
   功能简述：  产品收入汇总统计



   ------------------------------------------------------------------------
   操作人           操作时间       版本            操作
   LIUTX           20190918       1.0           新增
   liutx           20200114       1.1           修改添加分支机构筛选条件
  -----------------------------------------------------------------------*/

  V_SQL   VARCHAR2(3000);
  V_NOTE  VARCHAR2(1000);
  V_COUNT NUMBER;
BEGIN

  IF I_TJLX = 1 THEN

    V_SQL := 'SELECT AA.ID,AA.SJRQ , AA.FNAME,AA.NAME, AA.CPXL,SUM(AA.SXF_JY) SXF_JY ,SUM(AA.SXF_BY) SXF_BY,SUM(AA.JYYJ) JYYJ,SUM(AA.YJBC) YJBC,SUM(AA.QTSR) QTSR,SUM(HJ) HJ
FROM (SELECT X.ID,Z.SJRQ , X.FNAME,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.SXF_JY ,Z.SXF_BY ,Z.JYYJ ,Z.YJBC ,Z.QTSR ,(Z.SXF_JY +Z.SXF_BY +Z.JYYJ +Z.YJBC+Z.QTSR) HJ
    FROM (SELECT A.ID,B.NAME FNAME,A.NAME
            FROM PIF.TPIF_KHYYB@cpzx205 A
            LEFT JOIN PIF.TPIF_KHYYB@cpzx205 B
              ON A.FID = B.ID
           WHERE A.FID NOT IN (-1, 999999999)) X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         PIF.TPIF_ZDDXCPK@cpzx205 K,
         STAT_PIF.TPIF_STAT_CPDM_SRTJ_N@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2) AND X.ID = Z.JGDM
         AND Y.CPID = K.CPID
         AND Y.CPID = Z.CPID
         AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  ELSIF I_TJLX = 2 THEN
    V_SQL := 'SELECT AA.ID,AA.SJRQ , AA.FNAME,AA.NAME, AA.CPXL,SUM(AA.SXF_JY) SXF_JY ,SUM(AA.SXF_BY) SXF_BY,SUM(AA.JYYJ) JYYJ,SUM(AA.YJBC) YJBC,SUM(AA.QTSR) QTSR,SUM(HJ) HJ
FROM (SELECT X.ID,Z.SJRQ , X.FNAME,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.SXF_JY ,Z.SXF_BY ,Z.JYYJ ,Z.YJBC ,Z.QTSR ,(Z.SXF_JY +Z.SXF_BY +Z.JYYJ +Z.YJBC+Z.QTSR) HJ
    FROM (SELECT A.ID,B.NAME FNAME,A.NAME
            FROM PIF.TPIF_KHYYB@cpzx205 A
            LEFT JOIN PIF.TPIF_KHYYB@cpzx205 B
              ON A.FID = B.ID
           WHERE A.FID NOT IN (-1, 999999999)) X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         PIF.TPIF_ZDDXCPK@cpzx205 K,
         STAT_PIF.TPIF_STAT_CPDM_SRTJ_J@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2) AND X.ID = Z.JGDM
     AND Y.CPID = K.CPID
     AND Y.CPID = Z.CPID
     AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  ELSE
    V_SQL := 'SELECT AA.ID,AA.SJRQ , AA.FNAME,AA.NAME, AA.CPXL,SUM(AA.SXF_JY) SXF_JY ,SUM(AA.SXF_BY) SXF_BY,SUM(AA.JYYJ) JYYJ,SUM(AA.YJBC) YJBC,SUM(AA.QTSR) QTSR,SUM(HJ) HJ
FROM (SELECT X.ID,Z.SJRQ , X.FNAME,X.NAME,(SELECT NOTE FROM livebos.TXTDM WHERE FLDM = ''PIF_CPXL_CPZX'' AND IBM =Y.CPXL) CPXL,Y.CPDM,Y.CPMC,Z.SXF_JY ,Z.SXF_BY ,Z.JYYJ ,Z.YJBC ,Z.QTSR ,(Z.SXF_JY +Z.SXF_BY +Z.JYYJ +Z.YJBC+Z.QTSR) HJ
    FROM (SELECT A.ID,B.NAME FNAME,A.NAME
            FROM PIF.TPIF_KHYYB@cpzx205 A
            LEFT JOIN PIF.TPIF_KHYYB@cpzx205 B
              ON A.FID = B.ID
           WHERE A.FID NOT IN (-1, 999999999)) X ,
         PIF.TPIF_CPDM@cpzx205 Y,
         PIF.TPIF_ZDDXCPK@cpzx205 K,
         STAT_PIF.TPIF_STAT_CPDM_SRTJ_Y@cpzx205 Z
   WHERE (K.ZT = 1 OR K.ZT = 2) AND X.ID = Z.JGDM
     AND Y.CPID = K.CPID
     AND Y.CPID = Z.CPID
     AND Z.SJRQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;
  END IF;

  IF I_XSLX IS NOT NULL THEN
    V_SQL := V_SQL || ' AND K.SFCY=' || I_XSLX;
  END IF;

  IF I_CPXL IS NOT NULL THEN
    V_SQL := V_SQL || ' AND Y.CPXL = ' || I_CPXL;
  END IF;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM PIF.TPIF_FZJGRYMD@cpzx205
   WHERE USERNAME = I_USERID;
  IF V_COUNT > 0 THEN
    V_SQL := V_SQL ||
             ' AND instr('', '' || (SELECT WM_CONCAT(QXQYYB)
                                                  FROM PIF.TPIF_FZJGRYMD@cpzx205
                                                 WHERE USERNAME = ' ||
             I_USERID || ') || '', '', '', '' || X.ID || '', '') > 0';
  END IF;

  IF V_COUNT = 0 AND I_XSJG IS NOT NULL AND I_XSJG != 999999999 THEN
    V_SQL := V_SQL || ' AND X.ID = ' || I_XSJG;
  END IF;

  IF I_SFZDDX IS NOT NULL THEN
    V_SQL := V_SQL || ' AND Y.SFZDXS = ' || I_SFZDDX;
  END IF;

  V_SQL := V_SQL ||
           ') AA GROUP BY AA.ID,AA.SJRQ , AA.FNAME,AA.NAME, AA.CPXL';

  DBMS_OUTPUT.PUT_LINE(V_SQL);
  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
END PCX_PIF_CPSRHZTJ;
/

