create PROCEDURE PRO_PIF_CPSJLXCS(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_USER IN INTEGER, --操作人
                                                 I_IP   IN VARCHAR2, --操作IP
                                                 I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                                 I_ID   IN INTEGER --操作ID
                                                 ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品事件类型参数维护
        语法信息：
             输入参数：
             输出参数：   O_RESULT  返回结果
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-25     1.0.1    徐阳                创建
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPSJLXCS%ROWTYPE; --表单记录
    --V_SCBZ    INTEGER; --日志删除标识
    --V_OPER    VARCHAR2(200); --操作方法
    --V_FDETAIL VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    SELECT * INTO V_OBJ FROM TPIF_CPSJLXCS WHERE ID = I_ID;

    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';

    IF I_OPER = 0 THEN
        --//:新增
        IF V_OBJ.CSBM IS NULL THEN
            O_NOTE := '[编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.CSMC IS NULL THEN
            O_NOTE := '[名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPSJLXCS WHERE CSBM = V_OBJ.CSBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[编码]为[' || V_OBJ.CSBM || ']的记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPSJLXCS WHERE CSMC = V_OBJ.CSMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[名称]为[' || V_OBJ.CSMC || ']的记录!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --//:修改
        IF V_OBJ.CSBM IS NULL THEN
            O_NOTE := '[编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.CSMC IS NULL THEN
            O_NOTE := '[名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPSJLXCS WHERE CSBM = V_OBJ.CSBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[编码]为[' || V_OBJ.CSBM || ']的记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPSJLXCS WHERE CSMC = V_OBJ.CSMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[名称]为[' || V_OBJ.CSMC || ']的记录!';
            RETURN;
        END IF;
    END IF;

    IF I_OPER = 2 THEN
        --//:删除
        DELETE TPIF_CPSJLXCS WHERE ID = I_ID;
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE WHEN O_NOTE IS NULL THEN '未知错误' ELSE '在 ' || O_NOTE || ' 时出现异常' END) || ':' || SQLERRM;
        ROLLBACK;
END PRO_PIF_CPSJLXCS;
/

