create PROCEDURE PRO_SJQX_CPGGK(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2 --返回消息
                                           ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品公告库-TPIF_CPGGK数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-09-07     1.0       HANQN              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
  V_RQ   NUMBER;
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --聚源已上传公告清洗
  MERGE INTO TPIF_CPGGK T1
  USING (SELECT T.ID,
                S.CPID,
                T.INFOPUBLDATE, --信息发布日期
                T.ENDDATE, --修改日期
                T.CATEGORY, --栏目代码
                T.INFOTITLE, --信息标题
                T.FILETYPE, --报告原文文件格式
                T.FILENAME, --文件名
                T.INFOTYPE, --信息类别
                T.SUBTITLE, --小标题
                T.XGRQ, --修改日期
                T.INSERTTIME, --发布时间
                T.SECUCODE, --产品代码
                T.OSSURL --OSSURL
           FROM INFO.TINFO_GMJJGGYWFWB T, TPIF_CPDM S
          WHERE T.SECUCODE = S.CPDM
            AND T.OSSURL IS NOT NULL) T2
  ON (T1.YGGID = T2.ID AND T1.SJLY = 3)
  WHEN MATCHED THEN
    UPDATE
       SET T1.GGRQ   = T2.ENDDATE,
           T1.GGBT   = T2.INFOTITLE,
           T1.GGLB   = T2.INFOTYPE,
           T1.OSSURL = T2.OSSURL
  WHEN NOT MATCHED THEN
    INSERT
      (T1.ID, --ID,
       T1.CPID, --产品ID,
       T1.CPDM, --产品代码,
       T1.GGRQ, --公告日期,
       T1.YGGID, --原公告ID,
       T1.GGLB, --公告类别,
       T1.CATEGORY, --内容类别,
       T1.GGBT, --公告标题,
       T1.ZWNX, --正文类型,
       T1.OSSURL, --公告访问链接,
       T1.SJLY, --数据来源,
       T1.ZT, --状态,
       T1.LRR, --操作人,
       T1.LRSJ --操作时间
       )
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPGGK'),
       T2.CPID,
       T2.SECUCODE,
       T2.ENDDATE,
       T2.ID,
       T2.INFOTYPE,
       T2.CATEGORY,
       T2.INFOTITLE,
       3,
       T2.OSSURL,
       3,
       1,
       0,
       SYSDATE);

  --已上传财通资管公告清洗   
  MERGE INTO TPIF_CPGGK T1
  USING (SELECT T.ID,           --资管公告INFO层ID
                S.CPID,
                T.TITLE,        --标题
                T.DISK_PATH,
                T.FUND_CODE,    --产品代码
                T.FUND_NAME,    --产品名称
                T.RELEASE_DATE, --公告日期
                DECODE(T.TYPE, 1030, 6, 1028, 1, 1027, 3, NULL) AS GGLB, --1030产品公告 -6其他公告；1028法律文件 -1发行运作；1027定期报告-3定期报告
                T.SRCSYS, --格式
                T.OSSURL --OSSURL
           FROM INFO.CTZQ_FILE T, TPIF_CPDM S
          WHERE T.FUND_CODE = S.CPDM
            AND T.OSSURL IS NOT NULL) T2
  ON (T1.YGGID = T2.ID AND T1.SJLY = 7)
  WHEN MATCHED THEN
    UPDATE
       SET T1.GGRQ   = T2.RELEASE_DATE,
           T1.GGBT   = T2.TITLE,
           T1.GGLB   = T2.GGLB,
           T1.OSSURL = T2.OSSURL
  WHEN NOT MATCHED THEN
    INSERT
      (T1.ID, --ID,
       T1.CPID, --产品ID,
       T1.CPDM, --产品代码,
       T1.GGRQ, --公告日期,
       T1.YGGID, --原公告ID,
       T1.GGLB, --公告类别,
       T1.GGBT, --公告标题,
       T1.ZWNX, --正文类型,
       T1.OSSURL, --公告访问链接,
       T1.SJLY, --数据来源,
       T1.ZT, --状态,
       T1.LRR, --操作人,
       T1.LRSJ --操作时间
       )
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPGGK'),
       T2.CPID,
       T2.FUND_CODE,
       T2.RELEASE_DATE,
       T2.ID,
       T2.GGLB,
       T2.TITLE,
       3,
       T2.OSSURL,
       7, --财通资管
       1,
       0,
       SYSDATE);
  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_CPGGK表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := V_NOTE || SQLERRM;
END;
/

