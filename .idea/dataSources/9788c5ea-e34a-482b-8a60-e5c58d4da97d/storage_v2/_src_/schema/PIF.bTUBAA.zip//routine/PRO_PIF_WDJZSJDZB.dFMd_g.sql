create PROCEDURE PRO_PIF_WDJZSJDZB(O_CODE  OUT NUMBER, --返回值
                                              O_NOTE  OUT VARCHAR2, --返回消息
                                              I_USER  IN INTEGER, --操作人
                                              I_IP    IN VARCHAR2, --操作IP
                                              I_OPER  IN INTEGER, --操作类型 0|设置映射信息;
                                              I_ID    IN INTEGER,
                                              I_YCPID IN INTEGER) IS
  /*
  **功能说明： 万得私募产品映射管理
  **创建人：陈勇军
  **创建日期：2017-06-22
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **陈勇军              2017-06-22    创建
  **孙远何    V1.0.2    2018-08-14    增加处理CPDM_WD到产品代码表
  */
  V_COUNT INTEGER; --计数变量
  V_OBJ   TPIF_WDJZSJDZB%ROWTYPE; --表单记录
  V_QXBZ  INTEGER; --权限标识
  V_CZBM  VARCHAR2(200); --操作编码
  V_CZSM  VARCHAR2(2000); --日志操作明细
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  SELECT * INTO V_OBJ FROM TPIF_WDJZSJDZB WHERE ID = I_ID;
  SELECT DECODE(I_OPER, 0, '900803', '') INTO V_CZBM FROM DUAL;
  SELECT '[' || DECODE(I_OPER, 0, '设置映射信息', '') || ']_' || V_OBJ.WDCPMC
    INTO V_CZSM
    FROM DUAL;
  --CHECK
  /*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
  IF V_QXBZ = 0 THEN
      O_NOTE := '系统禁止管理员操作!';
      RETURN;
  END IF;*/
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    IF V_OBJ.CPID IS NOT NULL THEN
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_WDJZSJDZB
       WHERE CPID = V_OBJ.CPID;
      IF V_COUNT > 1 THEN
        O_NOTE := '已存在映射[' || V_OBJ.YWCPDM || ']的记录!';
        RETURN;
      END IF;
      IF V_OBJ.CLLX IS NULL THEN
        O_NOTE := '请选择[策略类型]!';
        RETURN;
      END IF;
      IF V_OBJ.CPID != I_YCPID THEN
        --变更映射关系：清除未确认净值信息
        DELETE FROM TPIF_CPJZ
         WHERE CPID = I_YCPID
           AND SJLY = 4
           AND QRZT = 0;
      END IF;
      UPDATE TPIF_WDJZSJDZB --赋值产品显示名称及映射标识
         SET CPMC_XS = (CASE
                         WHEN TRIM(CPMC_XS) IS NULL THEN
                          (SELECT CPMC FROM TPIF_CPDM WHERE ID = V_OBJ.CPID)
                         ELSE
                          CPMC_XS
                       END),
             YSBZ    = 1
       WHERE ID = I_ID;
      --UPDATE PIF.TPIF_CPDM SET CPDM_WD = V_OBJ.WDCPDM WHERE ID = V_OBJ.CPID;
    
    ELSE
      IF I_YCPID IS NOT NULL THEN
        --非空-空：清除未确认净值信息
        DELETE FROM TPIF_CPJZ
         WHERE CPID = I_YCPID
           AND SJLY = 4
           AND QRZT = 0;
        UPDATE TPIF_WDJZSJDZB
           SET YWCPDM  = '',
               YWCPMC  = '',
               CPMC_XS = '',
               CLRQ    = '',
               CLLX    = '',
               XSFW    = '',
               JZCXWZ  = '',
               BZ      = '',
               YSBZ    = 0
         WHERE ID = I_ID;
      END IF;
    END IF;
  END IF;
  --RECORD
  O_NOTE := '记录日志';
  PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, 1, V_CZSM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;
  --RETURN
  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER, 0, '设置映射信息', '') || ']成功!'
    INTO O_NOTE
    FROM DUAL;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_WDJZSJDZB;
/

