create PROCEDURE PRO_KHBF_GLDKJL(O_CODE   OUT NUMBER,    --错误代码
                                            O_NOTE   OUT VARCHAR2,  --错误消息
                                            I_USERID IN  NUMBER,    --登陆用户ID
                                            I_VISITID IN NUMBER,    --拜访记录ID

                                            I_GROUP_NAME	    IN VARCHAR2,  --部门名称
                                            I_CHECKIN_TYPE	  IN VARCHAR2,  --打卡类型
                                            I_CHECKIN_TIME	  IN VARCHAR2,  --打卡时间
                                            I_LOCATION_TITLE	IN VARCHAR2,  --地点
                                            I_LOCATION_DETAIL	IN VARCHAR2   --位置明细
                                         ) AS

/******************************************************************
  项目名称：财通证券运营展业平台-关联打卡记录
  所属用户：PIF
  概要说明：客户拜访关联打卡记录

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   gaokun            新增.
  ********************************************************************/
  v_DKSJ date;
BEGIN
  O_CODE :=1;
  O_NOTE :='成功！';

  IF I_USERID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='登录用户ID不能为空！';
    RETURN;
  END IF;

  IF I_VISITID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='拜访记录ID不能为空！';
    RETURN;
  END IF;
  
SELECT  TO_DATE('1970-01-01 08:00:00', 'YYYY-MM-DD HH:MI:SS')+I_CHECKIN_TIME / (1000 * 60 * 60 * 24) into v_DKSJ FROM dual ;

  UPDATE PIF.TPIF_BFJL A
     SET A.BMMC   = I_GROUP_NAME,
         A.DKLX   = I_CHECKIN_TYPE,
         A.DD     = I_LOCATION_TITLE,
         A.WZMX   = I_LOCATION_DETAIL,
         A.DKSJ   = v_DKSJ
   WHERE A.ID = I_VISITID;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;

END;
/

