create PROCEDURE PRO_PIF_JYRL_SCJYRL(O_CODE    OUT NUMBER, --返回值
                                                    O_NOTE    OUT VARCHAR2, --返回消息
                                                    I_NEWDDGZ IN NUMBER --新定点规则
                                                    ) IS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：根据规则记录刷新产品交易日历
    备注：日期暂未处理多选情况，待日后完善

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-06-27     V1.0      谢莉莉             创建
        2016-10-20     V2.0      王大一             托管系统迁移改造接入产品中心
        2016-11-18     V2.1      王大一             支持自定义规则审核后生成交易日历
        2016-12-22     V2.2      王大一             增加收费日规则R50至R54
        2016-12-23     V2.3      王大一             增加收费日规则R55
        2016-12-26     V2.4      王大一             增加收费日规则R56/R57
        2017-06-16     V2.5      孙远何             修改终止日和清盘日取值;增加R38每月第一个工作日的处理
        2021-12-01     V2.5      韩乔楠             增加定点规则R26/R58
     *********************************************************************************************************************/

    V_YWLX  VARCHAR2(300); --业务类型
    V_QSRQ  DATE; --起始日期
    V_QSJS  DATE; --结束日期
    V_DDGZ  NUMBER; --定点规则
    V_COUNT NUMBER; --统计
    V_YXJYR NUMBER; --运行交易日
    V_ZDGL  NUMBER; --是否关联[0：否，1：是]
    V_YF    VARCHAR2(300); --月份
    V_XQ    VARCHAR2(300); --星期
    V_RQ    VARCHAR2(300); --星期
    V_BH    VARCHAR2(300); --定点规则编号
    V_YSNF  VARCHAR2(300); --已刷年份
    V_DATE  DATE; --日期
    V_JGYFS NUMBER; --间隔月份数
    V_I     NUMBER; --计数
    V_SGYW  NUMBER; --第一个业务类型
    V_JJNF  NUMBER; --节假年份
    V_SQL   VARCHAR2(32767); --拼接语句
    --V_WHERE VARCHAR2(32767); --拼接语句
    V_TIME NUMBER; --记录次数
    V_CPID NUMBER; --产品ID
    V_CLRQ DATE; --成立日期
    TYPE CUR_TYPE IS REF CURSOR; --定义游标类型
    RTN_CUR CUR_TYPE; --定义游标变量
    TYPE RQ_TYPE IS RECORD(
        RQ DATE);
    RQ_RECORD RQ_TYPE;

BEGIN
    O_CODE := 1;
    O_NOTE := '操作成功！';

    --取得产品ID，交易日类型，业务类型，区间起始，区间结束，定点规则，月，星期，日，交易日长度，节假日处理
    SELECT YXJYR,
           YWLX,
           QJQS,
           QJJS,
           DDGZ,
           YF,
           XQ,
           RQ,
           ZDGLQTYXJYR,
           DECODE(INSTR(YWLX, ';'), 0, YWLX, SUBSTR(YWLX, 0, INSTR(YWLX, ';') - 1)),
           YSNF,
           CPID
      INTO V_YXJYR,
           V_YWLX,
           V_QSRQ,
           V_QSJS,
           V_DDGZ,
           V_YF,
           V_XQ,
           V_RQ,
           V_ZDGL,
           V_SGYW,
           V_YSNF,
           V_CPID
      FROM TPIF_JYRL_GZJL
     WHERE ID = I_NEWDDGZ;






    --获取产品成立日期
    BEGIN
        SELECT TO_DATE(CLRQ, 'YYYYMMDD') INTO V_CLRQ FROM TPIF_CPDM WHERE CPID = V_CPID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_CLRQ := NULL;
    END;

    --取得配置的最新节假日年份
    SELECT MAX(NF) INTO V_JJNF FROM LIVEBOS.TJRXX;

    --第一次生成
    IF (V_YSNF IS NULL) THEN
        --根据区间起始和区间结束刷新工作日表
        PRO_PIF_JYRL_CLGZRGXQJ(O_CODE,
                               O_NOTE,
                               TO_CHAR(V_QSRQ, 'YYYYMMDD'),
                               TO_CHAR(V_QSJS, 'YYYYMMDD'));
        IF (TO_DATE(TO_CHAR(V_JJNF) || '1231', 'YYYYMMDD') <= V_QSJS) THEN
            V_QSJS := TO_DATE(TO_CHAR(V_JJNF) || '1231', 'YYYYMMDD');
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JYRL
         WHERE INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0;
        IF (V_COUNT > 0) THEN
            PRO_PIF_JYRL_GZJLSC(O_CODE, O_NOTE, I_NEWDDGZ, -2);
        END IF;

    ELSE
        --非第一次生成
        IF (V_YSNF + 1 < V_JJNF) THEN
            IF (TO_DATE(V_YSNF + 1 || '0101', 'YYYYMMDD') >= V_QSRQ) THEN
                V_QSRQ := TO_DATE(V_YSNF + 1 || '0101', 'YYYYMMDD');
            ELSE
                RETURN;
            END IF;
        ELSE
            IF (TO_DATE(V_JJNF || '0101', 'YYYYMMDD') >= V_QSRQ) THEN
                V_QSRQ := TO_DATE(V_JJNF || '0101', 'YYYYMMDD');
            ELSIF (SUBSTR(TO_CHAR(V_QSRQ, 'YYYYMMDD'), 0, 4) > V_JJNF) THEN
                RETURN;
            END IF;
        END IF;
        IF (TO_DATE(V_JJNF || '1231', 'YYYYMMDD') <= V_QSJS) THEN
            V_QSJS := TO_DATE(V_JJNF || '1231', 'YYYYMMDD');
        -- ELSE  -- liliang 注释，解决刷新日历无法刷新下一年的日历数据
            -- RETURN;
        END IF;
        IF (V_QSRQ > V_QSJS) THEN
            RETURN;
        END IF;

    END IF;

    --根据是否需要关联交易日循环
    FOR YXJYR IN (SELECT ID, GLRGX, YWLX
                    FROM TPIF_JYRL_YXJYR
                   WHERE ID = V_YXJYR
                      OR GLJYR = V_YXJYR
                   ORDER BY GLJYR DESC) LOOP
        IF (YXJYR.ID = V_YXJYR) THEN
            --根据业务类型循环   '7;8'  ===>两条记录 id =7 和id=8
            FOR YWLX IN (SELECT REGEXP_SUBSTR(V_YWLX, '[^;]+', 1, ROWNUM) ID
                           FROM DUAL
                         CONNECT BY ROWNUM <=
                                    LENGTH(REGEXP_REPLACE(V_YWLX, '[^;]', NULL)) + 1) LOOP
                --定点规则处理
                --取得定点规则编号
                SELECT BH INTO V_BH FROM TPIF_JYRL_DDGZ WHERE ID = V_DDGZ;
                IF (V_BH != 'R21') THEN
                    --月份处理 '1,2,3,4,5,6,7,8,9,10,11,12'===>'01,02,03,04,05,06,07,08,09,10,11,12'
                    SELECT WM_CONCAT((CASE
                                         WHEN LENGTH(C.RQ) = 1 THEN
                                          0 || C.RQ
                                         ELSE
                                          C.RQ
                                     END)) RQ
                      INTO V_YF
                      FROM (SELECT REGEXP_SUBSTR(V_YF, '[^,]+', 1, ROWNUM) RQ
                              FROM DUAL
                            CONNECT BY ROWNUM <=
                                       LENGTH(REGEXP_REPLACE(V_YF, '[^,]', NULL)) + 1) C;
                    --日期处理  '8,11' ===>  '08,11'
                    SELECT WM_CONCAT((CASE
                                         WHEN LENGTH(C.RQ) = 1 THEN
                                          0 || C.RQ
                                         ELSE
                                          C.RQ
                                     END)) RQ
                      INTO V_RQ
                      FROM (SELECT REGEXP_SUBSTR(V_RQ, '[^,]+', 1, ROWNUM) RQ
                              FROM DUAL
                            CONNECT BY ROWNUM <=
                                       LENGTH(REGEXP_REPLACE(V_RQ, '[^,]', NULL)) + 1) C;
                END IF;
                --R11所有交易日
                IF (V_BH = 'R11') THEN
                    FOR DATE IN (SELECT RQ
                                   FROM (SELECT XQY RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQE RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQT RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQS RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQW RQ
                                           FROM TPIF_JYRL_GZR) C
                                  WHERE RQ BETWEEN V_QSRQ AND V_QSJS
                                    AND NOT EXISTS
                                  (SELECT 1
                                           FROM LIVEBOS.TJRXX
                                          WHERE C.RQ BETWEEN
                                                TO_DATE(TO_CHAR(KSRQ), 'YYYY/MM/DD') AND
                                                TO_DATE(TO_CHAR(JSRQ), 'YYYY/MM/DD'))
                                  ORDER BY C.RQ) LOOP
                        IF (DATE.RQ BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    DATE.RQ,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                    --R31每月最后一个工作日/R34每季度首月最后一个工作日/R35每季度末月最后一个工作日
                    --R36固定月最后一个工作日
                ELSIF (V_BH = 'R31' OR V_BH = 'R34' OR V_BH = 'R35' OR V_BH = 'R36') THEN
                    --取得区间内的所有月份，进行循环
                    FOR MONTH IN (SELECT YYYYMM
                                    FROM (SELECT TO_CHAR(ADD_MONTHS(V_QSJS, - (ROWNUM - 1)),
                                                         'YYYYMM') YYYYMM
                                            FROM DUAL
                                          CONNECT BY ROWNUM <
                                                     MONTHS_BETWEEN(V_QSJS, V_QSRQ) + 2) C
                                   WHERE INSTR(',' || V_YF || ',',
                                               ',' || SUBSTR(C.YYYYMM, 5, 2) || ',') > 0
                                   ORDER BY C.YYYYMM) LOOP
                        --取得每个月的最后一天
                        SELECT LAST_DAY(TO_DATE(MONTH.YYYYMM, 'YYYYMM'))
                          INTO V_DATE
                          FROM DUAL;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;

                    --R38每月第一个工作日    --modefy by syh 20170619 |新增
                ELSIF (V_BH = 'R38') THEN
                    --取得区间内的所有月份，进行循环
                    FOR MONTH IN (SELECT YYYYMM
                                    FROM (SELECT TO_CHAR(ADD_MONTHS(V_QSJS, - (ROWNUM - 1)),
                                                         'YYYYMM') YYYYMM
                                            FROM DUAL
                                          CONNECT BY ROWNUM <
                                                     MONTHS_BETWEEN(V_QSJS, V_QSRQ) + 2) C
                                   WHERE INSTR(',' || V_YF || ',',
                                               ',' || SUBSTR(C.YYYYMM, 5, 2) || ',') > 0
                                   ORDER BY C.YYYYMM) LOOP
                        --取得每个月的第一天
                        SELECT TO_DATE(MONTH.YYYYMM || '01', 'YYYYMMDD')
                          INTO V_DATE
                          FROM DUAL;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                    
                    --R22 每月单一开放日（支持冷静期），R24 固定月单一开放日（支持冷静期）
                    ELSIF(V_BH = 'R22' OR V_BH = 'R24') AND (V_YWLX='7;8'OR V_YWLX='7') THEN
                     
                    SELECT CASE
                         WHEN (SELECT INSTR(V_RQ, ',', 1, 1) - 1 FROM DUAL) < 0 THEN
                          V_RQ
                         ELSE
                          (SELECT SUBSTR(V_RQ, 0, INSTR(V_RQ, ',', 1, 1) - 1)
                           FROM   DUAL)
                     END
                    INTO V_RQ
              FROM   DUAL;
                  
                    FOR DATE IN (SELECT RQ
                                   FROM (SELECT XQY RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQE RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQT RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQS RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQW RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQL RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQR RQ
                                           FROM TPIF_JYRL_GZR) C
                                  WHERE RQ BETWEEN V_QSRQ AND V_QSJS
                                    AND INSTR(',' || V_YF || ',',
                                              ',' || SUBSTR(TO_CHAR(RQ, 'YYYYMMDD'), 5, 2) || ',') > 0
                                    AND INSTR(',' || V_RQ || ',',
                                              ',' || SUBSTR(TO_CHAR(RQ, 'YYYYMMDD'), 7, 2) || ',') > 0
                                  ORDER BY C.RQ) LOOP
                        IF (DATE.RQ BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    DATE.RQ,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                    --R23,每月最后一个工作日（支持冷静期）
                ELSIF ((V_BH = 'R23' OR V_BH='R26') AND (V_YWLX='7;8'OR V_YWLX='7')) THEN
                    --取得区间内的所有月份，进行循环
                    FOR MONTH IN (SELECT YYYYMM
                                    FROM (SELECT TO_CHAR(ADD_MONTHS(V_QSJS, - (ROWNUM - 1)),
                                                         'YYYYMM') YYYYMM
                                            FROM DUAL
                                          CONNECT BY ROWNUM <
                                                     MONTHS_BETWEEN(V_QSJS, V_QSRQ) + 2) C
                                   WHERE INSTR(',' || V_YF || ',',
                                               ',' || SUBSTR(C.YYYYMM, 5, 2) || ',') > 0
                                   ORDER BY C.YYYYMM) LOOP
                        --取得每个月的最后一天
                        SELECT LAST_DAY(TO_DATE(MONTH.YYYYMM, 'YYYYMM'))
                          INTO V_DATE
                          FROM DUAL;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                        
                    
                    --R12/R32、R14、R15、R13
                ELSIF (V_BH = 'R12' OR V_BH = 'R32' OR V_BH = 'R14' OR V_BH = 'R15' OR
                      V_BH = 'R13') THEN
                    FOR DATE IN (SELECT RQ
                                   FROM (SELECT XQY RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQE RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQT RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQS RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQW RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQL RQ
                                           FROM TPIF_JYRL_GZR
                                         UNION
                                         SELECT XQR RQ
                                           FROM TPIF_JYRL_GZR) C
                                  WHERE RQ BETWEEN V_QSRQ AND V_QSJS
                                    AND INSTR(',' || V_YF || ',',
                                              ',' || SUBSTR(TO_CHAR(RQ, 'YYYYMMDD'), 5, 2) || ',') > 0
                                    AND INSTR(',' || V_RQ || ',',
                                              ',' || SUBSTR(TO_CHAR(RQ, 'YYYYMMDD'), 7, 2) || ',') > 0
                                  ORDER BY C.RQ) LOOP
                        IF (DATE.RQ BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    DATE.RQ,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                    --R21
                ELSIF (V_BH = 'R21') THEN
                    --取得区间内的所有星期一，循环
                    FOR DATE IN (SELECT XQY
                                   FROM TPIF_JYRL_GZR
                                  WHERE XQY >= TRUNC(V_QSRQ, 'IW')
                                    AND XQY <= TRUNC(V_QSJS, 'IW')
                                  ORDER BY XQY) LOOP
                        FOR PDAY IN (SELECT REGEXP_SUBSTR(V_RQ, '[^,]+', 1, ROWNUM) RQ
                                       FROM DUAL
                                     CONNECT BY ROWNUM <=
                                                LENGTH(REGEXP_REPLACE(V_RQ, '[^,]', NULL)) + 1) LOOP
                            V_DATE := TO_DATE(TO_CHAR(DATE.XQY, 'YYYYMMDD'), 'YYYYMMDD') +
                                      (PDAY.RQ - 1);
                            IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                                --交易日长度和节假日处理
                                PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                        O_NOTE,
                                                        V_DATE,
                                                        I_NEWDDGZ,
                                                        YWLX.ID,
                                                        YXJYR.ID);
                            END IF;
                        END LOOP;
                    END LOOP;
                    --R33
                ELSIF (V_BH = 'R33') THEN
                    --月份间隔总数
                    V_TIME := 0;
                    SELECT ABS(MONTHS_BETWEEN(V_QSRQ, V_QSJS)) INTO V_JGYFS FROM DUAL;
                    FOR MONTH IN (SELECT REGEXP_SUBSTR(V_YF, '[^,]+', 1, ROWNUM) YF
                                    FROM DUAL
                                  CONNECT BY ROWNUM <=
                                             LENGTH(REGEXP_REPLACE(V_YF, '[^,]', NULL)) + 1) LOOP
                        IF (V_TIME = 0) THEN
                            V_I := 0;
                        ELSE
                            V_I := MONTH.YF;
                        END IF;
                        WHILE (V_I <= V_JGYFS) LOOP
                            --取得开始月份+I月份+日
                            SELECT TO_DATE(TO_CHAR(ADD_MONTHS(V_QSRQ, V_I), 'YYYYMM') || V_RQ,
                                           'YYYYMMDD')
                              INTO V_DATE
                              FROM DUAL;
                            IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                                --交易日长度和节假日处理
                                PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                        O_NOTE,
                                                        V_DATE,
                                                        I_NEWDDGZ,
                                                        YWLX.ID,
                                                        YXJYR.ID);
                            END IF;
                            V_TIME := 1;
                            V_I    := V_I + TO_NUMBER(MONTH.YF);
                        END LOOP;
                    END LOOP;
                    --R41、R42
                ELSIF (V_BH = 'R41' OR V_BH = 'R42' OR V_BH = 'R25') THEN
                    --取得区间内的所有固定星期几的日期根据月份排序，再取第几个星期
                    --取得年月，循环
                    FOR MONTH IN (SELECT YYYYMM
                                    FROM (SELECT TO_CHAR(ADD_MONTHS(V_QSJS, - (ROWNUM - 1)),
                                                         'YYYYMM') YYYYMM
                                            FROM DUAL
                                          CONNECT BY ROWNUM <
                                                     MONTHS_BETWEEN(V_QSJS, V_QSRQ) + 2) C
                                   WHERE INSTR(',' || V_YF || ',',
                                               ',' || SUBSTR(C.YYYYMM, 5, 2) || ',') > 0
                                   ORDER BY C.YYYYMM) LOOP
                        FOR PDAY IN (SELECT REGEXP_SUBSTR(V_RQ, '[^,]+', 1, ROWNUM) RQ
                                       FROM DUAL
                                     CONNECT BY ROWNUM <=
                                                LENGTH(REGEXP_REPLACE(V_RQ, '[^,]', NULL)) + 1) LOOP
                            FOR XQ IN (SELECT P.XQ
                                         FROM (SELECT ROWNUM R, XQ
                                                 FROM (SELECT W.XQ
                                                         FROM (SELECT XQY + (PDAY.RQ - 1) XQ
                                                                 FROM TPIF_JYRL_GZR) W
                                                        WHERE TO_CHAR(W.XQ, 'YYYYMMDD') LIKE
                                                              MONTH.YYYYMM || '%'
                                                        ORDER BY XQ) C) P
                                        WHERE INSTR(',' || V_XQ || ',', ',' || P.R || ',') > 0) LOOP
                                V_DATE := XQ.XQ;
                                IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                                    --交易日长度和节假日处理
                                    PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                            O_NOTE,
                                                            V_DATE,
                                                            I_NEWDDGZ,
                                                            YWLX.ID,
                                                            YXJYR.ID);
                                END IF;
                            END LOOP;
                        END LOOP;
                    END LOOP;
                    --20161222 王大一
                    --R50==>R54
                ELSIF (V_BH = 'R50' OR V_BH = 'R51' OR V_BH = 'R52' OR V_BH = 'R53' OR
                      V_BH = 'R54') THEN
                    --R50 成立日
                    IF V_BH = 'R50' THEN
                        V_SQL := 'SELECT TO_DATE(CLRQ,''YYYYMMDD'') RQ FROM TPIF_CPDM WHERE CPID=' ||
                                 V_CPID;
                    END IF;
                    --R51 一次清盘日
                    IF V_BH = 'R51' THEN
                        V_SQL := 'SELECT TO_DATE(QPQYDJR ,''YYYYMMDD'') RQ FROM TPIF_CPDM_GL_QYFA WHERE CPID=' ||
                                 V_CPID;
                    END IF;
                    --R52 终止日
                    IF V_BH = 'R52' THEN
                        V_SQL := 'SELECT TO_DATE(DQRQ,''YYYYMMDD'') RQ FROM TPIF_CPDM WHERE CPID=' ||
                                 V_CPID;
                    END IF;
                    --R53 业绩报酬计提日
                    IF V_BH = 'R53' THEN
                        V_SQL := 'SELECT RQ FROM TPIF_JYRL WHERE JYRLX=12 AND CPID=' ||
                                 V_CPID;
                    END IF;
                    --R54 开放日
                    IF V_BH = 'R54' THEN
                        V_SQL := 'SELECT RQ FROM TPIF_JYRL WHERE JYRLX IN (2,7) AND CPID=' ||
                                 V_CPID;
                    END IF;
                    OPEN RTN_CUR FOR V_SQL;
                    LOOP
                        FETCH RTN_CUR
                            INTO V_DATE;
                        EXIT WHEN RTN_CUR%NOTFOUND;
                        --交易日长度和节假日处理
                        PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                O_NOTE,
                                                V_DATE,
                                                I_NEWDDGZ,
                                                YWLX.ID,
                                                YXJYR.ID);
                    END LOOP;
                    --R55 成立日期的每隔N天的对日
                ELSIF (V_BH = 'R55') THEN
                    IF V_CLRQ IS NULL THEN
                        RETURN;
                    END IF;
                    V_I := 0;
                    LOOP
                        V_I := V_I + 1;
                        SELECT V_CLRQ + V_I * V_RQ INTO V_DATE FROM DUAL;
                        EXIT WHEN V_DATE > V_QSJS;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;

                    END LOOP;

                    --R56 成立日期及每N个月对日
                ELSIF (V_BH = 'R56') THEN
                    IF V_CLRQ IS NULL THEN
                        RETURN;
                    END IF;
                    V_I := -1;
                    LOOP
                        V_I := V_I + 1;
                        SELECT ADD_MONTHS(V_CLRQ, V_I * V_YF) INTO V_DATE FROM DUAL;
                        EXIT WHEN V_DATE > V_QSJS;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;

                    --R57 成立日期及每年对日
                ELSIF (V_BH = 'R57' OR V_BH = 'R58') THEN
                    IF V_CLRQ IS NULL THEN
                        RETURN;
                    END IF;
                    V_I := -1;
                    LOOP
                        V_I := V_I + 1;
                        SELECT ADD_MONTHS(V_CLRQ, V_I * 12) INTO V_DATE FROM DUAL;
                        EXIT WHEN V_DATE > V_QSJS;
                        IF (V_DATE BETWEEN V_QSRQ AND V_QSJS) THEN
                            --交易日长度和节假日处理
                            PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                    O_NOTE,
                                                    V_DATE,
                                                    I_NEWDDGZ,
                                                    YWLX.ID,
                                                    YXJYR.ID);
                        END IF;
                    END LOOP;
                
                ELSIF V_BH = 'R01' THEN
                    FOR X IN (SELECT *
                                FROM TPIF_JYRL_GZJL_YWRQ
                               WHERE TPIF_JYRL_GZJL_ID = I_NEWDDGZ
                               ORDER BY YWFQRQ) LOOP
                        --交易日长度和节假日处理
                        PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                                O_NOTE,
                                                X.YWFQRQ,
                                                I_NEWDDGZ,
                                                YWLX.ID,
                                                YXJYR.ID);
                    END LOOP;
                END IF;
            END LOOP;
        ELSE

            --关联交易日处理
            --根据业务类型循环
            FOR YWLX IN (SELECT REGEXP_SUBSTR(YXJYR.YWLX, '[^;]+', 1, ROWNUM) ID
                           FROM DUAL
                         CONNECT BY ROWNUM <=
                                    LENGTH(REGEXP_REPLACE(YXJYR.YWLX, '[^;]', NULL)) + 1) LOOP
                --关联日期刷入
                FOR GLR IN (SELECT DISTINCT FUNC_PIF_JYRL_QJGGZR(RQ, YXJYR.GLRGX) RQ
                              FROM TPIF_JYRL
                             WHERE INSTR(';' || GZJL || ';', ';' || I_NEWDDGZ || ';') > 0
                               AND JYRLX = V_YXJYR
                             ORDER BY RQ) LOOP
                    PRO_PIF_JYRL_JYRCDJJRCL(O_CODE,
                                            O_NOTE,
                                            GLR.RQ,
                                            I_NEWDDGZ,
                                            YXJYR.YWLX,
                                            YXJYR.ID);
                END LOOP;
            END LOOP;
        END IF;

        IF (V_ZDGL = 0) THEN
            IF (O_CODE = 1) THEN
                UPDATE TPIF_JYRL_GZJL
                   SET YSNF = DECODE(YSNF,
                                     '',
                                     SUBSTR(TO_CHAR(SYSDATE, 'YYYYMMDD'), 0, 4),
                                     YSNF + 1)
                 WHERE ID = I_NEWDDGZ;
            END IF;
            COMMIT;
            RETURN;
        END IF;
    END LOOP;
    IF (O_CODE = 1) THEN
        UPDATE TPIF_JYRL_GZJL SET YSNF = DECODE(YSNF, '', V_JJNF) WHERE ID = I_NEWDDGZ;
    END IF;
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JYRL_SCJYRL;
/

