create PROCEDURE PRO_PIF_JYRL_GZJLSC(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    I_GZJL IN NUMBER, --规则记录
                                                    I_USER IN NUMBER --用户ID[-1：表示审核(清盘时用),-2:删除生成日历和已刷年份，保存规则记录]
                                                    ) IS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：规则记录删除

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-07-21     V1.0      谢莉莉             创建
        2016-10-19     V2.0      王大一             托管系统迁移改造接入产品中心
     *********************************************************************************************************************/
    --V_YXJYR VARCHAR2(100); --运行交易日
    V_QPKS DATE; --清盘开始日
    V_CPID NUMBER; --产品ID
BEGIN
    O_CODE := 1;
    O_NOTE := '';

    --取得运行交易日
    SELECT CPID, QJQS INTO V_CPID, V_QPKS FROM TPIF_JYRL_GZJL WHERE ID = I_GZJL;
    --取得该产品的所有规则记录
    FOR GZJL IN (SELECT ID
                   FROM TPIF_JYRL_GZJL
                  WHERE (CPID = V_CPID AND ID != I_GZJL AND I_USER = -1)
                     OR (ID = I_GZJL AND I_USER != -1)) LOOP

        --将交易日历保存至备份表
        INSERT INTO TPIF_JYRL_BF
            (ID, ZBID, RQ, CPID, CPDM, JYRLX, YWLX, GZJL, BFR, BFSJ)
            SELECT LIVEBOS.FUNC_NEXTID('TPIF_JYRL_BF'),
                   ID,
                   RQ,
                   CPID,
                   CPDM,
                   JYRLX,
                   YWLX,
                   GZJL.ID,
                   I_USER,
                   SYSDATE
              FROM TPIF_JYRL
             WHERE (RQ >= V_QPKS AND I_USER = -1 AND
                   INSTR(';' || GZJL || ';', ';' || GZJL.ID || ';') > 0)
                OR (INSTR(';' || GZJL || ';', ';' || GZJL.ID || ';') > 0 AND I_USER != -1)
             ORDER BY RQ;
        --删除交易日历中规则记录为I_GZJL的数据
        DELETE FROM TPIF_JYRL
         WHERE (RQ >= V_QPKS AND I_USER = -1 AND GZJL = TO_CHAR(GZJL.ID))
            OR (GZJL = TO_CHAR(GZJL.ID) AND I_USER != -1);
        --删除交易日历中规则记录包含I_GZJL的数据
        UPDATE TPIF_JYRL
           SET GZJL = RTRIM(LTRIM(REPLACE(';' || GZJL || ';', ';' || GZJL.ID || ';', ';'),
                                  ';'),
                            ';')
         WHERE (RQ >= V_QPKS AND I_USER = -1 AND INSTR(GZJL, ';' || GZJL.ID || ';') > 0)
            OR (INSTR(';' || GZJL || ';', ';' || GZJL.ID || ';') > 0 AND I_USER != -1);

        --修改已刷年份
        IF (I_USER = -1) THEN
            UPDATE TPIF_JYRL_GZJL
               SET YSNF = SUBSTR(TO_CHAR(QJJS, 'YYYYMMDD'), 0, 4)
             WHERE ID = GZJL.ID;
        END IF;
    END LOOP;

    IF (I_USER >= 0) THEN
        --删除规则记录
        DELETE FROM TPIF_JYRL_GZJL WHERE ID = I_GZJL;
        --规则记录备份表处理
        UPDATE TPIF_JYRL_GZJLBF
           SET CZJL = CZJL || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '[用户ID:' ||
                      I_USER || ']==>删除'
         WHERE ID = I_GZJL;
    END IF;

    IF (I_USER = -2) THEN
        UPDATE TPIF_JYRL_GZJL SET YSNF = '' WHERE ID = I_GZJL;
    END IF;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JYRL_GZJLSC;
/

