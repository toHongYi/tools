create PROCEDURE PRO_PIF_YYGL_SJ_CPGJSJ(O_CODE OUT NUMBER,
                                                     O_NOTE OUT VARCHAR2,
                                                     I_RZLX IN NUMBER, --1|日常;2|重做;3|调整
                                                     I_KSRQ IN NUMBER DEFAULT NULL, --开始日期
                                                     I_JSRQ IN NUMBER DEFAULT NULL --结束日期
                                                     ) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：产品发行事件
          I_KSRQ    --开始日期
          I_JSRQ    --结束日期
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
          1)、TPIF_CPCJLX(产品事件类型);
          2)、TPIF_CPSJ(产品事件);
    运行原理：
          1.入参校验
         2.产品发行事件生成。
           2.1判断条件,获取事件类型。
           2.2生成产品事件。
    功能修订：
        简要说明：
          产品发行事件
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
    *********************************************************************************************************************/
    CONST_DYGC_CPFX  CONSTANT VARCHAR2(100) DEFAULT UPPER('PRO_PIF_YYGL_SJ_CPGJSJ'); --产品发行过程编码

    V_LXBM    VARCHAR2(30); --事件类型编码
    V_SJLX    NUMBER(16); --事件类型
    V_KSRQ    NUMBER(8) DEFAULT I_KSRQ; --当前日期
    V_JSRQ    NUMBER(8) DEFAULT I_JSRQ; --当前日期
    V_CURDATE TIMESTAMP; --当前时间
    V_CLSJS   NUMBER(8); --生成事件数
    V_SJCZLX  NUMBER(8); --事件类型对应的操作类型
    cursor cur is select * from TPIF_CPSJLX A where A.DYGC='PRO_PIF_YYGL_SJ_CPGJSJ';
BEGIN
    O_CODE := 1;
    O_NOTE := '成功';
    --1.***************************入参校验 ***************************
    --当前变量赋值
    IF V_KSRQ IS NULL THEN
        V_KSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
    END IF;
    IF V_JSRQ IS NULL THEN
        V_JSRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
    END IF;
    --1.1获取产品事件类型
    FOR CUR_LC IN cur LOOP
    
    SELECT A.ID, A.CZLX, A.LXBM
      INTO V_SJLX, V_SJCZLX, V_LXBM
      FROM TPIF_CPSJLX A
     WHERE A.DYGC = 'PRO_PIF_YYGL_SJ_CPGJSJ'
      AND A.LXBM=(CUR_LC.LXBM);
      
    dbms_output.put_line(V_LXBM);    
    dbms_output.put_line(V_SJCZLX);

    --1.2去除已经生成的无效的事件或者任务
    IF V_SJCZLX = 2 THEN
        V_CURDATE := SYSTIMESTAMP;
        DELETE FROM TPIF_CPSJ
         WHERE CPSJLX = V_SJLX;
           --AND SJKSSJ >= TO_DATE(V_KSRQ, 'YYYYMMDD');
        V_CLSJS := SQL%ROWCOUNT; --处理事件数
       /* IF V_CLSJS > 0 THEN
            --处理事件不为0，则记录事件监控日志
            PRO_PIF_YYGL_DJSJSCRZ(O_CODE, --记录日志
                                  O_NOTE,
                                  V_SJLX,
                                  V_KSRQ,
                                  CAST(V_CURDATE AS DATE),
                                  SYSDATE,
                                  1,
                                  V_CLSJS,
                                  V_CLSJS,
                                  FUNC_PIF_TIMESTAMP(SYSTIMESTAMP, V_CURDATE),
                                  '执行成功',
                                  3);
        END IF;*/
    END IF;
    --2.***************************获取事件类型，执行事件调度。***************************
    V_CURDATE := SYSTIMESTAMP;
    --2.1.***************************执行调度过程。***************************
    IF V_LXBM = 'CPTPDH' THEN
    INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               K.CPID,
               V_SJLX,
               K.GGRQ,
               '产品【' || A.CPMC || '】于[' || K.GGRQ ||'] 产品投票大会。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               K.SJLY,
               1
          FROM TPIF_CPDM A,(SELECT CPID,GGRQ,SJLY FROM TPIF_CPGGK WHERE GGBT like '%持有人大会%' GROUP BY (CPID,GGRQ,SJLY)) K
         WHERE K.CPID=A.CPID;

    V_CLSJS := SQL%ROWCOUNT;
    

    END IF;
    
    IF V_LXBM = 'CPFH' THEN
    INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               K.CPID,
               V_SJLX,
               K.GGRQ,
               '产品【' || A.CPMC || '】于[' || K.GGRQ ||'] 产品分红派息。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               K.SJLY,
               1
          FROM TPIF_CPDM A,(SELECT CPID,GGRQ,SJLY FROM TPIF_CPGGK WHERE GGBT like '%分红%' GROUP BY (CPID,GGRQ,SJLY)) K
         WHERE K.CPID=A.CPID;
           
           INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               R.CPID,
               V_SJLX,
               R.RQ,
               '产品【' || A.CPMC || '】于[' || R.RQ ||'] 产品分红派息。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               A.SJLY,
               1
          FROM TPIF_CPDM A,TPIF_JYRL R
         WHERE R.YWLX='11'
           --AND A.CPZTBZ=8
           AND R.CPID=A.CPID;

    V_CLSJS := SQL%ROWCOUNT;

    END IF;
    
    IF V_LXBM = 'JJJLBG' THEN
    INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               K.CPID,
               V_SJLX,
               K.GGRQ,
               '产品【' || A.CPMC || '】于[' || K.GGRQ ||'] 基金经理变更。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               K.SJLY,
               1
          FROM TPIF_CPDM A,(SELECT CPID,GGRQ,SJLY FROM TPIF_CPGGK WHERE GGBT like '%基金经理变更%' GROUP BY (CPID,GGRQ,SJLY)) K
         WHERE K.CPID=A.CPID;

    V_CLSJS := SQL%ROWCOUNT;

    END IF;
    
    IF V_LXBM = 'CPQP' THEN
    INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               K.CPID,
               V_SJLX,
               K.GGRQ,
               '产品【' || A.CPMC || '】于[' || K.GGRQ ||'] 产品清盘。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               K.SJLY,
               1
          FROM TPIF_CPDM A,(SELECT CPID,GGRQ,SJLY FROM TPIF_CPGGK WHERE GGBT like '%清算%' GROUP BY (CPID,GGRQ,SJLY)) K
         WHERE K.CPID=A.CPID;

    V_CLSJS := SQL%ROWCOUNT;

    END IF;
    
    IF V_LXBM = 'CPKF' THEN
    INSERT INTO TPIF_CPSJ
        (ID, CPID, CPSJLX, SJKSSJ, SJMS, SJSCRQ, SJSCSJ, JRCPFL, TZLX, CPXL, CPLY, SFSX)
        SELECT seq_tpif_cpsj.NEXTVAL,
               R.CPID,
               V_SJLX,
               R.RQ,
               '产品【' || A.CPMC || '】于[' || R.RQ ||'] 产品开放。',
               V_KSRQ,
               SYSDATE,
               A.JRCPFL,
               A.TZLB,
               A.CPXL,
               A.SJLY,
               1
          FROM TPIF_CPDM A,(SELECT CPID,RQ FROM TPIF_JYRL WHERE YWLX in(6,7,8) GROUP by CPID,RQ) R
         WHERE R.CPID=A.CPID;

    V_CLSJS := SQL%ROWCOUNT;
    END IF;
    
    END LOOP;
    --2.2.***************************更新事件生成日志。***************************
   /* PRO_PIF_YYGL_DJSJSCRZ(O_CODE,
                          O_NOTE,
                          V_SJLX,
                          V_KSRQ,
                          CAST(V_CURDATE AS DATE),
                          SYSDATE,
                          1,
                          V_CLSJS,
                          V_CLSJS,
                          FUNC_PIF_TIMESTAMP(SYSTIMESTAMP, V_CURDATE),
                          '执行成功',
                          I_RZLX);*/

EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_SJ_CPGJSJ;
/

