create PROCEDURE PCX_PIF_SY_XXGK(O_CODE   OUT NUMBER,
                                            O_NOTE   OUT VARCHAR2,
                                            O_RESULT OUT SYS_REFCURSOR,
                                            I_USERID IN NUMBER) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：首页-消息概况
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                          TYPE  消息类别
                          TOTAL_RECORD_NUM  总记录数
                          ALREADY_DEAL_NUM  已阅/已处理数
                          TIPS  提示信息
                          URL 明细链接URL
  
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        刘浪浪    1.0.1    2015/01/26                   新增
  
  -------------------------------------------------------------------------------------------------*/
  --V_SQL VARCHAR2(4000);

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空!';
    RETURN;
  END IF;

  --1：运营任务

  OPEN O_RESULT FOR
  
    SELECT 1 AS "TYPE",
           '运营任务' AS TYPE_DESC,
           COUNT(1) AS TOTAL_RECORD_NUM,
           SUM(CASE
                 WHEN ZXZT = 0 THEN
                  1
                 ELSE
                  0
               END) AS ALREADY_DEAL_NUM,
           '未完成任务' || SUM(CASE
                            WHEN ZXZT = 0 THEN
                             1
                            ELSE
                             0
                          END) || '个' AS TIPS,
           '/OPERATIONALTASKS/?QUERY_TYPE=2' AS URL
      FROM PIF.TPIF_CPYYRW
     WHERE ZXRY = I_USERID
    
    UNION ALL
    --2：流程提醒
    SELECT 2 AS "TYPE",
           '流程提醒' AS TYPE_DESC,
           RECORD_SUM.TOTAL AS TOTAL_RECORD_NUM,
           NO_DEAL_SUM.TOTAL AS ALREADY_DEAL_NUM,
           '待处理流程' || TO_CHAR(NO_DEAL_SUM.TOTAL) || '个' AS TIPS,
           '/UIProcessor?Table=WORKFLOW_TOTASKS' AS URL
      FROM (SELECT COUNT(1) AS TOTAL
              FROM LIVEBOS.OS_CURRENTSTEP   A,
                   LIVEBOS.OS_WFENTRY       B,
                   LIVEBOS.LBWFCURRENTOWNER D
             WHERE A.ENTRY_ID = B.ID
               AND B.STATE = 1
               AND A.ID = D.STEPID
               AND D.OWNER = I_USERID) NO_DEAL_SUM,
           (SELECT COUNT(1) AS TOTAL
              FROM (SELECT B.ID
                      FROM LIVEBOS.OS_CURRENTSTEP   A,
                           LIVEBOS.OS_WFENTRY       B,
                           LIVEBOS.LBWFCURRENTOWNER D
                     WHERE A.ENTRY_ID = B.ID
                       AND A.ID = D.STEPID
                       AND D.OWNER = 0
                    UNION
                    SELECT id
                      FROM LIVEBOS.OS_WFENTRY
                     WHERE ID IN (SELECT ENTRY_ID
                                    FROM LIVEBOS.OS_HISTORYSTEP
                                   WHERE CALLER = 0))) RECORD_SUM
    
    UNION ALL
    
    --3：站内消息
    
    SELECT 3 AS "TYPE",
           '站内消息' AS TYPE_DESC,
           COUNT(1) AS TOTAL_RECORD_NUM,
           SUM(CASE
                 WHEN NVL(IS_READ, 0) = 0 THEN
                  1
                 ELSE
                  0
               END) AS ALREADY_DEAL_NUM,
           '未读消息' || SUM(CASE
                           WHEN NVL(IS_READ, 0) = 0 THEN
                            1
                           ELSE
                            0
                         END) || '条' AS TIPS,
           '/UIProcessor?Table=VPIF_WDLY' AS URL
      FROM LIVEBOS.LBMESSAGE
     WHERE F_FOLDER = 0
       AND F_OWNER = I_USERID
    
    UNION ALL
    
    --4：风控事件 
    SELECT 4 AS "TYPE",
           '风控事件' AS TYPE_DESC,
           COUNT(1) AS TOTAL_RECORD_NUM,
           sum(case when a.clzt=1 then 1 else 0 end) AS ALREADY_DEAL_NUM,
           '有' || sum(case when a.clzt=1 then 0 else 1 end) || '件风控事件待处理！' AS TIPS,
           '/UIProcessor?Table=vPIF_FKZBJG' AS URL
      FROM PIF.TPIF_FKZBJG a
     WHERE 1=1;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

