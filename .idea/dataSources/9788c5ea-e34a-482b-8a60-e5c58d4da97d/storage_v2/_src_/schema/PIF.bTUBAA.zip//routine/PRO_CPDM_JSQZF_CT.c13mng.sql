create PROCEDURE PRO_CPDM_JSQZF_CT(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2 --返回消息
                                          ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：向TPIF_SMCP表中插入新增的资金户信息清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-11-09    1.0       吴金锋              创建
          2020-12-14    1.1       GAOKUN              修改
                                                      废弃，不用了
  ***********************************************************************/

  V_L INTEGER;
  V_COUNT NUMBER;
  V_JJGLR NUMBER;
  V_ORG_ID NUMBER;
  V_I NUMBER;
  V_A NUMBER;
  V_B NUMBER;
  V_ROWCOUNT_JJH NUMBER :=0;   --新增的经纪户记录数量
  V_ROWCOUNT_DX NUMBER :=0;    --新增的代销记录数量
  V_ROWCOUNT_GX_DX_JJH NUMBER :=0;   --更新业务类型为 代销+经纪户 的数量
  V_ROWCOUNT_XZ_DX_JJH NUMBER :=0;   --新增业务类型为 代销+经纪户 的数量
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --BEGIN
 ---经纪户表的数据判断是否需要导入私募产品表，如果存在客户号则不导入,如果不存在，根据代码进行匹配代销数据，匹配到则置状态为代销+经纪户
 FOR CUR_SRC IN(SELECT * FROM SRC_PIF.DWD_INF_ORGAN_PROD_INFO_DD
                   WHERE TRIM(CLIENT_ID) IS NOT NULL
                     AND ORGAN_PROD_KIND IN('08',   --私募基金
                                            --'12',   --信托产品
                                            --'22',   --上市公司员工持股计划
                                            --'23',   --资产管理计划
                                            '24'    --阿巴马鑫享红系列
                                             )) LOOP

      --CLIENT_ID  客户编号 和  KHBH 比较，如果私募产品表中有客户号就不新增了
      SELECT COUNT(*) INTO V_COUNT FROM TPIF_SMCP A  WHERE TRIM(A.KHBH) = TRIM(CUR_SRC.CLIENT_ID) ;

      IF V_COUNT = 0 THEN   --如果不存在，则需要进一步判断是否代销

         BEGIN   --基金管理人
           SELECT ID INTO V_JJGLR FROM TPIF_JGDM A WHERE TRIM(A.DJBH) = TRIM(CUR_SRC.ORGAN_PRODMANA_CODE) AND ROWNUM=1;
         EXCEPTION WHEN OTHERS THEN
           V_JJGLR := NULL ;
         END;

         SELECT B.ID INTO V_ORG_ID FROM LIVEBOS.LBORGANIZATION B WHERE B.BRANCH_ID=CUR_SRC.BRANCH_NO;  --营业部

         --代码比较，判断是否存在 代销 记录
         SELECT COUNT(1) INTO V_I FROM TPIF_SMCP A WHERE TRIM(A.CPDM) = TRIM(CUR_SRC.ORGAN_PROD_CODE) AND A.YWLX=1;

         --代码比较，判断是否存在 代销+经纪户 记录
         SELECT COUNT(1) INTO V_B FROM TPIF_SMCP A WHERE TRIM(A.CPDM) = TRIM(CUR_SRC.ORGAN_PROD_CODE) AND A.YWLX=3;

         IF V_I = 0 AND V_B = 0 THEN   --不存在则没有 代销 或 代销+经纪户 的记录，新增一条经纪户记录
            V_ROWCOUNT_JJH := V_ROWCOUNT_JJH+1;
             INSERT INTO TPIF_SMCP(  ID,    -- ID
                                KHBH,  -- 客户编号
                                KHRQ,  --开户日期
                                FL,    -- 分类  (?)
                                FGS,   -- 分公司
                                YYB,   -- 营业部
                                YYBDM, -- 营业部ID
                                CPMC,  -- 产品简称
                                CPDM,  -- 产品代码
                                YWLX,  --业务类型 1|代销;2|经纪户;3|代销+经纪户
                                JJGLR, --基金管理人
                                GLRDJBH, --管理人登记编号
                                CLRQ,    --产品成立日期
                                SHZT,    --审核状态  0未审核 2|审核通过
                                SJLY,    --数据来源 1|集中柜台;5|人工录入
                                ZHXGSJ,  --最后修改时间
                                SFCZYNBCP  --是否存在于内部产品，刚进来的产品审核后才进入内部产品，所以最开始为0
                                )
                     VALUES(LIVEBOS.FUNC_NEXTID('TPIF_SMCP'),
                            TRIM(CUR_SRC.CLIENT_ID),
                            NULL,
                            NULL,
                            (SELECT B.FID FROM LIVEBOS.LBORGANIZATION B WHERE B.ID=V_ORG_ID),
                            V_ORG_ID,
                            CUR_SRC.BRANCH_NO,
                            TRIM(CUR_SRC.ORGAN_PROD_NAME),
                            TRIM(CUR_SRC.ORGAN_PROD_CODE),
                            2,
                            V_JJGLR,
                            TRIM(CUR_SRC.ORGAN_PRODMANA_CODE),
                            NULL,
                            0,
                            1,
                            SYSDATE,
                            0
                        );
         ELSIF V_I = 0 AND V_B > 0 THEN
           V_ROWCOUNT_XZ_DX_JJH := V_ROWCOUNT_XZ_DX_JJH+1;
             INSERT INTO TPIF_SMCP(  ID,    -- ID
                                KHBH,  -- 客户编号
                                KHRQ,  --开户日期
                                FL,    -- 分类  (?)
                                FGS,   -- 分公司
                                YYB,   -- 营业部
                                YYBDM, -- 营业部ID
                                CPMC,  -- 产品简称
                                CPDM,  -- 产品代码
                                YWLX,  --业务类型 1|代销;2|经纪户;3|代销+经纪户
                                JJGLR, --基金管理人
                                GLRDJBH, --管理人登记编号
                                CLRQ,    --产品成立日期
                                SHZT,    --审核状态  0未审核 2|审核通过
                                SJLY,    --数据来源 1|集中柜台;5|人工录入
                                ZHXGSJ,  --最后修改时间
                                SFCZYNBCP  --是否存在于内部产品，刚进来的产品审核后才进入内部产品，所以最开始为0
                                )
                     VALUES(LIVEBOS.FUNC_NEXTID('TPIF_SMCP'),
                            TRIM(CUR_SRC.CLIENT_ID),
                            NULL,
                            NULL,
                            (SELECT B.FID FROM LIVEBOS.LBORGANIZATION B WHERE B.ID=V_ORG_ID),
                            V_ORG_ID,
                            CUR_SRC.BRANCH_NO,
                            TRIM(CUR_SRC.ORGAN_PROD_NAME),
                            TRIM(CUR_SRC.ORGAN_PROD_CODE),
                            3,
                            V_JJGLR,
                            CUR_SRC.ORGAN_PRODMANA_CODE,
                            NULL,
                            0,
                            1,
                            SYSDATE,
                            0
                        );
         ELSE
           V_ROWCOUNT_GX_DX_JJH :=V_ROWCOUNT_GX_DX_JJH+1;
           UPDATE TPIF_SMCP
           SET JJGLR=V_JJGLR,
               GLRDJBH=TRIM(CUR_SRC.ORGAN_PRODMANA_CODE),
               KHBH=TRIM(CUR_SRC.CLIENT_ID),
               FGS=(SELECT B.FID FROM LIVEBOS.LBORGANIZATION B WHERE B.ID=V_ORG_ID),
               YYB=V_ORG_ID,
               YYBDM=CUR_SRC.BRANCH_NO,
               YWLX=3,    --代销+经纪户
               SHZT=0,
               ZHXGSJ=SYSDATE
           WHERE TRIM(CPDM)=TRIM(CUR_SRC.ORGAN_PROD_CODE) AND YWLX=1;
         END IF;
      END IF ;
  END LOOP ;

 --对于柜台代销产品，首先判断是否已经存在该产品代销数据，存在则不进行任何操作，不存在就继续判断是否存在相应的经纪户数据，存在则更新，不存在就新增。
   FOR CUR IN (SELECT * FROM SRC_PIF.DWD_PRD_PRODCODE_DD T WHERE PRODCODE_TYPE='j'  AND PROD_BEGIN_DATE>=20190101) LOOP

    SELECT COUNT(1)
      INTO V_L
      FROM TPIF_SMCP
     WHERE TRIM(CPDM)=TRIM(CUR.PROD_CODE) AND (YWLX=1 OR YWLX=3);

    IF V_L = 0 THEN    --不存在则继续判断是否有相应的经纪户数据，经纪户的表存在代码，可以根据代码判断，EXCEL表的没代码，根据名字判断
      SELECT COUNT(1) INTO V_A FROM TPIF_SMCP WHERE (TRIM(CPDM)=TRIM(CUR.PROD_CODE) AND YWLX=2)
        OR (TRIM(CPMC)=TRIM(CUR.PROD_NAME) OR TRIM(CPMC)=TRIM(CUR.PRODALIAS_NAME));
      IF V_A=0 THEN
         V_ROWCOUNT_DX :=V_ROWCOUNT_DX+1;
         INSERT INTO TPIF_SMCP
           (ID, CPMC, CPDM, YWLX, SHZT, SJLY, ZHXGSJ,SFCZYNBCP)
         VALUES
           (LIVEBOS.FUNC_NEXTID('TPIF_SMCP'),
            CUR.PRODALIAS_NAME,
            TRIM(CUR.PROD_CODE),
            1,  --代销
            0,
            1,
            SYSDATE,
            0);
      ELSE  --存在则更新业务类型
        V_ROWCOUNT_GX_DX_JJH :=V_ROWCOUNT_GX_DX_JJH+1;
        UPDATE TPIF_SMCP
        SET CPDM=CUR.PROD_CODE,
            YWLX=3,
            SHZT=0,
            ZHXGSJ=SYSDATE
        WHERE  (TRIM(CPDM)=CUR.PROD_CODE AND YWLX=2)
        OR (TRIM(CPMC)=TRIM(CUR.PROD_NAME) OR TRIM(CPMC)=TRIM(CUR.PRODALIAS_NAME));
      END IF;
    END IF;
  END LOOP;

    --通过资金账户表-客户编号 更新开户日期 和 账户状态
    /*0 0 正常
      1 1 冻结
      2 2 挂失
      3 3 销户
      4 4 未确定
      5 5 休假
      6 6 VIP客户
      7 A 休眠待报送
      8 B 休眠待撤销
      9 C 中登休眠
    */

  MERGE INTO TPIF_SMCP M
  USING(SELECT FUND_ACCOUNT,OPEN_DATE,FUNDACCT_STATUS FROM SRC_PIF.DWD_PAR_FUND_ACCOUNT_BASE_DD) N
  ON( M.KHBH = N.FUND_ACCOUNT )
  WHEN MATCHED THEN UPDATE
    SET M.KHRQ = N.OPEN_DATE,
        M.ZHZT = DECODE(TRIM(FUNDACCT_STATUS),'0',0,'1',1,'2',2,'3',3,'4',4,'5',5,'6',6,'A',7,'B',8,'C',9);

  --代销产品账户状态 空
  UPDATE TPIF_SMCP
  SET ZHZT=10
  WHERE YWLX=1;


  --经纪户和柜台代销产品有代码，excel导入的没有代码，先根据代码匹配朝阳永续数据，
  MERGE INTO TPIF_SMCP M
  USING(SELECT FUND_ID,
              REG_CODE,
              TO_CHAR(FOUNDATION_DATE,'YYYYMMDD') AS CLRQ,
              DECODE(FUND_STATUS,'存续中',1,0) AS CPYXZT,
              FUND_NAME,
              FUND_FULL_NAME,
              FUND_TYPE_STRATEGY_LEVEL1
          FROM SRC_PIF.T_FUND_INFO
         WHERE  TRIM(REG_CODE) IS NOT NULL
         AND TRIM(REG_CODE) NOT IN( SELECT TRIM(REG_CODE)
                                           FROM SRC_PIF.T_FUND_INFO
                                         WHERE TRIM(REG_CODE) IS NOT NULL
                                          GROUP BY REG_CODE
                                          HAVING COUNT(*)>1 ) ) N
  ON(M.CPDM = N.REG_CODE)
  WHEN MATCHED THEN UPDATE SET
        M.DYCPID = NVL(M.DYCPID,N.FUND_ID),
        M.CLRQ = NVL(M.CLRQ,N.CLRQ),
        M.CPYXZT =  NVL(M.CPYXZT,N.CPYXZT),
        M.ZHXGR = 0,
        M.YJCL = DECODE(TRIM(FUND_TYPE_STRATEGY_LEVEL1),'股票策略','13','宏观策略','53','多策略','47','债券基金','35','管理期货','39','套利策略','23','其他策略','54','事件驱动','13','组合基金','50');

  --后根据名称 关联市场私募基金 并更新 对应产品全称、成立日期、产品运行状态
  MERGE INTO TPIF_SMCP M
  USING(SELECT FUND_ID,
              TO_CHAR(FOUNDATION_DATE,'YYYYMMDD') AS CLRQ,
              DECODE(FUND_STATUS,'存续中',1,0) AS CPYXZT,
              FUND_NAME,
              FUND_FULL_NAME,
              FUND_TYPE_STRATEGY_LEVEL1
          FROM SRC_PIF.T_FUND_INFO
         WHERE  TRIM(REG_CODE) IS NOT NULL
         AND TRIM(REG_CODE) NOT IN( SELECT TRIM(REG_CODE)
                                           FROM SRC_PIF.T_FUND_INFO
                                         WHERE TRIM(REG_CODE) IS NOT NULL
                                          GROUP BY REG_CODE
                                          HAVING COUNT(*)>1 ) ) N
  ON(M.CPMC = N.FUND_NAME OR  M.CPMC = N.FUND_FULL_NAME )
  WHEN MATCHED THEN UPDATE SET
        M.DYCPID = NVL(M.DYCPID,N.FUND_ID),
        M.CLRQ = NVL(M.CLRQ,N.CLRQ),
        M.CPYXZT =  NVL(M.CPYXZT,N.CPYXZT),
        M.ZHXGR = 0,
        M.YJCL = DECODE(TRIM(FUND_TYPE_STRATEGY_LEVEL1),'股票策略','13','宏观策略','53','多策略','47','债券基金','35','管理期货','39','套利策略','23','其他策略','54','事件驱动','13','组合基金','50');

  --对应产品全称不为空，但是基金管理人为空，则根据关联补充基金管理人
  UPDATE TPIF_SMCP A
     SET A.JJGLR =
         (SELECT B.ID
            FROM TPIF_JGDM B
           WHERE B.JGJC = (SELECT C.FUND_MANAGER_NOMINAL
                           FROM SRC_PIF.T_FUND_INFO C
                          WHERE C.FUND_ID = A.DYCPID))
   WHERE A.DYCPID IS NOT NULL
     AND A.JJGLR IS NULL
     AND A.SHZT = 0;
  
        
 --对于部分存在基金管理人，但是管理人登记编号为空的记录，根据基金管理人更新登记编号
  UPDATE TPIF_SMCP A
  SET A.GLRDJBH = (SELECT TRIM(B.DJBH) FROM TPIF_JGDM B WHERE B.ID=A.JJGLR)
  WHERE A.JJGLR IS NOT NULL AND A.GLRDJBH IS NULL;    
  
  COMMIT;
  O_CODE := 1;
  O_NOTE := 'TPIF_SMCP 表清洗成功,插入'||V_ROWCOUNT_JJH||'条经纪户记录,插入'||V_ROWCOUNT_DX||'条代销记录,插入'||V_ROWCOUNT_XZ_DX_JJH||'条代销+经纪户记录,更新'||V_ROWCOUNT_GX_DX_JJH||'条记录的业务类型';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_SMCP 表清洗,未知错误'
                ELSE
                 'TPIF_SMCP 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

