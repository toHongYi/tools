create PROCEDURE PRO_PIF_CPWDMX_CZRZDJ(O_CODE OUT NUMBER, --返回值
                                                      O_NOTE OUT VARCHAR2, --返回消息
                                                      I_USER IN INTEGER, --操作人
                                                      I_IP   IN VARCHAR2, --操作IP
                                                      I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                                      I_ID   IN INTEGER --操作ID
                                                      ) IS
    /*
    **功能说明：平台管理
    **创建人：刘浪浪
    **创建日期：2014-09-17
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **刘浪浪     1.0.1     2014/10/22   创建
    **刘浪浪     1.0.2     2014/12/23   增加对文档明细中排序的校验
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_WDMB%ROWTYPE; --表单记录
    V_OBJ1  TPIF_CPWDMX%ROWTYPE;
    --V_SCBZ    INTEGER; --日志删除标识
    V_OPER    VARCHAR2(200); --操作方法
    V_FDETAIL VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    SELECT *
      INTO V_OBJ
      FROM TPIF_WDMB
     WHERE ID = (SELECT WDMB FROM TPIF_CPWDMX WHERE ID = I_ID);

    SELECT * INTO V_OBJ1 FROM TPIF_CPWDMX WHERE ID = I_ID;

    SELECT '[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除') || ']_' || V_OBJ.MBMC ||
           '的对应明细'
      INTO V_FDETAIL
      FROM DUAL;

    SELECT DECODE(I_OPER, 0, 'TPIF_CPWDMX_XZ', 1, 'TPIF_CPWDMX_XG', 2, 'TPIF_CPWDMX_SC')
      INTO V_OPER
      FROM DUAL;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';

    IF I_OPER = 0 THEN
        --//:新增
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPWDMX
         WHERE WDMB = V_OBJ1.WDMB
           AND PX = NVL(V_OBJ1.PX, -1);
        IF V_COUNT > 1 THEN
            O_NOTE := '当前模板中已存在[排序]为[' || V_OBJ1.PX || ']的记录!';
            RETURN;
        END IF;

        IF V_OBJ1.PX <= 0 THEN
            O_NOTE := '排序字段必须大于0!';
            RETURN;
        END IF;

    END IF;

    IF I_OPER = 1 THEN
        --//:修改
        /*SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPWDMX
         WHERE WDMB = V_OBJ1.WDMB
           AND PX = NVL(V_OBJ1.PX, -1);
        IF V_COUNT > 1 THEN
            O_NOTE := '当前模板中已存在[排序]为[' || V_OBJ1.PX || ']的记录!';
            RETURN;
        END IF;*/

        IF V_OBJ1.PX <= 0 THEN
            O_NOTE := '排序字段必须大于0!';
            RETURN;
        END IF;

    END IF;
  /*
    --RECORD
    CRMII.PRO_CZRZDJ(O_CODE,
                     O_NOTE,
                     I_USER,
                     'TPIF_CPWDMX',
                     V_OPER,
                     I_ID,
                     V_FDETAIL,
                     I_IP,
                     '26004',
                     '');
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    */
    
    /*--记录基础日志
    IF I_OPER = 2 THEN
        V_SCBZ := 1;
    ELSE
        V_SCBZ := 0;
    END IF;
    PRO_PIF_JCCZRZ(O_CODE,
                   O_NOTE,
                   I_USER,
                   I_IP,
                   'TPIF_PT',
                   V_OPER,
                   I_ID,
                   V_FDETAIL,
                   1,
                   V_SCBZ,
                   '');*/
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE WHEN O_NOTE IS NULL THEN '未知错误' ELSE '在 ' || O_NOTE || ' 时出现异常' END) || ':' || SQLERRM;
END PRO_PIF_CPWDMX_CZRZDJ;
/

