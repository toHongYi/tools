create PROCEDURE PCX_PIF_CPJM_LBZSZD(O_CODE        OUT NUMBER,
                                                O_NOTE        OUT VARCHAR2,
                                                O_RESULT      OUT SYS_REFCURSOR,
                                                I_PROD_TYPE   IN VARCHAR2, --产品系列
                                                I_TEMPLATE_ID IN NUMBER --模版ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品产品列表-列表展示字段
  所属用户：PIF
  概要说明：查询当前登录人产品查询条件解析.
               I_PROD_TYPE       IN NUMBER, --产品分类ID
               I_TEMPLATE_ID         IN NUMBER  --模版ID
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_HASRECORDSET  IN,OUT参数.整型,返回1,表示有返回O_RESULT,否则没有O_RESULT(为空值)
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品列表需要显示的字段.
  
        1.查询产品列表需要显示的字段,供前端查询展示.
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020     4.0.0.1   GUONANHUA           新增.
  *********************************************************************************************************************/
  V_SQL_QUERY VARCHAR2(32767);

  V_ERRMSG    VARCHAR2(300); --错误信息
  V_COUNT     NUMBER(16);
  V_FROMTABLE VARCHAR2(500); --数据源表
  V_SQL_HFXJY VARCHAR2(5000); --合法性验证
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_TEMPLATE_ID IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【模版ID】';
    RETURN;
  END IF;

  --数据源赋值
  IF I_PROD_TYPE IS NULL THEN
    V_FROMTABLE := '  TPIF_TYMBLBPZ T, PIF.TPIF_TYMBDY H, PIF.TPIF_FIELD A
              WHERE T.TYMB = H.ID
               and t.cpsx = a.id
               and t.ywdx = a.tablename
               AND T.TYMB = ' || I_TEMPLATE_ID || '
               and t.zt = 1
               and h.mbzt = 1 order by T.xssx';
  ELSE
    V_FROMTABLE := '  TPIF_FLMBLBPZ T, PIF.TPIF_FLMBDY H, PIF.TPIF_FIELD A
              WHERE T.FLMB = H.ID
               and t.cpsx = a.id
               and t.ywdx = a.tablename
               AND T.FLMB = ' || I_TEMPLATE_ID || '
               and t.zt = 1
               and h.mbzt = 1
              -- AND exists( select 1 from table(split(''' ||
                   I_PROD_TYPE || ''','';''))  where instr('';''||h.CPDL||'';'','';''||column_value||'';'')>0 )
               order by T.xssx';
  END IF;

  --验证是否存在适用于当前登录人的通用模版
  V_SQL_HFXJY := ' SELECT COUNT(1) FROM ' || V_FROMTABLE;
  EXECUTE IMMEDIATE V_SQL_HFXJY
    INTO V_COUNT;

  IF V_COUNT = 0 THEN
    O_CODE := -2;
    O_NOTE := '错误：没有此条件模版！';
    RETURN;
  END IF;

  V_SQL_QUERY := 'SELECT t.xssx display_order, a.name field_id, t.xsmc display_name  from ' ||
                 V_FROMTABLE;

  --DBMS_OUTPUT.PUT_LINE('V_SQL:' || V_SQL_QUERY);

  OPEN O_RESULT FOR V_SQL_QUERY;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := ' 查询失败 ';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT ' 异常信息： ' || V_ERRMSG FROM DUAL;
  
  
END PCX_PIF_CPJM_LBZSZD;
/

