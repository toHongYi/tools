create PROCEDURE PRO_PIF_CPMDDSTS(O_CODE OUT NUMBER,
                                             O_NOTE  OUT VARCHAR2
                                              ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：获取产品摸底定时推送信息，O_RESULT
                MDID:摸底任务id，TPIF_CPMD.ID
                YHIDS:需推送的用户ID串，逗号间隔
                TSSJ:推送时间，截止日前9:00,15:00各一次，截止日当天9点起到摸底结束每小时提醒一次
      语法信息：
           输入参数：   无
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
                        O_RESULT
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-12-13    1.0     hanqn                 XZ
  ***********************************************************************/
V_SQL VARCHAR2(4000);
V_TSSJ VARCHAR2(200);
BEGIN
  --INIT
  
  O_CODE:=1;
  O_NOTE:='成功';
  DELETE FROM  TPIF_CPMDDSTS ;
  COMMIT;
  
  IF TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))<8 THEN
  RETURN;
  END IF;
  
  --9点15点各推一次
  IF TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))=8  THEN
    
     V_TSSJ:=TO_CHAR(SYSDATE,'YYYYMMDD')||'090000';
     V_SQL:='SELECT ROWNUM AS ID,ID AS MDID,YHIDS, TO_DATE('||V_TSSJ||',''YYYYMMDDHH24MISS'') AS TSSJ FROM 
             (SELECT S.ID, FUNC_GET_MDYYBYHIDS(S.ORGIDS) AS YHIDS
                FROM (SELECT ID,(SELECT to_char(wm_concat(DISTINCT fzjg))
                                   FROM tpif_mdkh
                                  WHERE mdid = a.id
                                    AND wczt = 0
                                    AND fzjg IS NOT NULL) AS orgids
                        FROM tpif_cpmd a 
                       WHERE a.rwfp=2 and a.mdkssj < SYSDATE AND trunc(a.mdjssj) > SYSDATE) S 
                WHERE S.ORGIDS IS NOT NULL 
             UNION ALL
             SELECT ID AS MDID,YHIDS  FROM 
               (SELECT S.ID, FUNC_GET_MDYYBYHIDS(S.ORGIDS) AS YHIDS
                  FROM (SELECT ID,(SELECT to_char(wm_concat(DISTINCT fzjg))
                          FROM tpif_mdkh
                         WHERE mdid = a.id AND wczt = 0
                           AND fzjg IS NOT NULL) AS orgids
                 FROM tpif_cpmd a
              WHERE  trunc(a.mdjssj) =TRUNC(SYSDATE) AND a.mdjssj>TO_DATE('||V_TSSJ||',''YYYYMMDDHH24MISS'') and a.rwfp=2) S WHERE S.ORGIDS IS NOT NULL)
                WHERE YHIDS IS NOT NULL)
               WHERE YHIDS IS NOT NULL 
              ';
  
  ELSIF TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))=14  THEN
    
      V_TSSJ:=TO_CHAR(SYSDATE,'YYYYMMDD')||'150000';
      V_SQL:='SELECT ROWNUM AS ID,ID AS MDID,YHIDS, TO_DATE('||V_TSSJ||',''YYYYMMDDHH24MISS'') AS TSSJ FROM 
          (SELECT S.ID, FUNC_GET_MDYYBYHIDS(S.ORGIDS) AS YHIDS
             FROM (SELECT ID,(SELECT to_char(wm_concat(DISTINCT fzjg))
                                FROM tpif_mdkh
                               WHERE mdid = a.id
                                 AND wczt = 0
                                 AND fzjg IS NOT NULL) AS orgids
                     FROM tpif_cpmd a
                    WHERE a.mdkssj < SYSDATE AND trunc(a.mdjssj) > SYSDATE and a.rwfp=2) S 
             WHERE S.ORGIDS IS NOT NULL 
          UNION ALL
          SELECT ID AS MDID,YHIDS  FROM 
            (SELECT S.ID, FUNC_GET_MDYYBYHIDS(S.ORGIDS) AS YHIDS
               FROM (SELECT ID,(SELECT to_char(wm_concat(DISTINCT fzjg))
                       FROM tpif_mdkh
                      WHERE mdid = a.id AND wczt = 0
                        AND fzjg IS NOT NULL) AS orgids
              FROM tpif_cpmd a
           WHERE  trunc(a.mdjssj) =TRUNC(SYSDATE) AND a.mdjssj>TO_DATE('||V_TSSJ||',''YYYYMMDDHH24MISS'') and a.rwfp=2) S WHERE S.ORGIDS IS NOT NULL)
             WHERE YHIDS IS NOT NULL)
            WHERE YHIDS IS NOT NULL 
           ';
  ELSIF TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))>7 THEN --摸底截止日9点起到结束前每小时提醒一次
        V_TSSJ:=to_char(SYSDATE,'yyyymmdd')||to_char(SYSDATE+1/24,'hh24');
        V_SQL:='SELECT ROWNUM AS ID,ID AS MDID,YHIDS,TO_DATE('||V_TSSJ||',''YYYYMMDDHH24MISS'') AS TSSJ  FROM 
            (SELECT S.ID, FUNC_GET_MDYYBYHIDS(S.ORGIDS) AS YHIDS
               FROM (SELECT ID,(SELECT to_char(wm_concat(DISTINCT fzjg)) 
                       FROM tpif_mdkh
                      WHERE mdid = a.id AND wczt = 0
                        AND fzjg IS NOT NULL) AS orgids
              FROM tpif_cpmd a
           WHERE  trunc(a.mdjssj) =TRUNC(SYSDATE) AND a.mdjssj>TO_DATE('||V_TSSJ||',''YYYYMMDDHH24'') and a.rwfp=2) S WHERE S.ORGIDS IS NOT NULL)
             WHERE YHIDS IS NOT NULL';
  ELSE 
    RETURN; 
  END IF;    
  DBMS_OUTPUT.put_line(V_SQL);        
  V_SQL:='INSERT INTO TPIF_CPMDDSTS(ID,MDID,YHIDS,TSSJ)'||V_SQL;
  --插入产品摸底定时推送表
  execute immediate V_SQL;
  
  --更新摸底内容为产品代码+名称
  UPDATE TPIF_CPMDDSTS t SET nr =(SELECT DISTINCT a.cpdm||a.cpmc FROM tpif_cpdm a,tpif_cpmd b WHERE b.id=t.mdid AND a.id=b.cpid); 
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE:=-1;
    O_NOTE:='清洗失败'||SQLERRM;
    ROLLBACK;  

END;
/

