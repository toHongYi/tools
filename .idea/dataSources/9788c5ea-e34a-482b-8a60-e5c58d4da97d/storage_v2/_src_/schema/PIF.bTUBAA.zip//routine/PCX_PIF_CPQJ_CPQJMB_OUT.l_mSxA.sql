create procedure pcx_pif_cpqj_cpqjmb_out(o_code         out number,
                                                o_note         out varchar2,
                                                o_result       out sys_refcursor,
                                                i_userid       in number, --用户 ID
                                                i_ip           in varchar2,--IP
                                                i_prod_id      in number --产品ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-我适用的模版
  所属用户：PIF
  概要说明：查询当前登录人所在部门适用的产品全景模版列表.
               i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                               并不是什么是否都需要分页,看情形而言.
               i_PageNo      --页码
               i_PageLength  --页长
               i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               i_Sort        --排序字段
               i_userid         IN NUMBER, --用户 ID
               i_prod_id         IN NUMBER  --产品ID
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.

  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询当前登录人所在部门适用的模版列表.

        1.当前登录人所在部门适用的模版可能有多个，按照最近配置日期排序.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
  *********************************************************************************************************************/
  v_sql    varchar2(32767);
  v_colist varchar2(32767);
  v_sort   varchar2(2000);
  v_errmsg varchar2(300); --错误信息
  v_count  number(12);
  v_mbids  varchar2(2000);
  v_ids    varchar2(2000);
begin
  o_code         := 0;
  o_note         := '成功';

  if i_userid is null then
    o_code := -1801;
    o_note := '请输入的必填参数【用户ID】';
    return;
  end if;
   if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;


  --验证是否存在适用于当前登录人的全景模版
  select count(1) into v_count from tpif_cpqjmbdy where mbzt = 1;
  if v_count = 0 then
    o_code := -1;
    o_note := '当前无启用的全景模板,请联系管理员!';
    return;
  end if;
  for cur in (select id, cpjh from tpif_cpqjmbdy where mbzt = 1) loop
    for cur_jh in (select sql_condition
                     from tprod_collection
                    where instr(';' || cur.cpjh || ';', ';' || id || ';') > 0) loop
      v_sql := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE ID = ' ||
               i_prod_id || ' AND ' || cur_jh.sql_condition;
      begin
        execute immediate v_sql
          into v_count;
      exception
        when others then
          null;
      end;
      if v_count > 0 then
        v_ids := v_ids || ';' || cur.id;
      end if;
    end loop;
  end loop;
  if v_ids is null then
    o_code := -1;
    o_note := '当前无适用于此产品的全景模板,请联系管理员!';
    return;
  end if;
  v_mbids := '';
  if i_userid = 0 then
    --管理员默认存在权限
    select ';' || replace(wm_concat(id), ',', ';')
      into v_mbids
      from tpif_cpqjmbdy
     where instr(v_ids || ';', ';' || id || ';') > 0;
  else
    for cur in (select *
                  from tpif_cpqjmbdy a
                 where instr(v_ids || ';', ';' || a.id || ';') > 0
                   and exists (select 1
                          from tpif_cpqjmbdy_syfw b
                         where b.tpif_cpqjmbdy_id = a.id
                           and b.fwlx = 3)) loop
      for cur_s in (select *
                      from tpif_cpqjmbdy_syfw
                     where tpif_cpqjmbdy_id = cur.id
                       and fwlx = 3) loop
        if instr(';' || cur_s.syyh || ';', ';' || i_userid || ';') > 0 then
          v_mbids := v_mbids || ';' || cur.id;
        end if;
      end loop;
    end loop;
    if v_mbids is null then
      for cur in (select *
                    from tpif_cpqjmbdy a
                   where instr(v_ids || ';', ';' || a.id || ';') > 0
                     and exists (select 1
                            from tpif_cpqjmbdy_syfw b
                           where b.tpif_cpqjmbdy_id = a.id
                             and b.fwlx = 4)) loop
        for cur_s in (select *
                        from tpif_cpqjmbdy_syfw
                       where tpif_cpqjmbdy_id = cur.id
                         and fwlx = 4) loop
          select count(1)
            into v_count
            from livebos.lbmember
           where userid = i_userid
             and instr(';' || cur_s.syjs || ';', ';' || roleid || ';') > 0
             and instr(';' || cur_s.sybm || ';', ';' || orgid || ';') > 0;
          if v_count > 0 then
            v_mbids := v_mbids || ';' || cur.id;
          end if;
        end loop;
      end loop;
    end if;
    if v_mbids is null then
      for cur in (select *
                    from tpif_cpqjmbdy a
                   where instr(v_ids || ';', ';' || a.id || ';') > 0
                     and exists (select 1
                            from tpif_cpqjmbdy_syfw b
                           where b.tpif_cpqjmbdy_id = a.id
                             and b.fwlx = 2)) loop
        for cur_s in (select *
                        from tpif_cpqjmbdy_syfw
                       where tpif_cpqjmbdy_id = cur.id
                         and fwlx = 2) loop
          select count(1)
            into v_count
            from livebos.lbmember
           where userid = i_userid
             and instr(';' || cur_s.syjs || ';', ';' || roleid || ';') > 0;
          if v_count > 0 then
            v_mbids := v_mbids || ';' || cur.id;
          end if;
        end loop;
      end loop;
    end if;
    if v_mbids is null then
      for cur in (select *
                    from tpif_cpqjmbdy a
                   where instr(v_ids || ';', ';' || a.id || ';') > 0
                     and exists (select 1
                            from tpif_cpqjmbdy_syfw b
                           where b.tpif_cpqjmbdy_id = a.id
                             and b.fwlx = 1)) loop
        for cur_s in (select *
                        from tpif_cpqjmbdy_syfw
                       where tpif_cpqjmbdy_id = cur.id
                         and fwlx = 1) loop
          select count(1)
            into v_count
            from livebos.tuser
           where id = i_userid
             and instr(';' || cur_s.sybm || ';', ';' || orgid || ';') > 0;
          if v_count > 0 then
            v_mbids := v_mbids || ';' || cur.id;
          end if;
        end loop;
      end loop;
    end if;
    if v_mbids is null then
      for cur in (select *
                    from tpif_cpqjmbdy a
                   where instr(v_ids || ';', ';' || a.id || ';') > 0
                     and exists (select 1
                            from tpif_cpqjmbdy_syfw b
                           where b.tpif_cpqjmbdy_id = a.id
                             and b.fwlx = 0)) loop
        v_mbids := v_mbids || ';' || cur.id;
      end loop;
    end if;
  end if;
  v_mbids := substr(v_mbids, 2);
  if v_mbids is null then
    o_code := -1;
    o_note := '错误：当前登录人无权查看此产品的产品全景信息！';
    return;
  else
    v_sql := ' SELECT  MB.ID
                         FROM PIF.TPIF_CPQJMBDY MB
                        WHERE INSTR('';' || v_mbids ||
             ';'' ,'';''||MB.ID||'';'')>0
                        ORDER BY ZHXGRQ DESC';

    --dbms_output.put_line(v_sql);
  end if;


  open o_result for v_sql;

  -- 5.==============调用分页查询过程，返回游标==============
  --5.1 初始化分页查询入参
  --列表

  --是否返回结果集
  commit;
  --5.2.调用分页查询过程

  /*PCX_TYCX(O_CODE,
  O_NOTE,
  O_HASRECORDSET,
  O_RESULT,
  I_PAGING,
  I_PAGENO,
  I_PAGELENGTH,
  I_TOTALROWS,
  SQLS           => V_SQL,
  COLLIST        => V_COLIST,
  HASWHERE       => TRUE,
  GROUPISLAST    => TRUE,
  I_SORT         => V_SORT, --至多一条，强制不排序
  I_HASWITH      => FALSE);*/

exception
  when others then
    o_code   := -1;
    o_note   := '查询失败';
    v_errmsg := sqlerrm;
    open o_result for
      select '异常信息：' || v_errmsg from dual;

end pcx_pif_cpqj_cpqjmb_out;
/

