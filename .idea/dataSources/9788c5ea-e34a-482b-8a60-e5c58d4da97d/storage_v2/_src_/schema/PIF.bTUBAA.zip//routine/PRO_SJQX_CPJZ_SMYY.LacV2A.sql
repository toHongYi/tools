create PROCEDURE PRO_SJQX_CPJZ_SMYY(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2 --返回消息
                                               ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：私募运营产品净值表 TPIF_CPJZ_SMYY 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-05-13     1.0.0     高昆               创建
          2021-7-28      1.0.1     高昆               修改来源，取质检后的净值
          2021-11-3      1.0.2     高昆                修改
  ***********************************************************************/
  V_COUNT NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  /************质检后的净值导入 ********************************************/
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPJZ_SMYY; --判断净值表是否有数据

  IF V_COUNT = 0 THEN
    --没有则全部插入
    INSERT INTO TPIF_CPJZ_SMYY
      (ID,
       CPID, --产品ID
       JYRQ, --交易日期
       JZRQ, --净值日期
       DWJZ, --单位净值
       LJJZ, --累计净值
       RZF, --较上期
       SJLY, --5 集中柜台
       QRZT, --1 有效
       CZSJ) --操作时间
      SELECT SEQ_TPIF_CPJZ_SMYY.NEXTVAL,
             B.CPID, --私募运营产品表ID
             A.JYRQ,
             A.JZRQ,
             A.DWJZ,
             A.LJJZ,
             RZF,
             5,
             1,
             SYSDATE
        FROM TPIF_CPJZ      A, --产品净值表_产品中心
             TPIF_CPDM_SMYY B --私募运营产品表
       WHERE TRIM(A.CPDM) = TRIM(B.DXCPDM);
    --私募经纪户没有代销产品代码，通过朝阳永续获取净值信息
  
    --如果私募净值表已经有数据
  ELSE
    MERGE INTO TPIF_CPJZ_SMYY M
    USING (SELECT B.CPID, --私募运营产品表ID
                  A.JYRQ,
                  A.JZRQ,
                  A.DWJZ,
                  A.LJJZ,
                  RZF
             FROM TPIF_CPJZ      A, --产品净值表_产品中心
                  TPIF_CPDM_SMYY B --私募运营产品表
            WHERE TRIM(A.CPDM) = TRIM(B.DXCPDM)) N
    ON (M.CPID = N.CPID AND M.JYRQ = N.JYRQ)
    WHEN MATCHED THEN
      UPDATE
         SET M.DWJZ = N.DWJZ,
             M.LJJZ = N.LJJZ,
             M.RZF  = N.RZF,
             M.JZRQ = N.JZRQ
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         CPID, --产品ID
         JYRQ, --交易日期
         JZRQ, --净值日期
         DWJZ, --单位净值
         LJJZ, --累计净值
         RZF,
         SJLY, --5 柜台
         QRZT, --1 有效
         CZSJ)
      VALUES
        (SEQ_TPIF_CPJZ_SMYY.NEXTVAL,
         N.CPID,
         N.JYRQ,
         N.JZRQ,
         N.DWJZ,
         N.LJJZ,
         N.RZF,
         5,
         1,
         SYSDATE);
  
  END IF;

  /************二、从朝阳永续更新经纪户净值   数据来源 2  **************************/
  MERGE INTO PIF.TPIF_CPJZ_SMYY M
  USING (SELECT B.CPID,
                TO_CHAR(A.STATISTIC_DATE, 'YYYYMMDD') AS JYRQ, --  统计日期
                A.NAV AS NET_VALUE, --  单位净值(元),
                A.ADDED_NAV AS ADDED_NET_VALUE, --  累计净值(元)
                A.SWANAV AS ARITHMETIC_NET_VALUE --复权净值
         --A.TOTAL_NAV AS TOTAL_NET_VALUE, --资产净值
         --A.ANNUALIZED_RETURN AS ANNUALIZED_RETURN, --  年化收益率
         --A.D7_ANNUALIZED_RETURN AS D7_ANNUALIZED_RETURN, --  7日年化收益率
         --A.INCOME_VALUE_PER_TEN_THOUSAND AS INCOME_VALUE_PER_TEN_THOUSAND --  每万份计划收益(元)
           FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A, PIF.TPIF_CPDM_SMYY B
          WHERE A.FUND_ID = B.ZYNM
            AND B.ZYNM IS NOT NULL
            AND B.CPYWLX = 2 --经纪户2 没有代销产品代码，从朝阳永续取
            AND NOT EXISTS (SELECT 1
                   FROM PIF.TPIF_CPJZ_SMYY C
                  WHERE C.CPID = B.CPID
                    AND C.SJLY = 5)
         -- AND A.NAV_DATE >= TO_CHAR(SYSDATE - 30, 'YYYYMMDD')
         --第一次跑先注释改行，后面每日跑时候取近一个月数据更新
         ) N
  ON (M.CPID = N.CPID AND M.JYRQ = N.JYRQ)
  /* WHEN MATCHED THEN
                   UPDATE SET M.JZRQ = N.JYRQ,                   --新增1130
                              M.DWJZ = N.NET_VALUE, --单位净值
                              M.LJJZ = N.ADDED_NET_VALUE,
                              M.FQJZ = N.ARITHMETIC_NET_VALUE,
                              M.ZCJZ = N.TOTAL_NET_VALUE,
                              M.NHSYL = N.ANNUALIZED_RETURN,
                              M.WFSYL = N.INCOME_VALUE_PER_TEN_THOUSAND,
                              M.NHSYL_D7 = N.D7_ANNUALIZED_RETURN*/
  WHEN NOT MATCHED THEN
    INSERT
      (ID,
       CPID, --产品ID
       JYRQ, --交易日期
       JZRQ, --净值日期
       DWJZ, --单位净值
       LJJZ, --累计净值
       FQJZ, --复权净值
       SJLY, --2 朝阳永续
       QRZT, --1
       CZSJ)
    VALUES
      (SEQ_TPIF_CPJZ_SMYY.NEXTVAL,
       N.CPID,
       N.JYRQ,
       N.JYRQ,
       N.NET_VALUE, --单位净值
       N.ADDED_NET_VALUE,
       N.ARITHMETIC_NET_VALUE,
       2,
       1,
       SYSDATE);

  DELETE FROM TPIF_CPJZ_SMYY
   WHERE CPID NOT IN (SELECT CPID FROM TPIF_CPDM_SMYY WHERE CPYWLX = 3)
     AND SJLY = 5;

  DELETE FROM TPIF_CPJZ_SMYY
   WHERE CPID NOT IN (SELECT CPID FROM TPIF_CPDM_SMYY WHERE CPYWLX = 2)
     AND SJLY = 2;

  /**********************************************************************************/
  --更新 TPIF_CPJZXX(产品净值信息表，该表以净值日期为唯一日期)
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPJZXX ';

  INSERT INTO TPIF_CPJZXX
    (CPID, JZRQ, DWJZ, LJJZ, FQJZ, JYRQ, SJLY, QRZT)
    SELECT CPID, JZRQ, DWJZ, LJJZ, FQJZ, JYRQ, SJLY, 1
      FROM (SELECT CPID,
                   JZRQ,
                   DWJZ,
                   LJJZ,
                   FQJZ,
                   JYRQ,
                   SJLY,
                   ROW_NUMBER() OVER(PARTITION BY CPID, JZRQ ORDER BY JYRQ DESC) AS RN
              FROM TPIF_CPJZ_SMYY
             WHERE DWJZ != 0
               AND LJJZ != 0)
     WHERE RN = 1;
  --同一净值日期，如果存在不同净值信息，则取交易日期最大的那一天的数据

  /********计算 TPIF_CPJZXX 的RZF*********************/
  MERGE INTO TPIF_CPJZXX M
  USING (SELECT A.CPID,
                A.JZRQ,
                A.LJJZ,
                LAG(A.LJJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRLJJZ,
                LAG(A.DWJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRDWJZ
           FROM TPIF_CPJZXX A) N
  ON (M.JZRQ = N.JZRQ AND M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.RZF = ROUND((CASE
                           WHEN N.ZRDWJZ = 0 THEN
                            0
                           ELSE
                            (N.LJJZ - N.ZRLJJZ) / N.ZRDWJZ
                         END),
                         6);

  /********************产品最新净值表清空并重新插入最新数据************************/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TPIF_CPZXJZ_SMYY ';

  INSERT INTO TPIF_CPZXJZ_SMYY
    (ID,
     CPID,
     JYRQ,
     JZRQ,
     DWJZ,
     LJJZ,
     FQJZ,
     --NHSYL,
     --WFSYL,
     RZF,
     ZZF,
     QRZT,
     SJLY,
     FBR,
     CZSJ
     --NHSYL_D7
     )
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPZXJZ_SMYY'),
           X.CPID,
           X.JYRQ,
           X.JZRQ,
           X.DWJZ,
           X.LJJZ,
           X.FQJZ,
           --X.NHSYL,
           --X.WFSYL,
           X.RZF,
           X.ZZF,
           X.QRZT,
           X.SJLY,
           X.FBR,
           SYSDATE
    --X.NHSYL_D7
      FROM (SELECT A.CPID,
                   A.JYRQ,
                   A.JZRQ,
                   A.DWJZ,
                   A.LJJZ,
                   A.FQJZ,
                   --A.NHSYL,
                   --A.WFSYL,
                   A.RZF,
                   A.ZZF,
                   A.QRZT,
                   A.SJLY,
                   A.FBR,
                   --A.NHSYL_D7,
                   ROW_NUMBER() OVER(PARTITION BY A.CPID ORDER BY A.JZRQ DESC) AS RNN
              FROM TPIF_CPJZXX A) X
     WHERE X.RNN = 1;

  /**************更新TPIF_CPDM_SMYY表净值信息***************************************/
  MERGE INTO PIF.TPIF_CPDM_SMYY M
  USING (SELECT CPID, JZRQ, DWJZ, LJJZ FROM TPIF_CPZXJZ_SMYY) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE SET M.JZRQ = N.JZRQ, M.CPJZ = N.DWJZ, M.LJJZ = N.LJJZ;

  /**************更新TPIF_CPJZXX 的复权净值******************************/
  /*  UPDATE TPIF_CPJZXX A --每个产品第一条记录的复权净值
     SET A.FQJZ =
         (A.DWJZ * (A.LJJZ - A.DWJZ + 1))
   WHERE A.JZRQ =
         (SELECT MIN(B.JZRQ) FROM TPIF_CPJZXX B WHERE A.CPID = B.CPID);
  
  --后续的复权净值
  FOR CUR_CP IN (SELECT A.CPID,
                        A.JZRQ,
                        A.RZF,
                        LAG(A.JZRQ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRJZRQ
                   FROM TPIF_CPJZXX A) LOOP
    UPDATE TPIF_CPJZXX B
       SET B.FQJZ = ROUND((CUR_CP.RZF + 1) *
                          (SELECT FQJZ
                             FROM TPIF_CPJZXX
                            WHERE JZRQ = CUR_CP.ZRJZRQ
                              AND CPID = CUR_CP.CPID),
                          4)
     WHERE CUR_CP.ZRJZRQ > 0
       AND B.CPID = CUR_CP.CPID
       AND B.JZRQ = CUR_CP.JZRQ;
  END LOOP;*/

  COMMIT;

  O_CODE := 1;
  O_NOTE := 'TPIF_CPJZ_SMYY 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPJZ_SMYY 表清洗,未知错误'
                ELSE
                 'TPIF_CPJZ_SMYY 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

