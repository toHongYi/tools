create PROCEDURE PRO_PIF_JRCPFL(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;
                                               --5|变更升级节点;6|上移;7|下移;
                                               I_ID IN VARCHAR2, --操作ID
                                               I_OP IN VARCHAR2 := '' --其他参数
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：金融产品分类管理
        语法信息：
             输入参数：   I_USER  操作人
                          I_IP    操作IP
                          I_OPER  操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;5|变更升级节点;6|上移;7|下移;
                          I_ID    操作ID
                          I_OP    其他参数
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-15     1.0.2    徐阳                创建
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_QXBZ  INTEGER; --权限标识
    V_OBJ   TPIF_JRCPFL%ROWTYPE; --表单记录
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSPX  INTEGER; --显示排序
    --V_SCBZ    INTEGER; --日志删除标识
    V_CZBM VARCHAR2(200); --操作编码
    V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_JRCPFL WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  0,
                  '100101',
                  1,
                  '100102',
                  2,
                  '100103',
                  3,
                  '100104',
                  4,
                  '100105',
                  5,
                  '100106',
                  6,
                  '100107',
                  '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '启用',
                         4,
                         '禁用',
                         5,
                         '变更节点',
                         6,
                         '上移',
                         7,
                         '下移',
                         '未知') || ']_' || V_OBJ.NAME
      INTO V_CZSM
      FROM DUAL;
    --check
/*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF I_IP = '[check]' THEN
            IF I_ID IS NOT NULL THEN
                SELECT COUNT(1)
                  INTO V_COUNT
                  FROM TPIF_JRCPFL
                 WHERE ID = I_ID
                   AND TYPE = 2;
                IF V_COUNT > 0 THEN
                    O_NOTE := '叶子节点不允许新增下级节点!';
                    RETURN;
                END IF;
            END IF;
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FLBM IS NULL THEN
            O_NOTE := '[分类编码]不允许为空!';
            RETURN;
        END IF;
        BEGIN
            V_COUNT := TO_NUMBER(V_OBJ.FLBM);
        EXCEPTION
            WHEN OTHERS THEN
                O_NOTE := '[分类编码]需为6位数字字符!';
                RETURN;
        END;
        IF LENGTH(TRIM(V_OBJ.FLBM)) != 6 THEN
            O_NOTE := '[分类编码]需为6位数字字符!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JRCPFL WHERE FLBM = V_OBJ.FLBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[分类编码]不允许重复!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[分类名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JRCPFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 1 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_OBJ.FID IS NULL THEN
            UPDATE TPIF_JRCPFL
               SET FID     = 0,
                   GRADE   = 0,
                   TYPE    = 1,
                   FDNCODE = 0,
                   XSPX    = 0
             WHERE ID = I_ID;
        ELSE
            FOR CUR IN (SELECT * FROM TPIF_JRCPFL WHERE ID = V_OBJ.FID) LOOP
                UPDATE TPIF_JRCPFL
                   SET GRADE   = CUR.GRADE + 1,
                       FDNCODE = CUR.FDNCODE || '.' || CUR.ID,
                       XSPX   =
                       (SELECT NVL(MAX(T.XSPX), 0) + 1
                          FROM TPIF_JRCPFL T
                         WHERE T.FID = V_OBJ.FID)
                 WHERE ID = I_ID;
            END LOOP;
        END IF;
        --同步销售资格掩码信息
        UPDATE TPIF_JRCPFL T
           SET XSZGYM =
               (SELECT PIF.FUNC_PIF_HQZDZDYM('PIF_XSZG', 1, 10, T.XSZG) FROM DUAL)
         WHERE ID = I_ID;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前节点已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            IF V_OBJ.GRADE = 0 THEN
                O_CODE := -1;
                O_NOTE := '根节点不允许修改！';
            END IF;
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FLBM IS NULL THEN
            O_NOTE := '[分类编码]不允许为空!';
            RETURN;
        END IF;
        BEGIN
            V_COUNT := TO_NUMBER(V_OBJ.FLBM);
        EXCEPTION
            WHEN OTHERS THEN
                O_NOTE := '[分类编码]需为6位数字字符!';
                RETURN;
        END;
        IF LENGTH(TRIM(V_OBJ.FLBM)) != 6 THEN
            O_NOTE := '[分类编码]需为6位数字字符!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JRCPFL WHERE FLBM = V_OBJ.FLBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[分类编码]不允许重复!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[分类名称]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JRCPFL;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[产品根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 1 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[产品根节点]!';
            RETURN;
        END IF;
        UPDATE TPIF_JRCPFL
           SET ID     = V_OBJ.FLBM
         WHERE ID = I_ID;
        UPDATE TPIF_JRCPFL T
           SET XSZGYM =
               (SELECT PIF.FUNC_PIF_HQZDZDYM('PIF_XSZG', 1, 10, T.XSZG) FROM DUAL)
         WHERE ID = I_ID;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前记录已[启用]!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_JRCPFL', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前金融产品分类已存在引用记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JRCPFL WHERE FID = I_ID;
        IF V_COUNT > 0 THEN
            O_NOTE := '当前节点存在下级节点!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_JRCPFL WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前节点已[启用]!';
            RETURN;
        END IF;
        --默认启用当前节点及上级节点
        UPDATE TPIF_JRCPFL
           SET ZT = 1
         WHERE INSTR('.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.', '.' || ID || '.') > 0;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF V_OBJ.ZT = -1 THEN
            O_NOTE := '当前节点已[禁用]!';
            RETURN;
        END IF;
        --默认禁用当前节点及下级节点
        UPDATE TPIF_JRCPFL
           SET ZT = -1
         WHERE INSTR('.' || FDNCODE || '.' || ID || '.', '.' || V_OBJ.ID || '.') > 0;
    END IF;
    IF I_OPER = 5 THEN
        --变更上级节点-----------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_JRCPFL WHERE ID = I_OP) LOOP
            UPDATE TPIF_JRCPFL
               SET GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE INSTR('.' || FDNCODE || '.',
                         '.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.') > 0;
            UPDATE TPIF_JRCPFL
               SET FID     = I_OP,
                   GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE ID = I_ID;
        END LOOP;
        UPDATE TPIF_JRCPFL A
           SET A.XSPX =
               (SELECT NVL(MAX(T.XSPX), 0) + 1
                  FROM TPIF_JRCPFL T
                 WHERE T.FID = I_OP
                   AND T.ID != I_ID)
         WHERE A.ID = I_ID;
    END IF;
    IF I_OPER = 6 THEN
        --上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSPX < V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_JRCPFL T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MAX(A.XSPX)
                           FROM TPIF_JRCPFL A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSPX < V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_JRCPFL SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_JRCPFL SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 7 THEN
        --下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_JRCPFL
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSPX > V_OBJ.XSPX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSPX
          INTO V_ZHID, V_XSPX
          FROM TPIF_JRCPFL T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSPX = (SELECT MIN(A.XSPX)
                           FROM TPIF_JRCPFL A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSPX > V_OBJ.XSPX)
           AND ROWNUM = 1;
        UPDATE TPIF_JRCPFL SET XSPX = V_XSPX WHERE ID = I_ID;
        UPDATE TPIF_JRCPFL SET XSPX = V_OBJ.XSPX WHERE ID = V_ZHID;
    END IF;
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           5,
                           '变更升级节点',
                           6,
                           '上移',
                           7,
                           '下移',
                           '') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JRCPFL;
/

