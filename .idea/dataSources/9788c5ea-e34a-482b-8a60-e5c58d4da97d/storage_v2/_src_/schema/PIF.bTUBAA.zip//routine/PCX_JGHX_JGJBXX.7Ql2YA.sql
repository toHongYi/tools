create PROCEDURE PCX_JGHX_JGJBXX (O_CODE OUT NUMBER,
                                             O_NOTE OUT VARCHAR2,
                                             O_RESULT OUT SYS_REFCURSOR,
                                             I_USERID IN NUMBER,  --用户ID
                                             I_ORGID IN NUMBER    --机构ID
                                             ) AS
/******************************************************************
  项目名称：财通证券运营展业平台-H5机构画像
  所属用户：PIF
  概要说明：机构基本信息查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/17     1.0.0.1   GAOKUN            新增.
  ********************************************************************/
V_FUND_ID VARCHAR2(4000);  --记录该机构的管理基金ID

BEGIN
  O_CODE := 1;
  O_NOTE := '成功！';
  
  IF I_ORGID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '机构ID不允许为空！';
    RETURN;
  END IF;
  
  SELECT TO_CHAR(MANAGE_FUND_ID)
    INTO V_FUND_ID
    FROM SRC_PIF.T_FUND_ORG
   WHERE ORG_ID = I_ORGID;

  OPEN O_RESULT FOR
    SELECT ORG_NAME,
           ORG_FULL_NAME,
           ORG_CATEGORY,
           TO_CHAR(FOUND_DATE, 'YYYYMMDD') AS FOUND_DATE,
           USCC,
           ORG_CODE,
           DECODE(IS_REG,'0','否','1','是') IS_REG,
           DECODE(IS_THIRD_PARTY,'0','否','1','是') IS_THIRD_PARTY,
           REG_CODE,
           TO_CHAR(REG_TIME, 'YYYYMMDD') AS REG_TIME,
           DECODE(IS_MEMBER,'0','否','1','是') IS_MEMBER,
           MASTER_STRATEGY,
           REPRESENTATIVE_FUND_ID AS FUND_ID,
           REPRESENTATIVE_FUND AS FUND_NAME,
           DECODE(ASSET_MGT_SCALE_RANGE,'1','<10亿','2','10-20亿','3','20-50亿','4','50-100亿','5','>100亿') ASSET_MGT_SCALE_RANGE,
           REGEXP_COUNT(MANAGE_FUND_ID, ',') + 1 FUND_AMOUNT,    --管理基金总数
           (CASE WHEN MANAGE_FUND_ID IS NULL THEN  NULL
           ELSE    
             (SELECT COUNT(*)
              FROM TPIF_SCSMJJXX B
             WHERE INSTR(',' || V_FUND_ID || ',', ',' || B.ID || ',') > 0
               AND TRIM(B.FUND_STATUS) = '存续中' )
           END)       AS RUNNING_FUND_AMOUNT, --管理的当前存续中的基金总数
           LEGAL_PERSON,
           ADDRESS,
           REG_ADDRESS,
           ORG_WEB,
           PROFILE
      FROM SRC_PIF.T_FUND_ORG 
      WHERE ORG_ID = I_ORGID;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := '查询失败：'||SQLERRM;
END;
/

