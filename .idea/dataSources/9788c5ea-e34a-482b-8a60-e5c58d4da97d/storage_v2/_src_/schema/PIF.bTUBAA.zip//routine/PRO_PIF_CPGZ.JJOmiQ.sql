create PROCEDURE PRO_PIF_CPGZ(O_CODE         OUT NUMBER, --返回值
                                         O_NOTE         OUT VARCHAR2, --返回消息
                                         I_OPERATE_TYPE IN INTEGER, --操作类型1|关注;2|取消关注
                                         I_USERID       IN NUMBER,
                                         I_PROD_ID      IN INTEGER --产品ID
                                         ) IS
  /*
  **功能说明：产品对比配置
  **创建人：涂孟
  **创建日期：2020-05-08
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **涂孟       1.0.0     2020-05-12   创建
  */
  V_COUNT NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --CHECK
  IF I_USERID IS NULL THEN
    O_NOTE := '系统异常:入参 i_userid 为空!';
    RETURN;
  END IF;
  
  IF I_OPERATE_TYPE IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPERATE_TYPE = 1 THEN
    --//:关注-----------------------------------------------------------------------
    IF I_PROD_ID IS NULL THEN
      O_NOTE := '系统异常:产品ID为空!';
      RETURN;
    END IF;
    
    SELECT COUNT(*) INTO V_COUNT FROM TPIF_WGZDCP WHERE YH = I_USERID AND CPID = I_PROD_ID ;
    
    IF V_COUNT > 0 THEN
      
        O_NOTE := '该产品已关注!';
      --  RETURN;
    
    ELSE
        O_NOTE := '执行关注成功!';
    
       INSERT INTO TPIF_WGZDCP(ID, YH, CPID, SJ) 
       VALUES(Livebos.Func_Nextid('TPIF_WGZDCP'),
              I_USERID,
              I_PROD_ID,
              sysdate  );

    END IF;
  END IF; 
  IF I_OPERATE_TYPE = 2 THEN
    --取消关注-----------------------------------------------------------------------
    IF I_PROD_ID IS NULL THEN
      O_NOTE := '系统异常:产品ID为空!';
      RETURN;
    END IF;
    
     O_NOTE := '取消关注成功!';
    --SELECT COUNT(*) INTO V_COUNT FROM TPIF_WGZDCP WHERE YH = I_USERID AND CPID = I_PROD_ID ;
    
    --IF V_COUNT = 0 THEN
      
    --    O_CODE := -1;
    --    O_NOTE := '系统异常:当前产品未关注!';
    --    RETURN;
    
    --ELSE
        DELETE FROM TPIF_WGZDCP  A WHERE A.CPID = I_PROD_ID AND A.YH = I_USERID;
    --END IF;
    
  END IF ;  
  --RETURN
  COMMIT;
  O_CODE := 1;
  /*SELECT '执行[' || DECODE(I_OPERATE_TYPE, 1, '关注', '取消关注') || ']成功!'
    INTO O_NOTE
    FROM DUAL;*/
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_CPGZ;
/

