create view TPIF_HTZTCX as
SELECT S.ID,
       S.CPID,
       S.CPDM,
       (SELECT CPGLRID FROM TPIF_CPDM WHERE ID=S.CPID) AS CPGLRID,
       S.SQBH,
       S.YYB,
       S.HTZT,
       S.HTQSZT,
       S.SQLC,
       S.LCZT,
       S.KDDH,
       S.CZSJ,
       S.HTID,
       CASE
         WHEN S.HTZT IN (1, 5) THEN
          '总部库房'
         WHEN S.HTZT IN (2, 3, 4, 6) THEN
          (SELECT NAME FROM LIVEBOS.LBORGANIZATION WHERE ID = S.YYB)
         WHEN S.HTZT = 7 THEN
          '管理人'
       END AS SZWZ,
       CASE
         WHEN FUNC_PIF_GET_CPHTYSSC(S.HTID) = 0 THEN
          NULL
         ELSE
          FUNC_PIF_GET_CPHTYSSC(S.HTID)
       END AS CSSC,
       (SELECT KHH FROM TPIF_CPHT WHERE ID = S.HTID) AS KHH,
       (SELECT KHXM FROM TPIF_CPHT WHERE ID = S.HTID) AS KHXM,
       (SELECT EMAIL FROM TPIF_CPHT WHERE ID = S.HTID) AS KHYX
  FROM (SELECT ROW_NUMBER() OVER(PARTITION BY CPDM, HTID ORDER BY CZSJ DESC) RN,
               T.*
          FROM TPIF_HTLSCX T
         WHERE EXISTS (SELECT 1
                  FROM TPIF_CPHT
                 WHERE ID = T.HTID
                   AND SFSC = 0)) S
 WHERE RN = 1
/

