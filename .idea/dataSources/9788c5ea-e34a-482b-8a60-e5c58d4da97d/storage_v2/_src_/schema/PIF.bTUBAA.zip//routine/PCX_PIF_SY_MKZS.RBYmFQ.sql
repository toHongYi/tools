create PROCEDURE PCX_PIF_SY_MKZS(O_CODE       OUT NUMBER,
                                            O_NOTE       OUT VARCHAR2,
                                            O_RESULT     OUT SYS_REFCURSOR,
                                            USERID       IN NUMBER, --登陆用户ID
                                            I_QUERY_TYPE IN NUMBER) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：产品中心
  
         功能说明：首页-首页展示模块查询
             参数说明：
                  入参：
                        I_USERID   IN  NUMBER     --登陆用户ID
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                          TYPE  消息类别
                          TOTAL_RECORD_NUM  总记录数
                          ALREADY_DEAL_NUM  已阅/已处理数
                          TIPS  提示信息
                          URL 明细链接URL
  
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        刘浪浪    1.0.1    2015/01/26                   新增
  
  -------------------------------------------------------------------------------------------------*/
  V_COUNT NUMBER;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  SELECT COUNT(*) INTO V_COUNT FROM TPIF_SYMKPZ WHERE YH = USERID;

  IF I_QUERY_TYPE = 1 THEN
    IF V_COUNT > 0 THEN
      OPEN O_RESULT FOR
        SELECT A.ID AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               B.XSCS AS DISPLAYPARAM,
               PARSEJSON(B.XSCS, 'y') * 10 + PARSEJSON(B.XSCS, 'x') "ORDER"
          FROM TPIF_SYMK A, TPIF_SYMKPZ B
         WHERE A.ID = B.MKID
           AND B.YH = USERID
           AND A.CXLX != 2
         ORDER BY "ORDER" ASC;
    ELSE
    
      OPEN O_RESULT FOR
        SELECT A.ID AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               A.MRXSCS AS DISPLAYPARAM,
               PARSEJSON(A.MRXSCS, 'y') * 10 + PARSEJSON(A.MRXSCS, 'x') AS"ORDER"
          FROM TPIF_SYMK A
         WHERE A.MRZS = 1
           AND A.CXLX != 2
         ORDER BY "ORDER" ASC;
    
    END IF;
  ELSIF I_QUERY_TYPE = 2 THEN
    IF V_COUNT > 0 THEN
      OPEN O_RESULT FOR
        SELECT A.ID AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               B.XSCS AS DISPLAYPARAM,
               PARSEJSON(B.XSCS, 'y') * 10 + PARSEJSON(B.XSCS, 'x') "ORDER"
          FROM TPIF_SYMK A, TPIF_SYMKPZ B
         WHERE A.ID = B.MKID
           AND B.YH = USERID
         ORDER BY "ORDER" ASC;
    ELSE
    
      OPEN O_RESULT FOR
        SELECT A.ID AS ID,
               A.XSTB AS ICON,
               A.MKMC AS NAME,
               A.MRXSCS AS DISPLAYPARAM,
               PARSEJSON(A.MRXSCS, 'y') * 10 + PARSEJSON(A.MRXSCS, 'x') AS"ORDER"
          FROM TPIF_SYMK A
         WHERE A.MRZS = 1
         ORDER BY "ORDER" ASC;
    
    END IF;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

