create PROCEDURE PRO_PIF_JYRL_GZSJJY(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    I_CPID IN NUMBER, --产品ID
                                                    I_SCQJ IN NUMBER, --生成区间
                                                    I_QJKS IN DATE, --区间开始
                                                    I_QJJS IN DATE --区间结束
                                                    ) IS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：定点规则数据校验

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-07-21     V1.0      谢莉莉             创建
        2016-10-20     V2.0      王大一             托管系统迁移改造接入产品中心
     *********************************************************************************************************************/

    V_CPMC   VARCHAR2(500); --产品名称
    V_QJQSMC VARCHAR2(500); --区间起始日名称
    V_QJQSRQ NUMBER; --区间起始日期
    V_QJJSMC VARCHAR2(500); --区间结束日名称
    V_QJJSRQ NUMBER; --区间结束日期

BEGIN

    O_CODE := 1;
    O_NOTE := '操作成功！';
    --PRO_PIF_JYRL_QJZJYR过程包含产品校验和区间校验
    PRO_PIF_JYRL_QJZJYR(O_CODE,
                        O_NOTE,
                        V_QJQSMC,
                        V_QJQSRQ,
                        V_QJJSMC,
                        V_QJJSRQ,
                        V_CPMC,
                        I_CPID,
                        I_SCQJ);

    IF (O_CODE < 0) THEN
        --产品和区间校验失败
        RETURN;
    ELSE
        IF (I_QJKS IS NULL) THEN
            O_CODE := -1;
            O_NOTE := '产品【' || V_CPMC || '】的区间开始''||V_QJQSMC||''不能为空！';
        ELSIF (I_QJKS IS NULL) THEN
            O_CODE := -1;
            O_NOTE := '产品【' || V_CPMC || '】的区间结束''||V_QJJSMC||''不能为空！';
        ELSIF (I_QJKS > I_QJJS) THEN
            O_CODE := -1;
            O_NOTE := '产品【' || V_CPMC ||
                      '】的区间开始''||V_QJQSMC||''不能大于区间结束''||V_QJJSMC||''！';
        END IF;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_JYRL_GZSJJY;
/

