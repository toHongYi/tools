create PROCEDURE PRO_PIF_YXFALCDWJFZ(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_RY   IN NUMBER, --操作人
                                                I_ID   IN NUMBER, --流程ID
                                                I_CPMC IN NUMBER, --已入文档库的cpid
                                                I_CPID IN NUMBER --产品ID
                                                ) IS

  /******************************************************************
        项目名称：产品中心
        所属用户：PIF
       功能说明：多文件复制到文档库
      语法信息：
           输入参数：I_RY   IN  NUMBER    --操作人
                             I_ID IN NUMBER       --所属机构服务ID
                             I_FJSTR IN VARCHAR2       --附件json字符串
          逻辑说明：复制记录，附件X拼接记录
          修订记录：
        修订日期              版本号   修订人      修改内容简要说明
        2021-08-013     1.0.0     WWH       新增附件转移
        20211018        1.0.1     ltx       修改fjx字段为拼接
  ***********************************************************************/

  V_CPID  NUMBER; --产品ID
  V_CPGLR NUMBER; --产品管理人ID
  V_CPXL  NUMBER; --产品分类
  V_WDID  NUMBER; --文档ID
  V_CPMC  VARCHAR2(200); --产品

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_CPID := I_CPID;

  FOR CUR IN (SELECT *
                FROM PIF.TPIF_CPWDK
               WHERE GLLCCPXX = I_ID
                 AND CPMC = I_CPMC) LOOP
  
    --获取营销产品信息
    SELECT CPMC, CPGLRID, CPXL
      INTO V_CPMC, V_CPGLR, V_CPXL
      FROM PIF.TPIF_CPDM
     WHERE ID = I_CPID;
  
    V_WDID := LIVEBOS.FUNC_NEXTID('TPIF_CPWDK');
    INSERT INTO TPIF_CPWDK
      (ID,
       BM,
       GLLX,
       GLID,
       CPMC,
       CPXL,
       WDFL,
       WDMC,
       FJX,
       GLFJID,
       SFYX,
       SCRY,
       SCRQ,
       BBH,
       WDYSTJ,
       WDGS,
       XZWDSJ,
       GGRQ,
       GLRMC,
       BZ,
       GLLC,
       GLLCCPXX)
    VALUES
      (V_WDID,
       V_WDID,
       1,
       V_CPID,
       V_CPID,
       V_CPXL,
       CUR.WDFL,
       CUR.WDMC,
       '<a href="OperateProcessor?Column=FJ&PopupWin=false&Table=vPIF_CPWDK&operate=Download&Type=Attachment&ID=' ||
       CUR.ID || '" class="link">' || CUR.WDMC ||
       '</a> <a href="OperateProcessor?Column=FJ&PopupWin=false&Table=vPIF_CPWDK&operate=Download&Type=Attachment&ID=' ||
       CUR.ID || '" class="link">下载</a>',
       CUR.ID,
       1,
       I_RY,
       TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')),
       V_CPMC || '_' || I_ID || '_V100.0_' || TO_CHAR(SYSDATE, 'yyyymmdd'),
       1,
       CUR.WDGS,
       SYSDATE,
       TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd')),
       V_CPGLR,
       CUR.BZ,
       4,
       I_ID);
  END LOOP;

  O_CODE := 1;
  O_NOTE := '成功';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    ROLLBACK;
END;
/

