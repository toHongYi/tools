create PROCEDURE PRO_SJQX_CP_FXTZ(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_RQ   IN NUMBER --统计日期
                                             ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险特征-DSC_STAT.TPIF_STAT_CP_FXTZ数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-15     1.0       吴金锋              创建
  ***********************************************************************/
  --V_COUNT NUMBER;
  V_RQ   NUMBER;
  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --1. 先将当前表数据备份到HIS表中
  BEGIN
    SELECT MAX(RQ) INTO V_RQ FROM DSC_STAT.TPIF_STAT_CP_FXTZ;
  EXCEPTION
    WHEN OTHERS THEN
      V_RQ := NULL;
  END;

  IF V_RQ > 0 THEN
  
    PRO_SJQX_CP_FXTZ_HIS(V_CODE, V_NOTE, V_RQ);
  
    IF V_CODE = -1 THEN
      O_NOTE := V_NOTE;
      RETURN;
    END IF;
  
  END IF;

  --2. TPIF_STAT_CP_FXTZ表数据清洗开始
  IF I_RQ IS NULL THEN
    --计算上个交易日的
    SELECT MAX(JYR)
      INTO V_RQ
      FROM LIVEBOS.TXTJYR A
     WHERE A.JYR < TO_CHAR(SYSDATE, 'YYYYMMDD');
  ELSE
    V_RQ := I_RQ;
  END IF;

  --2.1 清空表数据
  DELETE FROM DSC_STAT.TPIF_STAT_CP_FXTZ WHERE 1 = 1;
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_STAT_CP_FXTZ';

  --2.2 区间最大回撤
  PRO_SJQX_CP_FXTZ_ZDHC(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.3 年化波动率
  PRO_SJQX_CP_FXTZ_NHBDL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.4 年化下行波动率
  PRO_SJQX_CP_FXTZ_NHXXBDL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.5 亏损比率
  PRO_SJQX_CP_FXTZ_KSBL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.6 亏损平均收益率
  PRO_SJQX_CP_FXTZ_KSPJSYL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.7 最大连续亏损次数
  PRO_SJQX_CP_FXTZ_ZDLXKSCS(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --2.8 单次最大亏损收益率
  PRO_SJQX_CP_FXTZ_DCZDKSSYL(V_CODE, V_NOTE, V_RQ);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  --3.TEMP_STAT_CP_SYTZ 表数据加载到 TPIF_STAT_CP_SYTZ表中
  INSERT INTO DSC_STAT.TPIF_STAT_CP_FXTZ
    (RQ,
     CPID,
     JZRQ,
     JYRQ,
     DWJZ,
     NHBDL_3Y,
     NHBDL_6Y,
     NHBDL_1N,
     NHBDL_3N,
     NHBDL_5N,
     NHBDL_CLYL,
     NHBDL_JNYL,
     NHXXBDL_3Y,
     NHXXBDL_6Y,
     NHXXBDL_1N,
     NHXXBDL_3N,
     NHXXBDL_5N,
     NHXXBDL_CLYL,
     NHXXBDL_JNYL,
     ZDHC_3Y,
     ZDHC_6Y,
     ZDHC_1N,
     ZDHC_3N,
     ZDHC_5N,
     ZDHC_CLYL,
     ZDHC_JNYL,
     KSBL_3Y,
     KSBL_6Y,
     KSBL_1N,
     KSBL_3N,
     KSBL_5N,
     KSBL_CLYL,
     KSBL_JNYL,
     DCZDKSSYL_3Y,
     DCZDKSSYL_6Y,
     DCZDKSSYL_1N,
     DCZDKSSYL_3N,
     DCZDKSSYL_5N,
     DCZDKSSYL_CLYL,
     DCZDKSSYL_JNYL,
     ZDLXKSCS_3Y,
     ZDLXKSCS_6Y,
     ZDLXKSCS_1N,
     ZDLXKSCS_3N,
     ZDLXKSCS_5N,
     ZDLXKSCS_CLYL,
     ZDLXKSCS_JNYL,
     KSPJSYL_3Y,
     KSPJSYL_6Y,
     KSPJSYL_1N,
     KSPJSYL_3N,
     KSPJSYL_5N,
     KSPJSYL_CLYL,
     KSPJSYL_JNYL)
    SELECT RQ,
           CPID,
           JZRQ,
           JYRQ,
           DWJZ,
           SUM(NVL(NHBDL_3Y, 0)),
           SUM(NVL(NHBDL_6Y, 0)),
           SUM(NVL(NHBDL_1N, 0)),
           SUM(NVL(NHBDL_3N, 0)),
           SUM(NVL(NHBDL_5N, 0)),
           SUM(NVL(NHBDL_CLYL, 0)),
           SUM(NVL(NHBDL_JNYL, 0)),
           SUM(NVL(NHXXBDL_3Y, 0)),
           SUM(NVL(NHXXBDL_6Y, 0)),
           SUM(NVL(NHXXBDL_1N, 0)),
           SUM(NVL(NHXXBDL_3N, 0)),
           SUM(NVL(NHXXBDL_5N, 0)),
           SUM(NVL(NHXXBDL_CLYL, 0)),
           SUM(NVL(NHXXBDL_JNYL, 0)),
           SUM(NVL(ZDHC_3Y, 0)),
           SUM(NVL(ZDHC_6Y, 0)),
           SUM(NVL(ZDHC_1N, 0)),
           SUM(NVL(ZDHC_3N, 0)),
           SUM(NVL(ZDHC_5N, 0)),
           SUM(NVL(ZDHC_CLYL, 0)),
           SUM(NVL(ZDHC_JNYL, 0)),
           SUM(NVL(KSBL_3Y, 0)),
           SUM(NVL(KSBL_6Y, 0)),
           SUM(NVL(KSBL_1N, 0)),
           SUM(NVL(KSBL_3N, 0)),
           SUM(NVL(KSBL_5N, 0)),
           SUM(NVL(KSBL_CLYL, 0)),
           SUM(NVL(KSBL_JNYL, 0)),
           SUM(NVL(DCZDKSSYL_3Y, 0)),
           SUM(NVL(DCZDKSSYL_6Y, 0)),
           SUM(NVL(DCZDKSSYL_1N, 0)),
           SUM(NVL(DCZDKSSYL_3N, 0)),
           SUM(NVL(DCZDKSSYL_5N, 0)),
           SUM(NVL(DCZDKSSYL_CLYL, 0)),
           SUM(NVL(DCZDKSSYL_JNYL, 0)),
           SUM(NVL(ZDLXKSCS_3Y, 0)),
           SUM(NVL(ZDLXKSCS_6Y, 0)),
           SUM(NVL(ZDLXKSCS_1N, 0)),
           SUM(NVL(ZDLXKSCS_3N, 0)),
           SUM(NVL(ZDLXKSCS_5N, 0)),
           SUM(NVL(ZDLXKSCS_CLYL, 0)),
           SUM(NVL(ZDLXKSCS_JNYL, 0)),
           SUM(NVL(KSPJSYL_3Y, 0)),
           SUM(NVL(KSPJSYL_6Y, 0)),
           SUM(NVL(KSPJSYL_1N, 0)),
           SUM(NVL(KSPJSYL_3N, 0)),
           SUM(NVL(KSPJSYL_5N, 0)),
           SUM(NVL(KSPJSYL_CLYL, 0)),
           SUM(NVL(KSPJSYL_JNYL, 0))
    
      FROM TEMP_STAT_CP_FXTZ
     WHERE RQ = V_RQ
     GROUP BY RQ, CPID, JZRQ, JYRQ, DWJZ;

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'DSC_STAT.TPIF_STAT_CP_FXTZ 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := V_NOTE || sqlerrm;
END;
/

