create PROCEDURE pcx_pif_ygxszc_lyzs(O_CODE     OUT NUMBER,
                                                O_NOTE     OUT VARCHAR2,
                                                O_RESULT   OUT SYS_REFCURSOR,
                                                I_CURRENT  IN NUMBER, --页码
                                                I_PAGESIZE IN NUMBER, --页长
                                                I_PAGING   IN NUMBER, --是否分页
                                                I_SORT     IN STRING, --排序规模
                                                I_TOTAL    IN OUT NUMBER, --记录总数
                                                I_USERID   IN NUMBER,
                                                I_KSRQ     in number,     --开始日期
                                                I_JSRQ     in number      --结束日期

                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品路演及培训展示

      语法信息：
           输入参数：     I_CURRENT  IN NUMBER, --页码
                          I_PAGESIZE IN NUMBER, --页长
                          I_PAGING   IN NUMBER, --是否分页
                          I_SORT     IN STRING, --排序规模
                          I_TOTAL    IN OUT NUMBER --记录总数
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-02     1.0       TUMENG              新增
  ***********************************************************************/
  V_SQL          VARCHAR2(32767);
  V_COLLIST      VARCHAR2(32767);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER;
  V_BEGIN_DATE   NUMBER;
BEGIN

  IF I_USERID IS NULL THEN

    O_CODE := -1;
    O_NOTE := '入参【I_USERID】不允许为空';
    RETURN;

  END IF;
  

  --否则返回结果集合
  V_HASRECORDSET := 1;
  O_CODE         := 1;
  O_NOTE         := '成功';
  IF I_TOTAL IS NULL THEN
    I_TOTAL := -1;
  END IF;
  V_SORT := I_SORT;

  --后期根据实际情况调整
  V_BEGIN_DATE := TO_CHAR(SYSDATE - 360, 'YYYYMMDD');

  V_SQL := ' SELECT  ID as id,
             A.SJMC as title,
             A.TP as image,
             A.rq as date_n
             from TPIF_XSZC_LYJPXAPWH A
               WHERE A.RQ  between ' || I_KSRQ || ' AND ' || I_JSRQ;
  dbms_output.put_line(V_SQL);

  IF V_SORT IS NULL THEN
    V_SORT := 'date_n DESC';
  END IF;
  V_COLLIST := 'id,title,image,date_n';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;

END;
/

