create PROCEDURE PRO_PIF_CPPGWD(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_IP   IN VARCHAR2, --操作IP
                                               I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                               I_ID   IN INTEGER --操作ID
                                               ) IS
    /*
    **功能说明：平台管理
    **创建人：刘浪浪
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **刘浪浪     1.0.1     2015/06/01   创建
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPPGWD%ROWTYPE; --表单记录
    --V_SCBZ    INTEGER; --日志删除标识
    V_OPER    VARCHAR2(200); --操作方法
    V_FDETAIL VARCHAR2(2000); --日志操作明细
    V_NEWID   INTEGER;
    V_VERSION VARCHAR2(200); --版本号
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    SELECT * INTO V_OBJ FROM TPIF_CPPGWD WHERE ID = I_ID;

    SELECT '[' ||
           DECODE(I_OPER, 0, '添加维度', 1, '设置维度', 2, '作废维度', 3, '生成新版本') || ']_' ||
           V_OBJ.KJWD
      INTO V_FDETAIL
      FROM DUAL;

    SELECT DECODE(I_OPER,
                  0,
                  'TPIF_CPPGWD_XZWD',
                  1,
                  'TPIF_CPPGWD_SZWD',
                  2,
                  'TPIF_CPPGWD_ZFWD',
                  3,
                  'TPIF_CPPGWD_SCXBB')
      INTO V_OPER
      FROM DUAL;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';

    IF I_OPER = 0 THEN
        --//:新增

        IF V_OBJ.KJWD IS NULL THEN
            O_NOTE := '[框架维度]不允许为空!';
            RETURN;
        END IF;

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPPGWD WHERE KJWD = V_OBJ.KJWD;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[框架维度]为[' || V_OBJ.KJWD || ']的记录!';
            RETURN;
        END IF;

    END IF;
    IF I_OPER = 1 THEN
        --//:修改

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPPGMB_QUESTIONS WHERE QID = I_ID;

        IF V_COUNT > 0 THEN
            O_NOTE := '指标已被引用不允许修改!';
            RETURN;
        END IF;

        IF V_OBJ.STATUS = -1 THEN
            O_NOTE := '当前记录已[作废]!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;

        IF V_OBJ.KJWD IS NULL THEN
            O_NOTE := '[框架维度]不允许为空!';
            RETURN;
        END IF;

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPPGWD WHERE KJWD = V_OBJ.KJWD;
        IF V_COUNT > 1 THEN
            O_NOTE := '当前已存在[框架维度]为[' || V_OBJ.KJWD || ']的记录!';
            RETURN;
        END IF;
    END IF;

    IF I_OPER = 2 THEN
        --//:作废
        IF V_OBJ.STATUS = -1 THEN
            O_NOTE := '当前记录已[作废]!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        UPDATE TPIF_CPPGWD SET STATUS = -1 WHERE ID = I_ID;
    END IF;

    IF I_OPER = 3 THEN
        IF V_OBJ.STATUS = -1 THEN
            O_NOTE := '当前记录已[作废]!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;

        V_VERSION := V_OBJ.VERSION;

        --获取版本号
        IF V_VERSION IS NULL THEN
            V_VERSION := 'V1.0';
        END IF;

        BEGIN
            SELECT SUBSTR(V_VERSION, 0, INSTR(V_VERSION, '.')) ||
                   TO_CHAR(TO_NUMBER(SUBSTR(V_VERSION,
                                            INSTR(V_VERSION, '.') + 1,
                                            LENGTH(V_VERSION))) + 1)
              INTO V_VERSION
              FROM DUAL;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                O_CODE := -1;
                O_NOTE := '获取新版本号出错';
                RETURN;
        END;

        PIF.PNEXTID('TPIF_CPPGWD', V_NEWID);
        --插入框架维度
        INSERT INTO TPIF_CPPGWD
            (ID, KJWD, VERSION, STATUS)
            SELECT V_NEWID, KJWD, V_VERSION, 0 FROM TPIF_CPPGWD WHERE ID = I_ID;
        IF SQL%ROWCOUNT = 0 THEN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '记录产品框架维度出错';
            RETURN;
        END IF;
        --插入细分维度
        INSERT INTO TPIF_CPPGWD_WDXF
            (ID, XFWD, SM, TJYY, TJFZ_KS, TJFZ_JS, CPJB_KS, CPJB_JS, TPIF_CPPGWD_ID)
            SELECT PIF.FUNC_NEXTID('TPIF_CPPGWD_WDXF'),
                   XFWD,
                   SM,
                   TJYY,
                   TJFZ_KS,
                   TJFZ_JS,
                   CPJB_KS,
                   CPJB_JS,
                   V_NEWID
              FROM TPIF_CPPGWD_WDXF
             WHERE TPIF_CPPGWD_ID = I_ID;
        IF SQL%ROWCOUNT = 0 THEN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '记录产品框架维度出错';
            RETURN;
        END IF;
        UPDATE TPIF_CPPGWD SET STATUS = -1 WHERE ID = I_ID;
    END IF;

    --RECORD
    /*CRMII.PRO_CZRZDJ(O_CODE,
                     O_NOTE,
                     I_USER,
                     'TPIF_CPPGWD',
                     V_OPER,
                     I_ID,
                     V_FDETAIL,
                     I_IP,
                     '28001',
                     '');
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;*/

    O_CODE := 199;
    SELECT '执行[' ||
           DECODE(I_OPER, 0, '添加维度', 1, '设置维度', 2, '作废维度', 3, '生成新版本') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
        ROLLBACK;
END PRO_PIF_CPPGWD;
/

