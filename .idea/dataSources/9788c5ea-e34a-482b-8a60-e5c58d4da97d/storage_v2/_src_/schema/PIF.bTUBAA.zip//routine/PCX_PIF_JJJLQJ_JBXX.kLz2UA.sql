create PROCEDURE PCX_PIF_JJJLQJ_JBXX(O_CODE       OUT NUMBER, --返回值
                                                O_NOTE       OUT VARCHAR2, --返回信息
                                                O_RESULT     OUT SYS_REFCURSOR, --返回的数据集合
                                                I_USERID     IN NUMBER, --登陆用户ID，预留，便于后面文档查询的权限控制
                                                I_MANAGER_ID IN NUMBER --基金经理ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-基金经理全景-基本信息
  所属用户：PIF
  概要说明：查询基金经理基本信息.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
       输入参数：
          I_USERID        登陆用户ID，预留，便于后面文档查询的权限控制
          I_MANAGER_ID    基金经理ID
  
  运行原理：
        关联TPIF_STAT_JJJL（基金经理基本信息）、TPIF_STAT_JJGS（基金公司基本信息）、
        TPIF_STAT_JJJL_GLGM（基金经理管理规模）
        查询结果
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/06     1.0.0    杨啸天             新增.
  *****************************************************************************/
  --V_SQL VARCHAR2(32767); --写SQL可能用到的
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';
  --条件检验
  IF I_MANAGER_ID IS NULL THEN
    O_NOTE := '产品经理ID不允许为空！';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
    SELECT A.GRZL PHOTO, --基金经理个人资料（头像）
           A.XM MANAGER_NAME, --基金经理姓名
           DECODE(A.XB, 1, '男', 2, '女') GENDER, --基金经理性别
           A.JJJLPJ STAR_LEVEL,
           A.ZQCYJL TERM_TIME, --累计任期时间
           A.ZQCYRQ START_TIME, --任职起始时间
           (SELECT JGMC FROM DSC_STAT.TPIF_STAT_JJGS C WHERE C.ID = A.XRJJGS) ORG_NAME, -- 现任基金公司
           B.XRJJZZCGM CURRENT_TOTALSCALE, --  现任基金资产总规模
           B.RQZJJJHB TERM_BESTFUNDRETURN, --任职期间最佳基金回报
           B.LRJJSL HIS_FUNDNUM, --历任基金数量
           B.XRJJSL CURRENT_FUNNUM, --现任基金数量
           B.LRJJZZCGM HIS_TOTALSCALE, --历任基金资产总规模
           B.LRJJHBPMPJ HIS_RANKINGAVE, --历任基金回报排名平均
           A.JYBJ BACKGROUND --基金经理简介
      FROM DSC_STAT.TPIF_STAT_JJJL A
      LEFT JOIN DSC_STAT.TPIF_STAT_JJJL_GLGM B
        ON A.ID = B.JJJLID
     WHERE A.ID = I_MANAGER_ID;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
END PCX_PIF_JJJLQJ_JBXX;
/

