create PROCEDURE PRO_JGFW_JGFWFJ(
                                                   O_CODE OUT NUMBER,   --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   I_RY   IN  NUMBER,    --操作人
                                                   I_ID IN NUMBER,        --机构服务ID
                                                   I_FJSTR IN VARCHAR2       --附件json字符串
                                                  ) IS
                                                  
     /******************************************************************                                               
          项目名称：产品中心
          所属用户：PIF
         功能说明：机构业务拓展----机构服务新增----附件json切割转移到TPIF_JGFWFJ                                      
        语法信息：
             输入参数：I_RY   IN  NUMBER    --操作人                                                     
                               I_ID IN NUMBER       --所属机构服务ID                  
                               I_FJSTR IN VARCHAR2       --附件json字符串                   
            逻辑说明：切割得到item部分，循环遍历arr[i]    
            修订记录：  
          修订日期              版本号   修订人      修改内容简要说明
          2021-08-013     1.0.0     WWH       新增附件转移                                 
    ***********************************************************************/
                                                  
                                                  
 V_SUBFJSTR     VARCHAR2(2000); --切割的items部分
 V_FJID        VARCHAR2(2000); --拿到数组中每一个FJID
 V_FJNAME1  VARCHAR2(2000);--切割拿到的部分附件名称
 V_FJNAME  VARCHAR2(2000);--完整的附件名称
 V_COUNT NUMBER;--循环中的次数
 V_CZRID NUMBER;--操作人ID
 V_JGFWID  VARCHAR2(2000); --机构服务ID
 V_CHECK_FJSTR VARCHAR2(2000); --循环终止的条件
 V_FJSTR VARCHAR2(2000);--拿到的表单中附件的json字符串

 BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_COUNT:=0;      
  V_CZRID:=I_RY;
  V_JGFWID:=I_ID;
  V_FJSTR:=I_FJSTR;
   --第一次切割得到item部分，循环的终止条件
  /* SELECT SUBSTR(STR, INSTR(STR, '["', 1, 1))
  INTO   V_CHECK_FJSTR
  FROM   (SELECT SUBSTR(FJ, INSTR(FJ, '"items":[') + 9) AS STR
          FROM   TPIF_JGFW
          WHERE  ID =V_JGFWID ); */
          SELECT SUBSTR(STR, INSTR(STR, '["', 1, 1))
           INTO   V_CHECK_FJSTR
           FROM   (SELECT SUBSTR(V_FJSTR, INSTR(V_FJSTR, '"items":[') + 9) AS STR
                  FROM  dual);
      
    
  LOOP
          V_COUNT:=V_COUNT+1;
           --item部分
  /*         SELECT SUBSTR(STR, INSTR(STR, '["', 1, V_COUNT))
           INTO   V_SUBFJSTR
           FROM   (SELECT SUBSTR(FJ, INSTR(FJ, '"items":[') + 9) AS STR
                  FROM   TPIF_JGFW
                  WHERE  ID = V_JGFWID);
     */
     SELECT SUBSTR(STR, INSTR(STR, '["', 1, V_COUNT))
           INTO   V_SUBFJSTR
           FROM   (SELECT SUBSTR(V_FJSTR, INSTR(V_FJSTR, '"items":[') + 9) AS STR
                  FROM  dual);
              
       
           
           
           IF V_SUBFJSTR =V_CHECK_FJSTR and V_COUNT<>1 THEN
                      EXIT;
             --检测是否是空附件
          ELSIF   V_SUBFJSTR = ']}' THEN
                     EXIT;
                     
           ELSE 
                              --拿到FJID
                      SELECT SUBSTR(V_SUBFJSTR,3,INSTR(V_SUBFJSTR,'"',1,2)-3) INTO V_FJID FROM DUAL;
                             --去除掉数组第一个数据的ID
                      SELECT SUBSTR(V_SUBFJSTR,INSTR(V_SUBFJSTR,'","',V_COUNT,1)+3) INTO V_FJNAME1 FROM DUAL;
                             --拿到数组中第一个附件名称
                      SELECT SUBSTR(V_FJNAME1,1,INSTR(V_FJNAME1,'"]',1,1)-1)INTO V_FJNAME FROM DUAL;
        
                      INSERT INTO TPIF_JGFWFJ
                          (ID,
                           JGFWID,
                           FWFJID,
                           FJ,
                           FJMC,
                           CZR,
                           SFSC,
                           CZSJ)
                      VALUES
                          (LIVEBOS.FUNC_NEXTID('TPIF_JGFWFJ'),
                           V_JGFWID,
                           V_FJID,
                           V_FJNAME,
                           V_FJNAME,
                           V_CZRID,
                           0,
                           SYSDATE);
                    END IF; 
      
      END LOOP;
      
  O_CODE := 1;
  O_NOTE := '成功';
   COMMIT;
   
  EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败';
     ROLLBACK;
END;

/

