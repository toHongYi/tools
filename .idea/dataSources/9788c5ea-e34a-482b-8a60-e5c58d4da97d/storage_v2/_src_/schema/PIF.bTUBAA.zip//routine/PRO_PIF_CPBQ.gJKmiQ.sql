create PROCEDURE PRO_PIF_CPBQ(O_CODE OUT NUMBER, --返回值
                                             O_NOTE OUT VARCHAR2, --返回消息
                                             I_USER IN INTEGER, --操作人
                                             I_IP   IN VARCHAR2, --操作IP
                                             I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;5|上移;6|下移;7|规则维护
                                             I_ID   IN INTEGER, --操作ID
                                             I_OP   IN VARCHAR2 := '' --其他
                                             ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品标签管理
        语法信息：
             输入参数：I_USER IN INTEGER, --操作人
                       I_IP   IN VARCHAR2, --操作IP
                       I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;5|上移;6|下移;
                       I_ID   IN INTEGER, --操作ID
                       I_OP   IN VARCHAR2 := '' --其他
             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2017-05-02     V1.0.1    戴文生              新增
            2017-12-11     v1.0.2   孙远何              修改：自动生成编码
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_QXBZ  INTEGER; --权限标识
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSSX  INTEGER; --显示排序
    V_OBJ   TPIF_CPBQ%ROWTYPE; --表单记录
    V_BM    VARCHAR2(30); --编码
    --V_SCBZ    INTEGER; --日志删除标识
    V_CZBM VARCHAR2(200); --操作编码
    V_CZSM VARCHAR2(2000); --日志操作明细
    
    V_FJSZ NUMBER :=2 ; --标签编码如果重复，加上该字符继续判断是否重复
    V_CSBM VARCHAR2(30); -- 初始编码，重复则在此编码上加数字
    
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
   
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPBQ WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    SELECT DECODE(I_OPER,
                  0,
                  '100701',
                  1,
                  '100702',
                  2,
                  '100703',
                  3,
                  '100704',
                  4,
                  '100705',
                  5,
                  '100706',
                  6,
                  '100707',
                  7,
                   '100708',
                  
                  '0')
      INTO V_CZBM
      FROM DUAL;
    SELECT '[' || DECODE(I_OPER,
                         0,
                         '新增',
                         1,
                         '修改',
                         2,
                         '删除',
                         3,
                         '启用',
                         4,
                         '禁用',
                         5,
                         '上移',
                         6,
                         '下移',
                         '规则维护') || ']_' || V_OBJ.MC
      INTO V_CZSM
      FROM DUAL;
    --check
/*    SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
        O_NOTE := '系统禁止管理员操作!';
        RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF V_OBJ.BQLX IS NULL THEN
            O_NOTE := '[标签类型]不允许为空!';
            RETURN;
        END IF;
        /* IF V_OBJ.BM IS NULL THEN
            O_NOTE := '[标签编码]不允许为空!';
            RETURN;
        END IF;*/
        IF V_OBJ.MC IS NULL THEN
            O_NOTE := '[标签名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS IS NULL THEN
            O_NOTE := '[映射方式]不允许为空!';
            RETURN;
        END IF;
       -- IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
       --     O_NOTE := '[映射集合]不允许为空!';
       --     RETURN;
       -- END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ 
        WHERE MC = V_OBJ.MC
          AND BQLX = V_OBJ.BQLX;
        IF V_COUNT > 1 THEN
            O_NOTE := '同一标签类型下不允许存在重复的[标签名称]--' || V_OBJ.MC || '!';
            RETURN;
        END IF;
        
        IF V_OBJ.BM IS NOT NULL THEN--如果输入了编码
          
          --判断是否包含中文
          SELECT COUNT(1)
            INTO V_COUNT
            FROM DUAL
           WHERE LENGTH(V_OBJ.BM) = LENGTHB(V_OBJ.BM);
          IF V_COUNT = 0 THEN
            O_NOTE := '标签编码中包含中文，请检查！';
            RETURN;
          END IF;
          
          --判断是否重复
          SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM=V_OBJ.BM;
          IF V_COUNT>1 THEN 
            O_NOTE :='不允许存在重复的[标签编码]--' || V_OBJ.BM || '!';
            RETURN;
          END IF;
            
        ELSE --如果编码为空则自动生成
          
          SELECT livebos.FUNC_PINYIN(NAME || '_' || V_OBJ.MC)
            INTO V_BM
            FROM TPIF_BQLX
           WHERE ID = V_OBJ.BQLX;

          V_CSBM := V_BM;
          SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_BM;
          WHILE V_COUNT > 0 LOOP 
              V_BM := V_CSBM || V_FJSZ;
              V_FJSZ := V_FJSZ+1;
              SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_BM;
          END LOOP;
          
          UPDATE TPIF_CPBQ SET BM = V_BM WHERE ID = I_ID;
        
        END IF;
        ----------------
        /*  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_OBJ.BM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[标签编码]--' || V_OBJ.BM || '!';
            RETURN;
        END IF;*/
        UPDATE TPIF_CPBQ
           SET CPJH = (CASE
                          WHEN YSFS != 1 THEN
                           ''
                          ELSE
                           CPJH
                      END),
               XSSX =
               (SELECT NVL(MAX(T.XSSX), 0) + 1 FROM TPIF_CPBQ T WHERE T.BQLX = V_OBJ.BQLX)
         WHERE ID = I_ID;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前标签已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.BQLX IS NULL THEN
            O_NOTE := '[标签类型]不允许为空!';
            RETURN;
        END IF;
        /*    IF V_OBJ.BM IS NULL THEN
            O_NOTE := '[标签编码]不允许为空!';
            RETURN;
        END IF;*/
        IF V_OBJ.MC IS NULL THEN
            O_NOTE := '[标签名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS IS NULL THEN
            O_NOTE := '[映射方式]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[映射集合]不允许为空!';
            RETURN;
        END IF;
        
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ 
        WHERE MC = V_OBJ.MC
          AND BQLX = V_OBJ.BQLX;--判断同一标签类型下是否有重复标签名称
        IF V_COUNT > 1 THEN
            O_NOTE := '同一标签类型下不允许存在重复的[标签名称]--' || V_OBJ.MC || '!';
            RETURN;
        END IF;
        /*  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_OBJ.BM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[标签编码]--' || V_OBJ.BM || '!';
            RETURN;
        END IF;*/
        ------
/*        SELECT livebos.FUNC_PINYIN(name || '_' || V_OBJ.MC)
          INTO V_BM
          FROM TPIF_BQLX
        WHERE ID = V_OBJ.BQLX;

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_BM;
        IF V_COUNT > 0 THEN
            V_BM := V_BM || '2';
        END IF;*/

        --标签编码不随标签名称的修改而变化，新增时候就定死编码了
        UPDATE TPIF_CPBQ
           SET CPJH = (CASE
                          WHEN YSFS != 1 THEN
                           ''
                          ELSE
                           I_OP
                      END)/*,
               BM   = V_BM*/
         WHERE ID = I_ID;
         ------------
        IF NVL(V_OBJ.YSFS, 0) = 1 AND V_OBJ.CPJH != I_OP AND  V_OBJ.CPJH IS NOT NULL THEN
            PIF.PRO_PIF_JHSX(O_CODE, O_NOTE, I_USER, I_IP, 1, I_ID);
            IF O_CODE <= 0 THEN
                RETURN;
            ELSE
                O_CODE := -1;
                O_NOTE := '';
            END IF;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前标签已[启用]!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_CPBQ', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前产品标签已存在引用记录!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_CPBQ WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前标签已[启用]!';
            RETURN;
        END IF;
        UPDATE TPIF_CPBQ SET ZT = 1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF V_OBJ.ZT = -1 THEN
            O_NOTE := '当前标签已[禁用]!';
            RETURN;
        END IF;
        UPDATE TPIF_CPBQ SET ZT = -1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 5 THEN
        --上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPBQ
         WHERE BQLX = V_OBJ.BQLX
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签类型范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPBQ
         WHERE BQLX = V_OBJ.BQLX
           AND ID != I_ID
           AND XSSX < V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM TPIF_CPBQ T
         WHERE T.BQLX = V_OBJ.BQLX
           AND T.ID != I_ID
           AND T.XSSX = (SELECT MAX(A.XSSX)
                           FROM TPIF_CPBQ A
                          WHERE A.BQLX = V_OBJ.BQLX
                            AND A.ID != I_ID
                            AND A.XSSX < V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPBQ SET XSSX = V_XSSX WHERE ID = I_ID;
        UPDATE TPIF_CPBQ SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 6 THEN
        --下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPBQ
         WHERE BQLX = V_OBJ.BQLX
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签类型范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPBQ
         WHERE BQLX = V_OBJ.BQLX
           AND ID != I_ID
           AND XSSX > V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前标签已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM TPIF_CPBQ T
         WHERE T.BQLX = V_OBJ.BQLX
           AND T.ID != I_ID
           AND T.XSSX = (SELECT MIN(A.XSSX)
                           FROM TPIF_CPBQ A
                          WHERE A.BQLX = V_OBJ.BQLX
                            AND A.ID != I_ID
                            AND A.XSSX > V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPBQ SET XSSX = V_XSSX WHERE ID = I_ID;
        UPDATE TPIF_CPBQ SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    
      IF I_OPER = 7 THEN
        --规则维护-----------------------------------------------------------------------
       
        IF V_OBJ.BQLX IS NULL THEN
            O_NOTE := '[标签类型]不允许为空!';
            RETURN;
        END IF;
      
        IF V_OBJ.MC IS NULL THEN
            O_NOTE := '[标签名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS IS NULL THEN
            O_NOTE := '[映射方式]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[映射集合]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE MC = V_OBJ.MC;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[标签名称]--' || V_OBJ.MC || '!';
            RETURN;
        END IF;
        /*  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_OBJ.BM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[标签编码]--' || V_OBJ.BM || '!';
            RETURN;
        END IF;*/
        ------
    /*    SELECT livebos.FUNC_PINYIN(name || '_' || V_OBJ.MC)
          INTO V_BM
          FROM TPIF_BQLX
        WHERE ID = V_OBJ.BQLX;

        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BM = V_BM;
        IF V_COUNT > 0 THEN
            V_BM := V_BM || '2';
        END IF;*/

        UPDATE TPIF_CPBQ
           SET CPJH = (CASE
                          WHEN YSFS != 1 THEN
                           ''
                          ELSE
                           I_OP
                      END)/*,
               BM   = V_BM*/
         WHERE ID = I_ID;
         ------------
        IF NVL(V_OBJ.YSFS, 0) = 1 AND V_OBJ.CPJH != I_OP THEN
            PIF.PRO_PIF_JHSX(O_CODE, O_NOTE, I_USER, I_IP, 1, I_ID);
            IF O_CODE <= 0 THEN
                RETURN;
            ELSE
                O_CODE := -1;
                O_NOTE := '';
            END IF;
        END IF;
    END IF;
    
    
    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           5,
                           '上移',
                           6,
                           '下移','规则维护') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPBQ;
/

