create PROCEDURE PCX_PIF_CPYJBX (O_RESULT OUT SYS_REFCURSOR,

                                             I_CPXL   IN NUMBER,
                                             I_CPDM   IN NUMBER,
                                             I_USERID IN NUMBER,
                                             I_QSRQ   IN NUMBER,
                                             I_JSRQ   IN NUMBER) AS

  /* -----------------------------------------------------------------------
   过程名称 :  PCX_PIF_CPSRMXTJ
   功能简述：  产品最新业绩表现统计



   ------------------------------------------------------------------------
   操作人           操作时间       版本            操作
   LIUTX           20190917       1.0           新增
   liutx           20200114       1.1           修改添加分支机构筛选条件
  -----------------------------------------------------------------------*/
  V_SQL        VARCHAR2(3000);
  V_NOTE       VARCHAR2(1000);

BEGIN
/*  cpid, number(16), y, , 产品名称,
  jzrq, number(8), y, , 净值日期,
  dwjz, number(16,4), y, , 单位净值,
  jyzsyl, number(9,4), y, , 近1周收益率(%),
  jyysyl, number(9,4), y, , 近1月收益率(%),
  jsysyl, number(9,4), y, , 近3月收益率(%),
  jlysyl, number(9,4), y, , 近6月收益率(%),
  jynsyl, number(9,4), y, , 近1年收益率(%),
  j3nsyl, number(9,4), y, , 近3年收益率(%),
  clylsyl, number(9,4), y, , 成立以来收益率(%),
  jnylsyl, number(9,4), y, , 今年以来收益率(%),
  jyzjjyjph, number(10), y, , 近1周基金业绩排行,
  jyyjjyjph, number(10), y, , 近1月基金业绩排行,
  jsyjjyjph, number(10), y, , 近3月基金业绩排行,
  jlyjjyjph, number(10), y, , 近6月基金业绩排行,
  jynjjyjph, number(10), y, , 近1年基金业绩排行*/

  V_SQL:= 'SELECT  B.CPID,
                   A.RQ AS JZRQ ,
                   0  AS JYZSYL,
                   A.QJSYL_1Y AS JYYSYL,　
                   A.QJSYL_3Y  AS JSYSYL,
                   A.QJSYL_6Y AS JLYSYL,
                   A.QJSYL_1N AS JYNSYL,
                   A.QJSYL_3N AS J3NSYL,
                   A.QJSYL_CLYL AS CLYLSYL,
                   A.QJSYL_JNYL AS JNYLSYL,
                   NULL AS JYZJJYJPH,
                   A.YJPH_1Y AS JYYJJYJPH,
                   A.YJPH_3Y AS JSYJJYJPH,
                   A.YJPH_6Y AS JLYJJYJPH,
                   A.YJPH_1N AS JYNJJYJPH
            FROM DSC_STAT.TPIF_STAT_CP_YJBX A,TPIF_CPDM B
            WHERE A.CPID = B.ID AND A.RQ >= ' ||I_QSRQ || ' AND A.RQ <='||I_JSRQ;
            
  IF I_CPXL IS NOT NULL THEN

    V_SQL := V_SQL || ' AND B.CPXL = '|| I_CPXL;

  END IF;

  IF I_CPDM IS NOT NULL THEN

    V_SQL := V_SQL || ' AND B.CPID = '|| I_CPDM;

  END IF;

  OPEN O_RESULT FOR V_SQL || 'order by  JZRQ desc ';

EXCEPTION
  WHEN OTHERS THEN
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
END ;
/

