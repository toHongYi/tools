create PROCEDURE     PRO_CPZX_FHDF(
                                               O_CODE     OUT NUMBER,
                                               O_NOTE     OUT VARCHAR2,
                                               I_ID    in number
                                               ) AS
    /******************************************************************************
    *
    *文件名称：PRO_CPZX_FXDJPF
    *项目名称：东方c产品中心，复核人员打分修改
    *
    *创建人员：yc
    *创建日期：20170512
    *功能说明：产品风险等级评分

    *------------------------------------------------------------------------------
    *
    *修改者        版本号        修改日期        说明
    * 杨超         1.0.0        20170531        创建
    * 杨超         1.0.0        20170623       修改新增字段，并调整写法。
    ******************************************************************************/
V_ZF number(10,2);
V_LRLX number(10);
V_FHRYDF number(10,2);
BEGIN
    O_CODE := 1;
    O_NOTE :='成功';


select nvl(FHRYDF,0),nvl(zf,0)/*,lrlx*/ into V_FHRYDF ,V_ZF/*,V_LRLX*/ from pif.LC_CPXZ_SDXJ where id=I_id;
update
pif.LC_CPXZ_SDXJ set zf=V_ZF+V_FHRYDF*0.005 where id=I_id;
commit;

select nvl(zf,0) into V_ZF from pif.LC_CPXZ_SDXJ where id=I_id;
update pif.LC_CPXZ_SDXJ set 
 FXDJ=(select case when zf>=0 and zf<=18 then 1
when zf>18 and zf<=28 then 2
when zf>28 and zf<=43 then 3
when zf>43 and zf<=53 then 4
when zf>53 then 5 end from dual
  ) where id=I_ID;
  commit;
  
  select nvl(FXDJ,0) into V_ZF from pif.LC_CPXZ_SDXJ where id=I_id;
-----------------产品经理可以开始录入产品
update  pif.LC_CPXZ_SDXJ  set SFCPLR=1 where id=I_ID;
commit;

-------------线下已录入数据插入
  PIF.PRO_CPZX_XXCPLR(O_CODE,O_NOTE,I_ID);
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
END PRO_CPZX_FHDF;
/

