create PROCEDURE PRO_PIF_LCFQ(O_CODE   OUT NUMBER, --返回值
                                         O_NOTE   OUT VARCHAR2, --返回消息
                                         O_INSTID OUT NUMBER, --流程实例ID
                                         O_OBJECTID OUT VARCHAR2, --子对象ID串
                                         
                                         I_WORKFLOWID      IN VARCHAR2, --发起流程的类型ID：LC_SMJGBMDLC
                                         I_FORMVALUES      IN VARCHAR2, --字符串（JSON）,流程表单数据
                                         I_WORKFLOWCREATOR IN VARCHAR2, --流程发起人，为单值，同OA登录名一致
                                         I_WORKFLOWKEYWORD IN VARCHAR2, --流程关键字，预留
                                         I_CALLER          IN VARCHAR2, --调用方1:OA 2:基金管理平台
                                         I_IP              IN VARCHAR2 --操作IP
                                         ) IS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：流程发起后台处理逻辑
      语法信息：
           输入参数：   。。。。
           输出参数：   O_CODE    返回值
                       O_NOTE    返回消息
                       O_INSTID  流程实例ID
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-07     1.0.0    WUJINFENG                创建
  ***********************************************************************/
  V_COUNT  INTEGER; --计数变量
  V_CODE   NUMBER;
  V_NOTE   VARCHAR2(1000);
  V_INSTID INTEGER;
  V_OBJECTID VARCHAR2(4000);
  V_GROUPID VARCHAR2(1000);
BEGIN
  --INIT
  O_CODE := 99;
  O_NOTE := '';
  O_INSTID := -1 ;
  O_OBJECTID :='' ;
  
  /*--权限校验
  SELECT COUNT(*)
    INTO V_COUNT
    FROM PIF.TPIF_LCDJ A
   WHERE A.LCDM = I_WORKFLOWID
     AND A.SFYX = 1;

  IF V_COUNT <= 0 THEN
    O_NOTE := '发起流程的类型不存在！';
    RETURN;
  END IF;*/

  IF I_CALLER NOT IN (1, 2) THEN
    O_NOTE := '非法的调用方！';
    RETURN;
  END IF;
  
/*  IF I_IP IS NULL THEN
    O_NOTE := '调用方IP为空！';
    RETURN;
  END IF;*/

  --业务处理

  --1.私募机构白名单流程
  IF I_WORKFLOWID = 'lc_SMJGBMDLC' THEN
    null;
 
  /*
    PIF.PRO_PIF_LCFQ_SMJGBMDLC(V_CODE,
                               V_NOTE,
                               V_INSTID,
                               I_FORMVALUES,
                               I_WORKFLOWCREATOR,
                               I_WORKFLOWKEYWORD);
  */
  --END IF;
  
  
  
   --2.种子基金审批流程
  ELSIF I_WORKFLOWID = 'LCZZJJSPLC' THEN
    
 
  
    PIF.PRO_PIF_LCFQ_ZZJJSPLC(V_CODE,
                               V_NOTE,
                               V_INSTID,
                               V_OBJECTID,
                               V_GROUPID,
                               I_FORMVALUES,
                               I_WORKFLOWCREATOR,
                               I_WORKFLOWKEYWORD);

                               
     O_OBJECTID := V_OBJECTID ;
     
  ELSE
    
     V_CODE := 99;
     V_NOTE := '入参I_WORKFLOWID【'||I_WORKFLOWID||'】非法！';
  
  END IF;
  
  
  IF V_CODE<>1 THEN
    
     ROLLBACK;   
  
  ELSE

    INSERT INTO TPIF_LCDJZHB( id, 
                              instid, 
                              gzlbd, 
                              oalcid, 
                              fqrq, 
                             -- hxrq, 
                              bz, 
                              djf
                              )
          VALUES(  LIVEBOS.FUNC_NEXTID('TPIF_LCDJZHB'),
                   V_INSTID,
                   I_WORKFLOWID,
                   V_GROUPID,
                   SYSDATE,
                   I_FORMVALUES,
                   I_CALLER
                );
    COMMIT; 
  END IF;            
                            

  --RETURN
  O_INSTID := V_INSTID;
  O_CODE   := V_CODE;
  O_NOTE   := V_NOTE;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

