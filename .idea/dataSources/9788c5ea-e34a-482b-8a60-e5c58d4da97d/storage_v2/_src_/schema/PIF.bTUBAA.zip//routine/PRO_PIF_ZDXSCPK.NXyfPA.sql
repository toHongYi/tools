create PROCEDURE     PRO_PIF_ZDXSCPK(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_USER IN INTEGER, --操作人
                                                I_IP   IN VARCHAR2, --操作IP
                                                I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|审批通过;3|启用；4|禁用
                                                I_ID   IN INTEGER, --操作ID
                                                I_IDS  IN VARCHAR2 ---操作IDs
                                                ) AS

    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：重点销售产品库
        语法信息：
             输入参数：I_USER IN INTEGER, --操作人
                       I_IP   IN VARCHAR2, --操作IP
                       I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|审批通过;3|启用；4|禁用
                       I_ID   IN INTEGER, --操作ID
                       I_OP   IN VARCHAR2 := '' --其他
             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2020-06-29     V1.0.1    涂孟                新增
            2021-03-11      v1.0.2     sunyh              修改：增加产品入池时间更新
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPDM_ZDXS%ROWTYPE; --表单记录
    V_CZBM  VARCHAR2(200); --操作编码
    V_CZSM  VARCHAR2(2000); --日志操作明细
    --V_QXBZ  INTEGER; --权限标识
    V_IDS   VARCHAR2(2000);

BEGIN
    O_CODE := -1;
    O_NOTE := '';

    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPDM_ZDXS WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;

    SELECT DECODE(I_OPER,
                  0,
                  'Y00101',
                  1,
                  'Y00102',
                  2,
                  'Y00103',
                  3,
                  'Y00104',
                  4,
                  'Y00105',
                  '0')
      INTO V_CZBM
      FROM DUAL;

    SELECT '[' ||
           DECODE(I_OPER, 0, '新增', 1, '修改', 2, '审核通过', 3, '启用', 4, '禁用', '') || ']_' ||
           V_OBJ.CPMC
      INTO V_CZSM
      FROM DUAL;

    --CHECK
    /*  SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
    IF V_QXBZ = 0 THEN
      O_NOTE := '系统禁止管理员操作!';
      RETURN;
    END IF;*/
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;

    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        NULL;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        NULL;
    END IF;
    IF I_OPER = 2 THEN
        --审核通过-----------------------------------------------------------------------
        O_NOTE := '审核通过方法处理中！';
        V_IDS  := REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''), ']', '');
        --判断选中记录是否存在已审核通过记录
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPDM_ZDXS
         WHERE ID IN (SELECT COLUMN_VALUE FROM TABLE(SPLIT(V_IDS, ',')))
           AND SHZT = 1;
        IF V_COUNT > 1 THEN
            O_NOTE := '选中记录存在已审核通过记录！';
            RETURN;
        END IF;
    
        UPDATE TPIF_CPDM_ZDXS A
           SET A.SHZT = 1, A.CPRCSJ = SYSDATE
         WHERE ID IN (SELECT COLUMN_VALUE FROM TABLE(SPLIT(V_IDS, ','))); --更新审批状态
        SELECT '产品代码[' || TO_CHAR(WM_CONCAT(CPMC)) || ']的记录审核通过！'
          INTO V_CZSM
          FROM TPIF_CPDM_ZDXS
         WHERE ID IN (SELECT COLUMN_VALUE FROM TABLE(SPLIT(V_IDS, ','))); --记录日志
        O_CODE := 1;
    END IF;
    IF I_OPER = 3 THEN
        --启用
        NULL;
    END IF;
    IF I_OPER = 4 THEN
        NULL;
    END IF;

    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;

    O_CODE := 199;
    SELECT '执行[' ||
           DECODE(I_OPER, 0, '新增', 1, '修改', 2, '审核通过', 3, '启用', 4, '禁用', '') || ']成功!'
      INTO O_NOTE
      FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_ZDXSCPK;
/

