create PROCEDURE PRO_PIF_SMCPSR(O_RESULT OUT SYS_REFCURSOR,
                                           I_USERID IN NUMBER,  --用户ID
                                           I_YYB IN NUMBER,     --营业部
                                           I_CPMC IN VARCHAR2,  --产品名称
                                           I_LD IN NUMBER,  --粒度，1|月度;2|日度
                                           
                                           I_KSYF IN NUMBER,    --开始月份（月度）
                                           I_JSYF IN NUMBER,    --结束月份
                                           
                                           I_KSRQ IN NUMBER,    --开始日期（日度）
                                           I_JSRQ IN NUMBER,    --结束日期
                                           
                                           I_YWLX IN VARCHAR2   --业务类型，多选
                                           ) AS
                                           
/******************************************************************
  项目名称：财通证券运营展业平台-私募产品收入报表
  所属用户：PIF
  概要说明：私募产品收入

  语法信息：
       输出参数：
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/31     1.0.0.1   GAOKUN            新增.
  ********************************************************************/
                                           
V_NOTE VARCHAR2(1000);   --报错信息输出

V_BRANCH_ID NUMBER;  --组织机构id对应的营业部branch_id

BEGIN

  EXECUTE IMMEDIATE 'TRUNCATE TABLE PIF.TPIF_SMCPSR ';
  
  IF I_YYB IS NULL THEN
    V_BRANCH_ID:=NULL;
  ELSE
    BEGIN
      SELECT BRANCH_ID INTO V_BRANCH_ID FROM LIVEBOS.LBORGANIZATION WHERE ID=I_YYB;
    EXCEPTION WHEN OTHERS THEN
      V_BRANCH_ID:=NULL;
    END;    
  END IF;
  
  IF I_LD = 1 THEN 

    IF I_CPMC IS NULL AND V_BRANCH_ID IS NULL THEN  --产品名称和营业部均空，则 取所有
      INSERT INTO TPIF_SMCPSR
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_ID,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_BRANCH_INC_DD
         WHERE INIT_MONTH BETWEEN I_KSYF AND I_JSYF
           AND BRANCH_ID != 9999
         GROUP BY BRANCH_ID,CLIENT_ID;

    ELSIF  I_CPMC IS NULL AND V_BRANCH_ID IS NOT NULL THEN  --产品名称为空，营业部不为空，取该营业部
      INSERT INTO TPIF_SMCPSR
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_ID,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_BRANCH_INC_DD
         WHERE INIT_MONTH BETWEEN I_KSYF AND I_JSYF
           AND BRANCH_ID = V_BRANCH_ID
         GROUP BY BRANCH_ID,CLIENT_ID;

    ELSIF  I_CPMC IS NOT NULL AND V_BRANCH_ID IS  NULL THEN  --产品名称不为空，营业部为空，取该产品
      INSERT INTO TPIF_SMCPSR
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_ID,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_BRANCH_INC_DD
         WHERE INIT_MONTH BETWEEN I_KSYF AND I_JSYF
           AND CLIENT_NAME LIKE '%' || I_CPMC || '%'
         GROUP BY BRANCH_ID,CLIENT_ID;
   
    ELSE   --均不为空，取该营业部的该产品
      INSERT INTO TPIF_SMCPSR 
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_ID,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_BRANCH_INC_DD
         WHERE INIT_MONTH BETWEEN I_KSYF AND I_JSYF
           AND CLIENT_NAME LIKE '%' || I_CPMC || '%'
           AND BRANCH_ID = V_BRANCH_ID
         GROUP BY BRANCH_ID,CLIENT_ID;
    END IF;
    
  ELSIF I_LD = 2 THEN
    
    IF I_CPMC IS NULL AND V_BRANCH_ID IS NULL THEN  --产品名称和营业部均空，则 取所有
      INSERT INTO TPIF_SMCPSR
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_NO,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_NET_VALUE_DD
         WHERE INIT_DATE BETWEEN I_KSRQ AND I_JSRQ
       --    AND BRANCH_NO != 9999
         GROUP BY BRANCH_NO,CLIENT_ID;

    ELSIF  I_CPMC IS NULL AND V_BRANCH_ID IS NOT NULL THEN  --产品名称为空，营业部不为空，取该营业部
      INSERT INTO TPIF_SMCPSR
        (YYBDM,KHH,ZJYJ_SH)
        SELECT BRANCH_NO,CLIENT_ID,SUM(NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_NET_VALUE_DD
         WHERE INIT_DATE BETWEEN I_KSRQ AND I_JSRQ
           AND BRANCH_NO = V_BRANCH_ID
         GROUP BY BRANCH_NO,CLIENT_ID;

    ELSIF  I_CPMC IS NOT NULL AND V_BRANCH_ID IS  NULL THEN  --产品名称不为空，营业部为空，取该产品
      INSERT INTO TPIF_SMCPSR
        (YYBDM, KHH, ZJYJ_SH)
        SELECT A.BRANCH_NO, A.CLIENT_ID, SUM(A.NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_NET_VALUE_DD A, TPIF_SMCP B
         WHERE A.INIT_DATE BETWEEN I_KSRQ AND I_JSRQ
           AND A.CLIENT_ID = B.KHBH
           AND B.CPMC LIKE '%' || I_CPMC || '%'
         GROUP BY A.BRANCH_NO, A.CLIENT_ID;
   
    ELSE   --均不为空，取该营业部的该产品
      INSERT INTO TPIF_SMCPSR
        (YYBDM, KHH, ZJYJ_SH)
        SELECT A.BRANCH_NO, A.CLIENT_ID, SUM(A.NET_COMMISSION)
          FROM SRC_PIF.ADS_INF_PRIVATE_NET_VALUE_DD A, TPIF_SMCP B
         WHERE A.INIT_DATE BETWEEN I_KSRQ AND I_JSRQ
           AND A.CLIENT_ID = B.KHBH
           AND B.CPMC LIKE '%' || I_CPMC || '%'
           AND A.BRANCH_NO = V_BRANCH_ID
         GROUP BY A.BRANCH_NO, A.CLIENT_ID;
    END IF;
      
  END IF;  
  
  UPDATE TPIF_SMCPSR A    --补充相关数据
     SET A.YYBMC =
         (SELECT NAME
            FROM LIVEBOS.LBORGANIZATION B
           WHERE B.BRANCH_ID = A.YYBDM),
         A.FGS  =
         (SELECT B.NAME
            FROM LIVEBOS.LBORGANIZATION B
           WHERE B.ID = (SELECT FID
                           FROM LIVEBOS.LBORGANIZATION B
                          WHERE B.BRANCH_ID = A.YYBDM));
    UPDATE TPIF_SMCPSR A
     SET (A.YWLX, A.CPMC, A.YJCL, A.KHRQ, A.CLRQ, A.KHMC, A.KHZT) =
         (SELECT B.YWLX, B.CPMC, B.YJCL, B.KHRQ, B.CLRQ, B.CPMC, B.ZHZT
            FROM TPIF_SMCP B
           WHERE B.KHBH = A.KHH);
 /*          
  UPDATE TPIF_SMCPSR A
     SET A.CPMC =
         (SELECT B.FUND_FULL_NAME
            FROM TPIF_SCSMJJXX B
           WHERE B.ID =
                 (SELECT C.DYCPID FROM TPIF_SMCP C WHERE C.KHBH = A.KHH));*/
  
  INSERT INTO TPIF_SMCPSR  --计算合计
    (YYBMC, ZJYJ_SH)
    SELECT '合计', SUM(ZJYJ_SH) FROM TPIF_SMCPSR;
  
  COMMIT;
  
  OPEN O_RESULT FOR
    SELECT *
      FROM TPIF_SMCPSR
     WHERE INSTR(';' || I_YWLX || ';', ';' || YWLX || ';') > 0
        OR YYBMC = '合计'
     ORDER BY TO_NUMBER(YYBDM) ASC;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
END;
/

