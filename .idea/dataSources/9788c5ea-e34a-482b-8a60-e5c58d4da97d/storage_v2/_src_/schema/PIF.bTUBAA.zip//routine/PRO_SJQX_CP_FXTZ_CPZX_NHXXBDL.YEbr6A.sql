create PROCEDURE PRO_SJQX_CP_FXTZ_CPZX_NHXXBDL(O_CODE OUT NUMBER, --返回值
                                                          O_NOTE OUT VARCHAR2, --返回消息
                                                          I_RQ   IN NUMBER, --统计日期
                                                          I_JSRQ IN NUMBER  --统计区间结束日期
                                                          ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险特征-年化下行波动率计算
      语法信息：
           输入参数：   I_RQ     日期
           输出参数：   O_CODE  返回值
                       O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-15    1.0       吴金锋              创建
  ***********************************************************************/

  V_RQ            NUMBER;
  V_RQ_3Y         NUMBER; -- 近3月
  V_RQ_6Y         NUMBER; -- 近6月
  V_RQ_1N         NUMBER; -- 近1年
  V_RQ_3N         NUMBER; -- 近3年
  V_RQ_5N         NUMBER; -- 近5年
  V_RQ_JNYL       NUMBER; -- 今年以来
  V_RQ_CLYL       NUMBER; -- 成立以来
  V_RQ_3Y_NHBDL   NUMBER; -- 近3月
  V_RQ_6Y_NHBDL   NUMBER; -- 近6月
  V_RQ_1N_NHBDL   NUMBER; -- 近1年
  V_RQ_3N_NHBDL   NUMBER; -- 近3年
  V_RQ_5N_NHBDL   NUMBER; -- 近5年
  V_RQ_JNYL_NHBDL NUMBER; -- 今年以来
  V_RQ_CLYL_NHBDL NUMBER; -- 成立以来

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  V_RQ := I_JSRQ;

  -- 近3月
  SELECT JYR
    INTO V_RQ_3Y
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -3), 'YYYYMMDD');

  -- 近6月
  SELECT JYR
    INTO V_RQ_6Y
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -6), 'YYYYMMDD');

  -- 近1年
  SELECT JYR
    INTO V_RQ_1N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -12), 'YYYYMMDD');

  -- 近3年
  SELECT JYR
    INTO V_RQ_3N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -36), 'YYYYMMDD');

  -- 近5年
  SELECT JYR
    INTO V_RQ_5N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -60), 'YYYYMMDD');

  --今年以来
  SELECT JYR
    INTO V_RQ_JNYL
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR = TO_NUMBER(SUBSTR(V_RQ, 1, 4) || '0101');

  --循环获取每一只产品分别计算
  FOR CUR_ZHFA IN (SELECT CPID, JZRQ, JYRQ, DWJZ
                     FROM TEMP_TPIF_CPJZ
                    WHERE JYRQ = I_RQ) LOOP
  
    --V_RQ_CLYL NUMBER;  -- 成立以来
    SELECT MIN(JZRQ)
      INTO V_RQ_CLYL
      FROM TEMP_TPIF_CPJZ
     WHERE CPID = CUR_ZHFA.CPID;
  
    V_RQ_3Y_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                V_RQ_3Y,
                                                CUR_ZHFA.CPID);
    IF V_RQ_3Y_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_3月计算报错';
      RETURN;
    END IF;
  
    V_RQ_6Y_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                V_RQ_6Y,
                                                CUR_ZHFA.CPID);
    IF V_RQ_6Y_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_6月计算报错';
      RETURN;
    END IF;
  
    V_RQ_1N_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                V_RQ_1N,
                                                CUR_ZHFA.CPID);
    IF V_RQ_1N_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_1年计算报错';
      RETURN;
    END IF;
  
    V_RQ_3N_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                V_RQ_3N,
                                                CUR_ZHFA.CPID);
    IF V_RQ_3N_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_3年计算报错';
      RETURN;
    END IF;
  
    V_RQ_5N_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                V_RQ_5N,
                                                CUR_ZHFA.CPID);
    IF V_RQ_5N_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_5年计算报错';
      RETURN;
    END IF;
  
    V_RQ_JNYL_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                  V_RQ_JNYL,
                                                  CUR_ZHFA.CPID);
    IF V_RQ_JNYL_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_今年以来计算报错';
      RETURN;
    END IF;
  
    V_RQ_CLYL_NHBDL := FUNC_PIF_CPID_NHXXBDL_CPZX(V_RQ,
                                                  V_RQ_CLYL,
                                                  CUR_ZHFA.CPID);
    IF V_RQ_CLYL_NHBDL = -999 THEN
      O_CODE := -1;
      O_NOTE := '年化下行波动率_成立以来计算报错';
      RETURN;
    END IF;
  
    INSERT INTO TEMP_STAT_CP_FXTZ
      (RQ,
       CPID,
       JZRQ,
       JYRQ,
       DWJZ,
       NHXXBDL_3Y,
       NHXXBDL_6Y,
       NHXXBDL_1N,
       NHXXBDL_3N,
       NHXXBDL_5N,
       NHXXBDL_CLYL,
       NHXXBDL_JNYL)
    VALUES
      (V_RQ,
       CUR_ZHFA.CPID,
       CUR_ZHFA.JZRQ,
       CUR_ZHFA.JYRQ,
       CUR_ZHFA.DWJZ,
       V_RQ_3Y_NHBDL,
       V_RQ_6Y_NHBDL,
       V_RQ_1N_NHBDL,
       V_RQ_3N_NHBDL,
       V_RQ_5N_NHBDL,
       V_RQ_CLYL_NHBDL,
       V_RQ_JNYL_NHBDL
       );
  
  END LOOP;

  O_CODE := 1;
  O_NOTE := '产品收益特征-年化下行波动率清洗成功';

EXCEPTION
  WHEN OTHERS THEN
  
    O_CODE := -1;
    O_NOTE := '产品收益特征-年化下行波动率清洗失败';
END;
/

