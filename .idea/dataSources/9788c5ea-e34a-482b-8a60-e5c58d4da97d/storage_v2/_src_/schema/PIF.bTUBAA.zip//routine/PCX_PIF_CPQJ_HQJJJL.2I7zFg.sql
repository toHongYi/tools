create PROCEDURE PCX_PIF_CPQJ_HQJJJL(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                O_RESULT  OUT SYS_REFCURSOR,
                                                I_USERID  IN NUMBER, -- 用户ID
                                                I_PROD_ID IN NUMBER --产品ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-获取基金经理
  所属用户：PIF
  概要说明：获取基金经理.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        获取基金经理编号，然后有另外接口来查询基金经理的概况明细和管理的基金
        
        公募 聚源： 基金经理基本资料 TPIF_JJJLJBZL
                   基金与基金经理关联表 TPIF_JJYJJJLGLB
               
        私募 朝阳永续： 私募投资经理 TPIF_SMTZJL
                       基金与投资经理关联表 TPIF_JJYTZJLGLB       
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   TUMENG             新增.
      20200716       1.1       WUJINFENG          修改
      20201118                 GAOKUN             根据财通 表情况修改   
      2021-12-10     1.0.0.4   GAOKUN            根据财通表情况修改   
  **********************************************************************/
  V_SQL      VARCHAR2(4000);
  V_COUNT    NUMBER;
  V_CPLX     NUMBER; --产品类型
  V_CPDM     VARCHAR2(200); --根据入参 CPID 从产品代码表获取产品代码
  V_MAINCODE VARCHAR2(200); --公募基金概况表的主代码
  V_FUND_ID  NUMBER; --朝阳永续市场私募基金ID
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  BEGIN
    --获取产品类型，产品代码
    SELECT CPXL, TRIM(CPDM)
      INTO V_CPLX, V_CPDM
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
      V_CPDM := '0';
  END;

  IF V_CPLX = 1 THEN
    --公募
    SELECT COUNT(1) --先根据SECUCODE判断是否有记录
      INTO V_COUNT
      FROM INFO.TINFO_JJGK
     WHERE SECUCODE = V_CPDM;
  
    IF V_COUNT > 0 THEN
      --有则取主代码
      SELECT MAINCODE
        INTO V_MAINCODE
        FROM INFO.TINFO_JJGK
       WHERE SECUCODE = V_CPDM;
    
    ELSE
      --没有则根据后端代码取
      BEGIN
        SELECT MAINCODE
          INTO V_MAINCODE
          FROM INFO.TINFO_JJGK
         WHERE APPLYINGCODEBACK = V_CPDM;
      EXCEPTION
        WHEN OTHERS THEN
          V_MAINCODE := '0';
      END;
    END IF;
  
    V_SQL := 'SELECT A.ID AS FUND_MANAGER_NO, A.MC AS NAME, A.XB AS SEX
                FROM TPIF_JJJLJBZL A
               WHERE ID IN
                     (SELECT B.JJJLID FROM TPIF_JJYJJJLGLB B WHERE B.JJDM = ''' ||
             V_MAINCODE || ''')';
  
  ELSE
    --公墓以外的
  
    BEGIN
      SELECT ID INTO V_FUND_ID FROM TPIF_SCSMJJXX WHERE REG_CODE = V_CPDM;
    EXCEPTION
      WHEN OTHERS THEN
        V_FUND_ID := 0;
    END;
  
    V_SQL := 'SELECT A.ID AS FUND_MANAGER_NO, A.XM AS NAME, A.XB AS SEX
                FROM TPIF_SMTZJL A
               WHERE ID IN
                     (SELECT B.USER_ID FROM TPIF_JJYTZJLGLB B WHERE B.FUND_ID = ' ||
             V_FUND_ID || ')';
  
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_HQJJJL;
/

