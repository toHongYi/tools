create PROCEDURE PRO_PIF_CPXXSJDR( --产品信息数据导入
                                                 O_RESULT OUT INT, --返回结果代码
                                                 O_NOTE   OUT VARCHAR2, --返回结果说明
                                                 I_RQ     IN NUMBER, --日期
                                                 I_JGDM   IN VARCHAR2, --机构代码
                                                 I_USERID IN VARCHAR2, --用户ID, TUSER.USERID
                                                 I_IP     IN VARCHAR2 --操作站点
                                                 ) AS

  /******************************************************************************
  *
  *文件名称：PRO_PIF_CPXXSJDR
  *项目名称：海通产品中心
  *功能说明：TXT文件导入产品后处理主过程
   I_RQ     IN NUMBER  --日期
   I_JGDM   IN VARCHAR2, --机构代码
   I_USERID IN VARCHAR2, --用户ID, TUSER.USERID
   I_IP     IN VARCHAR2 --操作站点

  *------------------------------------------------------------------------------
  *修改者        版本号        修改日期         说明

  *孙远何        V1.0.1       2015-12-02        新增
  *****************************************************************************/

  V_COUNT NUMBER(8) := 0;
  --V_COUNT_CL  NUMBER(8) := 0;
  V_FXJG NUMBER;
  V_CZY  NUMBER;
  --V_TABLENAME VARCHAR2(60);
  --V_YWFL      NUMBER(8);
  --V_STATUS    NUMBER(8);
  --V_SQL       VARCHAR2(8000);
  V_JGDM  VARCHAR2(20) := I_JGDM;
  V_JOBID NUMBER(16);
  --V_RQ_PRE    NUMBER(8);
  V_PROC VARCHAR2(60);
BEGIN

  O_RESULT := 1;
  O_NOTE   := '成功';

  IF (V_JGDM IS NULL) THEN
    V_JGDM := '0000';
  END IF;
  BEGIN
    SELECT ID INTO V_CZY FROM livebos.TUSER WHERE userid = I_USERID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_RESULT := -1;
      O_NOTE   := '用户' || I_USERID || '不存在';
      RETURN;
  END;
  

  

  SELECT MAX(JOB_ID)
    INTO V_JOBID
    FROM TPIF_XTWJPZ
   WHERE YWFL = 7 /*产品信息文件*/
     AND JGDM = I_JGDM;

  /*--3|资料处理中
  select count(*) into v_count from TFILEJOB a where a.id  = V_JOBID and status=3;
  
  IF (V_COUNT > 0) THEN
    O_RESULT := -1;
    O_NOTE   := '对应机构的行情文件资料正在处理中';
   
    RETURN;
  END IF;
  */
  SELECT ID,
         CASE
           WHEN CORP_CLASS NOT IN (3, 4, 6) THEN
            'PRO_PIF_CPXXSJDR_' || I_JGDM
           ELSE
            'PRO_PIF_CPXXSJDR_OF)'
         END
    INTO V_FXJG, V_PROC
    FROM tORG_CODE_INFO
   WHERE ORG_CODE = V_JGDM;

  SELECT COUNT(1)
    INTO V_COUNT
    FROM USER_PROCEDURES
   WHERE OBJECT_NAME = 'PRO_PIF_CPXXSJDR_' || I_JGDM;
  IF (V_COUNT > 0) THEN
    V_PROC := 'PRO_PIF_CPXXSJDR_' || I_JGDM;
  ELSE
    V_PROC := 'PRO_PIF_CPXXSJDR_OF';
  END IF;
  
  SELECT COUNT(1)
    INTO V_COUNT
    FROM USER_PROCEDURES
   WHERE OBJECT_NAME = V_PROC;
  IF (V_COUNT = 0) THEN
    O_RESULT := -1;
    O_NOTE   := '对应执行过程' || V_PROC || '不存在';
    UPDATE TFILEJOB SET STATUS = -2, MSG = O_NOTE WHERE ID = V_JOBID;
    COMMIT;
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'BEGIN ' || V_PROC ||
                    '(:O_RESULT,:O_NOTE,:I_RQ,:I_JGDM,:I_USERID,:I_IP); END;'
    USING OUT O_RESULT, OUT O_NOTE, IN I_RQ, IN I_JGDM, IN I_USERID, IN I_IP;

EXCEPTION
  WHEN OTHERS THEN
    O_RESULT := -1;
    O_NOTE   := SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1000) ||
                SQLERRM;
    ROLLBACK;
    IF (V_JOBID > 0) THEN
      UPDATE TFILEJOB SET STATUS = -2, MSG = O_NOTE WHERE ID = V_JOBID;
      COMMIT;
    END IF;

END PRO_PIF_CPXXSJDR;
/

