create PROCEDURE PRO_SJQX_CP_FXTZ_CPZX_HIS(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_RQ   IN NUMBER --统计日期
                                                 ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险特征-DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX_HIS数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-05-19     1.0       李良              产品中心创建指标计算使用
  ***********************************************************************/
  V_COUNT NUMBER;
  V_RQ    NUMBER;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_RQ   := I_RQ;
  SELECT COUNT(1)
    INTO V_COUNT
    FROM DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX_HIS
   WHERE RQ = V_RQ;
   
  IF V_COUNT >0 THEN
    
     DELETE FROM DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX_HIS WHERE RQ = V_RQ ;
    
  END IF;
  
    INSERT INTO DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX_HIS
      (RQ,
       CPID,
       JZRQ,
       JYRQ,
       DWJZ,
       NHBDL_3Y,
       NHBDL_6Y,
       NHBDL_1N,
       NHBDL_3N,
       NHBDL_5N,
       NHBDL_CLYL,
       NHBDL_JNYL,
       NHXXBDL_3Y,
       NHXXBDL_6Y,
       NHXXBDL_1N,
       NHXXBDL_3N,
       NHXXBDL_5N,
       NHXXBDL_CLYL,
       NHXXBDL_JNYL,
       ZDHC_3Y,
       ZDHC_6Y,
       ZDHC_1N,
       ZDHC_3N,
       ZDHC_5N,
       ZDHC_CLYL,
       ZDHC_JNYL,
       KSBL_3Y,
       KSBL_6Y,
       KSBL_1N,
       KSBL_3N,
       KSBL_5N,
       KSBL_CLYL,
       KSBL_JNYL,
       DCZDKSSYL_3Y,
       DCZDKSSYL_6Y,
       DCZDKSSYL_1N,
       DCZDKSSYL_3N,
       DCZDKSSYL_5N,
       DCZDKSSYL_CLYL,
       DCZDKSSYL_JNYL,
       ZDLXKSCS_3Y,
       ZDLXKSCS_6Y,
       ZDLXKSCS_1N,
       ZDLXKSCS_3N,
       ZDLXKSCS_5N,
       ZDLXKSCS_CLYL,
       ZDLXKSCS_JNYL,
       KSPJSYL_3Y,
       KSPJSYL_6Y,
       KSPJSYL_1N,
       KSPJSYL_3N,
       KSPJSYL_5N,
       KSPJSYL_CLYL,
       KSPJSYL_JNYL
     )
      SELECT RQ,
             CPID,
             JZRQ,
             JYRQ,
             DWJZ,
             NHBDL_3Y,
             NHBDL_6Y,
             NHBDL_1N,
             NHBDL_3N,
             NHBDL_5N,
             NHBDL_CLYL,
             NHBDL_JNYL,
             NHXXBDL_3Y,
             NHXXBDL_6Y,
             NHXXBDL_1N,
             NHXXBDL_3N,
             NHXXBDL_5N,
             NHXXBDL_CLYL,
             NHXXBDL_JNYL,
             ZDHC_3Y,
             ZDHC_6Y,
             ZDHC_1N,
             ZDHC_3N,
             ZDHC_5N,
             ZDHC_CLYL,
             ZDHC_JNYL,
             KSBL_3Y,
             KSBL_6Y,
             KSBL_1N,
             KSBL_3N,
             KSBL_5N,
             KSBL_CLYL,
             KSBL_JNYL,
             DCZDKSSYL_3Y,
             DCZDKSSYL_6Y,
             DCZDKSSYL_1N,
             DCZDKSSYL_3N,
             DCZDKSSYL_5N,
             DCZDKSSYL_CLYL,
             DCZDKSSYL_JNYL,
             ZDLXKSCS_3Y,
             ZDLXKSCS_6Y,
             ZDLXKSCS_1N,
             ZDLXKSCS_3N,
             ZDLXKSCS_5N,
             ZDLXKSCS_CLYL,
             ZDLXKSCS_JNYL,
             KSPJSYL_3Y,
             KSPJSYL_6Y,
             KSPJSYL_1N,
             KSPJSYL_3N,
             KSPJSYL_5N,
             KSPJSYL_CLYL,
             KSPJSYL_JNYL

        FROM DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX
        WHERE RQ = V_RQ;
 
  O_CODE := 1;
  O_NOTE := '备份TPIF_STAT_CP_FXTZ_CPZX表数据到TPIF_STAT_CP_FXTZ_CPZX_HIS表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '备份TPIF_STAT_CP_FXTZ_CPZX表数据到TPIF_STAT_CP_FXTZ_CPZX_CPZX_HIS表清洗失败';

END;
/

