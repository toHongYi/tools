create PROCEDURE PRO_PIF_CPZT(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_USER IN INTEGER, --操作人
                                                I_IP   IN VARCHAR2, --操作IP
                                                I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;
                                                                   --5|变更升级节点;6|上移;7|下移;
                                                I_ID IN INTEGER, --操作ID
                                                I_OP IN VARCHAR2 := '' --其他参数
                                                ) IS
    /*
    **功能说明：产品专题管理
    **创建人：戴文生
    **创建日期：2014-12-01
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生              2014-12-01    创建
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_CPZT%ROWTYPE; --表单记录
    V_ZHID  INTEGER; --显示排序置换ID
    V_XSSX  INTEGER; --显示排序
    --V_SCBZ    INTEGER; --日志删除标识
    --V_OPER    VARCHAR2(200); --操作方法
    --V_FDETAIL VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPZT WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF I_IP = '[check]' THEN
            IF I_ID IS NOT NULL THEN
                SELECT COUNT(1)
                  INTO V_COUNT
                  FROM TPIF_CPZT
                 WHERE ID = I_ID
                   AND TYPE = 2;
                IF V_COUNT > 0 THEN
                    O_NOTE := '叶子节点不允许新增下级节点!';
                    RETURN;
                END IF;
            END IF;
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[专题名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS IS NULL THEN
            O_NOTE := '[映射方式]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[映射集合]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZT WHERE NAME = V_OBJ.NAME;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[专题名称]--'||V_OBJ.NAME||'!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZT;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 0 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[根节点]!';
            RETURN;
        END IF;
        IF V_OBJ.TYPE = 2 THEN
            IF V_OBJ.YSFS IS NULL THEN
                O_NOTE := '[映射方式]不允许为空!';
                RETURN;
            END IF;
            IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
                O_NOTE := '[映射集合]不允许为空!';
                RETURN;
            END IF;
        END IF;
        IF V_OBJ.FID IS NULL THEN
            UPDATE TPIF_CPZT
               SET FID     = 0,
                   GRADE   = 0,
                   TYPE    = 1,
                   FDNCODE = 0,
                   YSFS = '',
                   CPJH = '',
                   XSSX = 0
             WHERE ID = I_ID;
        ELSE
            FOR CUR IN (SELECT * FROM TPIF_CPZT WHERE ID = V_OBJ.FID) LOOP
                UPDATE TPIF_CPZT
                   SET GRADE   = CUR.GRADE + 1,
                       FDNCODE = CUR.FDNCODE || '.' || CUR.ID,
                       CPJH = (CASE
                                    WHEN YSFS != 1 THEN
                                     ''
                                    ELSE
                                     CPJH
                                END),
                       XSSX   =
                       (SELECT NVL(MAX(T.XSSX), 0) + 1
                          FROM TPIF_CPZT T
                         WHERE T.FID = V_OBJ.FID)
                 WHERE ID = I_ID;
            END LOOP;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前节点已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.TYPE IS NULL THEN
            O_NOTE := '[节点类型]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.NAME IS NULL THEN
            O_NOTE := '[专题名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS IS NULL THEN
            O_NOTE := '[映射方式]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[映射集合]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZT WHERE NAME = V_OBJ.NAME;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[专题名称]--'||V_OBJ.NAME||'!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZT;
        IF V_COUNT = 0 AND V_OBJ.TYPE != 1 THEN
            O_NOTE := '[节点类型]请选择[根节点]!';
            RETURN;
        END IF;
        IF V_COUNT > 0 AND V_OBJ.TYPE = 1 THEN
            O_NOTE := '[节点类型]不允许再选择[根节点]!';
            RETURN;
        END IF;
        IF V_OBJ.TYPE = 2 THEN
            IF V_OBJ.YSFS IS NULL THEN
                O_NOTE := '[映射方式]不允许为空!';
                RETURN;
            END IF;
            IF V_OBJ.YSFS = 1 AND V_OBJ.CPJH IS NULL THEN
                O_NOTE := '[映射集合]不允许为空!';
                RETURN;
            END IF;
        END IF;
        UPDATE TPIF_CPZT
                   SET CPJH = (CASE
                                    WHEN YSFS != 1 THEN
                                     ''
                                    ELSE
                                     I_OP
                                END)
                 WHERE ID = I_ID;
        IF NVL(V_OBJ.YSFS,0) = 1 AND V_OBJ.CPJH != I_OP THEN
            PIF.PRO_PIF_JHSX(O_CODE,O_NOTE,I_USER,I_IP,2,I_ID);
            IF O_CODE <= 0 THEN RETURN;ELSE O_CODE := -1; O_NOTE := ''; END IF;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.ZT = 1 THEN
            O_NOTE := '当前记录已[启用]!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_CPZT', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前产品专题已存在引用记录!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPZT WHERE FID = I_ID;
        IF V_COUNT > 0 THEN
            O_NOTE := '当前节点存在下级节点!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_CPZT WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF I_OP = 1 THEN
            IF V_OBJ.ZT = 1 THEN
                O_NOTE := '当前节点已[启用]!';
                RETURN;
            END IF;
            UPDATE TPIF_CPZT SET ZT = 1 WHERE ID = I_ID;
        ELSIF I_OP = 2 THEN
            UPDATE TPIF_CPZT
               SET ZT = 1
             WHERE INSTR('.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.', '.' || ID || '.') > 0;
        END IF;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF I_OP = 1 THEN
            IF V_OBJ.ZT = -1 THEN
                O_NOTE := '当前节点已[禁用]!';
                RETURN;
            END IF;
            UPDATE TPIF_CPZT SET ZT = -1 WHERE ID = I_ID;
        ELSIF I_OP = 2 THEN
            UPDATE TPIF_CPZT
               SET ZT = -1
             WHERE INSTR('.' || FDNCODE || '.', '.' || V_OBJ.FDNCODE || '.') > 0;
        END IF;
    END IF;
    IF I_OPER = 5 THEN
        --变更上级节点-----------------------------------------------------------------
        FOR CUR IN (SELECT * FROM TPIF_CPZT WHERE ID = I_OP) LOOP
            UPDATE TPIF_CPZT
               SET GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE INSTR('.' || FDNCODE || '.',
                         '.' || V_OBJ.FDNCODE || '.' || V_OBJ.ID || '.') > 0;
            UPDATE TPIF_CPZT
               SET FID     = I_OP,
                   GRADE   = GRADE - V_OBJ.GRADE + CUR.GRADE + 1,
                   FDNCODE = REPLACE(FDNCODE, V_OBJ.FDNCODE, CUR.FDNCODE || '.' || CUR.ID)
             WHERE ID = I_ID;
        END LOOP;
        UPDATE TPIF_CPZT A
           SET A.XSSX =
               (SELECT NVL(MAX(T.XSSX), 0) + 1
                  FROM TPIF_CPZT T
                 WHERE T.FID = I_OP
                   AND T.ID != I_ID)
         WHERE A.ID = I_ID;
    END IF;
    IF I_OPER = 6 THEN
        --上移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZT
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZT
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSSX < V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最高排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM TPIF_CPZT T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSSX = (SELECT MAX(A.XSSX)
                           FROM TPIF_CPZT A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSSX < V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPZT SET XSSX = V_XSSX WHERE ID = I_ID;
        UPDATE TPIF_CPZT SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    IF I_OPER = 7 THEN
        --下移-----------------------------------------------------------------------
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZT
         WHERE FID = V_OBJ.FID
           AND ID != I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点范围内不存在其他数据!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPZT
         WHERE FID = V_OBJ.FID
           AND ID != I_ID
           AND XSSX > V_OBJ.XSSX;
        IF V_COUNT = 0 THEN
            O_NOTE := '当前节点已处于允许的最低排序!';
            RETURN;
        END IF;
        SELECT T.ID, T.XSSX
          INTO V_ZHID, V_XSSX
          FROM TPIF_CPZT T
         WHERE T.FID = V_OBJ.FID
           AND T.ID != I_ID
           AND T.XSSX = (SELECT MIN(A.XSSX)
                           FROM TPIF_CPZT A
                          WHERE A.FID = V_OBJ.FID
                            AND A.ID != I_ID
                            AND A.XSSX > V_OBJ.XSSX)
           AND ROWNUM = 1;
        UPDATE TPIF_CPZT SET XSSX = V_XSSX WHERE ID = I_ID;
        UPDATE TPIF_CPZT SET XSSX = V_OBJ.XSSX WHERE ID = V_ZHID;
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           5,
                           '变更升级节点',
                           6,
                           '上移',
                           '下移') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPZT;

/

