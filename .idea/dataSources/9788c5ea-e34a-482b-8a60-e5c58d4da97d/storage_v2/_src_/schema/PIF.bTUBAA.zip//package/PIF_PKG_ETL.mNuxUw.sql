create PACKAGE PIF_PKG_ETL IS

  --采集程序主调度
  PROCEDURE PRO_PIF_ETL_MAIN(O_CODE OUT NUMBER,
                             O_NOTE OUT VARCHAR2,
                             I_BID  IN NUMBER); --采集表ID

  --采集程序开始日志
  PROCEDURE PRO_PIF_ETL_BEGIN(O_CODE    OUT NUMBER,
                              O_NOTE    OUT VARCHAR2,
                              O_TBBZZDZ OUT NUMBER, --同步标志最大值
                              O_RZID    OUT NUMBER, --日志ID
                              I_BID     IN NUMBER --采集表ID
                              );

  --采集程序结束日志
  PROCEDURE PRO_PIF_ETL_END(O_CODE OUT NUMBER,
                            O_NOTE OUT VARCHAR2,
                            I_BID  IN NUMBER --采集表ID
                            );

  --记录采集日志
  PROCEDURE PRO_PIF_ETL_LOG(I_RZID IN NUMBER, --ID
                            I_SJL  IN NUMBER,
                            I_ZT   IN NUMBER,
                            I_BZ   IN VARCHAR2);

  --柜台-产品代码设置采集逻辑
  PROCEDURE PRO_PRODCODE(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER);

  --柜台-产品业务设置
  PROCEDURE PRO_PRODALLOWBUSIN(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER);
  --柜台-产品额度设置
  PROCEDURE PRO_PRODCONTROL(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);

  --柜台-产品延迟交收设置
  PROCEDURE PRO_PRODDELAYDATE(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER);

  --柜台-产品折扣设置
  PROCEDURE PRO_PRODDISCOUNT(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER);

  --柜台-产品限额设置
  PROCEDURE PRO_PRODQUOT(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER);

  --柜台-产品报送代码设置
  PROCEDURE PRO_PRODSENDCODE(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER);

  --柜台-产品TA
  PROCEDURE PRO_PRODARG(O_CODE     OUT NUMBER,
                        O_NOTE     OUT VARCHAR2,
                        O_ROWCOUNT OUT NUMBER,
                        I_TBBZZDZ  IN NUMBER);

  --柜台-产品控制串
  PROCEDURE PRO_PRODCONTRLSTRUSE(O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER);
  --柜台-产品行情表
  PROCEDURE PRO_PRODPRICE(O_CODE     OUT NUMBER,
                          O_NOTE     OUT VARCHAR2,
                          O_ROWCOUNT OUT NUMBER,
                          I_TBBZZDZ  IN NUMBER);

  --柜台-客户表
  PROCEDURE PRO_CLIENT(O_CODE     OUT NUMBER,
                       O_NOTE     OUT VARCHAR2,
                       O_ROWCOUNT OUT NUMBER,
                       I_TBBZZDZ  IN NUMBER);

  --柜台-证券理财交割流水
  PROCEDURE PRO_SECUMDELIVER(O_CODE     OUT NUMBER,
                             O_NOTE     OUT VARCHAR2,
                             O_ROWCOUNT OUT NUMBER,
                             I_TBBZZDZ  IN NUMBER);

  --柜台-证券理财份额表
  PROCEDURE PRO_SECUMSHARE(O_CODE     OUT NUMBER,
                           O_NOTE     OUT VARCHAR2,
                           O_ROWCOUNT OUT NUMBER,
                           I_TBBZZDZ  IN NUMBER);

  --基金概况采集后处理逻辑
  PROCEDURE PRO_MF_FUNDARCHIVES(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER);
  --基金概况附表
  PROCEDURE PRO_MF_FUNDARCHIVESATTACH(O_CODE     OUT NUMBER,
                                      O_NOTE     OUT VARCHAR2,
                                      O_ROWCOUNT OUT NUMBER,
                                      I_TBBZZDZ  IN NUMBER);
  --基金发行与上市
  PROCEDURE PRO_MF_ISSUEANDLISTING(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER);
  --基金分红
  PROCEDURE PRO_MF_DIVIDEND(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);
  --基金管理人主要人员介绍
  PROCEDURE PRO_MF_ADVISORPERSONNEL(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);
  --基金管理人概况
  PROCEDURE PRO_MF_INVESTADVISOROUTLINE(O_CODE     OUT NUMBER,
                                        O_NOTE     OUT VARCHAR2,
                                        O_ROWCOUNT OUT NUMBER,
                                        I_TBBZZDZ  IN NUMBER);
  --公募基金经理基本资料
  PROCEDURE PRO_MF_PERSONALINFO(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER);

  --公募基金经理(新)
  PROCEDURE PRO_MF_FUNDMANAGERNEW(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);
  --基金费率表
  PROCEDURE PRO_MF_CHARGERATENEW(O_CODE     OUT NUMBER,
                                 O_NOTE     OUT VARCHAR2,
                                 O_ROWCOUNT OUT NUMBER,
                                 I_TBBZZDZ  IN NUMBER);
  --系统常量表（数据字典）
  PROCEDURE PRO_CT_SYSTEMCONST(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER);

  --行业表
  PROCEDURE PRO_CT_INDUSTRY(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);

  --基金拆分折算
  PROCEDURE PRO_MF_SHARESSPLIT(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER);

  --基金托管人概况
  PROCEDURE PRO_MF_TRUSTEEOUTLINE(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --基金托管人主要人员介绍
  PROCEDURE PRO_MF_TRUSTEEPERSONNEL(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --公募基金聚源分类
  PROCEDURE PRO_MF_JYFUNDTYPE(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER);

  --信托理财要素表
  PROCEDURE PRO_SF_TRPLANINFO(O_CODE     OUT NUMBER,
                              O_NOTE     OUT VARCHAR2,
                              O_ROWCOUNT OUT NUMBER,
                              I_TBBZZDZ  IN NUMBER);

  --私募基金基本信息
  PROCEDURE PRO_SF_POFBASICINFO(O_CODE     OUT NUMBER,
                                O_NOTE     OUT VARCHAR2,
                                O_ROWCOUNT OUT NUMBER,
                                I_TBBZZDZ  IN NUMBER);

  --私募基金经理基本资料
  PROCEDURE PRO_SF_POFMANAGERINFO(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --私募基金费率信息表
  PROCEDURE PRO_SF_POFRATEINFO(O_CODE     OUT NUMBER,
                               O_NOTE     OUT VARCHAR2,
                               O_ROWCOUNT OUT NUMBER,
                               I_TBBZZDZ  IN NUMBER);

  --理财产品主表
  PROCEDURE PRO_SF_PLANMAIN(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);

  --证券主表
  PROCEDURE PRO_SECUMAIN(O_CODE     OUT NUMBER,
                         O_NOTE     OUT VARCHAR2,
                         O_ROWCOUNT OUT NUMBER,
                         I_TBBZZDZ  IN NUMBER);

  --证券主表_香港 聚源库
  PROCEDURE PRO_HK_SECUMAIN(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);

  --基金行业投资
  PROCEDURE PRO_MF_INVESTINDUSTRY(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);

  --基金资产配置
  PROCEDURE PRO_MF_ASSETALLOCATION(O_CODE     OUT NUMBER,
                                   O_NOTE     OUT VARCHAR2,
                                   O_ROWCOUNT OUT NUMBER,
                                   I_TBBZZDZ  IN NUMBER);

  --基金重仓股票组合
  PROCEDURE PRO_MF_KEYSTOCKPORTFOLIO(O_CODE     OUT NUMBER,
                                     O_NOTE     OUT VARCHAR2,
                                     O_ROWCOUNT OUT NUMBER,
                                     I_TBBZZDZ  IN NUMBER);

  --基金债券组合明细
  PROCEDURE PRO_MF_BONDPORTIFOLIODETAIL(O_CODE     OUT NUMBER,
                                        O_NOTE     OUT VARCHAR2,
                                        O_ROWCOUNT OUT NUMBER,
                                        I_TBBZZDZ  IN NUMBER);

  --基金净值
  PROCEDURE PRO_MF_NETVALUE(O_CODE     OUT NUMBER,
                            O_NOTE     OUT VARCHAR2,
                            O_ROWCOUNT OUT NUMBER,
                            I_TBBZZDZ  IN NUMBER);
  --基金复权净值
  PROCEDURE PRO_MF_FUNDNETVALUERE(O_CODE     OUT NUMBER,
                                  O_NOTE     OUT VARCHAR2,
                                  O_ROWCOUNT OUT NUMBER,
                                  I_TBBZZDZ  IN NUMBER);
  --基金净值最新表现
  PROCEDURE PRO_MF_NETVALUEPERFORMANCE(O_CODE     OUT NUMBER,
                                       O_NOTE     OUT VARCHAR2,
                                       O_ROWCOUNT OUT NUMBER,
                                       I_TBBZZDZ  IN NUMBER);
  --基金净值历史表现
  PROCEDURE PRO_MF_NETVALUEPERFORMANCEHIS(O_CODE     OUT NUMBER,
                                          O_NOTE     OUT VARCHAR2,
                                          O_ROWCOUNT OUT NUMBER,
                                          I_TBBZZDZ  IN NUMBER);
  --基金行情表现
  PROCEDURE PRO_QT_FUNDSPERFORMANCE(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

  --基金临时公告
  PROCEDURE PRO_MF_INTERIMBULLETIN(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);
 --基金公告原文
  PROCEDURE PRO_MF_ANNOUNCEMENT(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);

 --指数行情  INNERCODE IN(3145 ,4978,1,1055,7542,11089)
  PROCEDURE PRO_QT_INDEXQUOTE(O_CODE     OUT NUMBER,
                                    O_NOTE     OUT VARCHAR2,
                                    O_ROWCOUNT OUT NUMBER,
                                    I_TBBZZDZ  IN NUMBER);


END;

/

