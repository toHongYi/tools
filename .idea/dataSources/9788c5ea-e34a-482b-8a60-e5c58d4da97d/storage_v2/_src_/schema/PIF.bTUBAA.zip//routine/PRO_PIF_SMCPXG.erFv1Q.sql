create PROCEDURE PRO_PIF_SMCPXG(O_CODE   OUT NUMBER,
                                           O_NOTE   OUT VARCHAR2,
                                           I_SMCPID IN NUMBER, --被修改那条记录的ID
                                           I_USERID IN NUMBER) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募经纪户维护-修改方法
                
      语法信息：
  
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-03-05     1.0.0     高昆                创建
          2021-05-11     1.0.1     高昆              审核通过进入私募运营产品表 
          2021-10-28     1.1.0     LTX               需求变动，调整 
  ***********************************************************************/
  V_IDS VARCHAR2(2000); --私募产品表记录ID串，逗号分隔

  V_YJFL NUMBER; --一级策略
  V_EJFL NUMBER; --二级策略
  V_SJFL NUMBER; --三级策略
  --  V_DXCPDM  VARCHAR2(200);
  CUR_JJHWH TPIF_SMJJHWH%ROWTYPE;

  V_ZYNM NUMBER; --原朝阳内码

  V_COUNT NUMBER;

  V_CPDM_SMYY_ID      NUMBER; --TPIF_CPDM_SMYY表修改的产品的ID
  V_CPDM_SMYY_NEXT_ID NUMBER; --TPIF_CPDM_SMYY表的NEXT ID
  V_CPDM_SMYY_IDS     VARCHAR2(2000) := ''; --记录这次审核后，TPIF_CPDM_SMYY表里新增或修改的记录的ID，后面CPDM表
  --更新数据时，只需针对这些记录更新，不用全表更新
BEGIN

  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_NOTE := 'I_USERID不能为空！';
    RETURN;
  END IF;

  --修改
  IF I_SMCPID IS NULL THEN
    O_NOTE := 'I_SMCPID不能为空！';
    RETURN;
  ELSE
    V_IDS := TO_CHAR(I_SMCPID); --  900258
  END IF;

  /*****一丶判断私募内部产品表里有无该产品数据，有则更新，没有则新增，根据朝阳永续ID匹配*****/
  FOR CUR_DYCPID IN (SELECT * FROM TPIF_SMJJHWH WHERE ID = V_IDS) LOOP
  
    IF CUR_DYCPID.SMNBCPID IS  NULL THEN
      --该记录还没有匹配，因此没有对应的私募内部CPID
    
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPDM_SMYY
       WHERE ZYNM = CUR_DYCPID.DYCPID;
      --判断私募内部表是否已经存在对应该朝阳永续产品的记录
    
      IF V_COUNT = 0 THEN
        --TPIF_CPDM_SMYY表不存在，新增
        V_CPDM_SMYY_NEXT_ID := LIVEBOS.FUNC_NEXTID('TPIF_CPDM_SMYY');
        V_CPDM_SMYY_ID      := V_CPDM_SMYY_NEXT_ID;
      
        INSERT INTO TPIF_CPDM_SMYY
          (ID, --  ID                                  
           JRCPFL, -- 一级分类
           CPXL, -- 产品类型
           CPNBZT, -- 产品内部状态
           CPDM, -- 备案编号，取朝阳永续的备案编号
           CLRQ, -- 产品成立日期             
           CPGLRID, --产品管理人ID
           ZYNM, --朝阳内码，对应朝阳永续私募基金信息表的ID
           CPYWLX, --产品业务类型
           ZHXGR,
           ZHXGSJ,
           GLKHH, --关联客户号
           CPMC --产品名称
           )
        VALUES
          (V_CPDM_SMYY_NEXT_ID,
           CUR_DYCPID.JRCPFL, --一级分类
           CUR_DYCPID.CPXL, --产品类型
           8, --已上架
           CUR_DYCPID.XHBADM,
           CUR_DYCPID.CLRQ,
           CUR_DYCPID.JJGLR,
           CUR_DYCPID.DYCPID,
           2,
           CUR_DYCPID.ZHXGR,
           SYSDATE,
           CUR_DYCPID.KHBH,
           CUR_DYCPID.CPMC);
      ELSE
        --TPIF_CPDM_SMYY表存在，则更新
        SELECT ID --获取该私募内部表的记录的ID
          INTO V_CPDM_SMYY_ID
          FROM TPIF_CPDM_SMYY
         WHERE ZYNM = CUR_DYCPID.DYCPID;
      
        UPDATE TPIF_CPDM_SMYY A
           SET A.CPMC    = CUR_DYCPID.CPMC,
               A.CPGLRID = CUR_DYCPID.JJGLR,
               A.CPGLRMC =
               (SELECT JGJC FROM TPIF_JGDM WHERE ID = CUR_DYCPID.JJGLR),
               --A.ZYNM    = CUR_DYCPID.DYCPID,
               A.CPDM   = CUR_DYCPID.XHBADM,
               A.CPXL   = CUR_DYCPID.CPXL,
               A.JRCPFL = CUR_DYCPID.JRCPFL,
               A.ZHXGSJ = SYSDATE,
               A.GLKHH = (CASE
                           WHEN A.GLKHH IS NULL THEN
                            CUR_DYCPID.KHBH
                           WHEN A.GLKHH IS NOT NULL AND
                                INSTR(A.GLKHH, CUR_DYCPID.KHBH) = 0 THEN
                            A.GLKHH || ',' || CUR_DYCPID.KHBH
                           ELSE
                            A.GLKHH
                         END)
         WHERE A.ID = V_CPDM_SMYY_ID;
      
      END IF;
      --该记录匹配后，补充私募内部CPID字段
      UPDATE TPIF_SMJJHWH SET SMNBCPID = V_CPDM_SMYY_ID WHERE ID = V_IDS;
    
    ELSE
      --该经纪户记录已经匹配，对应私募内部CPID存在，则该CPID即私募内部产品表的ID
    
      SELECT ZYNM --获取该记录修改前对应的朝阳永续产品
        INTO V_ZYNM
        FROM TPIF_CPDM_SMYY
       WHERE ID = CUR_DYCPID.SMNBCPID;
    
      IF (V_ZYNM = CUR_DYCPID.DYCPID) THEN
        --如果修改前对应朝阳永续产品和当前的朝阳永续产品一样，即对应朝阳永续产品没变
        V_CPDM_SMYY_ID := CUR_DYCPID.SMNBCPID;
      
        UPDATE TPIF_CPDM_SMYY A
           SET A.CPMC    = CUR_DYCPID.CPMC,
               A.CPGLRID = CUR_DYCPID.JJGLR,
               A.CPGLRMC =
               (SELECT JGJC FROM TPIF_JGDM WHERE ID = CUR_DYCPID.JJGLR),
               --A.ZYNM    = CUR_DYCPID.DYCPID,
               A.CPDM   = CUR_DYCPID.XHBADM,
               A.CPXL   = CUR_DYCPID.CPXL,
               A.JRCPFL = CUR_DYCPID.JRCPFL,
               A.ZHXGSJ = SYSDATE,
               A.GLKHH = (CASE
                           WHEN A.GLKHH IS NULL THEN
                            CUR_DYCPID.KHBH
                           WHEN A.GLKHH IS NOT NULL AND
                                INSTR(A.GLKHH, CUR_DYCPID.KHBH) = 0 THEN
                            A.GLKHH || ',' || CUR_DYCPID.KHBH
                           ELSE
                            A.GLKHH
                         END)
         WHERE A.ID = CUR_DYCPID.SMNBCPID;
      
      ELSE
        --对应朝阳永续产品 改变，特殊处理
        --查看当前经纪户表里已经匹配的记录中，是否存在对应朝阳永续产品和修改前的朝阳永续产品相同的产品
        --这一步主要是针对一个产品对应多条客户号的情况
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_SMJJHWH
         WHERE DYCPID = V_ZYNM
           AND SFPP = 1;
      
        IF V_COUNT = 0 THEN
          --不存在该对应朝阳永续产品了，删掉
          DELETE FROM TPIF_CPDM_SMYY WHERE ID = CUR_DYCPID.SMNBCPID;
        ELSE
          --存在则保留，更新客户号
          UPDATE TPIF_CPDM_SMYY
             SET GLKHH = TRIM(',' FROM REPLACE(GLKHH, CUR_DYCPID.KHBH, ''))
           WHERE ID = CUR_DYCPID.SMNBCPID;
        END IF;
      
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPDM_SMYY
         WHERE ZYNM = CUR_DYCPID.DYCPID;
        --判断私募内部表是否已经存在对应该朝阳永续产品的记录
      
        IF V_COUNT = 0 THEN
          --TPIF_CPDM_SMYY表不存在，新增
          V_CPDM_SMYY_NEXT_ID := LIVEBOS.FUNC_NEXTID('TPIF_CPDM_SMYY');
          V_CPDM_SMYY_ID      := V_CPDM_SMYY_NEXT_ID;
        
          INSERT INTO TPIF_CPDM_SMYY
            (ID, --  ID                                  
             JRCPFL, -- 一级分类
             CPXL, -- 产品类型
             CPNBZT, -- 产品内部状态
             CPDM, -- 备案编号，取朝阳永续的备案编号
             CLRQ, -- 产品成立日期             
             CPGLRID, --产品管理人ID
             ZYNM, --朝阳内码，对应朝阳永续私募基金信息表的ID
             CPYWLX, --产品业务类型
             ZHXGR,
             ZHXGSJ,
             GLKHH, --关联客户号
             CPMC --产品名称
             )
          VALUES
            (V_CPDM_SMYY_NEXT_ID,
             CUR_DYCPID.JRCPFL, --一级分类
             CUR_DYCPID.CPXL, --产品类型
             8, --已上架
             CUR_DYCPID.XHBADM,
             CUR_DYCPID.CLRQ,
             CUR_DYCPID.JJGLR,
             CUR_DYCPID.DYCPID,
             2,
             CUR_DYCPID.ZHXGR,
             SYSDATE,
             CUR_DYCPID.KHBH,
             CUR_DYCPID.CPMC);
        ELSE
          --TPIF_CPDM_SMYY表存在，则更新
          SELECT ID --获取该私募内部表的记录的ID
            INTO V_CPDM_SMYY_ID
            FROM TPIF_CPDM_SMYY
           WHERE ZYNM = CUR_DYCPID.DYCPID;
        
          UPDATE TPIF_CPDM_SMYY A
             SET A.CPMC    = CUR_DYCPID.CPMC,
                 A.CPGLRID = CUR_DYCPID.JJGLR,
                 A.CPGLRMC =
                 (SELECT JGJC FROM TPIF_JGDM WHERE ID = CUR_DYCPID.JJGLR),
                 --A.ZYNM    = CUR_DYCPID.DYCPID,
                 A.CPDM   = CUR_DYCPID.XHBADM,
                 A.CPXL   = CUR_DYCPID.CPXL,
                 A.JRCPFL = CUR_DYCPID.JRCPFL,
                 A.ZHXGSJ = SYSDATE,
                 A.GLKHH = (CASE
                             WHEN A.GLKHH IS NULL THEN
                              CUR_DYCPID.KHBH
                             WHEN A.GLKHH IS NOT NULL AND
                                  INSTR(A.GLKHH, CUR_DYCPID.KHBH) = 0 THEN
                              A.GLKHH || ',' || CUR_DYCPID.KHBH
                             ELSE
                              A.GLKHH
                           END)
           WHERE A.ID = V_CPDM_SMYY_ID;
        
        END IF;
        --该记录匹配后，补充私募内部CPID字段
        UPDATE TPIF_SMJJHWH SET SMNBCPID = V_CPDM_SMYY_ID WHERE ID = V_IDS;
      
      END IF;
    END IF;
  END LOOP;

  /*  \******二丶通过柜台基金信息表补充部分字段信息******\
  MERGE INTO PIF.TPIF_CPDM_SMYY M
  USING (SELECT PRODTA_NO, --  TA代码
                PROD_CODE, --  产品代码
                PROD_NAME, --  产品名称
                PRODSPELL_CODE, --  拼音代码
                IPO_BEGIN_DATE, --  募集开始日期
                IPO_END_DATE, --  募集结束日期
                PROD_BEGIN_DATE, --  产品成立日期
                PROD_END_DATE, --  产品结束日期
                PROM_BEGIN_DATE, --  推介开始日期
                PROM_END_DATE, --  推介结束日期
                PROD_TERM, --  产品期限
                PROD_STATUS, --  产品交易状态
                MONEY_TYPE, --   币种类别
                ISSUE_PRICE, --  发行价格
                PAR_VALUE, --  每份面值
                TRIM(CHARGE_TYPE) AS CHARGE_TYPE, --  基金收费方式
                TRIM(DIVIDEND_WAY) AS DIVIDEND_WAY, --  基金分红方式
                MIN_SHARE, --  个人最低认购金额
                PROD_MIN_BALA, --  产品最低募集金额
                PROD_MAX_BALA, --  产品最高募集金额
                PROD_REAL_BALA, --  产品实际募集金额
                YEAR_DAYS, --  产品年化天数
                PRODPRE_RATIO, --  产品预期年收益率
                PROD_RATIO_STR, --  产品预期年收益率文字描述
  
                PRODCOMPANY_NAME, --  产品注册登记机构名称
                --PROD_MANAGER, --  产品管理人
                --PROD_TRUSTEE, --  产品托管人
  
                TRIM(INVEST_TYPE) AS INVEST_TYPE, -- 产品投资类别
                TRIM(INCOME_TYPE) AS INCOME_TYPE, -- 产品收益类型
                TRIM(PROD_INVEST_TERM) AS PROD_INVEST_TERM, -- 产品投资期限
                TRIM(PRODRISK_LEVEL) AS PRODRISK_LEVEL, -- 产品风险等级
                TRIM(ASSESS_LEVEL) AS ASSESS_LEVEL, -- 产品评估等级
                TRIM(LOW_CORP_RISK_LEVEL) AS LOW_CORP_RISK_LEVEL, -- 最低风险等级
                TRIM(MIN_ASSET_NEED) AS MIN_ASSET_NEED, -- 投资者最低资产要求
                TRIM(EN_PROF_FLAG) AS EN_PROF_FLAG, -- 允许专业投资者类型
  
                CURRENT_AMOUNT_LOW, --持仓量的最低值
                MAX_SUBSCRIBE_NUM, --认购人数上限
                MIN_SWITCH_IN_BALANCE, --最低转换金额
                TRANS_LIMITSHARE, --最少转换份额
                SWITCH_UNIT, --转换单位
                REDEEM_LIMITSHARE, --赎回最低份额
                REDEMPTION_UNIT, --赎回最小单位
                TRIM(REDEEM_USE_FLAG) AS REDEEM_USE_FLAG, --赎回资金可用标志
                TRIM(MAX_ALLOTRATIO) AS MAX_ALLOTRATIO --每次最大可申购比例
           FROM SRC_PIF.DWD_PRD_PRODCODE_DD A
          WHERE TRIM(A.PRODCODE_TYPE) IS NOT NULL 
            AND EXISTS (SELECT 1
                   FROM TPIF_SMJJHWH B
                  WHERE B.SFPP = 1--是否匹配=1，已匹配
                    AND TRIM(B.XHBADM) = TRIM(A.PROD_CODE)
                    )) N
  ON (TRIM(M.DXCPDM) = TRIM(N.PROD_CODE) AND TRIM(M.DXCPDM) IS NOT NULL AND M.ID = V_CPDM_SMYY_ID)
                                                      --选择 这次审核后，TPIF_CPDM_SMYY表里新增或修改的记录
  WHEN MATCHED THEN
    UPDATE
       SET M.CPTA   = N.PRODTA_NO,
           M.CPMC   = N.PROD_NAME,
           M.PYDM   = N.PRODSPELL_CODE,
           M.MJKSRQ = N.IPO_BEGIN_DATE,
           M.MJJSRQ = N.IPO_END_DATE,
           M.CLRQ   = N.PROD_BEGIN_DATE,
           M.DQRQ   = N.PROD_END_DATE,
           M.TJQSRQ = N.PROM_BEGIN_DATE,
           M.TJZZRQ = N.PROM_END_DATE,
           M.CPQX   = N.PROD_TERM,
           M.CPJYZT = N.PROD_STATUS,
           M.HBZL   = N.MONEY_TYPE,
           M.FXJG   = N.ISSUE_PRICE,
           M.MFMZ   = N.PAR_VALUE,
           M.SFFS   = N.CHARGE_TYPE,
           M.FHFS   = N.DIVIDEND_WAY,
           M.QTJE   = N.MIN_SHARE,
  
           M.CPZDMJJE = N.PROD_MIN_BALA, --  产品最低募集金额
           M.CPZGMJJE = N.PROD_MAX_BALA, --  产品最高募集金额
           M.CPSJMJJE = N.PROD_REAL_BALA, --  产品实际募集金额
  
           M.NHTS    = N.YEAR_DAYS,
           M.YQSYL   = N.PRODPRE_RATIO,
           M.YQSYLMS = N.PROD_RATIO_STR,
           M.CPTAMC  = PRODCOMPANY_NAME,
           M.CPGLRID = NVL(M.CPGLRID,
                           (SELECT ID
                              FROM TPIF_JGDM A
                             WHERE (A.JGMC = N.PROD_MANAGER OR
                                   A.JGJC = N.PROD_MANAGER)
                               AND ROWNUM = 1)),
           M.CPTGR   = N.PROD_TRUSTEE,
  
           M.TZLB      = N.INVEST_TYPE,
           M.SYLX      = N.INCOME_TYPE,
           M.CPTZQX    = N.PROD_INVEST_TERM,
           M.CPFXDJ    = N.PRODRISK_LEVEL,
           M.CPPGDJ    = N.ASSESS_LEVEL,
           M.ZDFXDJ    = N.LOW_CORP_RISK_LEVEL,
           M.ZDZCYQ    = N.MIN_ASSET_NEED,
           M.YXZYTZZLX = N.EN_PROF_FLAG,
  
           M.CCLDZDZ   = N.CURRENT_AMOUNT_LOW, --持仓量的最低值
           M.RGRSSX    = MAX_SUBSCRIBE_NUM, --认购人数上限
           M.ZDZHJE    = N.MIN_SWITCH_IN_BALANCE, --最低转换金额
           M.ZSZHFE    = N.TRANS_LIMITSHARE, --最少转换份额
           M.ZHDW      = N.SWITCH_UNIT, --转换单位
           M.SHZDZ     = N.REDEEM_LIMITSHARE, --赎回最低份额
           M.SHZXDW    = N.REDEMPTION_UNIT, --赎回最小单位
           M.SHZJKYBZ  = N.REDEEM_USE_FLAG, --赎回资金可用标志
           M.MCZDKSGBL = N.MAX_ALLOTRATIO; --每次最大可申购比例*/

  /******三丶通过朝阳永续更新 ******/
  FOR CUR_FUND_ID IN (SELECT ID, CPID, ZYNM, HBZL
                        FROM TPIF_CPDM_SMYY
                       WHERE ZYNM IS NOT NULL
                         AND ID = V_CPDM_SMYY_ID) LOOP
  
    UPDATE TPIF_CPDM_SMYY M
       SET (M.CPJC, --产品简称
            M.DYCPQC, --对应产品全称
            M.BABH, --备案编号
            M.BASJ, --备案时间
            M.CPZHFS, --N   产品组合方式
            M.CPTZBD, --投资标的
            M.CPTGRMC, --产品托管人名称
            M.TZGW, --投资顾问  ，当作基金经理
            --M.TZFZR,--投资负责人
            M.TZFW, --投资方向
            M.TZMB, --投资目标
            M.TZFX, --投资方向
            M.TZLN, --投资理念
            M.CPDP, --产品点评
            M.CPYJX, --N  预警线
            M.CPZSX, --N  止损线
            M.CPJJ, --产品简介
            M.ZYNM, --朝阳内码
            M.CPJD, --产品阶段
            M.DQRQ, --产品到期日期
            M.CLRQ, --成立日期
            M.HBZL, --货币种类
            M.QTJE, --起投金额
            --M.CPZDMJJE,--产品最低募集金额
            --M.CPZGMJJE,--产品最高募集金额
            M.CPSJMJJE, --产品实际募集金额
            M.TJQSRQ, --推介起始日期
            M.TJZZRQ, --推介终止日期
            M.PYDM, --拼音代码
            M.CPGLRMC --产品管理人名称
            ) =
           (SELECT FUND_NAME, -- 基金简称
                   FUND_FULL_NAME, --  对应产品全称
                   REG_CODE,
                   TO_CHAR(REG_TIME, 'YYYYMMDD') AS REG_TIME,
                   DECODE(FUND_TYPE_INVESTMENT_WAY,
                          'FOF',
                          '3',
                          'MOM',
                          '4',
                          'TOF',
                          '2',
                          'TOL',
                          '5',
                          'TOT－一对多',
                          '1',
                          '伞形',
                          '7',
                          '链式基金',
                          '8',
                          '其他间接投资',
                          '6',
                          'FOF,其他间接投资',
                          '3;6',
                          'FOF,链式基金',
                          '3;8',
                          '其他间接投资,链式基金',
                          '6;8') AS FUND_TYPE_INVESTMENT_WAY,
                   FUND_TYPE_TARGET,
                   FUND_CUSTODIAN, --产品托管人名称
                   FUND_MEMBER, --投资经理 基金经理
                   --FUND_MANAGER,
                   INVESTMENT_RANGE,
                   INVESTMENT_TARGET,
                   ORIENTATION,
                   INVESTMENT_IDEA,
                   APPRAISE,
                   PRECAUTIOUS_LINE, --  预警线(元)
                   STOP_LOSS_LINE, --止损线(元)
                   INSTRUCTION, --简介
                   FUND_ID,
                   (CASE
                     WHEN FUND_STATUS = '存续中' THEN
                      3
                     WHEN FUND_STATUS = '已终止' THEN
                      5
                   END),
                   TO_CHAR(END_DATE, 'YYYYMMDD'),
                   TO_CHAR(FOUNDATION_DATE, 'YYYYMMDD'),
                   NVL(CUR_FUND_ID.HBZL,
                       DECODE(CURRENCY,
                              '人民币现钞',
                              0,
                              '美元现汇',
                              1,
                              '港元现汇',
                              2)),
                   MIN_PURCHASE_AMOUNT, --最低认购金额(元)
                   --ISSUING_SCALE,--  发行规模(元)
                   --ISSUING_SCALE,--  发行规模(元)
                   REAL_FINANCING_SCALE, --  实际募集规模
                   TO_CHAR(RECOMMENDATION_START, 'YYYYMMDD'),
                   TO_CHAR(RECOMMENDATION_END, 'YYYYMMDD'),
                   FUND_NAME_PY,
                   FUND_MANAGER_NOMINAL --产品管理人名称
              FROM SRC_PIF.T_FUND_INFO
             WHERE FUND_ID = CUR_FUND_ID.ZYNM)
     WHERE M.ZYNM = CUR_FUND_ID.ZYNM;
  
    --更新产品管理人ID，产品托管人ID    
    UPDATE TPIF_CPDM_SMYY M
       SET M.CPGLRID =
           (SELECT A.ID
              FROM TPIF_JGDM A
             WHERE A.JGJC = M.CPGLRMC
               AND ROWNUM = 1),
           M.CPTGR  =
           (SELECT A.ID
              FROM TPIF_JGDM A
             WHERE A.JGJC = M.CPTGRMC
               AND ROWNUM = 1)
     WHERE M.ZYNM = CUR_FUND_ID.ZYNM;
  END LOOP;

  --产品阶段处理  2募集期 3 存续期 4 清盘期 5 结束期
  /*1  开放期
  2  认购期
  4  产品成立
  5  产品终止
  6  停止交易
  7  停止申购
  8  停止赎回*/
  UPDATE TPIF_CPDM_SMYY A
     SET A.CPJD = DECODE(A.CPJYZT, 1, 3, 2, 2, 4, 3, 5, 5, 3)
   WHERE A.CPJYZT IS NOT NULL
     AND NVL(A.CPJD, -1) <> 5
     AND A.ID = V_CPDM_SMYY_ID;

  /*  --通过朝阳永续更新修正金融产品分类
    \*100100  信托
      100101  私募公司
      100102  公募专户及子公司
      100103  券商集合理财
      100104  银行
      100105  期货资管
      100107  保险公司及其子公司的资产管理计划
  
      100101100 私募证券投资基金
      100101101 私募其他投资基金
      100101102 私募股权投资基金
      100101103 私募创业投资基金
      100101104 私募资产配置基金*\
  MERGE INTO TPIF_CPDM_SMYY M
  USING (SELECT FUND_ID, TYPE_CODE
           FROM SRC_PIF.T_FUND_TYPE_MAPPING
          WHERE TYPE_CODE IN ('100100',
                              '100102',
                              '100103',
                              '100104',
                              '100105',
                              '100107',
                              '100101100',
                              '100101101',
                              '100101102',
                              '100101103',
                              '100101104')) N
  ON (M.ZYNM = N.FUND_ID AND M.ID = V_CPDM_SMYY_ID)
  WHEN MATCHED THEN
    UPDATE
       SET M.JRCPFL = NVL(DECODE(N.TYPE_CODE,
                                 '100100',
                                 '600100',
                                 '100102',
                                 '300400',
                                 '100103',
                                 '100100',
                                 '100104',
                                 '800100',
                                 '100105',
                                 '700200',
                                 '100107',
                                 '900100',
                                 '100101100',
                                 '500100',
                                 '100101101',
                                 '500500',
                                 '100101102',
                                 '500200',
                                 '100101103',
                                 '500300',
                                 '100101104',
                                 '500400'),
                          M.JRCPFL),
           M.CPXL   = NVL(DECODE(N.TYPE_CODE,
                                 '100100',
                                 8,
                                 '100102',
                                 7,
                                 '100103',
                                 3,
                                 '100104',
                                 5,
                                 '100105',
                                 9,
                                 '100107',
                                 6,
                                 '100101100',
                                 2,
                                 '100101101',
                                 2,
                                 '100101102',
                                 2,
                                 '100101103',
                                 2,
                                 '100101104',
                                 2),
                          M.CPXL);*/

  --更新CPID和ID值一致方便后续维护
  UPDATE TPIF_CPDM_SMYY A
     SET A.CPID = A.ID
   WHERE A.CPID IS NULL
     AND A.ID = V_CPDM_SMYY_ID;

  --日期处理   为0的改为NULL
  UPDATE TPIF_CPDM_SMYY A
     SET A.MJKSRQ = (CASE
                      WHEN A.MJKSRQ = 0 THEN
                       NULL
                      ELSE
                       A.MJKSRQ
                    END),
         A.MJJSRQ = (CASE
                      WHEN A.MJJSRQ = 0 THEN
                       NULL
                      ELSE
                       A.MJJSRQ
                    END),
         A.CLRQ = (CASE
                    WHEN A.CLRQ = 0 THEN
                     NULL
                    ELSE
                     A.CLRQ
                  END),
         A.DQRQ = (CASE
                    WHEN A.DQRQ = 0 THEN
                     NULL
                    ELSE
                     A.DQRQ
                  END),
         A.TJQSRQ = (CASE
                      WHEN A.TJQSRQ = 0 THEN
                       NULL
                      ELSE
                       A.TJQSRQ
                    END),
         A.TJZZRQ = (CASE
                      WHEN A.TJZZRQ = 0 THEN
                       NULL
                      ELSE
                       A.TJZZRQ
                    END)
   WHERE A.ID = V_CPDM_SMYY_ID;

  /*  --适当性 ，适合投资者类型
  UPDATE TPIF_CPDM_SMYY A SET A.SHTZZLX = （CASE WHEN A.CPFXDJ = 0 THEN '1;2;3;4;5' WHEN A.CPFXDJ = 1 THEN '2;3;4;5' WHEN A.CPFXDJ = 2 THEN '3;4;5' WHEN A.CPFXDJ = 3 THEN '4;5' WHEN A.CPFXDJ = 4 THEN '5'
  END) WHERE A.CPFXDJ IS
  NOT NULL AND A.ID = V_CPDM_SMYY_ID;
  */

  O_CODE := 1;
  O_NOTE := '';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
  
END;
/

