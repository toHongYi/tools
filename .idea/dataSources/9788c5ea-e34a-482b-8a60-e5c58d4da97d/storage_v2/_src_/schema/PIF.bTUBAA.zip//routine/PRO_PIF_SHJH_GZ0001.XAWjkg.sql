create PROCEDURE PRO_PIF_SHJH_GZ0001(O_CODE OUT NUMBER, --返回值
                                                    O_NOTE OUT VARCHAR2, --返回消息
                                                    O_NR   OUT VARCHAR2
                                                    ) AS

    -- GZ0002 产品同日期净值不唯一质检
    V_YF      NUMBER := SUBSTR(TO_CHAR(SYSDATE, 'YYYYMMDD'), 1, 6); --月份
    V_SY      NUMBER := SUBSTR(TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMMDD'), 1, 6); --上月
    V_KSRQ    NUMBER; --本月质检开始日期
    V_JSRQ    NUMBER; --本月质检结束日期
    V_IF      NUMBER;
    V_KS      NUMBER;
    V_JS      NUMBER;
    V_TS      NUMBER; --本月交易日天数
    V_MIN_JYR NUMBER; --本月最小交易日
    V_MAX_JYR NUMBER; --本月最大交易日
    V_JHJG    NUMBER;

BEGIN
    --变量初始化
    O_CODE := 1;
    O_NOTE := 'SUCCESS';
    O_NR := '';

   /* SELECT MIN(JYR) INTO V_MIN_JYR FROM DSC_CFG.T_XTJYR WHERE SUBSTR(JYR, 1, 6) = V_YF; --本月最小交易日
    SELECT MAX(JYR) INTO V_MAX_JYR FROM DSC_CFG.T_XTJYR WHERE SUBSTR(JYR, 1, 6) = V_YF; --本月最大交易日
    SELECT COUNT(*)
      INTO V_TS
      FROM (SELECT DISTINCT JYR FROM DSC_CFG.T_XTJYR WHERE SUBSTR(JYR, 1, 6) = V_YF); --本月交易日天数  */

    SELECT QSR
      INTO V_KS
      FROM PIF.TPIF_ZJQSPZB A, PIF.TPIF_JHGZGL B
     WHERE A.ZJGZ = B.ID
       AND B.GZDM = 'GZ0002';
    SELECT JSR
      INTO V_JS
      FROM PIF.TPIF_ZJQSPZB A, PIF.TPIF_JHGZGL B
     WHERE A.ZJGZ = B.ID
       AND B.GZDM = 'GZ0002';

  /*  SELECT JYR
      INTO V_KSRQ
      FROM (SELECT ROWNUM NUM, T.*
              FROM (SELECT DISTINCT JYR
                      FROM DSC_CFG.T_XTJYR
                     WHERE SUBSTR(JYR, 1, 6) = V_YF
                     ORDER BY JYR) T)
     WHERE NUM = CASE WHEN V_KS BETWEEN 1 AND V_TS THEN V_KS ELSE 1 END; --本月质检开始日期*/

/*    SELECT JYR
      INTO V_JSRQ
      FROM (SELECT ROWNUM NUM, T.*
              FROM (SELECT DISTINCT JYR
                      FROM DSC_CFG.T_XTJYR
                     WHERE SUBSTR(JYR, 1, 6) = V_YF
                     ORDER BY JYR) T)
     WHERE NUM = CASE WHEN V_JS BETWEEN 1 AND V_TS THEN V_JS ELSE V_TS END ; --本月质检结束日期*/

    --判断当日是否是该月的第1个到第8个工作日
    SELECT COUNT(*)
      INTO V_IF
      FROM DUAL
     WHERE TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN V_KSRQ AND V_JSRQ;

  
   /*     --将稽核结果写入稽核表中
        INSERT INTO PIF.TPIF_SJJHJG
            (ID, RQ, JHGZ, CPFL, JHJG, CWJGSL, CLFS, SFYTX)
            SELECT PIF.SEQ_TPIF_SJJHJG.NEXTVAL,
                   SYSDATE,
                   (SELECT ID FROM PIF.TPIF_JHGZGL B WHERE B.GZDM = 'GZ0002'),
                   N2,
                   (CASE
                       WHEN N1 = 0 THEN
                        0
                       ELSE
                        1
                   END),
                   '',
                   (SELECT DECODE(B.JHCLFS, 1, '告警', '消息提醒')
                      FROM PIF.TPIF_JHGZGL B
                     WHERE B.GZDM = 'GZ0002'),
                   0
              FROM PIF.TMP_COMMON;*/
      
        --将稽核结果写入稽核表中
        INSERT INTO PIF.TPIF_SJJHJG
            (ID, RQ, JHGZ, CPFL, JHJG, CWJGSL, CLFS, SFYTX)
        VALUES
            (LIVEBOS.FUNC_NEXTID('TPIF_SJJHJG'),
             SYSDATE,
             (SELECT ID FROM TPIF_JHGZGL WHERE GZDM='GZ0001')
             )      
              
        COMMIT;


EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := 'ERROR: [' || SQLERRM || ']';

END;
/

