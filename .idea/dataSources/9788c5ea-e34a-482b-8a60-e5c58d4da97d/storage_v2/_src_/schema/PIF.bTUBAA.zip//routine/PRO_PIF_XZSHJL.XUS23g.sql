create PROCEDURE PRO_PIF_XZSHJL(O_CODE OUT NUMBER,
                                 O_NOTE OUT VARCHAR2,
                                 I_USERID IN NUMBER,
                                 I_ID IN NUMBER,
                                 I_LX IN NUMBER --1通过，0不通过
                                 ) AS
V_COUNT NUMBER;

V_TPIF_SMCP TPIF_SMCP%ROWTYPE;

BEGIN
  O_CODE :=1;
  O_NOTE :='成功';
  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'USERID 不允许为空！';
  END IF;  

  SELECT * INTO V_TPIF_SMCP FROM TPIF_SMCP WHERE ID = I_ID;

  INSERT INTO TPIF_SMCPCZJL
    (ID,
     CZLX,
     CZCPID,
     CZSJ,
     CPMC,
     CPDM,
     CLRQ,
     JJGLR,
     GLRDJBH,
     DYCPID,
     KHBH,
     FL,
     FGS,
     YYB,
     YYBDM,
     KHRQ,
     YWLX,
     BZ,
     CPYXZT,
     ZHZT,
     SHZT,
     SJLY,
     ZHXGSJ,
     ZHXGR,
     SFCZYNBCP,
     YJCL,
     EJCL,
     SJCL)
  VALUES
    (LIVEBOS.FUNC_NEXTID('TPIF_SMCPCZJL'),
     4,
     V_TPIF_SMCP.ID,
     SYSDATE,
     V_TPIF_SMCP.CPMC,
     V_TPIF_SMCP.CPDM,
     V_TPIF_SMCP.CLRQ,
     V_TPIF_SMCP.JJGLR,
     V_TPIF_SMCP.GLRDJBH,
     V_TPIF_SMCP.DYCPID,
     V_TPIF_SMCP.KHBH,
     V_TPIF_SMCP.FL,
     V_TPIF_SMCP.FGS,
     V_TPIF_SMCP.YYB,
     V_TPIF_SMCP.YYBDM,
     V_TPIF_SMCP.KHRQ,
     V_TPIF_SMCP.YWLX,
     V_TPIF_SMCP.BZ,
     V_TPIF_SMCP.CPYXZT,
     V_TPIF_SMCP.ZHZT,
     V_TPIF_SMCP.SHZT,
     V_TPIF_SMCP.SJLY,
     V_TPIF_SMCP.ZHXGSJ,
     V_TPIF_SMCP.ZHXGR,
     V_TPIF_SMCP.SFCZYNBCP,
     V_TPIF_SMCP.YJCL,
     V_TPIF_SMCP.EJCL,
     V_TPIF_SMCP.SJCL);
   
  IF I_LX =1 THEN  
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_SMTGCP WHERE ID=I_ID;
    IF V_COUNT =0 THEN
      INSERT INTO PIF.TPIF_SMTGCP
        (ID,
         CPMC,
         CPDM,
         CLRQ,
         YJCL,
         JJGLR,
         GLRDJBH,
         DYCPID,
         KHBH,
         FL,
         FGS,
         YYB,
         YYBDM,
         KHRQ,
         YWLX,
         BZ,
         CPYXZT,
         ZHZT,
         SHZT,
         SJLY,
         ZHXGSJ,
         ZHXGR,
         SFCZYNBCP,
         EJCL,
         SJCL)
      VALUES
        (V_TPIF_SMCP.ID,
         V_TPIF_SMCP.CPMC,
         V_TPIF_SMCP.CPDM,
         V_TPIF_SMCP.CLRQ,
         V_TPIF_SMCP.YJCL,
         V_TPIF_SMCP.JJGLR,
         V_TPIF_SMCP.GLRDJBH,
         V_TPIF_SMCP.DYCPID,
         V_TPIF_SMCP.KHBH,
         V_TPIF_SMCP.FL,
         V_TPIF_SMCP.FGS,
         V_TPIF_SMCP.YYB,
         V_TPIF_SMCP.YYBDM,
         V_TPIF_SMCP.KHRQ,
         V_TPIF_SMCP.YWLX,
         V_TPIF_SMCP.BZ,
         V_TPIF_SMCP.CPYXZT,
         V_TPIF_SMCP.ZHZT,
         V_TPIF_SMCP.SHZT,
         V_TPIF_SMCP.SJLY,
         V_TPIF_SMCP.ZHXGSJ,
         V_TPIF_SMCP.ZHXGR,
         V_TPIF_SMCP.SFCZYNBCP,
         V_TPIF_SMCP.EJCL,
         V_TPIF_SMCP.SJCL);
    ELSE
      UPDATE TPIF_SMTGCP 
      SET ID=V_TPIF_SMCP.ID,
         CPMC=V_TPIF_SMCP.CPMC,
         CPDM=V_TPIF_SMCP.CPDM,
         CLRQ=V_TPIF_SMCP.CLRQ,
         YJCL=V_TPIF_SMCP.YJCL,
         JJGLR=V_TPIF_SMCP.JJGLR,
         GLRDJBH=V_TPIF_SMCP.GLRDJBH,
         DYCPID=V_TPIF_SMCP.DYCPID,
         KHBH=V_TPIF_SMCP.KHBH,
         FL=V_TPIF_SMCP.FL,
         FGS=V_TPIF_SMCP.FGS,
         YYB=V_TPIF_SMCP.YYB,
         YYBDM=V_TPIF_SMCP.YYBDM,
         KHRQ=V_TPIF_SMCP.KHRQ,
         YWLX=V_TPIF_SMCP.YWLX,
         BZ=V_TPIF_SMCP.BZ,
         CPYXZT=V_TPIF_SMCP.CPYXZT,
         ZHZT=V_TPIF_SMCP.ZHZT,
         SHZT=V_TPIF_SMCP.SHZT,
         SJLY=V_TPIF_SMCP.SJLY,
         ZHXGSJ=V_TPIF_SMCP.ZHXGSJ,
         ZHXGR=V_TPIF_SMCP.ZHXGR,
         SFCZYNBCP=V_TPIF_SMCP.SFCZYNBCP,
         EJCL=V_TPIF_SMCP.EJCL,
         SJCL=V_TPIF_SMCP.SJCL
         WHERE ID=I_ID;
    END IF;
       
  END IF;
  COMMIT;    

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;

END;
/

