create PROCEDURE PRO_PIF_JGFWFJ_XG(
                                                   O_CODE OUT NUMBER,   --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   I_RY   IN  NUMBER,    --操作人
                                                   I_ID IN NUMBER,       --机构服务ID
                                                   I_FJSTR IN VARCHAR2 )    --附件JSON字符串   
                                                IS
     /******************************************************************                                               
          项目名称：产品中心
          所属用户：PIF
         功能说明：机构业务拓展----机构服务修改----附件json切割转移到TPIF_JGFWFJ                                      
        语法信息：
             输入参数：I_RY   IN  NUMBER    --操作人                                                     
                               I_ID IN NUMBER       --所属机构服务ID                  
                               I_FJSTR IN VARCHAR2       --附件json字符串                   
            逻辑说明：切割得到item部分，拿到数组第一个id中，与该服务的附件最小id对比，
                               一致说明附件未作修改，不一致调用 PRO_JGFW_JGFWFJ  再次新增  
           修订记录：
          修订日期              版本号   修订人          修改内容简要说明
          2021-08-013     1.0.0     WWH            修改附件转移                                 
    ***********************************************************************/


  V_JGFWID  VARCHAR2(2000);
  V_CZRID     VARCHAR2(2000);
  V_FJID VARCHAR2(2000);
  V_MIN_FJID VARCHAR2(2000);
  V_SUBFJSTR VARCHAR2(2000);
  V_FJSTR VARCHAR2(2000);
  BEGIN
  O_CODE := -1;
  O_NOTE := '';
  V_CZRID:=I_RY;
  V_JGFWID:=I_ID;
  V_FJSTR:=I_FJSTR;
  
  

  
--附件存在，拿到items部分
/*SELECT SUBSTR(STR, INSTR(STR, '["', 1, 1))
           INTO   V_FJSTR
           FROM   (SELECT SUBSTR(FJ, INSTR(FJ, '"items":[') + 9) AS STR
                  FROM   TPIF_JGFW
                  WHERE  ID = V_JGFWID);*/
     SELECT SUBSTR(STR, INSTR(STR, '["', 1, 1))
           INTO   V_SUBFJSTR
           FROM   (SELECT SUBSTR(V_FJSTR, INSTR(V_FJSTR, '"items":[') + 9) AS STR  FROM  DUAL); 
 

                  --判断附件是否发生了改变
         IF   V_SUBFJSTR <> ']}' THEN
                  --获取数组中第一个id
                  SELECT SUBSTR(V_SUBFJSTR,3,INSTR(V_SUBFJSTR,'"',1,2)-3) INTO V_FJID FROM DUAL;
                  --与TPIF_JGFWFJ 表中的最小FJID作对比
                  SELECT MIN(FWFJID) INTO V_MIN_FJID  FROM TPIF_JGFWFJ WHERE JGFWID =V_JGFWID  AND SFSC=0;
                 
                    IF V_FJID =V_MIN_FJID THEN
                      
                    O_CODE:=1;
                    O_NOTE:='附件未做修改';
                      RETURN;
                    
                      --附件被修改或者没有附件
                     ELSE 
                      UPDATE PIF.TPIF_JGFWFJ SET SFSC=1 WHERE  JGFWID =V_JGFWID;
                      PRO_JGFW_JGFWFJ(O_CODE,O_NOTE,V_CZRID,V_JGFWID,V_FJSTR);
                      
 
                      O_NOTE:='成功';
                      O_CODE:=1;
                      
                     END IF;
          ELSE
                     --避免删除所有附件的时候，未作废以前的附件
                     UPDATE PIF.TPIF_JGFWFJ SET SFSC=1 WHERE  JGFWID =V_JGFWID;
         END IF;
     COMMIT;




 EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败';
     ROLLBACK;
END;
/

