create FUNCTION FUNC_PIF_CPID_ZDHCL_QJ( I_TJRQ IN NUMBER, --统计日期
                                                    I_KSRQ IN NUMBER,  --回测开始时间
                                                    I_CPID IN NUMBER  --产品ID
)RETURN VARCHAR2 IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算最大回测率

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        WUJINFENG   1.0.0    2020/01/15                新增
  --------------------------------------------------------------------------------*/
  V_ZDJZ    NUMBER:=0; ---最大净值
  V_ZDHC    NUMBER:=0; ---最大回撤
  V_ZDJZKSRQ NUMBER:=0; --最大净值开始日期
  V_ZDJZJSRQ NUMBER:=0; --最大净值开始日期

BEGIN
    FOR CUR_HC IN (SELECT LJJZ, JZRQ FROM TPIF_CPJZXX A
                    WHERE A.CPID = I_CPID
                      AND EXISTS (SELECT 1
                             FROM LIVEBOS.TXTJYR
                            WHERE ZRR = JYR
                              AND JYR = A.JZRQ
                              AND JYR >= I_KSRQ
                              AND JYR <= I_TJRQ) ORDER BY A.JZRQ ASC) LOOP

      IF CUR_HC.LJJZ >= V_ZDJZ THEN
        V_ZDJZ := CUR_HC.LJJZ;
        V_ZDJZKSRQ := CUR_HC.JZRQ;
      ELSIF (1 - CUR_HC.LJJZ / V_ZDJZ) * 100 > V_ZDHC THEN
        V_ZDHC := (1 - CUR_HC.LJJZ / V_ZDJZ) * 100;
        V_ZDJZJSRQ := CUR_HC.JZRQ;
     END IF;

    END LOOP;

    RETURN V_ZDHC || ',' ||V_ZDJZKSRQ||','|| V_ZDJZJSRQ;
EXCEPTION
  WHEN OTHERS THEN
    RETURN -999;
END;
/

