create PROCEDURE pcx_pif_rwgl_cpjbxxcx(o_code     out number,
                                              o_note     out varchar2,
                                              o_result   out sys_refcursor,
                                              i_current  in number, --页码
                                              i_pagesize in number, --页长
                                              i_paging   in number, --是否分页
                                              i_sort     in string, --排序规模
                                              i_total    in out number, --记录总数
                                                i_prod_name in varchar2,  --产品代码/名称
                                                i_userid    in number --用户id
                                                ) AS
  /******************************************************************
  项目名称：产品中心-任务管理-查询产品基本信息
  所属用户：PIF
  概要说明：查询当前登录人所创建的任务列表.
             i_prod_name in varchar2  --产品代码/名称
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.

  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询任务列表.

        1.查询任务列表需要显示的字段,供前端查询展示.

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/07/20     1.0.1     tumeng             新增.
  *********************************************************************************************************************/

  V_ERRMSG    VARCHAR2(300); --错误信息
   v_sql          varchar2(32767);
  v_collist      varchar2(32767);
  v_sort         varchar2(300);
  v_hasrecordset number;
BEGIN

  --否则返回结果集合
  v_hasrecordset := 1;
  o_code         := 1;
  o_note         := '成功';
  if i_total is null then
    i_total := -1;
  end if;
  v_sort := i_sort;



  --数据源赋值
  v_sql := 'select id,
                         (select note from livebos.txtdm where fldm = ''PIF_CPXL_CPZX'' and ibm = t.cpxl) as prod_type,
                         t.cpdm as prod_code,
                         t.cpmc as prod_name
                 from tpif_cpdm t
                 where 1=1 ' || case when  i_prod_name is not null then  ' and (t.cpdm like  ''%' || i_prod_name || '%''
                 or t.cpmc like   ''%' || i_prod_name || '%'' )' end;
  dbms_output.put_line(v_sql);
  OPEN O_RESULT FOR v_sql;
   if v_sort is null then
    v_sort := 'id ASC';
  end if;

  v_collist := 'ID,prod_type,prod_code,prod_name';

  pcx_tycx(o_code,
           o_note,
           v_hasrecordset,
           o_result,
           i_paging,
           i_current,
           i_pagesize,
           i_total,
           sqls           => v_sql,
           collist        => v_collist,
           haswhere       => true,
           groupislast    => false,
           i_sort         => v_sort,
           i_haswith      => false);
  
EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := ' 查询失败 ';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT ' 异常信息： ' || V_ERRMSG FROM DUAL;
END pcx_pif_rwgl_cpjbxxcx;
/

