create procedure PRO_CPYY_HQCPGLID  (
                                                   O_CODE OUT NUMBER,   --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   O_GLCPID OUT NUMBER, --关联产品ID
                                                   O_YYZED OUT NUMBER, --关联产品预约总额度
                                                   O_YYZRS OUT NUMBER, --关联产品预约总人数
                                                   O_YYKSSJ OUT VARCHAR2, --关联产品预约开始时间
                                                   O_YYJZSJ OUT VARCHAR2,--关联产品预约截止时间
                                                   O_YYCPPC OUT NUMBER,--关联产品批次
                                                   I_YYCPDM IN VARCHAR2, -- 预约产品代码
                                                   I_YYKSSJ IN VARCHAR2, --预约开始时间
                                                   I_YYJZSJ IN VARCHAR2  --预约截止时间
                                                   
)IS
V_YYCPDM VARCHAR2(300);
V_YYKSSJ VARCHAR2(300);
V_YYJZSJ VARCHAR2(300);
V_GLCPID NUMBER;
V_GLCPID_1 NUMBER;
V_YYZED NUMBER;
V_YYZRS NUMBER;
V_GLCPYYKSSJ VARCHAR2(300); --关联产品预约开始时间
V_GLCPYYJZSJ VARCHAR2(300);--关联产品预约截止时间
V_GLCPPC NUMBER; --关联产品批次

  /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：   I_CPDM  预约产品的产品代码
                              I_YYKSSJ   预约开始时间
                              I_YYJSSJ   预约截止时间
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                               O_GLCPID     关联产品的产品ID
                               O_YYZED      关联产品预约总额度
                               O_YYZRS      关联产品预约总人数
                               O_YYKSSJ     关联产品预约开始时间
                               O_YYJZSJ     关联产品预约截止时间
                               O_YYCPPC   关联产品批次
      逻辑说明：                                  
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WEIWENHAO        获取产品的关联产品的信息
  ***********************************************************************/
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_YYCPDM :=I_YYCPDM;
  V_YYKSSJ:=I_YYKSSJ;
  V_YYJZSJ:=I_YYJZSJ;
  

  --获取关联产品的ID，取最新操作时间的那条
   SELECT MAX(ID)
   INTO   V_GLCPID
   FROM   TPIF_YYCPGL
   WHERE  CPDM = V_YYCPDM
   AND    NOT ((YYJZRQ < TO_DATE(V_YYKSSJ, 'yyyy-mm-dd hh24:mi:ss')) OR
          (YYKSRQ > TO_DATE(V_YYJZSJ, 'yyyy-mm-dd hh24:mi:ss')));
   --取到的关联产品是否存在关联
    SELECT GLCPID,
           YYZED,
           YYZRS,
           TO_CHAR(YYKSRQ, 'yyyy-mm-dd hh24:mi:ss'),
           TO_CHAR(YYJZRQ, 'yyyy-mm-dd hh24:mi:ss'),
           CPPC
    INTO   V_GLCPID_1,
           V_YYZED,
           V_YYZRS,
           V_GLCPYYKSSJ,
           V_GLCPYYJZSJ,
           V_GLCPPC
    FROM   TPIF_YYCPGL
    WHERE  ID = V_GLCPID;

    IF V_GLCPID_1 IS NOT NULL THEN
     V_GLCPID:= V_GLCPID_1;
     END IF;
     O_GLCPID:=V_GLCPID;
     O_YYZED:=V_YYZED;
     O_YYZRS:=V_YYZRS;
     O_YYKSSJ:=V_GLCPYYKSSJ;
     O_YYJZSJ:=V_GLCPYYJZSJ;
     O_YYCPPC:=V_GLCPPC;

     EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
ROLLBACK;
END;
/

