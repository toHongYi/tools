create PROCEDURE PCX_PIF_XXZXSY_JRCP(O_CODE              OUT NUMBER,
                                                O_NOTE              OUT VARCHAR2,
                                                O_RESULT            OUT SYS_REFCURSOR,
                                                I_USERID            IN NUMBER, --登陆用户ID
                                                I_PROD_LEVEL1_CLASS IN VARCHAR2, --产品一级分类ID
                                                I_PROD_LEVEL2_CLASS IN VARCHAR2, --产品二级分类ID 二级分类ID，传空时查询全部
                                                I_IS_MY_CONCERN	IN VARCHAR2 := 0 --是否我关注的产品
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 信息中心首页-金融产品、服务产品列表查询
  
  
      语法信息：
           输入参数：   I_USERID IN NUMBER --登陆用户ID
                       I_PROD_LEVEL1_CLASS IN NUMBER, --产品一级分类ID
                       I_PROD_LEVEL2_CLASS IN NUMBER, --产品二级分类ID 二级分类ID，传空时查询全部
  
           输出参数：  O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/
  --V_SQL VARCHAR2(5000);
  V_JZRQ NUMBER;

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_LEVEL1_CLASS IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_LEVEL1_CLASS 不允许为空！';
    RETURN;
  END IF;

  /*  PROD_ID 产品ID
      PROD_CODE 产品代码
      PROD_NAME 产品名称
      PROD_TYPE 产品类型
      PROD_RISK_LEVEL 产品风险等级
      SUBSCRIBE_ORIGIN  认购起点(元)
      NAV_DATE  净值日期
      UNIT_NAV  单位净值
      UNIT_YIELD  万分收益
      D7_ANNUAL_YIELD_RATE  七日年化收益率
      PROD_TERM 产品期限
      PERFORMANCE_BENCHMARK 业绩比较基准
      YIELD_RATE_DAY  日涨幅
      YIELD_RATE_MONTH  近一个月涨幅
      YIELD_RATE_QUARTER  近三个月涨幅
      YIELD_RATE_ONE_YEAR 近一年涨幅
      YIELD_RATE_THISYEAR 今年以来涨幅
      YIELD_RATE_SINCE_FOUND  成立以来涨幅
      BENCHMARK_PRICE 基准价格
      PAY_DESC  支付说明
      APPLICABLE_OBJECT 适用对象
      PROD_FIXED_PRICE_METHOD 产品定价方式
      SERVICE_METHOD  服务方式
      PROD_MANAGER  产品经理
      CONTACT_METHOD  联系方式
  */

  --2  理财产品
  --3  公募基金
  --4  私募基金
  --5  服务产品
  
  IF I_IS_MY_CONCERN = 1 THEN 
    
  
    IF I_PROD_LEVEL1_CLASS = 5 THEN
          OPEN O_RESULT FOR
             SELECT
            
             C.ID AS PROD_ID, --产品ID
             C.CPDM AS PROD_CODE, --产品代码
             C.CPMC AS PROD_NAME, --产品名称
             A.NAME AS PROD_TYPE, --产品类型 
             C.CPFXDJ AS PROD_RISK_LEVEL, --产品风险等级ID
             (SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_CPFXDJ_CPZX'
                 AND IBM = C.CPFXDJ) AS PROD_RISK_LEVEL_DESC, --产品风险等级描述 
              NULL AS SUBSCRIBE_ORIGIN, --认购起点(元)
              C.JZRQ AS NAV_DATE, --净值日期
              to_char(ROUND(C.CPJZ,3),'FM9999990.0009')  AS UNIT_NAV,
              to_char(ROUND(C.WFSYL,3),'FM9999990.0009') AS UNIT_YIELD, --万分收益
              NULL AS D7_ANNUAL_YIELD_RATE, --七日年化收益率
             (CASE WHEN TRIM(C.CPQX) IS NULL THEN '无固定期限'
                   WHEN NVL(C.CPQX,0)='0' THEN '无固定期限'
                   else to_char(C.CPQX) ||'天' end)  AS PROD_TERM, --产品期限
             NULL AS PERFORMANCE_BENCHMARK, --业绩比较基准
             NULL AS YIELD_RATE_DAY, --日涨幅
             NULL AS YIELD_RATE_MONTH, --近一个月涨幅
             NULL AS YIELD_RATE_QUARTER, --近三个月涨幅
             NULL AS YIELD_RATE_ONE_YEAR, --近一年涨幅
             NULL AS YIELD_RATE_THISYEAR, --今年以来涨幅
             NULL AS YIELD_RATE_SINCE_FOUND, --成立以来涨幅
             (select wm_concat ((SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_DJZQ'
                 AND IBM = M.DJZQ ) ||':'||m.djz_xj||'元' ) FROM  TPIF_CPDM_FW_DJ M WHERE M.CPID = D.ID) AS BENCHMARK_PRICE, --基准价格
             D.ZFSM AS PAY_DESC, --支付说明
             (SELECT wm_concat( NOTE)
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_SYDX'
                 AND IBM = D.SYDX ) AS APPLICABLE_OBJECT, --适用对象
             (select wm_concat ((SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_DJZQ'
                 AND IBM = M.DJZQ ) ) FROM  TPIF_CPDM_FW_DJ M WHERE M.CPID = D.ID)  AS PROD_FIXED_PRICE_METHOD,
             (SELECT wm_concat( NOTE)
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_FWQD'
                 AND IBM = D.FWQD )  AS SERVICE_METHOD, --服务方式
            (SELECT NAME FROM LIVEBOS.TUSER WHERE ID= C.CPJL) AS PROD_MANAGER, --产品经理
             D.LXFS AS CONTACT_METHOD, --联系方式
             (select (case when count(*)>0 then 1 else 0 end) from tpif_wgzdcp where cpid=c.id and YH =I_USERID) AS IS_CONCERN
              FROM (SELECT ID,FID,NAME FROM TPIF_SYZSFL WHERE FID=I_PROD_LEVEL1_CLASS) A,
                   TPIF_SYZSFLCPMX B,
                   TPIF_CPDM C,
                   TPIF_CPDM_FW D
             WHERE A.ID = B.ZSFL
               AND B.CPID = C.ID
               AND C.ID = D.CPID
               and c.cpdm is not null 
               and exists(select 1 from TPIF_WGZDCP where cpid=c.id and YH = I_USERID);
    
    else
      
    
       
       BEGIN
              SELECT MAX(JZRQ)
                INTO V_JZRQ
                FROM TPIF_CPJZ_YSZB
               WHERE 1=1;--JZRQ >= TO_NUMBER(TO_CHAR(SYSDATE - 180, 'YYYYMMDD'));
            EXCEPTION
              WHEN OTHERS THEN
                SELECT JYR
                  INTO V_JZRQ
                  FROM LIVEBOS.TXTJYR
                 WHERE ZRR = TO_CHAR(SYSDATE - 1, 'YYYYMMDD');
            END;
          
            OPEN O_RESULT FOR
            
              SELECT
              
               C.ID AS PROD_ID, --产品ID
               C.CPDM AS PROD_CODE, --产品代码
               C.CPMC AS PROD_NAME, --产品名称
               NVL((CASE
                 WHEN C.CPXL = 1 THEN
                  (SELECT (SELECT NOTE
                             FROM LIVEBOS.TXTDM
                            WHERE FLDM = 'PIF_JJLB_CPZX'
                              AND IBM = M.JJLX)
                     FROM TPIF_CPDM_N_GMJJ M
                    WHERE M.CPID = C.ID)
                 ELSE
                  (SELECT NOTE
                     FROM LIVEBOS.TXTDM
                    WHERE FLDM = 'PIF_CPXL_CPZX'
                      AND IBM = C.CPXL)
               END),A.NAME) AS PROD_TYPE, --产品类型 
               C.CPFXDJ AS PROD_RISK_LEVEL, --产品风险等级ID
               (SELECT NOTE
                  FROM LIVEBOS.TXTDM
                 WHERE FLDM = 'PIF_CPFXDJ_CPZX'
                   AND IBM = C.CPFXDJ) AS PROD_RISK_LEVEL_DESC, --产品风险等级描述 
                (case when nvl(c.QTJE,0)=0 then 100 else c.QTJE end)||'元' AS SUBSCRIBE_ORIGIN, --认购起点(元)
                C.JZRQ AS NAV_DATE, --净值日期
                to_char(ROUND(C.CPJZ,3),'FM9999990.0009')  AS UNIT_NAV,
                to_char(ROUND(C.WFSYL,3),'FM9999990.0009') AS UNIT_YIELD, --万分收益
                (case when c.QRNHSYL is not null then to_char(ROUND(c.QRNHSYL*100,3),'FM9999990.009')||'%' end) AS D7_ANNUAL_YIELD_RATE, --七日年化收益率
               (CASE WHEN TRIM(C.CPQX) IS NULL THEN '无固定期限'
                     WHEN NVL(C.CPQX,0)='0' THEN '无固定期限'
                     else to_char(C.CPQX) ||'天' end)  AS PROD_TERM, --产品期限
               ROUND(C.YQSYL * 100, 2) AS PERFORMANCE_BENCHMARK, --业绩比较基准
               NULL AS YIELD_RATE_DAY, --日涨幅
               to_char(ROUND(D.JYYSYL , 2),'FM99990.009') ||'%' YIELD_RATE_MONTH, --近一个月涨幅
               to_char(ROUND(D.JSYSYL , 2),'FM99990.009') ||'%' YIELD_RATE_QUARTER, --近三个月涨幅
               to_char(ROUND(D.JYNSYL , 2),'FM99990.009') ||'%' YIELD_RATE_ONE_YEAR, --近一年涨幅
               to_char(ROUND(D.JNYLSYL , 2),'FM99990.009')||'%' YIELD_RATE_THISYEAR, --今年以来涨幅
               to_char(ROUND(D.CLYLSYL , 2),'FM99990.009')||'%' YIELD_RATE_SINCE_FOUND, --成立以来涨幅
               NULL AS BENCHMARK_PRICE, --基准价格
               NULL AS PAY_DESC, --支付说明
               NULL AS APPLICABLE_OBJECT, --适用对象
               NULL AS PROD_FIXED_PRICE_METHOD, --产品定价方式
               NULL AS SERVICE_METHOD, --服务方式
               NULL AS PROD_MANAGER, --产品经理
               NULL AS CONTACT_METHOD, --联系方式
               (select (case when count(*)>0 then 1 else 0 end) from tpif_wgzdcp where cpid=c.id and YH =I_USERID) AS IS_CONCERN
                FROM (SELECT ID,FID,NAME FROM TPIF_SYZSFL WHERE FID=I_PROD_LEVEL1_CLASS) A,
                     TPIF_SYZSFLCPMX B,
                     TPIF_CPDM C,
                     (SELECT CPID,
                             JYYSYL, --近1月收益率(%)
                             JSYSYL, --近3月收益率(%)
                             JLYSYL, --近6月收益率(%)
                             JYNSYL, --近1年收益率(%)
                             J3NSYL, --近3年收益率(%)
                             CLYLSYL, --成立以来收益率(%)
                             JNYLSYL --今年以来收益率(%)
                        FROM TPIF_CPJZ_YSZB
                       WHERE JZRQ = V_JZRQ) D
               WHERE A.ID = B.ZSFL
                 AND B.CPID = C.ID
                 AND C.ID = D.CPID(+)
                -- AND (trim(I_PROD_LEVEL2_CLASS) IS NULL OR A.ID = to_number(trim(I_PROD_LEVEL2_CLASS)))
                 and c.cpdm is not null 
                 and exists(select 1 from TPIF_WGZDCP where cpid=c.id and YH = I_USERID);
     end if ;      
               
  ELSE

        IF I_PROD_LEVEL1_CLASS = 5 THEN
        
          OPEN O_RESULT FOR
             SELECT
            
             C.ID AS PROD_ID, --产品ID
             C.CPDM AS PROD_CODE, --产品代码
             C.CPMC AS PROD_NAME, --产品名称
             A.NAME AS PROD_TYPE, --产品类型 
             C.CPFXDJ AS PROD_RISK_LEVEL, --产品风险等级ID
             (SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_CPFXDJ_CPZX'
                 AND IBM = C.CPFXDJ) AS PROD_RISK_LEVEL_DESC, --产品风险等级描述 
              NULL AS SUBSCRIBE_ORIGIN, --认购起点(元)
              C.JZRQ AS NAV_DATE, --净值日期
              to_char(ROUND(C.CPJZ,3),'FM9999990.0009')  AS UNIT_NAV,
              to_char(ROUND(C.WFSYL,3),'FM9999990.0009') AS UNIT_YIELD, --万分收益
              NULL AS D7_ANNUAL_YIELD_RATE, --七日年化收益率
             (CASE WHEN TRIM(C.CPQX) IS NULL THEN '无固定期限'
                   WHEN NVL(C.CPQX,0)='0' THEN '无固定期限'
                   else to_char(C.CPQX) ||'天' end)  AS PROD_TERM, --产品期限
             NULL AS PERFORMANCE_BENCHMARK, --业绩比较基准
             NULL AS YIELD_RATE_DAY, --日涨幅
             NULL AS YIELD_RATE_MONTH, --近一个月涨幅
             NULL AS YIELD_RATE_QUARTER, --近三个月涨幅
             NULL AS YIELD_RATE_ONE_YEAR, --近一年涨幅
             NULL AS YIELD_RATE_THISYEAR, --今年以来涨幅
             NULL AS YIELD_RATE_SINCE_FOUND, --成立以来涨幅
             (select wm_concat ((SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_DJZQ'
                 AND IBM = M.DJZQ ) ||':'||m.djz_xj||'元' ) FROM  TPIF_CPDM_FW_DJ M WHERE M.CPID = D.ID) AS BENCHMARK_PRICE, --基准价格
             D.ZFSM AS PAY_DESC, --支付说明
             (SELECT wm_concat( NOTE)
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_SYDX'
                 AND IBM = D.SYDX ) AS APPLICABLE_OBJECT, --适用对象
             (select wm_concat ((SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_DJZQ'
                 AND IBM = M.DJZQ ) ) FROM  TPIF_CPDM_FW_DJ M WHERE M.CPID = D.ID)  AS PROD_FIXED_PRICE_METHOD,
             (SELECT wm_concat( NOTE)
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_FWQD'
                 AND IBM = D.FWQD )  AS SERVICE_METHOD, --服务方式
            (SELECT NAME FROM LIVEBOS.TUSER WHERE ID= C.CPJL) AS PROD_MANAGER, --产品经理
             D.LXFS AS CONTACT_METHOD, --联系方式
             (select (case when count(*)>0 then 1 else 0 end) from tpif_wgzdcp where cpid=c.id and YH =I_USERID) AS IS_CONCERN
              FROM (SELECT ID,FID,NAME FROM TPIF_SYZSFL WHERE FID=I_PROD_LEVEL1_CLASS) A,
                   TPIF_SYZSFLCPMX B,
                   TPIF_CPDM C,
                   TPIF_CPDM_FW D
             WHERE A.ID = B.ZSFL
               AND B.CPID = C.ID
               AND C.ID = D.CPID
               AND (trim(I_PROD_LEVEL2_CLASS) IS NULL OR A.ID = to_number(trim(I_PROD_LEVEL2_CLASS)))
               and c.cpdm is not null 
               and rownum<=5;
        
        ELSE
        
          BEGIN
            SELECT MAX(JZRQ)
              INTO V_JZRQ
              FROM TPIF_CPJZ_YSZB
             WHERE 1=1;--JZRQ >= TO_NUMBER(TO_CHAR(SYSDATE - 180, 'YYYYMMDD'));
          EXCEPTION
            WHEN OTHERS THEN
              SELECT JYR
                INTO V_JZRQ
                FROM LIVEBOS.TXTJYR
               WHERE ZRR = TO_CHAR(SYSDATE - 1, 'YYYYMMDD');
          END;
        
          OPEN O_RESULT FOR
          
            SELECT
            
             C.ID AS PROD_ID, --产品ID
             C.CPDM AS PROD_CODE, --产品代码
             C.CPMC AS PROD_NAME, --产品名称
             NVL((CASE
               WHEN C.CPXL = 1 THEN
                (SELECT (SELECT NOTE
                           FROM LIVEBOS.TXTDM
                          WHERE FLDM = 'PIF_JJLB_CPZX'
                            AND IBM = M.JJLX)
                   FROM TPIF_CPDM_N_GMJJ M
                  WHERE M.CPID = C.ID)
               ELSE
                (SELECT NOTE
                   FROM LIVEBOS.TXTDM
                  WHERE FLDM = 'PIF_CPXL_CPZX'
                    AND IBM = C.CPXL)
             END),A.NAME) AS PROD_TYPE, --产品类型 
             C.CPFXDJ AS PROD_RISK_LEVEL, --产品风险等级ID
             (SELECT NOTE
                FROM LIVEBOS.TXTDM
               WHERE FLDM = 'PIF_CPFXDJ_CPZX'
                 AND IBM = C.CPFXDJ) AS PROD_RISK_LEVEL_DESC, --产品风险等级描述 
              (case when nvl(c.QTJE,0)=0 then 100 else c.QTJE end)||'元' AS SUBSCRIBE_ORIGIN, --认购起点(元)
              C.JZRQ AS NAV_DATE, --净值日期
              to_char(ROUND(C.CPJZ,3),'FM9999990.0009')  AS UNIT_NAV,
              to_char(ROUND(C.WFSYL,3),'FM9999990.0009') AS UNIT_YIELD, --万分收益
              (case when c.QRNHSYL is not null then to_char(ROUND(c.QRNHSYL*100,3),'FM9999990.009')||'%' end) AS D7_ANNUAL_YIELD_RATE, --七日年化收益率
             (CASE WHEN TRIM(C.CPQX) IS NULL THEN '无固定期限'
                   WHEN NVL(C.CPQX,0)='0' THEN '无固定期限'
                   else to_char(C.CPQX) ||'天' end)  AS PROD_TERM, --产品期限
             ROUND(C.YQSYL * 100, 2) AS PERFORMANCE_BENCHMARK, --业绩比较基准
             NULL AS YIELD_RATE_DAY, --日涨幅
             to_char(ROUND(D.JYYSYL , 2),'FM99990.009') ||'%' YIELD_RATE_MONTH, --近一个月涨幅
             to_char(ROUND(D.JSYSYL , 2),'FM99990.009') ||'%' YIELD_RATE_QUARTER, --近三个月涨幅
             to_char(ROUND(D.JYNSYL , 2),'FM99990.009') ||'%' YIELD_RATE_ONE_YEAR, --近一年涨幅
             to_char(ROUND(D.JNYLSYL , 2),'FM99990.009')||'%' YIELD_RATE_THISYEAR, --今年以来涨幅
             to_char(ROUND(D.CLYLSYL , 2),'FM99990.009')||'%' YIELD_RATE_SINCE_FOUND, --成立以来涨幅
             NULL AS BENCHMARK_PRICE, --基准价格
             NULL AS PAY_DESC, --支付说明
             NULL AS APPLICABLE_OBJECT, --适用对象
             NULL AS PROD_FIXED_PRICE_METHOD, --产品定价方式
             NULL AS SERVICE_METHOD, --服务方式
             NULL AS PROD_MANAGER, --产品经理
             NULL AS CONTACT_METHOD, --联系方式
             (select (case when count(*)>0 then 1 else 0 end) from tpif_wgzdcp where cpid=c.id and YH =I_USERID) AS IS_CONCERN
              FROM (SELECT ID,FID,NAME FROM TPIF_SYZSFL WHERE FID=I_PROD_LEVEL1_CLASS) A,
                   TPIF_SYZSFLCPMX B,
                   TPIF_CPDM C,
                   (SELECT CPID,
                           JYYSYL, --近1月收益率(%)
                           JSYSYL, --近3月收益率(%)
                           JLYSYL, --近6月收益率(%)
                           JYNSYL, --近1年收益率(%)
                           J3NSYL, --近3年收益率(%)
                           CLYLSYL, --成立以来收益率(%)
                           JNYLSYL --今年以来收益率(%)
                      FROM TPIF_CPJZ_YSZB
                     WHERE JZRQ = V_JZRQ) D
             WHERE A.ID = B.ZSFL
               AND B.CPID = C.ID
               AND C.ID = D.CPID(+)
               AND (trim(I_PROD_LEVEL2_CLASS) IS NULL OR A.ID = to_number(trim(I_PROD_LEVEL2_CLASS)))
               and c.cpdm is not null 
               and rownum<=5;

        END IF;
  END IF;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

