create FUNCTION     parsejson(p_jsonstr varchar2,p_key varchar2) RETURN VARCHAR2
AS
  rtnVal VARCHAR2(3000);
  i NUMBER(2);
  jsonkey VARCHAR2(500);
  jsonvalue VARCHAR2(1000);
  json VARCHAR2(3000);
BEGIN
  IF p_jsonstr IS NOT NULL THEN
     
     if p_key='data' then
       
        rtnVal := rtrim(ltrim(substr(p_jsonstr , instr(p_jsonstr,'data')+6, instr(p_jsonstr,'}',instr(p_jsonstr,'data'),1)-instr(p_jsonstr,'data')-5),'"'),'"');
       
     else

  
         json := REPLACE(p_jsonstr,'{','') ;
         json := REPLACE(json,'}','') ;
         json := replace(json,'"','') ;
         FOR temprow IN(SELECT strvalue AS VALUE FROM TABLE(fn_split(json, ','))) LOOP
            IF temprow.VALUE IS NOT NULL THEN
               i := 0;
               jsonkey := '';
               jsonvalue := '';
               FOR tem2 IN(SELECT strvalue AS VALUE FROM TABLE(fn_split(temprow.value, ':'))) LOOP
                   IF i = 0 THEN
                      jsonkey := tem2.VALUE;
                   END IF;
                   IF i = 1 THEN
                      jsonvalue := tem2.VALUE;
                   END IF;

                   i := i + 1;
               END LOOP;

               IF(jsonkey = p_key) THEN
                   rtnVal := jsonvalue;
               END if;
            END IF;
         END LOOP;
     
   end if;  
     
     
  END IF;
  RETURN rtnVal;
END parsejson;
/

