create PROCEDURE PCX_CPYY_YYKHCX (
                                                       --    O_NOTE  OUT VARCHAR2,
                                                           O_RESULT     OUT SYS_REFCURSOR,-- 返回结果集
                                                           I_CZR IN NUMBER,--当前登录人,
                                                           I_YYCPID IN NUMBER --预约产品ID

) AS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：     I_YYCPID  产品预约管理ID
                                 I_CZR   操作人
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                              
      逻辑说明：  查询当前产品的预约客户记录，管理看所有，分公司看包含
      子部门的记录，营业部只能看当前营业部的预约记录                        
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WWH        预约客户信息查询
  ***********************************************************************/

V_YYCPID NUMBER;
V_SQL VARCHAR2(32767);
V_WHERE VARCHAR2(32767);
V_CZR NUMBER;
V_ORGID NUMBER;--用户所属部门
V_ZBGLG NUMBER; --总部管理岗
V_FGSGLG NUMBER;--分公司管理岗
V_YYBYWRY NUMBER;--营业部业务人员
ZB_ROLE NUMBER; --总部管理人角色ID
FGS_ROLE NUMBER;--分公司管理人角色ID
YYB_ROLE NUMBER; --营业部业务人员角色ID
V_SORT VARCHAR2(1000); -- 排序条件

O_NOTE   VARCHAR2(300);
BEGIN
O_NOTE:='';
V_YYCPID:=I_YYCPID;
/*ZB_ROLE:=900011;
FGS_ROLE:=900012;
YYB_ROLE:=900013;*/
V_CZR:=I_CZR;

--获取用户所在部门
/*SELECT ORGID INTO V_ORGID FROM   LIVEBOS.TUSER WHERE  ID = V_CZR;
--判断该用户是否是总部管理人角色
SELECT COUNT(1) INTO  V_ZBGLG FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =ZB_ROLE AND USERID =V_CZR;
--判断该用户是否是分公司管理人角色
SELECT COUNT(1) INTO  V_FGSGLG FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =FGS_ROLE AND USERID =V_CZR;
--判断该用户是否是营业部业务人员
SELECT COUNT(1) INTO  V_YYBYWRY FROM LIVEBOS.LBMEMBER  A WHERE A.ROLEID =YYB_ROLE AND USERID =V_CZR;*/
/*--管理员查看
IF V_CZR = 0 THEN
  V_ZBGLG:=1;
END IF;
*/
V_SORT:='    ORDER BY TJSJ DESC';
/*V_SQL:='SELECT A.ID,
A.ZJZHID AS ZJZH,
       A.KHXM,
       A.DHHM,
       A.ZJLX,
       A.SFZH AS ZJHM,
       A.YYJE,
       A.YYBID AS SSYYB,
       (SELECT FID FROM LIVEBOS.LBORGANIZATION WHERE ID =A.YYBID ) AS SSFGS,
       A.TJR AS JBR,
       A.TJSJ,
       A.YYSYWCC AS YWCC
FROM   TPIF_YYGL A
WHERE A.YYCPID ='||V_YYCPID|| '  '; */

      V_SQL:= 'SELECT A.ID,
A.ZJZHID AS ZJZH,
       A.KHXM,
       A.DHHM,
       (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''CTGT_ZJLX'' AND CBM=TO_CHAR(A.ZJLX)) AS ZJLX,
       A.SFZH AS ZJHM,
       A.YYJE,
       A.YYBID AS SSYYB,
       (SELECT FID FROM LIVEBOS.LBORGANIZATION WHERE ID =A.YYBID ) AS SSFGS,
       A.TJR AS JBR,
       A.TJSJ,
       (SELECT COUNT(1) FROM DSC_STAT.TPIF_YYCZXX WHERE ZJZH =A.ZJZHID   AND DQSL>0 AND CPDM = (SELECT CPDM FROM TPIF_YYCPGL WHERE ID = A.YYCPID )) AS YWCC
     
FROM   TPIF_YYGL A WHERE YYCPID = '||V_YYCPID||' AND YYBID IN   (SELECT ID FROM LIVEBOS.LBORGANIZATION  START WITH ID IN (
  SELECT CASE WHEN SCOPEEXP = ''<ALL>'' THEN ''183'' ELSE SCOPEEXP END
                                 FROM LIVEBOS.LBDATASCOPEAUTH
                                WHERE MEMBERID IN
                                      (select ROLEID from LIVEBOS.LBMEMBER WHERE USERID =  '||V_CZR||')
                                  AND TYPE = 1
                                  AND SCOPENAME = ''YYB''                                                              
                                   UNION ALL
                               SELECT CASE WHEN SCOPEEXP = ''<ALL>'' THEN ''183'' ELSE SCOPEEXP END
                                 FROM LIVEBOS.LBDATASCOPEAUTH
                                WHERE MEMBERID = '||V_CZR||'
                                  AND TYPE = 0
                                  AND SCOPENAME = ''YYB'') CONNECT BY PRIOR  ID=FID )';
/*LEFT   JOIN INFO.TINFO_ZJZHXX B
ON     A.ZJZHID = B.KHH */
--实时持仓查询
/*(SELECT COUNT(1) FROM DSC_STAT.TPIF_YYCZXX WHERE ZJZH =A.ZJZHID AND  CPDM = (SELECT CPDM FROM TPIF_YYCPGL WHERE ID = A.YYCPID )) AS YWCC
*/
/*--总部查询SQL
     IF V_ZBGLG >0 THEN
       V_WHERE:=' ';
       END IF;
--分公司查询SQL
     IF V_FGSGLG >0 THEN
         V_WHERE:= '  AND     YYCPID ='||V_YYCPID||'   AND  YYBID  IN (SELECT ID
                         FROM   LIVEBOS.LBORGANIZATION
                         WHERE  BRANCH_ID IS NOT NULL
                         START  WITH ID = '||V_ORGID||'
                         CONNECT BY PRIOR ID = FID) ';
                         END IF;
 --营业部查询SQL
    IF V_YYBYWRY >0 THEN
      V_WHERE:=' AND  YYCPID ='||V_YYCPID||'     AND  YYBID  IN ( '||V_ORGID||')   '  ;    
   END IF;
   */
    --拼接SQL
    
/*    V_SQL:=V_SQL||V_WHERE||V_SORT;   */
 IF  V_CZR=0 THEN
   V_SQL:='SELECT A.ID,
A.ZJZHID AS ZJZH,
       A.KHXM,
       A.DHHM,
       (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''CTGT_ZJLX'' AND CBM=to_char(A.ZJLX)) AS ZJLX,
       A.SFZH AS ZJHM,
       A.YYJE,
       A.YYBID AS SSYYB,
       (SELECT FID FROM LIVEBOS.LBORGANIZATION WHERE ID =A.YYBID ) AS SSFGS,
       A.TJR AS JBR,
       A.TJSJ,
             (SELECT COUNT(1) FROM DSC_STAT.TPIF_YYCZXX WHERE ZJZH =A.ZJZHID   AND DQSL>0 AND CPDM = (SELECT CPDM FROM TPIF_YYCPGL WHERE ID = A.YYCPID )) AS YWCC

FROM   TPIF_YYGL A
WHERE A.YYCPID ='||V_YYCPID|| '  '; 
   END IF;
      V_SQL:=V_SQL||V_SORT;
    dbms_output.put_line('V_SQL:  '||V_SQL);
    OPEN O_RESULT FOR V_SQL;
    
    O_NOTE:='成功！';
EXCEPTION
  WHEN OTHERS THEN

    O_NOTE := SQLERRM;
    OPEN o_result FOR
      SELECT '异常信息：' || O_NOTE FROM dual;

END;


/

