create PROCEDURE PCX_PIF_CPQJ_CPQJMB(O_CODE    OUT NUMBER,
                                                O_NOTE    OUT VARCHAR2,
                                                O_RESULT  OUT SYS_REFCURSOR,
                                                I_USERID  IN NUMBER, --用户ID
                                                I_PROD_ID IN NUMBER --产品ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-我适用的模版
  所属用户：PIF
  概要说明：查询当前登录人所在部门适用的产品全景模版列表.
  
               I_USERID         IN NUMBER, --用户 ID
               I_PROD_ID         IN NUMBER  --产品ID
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询当前登录人所在部门适用的模版列表.
  
        当前登录人所在部门适用的模版可能有多个，按照最近配置日期排序取最近的，(ID大的)
        
        如果传产品，则查询先查该产品的模板，然后查该用户能看该产品的哪些模板
        如果不产品，相当于查该用户能看的模板
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2021-12-3      1.0.0    GAOKUN               修改优化，加注释
  *********************************************************************************************************************/
  V_SQL    VARCHAR2(32767);
  V_ERRMSG VARCHAR2(300); --错误信息
  V_COUNT  NUMBER(12);
  V_MBIDS  VARCHAR2(2000); --该用户满足的模板ID（第二步，看产品满足的模板能不能给该用户看）
  V_IDS    VARCHAR2(2000); --该产品满足的模板ID（第一步）
BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '成功';

  IF I_USERID IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【用户ID】';
    RETURN;
  END IF;

  --验证是否存在适用于当前登录人的全景模版
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBZT = 1; --查询启用模板数量
  IF V_COUNT = 0 THEN
    O_CODE := -2;
    O_NOTE := '当前无启用的全景模板,请联系管理员!';
    RETURN;
  END IF;

  --对于启用的模板，循环
  FOR CUR IN (SELECT ID, CPJH FROM TPIF_CPQJMBDY WHERE MBZT = 1) LOOP
    --循环该模板所应用的产品集合的WHERE，来查该产品是否满足该WHERE，满足则等于满足该模板
    FOR CUR_JH IN (SELECT SQLWHERE
                     FROM TPIF_CPJH
                    WHERE INSTR(';' || CUR.CPJH || ';', ';' || ID || ';') > 0
                      AND ZT = 1 --启用的集合
                   ) LOOP
      V_SQL := 'SELECT COUNT(1) FROM PIF.TPIF_CPDM WHERE ID = ' ||
               I_PROD_ID || ' AND ' || CUR_JH.SQLWHERE; --查该产品是否满足
    
      --DBMS_OUTPUT.PUT_LINE(V_SQL);
    
      BEGIN
        EXECUTE IMMEDIATE V_SQL
          INTO V_COUNT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      IF V_COUNT > 0 THEN
        --如果有满足的模板，则记录该模板ID
        V_IDS := V_IDS || ';' || CUR.ID;
      END IF;
    END LOOP;
  END LOOP;

  IF V_IDS IS NULL THEN
    O_CODE := -2;
    O_NOTE := '当前无适用于此产品的全景模板,请联系管理员!';
    RETURN;
  END IF;

  V_MBIDS := '';
  --判断该用户能不能看该产品满足的模板
  IF I_USERID = 0 THEN
    --如果是管理员，管理员默认全部权限，能看 该产品满足的模板
    SELECT ';' || REPLACE(WM_CONCAT(ID), ',', ';')
      INTO V_MBIDS
      FROM TPIF_CPQJMBDY
     WHERE INSTR(V_IDS || ';', ';' || ID || ';') > 0;
  ELSE
    --其他人员
    --先根据用户判断
    FOR CUR IN (SELECT *
                  FROM TPIF_CPQJMBDY A
                 WHERE INSTR(V_IDS || ';', ';' || A.ID || ';') > 0
                   AND EXISTS (SELECT 1
                          FROM TPIF_CPQJMBDY_SYFW B --适用范围
                         WHERE B.TPIF_CPQJMBDY_ID = A.ID
                           AND B.FWLX = 3) --范围类型=3 用户
                ) LOOP
      FOR CUR_S IN (SELECT *
                      FROM TPIF_CPQJMBDY_SYFW
                     WHERE TPIF_CPQJMBDY_ID = CUR.ID
                       AND FWLX = 3) LOOP
        IF INSTR(';' || CUR_S.SYYH || ';', ';' || I_USERID || ';') > 0 THEN
          --如果该模板的适用范围中的用户包含该用户，则该模板能给该用户看，满足
          V_MBIDS := V_MBIDS || ';' || CUR.ID;
        END IF;
      END LOOP;
    END LOOP;
  
    --如果通过用户判断，没有满足的模板，
    IF V_MBIDS IS NULL THEN
      FOR CUR IN (SELECT *
                    FROM TPIF_CPQJMBDY A
                   WHERE INSTR(V_IDS || ';', ';' || A.ID || ';') > 0
                     AND EXISTS (SELECT 1
                            FROM TPIF_CPQJMBDY_SYFW B
                           WHERE B.TPIF_CPQJMBDY_ID = A.ID
                             AND B.FWLX = 4) --范围类型=4组织角色
                  ) LOOP
        FOR CUR_S IN (SELECT *
                        FROM TPIF_CPQJMBDY_SYFW
                       WHERE TPIF_CPQJMBDY_ID = CUR.ID
                         AND FWLX = 4) LOOP
          SELECT COUNT(1)
            INTO V_COUNT
            FROM LIVEBOS.LBMEMBER
           WHERE USERID = I_USERID --该用户
             AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0 --角色
             AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0; --部门(组织)
          IF V_COUNT > 0 THEN
            V_MBIDS := V_MBIDS || ';' || CUR.ID;
          END IF;
        END LOOP;
      END LOOP;
    END IF;
  
    --如果用户和组织角色判断都为空
    IF V_MBIDS IS NULL THEN
      FOR CUR IN (SELECT *
                    FROM TPIF_CPQJMBDY A
                   WHERE INSTR(V_IDS || ';', ';' || A.ID || ';') > 0
                     AND EXISTS (SELECT 1
                            FROM TPIF_CPQJMBDY_SYFW B
                           WHERE B.TPIF_CPQJMBDY_ID = A.ID
                             AND B.FWLX = 2) --范围类型=2角色
                  ) LOOP
        FOR CUR_S IN (SELECT *
                        FROM TPIF_CPQJMBDY_SYFW
                       WHERE TPIF_CPQJMBDY_ID = CUR.ID
                         AND FWLX = 2) LOOP
          SELECT COUNT(1)
            INTO V_COUNT
            FROM LIVEBOS.LBMEMBER
           WHERE USERID = I_USERID
             AND INSTR(';' || CUR_S.SYJS || ';', ';' || ROLEID || ';') > 0; --单用角色
          IF V_COUNT > 0 THEN
            V_MBIDS := V_MBIDS || ';' || CUR.ID;
          END IF;
        END LOOP;
      END LOOP;
    END IF;
  
    --还为空，继续
    IF V_MBIDS IS NULL THEN
      FOR CUR IN (SELECT *
                    FROM TPIF_CPQJMBDY A
                   WHERE INSTR(V_IDS || ';', ';' || A.ID || ';') > 0
                     AND EXISTS (SELECT 1
                            FROM TPIF_CPQJMBDY_SYFW B
                           WHERE B.TPIF_CPQJMBDY_ID = A.ID
                             AND B.FWLX = 1) --范围类型=1组织
                  ) LOOP
        FOR CUR_S IN (SELECT *
                        FROM TPIF_CPQJMBDY_SYFW
                       WHERE TPIF_CPQJMBDY_ID = CUR.ID
                         AND FWLX = 1) LOOP
          SELECT COUNT(1)
            INTO V_COUNT
            FROM LIVEBOS.TUSER
           WHERE ID = I_USERID
             AND INSTR(';' || CUR_S.SYBM || ';', ';' || ORGID || ';') > 0; --部门(组织)
          IF V_COUNT > 0 THEN
            V_MBIDS := V_MBIDS || ';' || CUR.ID;
          END IF;
        END LOOP;
      END LOOP;
    END IF;
  
    --还为空，继续
    IF V_MBIDS IS NULL THEN
      FOR CUR IN (SELECT *
                    FROM TPIF_CPQJMBDY A
                   WHERE INSTR(V_IDS || ';', ';' || A.ID || ';') > 0
                     AND EXISTS (SELECT 1
                            FROM TPIF_CPQJMBDY_SYFW B
                           WHERE B.TPIF_CPQJMBDY_ID = A.ID
                             AND B.FWLX = 0) --范围类型=0所有员工
                  ) LOOP
        V_MBIDS := V_MBIDS || ';' || CUR.ID; --存在模板则该用户一定满足，直接取
      END LOOP;
    END IF;
  END IF;
  --判断结束，V_MBIDS即该用户能看到的 该产品满足的模板 ID

  V_MBIDS := SUBSTR(V_MBIDS, 2); --去掉前面的';'

  --没有则报错
  IF V_MBIDS IS NULL THEN
    O_CODE := -2;
    O_NOTE := '错误：当前登录人无权查看此产品的产品全景信息！';
    RETURN;
  ELSE
    --如果有多个模板，则取ID最大的那一个，一般来说ID大的是离当前最近的
    V_SQL := ' SELECT  MB.ID 
                 FROM PIF.TPIF_CPQJMBDY MB
                WHERE INSTR('';' || V_MBIDS ||
             ';'' ,'';''||MB.ID||'';'')>0
                  AND ROWNUM = 1
             ORDER BY ID DESC';
  
    --DBMS_OUTPUT.PUT_LINE(V_SQL);
  END IF;

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || V_ERRMSG FROM DUAL;
  
  
END PCX_PIF_CPQJ_CPQJMB;
/

