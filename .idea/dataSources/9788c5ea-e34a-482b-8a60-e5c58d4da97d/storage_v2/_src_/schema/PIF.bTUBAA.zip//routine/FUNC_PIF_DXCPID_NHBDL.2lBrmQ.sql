create FUNCTION FUNC_PIF_DXCPID_NHBDL(I_TJRQ IN NUMBER, --统计日期
                                               I_KSRQ IN NUMBER, --回测开始时间
                                               I_CPID IN NUMBER  --产品ID

                                               ) RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算年化波动率（代销产品表使用）

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        gaokun   1.0.0    2021/02/20                   新增
  --------------------------------------------------------------------------------*/
  V_FC     NUMBER;
  V_NHBDL  NUMBER;
  V_JSTS   NUMBER;
  V_PJZF   NUMBER;
  V_ZRLJJZ NUMBER;
  V_JYRQ   NUMBER;
BEGIN
  --变量初始化
  V_FC := 0;

  --获取平均涨幅
  SELECT AVG(ZZF)
    INTO V_PJZF
    FROM TPIF_DXCPJZXX
   WHERE CPID = I_CPID
     AND JYRQ >= I_KSRQ
     AND JYRQ <= I_TJRQ;

  /*--获取交易天数
  SELECT COUNT(*)
    INTO V_JSTS
    FROM LIVEBOS.TXTJYR
   WHERE ZRR = JYR
     AND JYR > I_KSRQ
     AND JYR <= I_TJRQ;*/

  --循环计算当前产品的方差
  V_JSTS := 0 ;
  FOR CUR_FC IN (SELECT CPID,
                        JYRQ,
                        LJJZ,
                        LAG(LJJZ, 1, 0) OVER(PARTITION BY CPID ORDER BY JYRQ ASC) AS ZRLJJZ
                   FROM TPIF_DXCPJZXX A
                  WHERE A.CPID = I_CPID
                    AND EXISTS (SELECT 1
                           FROM LIVEBOS.TXTJYR
                          WHERE ZRR = JYR
                            AND JYR = A.JYRQ
                            AND JYR >= I_KSRQ
                            AND JYR <= I_TJRQ)) LOOP


    V_ZRLJJZ := CUR_FC.ZRLJJZ ;

    IF V_ZRLJJZ = 0 THEN

       BEGIN
         SELECT MAX(JYRQ) INTO V_JYRQ FROM TPIF_DXCPJZXX WHERE CPID=CUR_FC.CPID AND JYRQ < CUR_FC.JYRQ;

         SELECT LJJZ INTO V_ZRLJJZ FROM TPIF_DXCPJZXX WHERE CPID=CUR_FC.CPID AND JYRQ = V_JYRQ;

       EXCEPTION WHEN OTHERS THEN

          V_ZRLJJZ :=  CUR_FC.LJJZ ;

       END;


    END IF ;


    --计算方差之和
    V_FC := POWER((CUR_FC.LJJZ /V_ZRLJJZ - 1 - V_PJZF), 2) +
            NVL(V_FC, 0);

    V_JSTS := V_JSTS + 1 ;

  END LOOP;

  --获取年化波动率

  --特殊处理如果交易天数只有1天的情况下
  IF V_JSTS = 1 THEN

      V_NHBDL := 0 ;

  ELSE

      V_NHBDL := ROUND(POWER(V_FC * (1 / (V_JSTS - 1)) * 243, 0.5) * 100, 6);

  END IF;
  RETURN V_NHBDL;

EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;
/

