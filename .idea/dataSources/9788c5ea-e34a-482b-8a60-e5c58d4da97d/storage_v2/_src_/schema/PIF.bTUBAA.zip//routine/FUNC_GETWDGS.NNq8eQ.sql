create FUNCTION FUNC_GETWDGS(I_WDMC IN VARCHAR2 -- 文档名称
                                        ) RETURN NUMBER IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：获取新录入产品的CPID
      语法信息：
           输入参数：    I_CPXL IN NUMBER, --产品系列
  
           输出参数：   
            1  WORD 包括doc和docx两种格式  doc;docx
            2  EXCEL  xls和xlsx  xls;xlsx
            3  PPT  ppt和pptx  ppt;pptx
            4  TXT  文本文件  txt
            6  PDF  pdf格式 pdf
            7   DBF 桌面数据库文件 dbf
            8  XML  xml文件 xml
            99  QT  其他  .
  
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-08-08     1.0       WUJINFENG               创建
  ***********************************************************************/
  V_WDGS NUMBER;
  V_WDHZ VARCHAR2(20);
BEGIN

  IF I_WDMC IS NULL THEN
    V_WDGS := 99;
  END IF;

  --文件无后缀
  IF INSTR('22222', '.') = 0 THEN
    V_WDGS := 99;
  END IF;

  SELECT SUBSTR(I_WDMC, INSTR(I_WDMC, '.', -1) + 1, LENGTH(I_WDMC))
    INTO V_WDHZ
    FROM DUAL;

  --1   WORD 包括doc和docx两种格式  doc;docx
  IF UPPER(V_WDHZ) IN ('DOC', 'DOCX') THEN
    V_WDGS := 1;
  ELSIF UPPER(V_WDHZ) IN ('XLS', 'XLSX') THEN
    V_WDGS := 2;
  ELSIF UPPER(V_WDHZ) IN ('PPT', 'PPTX') THEN
    V_WDGS := 3;
  ELSIF UPPER(V_WDHZ) IN ('TXT', 'LOG', 'PROC') THEN
    V_WDGS := 4;
  ELSIF UPPER(V_WDHZ) IN ('PDF') THEN
    V_WDGS := 6;
  ELSIF UPPER(V_WDHZ) IN ('DBF') THEN
    V_WDGS := 7;
  ELSIF UPPER(V_WDHZ) IN ('XML') THEN
    V_WDGS := 8;
  ELSE
    V_WDGS := 99;
  END IF;
  RETURN(V_WDGS);
END;
/

