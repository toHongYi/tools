create FUNCTION FUNC_GET_MDYYBYHIDS(I_ORGID IN VARCHAR2 --营业部ID
                                               ) RETURN VARCHAR2 IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：获取营业部摸底通知人员,角色为分支机构产品联络岗和管理人岗
      语法信息：
           输入参数：I_ORGID  NUMBER  营业部id
  
           输出参数：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          20211213       1.0.1     hanqn              新增
  ***********************************************************************/
  V_RET VARCHAR2(4000);
BEGIN
  SELECT to_char(wm_concat(userid))
    INTO V_RET
    FROM livebos.tuser t
   WHERE EXISTS (SELECT 1
            FROM livebos.lbrole a, livebos.lbmember b
           WHERE a.rolecode IN ('FZJG_CPLLG', 'FZJG_GLG')
             AND a.id = b.roleid
             AND b.userid = t.id)  --角色为产品联络岗或管理人岗
     AND (EXISTS                   --判断用户数据权限
          (SELECT 1  
             FROM LIVEBOS.LBDATASCOPEAUTH M
            WHERE M.scopename = 'YYB' 
              AND M.TYPE = 0         
              AND M.MEMBERID = T.ID
              AND EXISTS(SELECT ID,FID FROM LIVEBOS.LBORGANIZATION X WHERE INSTR(','||I_ORGID||',',','||X.ID||',')>0 START WITH  ID=M.SCOPEEXP CONNECT BY PRIOR ID=FID )
            ) 
          OR EXISTS                --判断用户角色数据权限
           (SELECT 1
             FROM LIVEBOS.LBMEMBER M, LIVEBOS.LBDATASCOPEAUTH N,(SELECT ID,FID FROM LIVEBOS.LBORGANIZATION START WITH  ID=301 CONNECT BY PRIOR ID=FID)P
            WHERE N.scopename = 'YYB' AND N.SCOPEEXP=P.ID
              AND N.TYPE = 1
              AND M.ROLEID = N.MEMBERID
              AND M.USERID = T.ID
              AND EXISTS(SELECT ID,FID FROM LIVEBOS.LBORGANIZATION X WHERE INSTR(','||I_ORGID||',',','||X.ID||',')>0 START WITH  ID=N.SCOPEEXP CONNECT BY PRIOR ID=FID)
            )
           );


  RETURN(V_RET);
END;
/

