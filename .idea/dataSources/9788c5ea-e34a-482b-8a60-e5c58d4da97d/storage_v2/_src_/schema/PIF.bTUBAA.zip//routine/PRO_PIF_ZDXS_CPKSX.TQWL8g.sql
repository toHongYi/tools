create PROCEDURE PRO_PIF_ZDXS_CPKSX(O_CODE OUT NUMBER, --返回值
                                               O_NOTE OUT VARCHAR2, --返回消息
                                               I_USER IN INTEGER, --操作人
                                               I_OPER IN INTEGER, --操作类型1|上移;2|下移；3|启用;4|禁用;5|删除
                                               I_ID IN INTEGER --操作ID (重点销售产品库ID)
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：重点销售产品管理-产品顺序
        语法信息：
             输入参数：I_USER IN INTEGER, --操作人
                       I_OPER IN INTEGER, --操作类型1|上移;2|下移;3|启用;4|禁用
                       I_ZDCPGLID IN INTEGER --操作ID (重点销售产品管理ID)

             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-06-09     1.0.1     HQN                新增
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量
    V_CPKID INTEGER; --产品库id
    V_QXBZ  INTEGER; --权限标识
    V_ID    INTEGER;
    V_ZT    INTEGER; --产品库状态
    V_ZHID  INTEGER; --置换id
    V_ZHSX  INTEGER; --置换顺序
    V_ZSSX  INTEGER; --显示排序
    V_OBJ   TPIF_CPBQMX%ROWTYPE; --表单记录
    V_SFSF  INTEGER; --是否首发
    V_CZSM VARCHAR2(2000); --日志操作明细
BEGIN
    --INIT
    O_CODE := 1;
    O_NOTE := '';


    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
     O_NOTE :='操作成功';

    --获取是否置顶，置顶顺序，展示顺序和产品库

    SELECT SFSF,ZSSX,ID,ZT INTO V_SFSF,V_ZSSX,V_ID,V_ZT
     FROM PIF.TPIF_ZDXS_CPK WHERE ID=I_ID;

    IF I_OPER = 1 THEN --上移
       IF  V_ZSSX=1 THEN  --第一位
        O_CODE:=-1;
        O_NOTE:='该产品库已在第一位，无法上移';
        RETURN;
       END IF;
       --获取置换产品库id
       SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CPK WHERE ZSSX=V_ZSSX-1;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=V_ZSSX-1 WHERE ID=I_ID;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=V_ZSSX WHERE ID=V_ZHID;
    END IF;
    
    IF I_OPER = 2 THEN --下移
       SELECT COUNT(1) INTO V_COUNT FROM PIF.TPIF_ZDXS_CPK WHERE ZSSX>V_ZSSX;
       IF V_COUNT=0 THEN 
       O_CODE:=-1;
       O_NOTE:='该产品库已在最后一位，无法下移';
       RETURN;
       END IF;  
       --获取置换产品库id
       SELECT ID INTO V_ZHID FROM PIF.TPIF_ZDXS_CPK WHERE ZSSX=V_ZSSX+1;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=V_ZSSX+1 WHERE ID=I_ID;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=V_ZSSX WHERE ID=V_ZHID;
    END IF;   
    
    IF I_OPER = 3 AND V_ZT=0 THEN --启用产品库
       SELECT NVL(MAX(ZSSX),0)+1 INTO V_ZSSX FROM PIF.TPIF_ZDXS_CPK;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=V_ZSSX,ZT=1 WHERE ID=I_ID;
    END IF; 
    
   IF I_OPER = 4 AND V_ZT=1 THEN --禁用产品库
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=ZSSX-1 WHERE ZSSX >V_ZSSX AND ZT=1;
       UPDATE PIF.TPIF_ZDXS_CPK SET ZSSX=NULL,ZT=0 WHERE ID=I_ID;
    END IF;
   
   IF I_OPER =5 THEN
     
     --宣传图片删除
     UPDATE TPIF_ZDXS_CPXCTP T
        SET SFSC = 1
      WHERE EXISTS (SELECT 1
               FROM TPIF_ZDXS_CP
              WHERE ID = T.ZDCPGLID
                AND CPKID = I_ID);
                
     --产品库产品删除
     UPDATE TPIF_ZDXS_CP 
        SET SFSC =1,
            FBZT =0
      WHERE CPKID = I_ID
        AND SFSC =0;
     
   END IF;
   
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_ZDXS_CPKSX;
/

