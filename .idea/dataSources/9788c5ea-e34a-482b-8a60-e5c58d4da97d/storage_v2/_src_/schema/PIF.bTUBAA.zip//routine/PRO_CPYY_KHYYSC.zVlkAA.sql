create PROCEDURE PRO_CPYY_KHYYSC(O_CODE   OUT NUMBER,
                                            O_NOTE   OUT VARCHAR2,
                                            I_YYCPID IN NUMBER, --预约产品ID
                                            I_YYGLID IN NUMBER --预约记录ID
                                            ) AS
  /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数： I_YYCPID 预约产品ID
                      I_YYGLID   预约记录ID
  
  
           输出参数：   O_CODE  返回值
                        O_NOTE      返回消息
  
      逻辑说明：   预约记录删除，返还预约金额和营业部额度；
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-12-27     1.0.0       HANQN             预约记录删除
  ***********************************************************************/
  V_YYJLID    NUMBER(10);
  V_YYJE      NUMBER(16, 2); --预约金额
  V_ORG       NUMBER(10); --资金账号所属营业部
  V_YYCPID    NUMBER(10);
  V_ZKYED     NUMBER(16, 2);
  V_ZKYRS     NUMBER(10);
  V_COUNT     NUMBER(10);
  V_SFCC      NUMBER(2); --预约时是否有持仓
  
BEGIN
  V_YYJLID := I_YYGLID;
  V_YYCPID := I_YYCPID;
  
  --获取预约金额，营业部和预约时有无持仓
  SELECT YYJE, YYBID, nvl(YYSYWCC,0)
    INTO V_YYJE, V_ORG, V_SFCC
    FROM TPIF_YYGL
   WHERE ID = V_YYJLID;
  SELECT YYZED INTO V_ZKYED FROM TPIF_YYCPGL WHERE ID = V_YYCPID;
  SELECT YYZRS INTO V_ZKYRS FROM TPIF_YYCPGL WHERE ID = V_YYCPID;

  --有持仓，减去持仓用户金额和人数，不返还额度
  IF V_SFCC = 1 THEN   
    UPDATE TPIF_YYCPGL
       SET CCKHYYJE = CCKHYYJE - V_YYJE, CCKHYYSL = CCKHYYSL - 1
     WHERE ID = V_YYCPID;
  
    UPDATE TPIF_YYBXE
       SET CCKHYYJE = CCKHYYJE - V_YYJE, CCKHYYSL = CCKHYYSL - 1
     WHERE CPGLID = V_YYCPID
       AND YYBID = V_ORG;
  
    DELETE TPIF_YYGL WHERE ID = V_YYJLID; --删除预约记录
  
  END IF;
    
  --无持仓，返还已预约人数和已预约金额 
  IF V_SFCC = 0 THEN  
    UPDATE TPIF_YYCPGL
       SET YYYZJE = YYYZJE - V_YYJE, 
           YYYZRS = YYYZRS - 1
     WHERE ID = V_YYCPID;
  
    UPDATE TPIF_YYBXE
       SET YYJE = YYJE - V_YYJE,
           YYRS = YYRS - 1
     WHERE CPGLID = V_YYCPID
       AND YYBID = V_ORG;
  
    DELETE TPIF_YYGL WHERE ID = V_YYJLID; --删除预约记录
  
  END IF;
  COMMIT;
  
  O_CODE := 199;
  O_NOTE := '删除成功!';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := SQLERRM;
  
END;
/

