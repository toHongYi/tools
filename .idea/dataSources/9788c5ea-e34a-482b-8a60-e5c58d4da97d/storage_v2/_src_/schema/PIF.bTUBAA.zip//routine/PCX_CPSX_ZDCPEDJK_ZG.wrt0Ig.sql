create procedure pcx_cpsx_zdcpedjk_zg(cur_result out types.cursortype) is

  /*  项目：中信建投产品中心
      功能作用：重点产品额度监控_资管
      创建：
      作者      版本     时间
      侯金铂    1.0.1   20171020 新增
      侯金铂    1.0.2   20171026 修改：去掉开始日期，结束日期，额度，剩余额度；累计销售量改成当日净申购，只取当天
      侯金铂    1.0.3   20171102 修改  去掉不必要的临时表，优化效率
      侯金铂    1.0.4   20171211 排序默认按 项目编号倒序排序  ，统计不到数据时，取当前时间
      涂孟      1.0.5   20180608 修改资管的相关条件
      涂孟      1.0.6   20190109 修改增加日期限制
  */
  v_sql   varchar2(2000);
  v_tjsj  varchar2(20); -- 统计时间
  v_count number(8);
  v_rq    number(8) := to_number(to_char(sysdate,'yyyymmdd'));
begin

  --- 清空临时表数据

  -- EXECUTE IMMEDIATE ('TRUNCATE TABLE HIS.T_TEMP_ZDCPWTLS_ED_ZG');

  

    select to_char(sysdate, 'yyyymmdd hh24:mi:ss') into v_tjsj from dual; --- 统计不到数据时，取当前时间

  --- 插入数据

  /*   ---- 当日数据插入
  INSERT INTO HIS.T_TEMP_ZDCPWTLS_ED_ZG
  ( CPDM, CPMC, YYB, ZJZH, WTJE, RQ,TJSJ)
  SELECT  CPDM, CPMC, YYB, ZJZH, WTJE, RQ,V_TJSJ FROM HIS.T_PJWTLS_OFORDER A
  WHERE  A.CPDM IN (SELECT JKCPDM FROM PIF.TPIF_JKDMWH WHERE JKZT=1 AND CYSF = 3 )
  AND A.WTJE IS NOT NULL AND A.WTJE<>0; --  HIS.T_PJWTLS_OFORDER 表里只有当日的数据

  COMMIT ;*/

  v_sql := 'SELECT ''' || v_tjsj ||
           ''' AS 时间,
             A.XMBH 项目编号,
             A.XMMC 项目名称,
             DRJSG "当日净申购(万元)"
        FROM T_ZGDRXSJ A ';
/*  --测试用
  delete from pif.temp_xstj_test_xgh where cslx = 4.1;
  insert into pif.temp_xstj_test_xgh
    (sj, xmbh, xmmc, drjsg,cslx)
    select v_tjsj, a.xmbh, max(a.xmmc), nvl(sum(b.wtje), 0) / 10000,4.1
      from pif.tpif_jkdmwh a
      left join his.t_pjwtls_oforder b
        on a.jkcpdm = b.cpdm
     where a.jkzt = 1
       and a.zg = 2
     group by a.xmbh
     order by a.xmbh desc;
  commit;*/
  /*
   insert into pif.test_para (sj,proc,vsql,time) values (sysdate,'PCX_CPSX_ZDCPEDJK_ZG',V_SQL,sysdate) ;
   commit ;
  */
  open cur_result for v_sql;

exception
  when others then
    rollback;
    v_sql := 'SELECT ' || sqlerrm || ' FROM DUAL';
    open cur_result for v_sql;
    /*  O_CODE := -1;
    O_NOTE := SQLERRM;*/
end pcx_cpsx_zdcpedjk_zg;
/

