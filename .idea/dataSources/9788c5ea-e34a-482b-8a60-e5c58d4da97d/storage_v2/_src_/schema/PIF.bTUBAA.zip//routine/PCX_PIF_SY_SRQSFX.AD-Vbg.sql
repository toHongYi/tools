create PROCEDURE PCX_PIF_SY_SRQSFX(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              --I_TYPE          IN NUMBER, --类型:1:保有量 2:日均资 3:交易量
                                              I_TIME_INTERVAL IN NUMBER --统计周期: 1：近1年
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  项目名称：产品中心
  
         功能说明：产品首页-产品收入趋势分析
             参数说明：
                  入参：
                        I_TIME_INTERVAL  IN NUMBER --统计周期: 1：近1年
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
        liutx      1.1    2021/10/12                   收入改成保有量
        liutx      2.0    2021/12/21                   新增私募首页高频日均资产趋势、高频交易量趋势
  -----------------------------------------------------------------------------------------------*/
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_TIME_INTERVAL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TIME_INTERVAL不能为空!';
    RETURN;
  END IF;

  --近1年
  IF I_TIME_INTERVAL = 1 THEN
  
    --STAT_DATE       统计日期
    --STAT_DATE_DESC  统计日期描述
    --AMOUNT          金额
    OPEN O_RESULT FOR
      SELECT YF AS STAT_DATE,
             SUBSTR(YF, 1, 4) || '年' || SUBSTR(YF, 5, 2) || '月' AS STAT_DATE_DESC,
             --ROUND(SUM(XSSR)/10000,4) AS AMOUNT
             ROUND(SUM(NBYL) / 10000, 2) AS AMOUNT
        FROM --TPIF_ZB_XSGMSY_YTJ
             DSC_STAT.TPIF_STAT_CPDXYB_HZTJ
       WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'yyyymm')
       GROUP BY YF
       ORDER BY STAT_DATE ASC;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

