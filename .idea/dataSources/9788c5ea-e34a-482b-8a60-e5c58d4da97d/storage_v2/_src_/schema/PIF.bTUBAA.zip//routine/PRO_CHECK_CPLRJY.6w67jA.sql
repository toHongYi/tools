create PROCEDURE PRO_CHECK_CPLRJY(O_CODE OUT NUMBER,
                                             O_NOTE OUT VARCHAR2,
                                             I_ID IN NUMBER,
                                             I_LX IN NUMBER --1:适当性录入,0：适当性录入失败
                                             ) IS
                                             
/******************************************************************************
  *
  *创建人员：许龙全
  *创建日期：20190325
  *功能说明：产品录入校验

    *------------------------------------------------------------------------------
    *
    *修改者        版本号        修改日期        说明
    * 许龙全       1.0.0        20190325       对产品录入进行校验
    ******************************************************************************/
    
    V_BQLX NUMBER(8);
    V_BQMC VARCHAR2(200);
    V_COUNT VARCHAR2(200);
    V_COUNT1 VARCHAR2(200);
    
BEGIN
  O_CODE := 1;
  O_NOTE := '校验正确';
  
  IF I_LX=0 THEN
    DELETE PIF.LC_CPXZ_SDXJ_CPBQ WHERE LC_CPXZ_SDXJ_ID=I_ID;
    DELETE PIF.LC_CPXZ_SDXJ_SCHTSMJ_TCPFJB WHERE LC_CPXZ_SDXJ_ID=I_ID;
    DELETE PIF.LC_CPXZ_SDXJ_SCQTFJ_TCPFJB WHERE LC_CPXZ_SDXJ_ID=I_ID;
    DELETE PIF.LC_CPXZ_SDXj WHERE ID=I_ID;
    COMMIT;
  END IF;
  
  FOR X IN (SELECT a.* FROM PIF.LC_CPXZ_SDXJ_CPBQ a,PIF.LC_CPXZ_SDXJ b WHERE a.LC_CPXZ_SDXJ_ID=B.id and B.id=I_ID and b.cplx not in (100074,100073,100071)) LOOP
    
    SELECT COUNT(1)INTO V_COUNT FROM pif.LC_CPXZ_SDXJ_CPBQ A WHERE A.LC_CPXZ_SDXJ_ID=I_ID AND A.BQZBDXXZ IS NOT NULL;
     IF V_COUNT = 0 THEN
      O_CODE := -1;
      O_NOTE := '私募产品的产品标签为必填';
      RETURN;
    END IF;
  
   
  
  
    SELECT BQLX INTO V_BQLX FROM TPIF_BQZDB WHERE ID=X.BQMC;
    SELECT BQMC INTO V_BQMC FROM TPIF_BQZDB WHERE ID=X.BQMC;
    IF V_BQLX=1 AND X.BQZBDXXZ IS NOT NULL THEN
      O_CODE := -1;
      O_NOTE := V_BQMC||'：标签类型为单选，不能填写不定项选择。';
      RETURN;
    END IF;
    
    IF V_BQLX=2 AND X.BQZDX IS NOT NULL THEN
      O_CODE := -1;
      O_NOTE := V_BQMC||'：标签类型为不定项选择，不能填写单选。';
      RETURN;
    END IF;
    
    IF X.BQZBDXXZ IS NULL AND X.BQZDX IS NULL THEN
      O_CODE := -1;
      O_NOTE := V_BQMC||':标签为必填项，请填写完整。';
      RETURN;
    END IF;
  END LOOP;
  
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
  ROLLBACK;
END PRO_CHECK_CPLRJY;
/

