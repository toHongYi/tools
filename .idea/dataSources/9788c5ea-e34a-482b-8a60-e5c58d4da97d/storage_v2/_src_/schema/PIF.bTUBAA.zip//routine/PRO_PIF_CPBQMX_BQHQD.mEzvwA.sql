create procedure PRO_PIF_CPBQMX_BQHQD(O_CODE           OUT NUMBER,
                                                 O_NOTE           OUT VARCHAR2,
                                                 I_TPIF_CPBQMX_ID IN NUMBER, --获取表格内容，无实际意义
                                                 I_CPID           IN NUMBER, --产品id，给这个产品打标签
                                                 I_USERID         IN NUMBER --用户id
                                                 ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品标签明细----新增标签 表格形式 所用过程
  
      表格需要一个父对象id，明确是哪条记录的表格内容，此处为自由操作的新增，
      实际上这个表格并不属于任何记录，所以取了一个临时的记录id，即入参
      I_TPIF_CPBQMX_ID =( select min(id) from pif.TPIF_CPBQMX )，
  
      每次都清空表格TPIF_CPBQMX_BQHQD，该表格仅作为中间表插入数据用
  
      语法信息：
           输入参数：
  
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-04-26     1.0.0    gk                  XIN ZENG
  ***********************************************************************/
  V_COUNT NUMBER := 0;
  V_BQMC  VARCHAR2(200);

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  FOR CUR IN (SELECT CPBQ, QD
                FROM TPIF_CPBQMX_BQHQD
               WHERE TPIF_CPBQMX_ID = I_TPIF_CPBQMX_ID) LOOP
  
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPBQMX
     WHERE CPID = I_CPID
       AND CPBQ = CUR.CPBQ;
  
    IF V_COUNT > 0 THEN
      SELECT MC INTO V_BQMC FROM TPIF_CPBQ WHERE ID = CUR.CPBQ;
      O_NOTE := '标签:【' || V_BQMC || '】已存在，请检查！';
      O_CODE := -1;
      RETURN;
    ELSE
      INSERT INTO TPIF_CPBQMX
        (ID, CPBQ, CPID, YSLY, CZSJ, CZR, QD)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPBQMX'),
         CUR.CPBQ,
         I_CPID,
         2,
         SYSDATE,
         I_USERID,
         CUR.QD);
    END IF;
  END LOOP;

  COMMIT;
  O_CODE := 199;
  O_NOTE := '新增成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

