create PROCEDURE pcx_pif_wdgl_zxsc(O_CODE   OUT NUMBER,
                                                    O_NOTE   OUT VARCHAR2,
                                                    O_RESULT OUT SYS_REFCURSOR,
                                                    I_CURRENT         IN NUMBER, --页码
                                                    I_PAGESIZE        IN NUMBER, --页长
                                                    I_PAGING          IN NUMBER, --是否分页
                                                    I_SORT            IN VARCHAR2, --排序规模
                                                    I_TOTAL           IN OUT NUMBER, --记录总数
                                                    I_USERID          IN NUMBER --登陆用户ID

) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：产品中心

           功能说明：文档管理-最新上传文档查询


               参数说明：
                    入参：
                          I_USERID   IN  NUMBER     --登陆用户ID

                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,
                          O_RESULT OUT   SYS_REFCURSOR,



          ----------------------------------------------------------
          操作人       版本号      时间                        操作
          WUJINFENG    1.0        2020/06/29                  新增
    -------------------------------------------------------------------------------------------------*/
  V_SQL          VARCHAR2(8000);
  V_SORT         VARCHAR2(200);
  V_COLLIST      VARCHAR2(500);
  V_HASRECORDSET NUMBER;
  V_PARAMVALUE   VARCHAR2(200);

BEGIN
  O_CODE         := 1;
  O_NOTE         := '成功!';
  V_HASRECORDSET := 1;
  I_TOTAL        := -1;
  V_SORT         := I_SORT;



  IF I_USERID IS NULL  THEN
      O_CODE := -1;
      O_NOTE := 'I_USERID不能为空!';
      RETURN;
  END IF;
    /*ID  文档ID
      DOC_TYPE  文档类型
      DOC_TYPE_DESC 文档类型描述
      OBJ_NAME  产品名称/机构名称
      DOC_NAME  文档名称
      DOC_URL 文档存储路径
      DOC_SIZE  文档大小
      VERSION_NUM 版本号
      UPLOAD_PERSON 上传人员
      UPLOAD_DATE 上传日期
      DOWNLOAD_TIMES  文档下载次数
      */

  SELECT PARAMVALUE INTO V_PARAMVALUE FROM LIVEBOS.TSYSPARAM WHERE PARAMNAME='document-path';

  V_SQL := ' SELECT ROW_NUMBER() OVER( ORDER BY SCRQ DESC) AS RNN,
                    case when A.GLFJID is null then A.ID else A.GLFJID end as ID,
                    A.WDFL AS DOC_TYPE,
                    (SELECT NAME FROM TPIF_CPWDFL WHERE ID=A.WDFL) AS DOC_TYPE_DESC,
                    case when A.GLLX=1 THEN (SELECT CPMC||''(''||CPDM||'')'' FROM TPIF_CPDM WHERE ID=A.GLID)
                                   ELSE  (SELECT JGMC||''(''||JGDM||'')'' FROM TPIF_JGDM WHERE ID=A.GLID)  END AS OBJ_NAME,';

  V_SQL := V_SQL || ' A.WDMC AS DOC_NAME,'''||  V_PARAMVALUE ||'TPIF_CPWDK/''||A.ID||''.FJ''  AS DOC_URL,'
                 || ' A.WJDX/1024/1024 AS doc_size,'
                 || ' A.BBH AS version_num,'
                 || '(SELECT NAME FROM LIVEBOS.TUSER WHERE ID=A.SCRY) AS upload_person,'
                 || ' A.SCRQ AS upload_date,'
                 || ' (SELECT COUNT(*) FROM TPIF_WDXZRZ WHERE WDID=A.ID) AS download_times '
                 || ' FROM PIF.TPIF_CPWDK A WHERE 1=1 ';

 

  V_SQL := V_SQL || ' AND A.SFYX = 1 '  ;
  
  --20210923 文档权限（1总部，2内部，3公开）
  V_SQL := V_SQL || ' AND (EXISTS (SELECT 1 FROM PIF.TPIF_CPWDFL WHERE ID=A.WDFL AND WDQX<>1)
    OR NOT EXISTS(SELECT 1 FROM LIVEBOS.LBORGANIZATION WHERE ID=(SELECT ORGID FROM LIVEBOS.TUSER WHERE ID='|| I_USERID ||') START WITH NAME=''分支机构'' CONNECT BY PRIOR ID=FID))';
       
  V_SQL := 'SELECT id,doc_type,doc_type_desc,obj_name,doc_name,doc_url,doc_size,version_num,upload_person,upload_date,download_times
                     FROM (  '||V_SQL||') WHERE RNN <=100 ';


  IF  V_SORT IS NULL THEN
     V_SORT := ' id DESC,doc_type DESC';
  END IF ;

DBMS_OUTPUT.put_line(V_SQL);
  V_COLLIST := 'id,doc_type,doc_type_desc,obj_name,doc_name,doc_url,doc_size,version_num,upload_person,upload_date,download_times';

  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);



EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;
        OPEN O_RESULT FOR
            SELECT O_NOTE FROM DUAL;

END ;
/

