create PROCEDURE PRO_PIF_BQLX(O_CODE OUT NUMBER, --返回值
                                         O_NOTE OUT VARCHAR2, --返回消息
                                         I_USER IN INTEGER, --操作人
                                         I_IP   IN VARCHAR2, --操作IP
                                         I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                                         I_ID   IN INTEGER --操作ID
                                         ) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品类型管理
      语法信息：
           输入参数：I_USER IN INTEGER, --操作人
                     I_IP   IN VARCHAR2, --操作IP
                     I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;
                     I_ID   IN INTEGER, --操作ID
                     I_OP   IN VARCHAR2 := '' --其他
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-06-19     V1.0.1    涂孟               新增
          2021-7-13       1.0.2    GAOKUN           修改错误，补充内容
  ***********************************************************************/
  V_COUNT INTEGER; --计数变量
  V_OBJ   TPIF_BQLX%ROWTYPE; --表单记录
  V_CZBM  VARCHAR2(200); --操作编码
  V_CZSM  VARCHAR2(2000); --日志操作明细
  V_QXBZ  INTEGER; --权限标识

  V_BM   VARCHAR2(30); --编码
  V_FJSZ NUMBER := 2; --标签编码如果重复，加上该字符继续判断是否重复
  V_CSBM VARCHAR2(30); -- 初始编码，重复则在此编码上加数字

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  BEGIN
    SELECT * INTO V_OBJ FROM TPIF_BQLX WHERE ID = I_ID;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  SELECT DECODE(I_OPER, 0, '101101', 1, '101102', 2, '101103', '0')
    INTO V_CZBM
    FROM DUAL;

  SELECT '[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除', '') || '标签类型]_' ||
         V_OBJ.NAME
    INTO V_CZSM
    FROM DUAL;

  --CHECK
  /*  SELECT PIF.FUNC_PIF_HQGLYQXBZ(I_USER) INTO V_QXBZ FROM DUAL;
  IF V_QXBZ = 0 THEN
    O_NOTE := '系统禁止管理员操作!';
    RETURN;
  END IF;*/
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;

  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --//:新增-----------------------------------------------------------------------
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE NAME = V_OBJ.NAME;
    IF V_COUNT > 1 THEN
      O_NOTE := '不允许存在重复的[标签类型]--' || V_OBJ.NAME || '!';
      RETURN;
    END IF;
  
    IF V_OBJ.BQLXBM IS NOT NULL THEN
      --如果输入了标签类型编码
    
      --判断是否包含中文
      SELECT COUNT(1)
        INTO V_COUNT
        FROM DUAL
       WHERE LENGTH(V_OBJ.BQLXBM) = LENGTHB(V_OBJ.BQLXBM);
      IF V_COUNT = 0 THEN
        O_NOTE := '标签类型编码中包含中文，请检查！';
        RETURN;
      END IF;
    
      --判断是否重复
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_BQLX
       WHERE BQLXBM = V_OBJ.BQLXBM;
      IF V_COUNT > 1 THEN
        O_NOTE := '不允许存在重复的[标签类型编码]--' || V_OBJ.BQLXBM || '!';
        RETURN;
      END IF;
    
    ELSE
      --如果标签类型编码为空，则自动生成
    
      SELECT LIVEBOS.FUNC_PINYIN(V_OBJ.NAME)
        INTO V_BM
        FROM TPIF_BQLX
       WHERE ID = I_ID;
    
      V_CSBM := V_BM;
      SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE BQLXBM = V_BM;
      WHILE V_COUNT > 0 LOOP
        V_BM   := V_CSBM || V_FJSZ;
        V_FJSZ := V_FJSZ + 1;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE BQLXBM = V_BM;
      END LOOP;
    
      UPDATE TPIF_BQLX SET BQLXBM = V_BM WHERE ID = I_ID;
    END IF;
  
  END IF;

  IF I_OPER = 1 THEN
    --修改-----------------------------------------------------------------------
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE NAME = V_OBJ.NAME;
    IF V_COUNT > 1 THEN
      O_NOTE := '不允许存在重复的[标签类型]--' || V_OBJ.NAME || '!';
      RETURN;
    END IF;
    IF I_IP = '[CHECK]' THEN
      O_CODE := 1;
      O_NOTE := '';
      RETURN;
    END IF;
  
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE TYPE = 1; --查询根节点
    IF V_COUNT = 0 THEN
      O_NOTE := '不允许没有根节点!';
      RETURN;
    ELSIF V_COUNT > 1 THEN
      O_NOTE := '不允许有多个根节点!';
      RETURN;
    END IF;
  
    IF V_OBJ.TYPE = 2 THEN
      --如果修改为末节点，需要检查是否合理
      SELECT COUNT(1) INTO V_COUNT FROM TPIF_BQLX WHERE FID = I_ID;
      IF V_COUNT > 0 THEN
        O_NOTE := '该节点下还有子节点，因此无法修改为末节点!';
        RETURN;
      END IF;
    END IF;
  
    IF V_OBJ.TYPE = 0 THEN
      --如果修改为普通节点，需要检查该标签类型下是否有产品标签，末节点才能新增产品标签
      SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPBQ WHERE BQLX = I_ID;
      IF V_COUNT > 0 THEN
        O_NOTE := '该标签类型下存在产品标签，请检查！';
        RETURN;
      END IF;
    END IF;
  
  END IF;
  IF I_OPER = 2 THEN
    --删除-----------------------------------------------------------------------
    IF I_IP = '[CHECK]' THEN
      O_CODE := 1;
      O_NOTE := '';
      RETURN;
    END IF;
  
    V_COUNT := 0;
    --查询该节点或子节点下始有由产品标签
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPBQ
     WHERE BQLX IN (SELECT ID
                      FROM TPIF_BQLX
                     START WITH ID = I_ID
                    CONNECT BY PRIOR ID = FID);
    IF V_COUNT > 0 THEN
      O_NOTE := '该节点或该节点的子节点存在产品标签，请检查！';
      RETURN;
    END IF;
  
    DELETE FROM TPIF_BQLX --删除该节点及下属的全部节点
     WHERE ID IN (SELECT ID
                    FROM TPIF_BQLX
                   START WITH ID = I_ID
                  CONNECT BY PRIOR ID = FID);
  END IF;

  --RECORD
  O_NOTE := '记录日志';
  PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
  IF O_CODE < 0 THEN
    RETURN;
  ELSE
    O_CODE := -1;
    O_NOTE := '';
  END IF;

  O_CODE := 199;
  SELECT '执行[' || DECODE(I_OPER, 0, '新增', 1, '修改', 2, '删除') || ']成功!'
    INTO O_NOTE
    FROM DUAL;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_BQLX;
/

