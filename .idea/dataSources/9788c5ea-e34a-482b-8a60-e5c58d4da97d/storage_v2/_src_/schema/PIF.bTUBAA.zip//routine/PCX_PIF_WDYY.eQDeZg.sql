create PROCEDURE PCX_PIF_WDYY(O_CODE          OUT NUMBER, --返回值
                                         O_NOTE          OUT VARCHAR2, --返回消息
                                         O_RESULT        OUT SYS_REFCURSOR, --返回结果集
                                         i_current     IN Number , --页码   
                                         i_pageSize    IN  Number,  --页长 
                                         i_paging      IN  Number,  --是否分页 
                                         i_sort        IN  String,  --排序规模 
                                         i_total       IN OUT   Number,  --记录总数 
                                         i_userid      IN  Number   --登陆用户ID
                                        
                                         ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：获取首页我的应用
      语法信息：
           输入参数：   i_userid     IN INTEGER --用户ID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
                        O_RESULT OUT TYPES.CURSORTYPE, --返回结果集
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    陈勇军                创建
  ***********************************************************************/
  V_COUNT        INTEGER;
  V_SQL          VARCHAR2(2000);
  V_COLIST       VARCHAR2(2000);
  V_SORT         VARCHAR2(2000);
  v_HASRECORDSET number;
BEGIN
  --init
  O_CODE          := 1;
  O_NOTE          := '成功';
  IF i_total IS NULL THEN
        i_total := -1;
  END IF;
  V_SORT := I_SORT;
  --check
  SELECT COUNT(1)
    INTO V_COUNT
    FROM TPIF_YHKJCZCD XZ, TPIF_KJCZCD CZ
   WHERE XZ.KJCZCD = CZ.ID
     AND USERID = i_userid;
  IF V_COUNT > 0 THEN
    --用户存在已设置的配置
    V_SQL := 'SELECT CZ.ID as ID,
                     CZ.CDMC as menu_name,
                     CZ.CDFL as menu_class,
                     CZ.URL as menu_url,
                     CZ.SFMR as is_default,
                     NVL2(CZ.XSTB, 1, 0) display_icon,
                     CZ.XGRQ as modify_date,
                     CZ.DKLX as open_type,
                     CZ.XSMC as display_name
              FROM TPIF_YHKJCZCD XZ, TPIF_KJCZCD CZ
             WHERE XZ.KJCZCD = CZ.ID
               AND USERID = ' || i_userid;
  
  ELSE
    --用户不存在配置则返回默认配置
    V_SQL := 'SELECT CZ.ID as ID,
                     CZ.CDMC as menu_name,
                     CZ.CDFL as menu_class,
                     CZ.URL as menu_url,
                     CZ.SFMR as is_default,
                     NVL2(CZ.XSTB, 1, 0) display_icon,
                     CZ.XGRQ as modify_date,
                     CZ.DKLX as open_type,
                     CZ.XSMC as display_name
              FROM TPIF_KJCZCD CZ
             WHERE CZ.SFMR = 1';
  END IF;
  V_COLIST := 'ID,menu_name,menu_class,menu_url,is_default,display_icon,modify_date,open_type,display_name';
  IF V_SORT IS NULL THEN
    V_SORT := ' ID ASC ';
  END IF;
  --RETURN
  --是否返回结果集
  v_HASRECORDSET := 1;
  --调用分页查询
  PCX_TYCX(O_CODE,
           O_NOTE,
           v_HASRECORDSET,
           O_RESULT,
           i_paging,
           i_current,
           i_pageSize,
           i_total,
           SQLS            => V_SQL,
           COLLIST         => V_COLIST,
           HASWHERE        => TRUE,
           GROUPISLAST     => TRUE,
           I_SORT          => V_SORT, --至多一条，强制不排序
           I_HASWITH       => FALSE);
  O_CODE := 1;
  O_NOTE := '成功!';
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
END PCX_PIF_WDYY;
/

