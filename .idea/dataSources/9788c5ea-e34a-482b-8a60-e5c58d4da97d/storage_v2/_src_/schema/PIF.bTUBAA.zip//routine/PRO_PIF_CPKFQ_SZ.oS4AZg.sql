create PROCEDURE PRO_PIF_CPKFQ_SZ(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_USER IN INTEGER, --操作人
                                                 I_IP   IN VARCHAR2, --操作IP
                                                 I_OPER IN INTEGER, --操作类型  0:产品开放期计算;
                                                 I_ID   IN INTEGER, --产品ID
                                                 I_KFLX IN NUMBER---开放类型
                                                 ) IS
                                                 
  /*
  **功能说明：产品开放期设置
  **创建人：  wujinfeng
  **创建日期：2016-04-05
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **wujinfeng     1.0.1     2016-04-05    创建
  **tianhaonan    1.0.2     2020-02-27    新增每六月规则，申购赎回拆分
  */
  V_COUNT INTEGER; --计数变量
  V_OBJ   TPIF_CPKFQ_SZ%ROWTYPE; --表单记录

  V_KSRQ  NUMBER;
  V_JSRQ  NUMBER;
  V_CLRQ  NUMBER;


  V_KFQSRQ NUMBER; --开放起始日期  成立日期+封闭期 的第一天

  V_MONTH NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --CHECK
  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  IF I_OPER = 0 THEN
    --产品开放期计算;
  
    --单只产品开放期计算
    
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM TPIF_CPDM A
       WHERE A.CPID = I_ID
         AND A.CLRQ IS NULL;
      IF V_COUNT > 0 THEN
        O_NOTE := '系统异常:产品成立日为空!';
        RETURN;
      END IF;
    
/*      SELECT COUNT(*)
        INTO V_COUNT
        FROM TPIF_CPDM A
       WHERE A.CPID = I_ID
         AND A.Cpnbzt <> 8;
      IF V_COUNT > 0 THEN
        O_NOTE := '系统异常:产品未上柜!';
        RETURN;
      END IF;*/
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM TPIF_CPKFQ_SZ A
       WHERE A.CPID = I_ID
         AND A.ZT = 1;
      IF V_COUNT <= 0 THEN
        O_NOTE := '系统异常:未进行产品开放期设置或者设置的产品开放期未启用!';
        RETURN;
      END IF;
    
      /* 1 每月开放
         2 每3月开放
         3 每月第几周星期几开放
         4 每6月开放
      */
    
      SELECT * INTO V_OBJ FROM TPIF_CPKFQ_SZ A WHERE A.CPID = I_ID AND A.KFLX=I_KFLX;
      SELECT CLRQ INTO V_CLRQ FROM TPIF_CPDM A WHERE A.CPID = I_ID;
    
      /************************申赎开放期计算**************************************************/

      --获取开放申赎起始日期  = 成立日期 + 申购封闭期
      SELECT TO_CHAR((CASE
                       WHEN V_OBJ.FBQ_DW_SH = 0 THEN
                        ADD_MONTHS(TO_DATE(V_CLRQ, 'YYYYMMDD'), V_OBJ.FBYS_SH)
                       ELSE
                        TO_DATE(V_CLRQ, 'YYYYMMDD') + V_OBJ.FBYS_SH
                     END),
                     'YYYYMMDD')
        INTO V_KFQSRQ
        FROM DUAL;
    
      --如果上次计算的申赎结束日期小于当前日期时才需要重新更新申购开始和结束日期
               
     IF V_OBJ.KFLX_SH = 1 THEN 
            ---每月开放
          --计算到本年末  
          V_MONTH := GREATEST( to_char(sysdate, 'yyyymm') ,SUBSTR(V_KFQSRQ,1,6));
          
          WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP

            
              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                           AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE SUBSTR(JYR,1,6) = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
          IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
            V_MONTH := V_MONTH + 1 ;
          
           END LOOP ;
          END IF;
          
      --每3个月
      IF V_OBJ.KFLX_SH = 2 THEN 
     --SCKFYF
        --计算到本年末  
        V_MONTH :=  TO_CHAR(SYSDATE, 'YYYY')|| SUBSTR(100+V_OBJ.SCKFYF,2) ;
        WHILE V_MONTH < SUBSTR(V_KFQSRQ,1,6) LOOP
            V_MONTH := TO_CHAR(ADD_MONTHS(TO_DATE(V_MONTH,'YYYYMM'),3),'YYYYMM');
        END LOOP ;
          
        WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP
          
            
              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                           AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE SUBSTR(JYR,1,6) = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
            IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
             V_MONTH := V_MONTH + 3 ;
        END LOOP ;
        
     
      END IF;
          
       --每月第M个周N开放
      IF V_OBJ.KFLX_SH = 3 THEN 
          --计算到本年末  
          V_MONTH := GREATEST( to_char(sysdate, 'yyyymm') ,SUBSTR(V_KFQSRQ,1,6));
          
          WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP

                --算开始日期
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_CHAR(TO_DATE(A.ZRR,'YYYYMMDD'),'W') = V_OBJ.M
                           AND A.XQ = V_OBJ.XQXZ_SH
                           AND A.NY = V_MONTH);

            
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
            IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
             V_MONTH := V_MONTH + 1 ;
          
           END LOOP ;
         
             
      END IF;

      --每6个月
       IF V_OBJ.KFLX_SH =4 THEN 
     --SCKFYF
        --计算到本年末  
        V_MONTH :=  TO_CHAR(SYSDATE, 'YYYY')|| SUBSTR(100+V_OBJ.SCKFYF,2) ;
        WHILE V_MONTH < SUBSTR(V_KFQSRQ,1,6) LOOP
            V_MONTH := TO_CHAR(ADD_MONTHS(TO_DATE(V_MONTH,'YYYYMM'),6),'YYYYMM');
        END LOOP ;
          
        WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP
          
            
              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                           AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE SUBSTR(JYR,1,6) = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
            IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        I_ID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = I_ID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
             V_MONTH := V_MONTH + 6 ;
        END LOOP ;
        
     
      END IF;
  
  
  ELSE
     --产品开放期批量计算
           FOR CUR_CPDM IN( SELECT A.CPID,A.CLRQ,B.KFLX FROM TPIF_CPDM A,TPIF_CPKFQ_SZ B WHERE A.Cpnbzt = 8 AND A.CLRQ > 0 
                                    AND( EXISTS(SELECT 1 FROM TPIF_CPKFQ_SZ B WHERE B.CPID = A.CPID AND B.ZT=1) OR EXISTS(SELECT 1 FROM TPIF_LSKFQ_SZ C WHERE C.CPID = A.CPID) )
                                    AND A.CPID=B.CPID
                          ) LOOP

              SELECT * INTO V_OBJ FROM  TPIF_CPKFQ_SZ A WHERE A.CPID = CUR_CPDM.CPID AND A.KFLX=CUR_CPDM.KFLX;
              SELECT CLRQ INTO V_CLRQ FROM TPIF_CPDM A WHERE A.CPID = CUR_CPDM.CPID;
              --V_CLRQ := CUR_CPDM.CPID ;
     /************************申赎批量开放期计算**************************************************/
     --获取开放申赎起始日期  = 成立日期 + 申购封闭期
      SELECT TO_CHAR((CASE
                       WHEN V_OBJ.FBQ_DW_SH = 0 THEN
                        ADD_MONTHS(TO_DATE(V_CLRQ, 'YYYYMMDD'), V_OBJ.FBYS_SH)
                       ELSE
                        TO_DATE(V_CLRQ, 'YYYYMMDD') + V_OBJ.FBYS_SH
                     END),
                     'YYYYMMDD')
        INTO V_KFQSRQ
        FROM DUAL;
      
    
      --如果上次计算的申赎结束日期小于当前日期时才需要重新更新申购开始和结束日期
               
     IF V_OBJ.KFLX_SH = 1 THEN 
            ---每月开放
          --计算到本年末  
          V_MONTH := GREATEST( to_char(sysdate, 'yyyymm') ,SUBSTR(V_KFQSRQ,1,6));
          
          WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP

              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                            AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE A.NY = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
             IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
             V_MONTH := V_MONTH + 1 ;
          
           END LOOP ;
          END IF;
          
      --每3个月
      IF V_OBJ.KFLX_SH = 2 THEN 
     --SCKFYF
        --计算到本年末  
        V_MONTH :=  TO_CHAR(SYSDATE, 'YYYY')|| SUBSTR(100+V_OBJ.SCKFYF,2) ;
        WHILE V_MONTH < SUBSTR(V_KFQSRQ,1,6) LOOP
            V_MONTH := TO_CHAR(ADD_MONTHS(TO_DATE(V_MONTH,'YYYYMM'),3),'YYYYMM');
        END LOOP ;
          
        WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP
          
            
              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                           AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE SUBSTR(JYR,1,6) = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
 IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
        
             V_MONTH := V_MONTH + 3 ;
        END LOOP ;
        
     
      END IF;
          
       --每月第M个周N开放
      IF V_OBJ.KFLX_SH = 3 THEN 
          --计算到本年末  
          V_MONTH := GREATEST( to_char(sysdate, 'yyyymm') ,SUBSTR(V_KFQSRQ,1,6));
          
          WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP

                --算开始日期
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_CHAR(TO_DATE(A.ZRR,'YYYYMMDD'),'W') = V_OBJ.M
                           AND A.XQ = V_OBJ.XQXZ_SH
                           AND A.NY = V_MONTH);

            
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
             IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;

             V_MONTH := V_MONTH + 1 ;
          
           END LOOP ;
         
             
      END IF;

      IF V_OBJ.KFLX_SH =4 THEN 
     --SCKFYF
        --计算到本年末  
        V_MONTH :=  TO_CHAR(SYSDATE, 'YYYY')|| SUBSTR(100+V_OBJ.SCKFYF,2) ;
        WHILE V_MONTH < SUBSTR(V_KFQSRQ,1,6) LOOP
            V_MONTH := TO_CHAR(ADD_MONTHS(TO_DATE(V_MONTH,'YYYYMM'),6),'YYYYMM');
        END LOOP ;
          
        WHILE V_MONTH <= to_number(to_char(sysdate, 'yyyy')||'12')  LOOP
          
            
              IF V_OBJ.AYXZ_SH = 0 THEN
                ---按日期
              
                SELECT MIN(JYR)
                  INTO V_KSRQ
                  FROM livebos.TXTJYR B
                 WHERE B.JYR >=
                       (SELECT MIN(ZRR)
                          FROM livebos.TXTJYR A
                         WHERE A.ZRR >= V_KFQSRQ
                           AND TO_NUMBER(SUBSTR(A.ZRR, -2)) = V_OBJ.SCKFR_SH
                           AND A.NY = V_MONTH);
              
              ELSE
                --按交易日
                BEGIN
                
                  SELECT JYR
                    INTO V_KSRQ
                    FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                            FROM (SELECT DISTINCT JYR
                                    FROM livebos.TXTJYR A
                                   WHERE SUBSTR(JYR,1,6) = V_MONTH))
                   WHERE ID = V_OBJ.DJGXYR_SH;
    
                EXCEPTION
                  WHEN OTHERS THEN
                    --IF V_KSRQ IS NULL THEN --未找到第几个交易日时，用当月最后一个交易日
                    SELECT MAX(JYR)
                      INTO V_KSRQ
                      FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                              FROM (SELECT DISTINCT JYR
                                      FROM livebos.TXTJYR A
                                     WHERE SUBSTR(JYR,1,6) = V_MONTH));
                END;
            END IF;
            SELECT JYR
              INTO V_JSRQ
              FROM (SELECT JYR, RANK() OVER(ORDER BY JYR ASC) ID
                      FROM (SELECT DISTINCT JYR
                              FROM (SELECT JYR
                                      FROM livebos.TXTJYR B
                                     WHERE B.JYR >=V_KSRQ
                                            )))
             WHERE ID = V_OBJ.KFTS_SH;
          
            IF V_OBJ.KFLX = 1 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=2 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 2 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        3,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=3 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
          IF V_OBJ.KFLX = 3 THEN
            IF V_KSRQ > 0 AND V_JSRQ > 0 THEN
              --更新表 【TPIF_CPDM_GL_QX】
                INSERT INTO TPIF_CPDM_GL_QX
                  (ID, CPID, JYQX, KSRQ, JSRQ)
                SELECT  livebos.FUNC_NEXTID('TPIF_CPDM_GL_QX'),
                        V_OBJ.CPID,
                        2,
                        JYR,
                        JYR
                FROM (SELECT  DISTINCT 
                        JYR
                 FROM livebos.TXTJYR A 
                 WHERE A.JYR >= V_KSRQ 
                   AND A.JYR <= V_JSRQ 
                   AND A.ND = TO_CHAR(SYSDATE,'YYYY')) M
                WHERE NOT EXISTS(SELECT 1 FROM TPIF_CPDM_GL_QX C WHERE C.CPID = V_OBJ.CPID AND C.JYQX=4 AND C.KSRQ = M.JYR )
                ORDER BY M.JYR ASC ;                

            END IF;
            END IF;
            
             V_MONTH := V_MONTH + 6 ;
        END LOOP ;
        
     
      END IF;
        
     END LOOP;
     END IF;

  COMMIT;
  --RETURN
  O_CODE := 199;
  SELECT DECODE(I_OPER, 0, 199, 1),
         '执行[' ||
         DECODE(I_OPER, 0, '产品开放期计算', '产品开放期批量计算') || ']成功!'
    INTO O_CODE，O_NOTE
    FROM DUAL;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
  
END;
/

