create PROCEDURE pcx_ProdContract(O_CODE          OUT NUMBER,
                                              O_NOTE          OUT VARCHAR2,
                                              O_RESULT        OUT SYS_REFCURSOR,
                                              I_PROD_CODE     IN VARCHAR2 --产品代码

                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：基金产品合同查询

      语法信息：
           输入参数：    I_PROD_CODE     IN VARCHAR2, --产品代码
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-05-20     1.0       CR              新增
  ***********************************************************************/
  CONST_JKDM CONSTANT VARCHAR2(100) DEFAULT UPPER('10000024');
  V_COUNT     NUMBER;
  V_JKLX      NUMBER;
BEGIN

  SELECT COUNT(*)
    INTO V_COUNT
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM
     AND A.STATUS = 1;
  IF V_COUNT <= 0 THEN
    O_CODE := 1002;
    O_NOTE := '接口【' || CONST_JKDM || '】不存在或未开启';
    GOTO BOTTOM;
  END IF;

  SELECT INTERFACE_TYPE
    INTO V_JKLX
    FROM TINTERFACE_DETAILS_CONFIG A
   WHERE A.INTERFACE_NO = CONST_JKDM;


  OPEN O_RESULT FOR
    SELECT COMP_ID, --公司ID
           COMPANY_NAME,  --公司名称
           PROVINCE, --省份
           CITY,  --城市
           ADDRESS,  --注册地址
           CHAIRMAN,  --法人代表
           REG_CAPITAL,   --注册资本
           FOUND_DATE,  --成立日期
           BRIEFING,   --公司简介
           COUNTRY,  --国籍
           BUST_SCOPE,  --经营范围
           COMPANY_TYPE,   --公司类别
           TOTAL_EMPLOYEES, --员工总数(人)
           MAIN_BUSINESS,  --主要产品及业务
           SOCIAL_CREDIT_CODE   --统一社会信用编码
        FROM(SELECT  B.COMP_ID AS COMP_ID, --公司ID
                     B.COMP_NAME AS COMPANY_NAME,  --公司名称
                     B.PROVINCE AS  PROVINCE, --省份
                     B.CITY AS CITY,  --城市
                     B.ADDRESS AS ADDRESS,  --注册地址
                     B.CHAIRMAN AS CHAIRMAN,  --法人代表
                     B.REGCAPITAL AS REG_CAPITAL,   --注册资本
                     B.FOUNDDATE AS FOUND_DATE,  --成立日期
                     B.BRIEFING AS BRIEFING,   --公司简介
                     B.COUNTRY AS COUNTRY,  --国籍
                     B.BUSINESSSCOPE AS BUST_SCOPE,  --经营范围
                     B.COMP_TYPE AS COMPANY_TYPE,   --公司类别
                     B.S_INFO_TOTALEMPLOYEES AS TOTAL_EMPLOYEES, --员工总数(人)
                     B.MAIN_BUSINESS AS MAIN_BUSINESS,  --主要产品及业务
                     B.SOCIAL_CREDIT_CODE AS SOCIAL_CREDIT_CODE   --统一社会信用编码
             FROM PIF.Chinamutualfunddescription A,PIF.Cfundintroduction B
             WHERE A.F_INFO_CORP_FUNDMANAGEMENTID = B.COMP_ID
             AND A.F_INFO_WINDCODE LIKE '%' ||I_PROD_CODE|| '%');

  O_CODE := 0;
  O_NOTE := '查询成功';

  <<BOTTOM>>

  IF O_CODE > 1000 THEN
    OPEN O_RESULT FOR
    SELECT NULL AS COMP_ID, --公司ID
           NULL AS COMPANY_NAME,  --公司名称
           NULL AS PROVINCE, --省份
           NULL AS CITY,  --城市
           NULL AS ADDRESS,  --注册地址
           NULL AS CHAIRMAN,  --法人代表
           NULL AS REG_CAPITAL,   --注册资本
           NULL AS FOUND_DATE,  --成立日期
           NULL AS BRIEFING,   --公司简介
           NULL AS COUNTRY,  --国籍
           NULL AS BUST_SCOPE,  --经营范围
           NULL AS COMPANY_TYPE,   --公司类别
           NULL AS TOTAL_EMPLOYEES, --员工总数(人)
           NULL AS MAIN_BUSINESS,  --主要产品及业务
           NULL AS SOCIAL_CREDIT_CODE   --统一社会信用编码
     FROM DUAL
     WHERE 1 = 2;
  END IF ;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 1005;
    O_NOTE := '程序错误:' || SQLERRM;
END;
/

