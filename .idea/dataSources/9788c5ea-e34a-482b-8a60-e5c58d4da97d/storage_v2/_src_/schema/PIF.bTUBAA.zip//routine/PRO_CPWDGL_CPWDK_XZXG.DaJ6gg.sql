create PROCEDURE PRO_CPWDGL_CPWDK_XZXG(O_CODE   OUT NUMBER,
                                                      O_NOTE   OUT VARCHAR2,
                                                      OLD_ID   IN NUMBER, --旧ID
                                                      NEW_ID   IN NUMBER, --新ID
                                                      I_BM     IN VARCHAR2, --编码
                                                      I_GLID   IN VARCHAR2, --产品ID
                                                      I_WDFL   IN NUMBER, --文档分类
                                                      I_CPWDMX IN NUMBER, --文档明细
                                                      I_WDMC   IN VARCHAR2, --文档名称
                                                      I_WDMS   IN VARCHAR2, --文档描述
                                                      I_FJ     IN VARCHAR2, --附件名称
                                                      I_WJDX   IN NUMBER, --文件大小
                                                      I_WDYSTJ IN NUMBER, --文档约束条件
                                                      I_SCRQ   IN NUMBER, --上传日期
                                                      I_XGRQ   IN NUMBER, --修改日期
                                                      I_SCRY   IN NUMBER, --上传人员
                                                      I_ZHXGR  IN NUMBER, --最后修改人
                                                      I_SFYX   IN NUMBER, --`是否有效
                                                      I_WDGS   IN NUMBER, --文档格式
                                                      I_IP     IN VARCHAR2, --操作IP
                                                      I_BZ     IN VARCHAR2, --备注
                                                      I_WDLY   IN NUMBER DEFAULT 10, --文档来源(10,11,12,13,14,20)
                                                      I_WBID   IN VARCHAR2 DEFAULT NULL, --外部ID
                                                      I_MBID   IN NUMBER DEFAULT NULL,
                                                      I_GLLX   IN NUMBER DEFAULT 1 --1|产品；2|机构；3|统计
                                                      ) AS

    /*--------------------------------------------------------------------------------------------

           项目名称：产品中心

           功能说明：修改和新增产品文档要素
               参数说明：
                    入参：
                    出参： O_CODE
                           O_NOTE
             数据源：PIF.TPIF_CPWDK

          ----------------------------------------------------------
          操作人     版本号     时间                       操作
          HOUJINBO              20170809                  修改：GLLX = 1的才更新 CPMC
          HOUJINBO              20170814                  修改：增加 GLLX 5 资管,6 非公募,7 公募 的更新
          sunyuanhe  V1.3       20171218                  修改：更新产品名称/项目名称时用 V_GLLX代替原来的I_GLLX
    -------------------------------------------------------------------------------------------------*/
    V_SCRQ   NUMBER(8);
    V_XGRQ   NUMBER(8);
    V_FBWDSL NUMBER(8); --1|单个；2|多个
    V_CNT    NUMBER(8); --记录条数
    V_BZ     VARCHAR2(500); --备注
    V_SCRY   NUMBER(16); --上传人员
    V_ZHXGR  NUMBER(16); --最后修改人
    V_BM     VARCHAR2(30); --编码
    V_WDYSTJ NUMBER(8); --文档约束条件
    V_WDLY   INTEGER DEFAULT I_WDLY; --文档来源
    V_GLLX   INTEGER DEFAULT I_GLLX;
    v_id     NUMBER(16);
    v_cpmc   VARCHAR2(300);
    v_code   VARCHAR2(30);

BEGIN
    O_CODE := 1;
    O_NOTE := '成功';

    IF NEW_ID IS NULL THEN
        O_CODE := -1;
        O_NOTE := '新记录ID不能为空！';
        RETURN;
    END IF;

    IF I_WDGS IS NULL THEN
        O_CODE := -1;
        O_NOTE := '文档格式不能为空！';
        RETURN;
    END IF;


 select prod_fullname,prod_code into v_cpmc ,v_code from pif.tprod_basic_info where id=I_GLID ;
    --文档约束条件对应权限
    IF I_WDYSTJ IS NULL THEN
        V_WDYSTJ := 1;
    ELSE
        V_WDYSTJ := I_WDYSTJ;
    END IF;

    IF I_GLLX IS NULL THEN
        V_GLLX := 1;
    ELSE
        V_GLLX := I_GLLX;
    END IF;

    IF I_SCRQ IS NULL THEN
        V_SCRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
    ELSE
        V_SCRQ := I_SCRQ;
    END IF;

    IF I_XGRQ IS NULL THEN
        V_XGRQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
    ELSE
        V_XGRQ := I_XGRQ;
    END IF;



    IF I_SCRY = -1 OR I_SCRY = -2 THEN
        V_SCRY := NULL;
    ELSE
        V_SCRY := I_SCRY;
    END IF;

    IF I_ZHXGR = -1 OR I_ZHXGR = -2 THEN
        V_ZHXGR := NULL;
    ELSE
        V_ZHXGR := I_ZHXGR;
    END IF;

    IF V_WDLY IS NULL THEN
        V_WDLY := 10;
    END IF;


    IF OLD_ID IS NULL THEN
        --新增文档

     
                --不存在此类型的文档，直接插入新纪录
                INSERT INTO pif.tprod_agreement
                    ( id                           ,
                      prod_id                   ,
                      agreement_name             ,
                      agreement_attachment        ,
                      agreement_content          ,
                      agreement_version          ,
                      agree_resourse_internal_addr ,
                      file_type                    ,
                      agreement_no                 ,
                      agree_resourse_external_addr ,
                      user_flag                    ,
                      register_date                ,
                      is_view                     ,
                      agreement_type              ,
                      image_str_address  )
                    SELECT NEW_ID ,
                           i_glid,
                           v_cpmc ||'基金概要',
                           I_FJ,
                           '',
                           substr(I_WDMC,-6,2),
                           '/202008/'||I_WDMC,
                           7,
                           v_code||substr(I_WDMC,-6,2),
                           'https://cpxy.dfzq.com.cn/202008/'||I_WDMC,
                           1,
                           (select to_number(to_char(sysdate,'yyyymmdd')) from dual),
                           0,
                           0,
                           ''

                      FROM DUAL;



    END IF;
/*delete from pif.tprod_agreement where id in (select c.id from (select id, a.rowid,a.prod_id from pif.tprod_agreement a ,

(select  a.prod_id,count(*) from pif.tprod_agreement a group by a.prod_id having count(*)>1) b where a.prod_id=b.prod_id and a.file_type=7 and

 a.id in (select max(id) from pif.tprod_agreement a group by a.prod_id  having count(*)>1)) c);*/

    COMMIT;
      O_CODE := 1;
    O_NOTE := '成功';
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -1;
        O_NOTE := '失败,' || SQLERRM;
        ROLLBACK;
END PRO_CPWDGL_CPWDK_XZXG;
/

