create PROCEDURE pcx_pif_rwgl_zrwcx(O_CODE   OUT NUMBER,
                                                O_NOTE   OUT VARCHAR2,
                                                O_RESULT OUT SYS_REFCURSOR,
                                                i_userid IN number, --用户id
                                                i_id in number--记录id
                                                ) AS
  /******************************************************************
  项目名称：产品中心-任务管理-任务详情-查询子任务信息
  所属用户：PIF
  概要说明：查询子任务信息
               i_userid       IN NUMBER, 用户id
               i_id           in NUMBER  记录id
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.

  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        任务详情-查询子任务信息

        1.任务详情-查询子任务信息

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/07/22     1.0.1     tumeng             新增.
  *********************************************************************************************************************/
  V_SQL_QUERY VARCHAR2(32767);
  V_ERRMSG    VARCHAR2(300); --错误信息
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF i_userid IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【用户ID】';
    RETURN;
  END IF;
  IF i_id IS NULL  THEN
    O_CODE := -1802;
    O_NOTE := '请输入的必填参数【记录id】';
    RETURN;
  END IF;

  --数据源赋值
  V_SQL_QUERY := 'select id as id,
                         rwbt as title,
                         rwnr as content,
                         rwksrq as startdate,
                         rwjzrq as enddate,
                         ZXRMC as exe_org_name,
                         zxr   as exe_org_id
                  from TPIF_RWFPXX t where frw =  '|| i_id;
  dbms_output.put_line(V_SQL_QUERY);
  OPEN O_RESULT FOR V_SQL_QUERY;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := ' 查询失败 ';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT ' 异常信息： ' || V_ERRMSG FROM DUAL;
END pcx_pif_rwgl_zrwcx;
/

