create PROCEDURE PRO_PIF_XSZC_CXXSFGMCPLS(O_CODE OUT NUMBER, --返回值
                                                         O_NOTE OUT VARCHAR2, --返回消息
                                                         I_USER IN INTEGER, --操作人
                                                         I_IP   IN VARCHAR2, --操作IP
                                                         I_OPER IN INTEGER, --操作类型0|修改；1|恢复销售
                                                         I_ID   IN INTEGER --操作ID
                                                         ) IS
    /*
    **功能说明：持续销售非金融产品历史管理
    **创建人： 陈勇军
    **创建日期：2017-06-14
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **
    */
    V_COUNT INTEGER; --计数变量
    V_OBJ   TPIF_XSZC_CXXSFGMCP_HIS%ROWTYPE; --表单记录
    V_CZBM VARCHAR2(200); --操作编码
    V_CZSM VARCHAR2(2000); --日志操作明细

BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_XSZC_CXXSFGMCP_HIS WHERE ID = I_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            O_NOTE := '未找到数据';
            RETURN;
    END;

    SELECT DECODE(I_OPER, 0, '400901', 1, '400902') INTO V_CZBM FROM DUAL;

    SELECT '[' || DECODE(I_OPER, 0, '修改', 1, '销售恢复') || ']_' || V_OBJ.CPMC
      INTO V_CZSM
      FROM DUAL;
    --CHECK
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;

    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN

        --//:修改
        IF V_OBJ.CPDM IS NULL THEN
            O_NOTE := '[产品编码]不允许为空!';
            RETURN;
        END IF;
        --判断是否有重复记录
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_XSZC_CXXSFGMCP_HIS
         WHERE CPDM = V_OBJ.CPDM;
        IF V_COUNT > 1 THEN
            O_NOTE := '[产品编码]为' || V_OBJ.CPDM || '记录已经存在，不允许重复添加！';
            RETURN;
        END IF;
        IF V_OBJ.CPMC IS NULL THEN
            O_NOTE := '[产品名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.FXDJ IS NULL THEN
            O_NOTE := '[风险等级]不允许为空!';
            RETURN;
        END IF;

    END IF;
    IF I_OPER = 1 THEN
        --//:销售恢复
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_XSZC_CXXSFGMCP WHERE ID = I_ID;
        IF V_COUNT > 0 THEN
            O_CODE := -1;
            O_NOTE := '该记录数已存在历史，请联系技术人员！';
            RETURN;
        END IF;
        INSERT INTO TPIF_XSZC_CXXSFGMCP
            (ID,
             CPDM,
             CPMC,
             FXDJ,
             JSSJ,
             YDSL,
             CPZL,
             CPBQ,
             CPBS,
             XSZC,
             ZLSBS,
             FBBS,
             CZR,
             FXSJ,
             DJSJ,
             ZSSX,
             FBRQ,
             KSRQ,
             JSRQ)
            SELECT M.ID,
                   M.CPDM,
                   M.CPMC,
                   M.FXDJ,
                   M.JSSJ,
                   M.YDSL,
                   M.CPZL,
                   M.CPBQ,
                   M.CPBS,
                   M.XSZC,
                   1,
                   M.FBBS,
                   I_USER,
                   M.FXSJ,
                   M.DJSJ,
                   (SELECT NVL(MAX(ZSSX), 0) + 1 FROM PIF.TPIF_XSZC_CXXSFGMCP) AS ZSSX,
                   M.FBRQ,
                   M.KSRQ,
                   M.JSRQ
              FROM TPIF_XSZC_CXXSFGMCP_HIS M
             WHERE M.ID = I_ID;
        UPDATE TPIF_XSZC_CXXSFGMCP T SET T.ZLSBS = 2 WHERE T.ID = I_ID;
        DELETE FROM TPIF_XSZC_CXXSFGMCP_HIS I WHERE I.ID = I_ID;
    END IF;

    --RECORD
    O_NOTE := '记录日志';
    PRO_PIF_CZRZ(O_CODE, O_NOTE, I_USER, I_IP, V_CZBM, V_OBJ.ID, V_CZSM);
    IF O_CODE < 0 THEN
        RETURN;
    ELSE
        O_CODE := -1;
        O_NOTE := '';
    END IF;
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER, 0, '修改', 1, '销售恢复') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_XSZC_CXXSFGMCPLS;
/

