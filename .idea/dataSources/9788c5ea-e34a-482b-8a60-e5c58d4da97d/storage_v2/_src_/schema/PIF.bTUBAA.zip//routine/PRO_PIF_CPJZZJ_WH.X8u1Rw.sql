create PROCEDURE PRO_PIF_CPJZZJ_WH(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2, --返回消息
                                              I_ID   IN INTEGER, --异常明细id
                                              I_TYPE IN INTEGER, --1|修正,2|通过,3|作废
                                              I_DWJZ IN NUMBER, --单位净值
                                              I_LJJZ IN NUMBER --累计净值
                                              ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品净值质检结果-维护
      语法信息：
           输入参数：I_ID IN INTEGER --TPIF_ZJJG_CPJZ_MX的id
                     I_TYPE IN INTEGER --1|修正,2|通过,3|作废
                     I_DWJZ IN NUMBER,    --单位净值
                     I_LJJZ IN NUMBER     --累计净值
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-07-13     1.0.1     HQN                新增
  ***********************************************************************/
  V_COUNT      INTEGER; --计数变量
  V_COUNT1     INTEGER; --计数变量1
  V_COUNT_NEXT NUMBER;
  V_CPID       NUMBER;
  V_CPDM       VARCHAR2(30);
  V_JZRQ       NUMBER;
  V_JYRQ       NUMBER;
  V_DWJZ       NUMBER(16, 4);
  V_LJJZ       NUMBER(16, 4);
  V_LASTJZRQ   NUMBER;
  V_NEXTJZRQ   NUMBER;
  V_LASTLJJZ   NUMBER(16, 4);
  V_NEXTLJJZ   NUMBER(16, 4);
  V_LASTDWJZ   NUMBER(16, 4);
  V_YJZRQ      NUMBER;
  V_YJYRQ      NUMBER;
  V_YDWJZ      NUMBER(16, 4);
  V_YLJJZ      NUMBER(16, 4);
  V_YZJJGID    NUMBER;
  V_ZJJGID     NUMBER;
  V_ZJJGID_1   NUMBER;
  V_ZXJZRQ     NUMBER; --最新净值日期
  V_JZYC       INTEGER;
  V_ZDFYC      INTEGER;
  V_YCXX       VARCHAR2(100);
  V_ZDF        NUMBER(16, 6);
  V_LJZRQ      NUMBER;
  V_LJYRQ      NUMBER;
  V_LDWJZ      NUMBER(16, 4);
  V_LLJJZ      NUMBER(16, 4);
  V_MXID       NUMBER; --明细id
  V_SF         NUMBER := 0;
  V_XDWJZ      NUMBER(16, 4);
  V_XLJJZ      NUMBER(16, 4);
  V_XJYRQ      NUMBER(16, 4);
  V_XJZRQ      NUMBER(16, 4);

BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '操作成功';
  --START

  --获取异常净值
  SELECT CPID, CPDM, JYRQ, JZRQ, DWJZ, LJJZ, ZJJGID
    INTO V_CPID, V_CPDM, V_JYRQ, V_JZRQ, V_DWJZ, V_LJJZ, V_ZJJGID_1
    FROM TPIF_ZJJG_CPJZ_MX
   WHERE ID = I_ID;

  IF I_TYPE = 1 OR I_TYPE = 2 THEN
    --修正
    IF I_TYPE = 1 THEN
      V_DWJZ := I_DWJZ;
      V_LJJZ := I_LJJZ;
    END IF;
    --更新明细同净值日期
    UPDATE TPIF_ZJJG_CPJZ_MX
       SET DWJZ = V_DWJZ, LJJZ = V_LJJZ
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ
       AND ZT < 2; --是否过滤已作废净值？

    --未处理净值置为通过
    UPDATE TPIF_ZJJG_CPJZ_MX
       SET ZT = 1
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ
       AND ZT = 0;

    --更新产品净值表
    UPDATE TPIF_CPJZ
       SET DWJZ = V_DWJZ, LJJZ = V_LJJZ
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ;

    --已通过的净值插入TPIF_CPJZ
    INSERT INTO TPIF_CPJZ
      (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM)
      SELECT SEQ_TPIF_CPJZ.NEXTVAL,
             CPID,
             JYRQ,
             JZRQ,
             V_DWJZ,
             V_LJJZ,
             5, --数据来源 5柜台
             1, --确认状态 1有效
             CPDM -- CPJZ表增加cpdm
        FROM (SELECT DISTINCT CPID, JYRQ, JZRQ, CPDM
                FROM TPIF_ZJJG_CPJZ_MX MX
               WHERE CPDM = V_CPDM
                 AND JZRQ = V_JZRQ
                 AND ZT = 1
                 AND NOT EXISTS (SELECT 1
                        FROM TPIF_CPJZ
                       WHERE CPDM = V_CPDM
                         AND JYRQ = MX.JYRQ) --重复交易日期忽略
              );

    -- 判断TPIF_CPJZXX_CPZX是否有净值记录
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPJZXX_CPZX
     WHERE CPID = V_CPID
       AND JZRQ = V_JZRQ;

    IF V_COUNT = 0 THEN
      INSERT INTO TPIF_CPJZXX_CPZX
        (CPID, JYRQ, JZRQ, DWJZ, LJJZ, CPDM ,SJLY)
      VALUES
        (V_CPID, V_JYRQ, V_JZRQ, V_DWJZ, V_LJJZ, V_CPDM ,5);
    ELSE
      UPDATE TPIF_CPJZXX_CPZX
         SET DWJZ = V_DWJZ, LJJZ = V_LJJZ
       WHERE CPID = V_CPID
         AND JZRQ = V_JZRQ;
    END IF;

    --更新日涨幅
    --是否存在上一个净值日期

    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPJZXX_CPZX
     WHERE CPID = V_CPID
       AND JZRQ < V_JZRQ;

    IF V_COUNT > 0 THEN
      SELECT JZRQ, LJJZ, DWJZ
        INTO V_LASTJZRQ, V_LASTLJJZ, V_LASTDWJZ
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = V_CPID
         AND JZRQ = (SELECT MAX(JZRQ)
                       FROM TPIF_CPJZ
                      WHERE CPID = V_CPID
                        AND JZRQ < V_JZRQ);

      UPDATE TPIF_CPJZXX_CPZX
         SET RZF = ROUND((V_LJJZ-V_LASTLJJZ)/V_LASTDWJZ, 6)
       WHERE CPID = V_CPID
         AND JZRQ = V_JZRQ;

    END IF;

    --是否存在下一个净值日期
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPJZXX_CPZX
     WHERE CPID = V_CPID
       AND JZRQ > V_JZRQ;

    IF V_COUNT > 0 THEN
      SELECT JZRQ, LJJZ
        INTO V_NEXTJZRQ, V_NEXTLJJZ
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = V_CPID
         AND JZRQ = (SELECT MIN(JZRQ)
                       FROM TPIF_CPJZ
                      WHERE CPID = V_CPID
                        AND JZRQ > V_JZRQ);

      UPDATE TPIF_CPJZXX_CPZX
         SET RZF = ROUND((V_NEXTLJJZ-V_LJJZ)/V_DWJZ, 6)
       WHERE CPID = V_CPID
         AND JZRQ = V_NEXTJZRQ;
    END IF;

    --获取产品最新净值日期
    SELECT MAX(JZRQ) INTO V_ZXJZRQ FROM TPIF_CPJZ WHERE CPID = V_CPID;
    IF V_ZXJZRQ <= V_JZRQ THEN
      V_ZXJZRQ := 99999999;
    END IF;

    V_YJZRQ   := V_JZRQ;
    V_YJYRQ   := V_JYRQ;
    V_YDWJZ   := V_DWJZ;
    V_YLJJZ   := V_LJJZ;
    V_YZJJGID := V_ZJJGID_1;

    --重新质检到最新净值日期
    FOR CUR_JZ IN (SELECT ID,
                          T.ZJJGID,
                          T.JYRQ,
                          T.JZRQ,
                          T.DWJZ,
                          T.LJJZ,
                          T.CPDM,
                          T.CPID
                     FROM TPIF_ZJJG_CPJZ_MX T
                    WHERE CPID = V_CPID
                      AND ZT = 0
                      AND JZRQ >= V_JZRQ
                      AND JZRQ < V_ZXJZRQ
                      AND EXISTS (SELECT 1
                             FROM TPIF_ZJJG_CPJZ
                            WHERE YCLB = 2
                              AND ID = T.ZJJGID)
                    ORDER BY JZRQ, JYRQ) LOOP

      V_YCXX  := '';
      V_JZYC  := 0;
      V_ZDFYC := 0;

      --1.净值是否为0
      IF CUR_JZ.DWJZ = 0 OR CUR_JZ.LJJZ = 0 THEN
        V_JZYC := 1;
        IF CUR_JZ.DWJZ = 0 THEN
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;
        IF CUR_JZ.LJJZ = 0 THEN
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_ZJJG_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ
           AND YCLB = 1;
        IF V_COUNT > 0 THEN
          SELECT ID
            INTO V_ZJJGID
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
        ELSE
          SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
          INSERT INTO TPIF_ZJJG_CPJZ
            (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
          VALUES
            (V_ZJJGID, CUR_JZ.CPID, CUR_JZ.CPDM, CUR_JZ.JZRQ, 0, 1, V_YCXX);
        END IF;
        --插入异常明细
        INSERT INTO TPIF_ZJJG_CPJZ_MX
          (ID,
           ZJJGID,
           CPID,
           CPDM,
           JYRQ,
           JZRQ,
           DWJZ,
           LJJZ,
           ZDF,
           CZR,
           ZT,
           CZSJ)
        VALUES
          (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
           V_ZJJGID,
           CUR_JZ.CPID,
           CUR_JZ.CPDM,
           CUR_JZ.JYRQ,
           CUR_JZ.JZRQ,
           CUR_JZ.DWJZ,
           CUR_JZ.LJJZ,
           NULL,
           0,
           0,
           SYSDATE);
        CONTINUE;
      END IF;

      --2.是否存在同净值日期净值不一致
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZ
       WHERE CPID = CUR_JZ.CPID
         AND JZRQ = CUR_JZ.JZRQ;

      --判断同净值日期净值是否一致
      IF V_COUNT > 0 AND CUR_JZ.ZJJGID != V_ZJJGID_1 THEN
        --对比净值
        SELECT DWJZ, LJJZ, JYRQ, JZRQ
          INTO V_XDWJZ, V_XLJJZ, V_XJYRQ, V_XJZRQ
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ
           AND ROWNUM = 1
         ORDER BY JYRQ DESC;
        IF V_XDWJZ != CUR_JZ.DWJZ THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '单位净值异常';
        END IF;

        IF V_XLJJZ != CUR_JZ.LJJZ THEN
          V_JZYC := 1;
          V_YCXX := V_YCXX || '累计净值异常';
        END IF;

        --存在净值异常插入质检结果表
        IF V_JZYC > 0 THEN

          --是否存在异常
          SELECT COUNT(1)
            INTO V_COUNT
            FROM TPIF_ZJJG_CPJZ
           WHERE CPID = CUR_JZ.CPID
             AND JZRQ = CUR_JZ.JZRQ
             AND YCLB = 1;
          IF V_COUNT > 0 THEN
            SELECT ID
              INTO V_ZJJGID
              FROM TPIF_ZJJG_CPJZ
             WHERE CPID = CUR_JZ.CPID
               AND JZRQ = CUR_JZ.JZRQ
               AND YCLB = 1;
            UPDATE TPIF_ZJJG_CPJZ SET CLZT = 0 WHERE ID = V_ZJJGID;
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
          ELSE
            SELECT SEQ_TPIF_ZJJG_CPJZ.NEXTVAL INTO V_ZJJGID FROM DUAL;
            INSERT INTO TPIF_ZJJG_CPJZ
              (ID, CPID, CPDM, JZRQ, CLZT, YCLB, YCXX)
            VALUES
              (V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JZRQ,
               0,
               1,
               V_YCXX);
            --插入异常明细
            INSERT INTO TPIF_ZJJG_CPJZ_MX
              (ID,
               ZJJGID,
               CPID,
               CPDM,
               JYRQ,
               JZRQ,
               DWJZ,
               LJJZ,
               ZDF,
               CZR,
               ZT,
               CZSJ)
            VALUES
              (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
               V_ZJJGID,
               CUR_JZ.CPID,
               CUR_JZ.CPDM,
               CUR_JZ.JYRQ,
               CUR_JZ.JZRQ,
               CUR_JZ.DWJZ,
               CUR_JZ.LJJZ,
               NULL,
               0,
               0,
               SYSDATE);
            --是否已存在异常明细
            SELECT COUNT(1)
              INTO V_COUNT
              FROM TPIF_ZJJG_CPJZ_MX
             WHERE ZJJGID = V_ZJJGID
               AND CPID = V_CPID
               AND JZRQ = V_XJZRQ
               AND JYRQ = V_XJYRQ;
            IF V_COUNT = 0 THEN
              INSERT INTO TPIF_ZJJG_CPJZ_MX
                (ID,
                 ZJJGID,
                 CPID,
                 CPDM,
                 JYRQ,
                 JZRQ,
                 DWJZ,
                 LJJZ,
                 ZDF,
                 CZR,
                 ZT,
                 CZSJ)
              VALUES
                (SEQ_TPIF_ZJJG_CPJZ_MX.NEXTVAL,
                 V_ZJJGID,
                 CUR_JZ.CPID,
                 CUR_JZ.CPDM,
                 V_XJYRQ,
                 V_XJZRQ,
                 V_XDWJZ,
                 V_XLJJZ,
                 NULL,
                 0,
                 0,
                 SYSDATE);
            END IF;
          END IF;
          CONTINUE;
        END IF;

      END IF;

      --相同净值日期不质检涨跌幅
      IF CUR_JZ.JZRQ = V_YJZRQ AND CUR_JZ.JYRQ != V_JYRQ AND V_SF = 1 THEN
        SELECT ID
          INTO V_MXID
          FROM TPIF_ZJJG_CPJZ_MX
         WHERE CPID = CUR_JZ.CPID
           AND ZJJGID = V_YZJJGID
           AND JZRQ != V_YJZRQ;

        UPDATE TPIF_ZJJG_CPJZ_MX
           SET (JYRQ, JZRQ, DWJZ, LJJZ, ZT) =
               (SELECT JYRQ, JZRQ, DWJZ, LJJZ, ZT
                  FROM TPIF_ZJJG_CPJZ_MX
                 WHERE ID = V_MXID)
         WHERE CPID = CUR_JZ.CPID
           AND ZJJGID = CUR_JZ.ZJJGID
           AND JZRQ != CUR_JZ.JZRQ;

        UPDATE TPIF_ZJJG_CPJZ_MX
           SET ZT = 1, ZDF = V_ZDF
         WHERE CPID = CUR_JZ.CPID
           AND ZJJGID = CUR_JZ.ZJJGID
           AND JZRQ = CUR_JZ.JZRQ;

        --插入TPIF_CPJZ
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JYRQ = CUR_JZ.JYRQ;
        IF V_COUNT = 0 THEN
          INSERT INTO TPIF_CPJZ
            (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM, RZF)
          VALUES
            (SEQ_TPIF_CPJZ.NEXTVAL,
             CUR_JZ.CPID,
             CUR_JZ.JYRQ,
             CUR_JZ.JZRQ,
             CUR_JZ.DWJZ,
             CUR_JZ.LJJZ,
             5, --数据来源 5柜台
             1, --确认状态 1有效
             CUR_JZ.CPDM,
             V_ZDF);
        END IF;
        CONTINUE;
      END IF;

      --是否存在涨跌幅异常
      V_ZDF := ROUND((CUR_JZ.LJJZ-V_YLJJZ)/V_YDWJZ, 6);
      IF V_ZDF > 0.15 OR V_ZDF < -0.15 THEN
        V_ZDFYC := 1;
        V_YCXX  := '涨跌幅异常';
        IF CUR_JZ.JZRQ != V_YJZRQ THEN

          UPDATE TPIF_ZJJG_CPJZ_MX
             SET JYRQ = V_YJYRQ,
                 JZRQ = V_YJZRQ,
                 DWJZ = V_YDWJZ,
                 LJJZ = V_YLJJZ,
                 ZT   = 0
           WHERE ZJJGID = CUR_JZ.ZJJGID
             AND JZRQ != CUR_JZ.JZRQ;

        END IF;

        UPDATE TPIF_ZJJG_CPJZ_MX
             SET ZDF = V_ZDF
           WHERE ZJJGID = CUR_JZ.ZJJGID
             AND JZRQ = CUR_JZ.JZRQ;

      --质检正常更新质检结果和净值
      ELSE
        UPDATE TPIF_ZJJG_CPJZ_MX
           SET ZT = 1, ZDF = V_ZDF
         WHERE ZJJGID = CUR_JZ.ZJJGID
           AND JZRQ = CUR_JZ.JZRQ;
        UPDATE TPIF_ZJJG_CPJZ_MX
           SET ZT   = 1,
               JYRQ = V_YJYRQ,
               JZRQ = V_YJZRQ,
               DWJZ = V_YDWJZ,
               LJJZ = V_YLJJZ
         WHERE ZJJGID = CUR_JZ.ZJJGID
           AND JZRQ != CUR_JZ.JZRQ;

        --插入TPIF_CPJZ
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPJZ
         WHERE CPID = CUR_JZ.CPID
           AND JYRQ = CUR_JZ.JYRQ;
        IF V_COUNT = 0 THEN
          INSERT INTO TPIF_CPJZ
            (ID, CPID, JYRQ, JZRQ, DWJZ, LJJZ, SJLY, QRZT, CPDM, RZF)
          VALUES
            (SEQ_TPIF_CPJZ.NEXTVAL,
             CUR_JZ.CPID,
             CUR_JZ.JYRQ,
             CUR_JZ.JZRQ,
             CUR_JZ.DWJZ,
             CUR_JZ.LJJZ,
             5, --数据来源 5柜台
             1, --确认状态 1有效
             CUR_JZ.CPDM,
             V_ZDF);
        END IF;

        --更新上一有效净值变量
        V_SF      := 1;
        V_YJYRQ   := CUR_JZ.JYRQ;
        V_YJZRQ   := CUR_JZ.JZRQ;
        V_YDWJZ   := CUR_JZ.DWJZ;
        V_YLJJZ   := CUR_JZ.LJJZ;
        V_YZJJGID := CUR_JZ.ZJJGID;

        -- 判断TPIF_CPJZXX_CPZX是否有净值记录
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = CUR_JZ.CPID
           AND JZRQ = CUR_JZ.JZRQ;

        IF V_COUNT > 0 THEN
          CONTINUE;
        ELSE
          INSERT INTO TPIF_CPJZXX_CPZX
            (CPID, JYRQ, JZRQ, DWJZ, LJJZ, CPDM, RZF ,SJLY)
          VALUES
            (CUR_JZ.CPID,
             CUR_JZ.JYRQ,
             CUR_JZ.JZRQ,
             CUR_JZ.DWJZ,
             CUR_JZ.LJJZ,
             CUR_JZ.CPDM,
             V_ZDF,
             5);
        END IF;
      END IF;

    END LOOP;

    --更新产品最新净值表TPIF_CPZXJZ
    MERGE INTO TPIF_CPZXJZ T1
    USING (SELECT X.CPID,
                  X.JYRQ,
                  X.JZRQ,
                  X.DWJZ,
                  X.LJJZ,
                  X.FQJZ,
                  X.NHSYL,
                  X.WFSYL,
                  X.RZF,
                  X.ZZF,
                  X.QRZT,
                  X.SJLY,
                  X.FBR,
                  X.NHSYL_D7,
                  X.CPDM
             FROM (SELECT A.CPID,
                          A.JYRQ,
                          A.JZRQ,
                          A.DWJZ,
                          A.LJJZ,
                          A.FQJZ,
                          A.NHSYL,
                          A.WFSYL,
                          A.RZF,
                          A.ZZF,
                          A.QRZT,
                          A.SJLY,
                          A.FBR,
                          A.NHSYL_D7,
                          A.CPDM
                     FROM TPIF_CPJZXX_CPZX A
                    WHERE A.CPID = V_CPID
                    ORDER BY JZRQ DESC, JYRQ DESC) X
            WHERE ROWNUM = 1) T2
    ON (T1.CPID = T2.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET T1.JYRQ     = T2.JYRQ,
             T1.JZRQ     = T2.JZRQ,
             T1.DWJZ     = T2.DWJZ,
             T1.LJJZ     = T2.LJJZ,
             T1.FQJZ     = T2.FQJZ,
             T1.NHSYL    = T2.NHSYL,
             T1.WFSYL    = T2.WFSYL,
             T1.RZF      = T2.RZF,
             T1.ZZF      = T2.ZZF,
             T1.QRZT     = T2.QRZT,
             T1.SJLY     = T2.SJLY,
             T1.FBR      = T2.FBR,
             T1.CZSJ     = SYSDATE,
             T1.NHSYL_D7 = T2.NHSYL_D7
    WHEN NOT MATCHED THEN
      INSERT
        (T1.ID,
         T1.CPID,
         T1.JYRQ,
         T1.JZRQ,
         T1.DWJZ,
         T1.LJJZ,
         T1.FQJZ,
         T1.NHSYL,
         T1.WFSYL,
         T1.RZF,
         T1.ZZF,
         T1.QRZT,
         T1.SJLY,
         T1.FBR,
         T1.CZSJ,
         T1.NHSYL_D7,
         T1.CPDM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPZXJZ'),
         T2.CPID,
         T2.JYRQ,
         T2.JZRQ,
         T2.DWJZ,
         T2.LJJZ,
         T2.FQJZ,
         T2.NHSYL,
         T2.WFSYL,
         T2.RZF,
         T2.ZZF,
         T2.QRZT,
         T2.SJLY,
         T2.FBR,
         SYSDATE,
         T2.NHSYL_D7,
         T2.CPDM);

    --更新TPIF_CPDM表净值信息
    MERGE INTO PIF.TPIF_CPDM M
    USING (SELECT CPID, JZRQ, DWJZ, LJJZ, NHSYL_D7, WFSYL
             FROM TPIF_CPZXJZ
            WHERE CPID = V_CPID) N
    ON (M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.JZRQ    = N.JZRQ,
             M.CPJZ    = N.DWJZ,
             M.LJJZ    = N.LJJZ,
             M.QRNHSYL = N.NHSYL_D7,
             M.WFSYL   = N.WFSYL;

  END IF;

  --作废
  IF I_TYPE = 3 THEN

    --同净值置为作废
    UPDATE TPIF_ZJJG_CPJZ_MX
       SET ZT = 2
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ
       AND DWJZ = V_DWJZ
       AND LJJZ = V_LJJZ; --是否过滤已通过净值

    --同净值日期同净值删除
    DELETE FROM TPIF_CPJZ
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ
       AND DWJZ = V_DWJZ
       AND LJJZ = V_LJJZ;

    --是否存在TPIF_CPJZXX_CPZX
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPJZXX_CPZX
     WHERE CPDM = V_CPDM
       AND JZRQ = V_JZRQ
       AND DWJZ = V_DWJZ
       AND LJJZ = V_LJJZ;

    IF V_COUNT > 0 THEN

      DELETE FROM TPIF_CPJZXX_CPZX
       WHERE CPID = V_CPID
         AND JZRQ = V_JZRQ
         AND DWJZ = V_DWJZ
         AND LJJZ = V_LJJZ;

      --若存在下一个净值日期，更新日涨幅
      SELECT COUNT(1)
        INTO V_COUNT
        FROM TPIF_CPJZXX_CPZX
       WHERE CPID = V_CPID
         AND JZRQ > V_JZRQ;

      IF V_COUNT > 0 THEN
        SELECT JZRQ, LJJZ
          INTO V_NEXTJZRQ, V_NEXTLJJZ
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = V_CPID
           AND JZRQ = (SELECT MIN(JZRQ)
                         FROM TPIF_CPJZ
                        WHERE CPID = V_CPID
                          AND JZRQ > V_JZRQ);

        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPJZXX_CPZX
         WHERE CPID = V_CPID
           AND JZRQ < V_JZRQ;

        IF V_COUNT > 0 THEN

          SELECT JZRQ, LJJZ ,DWJZ
            INTO V_LASTJZRQ, V_LASTLJJZ ,V_LASTDWJZ
            FROM TPIF_CPJZXX_CPZX
           WHERE CPID = V_CPID
             AND JZRQ = (SELECT MAX(JZRQ)
                           FROM TPIF_CPJZ
                          WHERE CPID = V_CPID
                            AND JZRQ < V_JZRQ);

          UPDATE TPIF_CPJZXX_CPZX
             SET RZF = ROUND((V_NEXTLJJZ - V_LASTLJJZ)/V_LASTDWJZ, 6)
           WHERE CPID = V_CPID
             AND JZRQ = V_NEXTJZRQ;
        ELSE
          UPDATE TPIF_CPJZXX_CPZX
             SET RZF = 0
           WHERE CPID = V_CPID
             AND JZRQ = V_NEXTJZRQ;
        END IF;
      END IF;
    END IF;
        --更新产品最新净值表TPIF_CPZXJZ
    MERGE INTO TPIF_CPZXJZ T1
    USING (SELECT X.CPID,
                  X.JYRQ,
                  X.JZRQ,
                  X.DWJZ,
                  X.LJJZ,
                  X.FQJZ,
                  X.NHSYL,
                  X.WFSYL,
                  X.RZF,
                  X.ZZF,
                  X.QRZT,
                  X.SJLY,
                  X.FBR,
                  X.NHSYL_D7,
                  X.CPDM
             FROM (SELECT A.CPID,
                          A.JYRQ,
                          A.JZRQ,
                          A.DWJZ,
                          A.LJJZ,
                          A.FQJZ,
                          A.NHSYL,
                          A.WFSYL,
                          A.RZF,
                          A.ZZF,
                          A.QRZT,
                          A.SJLY,
                          A.FBR,
                          A.NHSYL_D7,
                          A.CPDM
                     FROM TPIF_CPJZXX_CPZX A
                    WHERE A.CPID = V_CPID
                    ORDER BY JZRQ DESC, JYRQ DESC) X
            WHERE ROWNUM = 1) T2
    ON (T1.CPID = T2.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET T1.JYRQ     = T2.JYRQ,
             T1.JZRQ     = T2.JZRQ,
             T1.DWJZ     = T2.DWJZ,
             T1.LJJZ     = T2.LJJZ,
             T1.FQJZ     = T2.FQJZ,
             T1.NHSYL    = T2.NHSYL,
             T1.WFSYL    = T2.WFSYL,
             T1.RZF      = T2.RZF,
             T1.ZZF      = T2.ZZF,
             T1.QRZT     = T2.QRZT,
             T1.SJLY     = T2.SJLY,
             T1.FBR      = T2.FBR,
             T1.CZSJ     = SYSDATE,
             T1.NHSYL_D7 = T2.NHSYL_D7
    WHEN NOT MATCHED THEN
      INSERT
        (T1.ID,
         T1.CPID,
         T1.JYRQ,
         T1.JZRQ,
         T1.DWJZ,
         T1.LJJZ,
         T1.FQJZ,
         T1.NHSYL,
         T1.WFSYL,
         T1.RZF,
         T1.ZZF,
         T1.QRZT,
         T1.SJLY,
         T1.FBR,
         T1.CZSJ,
         T1.NHSYL_D7,
         T1.CPDM)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPZXJZ'),
         T2.CPID,
         T2.JYRQ,
         T2.JZRQ,
         T2.DWJZ,
         T2.LJJZ,
         T2.FQJZ,
         T2.NHSYL,
         T2.WFSYL,
         T2.RZF,
         T2.ZZF,
         T2.QRZT,
         T2.SJLY,
         T2.FBR,
         SYSDATE,
         T2.NHSYL_D7,
         T2.CPDM);

    --更新TPIF_CPDM表净值信息
    MERGE INTO PIF.TPIF_CPDM M
    USING (SELECT CPID, JZRQ, DWJZ, LJJZ, NHSYL_D7, WFSYL
             FROM TPIF_CPZXJZ
            WHERE CPID = V_CPID) N
    ON (M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.JZRQ    = N.JZRQ,
             M.CPJZ    = N.DWJZ,
             M.LJJZ    = N.LJJZ,
             M.QRNHSYL = N.NHSYL_D7,
             M.WFSYL   = N.WFSYL;
  END IF;

  --更新TPIF_CPJZ表RZF,用累计净值算
    MERGE INTO TPIF_CPJZ M
    USING (SELECT CPID,
                  JYRQ,
                  LJJZ,
                  LAG(LJJZ, 1, 0) OVER(PARTITION BY CPID ORDER BY JYRQ ASC) AS ZRLJJZ,
                  LAG(DWJZ, 1, 0) OVER(PARTITION BY CPID ORDER BY JYRQ ASC) AS ZRDWJZ
             FROM TPIF_CPJZ WHERE CPDM=V_CPDM) N
    ON (M.JYRQ = N.JYRQ AND M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.RZF = ROUND((CASE
                             WHEN N.ZRDWJZ = 0 THEN
                              0
                             ELSE
                              (N.LJJZ - N.ZRLJJZ) / N.ZRDWJZ
                           END),
                           6);

    --计算 TPIF_CPJZXX_CPZX 的RZF
    MERGE INTO TPIF_CPJZXX_CPZX M
    USING (SELECT A.CPID,
                  A.JZRQ,
                  A.LJJZ,
                  LAG(A.LJJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRLJJZ,
                  LAG(A.DWJZ, 1, 0) OVER(PARTITION BY A.CPID ORDER BY A.JZRQ ASC) AS ZRDWJZ
             FROM TPIF_CPJZXX_CPZX A WHERE CPDM=V_CPDM) N
    ON (M.JZRQ = N.JZRQ AND M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.RZF = ROUND((CASE
                             WHEN N.ZRDWJZ = 0 THEN
                              0
                             ELSE
                              (N.LJJZ - N.ZRLJJZ) / N.ZRDWJZ
                           END),
                           6);
  --更新已处理质检结果
  UPDATE TPIF_ZJJG_CPJZ T
     SET CLZT = 1
   WHERE CPDM = V_CPDM
     AND CLZT = 0
     AND NOT EXISTS (SELECT 1
            FROM TPIF_ZJJG_CPJZ_MX
           WHERE ZJJGID = T.ID
             AND ZT = 0);

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_CPJZZJ_WH;
/

