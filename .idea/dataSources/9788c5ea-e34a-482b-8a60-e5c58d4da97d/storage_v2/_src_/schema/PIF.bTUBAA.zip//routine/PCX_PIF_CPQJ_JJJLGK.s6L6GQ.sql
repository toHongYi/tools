create PROCEDURE PCX_PIF_CPQJ_JJJLGK(O_CODE            OUT NUMBER,
                                                O_NOTE            OUT VARCHAR2,
                                                O_RESULT          OUT SYS_REFCURSOR,
                                                I_USERID          IN NUMBER, --用户ID
                                                I_FUND_MAGAGER_NO IN VARCHAR2, --基金经理编号
                                                I_PROD_ID         IN NUMBER --产品ID
                                                ) AS
  /******************************************************************
  项目名称：产品中心-产品全景-查询基金经理概况
  所属用户：PIF
  概要说明：查询基金经理概况.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询基金经理概况.
        
        公募 聚源： 基金经理基本资料 TPIF_JJJLJBZL
                   基金与基金经理关联表 TPIF_JJYJJJLGLB
               
        私募 朝阳永续： 私募投资经理 TPIF_SMTZJL
                       基金与投资经理关联表 TPIF_JJYTZJLGLB 
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/04/27     1.0.0.1   TUMENG             新增
      20200716       1.1       WUJINFENG          修改
      20201118                 GAOKUN            根据财通的表进行修改
      2021-12-10     1.0.0.4   GAOKUN            根据财通的表进行修改
  ************************************************************************/
  V_SQL        VARCHAR2(4000);
  V_BEST_RATIO NUMBER; --最佳任期收益回报率(%)
  V_CYJY       NUMBER; --从业经验 年
  V_RQSC_N     NUMBER; --任期时长_年
  V_RQSC_T     NUMBER; --任期时长_天
  V_ZGM        NUMBER; --总管理规模(万元) 当前
  V_RZTS       NUMBER; --任职天数
  V_COUNT      NUMBER;
  V_CPLX       NUMBER; --产品类型
  V_CPDM       VARCHAR2(200); --根据入参 CPID 从产品代码表获取产品代码
  V_MAINCODE   VARCHAR2(200); --公募基金概况表的主代码
  V_FUND_ID    NUMBER; --朝阳永续市场私募基金ID
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_ID IS NULL THEN
    O_NOTE := '产品ID不允许为空！';
    RETURN;
  END IF;

  IF I_FUND_MAGAGER_NO IS NULL THEN
    O_NOTE := '基金经理编号不允许为空！';
    RETURN;
  END IF;

  BEGIN
    --获取产品类型，产品代码
    SELECT CPXL, TRIM(CPDM)
      INTO V_CPLX, V_CPDM
      FROM TPIF_CPDM
     WHERE CPID = I_PROD_ID;
  EXCEPTION
    --没查询到产品
    WHEN OTHERS THEN
      V_CPLX := -1;
      V_CPDM := '0';
  END;

  IF V_CPLX = 1 THEN
    --公募
    SELECT COUNT(1) --先根据SECUCODE判断是否有记录
      INTO V_COUNT
      FROM INFO.TINFO_JJGK
     WHERE SECUCODE = V_CPDM;
  
    IF V_COUNT > 0 THEN
      --有则取主代码
      SELECT MAINCODE
        INTO V_MAINCODE
        FROM INFO.TINFO_JJGK
       WHERE SECUCODE = V_CPDM;
    
    ELSE
      --没有则根据后端代码取
      BEGIN
        SELECT MAINCODE
          INTO V_MAINCODE
          FROM INFO.TINFO_JJGK
         WHERE APPLYINGCODEBACK = V_CPDM;
      EXCEPTION
        WHEN OTHERS THEN
          V_MAINCODE := '0';
      END;
    END IF;
  
    --获取 从业经验（投资年限）,总管理规模(万元) 当前
    SELECT CYNX, GLGM * 10000
      INTO V_CYJY, V_ZGM
      FROM TPIF_JJJLJBZL
     WHERE ID = I_FUND_MAGAGER_NO;
  
    IF V_CYJY IS NULL THEN
      V_CYJY := -1;
    END IF;
  
    IF V_ZGM IS NULL THEN
      V_ZGM := -1;
    END IF;
  
    --最佳任期收益回报率(%)
    SELECT MAX(RZQJJZZZL)
      INTO V_BEST_RATIO
      FROM TPIF_JJYJJJLGLB
     WHERE JJJLID = I_FUND_MAGAGER_NO;
  
    IF V_BEST_RATIO IS NULL THEN
      V_BEST_RATIO := -1;
    END IF;
  
    --获取该经理任职该产品的总天数
    --注意会出现同一个基金经理在两个时间段中管理基金，所以用SUM
    SELECT SUM(RZTS)
      INTO V_RZTS --可能为0或者NULL(为0可能是数据问题，测试环境存在任职天数=0的情况)
      FROM TPIF_JJYJJJLGLB
     WHERE JJDM = V_MAINCODE
       AND JJJLID = I_FUND_MAGAGER_NO;
  
    IF V_RZTS = 0 OR V_RZTS IS NULL THEN
      --如果为0或者NULL
      V_RQSC_T := -1;
      V_RQSC_N := -1;
    ELSE
      --获取任期时长_天（结束日期为空选SYSDATE）    2038取余365=213
      SELECT MOD(V_RZTS, 365) INTO V_RQSC_T FROM DUAL;
    
      --获取任期时长_年                            2038除以365,结果取整数部分=5
      SELECT TRUNC(V_RZTS / 365) INTO V_RQSC_N FROM DUAL;
      --2038天 = 5年213天    
    END IF;
  
    V_SQL := 'SELECT A.MC AS NAME,
                     A.XB AS SEX,
                     (SELECT B.NOTE FROM LIVEBOS.TXTDM B WHERE B.FLDM=''PIF_XLDM'' AND B.IBM=A.ZGXL) AS EDU,
                     A.GRJJ AS BRIEF_INTR,
                     NULL AS IMAGE,
                 (CASE WHEN ' || V_CYJY ||
             ' = -1 THEN NULL 
                 ELSE ''' || V_CYJY ||
             '年'' END) AS OCCUPATION_EXPERIENCE,
                 (CASE WHEN ' || V_RQSC_N || ' = -1 AND ' ||
             V_RQSC_T || ' = -1 THEN NULL
                 ELSE ''' || V_RQSC_N || '年' || V_RQSC_T ||
             '天'' END) AS ASSUME_OFFICE_DURATION,
              (CASE WHEN ' || V_ZGM ||
             ' = -1 THEN NULL 
              ELSE TO_CHAR(' || V_ZGM ||
             ',''FM99999990.0999'') END) AS TOTAL_SCALE,
              (CASE WHEN ' || V_BEST_RATIO ||
             ' = -1 THEN NULL 
              ELSE TO_CHAR(' || V_BEST_RATIO ||
             '*100,''FM9990.00'') END) AS BEST_PERIOD_PAYBACK_RATIO
            FROM TPIF_JJJLJBZL A
           WHERE A.ID = ' || I_FUND_MAGAGER_NO;
  
  ELSE
  
    BEGIN
      SELECT ID INTO V_FUND_ID FROM TPIF_SCSMJJXX WHERE REG_CODE = V_CPDM;
    EXCEPTION
      WHEN OTHERS THEN
        V_FUND_ID := 0;
    END;
  
    --获取从业经验（投资年限），总管理规模(万元) 当前
    SELECT INVESTMENT_YEARS, ASSET_MGT_SCALE / 10000
      INTO V_CYJY, V_ZGM
      FROM SRC_PIF.T_FUND_MANAGER
     WHERE USER_ID = I_FUND_MAGAGER_NO;
  
    IF V_CYJY IS NULL THEN
      V_CYJY := -1;
    END IF;
  
    IF V_ZGM IS NULL THEN
      V_ZGM := -1;
    END IF;
  
    --获取该经理任职该产品的总天数      
    SELECT SUM(TO_NUMBER(NVL(TO_DATE(TO_CHAR(A.END_DATE), 'YYYYMMDD'),
                             TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'),
                                     'YYYYMMDD')) -
                         TO_DATE(TO_CHAR(A.START_DATE), 'YYYYMMDD')))
      INTO V_RZTS
      FROM TPIF_JJYTZJLGLB A
     WHERE A.USER_ID = I_FUND_MAGAGER_NO
       AND A.FUND_ID = V_FUND_ID;
  
    IF V_RZTS = 0 OR V_RZTS IS NULL THEN
      V_RQSC_T := -1;
      V_RQSC_N := -1;
    ELSE
      --获取任期时长_天（结束日期为空选SYSDATE）    2038取余365=213
      SELECT MOD(V_RZTS, 365) INTO V_RQSC_T FROM DUAL;
    
      --获取任期时长_年                            2038除以365,结果取整数部分=5
      SELECT TRUNC(V_RZTS / 365) INTO V_RQSC_N FROM DUAL;
      --2038天 = 5年213天 
    END IF;
  
    V_SQL := ' SELECT A.XM AS NAME,
                      A.XB AS SEX,
                      (SELECT B.NOTE FROM LIVEBOS.TXTDM B WHERE B.FLDM=''PIF_XLDM'' AND B.IBM=A.XL) AS EDU,
                      A.JJ AS BRIEF_INTR,
                      NULL AS IMAGE,
                    (CASE WHEN ' || V_CYJY ||
             ' = -1 THEN NULL 
                    ELSE ''' || V_CYJY ||
             '年'' END) AS OCCUPATION_EXPERIENCE,
             (CASE WHEN ' || V_RQSC_N || ' = -1 AND ' ||
             V_RQSC_T || ' = -1 THEN NULL
             ELSE ''' || V_RQSC_N || '年' || V_RQSC_T ||
             '天'' END) AS ASSUME_OFFICE_DURATION,
             (CASE WHEN ' || V_ZGM ||
             ' = -1 THEN NULL
             ELSE TO_CHAR(' || V_ZGM ||
             ',''FM99999990.0999'') END) AS TOTAL_SCALE,
             NULL AS BEST_PERIOD_PAYBACK_RATIO
             FROM PIF.TPIF_SMTZJL A
             WHERE A.TZJLBH = ''' || I_FUND_MAGAGER_NO || '''';
  
  END IF;

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPQJ_JJJLGK;
/

