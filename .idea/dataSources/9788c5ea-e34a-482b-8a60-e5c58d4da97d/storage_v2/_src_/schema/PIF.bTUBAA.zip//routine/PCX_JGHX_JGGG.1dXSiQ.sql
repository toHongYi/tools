create PROCEDURE PCX_JGHX_JGGG (O_CODE OUT NUMBER,
                                           O_NOTE OUT VARCHAR2,
                                           O_RESULT OUT SYS_REFCURSOR,
                                           I_USERID IN NUMBER,   --用户ID
                                           I_ORGID IN NUMBER     --机构ID
                                           ) AS
/******************************************************************
  项目名称：财通证券运营展业平台-H5机构画像
  所属用户：PIF
  概要说明：机构高管信息查询

  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/17     1.0.0.1   GAOKUN            新增.
  ********************************************************************/

BEGIN
  O_CODE := 1;
  O_NOTE :='成功！';

  IF I_ORGID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '机构ID不允许为空！';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
    SELECT ORG_FULL_NAME, NAME, REGEXP_REPLACE(DUTY, ' +', '、') DUTY
      FROM SRC_PIF.T_FUND_ORG_EXECUTIVE_INFO
     WHERE ORG_ID = I_ORGID;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := 99;
    O_NOTE := '查询失败:' || SQLERRM;
END;
/

