create procedure     pcx_pif_jjgsqj_qxjj(o_code     out number,
                                                o_note     out varchar2,
                                                o_result   out sys_refcursor,
                                                I_CURRENT  IN NUMBER, --页码
                                                I_PAGESIZE IN NUMBER, --页长
                                                I_PAGING   IN NUMBER, --是否分页
                                                I_SORT     IN STRING, --排序规模
                                                I_TOTAL    IN OUT NUMBER, --记录总数
                                                I_USERID   in integer, --用户ID
                                                i_org_id   in number --机构ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-基金公司全景-旗下基金
  所属用户：PIF
  概要说明：查询基金公司旗下基金.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询旗下基金.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/06    1.0.0.1   陈云昊             新增.
  *********************************************************************************************************************/
  v_sql          varchar2(32767);
  v_collist      varchar2(32767);
  v_sort         varchar2(300);
  v_hasrecordset number;
begin

  --否则返回结果集合
  v_hasrecordset := 1;
  o_code         := 1;
  o_note         := '成功';
  if i_total is null then
    i_total := -1;
  end if;
  v_sort := i_sort;

  --条件检验
  if i_userid is null then
    o_code := -1;
    o_note := ' 用户ID不允许为空！';
    return;
  end if;
  if i_org_id is null then
    o_code := -1;
    o_note := '机构ID不允许为空！';
    return;
  end if;

  v_sql := ' SELECT t1.JYDM fund_code,
                    t1.JJMC fund_name,
                    decode(t1.JJLB,1101,''股票型'',1103,''混合型'',1105,''债券型'',1107,''保本型'',1109,''货币型'',1110,''QDII'',1199,''其他型'',''其他型'') fund_type,
                    to_char(t2.DWJZ,''fm99999999999999990.099999999'') unit_nav,
                    to_char(t2.JYYSYL,''fm99999999999999990.099999999'') yield_rate_month,
                    to_char(t2.JSYSYL,''fm99999999999999990.099999999'') yield_rate_quarter,
                    to_char(t2.JLYSYL,''fm99999999999999990.099999999'') yield_rate_halfyear,
                    to_char(t2.JYNSYL,''fm99999999999999990.099999999'') yield_rate_one_year
             FROM DSC_STAT.tpif_stat_jj t1,DSC_STAT.tpif_stat_jj_yjbx t2
             WHERE t1.id = t2.jjid
             AND t1.jjglr = ' || i_org_id;
 dbms_output.put_line(v_sql);
  if v_sort is null then
    v_sort := 'fund_code DESC';
  end if;

  v_collist := 'fund_code,fund_name,fund_type,unit_nav,yield_rate_month,yield_rate_quarter,yield_rate_halfyear,yield_rate_one_year';

  pcx_tycx(o_code,
           o_note,
           v_hasrecordset,
           o_result,
           i_paging,
           i_current,
           i_pagesize,
           i_total,
           sqls           => v_sql,
           collist        => v_collist,
           haswhere       => true,
           groupislast    => false,
           i_sort         => v_sort,
           i_haswith      => false);

exception
  when others then
    o_code := -1;
    o_note := '失败:' || sqlerrm;

end pcx_pif_jjgsqj_qxjj;
/

