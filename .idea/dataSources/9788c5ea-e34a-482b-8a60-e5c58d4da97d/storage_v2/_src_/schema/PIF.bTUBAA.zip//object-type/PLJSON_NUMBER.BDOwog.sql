create type pljson_number force under pljson_element
(
  num number,
  num_double binary_double, -- both num and num_double are set, there is never exception (until Oracle 12c)
  num_repr_number_p varchar2(1),
  num_repr_double_p varchar2(1),

  constructor function pljson_number(num number) return self as result,
  /* E.I.Sarmas (github.com/dsnz)   2016-11-03   support for binary_double numbers */
  constructor function pljson_number(num_double binary_double) return self as result,
  overriding member function is_number return boolean,
  overriding member function value_of(max_byte_size number default null, max_char_size number default null) return varchar2,

  overriding member function get_number return number,
  /* E.I.Sarmas (github.com/dsnz)   2016-11-03   support for binary_double numbers */
  overriding member function get_double return binary_double,

  /* E.I.Sarmas (github.com/dsnz)   2016-11-03   support for binary_double numbers, is_number is still true, extra info */
  /* return true if 'number' is representable by Oracle number */
  /** Private method for internal processing. */
  overriding member function is_number_repr_number return boolean,
  /* return true if 'number' is representable by Oracle binary_double */
  /** Private method for internal processing. */
  overriding member function is_number_repr_double return boolean,
  /* E.I.Sarmas (github.com/dsnz)   2016-11-03   support for binary_double numbers */
  -- set value for number from string representation; to replace to_number in pljson_parser
  -- can automatically decide and use binary_double if needed
  -- less confusing than new constructor with dummy argument for overloading
  -- centralized parse_number to use everywhere else and replace code in pljson_parser
  -- this procedure is meant to be used internally only
  -- procedure does not work correctly if called standalone in locales that
  -- use a character other than "." for decimal point
  member procedure parse_number(str varchar2),

  /* E.I.Sarmas (github.com/dsnz)   2016-12-01   support for binary_double numbers */
  -- this procedure is meant to be used internally only
  member function number_toString return varchar2
) not final

/

