create PROCEDURE PCX_PIF_YYGL_CPYYRL_CPXX(O_CODE   OUT NUMBER,
                                                     O_NOTE   OUT VARCHAR2,
                                                     O_RESULT OUT SYS_REFCURSOR,
                                                     I_CALENDAR_TYPE   IN NUMBER, --1|销售日历;2|运营日历；3|产品中心登入
                                                     I_QUERY_DATE     IN NUMBER, --查询日期
                                                     I_USERID  IN NUMBER := '', --登陆用户ID
                                                     I_PROD_CLASS IN VARCHAR2 := '' --产品分类
                                                     ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：运营管理产品日历_产品信息
      语法信息：
           输入参数：
           输出参数：   O_RESULT  返回结果
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    徐阳                创建
          2017-09-27     1.0.2    SYH                 增加 募集起始日期，募集结束日期，产品期限;日历类型=2时调整返回值
          2017-10-10     1.0.3    SYH                 修改：在售产品事件展示为募集起始、结束日期;筛选条件修改为事件开始事件和结束时间区间内
          2017-10-16     1.0.4    HOUJINBO            修改：收益率字段加条件 如果是浮动收益类产品。只有收益凭证展示。其他分类返回空
          2017-12-06     1.0.5    SYH                 修改: 增加按产品大类、产品期限(固定)、资管小集合靠前(浮动);新增COL7（创收率描述）、COL8（风险等级）两个出参
          2017-12-26     1.0.6    CYJ                 修改： 增加 0Q6026,0Q6036,0Q6068,0Q6069,0Q6096,0Q6097产品过滤条件
  ***********************************************************************/
  V_SQL VARCHAR2(8000);
  V_RQ  NUMBER(8);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_QUERY_DATE IS NULL THEN
    V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD'));
  ELSE
    V_RQ := I_QUERY_DATE;
  END IF;

  IF I_CALENDAR_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '日历类型不能为空!';
    RETURN;
  END IF;

  IF I_CALENDAR_TYPE = 2 THEN

      V_SQL := 'SELECT A.ID AS PROD_ID,
                       A.CPMC AS PROD_NAME,
                       A.CPDM AS PROD_CODE,
                       NVL((SELECT NAME FROM PIF.TPIF_JRCPFL WHERE ID=A.JRCPFL),''--'') AS PROD_TYPE,
                       NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=A.CPFXDJ),''--'')  PROD_RISK_LEVEL,
                       (CASE WHEN A.YQSYL IS NOT NULL THEN  TO_CHAR(A.YQSYL*100)  ELSE ''--'' END) EXPECTED_YIELD_RATE,
                       NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_JZJYCPZT'' AND IBM=A.CPJYZT),''--'') PROD_STATUS,
                       A.QTJE AS SUBSCRIBE_ORIGIN,
                       A.MJKSRQ AS SUBSCRIBE_BEGIN_DATE,
                       A.MJJSRQ AS SUBSCRIBE_END_DATE,
                       A.CLRQ AS ESTABLISH_DATE, 
                       A.DQRQ AS EXPIRE_DATE,
                       A.CPQX AS PROD_TERM,
                       NVL((SELECT NAME FROM PIF.TPIF_JRCPFL WHERE ID=A.JRCPFL),''--'') AS COL1,
                       ''[''||A.CPDM||'']''||A.CPMC  AS COL2,
                       NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPJD'' AND IBM=A.CPJD),''--'') AS COL3,
                       A.MJKSRQ AS COL4,
                       A.CLRQ   AS COL5,
                       A.DQRQ   AS COL6,
                       NVL(TO_CHAR(A.CPQX),''--'')   AS COL7,
                       NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=A.CPFXDJ),''--'') AS COL8,
                       B.CPSJLX AS PROD_EVENT_TYPE,
                       (SELECT LXMC FROM TPIF_CPSJLX WHERE ID=B.CPSJLX) EVENT_TYPE_NAME,
                       C.ZSSX AS DISPLAY_ORDER
                     FROM TPIF_CPDM A,TPIF_CPSJ B,TPIF_CPSJLX_RLZS C
                    WHERE A.ID=B.CPID
                      AND B.CPSJLX=C.CPSJLX
                      AND B.SFSX=1
                      AND TO_NUMBER(TO_CHAR(B.SJKSSJ,''YYYYMMDD'')) = ' || V_RQ || '
                     -- AND TO_NUMBER(TO_CHAR(B.SJKSSJ,''YYYYMMDD'')) <= ' || V_RQ || '
                     -- AND TO_NUMBER(TO_CHAR(B.SJJSSJ,''YYYYMMDD'') )>= ' || V_RQ || '
                      AND C.RLLX=' || I_CALENDAR_TYPE;

  ELSE

    V_SQL := 'SELECT A.ID AS PROD_ID,
                     A.CPMC AS PROD_NAME,
                     A.CPDM AS PROD_CODE,
                     NVL((SELECT NAME FROM PIF.TPIF_JRCPFL WHERE ID=A.JRCPFL),''--'') AS PROD_TYPE,
                     NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_CPFXDJ_CPZX'' AND IBM=A.CPFXDJ),''--'')  PROD_RISK_LEVEL,
                     (CASE WHEN A.YQSYL IS NOT NULL THEN  TO_CHAR(A.YQSYL*100)  ELSE ''--'' END) EXPECTED_YIELD_RATE,
                     NVL((SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_JZJYCPZT'' AND IBM=A.CPJYZT),''--'') PROD_STATUS,
                     A.QTJE AS SUBSCRIBE_ORIGIN,
                     A.MJKSRQ AS SUBSCRIBE_BEGIN_DATE,
                     A.MJJSRQ AS SUBSCRIBE_END_DATE,
                     A.CLRQ AS ESTABLISH_DATE, 
                     A.DQRQ AS EXPIRE_DATE,
                     A.CPQX AS PROD_TERM,
                     B.CPSJLX  AS PROD_EVENT_TYPE,
                     (SELECT LXMC FROM TPIF_CPSJLX WHERE ID=B.CPSJLX) EVENT_TYPE_NAME,
                     C.ZSSX AS DISPLAY_ORDER
                     FROM TPIF_CPDM A,TPIF_CPSJ B,TPIF_CPSJLX_RLZS C
                    WHERE A.ID=B.CPID
                      AND B.CPSJLX=C.CPSJLX
                      AND B.SFSX=1
                      AND TO_NUMBER(TO_CHAR(B.SJKSSJ,''YYYYMMDD'')) = ' || V_RQ || '
                     -- AND TO_NUMBER(TO_CHAR(B.SJKSSJ,''YYYYMMDD'')) <= ' || V_RQ || '
                     -- AND TO_NUMBER(TO_CHAR(B.SJJSSJ,''YYYYMMDD'') )>= ' || V_RQ || '
                      AND C.RLLX=' || I_CALENDAR_TYPE;

  END IF;

  IF I_PROD_CLASS IS NOT NULL THEN
    V_SQL := V_SQL || ' AND A.JRCPFL = ''' || I_PROD_CLASS || '''';
  END IF;

  V_SQL := V_SQL || ' ORDER BY  ZSSX ';
  
  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;

END PCX_PIF_YYGL_CPYYRL_CPXX;
/

