create PROCEDURE PRO_PIF_SMJGBMDTZLC( O_CODE     OUT NUMBER,   --返回值
                                               O_NOTE     OUT VARCHAR2, --返回消息

                                               I_OPER     IN INTEGER,   -- 1: 提交校验，2：发起申请   3：审核完成
                                               I_ID       IN VARCHAR2,    --对象ID或id串
                                               I_INSTID   IN NUMBER,
                                               I_USER     IN NUMBER
) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募机构白名单调整流程 后台处理逻辑
      语法信息：


      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-03-04     1.0.0     高昆                创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_IDS varchar2(2000);

  V_RCLX NUMBER;   --入池类型  1|观察名单;2|黑名单

BEGIN

  IF I_OPER IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'i_OPER不能为空!';
    RETURN;
  END IF;
  --1:提交校验

  --2：发起申请


  --3：审核完成  I_INSTID    IN NUMBER
  IF I_OPER = 3 THEN

    SELECT RCLX INTO V_RCLX FROM LC_SMJGBMDTZLC WHERE ID=I_INSTID;
    
    IF V_RCLX = 1 THEN   --1 入观察名单池
      FOR CUR_IN IN( SELECT * FROM LC_SMJGBMDTZLC_JGLB  A WHERE A.LC_SMJGBMDTZLC_ID = I_INSTID) LOOP
        
        IF CUR_IN.SFTG = 1 THEN   --通过则插入观察名单池，同时从白名单池删除
          
          INSERT INTO TPIF_SMJGGCMDC
            (id, jgid, yy, rcry, rcsj)
            SELECT LIVEBOS.FUNC_NEXTID('TPIF_SMJGGCMDC'),
                   CUR_IN.JGMC,
                   CUR_IN.YY,
                   I_USER,
                   SYSDATE
              FROM DUAL;
              
          --私募机构白名单池中删除该机构
          DELETE FROM TPIF_SMJGBMDC WHERE JGID=CUR_IN.JGMC;   
        END IF;   
      END LOOP;
     
    ELSE   --2 入黑名单池
      FOR CUR_IN IN( SELECT * FROM LC_SMJGBMDTZLC_JGLB  A WHERE A.LC_SMJGBMDTZLC_ID = I_INSTID) LOOP
       
        IF CUR_IN.SFTG = 1 THEN   --通过则插入黑名单池，同时从白名单池删除
     
          INSERT INTO TPIF_SMJGHMDC
            (id, jgid, yy, rcry, rcsj)
            SELECT LIVEBOS.FUNC_NEXTID('TPIF_SMJGHMDC'),
                   CUR_IN.JGMC,
                   CUR_IN.YY,
                   I_USER,
                   SYSDATE
              FROM DUAL;
          --私募机构白名单池中删除该机构
          DELETE FROM TPIF_SMJGBMDC WHERE JGID=CUR_IN.JGMC;       
        END IF;
      END LOOP;
       
    END IF;
  
  END IF;  
  
  --更新流程表状态
  UPDATE LC_SMJGBMDTZLC A SET A.SHZT = 2 ,A.WCRQ=TO_CHAR(SYSDATE,'YYYYMMDD') WHERE A.ID = I_INSTID ;

  COMMIT;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
    ROLLBACK;
END;
/

