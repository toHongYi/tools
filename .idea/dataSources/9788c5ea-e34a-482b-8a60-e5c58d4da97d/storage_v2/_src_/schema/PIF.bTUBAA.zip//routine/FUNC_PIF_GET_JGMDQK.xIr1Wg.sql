create FUNCTION FUNC_PIF_GET_JGMDQK(I_ORGID  IN NUMBER, --组织ID
                                               I_TYPE   IN NUMBER, --1|摸底数量,2|未完成,3|按时完成,4|延时完成
                                               I_ZXJSRQ IN NUMBER, --最小结束日期
                                               I_ZDJSRQ IN NUMBER --最大结束日期
                                               ) RETURN NUMBER IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算机构摸底情况
  
      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        韩乔楠   1.0.0        2021/12/08                新增
  --------------------------------------------------------------------------------*/
  V_COUNT  INTEGER; --计数
  V_RET    INTEGER;
  V_ZXJSRQ DATE;
  V_ZDJSRQ DATE;

BEGIN
  SELECT TO_DATE(TO_CHAR(NVL(I_ZXJSRQ, 19990101)), 'YYYYMMDD')
    INTO V_ZXJSRQ
    FROM DUAL;
  SELECT TO_DATE(TO_CHAR(NVL(I_ZDJSRQ, 20981231)), 'YYYYMMDD') + 1
    INTO V_ZDJSRQ
    FROM DUAL;

  IF I_TYPE = 1 THEN
    --1|摸底数量
    SELECT COUNT(DISTINCT B.ID)
      INTO V_RET
      FROM TPIF_MDKH A, TPIF_CPMD B
     WHERE A.MDID = B.ID
       AND A.FZJG = I_ORGID
       AND B.RWFP > 1
       AND B.MDJSSJ > V_ZXJSRQ
       AND B.MDJSSJ < V_ZDJSRQ;
  END IF;

  IF I_TYPE = 2 THEN
    --2|未完成 
    SELECT COUNT(DISTINCT B.ID)
      INTO V_RET
      FROM TPIF_MDKH A, TPIF_CPMD B
     WHERE A.MDID = B.ID
       AND A.FZJG = I_ORGID
       AND B.RWFP > 1
       AND B.MDJSSJ > V_ZXJSRQ
       AND B.MDJSSJ < V_ZDJSRQ
       AND A.WCZT = 0;
  END IF;

  IF I_TYPE = 3 THEN
    --3|按时完成 
    SELECT COUNT(DISTINCT B.ID)
      INTO V_RET
      FROM TPIF_MDKH A, TPIF_CPMD B
     WHERE A.MDID = B.ID
       AND A.FZJG = I_ORGID
       AND B.RWFP > 1
       AND B.MDJSSJ > V_ZXJSRQ
       AND B.MDJSSJ < V_ZDJSRQ
       AND NOT EXISTS (SELECT 1
              FROM TPIF_MDKH
             WHERE MDID = A.MDID
               AND FZJG = A.FZJG
               AND (WCZT = 0 OR WCSJ > B.MDJSSJ));
  END IF;

  IF I_TYPE = 4 THEN
    --4|延时完成 
    SELECT COUNT(DISTINCT B.ID)
      INTO V_RET
      FROM TPIF_MDKH A, TPIF_CPMD B
     WHERE A.MDID = B.ID
       AND A.FZJG = I_ORGID
       AND B.RWFP > 1
       AND B.MDJSSJ > V_ZXJSRQ
       AND B.MDJSSJ < V_ZDJSRQ
       AND EXISTS (SELECT 1
              FROM TPIF_MDKH
             WHERE MDID = A.MDID
               AND FZJG = A.FZJG
               AND WCSJ > B.MDJSSJ)
       AND NOT EXISTS (SELECT 1
              FROM TPIF_MDKH
             WHERE MDID = A.MDID
               AND FZJG = A.FZJG
               AND WCZT = 0);
  END IF;

  RETURN V_RET;

EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
/

