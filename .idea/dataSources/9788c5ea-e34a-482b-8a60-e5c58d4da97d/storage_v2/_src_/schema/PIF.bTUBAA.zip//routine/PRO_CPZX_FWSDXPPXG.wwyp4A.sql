create PROCEDURE     PRO_CPZX_FWSDXPPXG ( O_CODE   OUT NUMBER,
                                                     O_NOTE   OUT VARCHAR2,
                                                     I_ID     IN  NUMBER,
                                                     I_YWMC   IN VARCHAR2,
                                                     I_FXJB   IN NUMBER,--1|低风险等级;2|中低风险等级;3|中等风险等级;4|中高风险等级;5|高风险等级
                                                     I_TZQX   IN NUMBER,--1|短期(0-1年);2|中期(0-5年);3|长期(5年以上);0|全部
                                                     I_KTJB   IN NUMBER,--1|高风险承受等级;2|中高风险承受等级;3|中风险承受等级;4|中低风险承受等级;5|低风险承受等级;6|最低风险承受等级;99|全部;
                                                     I_TZPZ   IN  VARCHAR2--1|债券、货币市场基金、债券型基金或其他固定收益类产品;2|股票、混合型基金、偏股型基金、股票型基金等权益类投资产品;4|期货、融资融券等杠杆类产品;5|复杂金融产品;6|其他产品
                                                     )IS
/******************************************************************************
*
*项目名称：东方证券
*创建人员：张庆
*创建日期：20170629
*功能说明：修改服务适当性匹配数据
*
*------------------------------------------------------------------------------
*
*修改者        版本号        修改日期        说明
* 张庆         1.0.0         2017-06-29     创建
*徐宝华                      20170912        名称允许修改
******************************************************************************/
BEGIN

    UPDATE PIF.tRISKLEVEL_INVESTTERM_INFO SET  RISK_LEVEL=(CASE WHEN I_FXJB=1 THEN '00E'--低风险
                                      WHEN I_FXJB=2 THEN '00D'--中低风险
                                      WHEN I_FXJB=3 THEN '00C'--中风险
                                      WHEN I_FXJB=4 THEN '00B'--中高风险
                                      WHEN I_FXJB=5 THEN '00A'--高风险
                                      END),
                            INVEST_TERM=(CASE WHEN I_TZQX=0 THEN  '000'--0|全部
                                       WHEN I_TZQX=1 THEN  '001'--1|短期(0-1年)
                                       WHEN I_TZQX=2 THEN  '002'--2|中期(0-5年)
                                        WHEN I_TZQX=3 THEN  '003'--3|长期(5年以上)
                                        END),
                            OPEN_LEVEL=(CASE WHEN I_KTJB=1 THEN '001'--高风险承受等级
                                       WHEN I_KTJB=2 THEN '002'--中高风险承受等级
                                       WHEN I_KTJB=3 THEN '003'--中风险承受等级
                                       WHEN I_KTJB=4 THEN '004'--中低风险承受等级
                                       WHEN I_KTJB=5 THEN '005'--低风险承受等级
                                       WHEN I_KTJB=6 THEN '006'--最低风险承受等级
                                       WHEN I_KTJB=99 THEN '099'--全部;
                                       END),
                            BUSINESS_NAME=I_YWMC

                            WHERE ID=I_ID;
                            COMMIT;
     DELETE PIF.tINVEST_VARIETY_INFO WHERE ID=I_ID;
     COMMIT;
     INSERT INTO PIF.tINVEST_VARIETY_INFO
     (ID, BUSINESS_NAME, INVEST_VARIETY)
     SELECT I_ID,
            I_YWMC,
             TZPZ
     FROM
         （SELECT
            ('00'||NVL(REGEXP_SUBSTR(I_TZPZ, '[^;]+', 1, LEVEL, 'i'), 'NULL')) AS TZPZ
         FROM DUAL
       CONNECT BY LEVEL <= LENGTH(I_TZPZ) - LENGTH(REPLACE(I_TZPZ, ';', '')) + 1) ;
     COMMIT;
    UPDATE PIF.tBIZ_SERVICE_OTHER_INFO SET BUSINESS_NAME=I_YWMC WHERE ID=I_ID;
COMMIT;

EXCEPTION
      WHEN OTHERS THEN
      O_CODE:=-1;
      O_NOTE  :=SQLERRM;
      ROLLBACK;
END PRO_CPZX_FWSDXPPXG;
/

