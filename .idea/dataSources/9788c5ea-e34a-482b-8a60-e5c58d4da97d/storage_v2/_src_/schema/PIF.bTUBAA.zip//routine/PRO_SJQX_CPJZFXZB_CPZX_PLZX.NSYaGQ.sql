create PROCEDURE PRO_SJQX_CPJZFXZB_CPZX_PLZX(O_CODE OUT NUMBER,
                                                        O_NOTE OUT VARCHAR2,
                                                        I_RQ   IN NUMBER --计算日期
                                                        ) AS

  /******************************************************************
      所属用户：PIF
      功能说明：批量执行-产品中心-数据清洗逻辑
      
          循环每个产品，调用指标计算过程
              
      语法信息：
           输入参数：    见参数定义
           输出参数：    O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
           修订日期        版本号     修订人             修改内容简要说明
          2021-8-3         1.0.0     GAOKUN               新增
  ***********************************************************************/

  V_CODE NUMBER;
  V_NOTE VARCHAR2(500);
  V_CPDM VARCHAR2(500);
BEGIN
  O_CODE := -1;
  O_NOTE := '';

  --循环，计算每个产品的指标
  FOR CUR_CP IN (SELECT DISTINCT CPDM FROM TPIF_CPZXJZ) LOOP
    PRO_SJQX_CPJZFXZB_CPZX(V_CODE, V_NOTE, I_RQ, I_RQ, CUR_CP.CPDM);
    IF V_CODE = -1 THEN
      V_CPDM := CUR_CP.CPDM;
      O_NOTE := V_NOTE || '，出错产品：' || V_CPDM;
      RETURN;
    END IF;
  END LOOP;

  --历史表---->最新表
  PRO_SJQX_ZXFXZB_CPZX(V_CODE, V_NOTE);
  IF V_CODE = -1 THEN
    O_NOTE := V_NOTE;
    RETURN;
  END IF;

  COMMIT;
  O_CODE := 1;
  O_NOTE := '成功！';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '批量执行指标清洗,未知错误'
                ELSE
                 '批量执行指标清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

