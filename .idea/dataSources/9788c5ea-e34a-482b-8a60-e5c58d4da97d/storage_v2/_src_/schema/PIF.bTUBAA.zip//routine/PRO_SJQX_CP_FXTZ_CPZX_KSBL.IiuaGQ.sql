create PROCEDURE PRO_SJQX_CP_FXTZ_CPZX_KSBL(O_CODE OUT NUMBER, --返回值
                                                       O_NOTE OUT VARCHAR2, --返回消息
                                                       I_RQ   IN NUMBER, --统计日期
                                                       I_JSRQ IN NUMBER  --统计区间结束日期 
                                                       ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品风险特征-亏损比率计算
      语法信息：
  
          此处收益率取周收益率
  
           输入参数：   I_RQ    日期
           输出参数：   O_CODE  返回值
                       O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-01-13     1.0       吴金锋              创建
  ***********************************************************************/
  V_RQ      NUMBER;
  V_RQ_3Y   NUMBER; -- 近3月
  V_RQ_6Y   NUMBER; -- 近6月
  V_RQ_1N   NUMBER; -- 近1年
  V_RQ_3N   NUMBER; -- 近3年
  V_RQ_5N   NUMBER; -- 近5年
  V_RQ_JNYL NUMBER; -- 今年以来
  V_RQ_CLYL NUMBER; -- 成立以来

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_RQ   := I_JSRQ;

  -- 近3月
  SELECT JYR
    INTO V_RQ_3Y
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -3), 'YYYYMMDD');

  -- 近6月
  SELECT JYR
    INTO V_RQ_6Y
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -6), 'YYYYMMDD');

  -- 近1年
  SELECT JYR
    INTO V_RQ_1N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -12), 'YYYYMMDD');

  -- 近3年
  SELECT JYR
    INTO V_RQ_3N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -36), 'YYYYMMDD');

  -- 近5年
  SELECT JYR
    INTO V_RQ_5N
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR =
         TO_CHAR(ADD_MONTHS(TO_DATE(V_RQ, 'YYYYMMDD'), -60), 'YYYYMMDD');

  -- 今年以来
  SELECT JYR
    INTO V_RQ_JNYL
    FROM LIVEBOS.TXTJYR A
   WHERE A.ZRR = TO_NUMBER(SUBSTR(V_RQ, 1, 4) || '0101');

  --插入到临时表 TEMP_STAT_CP_FXTZ

  FOR CUR_ZXJZ IN (SELECT CPID, JZRQ, JYRQ, DWJZ
                     FROM TEMP_TPIF_CPJZ
                    WHERE JYRQ = I_RQ) LOOP
    --V_RQ_CLYL NUMBER;  -- 成立以来
    SELECT MIN(JZRQ)
      INTO V_RQ_CLYL
      FROM TEMP_TPIF_CPJZ
     WHERE CPID = CUR_ZXJZ.CPID;
  
    INSERT INTO TEMP_STAT_CP_FXTZ
      (RQ,
       CPID,
       JZRQ,
       JYRQ,
       DWJZ,
       KSBL_3Y,
       KSBL_6Y,
       KSBL_1N,
       KSBL_3N,
       KSBL_5N,
       KSBL_CLYL,
       KSBL_JNYL)
    
      SELECT V_RQ,
             CUR_ZXJZ.CPID,
             CUR_ZXJZ.JZRQ,
             CUR_ZXJZ.JYRQ,
             CUR_ZXJZ.DWJZ, --20210129 结果*100，字段加%
             (CASE
               WHEN NVL(A.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((A.FZ / A.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(B.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((B.FZ / B.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(C.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((C.FZ / C.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(D.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((D.FZ / D.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(E.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((E.FZ / E.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(F.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((F.FZ / F.FM) * 100, 6)
             END),
             (CASE
               WHEN NVL(G.FM, 0) = 0 THEN
                0
               ELSE
                ROUND((G.FZ / G.FM) * 100, 6)
             END)
      
        FROM (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_3Y, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) A,
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_6Y, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) B,
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_1N, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) C,
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_3N, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) D,
             
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_5N, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) E,
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_CLYL, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) F,
             
             (SELECT CPID,
                     SUM(CASE
                           WHEN RZF < 0 THEN
                            1
                           ELSE
                            0
                         END) AS FZ,
                     COUNT(1) AS FM
                FROM PIF.TEMP_TPIF_CPJZXX
               WHERE CPID = CUR_ZXJZ.CPID
                 AND JZRQ >= GREATEST(V_RQ_JNYL, V_RQ_CLYL)
                 AND JZRQ <= V_RQ
               GROUP BY CPID) G
       WHERE A.CPID = B.CPID(+)
         AND A.CPID = C.CPID(+)
         AND A.CPID = D.CPID(+)
         AND A.CPID = E.CPID(+)
         AND A.CPID = F.CPID(+)
         AND A.CPID = G.CPID(+);
  
  END LOOP;

  --COMMIT;
  O_CODE := 1;
  O_NOTE := '产品风险特征-亏损比率清算成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '产品风险特征-亏损比率清算失败';
END;
/

