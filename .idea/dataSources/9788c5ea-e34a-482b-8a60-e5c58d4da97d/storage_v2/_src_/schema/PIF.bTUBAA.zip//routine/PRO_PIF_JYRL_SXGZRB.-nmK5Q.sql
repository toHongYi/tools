create PROCEDURE PRO_PIF_JYRL_SXGZRB(O_CODE OUT NUMBER, --返回值
                                                O_NOTE OUT VARCHAR2, --返回消息
                                                I_KSNF IN VARCHAR2, --开始年份
                                                I_JSNF IN VARCHAR2 --结束年份
                                                ) IS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：刷新工作日表

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-07-25     V1.0      谢莉莉             创建
      2016-10-20     V2.0      王大一             托管系统迁移改造接入产品中心
   *********************************************************************************************************************/

  V_LEVEL NUMBER; --层数
  V_JDRQ  DATE; --较大日期
  V_JXRQ  DATE; --较小日期

BEGIN
  O_CODE := 1;
  O_NOTE := '操作成功！';

  V_JDRQ  := TO_DATE(I_JSNF || '1231', 'yyyymmdd');
  V_JXRQ  := TO_DATE(I_KSNF || '0101', 'yyyymmdd');
  V_LEVEL := ABS(V_JDRQ - V_JXRQ);
  --插入区间内星期一数据
  INSERT INTO TPIF_JYRL_GZR
    (ID, XQY, YF)
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_GZR'),
           C.v_date,
           SUBSTR(TO_CHAR(C.v_date, 'yyyymmdd'), 0, 6)
      FROM (select *
              from (select distinct trunc(V_JXRQ + level, 'iw') as v_date
                      from dual
                    connect by level <= (V_LEVEL + 1) * 7)
             where v_date <= V_JDRQ
               AND v_date >= V_JXRQ
               AND v_date NOT IN
                   (SELECT TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd')
                      FROM TPIF_JYRL_GZR
                     WHERE XQY IS NOT NULL)
             order by v_date) C;

  --完善其他日期
  UPDATE TPIF_JYRL_GZR
     SET XQE = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 1,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 1,
                      ''),
         XQT = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 2,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 2,
                      ''),
         XQS = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 3,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 3,
                      ''),
         XQW = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 4,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 4,
                      ''),
         XQL = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 5,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 5,
                      ''),
         XQR = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQY, 'yyyymmdd'),
                                             'yyyymmdd') + 6,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQY, 'yyyymmdd'), 'yyyymmdd') + 6,
                      '')
   WHERE (XQE IS NULL OR XQT IS NULL OR XQS IS NULL OR XQW IS NULL OR
         XQL IS NULL OR XQR IS NULL)
     AND XQY IS NOT NULL
     AND SUBSTR(TO_CHAR(XQY, 'yyyymmdd'), 0, 6) = YF;

  --插入区间内星期天数据
  INSERT INTO TPIF_JYRL_GZR
    (ID, XQR, YF)
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_GZR'),
           C.v_date,
           SUBSTR(TO_CHAR(C.v_date, 'yyyymmdd'), 0, 6)
      FROM (select *
              from (select distinct trunc(V_JXRQ + level, 'iw') - 1 as v_date
                      from dual
                    connect by level <= (V_LEVEL + 1) * 7)
             where v_date <= V_JDRQ
               AND v_date >= V_JXRQ
               AND v_date NOT IN
                   (SELECT TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd')
                      FROM TPIF_JYRL_GZR
                     WHERE XQR IS NOT NULL)
             order by v_date) C;

  --完善其他日期
  UPDATE TPIF_JYRL_GZR
     SET XQE = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'),
                                             'yyyymmdd') - 5,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 5,
                      ''),
         XQT = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'),
                                             'yyyymmdd') - 4,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 4,
                      ''),
         XQS = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'),
                                             'yyyymmdd') - 3,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 3,
                      ''),
         XQW = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'),
                                             'yyyymmdd') - 2,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 2,
                      ''),
         XQL = DECODE(SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'),
                                             'yyyymmdd') - 1,
                                     'yyyymmdd'),
                             0,
                             6),
                      YF,
                      TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 1,
                      '')
   WHERE (XQE IS NULL OR XQT IS NULL OR XQS IS NULL OR XQW IS NULL OR
         XQL IS NULL OR XQY IS NULL)
     AND XQR IS NOT NULL
     AND SUBSTR(TO_CHAR(XQR, 'yyyymmdd'), 0, 6) = YF
     AND SUBSTR(TO_CHAR(TO_DATE(TO_CHAR(XQR, 'yyyymmdd'), 'yyyymmdd') - 6,
                        'yyyymmdd'),
                0,
                6) != YF;
  --完善第几周
  FOR NY IN (select DISTINCT YF, XQR, XQY
               from TPIF_JYRL_GZR t
              WHERE XQ IS NULL
              GROUP BY YF, XQR, XQY
              ORDER BY YF, XQR, XQY) LOOP
    UPDATE TPIF_JYRL_GZR t
       SET XQ =
           (with p as (SELECT ROWNUM R, p.XQR, p.XQY
                         FROM (SELECT XQR, XQY
                                 FROM TPIF_JYRL_GZR
                                WHERE YF = NY.YF
                                ORDER BY XQR, XQY) p)
             select a.R
               from p a
              where a.XQR = t.XQR
                 OR a.XQY = t.XQY)
              WHERE YF = NY.YF;


  END LOOP;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_JYRL_SXGZRB;
/

