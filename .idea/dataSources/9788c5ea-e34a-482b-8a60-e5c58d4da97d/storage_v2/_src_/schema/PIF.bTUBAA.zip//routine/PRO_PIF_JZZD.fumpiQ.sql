create PROCEDURE PRO_PIF_JZZD(O_RESULT OUT SYS_REFCURSOR,
                                         I_USERID IN NUMBER,
                                         I_BQ IN NUMBER,     --本期交易日期
                                         I_SQ IN NUMBER,     --上期交易日期
                                         I_CPID IN NUMBER,   --产品ID
                                         I_CPJD IN VARCHAR2, --产品阶段
                                         I_YWLX IN VARCHAR2  --业务类型
                                         )AS        
                                                  
/******************************************************************
  项目名称：财通证券运营展业平台-净值报表
  所属用户：PIF
  概要说明：单位净值涨跌情况、累计净值涨跌情况

  语法信息：
       输出参数：
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分

  修订记录：
      修订日期       版本号     修订人             修改内容简要说明
      2020-12-30      1.0.     GAOKUN               新增.
      2021-05-14      1.1      GAOKUN             因拆分而修改
  ********************************************************************/
  
                                           
V_NOTE VARCHAR2(1000);   --报错信息输出                                     
                                    
V_YJCL VARCHAR2(1000);   --一级策略、二级策略、三级策略
V_EJCL VARCHAR2(1000);   
V_SJCL VARCHAR2(1000);

V_BQJZRQ NUMBER;   --本期净值日期、累计净值、单位净值
V_BQLJJZ NUMBER;
V_BQDWJZ NUMBER;

V_SQJZRQ NUMBER;   --上期净值日期、累计净值、单位净值
V_SQLJJZ NUMBER;
V_SQDWJZ NUMBER;

V_I NUMBER :=0;    --判断上期
V_J NUMBER :=0;    --判断本期

V_ZJSQ NUMBER;     --上期和本期之间 距离上期最近那一天
V_ZJBQ NUMBER;     --上期和本期之间 距离本期最近那一天

BEGIN
  EXECUTE IMMEDIATE 'TRUNCATE TABLE PIF.TPIF_JZZD ';  --每次都清空该表，该表用于返回数据

  IF I_USERID IS NULL THEN
    RETURN;
  END IF;
  
  --内部产品表循环  
  FOR CUR IN (SELECT * FROM TPIF_CPDM_SMYY   
              WHERE (I_CPID IS NULL OR ID = I_CPID)
                AND (INSTR(';'||I_CPJD||';',';'||CPJD||';')>0)
                AND (INSTR(';'||I_YWLX||';',';'||CPYWLX||';')>0)
   ) LOOP    
    --判断私募产品净值表中是否存在 当前产品交易日期=上期 的数据
    SELECT COUNT(1) INTO V_I FROM TPIF_CPJZ_SMYY WHERE CPID=CUR.CPID AND JYRQ=I_SQ;
    --如果存在，直接取上期这一天的数据即可
    IF V_I >0 THEN   
      SELECT JZRQ, DWJZ, LJJZ
        INTO V_SQJZRQ, V_SQDWJZ, V_SQLJJZ
        FROM TPIF_CPJZ_SMYY
       WHERE CPID = CUR.CPID
         AND JYRQ = I_SQ;
    --如果不存在，则取在上期和本期之间，距离上期最近的那一天的数据，没有则置空
    ELSE
        BEGIN
          SELECT MIN(JYRQ)
            INTO V_ZJSQ
            FROM TPIF_CPJZ_SMYY
           WHERE CPID = CUR.CPID
             AND JYRQ > I_SQ
             AND JYRQ < I_BQ;
        EXCEPTION WHEN OTHERS THEN  --找不到距离上期最近的交易日期的话，则上期的数据为空
          V_ZJSQ   := NULL;
          V_SQJZRQ := NULL;
          V_SQDWJZ := NULL;
          V_SQLJJZ := NULL;
        END;
            
        IF V_ZJSQ IS NOT NULL THEN  --找到的话，则取距离上期最近的那一天的数据
          SELECT JZRQ, DWJZ, LJJZ
            INTO V_SQJZRQ, V_SQDWJZ, V_SQLJJZ
            FROM TPIF_CPJZ_SMYY
           WHERE CPID = CUR.CPID
             AND JYRQ = V_ZJSQ;
        END IF;  
    END IF;
        
    --获取本期数据
    SELECT COUNT(1) INTO V_J FROM TPIF_CPJZ_SMYY WHERE CPID=CUR.CPID AND JYRQ=I_BQ;
    IF V_J >0 THEN
      SELECT JZRQ, DWJZ, LJJZ
        INTO V_BQJZRQ, V_BQDWJZ, V_BQLJJZ
        FROM TPIF_CPJZ_SMYY
       WHERE CPID = CUR.CPID
         AND JYRQ = I_BQ;
    ELSE
        BEGIN
          SELECT MAX(JYRQ)
            INTO V_ZJBQ
            FROM TPIF_CPJZ_SMYY
           WHERE CPID = CUR.CPID
             AND JYRQ > I_SQ
             AND JYRQ < I_BQ;
     --        AND JYRQ !=V_SQJZRQ;
        EXCEPTION WHEN OTHERS THEN
          V_ZJBQ   :=NULL;
          V_BQJZRQ :=NULL;
          V_BQDWJZ :=NULL;
          V_BQLJJZ :=NULL;
        END;
            
        IF V_ZJBQ IS NOT NULL THEN
          SELECT JZRQ, DWJZ, LJJZ
            INTO V_BQJZRQ, V_BQDWJZ, V_BQLJJZ
            FROM TPIF_CPJZ_SMYY
           WHERE CPID = CUR.CPID
             AND JYRQ = V_ZJBQ;
        END IF;
    END IF;
        
    --获取该产品的三级策略 字符串
    BEGIN
      SELECT NAME
        INTO V_YJCL
        FROM TPIF_SMCLFL
       WHERE ID = (SELECT SMCLYJFL FROM TPIF_CPDM_SMYY WHERE CPID = CUR.CPID);
    EXCEPTION WHEN OTHERS THEN 
      V_YJCL:=NULL;
    END;
    BEGIN
      SELECT NAME
        INTO V_EJCL
        FROM TPIF_SMCLFL
       WHERE ID = (SELECT SMCLEJFL FROM TPIF_CPDM_SMYY WHERE CPID = CUR.CPID);
    EXCEPTION WHEN OTHERS THEN 
      V_EJCL:=NULL;
    END;  
    BEGIN
      SELECT NAME
        INTO V_SJCL
        FROM TPIF_SMCLFL
       WHERE ID = (SELECT SMCLSJFL FROM TPIF_CPDM_SMYY WHERE CPID = CUR.CPID);
    EXCEPTION WHEN OTHERS THEN 
      V_SJCL:=NULL;
    END;    
         
    --如果上期净值日期和本期净值日期均不为空，则可以求涨跌额、单位净值涨跌幅等信息
    IF V_SQJZRQ IS NOT NULL AND V_BQJZRQ IS NOT NULL THEN
      INSERT INTO PIF.TPIF_JZZD
        (CPDM,
         DXCPDM,
         CPMC,
         CPJD,
         CLRQ,
         SQJZRQ,
         SQLJJZ,
         SQDWJZ,
         BQJZRQ,
         BQLJJZ,
         BQDWJZ,
         LJZZDE,
         DQZZDE,
         FH,
         YJCL,
         EJCL,
         SJCL,
         DQZZDF,
         WDZDF
         )
      VALUES
        (CUR.CPDM,
         CUR.DXCPDM,
         CUR.DYCPQC,
         DECODE(CUR.CPJD, 3, '存续期', 5, '结束期'),
         CUR.CLRQ,
         V_SQJZRQ,
         V_SQLJJZ,
         V_SQDWJZ,
         V_BQJZRQ,
         V_BQLJJZ,
         V_BQDWJZ,
         V_BQLJJZ - V_SQLJJZ,
         V_BQDWJZ - V_SQDWJZ,
         (V_BQLJJZ - V_SQLJJZ) - (V_BQDWJZ - V_SQDWJZ),
         V_YJCL,
         V_EJCL,
         V_SJCL,
         ((V_BQDWJZ-V_SQDWJZ)/V_SQDWJZ)*100,
        (SELECT (CASE
                 WHEN NVL(A.ZSPJ, 0) = 0 THEN
                  0
                 ELSE
                  ROUND((B.ZSPJ - A.ZSPJ) / A.ZSPJ, 6)
               END)*100 WDZDF
          FROM (SELECT ZSPJ
                  FROM DSC_STAT.TPIF_STAT_ZSHQ
                 WHERE ZSDM = '881001.WI'
                   AND SJRQ = V_SQJZRQ) A,
               (SELECT ZSPJ
                  FROM DSC_STAT.TPIF_STAT_ZSHQ
                 WHERE ZSDM = '881001.WI'
                   AND SJRQ = V_BQJZRQ) B)
         );
         
    --如果本期净值日期和上期净值日期中有一方为空，则无法计算涨跌额、单位净值涨跌幅等信息 
    ELSIF (V_SQJZRQ IS NOT NULL AND V_BQJZRQ IS NULL) 
       OR (V_SQJZRQ IS NULL AND V_BQJZRQ IS NOT NULL) THEN
      INSERT INTO PIF.TPIF_JZZD
        (CPDM,
         DXCPDM,
         CPMC,
         CPJD,
         CLRQ,
         SQJZRQ,
         SQLJJZ,
         SQDWJZ,
         BQJZRQ,
         BQLJJZ,
         BQDWJZ,
         LJZZDE,
         DQZZDE,
         FH,
         YJCL,
         EJCL,
         SJCL,
         DQZZDF
         )
      VALUES
        (CUR.CPDM,
         CUR.DXCPDM,
         CUR.DYCPQC,
         DECODE(CUR.CPJD, 3, '存续期', 5, '结束期'),
         CUR.CLRQ,
         V_SQJZRQ,
         V_SQLJJZ,
         V_SQDWJZ,
         V_BQJZRQ,
         V_BQLJJZ,
         V_BQDWJZ,
         NULL,
         NULL,
         NULL,
         V_YJCL,
         V_EJCL,
         V_SJCL,
         NULL
         );
         --上期和本期均为空的过滤，不展示
    END IF;
        
    V_YJCL :=NULL;   --三级策略
    V_EJCL :=NULL;
    V_SJCL :=NULL;

    V_BQJZRQ :=NULL;   --本期净值日期、累计净值、单位净值
    V_BQLJJZ :=NULL;
    V_BQDWJZ :=NULL;

    V_SQJZRQ :=NULL;   --上期净值日期、累计净值、单位净值
    V_SQLJJZ :=NULL;
    V_SQDWJZ :=NULL;

    V_I  :=0;    --判断上期
    V_J  :=0;    --判断本期

    V_ZJSQ :=NULL;     --上期和本期之间 距离上期最近那一天
    V_ZJBQ :=NULL;
  END LOOP;
  
  COMMIT;
  OPEN O_RESULT FOR
    SELECT * FROM TPIF_JZZD ORDER BY SQJZRQ ASC;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
END;
/

