create PROCEDURE PRO_SJQX_DZQY_PENDING_INFO(O_CODE OUT NUMBER, --返回值
                                                       O_NOTE OUT VARCHAR2 --返回消息
                                                       ) IS

  /******************************************************************
      所属用户：PIF
      功能说明：电子签约待定项目表 PIF.DZQY_PENDING_INFO 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5       1.0       HANQN              创建
  
  ***********************************************************************/

BEGIN
  O_CODE := -1;
  O_NOTE := '';

  MERGE INTO DZQY_PENDING_INFO_TEST T
  USING (SELECT A.CHANNEL_ID   AS BIZ_CHANNEL_ID,
                A.NAME         AS BIZ_NAME,
                A.FUND_CODE,
                A.FUND_NAME,
                A.ACCOUNT_TYPE,
                A.ITOACCOUNT   AS ITO_ACCOUNT,
                B.PROD_CODE
           FROM SRC_PIF.PROD_PENDING_INFO A, SRC_PIF.PROD_PROJ_INFO B
          WHERE A.FUND_CODE = B.FUND_CODE) S
  ON (T.BIZ_CHANNEL_ID = S.BIZ_CHANNEL_ID)
  WHEN NOT MATCHED THEN
    INSERT
      (T.ID,
       T.FUND_CODE,
       T.PROD_CODE,
       T.CREATE_DATE,
       T.LAST_MODIFIED_DATE,
       T.DELETED_FLAG,
       T.FUND_NAME,
       T.BIZ_CHANNEL_ID,
       T.BIZ_NAME,
       T.ITO_ACCOUNT,
       T.ACCOUNT_TYPE)
    VALUES
      (LIVEBOS.FUNC_NEXTID('DZQY_PENDING_INFO_TEST'),
       S.FUND_CODE,
       S.PROD_CODE,
       SYSDATE,
       SYSDATE,
       2,
       S.FUND_NAME,
       S.BIZ_CHANNEL_ID,
       S.BIZ_NAME,
       S.ITO_ACCOUNT,
       S.ACCOUNT_TYPE);

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'PIF.DZQY_PENDING_INFO 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'DZQY_PENDING_INFO 表清洗,未知错误'
                ELSE
                 'DZQY_PENDING_INFO,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

