create PROCEDURE PCX_CPYYGL_HQXSJSRQ(O_XSJSRQ OUT NUMBER, --返回值,
                                                I_CPID   IN NUMBER --产品ID

                                                ) IS

  /******************************************************************
      所属用户：PIF
      功能说明：根据产品ID获取产品销售结束日期,用于TPIF_YYCPGL对象新增方法
      语法信息：
           输入参数：   CPID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-14     1.0.0     WEIWENHAO        获取产品销售结束日期
  ***********************************************************************/

  V_XSKSRQ     DATE; --销售开始日期
  V_XSKSRQ_TEM NUMBER;
  V_CPID       NUMBER; --产品管理ID
  V_XSJSRQ     NUMBER; --销售结束日期
  V_COUNT      NUMBER;
  V_YWLX       VARCHAR2(30); --业务类型

BEGIN
  V_CPID := I_CPID;
  SELECT COUNT(1)
    INTO V_COUNT
    FROM pif.TPIF_JYRL_HB
   WHERE rq > trunc(SYSDATE)
     AND cpid = V_CPID
     AND YWLX IN ('6', '7');
  IF V_COUNT > 0 THEN
    FOR CUR IN (SELECT trunc(MIN(rq)) AS RQ, YWLX
                  FROM pif.TPIF_JYRL_HB
                 WHERE rq > trunc(SYSDATE)
                   AND cpid = V_CPID
                   AND YWLX IN ('6', '7')
                 GROUP BY YWLX) LOOP

      V_YWLX       := CUR.YWLX;
      V_XSKSRQ_TEM := TO_NUMBER(TO_CHAR(CUR.RQ,'YYYYMMDD'));
      V_XSJSRQ     := FUNC_PIF_GET_ENDOPENDAY(V_CPID, V_XSKSRQ_TEM, V_YWLX);
      --优先取认购，无认购取申购
      IF CUR.YWLX=6 THEN
        O_XSJSRQ := V_XSJSRQ;
      END IF;
      IF CUR.YWLX=7 AND O_XSJSRQ IS NULL THEN
        O_XSJSRQ := V_XSJSRQ;
      END IF;
    END LOOP;
  ELSE
    O_XSJSRQ := NULL;
  END IF;

END;
/

