create procedure PCX_CPYYGL_HQXSJSRQ(
                         O_XSJSRQ OUT NUMBER,  --返回值,
                                                   I_CPID   IN  NUMBER--产品ID
                                                   
                                                   )IS

  /******************************************************************
      所属用户：PIF
      功能说明：根据产品ID获取产品销售结束日期,用于TPIF_YYCPGL对象新增方法
      语法信息：
           输入参数：   CPID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-14     1.0.0     WEIWENHAO        获取产品销售结束日期
  ***********************************************************************/

V_XSKSRQ  date; --销售开始日期
V_XSKSRQ_TEM NUMBER;
V_CPID NUMBER;--产品管理ID
V_XSJSRQ NUMBER; --销售结束日期
V_COUNT NUMBER;
V_YWLX VARCHAR2(30);--业务类型


BEGIN
V_CPID := I_CPID;
SELECT COUNT(1) INTO V_COUNT FROM pif.TPIF_JYRL_HB where rq >trunc(sysdate) and cpid =V_CPID  AND YWLX IN('6','7') ;
IF V_COUNT >0 THEN
select  trunc(min(rq)),YWLX  INTO V_XSKSRQ,V_YWLX from pif.TPIF_JYRL_HB where rq >trunc(sysdate) and cpid =V_CPID  AND YWLX IN( '6','7');

SELECT   TO_NUMBER(TO_CHAR(V_XSKSRQ,'YYYYMMDD')) INTO V_XSKSRQ_TEM    FROM DUAL;
   V_XSJSRQ:=  FUNC_PIF_GET_ENDOPENDAY(V_CPID,V_XSKSRQ_TEM,V_YWLX);
 O_XSJSRQ:=V_XSJSRQ;
 ELSE
   
 O_XSJSRQ:=NULL;
 END IF;
 
 END;
/

