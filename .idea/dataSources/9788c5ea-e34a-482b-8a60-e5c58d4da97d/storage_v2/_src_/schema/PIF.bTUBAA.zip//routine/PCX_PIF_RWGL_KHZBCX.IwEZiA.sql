create PROCEDURE pcx_pif_rwgl_khzbcx(O_CODE   OUT NUMBER,
                                                O_NOTE   OUT VARCHAR2,
                                                O_RESULT OUT SYS_REFCURSOR,
                                                i_userid IN number, --用户id
                                                i_rwlx in number, --任务类型
                                                i_rwld in number  --任务粒度
                                                ) AS
  /******************************************************************
  项目名称：产品中心-任务管理-查询任务列表
  所属用户：PIF
  概要说明：查询当前登录人所创建的任务列表.
               i_userid       IN NUMBER, --用户id
               i_type         IN NUMBER  --查询类别 1|我创建的惹任务；2|我被下达的任务
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.

  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询任务列表.

        1.查询任务列表需要显示的字段,供前端查询展示.

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/07/20     1.0.1     tumeng             新增.
  *********************************************************************************************************************/
  V_SQL_QUERY VARCHAR2(32767);
  V_ERRMSG    VARCHAR2(300); --错误信息
BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  IF i_userid IS NULL THEN
    O_CODE := -1801;
    O_NOTE := '请输入的必填参数【用户ID】';
    RETURN;
  END IF;
  IF i_rwlx IS NULL  THEN
    O_CODE := -1802;
    O_NOTE := '请输入的必填参数【任务类型】';
    RETURN;
  END IF;
/*  IF i_rwld IS NULL  THEN
    O_CODE := -1803;
    O_NOTE := '请输入的必填参数【任务粒度】';
    RETURN;
  END IF;*/

  --数据源赋值
  V_SQL_QUERY := 'select  id,
                          ZBMC as name,
                          ZBGZDY as description,
                          ZBFZ as group_id,
                          (select note from livebos.txtdm  where fldm = ''PIF_ZBFZ'' and ibm = t.zbfz) as group_name
               from pif.TPIF_RWZBXX t
               where ' || case when i_rwlx = 2 then ' ZBLD = 4 ' else ' ZBLD = ' || i_rwld end;
  dbms_output.put_line(V_SQL_QUERY);
  OPEN O_RESULT FOR V_SQL_QUERY;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := ' 查询失败 ';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT ' 异常信息： ' || V_ERRMSG FROM DUAL;
END pcx_pif_rwgl_khzbcx;
/

