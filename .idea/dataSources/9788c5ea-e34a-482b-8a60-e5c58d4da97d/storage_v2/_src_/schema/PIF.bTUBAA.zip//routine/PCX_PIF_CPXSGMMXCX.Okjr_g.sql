create PROCEDURE PCX_PIF_CPXSGMMXCX( O_RESULT OUT SYS_REFCURSOR,
                                               I_KSRQ IN NUMBER,
                                               I_JSRQ IN NUMBER,
                                               I_CPDM IN NUMBER,
                                               I_YYB IN NUMBER
                                               ) AS

/* -----------------------------------------------------------------------
   项目：财通产品中心
   过程名称 :  PCX_PIF_CPXSGMMXCX
   功能简述：  产品销售规模明细查询

   输入： I_KSRQ IN NUMBER,   
          I_JSRQ IN NUMBER,  
          I_CPDM IN NUMBER,  
          I_YYB IN NUMBER    营业部


   输出：O_RESULT OUT SYS_REFCURSOR


   ------------------------------------------------------------------------
   操作人           操作时间       版本            操作
   gaokun           20201103       1.0           新增
  -----------------------------------------------------------------------*/
V_SQL VARCHAR2(3000);
V_NOTE  VARCHAR2(1000);

BEGIN

  V_SQL:='SELECT A.RQ,
                 (SELECT NAME FROM LIVEBOS.lbOrganization WHERE ID=A.FGS) FGS,
                 B.BRANCH_SHORT_NAME YYBJC,
                 B.BRANCH_NAME YYBQC,
                 B.BRANCH_ID YYBDM,
                 C.CPMC CPQC,
                 C.CPDM CPDM,
                 A.SXGM,
                 A.CPHSXGM
         FROM DSC_STAT.TPIF_STAT_CP_XSGM A,LIVEBOS.lbOrganization B,PIF.TPIF_CPDM C
         WHERE A.YYB=B.ID AND C.ID=A.CPID 
         AND A.RQ BETWEEN ' || I_KSRQ || ' AND ' || I_JSRQ;

  IF I_CPDM IS NOT NULL THEN
    V_SQL := V_SQL || ' AND A.CPID = ' || I_CPDM ;
  END IF;

  IF I_YYB IS NOT NULL THEN
    V_SQL := V_SQL || ' AND A.YYB = ' || I_YYB;
  END IF;

  DBMS_OUTPUT.PUT_LINE(V_SQL);
  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;

END;
/

