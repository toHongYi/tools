create PROCEDURE PCX_PIF_CPSY_CPZQ(O_CODE           OUT NUMBER,
                                              O_NOTE           OUT VARCHAR2,
                                              O_RESULT         OUT SYS_REFCURSOR,
                                              I_Product_area   IN NUMBER  --产品专区ID
                                              ) AS
  /******************************************************************
  项目名称：产品中心-产品首页-查询产品专区
  所属用户：PIF
  概要说明：查询产品专区列表.
               i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                               并不是什么是否都需要分页,看情形而言.
               i_PageNo      --页码
               i_PageLength  --页长
               i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               i_Sort        --排序字段
               I_YHID         IN NUMBER, --用户 ID
               I_MBBM         IN NUMBER  --模版编码,可为空
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  
  数据准备：
      PIF.TFP_CPLX 产品类型
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品专区列表.
  
        1.查询产品专区列表.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2014/11/11     4.0.0.1   guonanhua           新增.
  *********************************************************************************************************************/
  V_SQL          VARCHAR2(32767);
BEGIN
  O_CODE         := 1;
  O_NOTE         := '成功';

  V_SQL := ' SELECT T.ID prodarea_id,
                      T.NAME prodarea_name,
                      ''TPIF_CPZT.XTPFJ.''||T.ID   list_image_info,
                      ''TPIF_CPZT.DTPFJ.''||T.ID   details_image_info,
                      T.ZTJS prodarea_intro,
                      T.XSSX display_order
                 FROM PIF.TPIF_CPZT T
                WHERE T.ZT = 1
                  AND T.TYPE = 2  ';

  IF I_Product_area IS NOT NULL THEN
  
    V_SQL := V_SQL || ' AND T.ID = ' || I_Product_area;
  
  END IF;

  OPEN O_RESULT FOR V_SQL;


EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败:'||SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
END PCX_PIF_CPSY_CPZQ;
/

