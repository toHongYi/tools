create PROCEDURE     PRO_PIF_CPXXSJDR_CSBGTX(O_CODE   OUT INT, --返回结果代码
                                                        O_NOTE   OUT VARCHAR2, --返回结果说明
                                                        O_RESULT OUT SYS_REFCURSOR,
                                                        I_RQ     IN NUMBER, --日期
                                                        I_JGDM   IN VARCHAR2, --机构代码
                                                        I_USERID IN VARCHAR2, --用户ID, TUSER.USERID
                                                        I_IP     IN VARCHAR2 --操作站点
                                                        ) AS
  /******************************************************************************
  *
  *文件名称：PRO_PIF_CPXXSJDR_CSBGTX
  *项目名称：海通产品中心
  *功能说明：TXT文件导入产品后参数变更提醒
  *处理逻辑：比较从07文件中取到的数据与现有数据是否一致
   I_RQ     IN NUMBER  --日期
   I_JGDM   IN VARCHAR2, --机构代码
   I_USERID IN VARCHAR2, --用户ID, TUSER.USERID
   I_IP     IN VARCHAR2 --操作站点

  *------------------------------------------------------------------------------
  *修改者        版本号        修改日期         说明
  *孙远何        V1.0.1        2015-12-21       新增
  *****************************************************************************/

  V_COUNT    NUMBER(8) := 0;
  V_COUNT_CL NUMBER(8) := 0;
  V_FXJG     NUMBER;
  V_CZY      NUMBER;
  V_IDS      VARCHAR2(8000);
  V_SQL      VARCHAR2(8000);
  V_JOBID    NUMBER(16);
  V_NZ       VARCHAR2(30);
  V_OZ       VARCHAR2(30);
  V_SFBG     INTEGER;
  V_SQL_BG   VARCHAR2(8000);
  V_ZD       VARCHAR2(30);
  V_ERRMSG   VARCHAR2(300); --错误信息

BEGIN

  O_CODE := 1;
  O_NOTE := '成功';

  /*  BEGIN
      SELECT ID INTO V_CZY FROM CRMII.TUSER WHERE USERID = I_USERID;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          O_RESULT := -1;
          O_NOTE   := '用户' || I_USERID || '不存在';
          RETURN;
  END;

  SELECT MAX(JOB_ID)
    INTO V_JOBID
    FROM TPIF_XTWJPZ
   WHERE YWFL = 7 \*产品信息文件*\
     AND JGDM = I_JGDM;
  IF (V_JOBID > 0) THEN
      UPDATE TFILEJOB SET STATUS = 3, MSG = '数据处理中' WHERE ID = V_JOBID;
      COMMIT;
  END IF;

  --过滤空格
  FOR X IN (SELECT COLUMN_NAME || '=REPLACE(' || COLUMN_NAME || ','' '',NULL)' COL
              FROM USER_TAB_COLS
             WHERE DATA_TYPE = 'VARCHAR2'
               AND TABLE_NAME = 'TPIF_TEMP_QS_OF_07') LOOP
      IF (V_SQL IS NULL) THEN
          V_SQL := X.COL;
      ELSE
          V_SQL := V_SQL || ',' || X.COL;
      END IF;
  END LOOP;
  IF (V_SQL IS NOT NULL) THEN
      V_SQL := 'UPDATE TPIF_TEMP_QS_OF_07 SET ' || V_SQL;
      EXECUTE IMMEDIATE V_SQL;
  END IF;

  --取发行机构
  SELECT ID INTO V_FXJG FROM TPIF_JGDM WHERE JGDM = I_JGDM;*/
  --计算导入总行数
  ----重要参数变更提醒----

  FOR CUR_CP IN (SELECT TOTALFUNDVOL           JJZFS,
                        FUNDCODE               CPDM,
                        FUNDSTATUS             JJZT,
                        NAV                    JJJZ,
                        UPDATEDATE             JZRQ,
                        NETVALUETYPE           JZLX,
                        ACCUMULATIVENAV        LJJZ,
                        CONVERTSTATUS          JJZHZT,
                        PERIODICSTATUS         DQDEZT,
                        TRANSFERAGENCYSTATUS   ZTGZT,
                        FUNDSIZE               JJGM,
                        CURRENCYTYPE           JSBZ,
                        ANNOUNCFLAG            GGBZ,
                        DEFDIVIDENDMETHOD      MRFHFS,
                        TRADINGPRICE           JYJG,
                        FACEVALUE              JJMZ,
                        ISSUETYPEBYINDI        GRFXFS,
                        ISSUETYPEBYINST        JGFXFS,
                        COLLECTFEETYPE         JYFSQFS,
                        VALUELINE              CPJZXSZ,
                        TOTALDIVIDENT          LJDWFH,
                        FUNDINCOME             HBJJWFSY,
                        FUNDINCOMEFLAG         HBJJWFSYZF,
                        YIELD                  HBJJQRNHSYL,
                        YIELDFLAG              HBJJQRNHSYLZF,
                        GUARANTEEDNAV          BBJZ,
                        FUNDYEARINCOMERATE     HBJJNSYL,
                        FUNDYEARINCOMERATEFLAG HBJJNSYLZF,
                        FUNDDAYINCOMEFLAG      JJDRZSYZF,
                        FUNDDAYINCOME          JJDRZSY,
                        IPOSTARTDATE           JJMJKSRQ,
                        IPOENDDATE             JJMJJSRQ,
                        FUNDTYPE               JJLX,
                        FUNDTYPENAME           JJLXMC,
                        INSTAPPSUBSAMNT        ZJRGJE_JG,
                        INSTAPPSUBSVOL         ZJRGFS_JG,
                        MINAMOUNTBYINST        SCRGZDJE_JG,
                        MINVOLBYINST           SCRGZDFS_JG,
                        INDIAPPSUBSVOL         ZJRGFS_GR,
                        INDIAPPSUBSAMOUNT      ZJRGJE_GR,
                        MINSUBSVOLBYINDI       SCRGZDFS_GR,
                        MINSUBSAMOUNTBYINDI    SCRGZDJE_GR,
                        MAXSUBSVOLBYINDI       ZGRGFS_GR,
                        MAXSUBSAMOUNTBYINDI    ZGRGJE_GR,
                        MAXSUBSVOLBYINST       ZGRGFS_JG,
                        MAXSUBSAMOUNTBYINST    ZGRGJE_JG,
                        UNITSUBSVOLBYINDI      RGFSDW_GR,
                        UNITSUBSAMOUNTBYINDI   RGJEDW_GR,
                        UNITSUBSVOLBYINST      RGFSDW_JG,
                        UNITSUBSAMOUNTBYINST   RGJEDW_JG,
                        SUBSTYPE               RGFS,
                        INDIDAYMAXSUMBUY       DRLJGMZDJE_GR,
                        INSTDAYMAXSUMBUY       DRLJGMZDJE_JG,
                        AMOUNTOFPERIODICSUBS   DSDESGJE,
                        DATEOFPERIODICSUBS     DSDESGRQ,
                        MINBIDSAMOUNTBYINDI    SCSGZDJE_GR,
                        MINBIDSAMOUNTBYINST    SCSGZDJE_JG,
                        MINAPPBIDSAMOUNTBYINDI ZJSGZDJE_GR,
                        MINAPPBIDSAMOUNTBYINST ZJSGZDJE_JG,
                        INDIMAXPURCHASE        ZDSGJE_GR,
                        INSTMAXPURCHASE        ZDSGJE_JG,
                        MININTERCONVERTVOL     ZDJJZHFS,
                        MAXREDEMPTIONVOL       JJZGSHFS,
                        MINACCOUNTBALANCE      JJZDCYFS,
                        MINREDEMPTIONVOL       JJZSSHFS,
                        INDIMAXREDEEM          ZDSHFE_GR,
                        INSTMAXREDEEM          ZDSHFE_JG,
                        ALLOWBREACHREDEMPT     YXWYSHBZ,
                        INDIDAYMAXSUMREDEEM    DRLJSHZDFE_GR,
                        INSTDAYMAXSUMREDEEM    DRLJSHZDFE_JG,
                        --'' JJSSTA,
                        CUSTODIANCODE TGRDM,
                        --'' JJTGRMC,
                        FUNDMANAGERCODE     JJGLR,
                        FUNDMANAGERNAME     JJGLRMC,
                        REGISTRARCODE       ZCDJR,
                        REGISTRARNAME       ZCDJRMC,
                        FUNDSPONSOR         JJFQR,
                        FUNDSERVERTEL       JJGSKFDH,
                        FUNDINTERNETADDRESS JJGSWZ,
                        DIVIDENTDATE        FHR,
                        REGISTRATIONDATE    QYDJR,
                        XRDATE              CQR,
                        NEXTTRADEDATE       XYKFR
                 --V_FXJG JJFXR
                   FROM TPIF_TEMP_QS_OF_07 T
                  WHERE EXISTS
                  (SELECT 1 FROM TPIF_CPDM_TMP_OF T WHERE T.CPDM = CPDM)) LOOP

    FOR CUR_ZD IN (SELECT SUBSTR(CPSX, INSTR(CPSX, '.', 1) + 1) CPSX, TZRY
                     FROM TPIF_CPDM_OF_CSBGTXPZ) LOOP
      SELECT CUR_ZD.CPSX INTO V_ZD FROM DUAL;
      V_SQL_BG := 'SELECT CUR_CP ' || ''' . ''' || V_ZD || ', O ' ||
                  ''' .
                        ''' || V_ZD ||
                  ', CASE
                            WHEN  CUR_CP ' || '''.
                        ''' || V_ZD || ' = O ' ||
                  ''' . ''' || V_ZD ||
                  ' THEN
                             1
                            ELSE
                             0
                        END SFBG --1|未变动,0|变动
                        FROM TPIF_CPDM_TMP_OF O WHERE O.CPDM = ' ||
                  CUR_CP.CPDM;

      /*    EXECUTE IMMEDIATE V_SQL_BG
              INTO V_SFBG;
      */
      OPEN O_RESULT FOR V_SQL_BG;
      /*  IF V_SFBG = 1 THEN
              CRMII.PRO_FWGL_DXFS(O_RESULT, --返回结果代码
                                  O_NOTE, --返回结果说明
                                  V_CZY, --TUSER.ID
                                  2, --电子邮件
                                  1, --自动配送
                                  CUR_ZD.TZRY, --通知人|邮件接收人
                                  ' ', --邮件地址
                                  '公募基金07文件参数值变动提醒', --标题
                                  '公募基金：[' || CUR_CP.CPDM || ']参数：{' || CUR_ZD.CPSX ||
                                  '}的值由：' || V_OZ || ' 变为：' || V_NZ --内容
                                  );

          END IF;
      END LOOP;
      CRMII.PRO_YJHBCL(O_RESULT, O_NOTE, '公募基金07文件参数值变动提醒');*/
    END LOOP;
  END LOOP;
  O_CODE := 1;
  O_NOTE := 'XXX';
  CRMII.PRO_YJHBCL(O_CODE, O_NOTE, '公募基金07文件参数值变动提醒');
EXCEPTION
  WHEN OTHERS THEN
    O_CODE   := -1;
    O_NOTE   := '查询失败';
    V_ERRMSG := SQLERRM;
    OPEN O_RESULT FOR
      SELECT V_ERRMSG FROM DUAL;

END PRO_PIF_CPXXSJDR_CSBGTX;
/

