create PROCEDURE PRO_SJQX_TEMPCPJZ(O_CODE OUT NUMBER, --返回值
                                              O_NOTE OUT VARCHAR2 --返回消息
                                              ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：LIVEBOS.TUSER数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          
  ***********************************************************************/
  V_COUNT NUMBER;
  V_MAX   NUMBER;
  V_MIN   NUMBER;
  V_DWJZ  NUMBER;
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  FOR CUR IN (SELECT * FROM TPIF_CPDM WHERE CPXL = 2) LOOP
    /*    SELECT MAX(JZRQ)
      INTO V_MAX
      FROM PIF.TPIF_JZCXCPJZ
     WHERE CPDM = CUR.CPDM;
    SELECT MIN(JZRQ)
      INTO V_MIN
      FROM PIF.TPIF_JZCXCPJZ
     WHERE CPDM = CUR.CPDM;
    INSERT INTO TEMPCPJZ
      (zrr, jyr, cpdm, jzrq, dwjz, ljjz)
      SELECT T.ZRR, T.JYR, C.CPDM, C.JZRQ, C.DWJZ, C.LJJZ
        FROM livebos.txtjyr t
        left join (SELECT * FROM PIF.TPIF_JZCXCPJZ WHERE CPDM = CUR.CPDM) C
          ON t.zrr = C.JZRQ
       WHERE ZRR >= V_MIN
         AND ZRR <= V_MAX;
    COMMIT;
    UPDATE TEMPCPJZ SET CPDM = CUR.CPDM WHERE CPDM IS NULL;
    COMMIT;*/
    UPDATE TEMPCPJZ t
       SET (JZRQ, DWJZ, LJJZ) =
           (SELECT JZRQ, DWJZ, LJJZ
              FROM TEMPCPJZ
             WHERE ZRR = TO_CHAR(TO_DATE(T.ZRR, 'YYYYMMDD') - 1, 'YYYYMMDD')
               AND CPDM = CUR.CPDM)
     WHERE DWJZ IS NULL
       AND CPDM = CUR.CPDM;
    COMMIT;
  
  END LOOP;

  O_CODE := 1;
  O_NOTE := 'TEMPCPJZ 表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TEMPCPJZ 表清洗,未知错误'
                ELSE
                 'TEMPCPJZ 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

