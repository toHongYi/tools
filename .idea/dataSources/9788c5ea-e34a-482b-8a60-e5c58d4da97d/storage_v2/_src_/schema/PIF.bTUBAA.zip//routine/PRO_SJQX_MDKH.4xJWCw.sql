create PROCEDURE PRO_SJQX_MDKH(O_CODE OUT NUMBER, --返回值
                                          O_NOTE OUT VARCHAR2, --返回消息
                                          I_ID   IN NUMBER, --产品摸底的ID
                                          I_MDLX IN VARCHAR2 --摸底类型
                                          ) IS

  /******************************************************************
      所属用户：INFO
      功能说明：摸底客户
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-12-2     1.0       LTX                   创建
          2022-1-4      1.0.1     HANQN                赎回份额逻辑改为当前份额减去锁定期认申金额
  ***********************************************************************/

  V_OBJ     PIF.TPIF_CPMD%ROWTYPE;
  V_2DAY    NUMBER(8); --2天后交易日
  V_ZXFEQRR NUMBER(8); --最小份额确认日

  /*  
  44122 --证券理财申购确认
  44130 --证券理财认购成立
  44143 --证券理财红利发放
  44144 --证券理财强行调增
  
  
  44124 --证券理财赎回确认
  44126 --证券理财转托管确认
  44142 --证券理财强行赎回
  44145 --证券理财强行调减
  44150 --证券理财清盘
  44151 --证券理财终止
  */
BEGIN
  O_CODE := -1;
  O_NOTE := '';

  --最近赎回开放日+2个交易日-锁定期>=份额确认日
  SELECT * INTO V_OBJ FROM PIF.TPIF_CPMD WHERE ID = I_ID;
  V_2DAY := LIVEBOS.FUNC_GETNEXTJYR(V_OBJ.ZJSHKF, 2); --2个交易日
  SELECT TO_CHAR(TO_DATE(V_2DAY, 'YYYYMMDD') - V_OBJ.SDQ, 'YYYYMMDD') ---锁定期(天)
    INTO V_ZXFEQRR
    FROM DUAL;
  --单选 分红
  IF I_MDLX = '2' THEN
    MERGE INTO PIF.TPIF_MDKH M
    USING (SELECT (SELECT ID
                     FROM PIF.TPIF_MDKHXX
                    WHERE KHBH = A.KHBH
                      AND CPDM = V_OBJ.CPDM) KHID,
                  A.KHBH,
                  A.FZJG,
                  A.JYRQ,
                  (A.RSSL - NVL(B.SHSL, 0)) DQFE, --当前份额
                  (SELECT FHFS FROM PIF.TPIF_CPDM WHERE CPID = V_OBJ.CPID) MRFHFS
             FROM (SELECT MAX(JYRQ) JYRQ, KHBH, KHXM, FZJG, SUM(CJSL) RSSL
                     FROM TPIF_MDKHLS
                    WHERE CPDM = V_OBJ.CPDM
                      AND YWBZ IN (44122, 44130, 44143, 44144)
                    GROUP BY KHBH, KHXM, FZJG) A
             LEFT JOIN (SELECT KHBH, SUM(CJSL) SHSL
                         FROM TPIF_MDKHLS
                        WHERE CPDM = V_OBJ.CPDM
                          AND YWBZ IN
                              (44124, 44126, 44142, 44145, 44150, 44151)
                        GROUP BY KHBH) B
               ON A.KHBH = B.KHBH
            WHERE A.RSSL - NVL(B.SHSL, 0) > 0) N
    ON (M.KHID = N.KHID AND M.MDID = I_ID)
    WHEN NOT MATCHED THEN
      INSERT
        (ID, MDID, KHID, KHBH, FZJG, FEQRR, DQFE, CXFE, XTFHHS, WCZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_MDKH'),
         I_ID,
         N.KHID,
         N.KHBH,
         N.FZJG,
         N.JYRQ,
         N.DQFE,
         N.DQFE,
         N.MRFHFS,
         0);
  ELSE
    --根据获取的最小份额确认日去表里面判断，小于本日期的所有记录数，所有持仓的和-所有赎回的数量，就是可赎回的数量
    --小于日期的最大一个值就是份额确认日
    MERGE INTO PIF.TPIF_MDKH M
    USING (SELECT (SELECT ID
                     FROM PIF.TPIF_MDKHXX
                    WHERE KHBH = A.KHBH
                      AND CPDM = V_OBJ.CPDM) KHID,
                  A.KHBH,
                  A.FZJG,
                  A.JYRQ,
                  (C.RSSL - NVL(D.SHSL, 0)) DQFE, --当前份额
                  (C.RSSL - NVL(D.SHSL, 0)-NVL(E.RSSL, 0)) CJSL, --成交数量
                  (SELECT FHFS FROM PIF.TPIF_CPDM WHERE CPID = V_OBJ.CPID) MRFHFS
             FROM (SELECT MAX(JYRQ) JYRQ, KHBH, KHXM, FZJG, SUM(CJSL) RSSL
                     FROM TPIF_MDKHLS
                    WHERE CPDM = V_OBJ.CPDM
                      AND YWBZ IN (44122, 44130, 44143, 44144)
                      AND JYRQ <= V_ZXFEQRR
                    GROUP BY KHBH, KHXM, FZJG) A
             LEFT JOIN (SELECT KHBH, SUM(CJSL) SHSL
                         FROM TPIF_MDKHLS
                        WHERE CPDM = V_OBJ.CPDM
                          AND YWBZ IN
                              (44124, 44126, 44142, 44145, 44150, 44151)
                          AND JYRQ <= V_ZXFEQRR
                        GROUP BY KHBH) B
               ON A.KHBH = B.KHBH
             LEFT JOIN (SELECT KHBH, SUM(CJSL) RSSL
                         FROM TPIF_MDKHLS
                        WHERE CPDM = V_OBJ.CPDM
                          AND YWBZ IN (44122, 44130, 44143, 44144)
                        GROUP BY KHBH, KHXM, FZJG) C
               ON A.KHBH = C.KHBH
             LEFT JOIN (SELECT KHBH, SUM(CJSL) SHSL
                         FROM TPIF_MDKHLS
                        WHERE CPDM = V_OBJ.CPDM
                          AND YWBZ IN
                              (44124, 44126, 44142, 44145, 44150, 44151)
                        GROUP BY KHBH) D
               ON A.KHBH = D.KHBH
             LEFT JOIN (SELECT KHBH, SUM(CJSL) RSSL
                         FROM TPIF_MDKHLS
                        WHERE CPDM = V_OBJ.CPDM
                          AND YWBZ IN (44122, 44130, 44143, 44144)
                          AND JYRQ > V_ZXFEQRR
                        GROUP BY KHBH, KHXM, FZJG) E
               ON A.KHBH = E.KHBH
            WHERE C.RSSL - NVL(D.SHSL, 0) > 0) N
    ON (M.KHID = N.KHID AND M.MDID = I_ID)
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         MDID,
         KHID,
         KHBH,
         FZJG,
         FEQRR,
         DQFE,
         CXFE,
         KSHFE,
         XTFHHS,
         WCZT)
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_MDKH'),
         I_ID,
         N.KHID,
         N.KHBH,
         N.FZJG,
         N.JYRQ,
         N.DQFE,
         N.DQFE,
         N.CJSL,
         N.MRFHFS,
         0);
  END IF;
  COMMIT;
  O_CODE := 1;
  O_NOTE := 'PIF.TPIF_MDKH  表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'PIF.TPIF_MDKH   表清洗,未知错误'
                ELSE
                 'PIF.TPIF_MDKH  ,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

