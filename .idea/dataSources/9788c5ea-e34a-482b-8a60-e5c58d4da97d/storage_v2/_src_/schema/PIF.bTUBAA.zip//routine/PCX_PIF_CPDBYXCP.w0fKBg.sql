create procedure pcx_pif_cpdbyxcp(o_code    out number,
                                                o_note    out varchar2,
                                                o_result  out sys_refcursor,
                                                i_userid   in number
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品列表-产品对比已选产品
  所属用户：PIF
  概要说明：查询产品对比已选产品.

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品对比已选产品.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/05/08     1.0.0.1   tumeng             新增.
      2020/07/22     1.0.0.2   tumeng             2个一下产品不能进行对比
  *********************************************************************************************************************/
  v_sql varchar2(32767);
  v_count number(10);
begin

  --初始化
  o_code := -1;
  o_note := '';
  --业务处理
/*  select count(1) into v_count from tpif_dbcplb where yh = i_userid;
  if v_count <=1 then
    o_code := 99;
    o_note := '选中产品不足2个，请至少选择2个产品进行对比！';
    return;
  end if;*/
  
  v_sql := 'select cpid prod_id,
                   cpdm prod_code,
                   cpmc prod_name
                   from pif.tpif_dbcplb
                   where yh = ' || i_userid;

  open o_result for v_sql;

  o_code := 1;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
select '异常信息：' || o_note from dual;

end pcx_pif_cpdbyxcp;
/

