create procedure PRO_PIF_ZDXS_CPXZ(O_CODE           OUT NUMBER,
                                              O_NOTE           OUT VARCHAR2,
                                              I_ZDXS_CPID      IN NUMBER, --获取表格内容，无实际意义
                                              I_CPID           IN NUMBER,  --产品id
                                              I_CPDM           IN VARCHAR2, --产品代码，给这个产品打标签
                                              I_USERID         IN NUMBER --用户id
                                                 ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：重点销售产品管理----新增产品 表格形式 所用过程

      表格需要一个父对象id，明确是哪条记录的表格内容，此处为自由操作的新增，
      实际上这个表格并不属于任何记录，所以取了一个临时的记录id

      每次都清空表格TPIF_ZDXS_CP_YYXX，该表格仅作为中间表插入数据用

      语法信息：
           输入参数：

           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-05-17     1.0.0     hqn                 新增
  ***********************************************************************/
  V_COUNT NUMBER := 0;
  V_COUNT1 NUMBER := 0;
  V_BQMC  VARCHAR2(200);

BEGIN
  O_CODE := -1;
  O_NOTE := '';
  --CHECK
  SELECT COUNT(1)
    INTO V_COUNT
    FROM PIF.TPIF_ZDXS_CP_YYXX
   WHERE TPIF_ZDXS_CP_ID = I_ZDXS_CPID
     AND LX = 1;
  
   SELECT COUNT(1)
    INTO V_COUNT1
    FROM PIF.TPIF_ZDXS_CP_YYXX
   WHERE TPIF_ZDXS_CP_ID = I_ZDXS_CPID
     AND LX = 2;
  
  IF V_COUNT>1 OR V_COUNT1>1 THEN
     O_CODE := -1;
     O_NOTE := '该类型已存在，请确认！';
  
  ELSE  
  --表格对象插入运营信息表
    MERGE INTO TPIF_ZDXS_CPYYXX T
    USING (SELECT M.ID,
                  M.LX,
                  M.NR,
                  N.CPKID AS CPKID,
                  N.CPID,
                  M.TPIF_ZDXS_CP_ID,
                  M.LDMC
            FROM  TPIF_ZDXS_CP_YYXX M,TPIF_ZDXS_CP N WHERE M.TPIF_ZDXS_CP_ID=N.ID AND M.TPIF_ZDXS_CP_ID= I_ZDXS_CPID
        )S
    ON (T.ZDCPGLID=S.TPIF_ZDXS_CP_ID)
    WHEN NOT MATCHED THEN
      INSERT(T.ID, T.CPKID,T.YYXXID,T.CPID, T.ZDCPGLID, T.LX, T.LDMC, T.NR, T.CZR, T.CZSJ,T.SFSC)
      VALUES(LIVEBOS.FUNC_NEXTID('tpif_zdxs_cpyyxx'),S.CPKID,S.ID,S.CPID, S.TPIF_ZDXS_CP_ID, S.LX, S.LDMC, S.nr,I_USERID,SYSDATE,0 );
  
    --表格对象插入宣传链接表
    MERGE INTO TPIF_ZDXS_CPXCLJ T
    USING (SELECT ID,
                  XCBQ,
                  XCLX,
                  GGLX,
                  GGID,
                  XCBT,
                  FJ,
                  XCKSRQ,
                  XCJSRQ,
                  TPIF_ZDXS_CP_ID,
                  URL
            FROM  TPIF_ZDXS_CP_XCLJ
           WHERE  TPIF_ZDXS_CP_ID=I_ZDXS_CPID
             AND  YID IS NULL       
                  )S
         ON (T.ZDCPGLID=S.TPIF_ZDXS_CP_ID )            
    WHEN NOT MATCHED THEN 
      INSERT (T.ID,T.ZDCPGLID,T.XCLJID,T.CPID,T.CPDM,T.XCBQ,T.XCLX,T.GGLX,T.GGID,T.XCBT,T.FJ,T.XCKSRQ,T.XCJSRQ,T.CZR,T.CZSJ,T.SFSC,T.OSSURL)
      VALUES (LIVEBOS.FUNC_NEXTID('TPIF_ZDXS_CPXCLJ'),S.TPIF_ZDXS_CP_ID,S.ID,I_CPID,I_CPDM,S.XCBQ,S.XCLX,S.GGLX,S.GGID,S.XCBT,S.FJ,S.XCKSRQ,S.XCJSRQ,I_USERID,SYSDATE,0,S.URL);
      
      --删除宣传链接
      UPDATE TPIF_ZDXS_CPXCLJ A
         SET SFSC=1
       WHERE A.CPID=I_CPID 
         AND NOT EXISTS(SELECT 1 FROM TPIF_ZDXS_CP_XCLJ WHERE TPIF_ZDXS_CP_ID=I_ZDXS_CPID AND (YID=A.XCLJID OR ID=A.XCLJID));
       
      --补充表格对象附件 
      UPDATE TPIF_ZDXS_CP_XCLJ A
        SET FJ=(SELECT FJ FROM TPIF_ZDXS_CPXCLJ WHERE XCLJID=A.YID)
       WHERE A.TPIF_ZDXS_CP_ID=I_ZDXS_CPID
        AND A.YID IS NOT NULL
        AND EXISTS(SELECT 1 FROM TPIF_ZDXS_CPXCLJ WHERE XCLJID=A.YID AND FJ IS NOT NULL);
        
        
    O_CODE := 199;
    O_NOTE := '新增成功';
  COMMIT;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

