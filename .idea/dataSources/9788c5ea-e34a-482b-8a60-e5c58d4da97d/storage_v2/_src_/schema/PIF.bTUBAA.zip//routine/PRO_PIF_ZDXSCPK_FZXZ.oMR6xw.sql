create PROCEDURE PRO_PIF_ZDXSCPK_FZXZ(O_CODE      OUT NUMBER,
                                                 O_NOTE      OUT VARCHAR2,
                                                 O_SUM       OUT NUMBER, --新增记录数量
                                                 O_SUM_EXIST OUT NUMBER, --已存在记录数量
                                                 I_IDS       IN VARCHAR2, --选中的记录的ID串
                                                 I_TJYF      IN NUMBER, --添加月份
                                                 I_USERID    IN NUMBER) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：优选基金批量复制新增
      语法信息：
  
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-04-01     1.0.0     高昆                创建
          2021-07-27     1.0.1     hanqiaonan          复制优选产品系列
  ***********************************************************************/

  V_COUNT     NUMBER; --用于判断指定月份是否存在该产品
  V_IDS       VARCHAR2(2000); --选中的记录的 ID串，分号分隔  '900125;900065'
  V_SUM       NUMBER := 0; --记录新增了多少条数据
  V_SUM_EXIST NUMBER := 0; --已存在记录数量，已存在的不新增

BEGIN
  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_USERID不能为空！';
    RETURN;
  END IF;

  IF I_IDS IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'I_IDS不能为空！';
    RETURN;
  ELSE
    V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''),
                             ']',
                             ''),
                     ',',
                     ';');
  END IF; --     '[900125,900065]' ----->   '900125;900065'

  FOR CUR IN (SELECT *
                FROM TPIF_CPDM_ZDXS
               WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0) LOOP
  
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_CPDM_ZDXS
     WHERE TJYF = I_TJYF
       AND CPBQID = CUR.CPBQID --优选1 
       AND CPID = CUR.CPID; --优选基金只从正式库取数据
  
    IF V_COUNT = 0 THEN
      --指定月份不存在才新增
      INSERT INTO TPIF_CPDM_ZDXS
        (ID,
         TJYF, --添加月份
         CPBQID, --产品主题  新发2、优选1
         LRLX, --数据录入来源  1|正式库;2|备选库
         CPID, --正式产品标识
         BXCPID, --备选产品标识
         CPXL, --产品系列
         JRCPFL, --金融产品分类
         SFCY, --首发/持营
         CPDM, --产品代码
         CPMC,
         CPFXDJ,
         CPJYZT,
         RGKSRQ,
         RGJSRQ,
         CPGLR,
         CPBZ, --产品备注
         SHZT, --审核状态 1正常
         ZT, --状态 1启用
         CPRCSJ,
         CZR,
         CZSJ,
         YXCPXL --优选产品系列
         )
      VALUES
        (LIVEBOS.FUNC_NEXTID('TPIF_CPDM_ZDXS'),
         I_TJYF,
         CUR.CPBQID,
         CUR.LRLX,
         CUR.CPID,
         CUR.BXCPID,
         CUR.CPXL,
         CUR.JRCPFL,
         CUR.SFCY,
         CUR.CPDM,
         CUR.CPMC,
         CUR.CPFXDJ,
         CUR.CPJYZT,
         CUR.RGKSRQ,
         CUR.RGJSRQ,
         CUR.CPGLR,
         CUR.CPBZ,
         1,
         1,
         SYSDATE,
         I_USERID,
         SYSDATE,
         CUR.YXCPXL);
      V_SUM := V_SUM + 1; --记录新增数量
    ELSE
      V_SUM_EXIST := V_SUM_EXIST + 1; --记录已存在数量
    END IF;
  END LOOP;

  O_SUM_EXIST := V_SUM_EXIST;
  O_SUM       := V_SUM;
  O_CODE      := 1;
  O_NOTE      := '成功！';
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
END;
/

