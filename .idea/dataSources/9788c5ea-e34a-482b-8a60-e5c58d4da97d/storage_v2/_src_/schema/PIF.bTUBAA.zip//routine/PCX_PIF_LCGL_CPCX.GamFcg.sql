create PROCEDURE PCX_PIF_LCGL_CPCX(O_CODE         OUT NUMBER,
                                              O_NOTE         OUT VARCHAR2,
                                              O_RESULT       OUT SYS_REFCURSOR,
                                              I_USERID       IN NUMBER, --登陆用户ID
                                              I_PROD_TYPE    IN VARCHAR2, -- 产品类型，多值选择项，分号“;“分隔
                                              I_PROD_MANAGER IN VARCHAR2, --产品管理人ID
                                              I_PROD_NAME    IN VARCHAR2 --产品代码/名称
                                              ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 流程管理-产品信息模糊查询（仅指有审批记录的产品）
  
      语法信息：
           输入参数：   I_USERID          IN NUMBER,   --登陆用户ID
                       I_PROD_TYPE       IN VARCHAR2  --产品类型，多值选择项，分号“;“分隔
                       I_PROD_MANAGER    IN VARCHAR2, --产品管理人ID
                       I_PROD_NAME       IN VARCHAR2  --产品代码/名称
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/
  V_SQL            VARCHAR2(20000);
  V_PROCESS_STATUS VARCHAR2(20000);
  V_STATUS         VARCHAR2(2000);
  V_LCGZ_URL       VARCHAR2(20000); 

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  IF I_PROD_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_PROD_TYPE 不允许为空！';
    RETURN;
  END IF;

  /*  PROD_ID 产品ID
       PROD_CODE 产品代码
       PROD_NAME 产品名称
       PROD_TYPE 产品类型
       PROD_RISK_LEVEL 产品风险等级
       SUBSCRIBE_ORIGIN  认购起点(元)
       PROCESS_STATUS  流程状态
       REMARKS 备注
  */

  --公募基金
  V_PROCESS_STATUS := '''[';
  --IF I_PROD_TYPE = 1 THEN

  V_SQL := ' SELECT A.CPID   AS PROD_ID,
                    A.CPDM   AS PROD_CODE,
                    A.CPMC   AS PROD_NAME, 
                    (SELECT T.NOTE FROM LIVEBOS.TXTDM T WHERE T.FLDM=''PIF_CPXL_CPZX'' AND T.IBM=A.CPXL) AS PROD_TYPE,
                    (SELECT T.NOTE FROM LIVEBOS.TXTDM T WHERE T.FLDM=''PIF_CPFXDJ_CPZX'' AND T.IBM=A.CPFXDJ) AS PROD_RISK_LEVEL,
                        ';
  --拼接 {"ID": "1","STATUS": "2"},    
  --ID是流程的ID，无实际意义，状态是该产品的该流程目前的状态     
  FOR CUR_LC IN (SELECT A.LCID, A.JB, B.YXXPDLJ, B.LCFQ_URL, B.LCGZ_URL
                   FROM TPIF_CPLCPZ A, TPIF_LCDJ B
                  WHERE A.LCID = B.ID
                    AND INSTR(';' || A.CPXL || ';',
                              ';' || I_PROD_TYPE || ';') > 0
                  ORDER BY A.JB ASC) LOOP
  
    --判断流程进度
    --#CPID表示产品ID 、#CPDM表示产品代码、 #GLR 表示管理人、#CPXL 表示产品系列 、#SYSDATE 表示当前日期
    SELECT REPLACE(REPLACE(REPLACE(REPLACE(CUR_LC.YXXPDLJ,
                                           '#CPID',
                                           'A.CPID'),
                                   '#CPDM',
                                   'A.CPDM'),
                           '#GLR',
                           'A.CPGLRID'),
                   '#CPXL',
                   'A.CPXL')
      INTO V_STATUS
      FROM DUAL;
      
    --取流程ID
    IF CUR_LC.LCGZ_URL IS NOT NULL THEN
    
      SELECT REPLACE(CUR_LC.LCGZ_URL,
                     '#LCID',
                     '''||(SELECT MAX(M.LCID)  ' ||
                     SUBSTR(V_STATUS, INSTR(V_STATUS, 'FROM')) || ')||''')
        INTO V_LCGZ_URL
        FROM DUAL;
    
    ELSE
    
      V_LCGZ_URL := '';
    
    END IF;
  
    V_PROCESS_STATUS := V_PROCESS_STATUS || '{"ID":"' || CUR_LC.LCID ||
                        '","STATUS":"''||(' || V_STATUS ||
                        ')||''","PROCESS_TRACKING_URL":"' || V_LCGZ_URL ||
                        '","PROCESS_START_URL":"' || CUR_LC.LCFQ_URL ||
                        '"},';
  
  END LOOP;

  V_SQL := V_SQL || RTRIM(V_PROCESS_STATUS, ',') || ']' ||
           ''' AS SUBSCRIBE_ORIGIN,
          NULL AS REMARKS                
          FROM TPIF_CPDM A
         WHERE INSTR('';' || I_PROD_TYPE ||
           ';'', '';'' || A.CPXL || '';'') > 0 
                  --AND A.CPXL > 0 
                  --AND A.CPGLRID IS NOT NULL
                  AND A.CPNBZT IN(0,1,2)   ';
  --END IF;
  /*
    --私募基金
    V_PROCESS_STATUS := '''[';
    IF I_PROD_TYPE = 2 THEN
    
      V_SQL := ' SELECT A.CPID   AS PROD_ID,
                          A.CPDM   AS PROD_CODE,
                          A.CPMC   AS PROD_NAME, 
                          NULL AS PROD_TYPE,
                          (SELECT JGMC FROM PIF.TPIF_JGDM WHERE ID=A.CPGLRID) AS PROD_RISK_LEVEL,
                          ';
      --拼接 {"ID": "1","STATUS": "2"},         
      FOR CUR_LC IN (SELECT A.LCID, A.JB, B.YXXPDLJ, B.LCFQ_URL, B.LCGZ_URL
                       FROM TPIF_CPLCPZ A, TPIF_LCDJ B
                      WHERE A.LCID = B.ID
                        AND INSTR(';' || A.CPXL || ';', ';' || I_PROD_TYPE || ';') > 0
                      ORDER BY A.JB ASC) LOOP
      
        --判断流程进度
        --#CPID表示产品ID 、#CPDM表示产品代码、 #GLR 表示管理人、#CPXL 表示产品系列 、#SYSDATE 表示当前日期
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(CUR_LC.YXXPDLJ, '#CPID', 'A.CPID'), '#CPDM', 'A.CPDM'), '#GLR', 'A.CPGLRID'), '#CPXL', 'A.CPXL')
          INTO V_STATUS
          FROM DUAL;
      
        ---SELECT NVL(MAX(SHZT),0) FROM PIF.LCJRCPDXPJLC WHERE CPID = #CPID
        IF CUR_LC.LCGZ_URL IS NOT NULL THEN
        
          SELECT REPLACE(CUR_LC.LCGZ_URL, '#LCID', '''||(SELECT MAX(ID)  ' ||
                          SUBSTR(V_STATUS, INSTR(V_STATUS, 'FROM')) ||
                          ')||''')
            INTO V_LCGZ_URL
            FROM DUAL;
        
        ELSE
        
          V_LCGZ_URL := '';
        
        END IF;
      
        V_PROCESS_STATUS := V_PROCESS_STATUS || '{"ID":"' || CUR_LC.LCID ||
                            '","STATUS":"''||(' || V_STATUS ||
                            ')||''","PROCESS_TRACKING_URL":"' || V_LCGZ_URL ||
                            '","PROCESS_START_URL":"' || CUR_LC.LCFQ_URL ||
                            '"},';
      
      END LOOP;
    
      V_SQL := V_SQL || RTRIM(V_PROCESS_STATUS, ',') || ']' ||
               ''' AS SUBSCRIBE_ORIGIN, NULL AS REMARKS                
               FROM TPIF_CPDM A
                 WHERE INSTR('';' || I_PROD_TYPE ||
               ';'', '';'' || A.CPXL || '';'') > 0 
                    AND A.CPXL > 0 
                    AND A.CPGLRID IS NOT NULL
                    AND A.ID IN(SELECT CPID FROM PIF.LCCPCSSZ)  ';
    END IF;
  
    --券商资管
    V_PROCESS_STATUS := '''[';
    IF I_PROD_TYPE = 3 THEN
    
      V_SQL := ' SELECT A.CPID   AS PROD_ID,
                          A.CPDM   AS PROD_CODE,
                          A.CPMC   AS PROD_NAME, 
                          NULL AS PROD_TYPE,
                          (SELECT JGMC FROM PIF.TPIF_JGDM WHERE ID=A.CPGLRID) AS PROD_RISK_LEVEL,
                          ';
      --拼接 {"ID": "1","STATUS": "2"},         
      FOR CUR_LC IN (SELECT A.LCID, A.JB, B.YXXPDLJ, B.LCFQ_URL, B.LCGZ_URL
                       FROM TPIF_CPLCPZ A, TPIF_LCDJ B
                      WHERE A.LCID = B.ID
                        AND INSTR(';' || A.CPXL || ';', ';' || I_PROD_TYPE || ';') > 0
                      ORDER BY A.JB ASC) LOOP
      
        --判断流程进度
        --#CPID表示产品ID 、#CPDM表示产品代码、 #GLR 表示管理人、#CPXL 表示产品系列 、#SYSDATE 表示当前日期
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(CUR_LC.YXXPDLJ, '#CPID', 'A.CPID'), '#CPDM', 'A.CPDM'), '#GLR', 'A.CPGLRID'), '#CPXL', 'A.CPXL')
          INTO V_STATUS
          FROM DUAL;
      
        ---SELECT NVL(MAX(SHZT),0) FROM PIF.LCJRCPDXPJLC WHERE CPID = #CPID
        IF CUR_LC.LCGZ_URL IS NOT NULL THEN
        
          SELECT REPLACE(CUR_LC.LCGZ_URL, '#LCID', '''||(SELECT MAX(ID)  ' ||
                          SUBSTR(V_STATUS, INSTR(V_STATUS, 'FROM')) ||
                          ')||''')
            INTO V_LCGZ_URL
            FROM DUAL;
        
        ELSE
        
          V_LCGZ_URL := '';
        
        END IF;
      
        V_PROCESS_STATUS := V_PROCESS_STATUS || '{"ID":"' || CUR_LC.LCID ||
                            '","STATUS":"''||(' || V_STATUS ||
                            ')||''","PROCESS_TRACKING_URL":"' || V_LCGZ_URL ||
                            '","PROCESS_START_URL":"' || CUR_LC.LCFQ_URL ||
                            '"},';
      
      END LOOP;
    
      V_SQL := V_SQL || RTRIM(V_PROCESS_STATUS, ',') || ']' ||
               ''' AS SUBSCRIBE_ORIGIN, NULL AS REMARKS                
               FROM TPIF_CPDM A
                 WHERE INSTR('';' || I_PROD_TYPE ||
               ';'', '';'' || A.CPXL || '';'') > 0 
                    AND A.CPXL > 0 
                    AND A.CPGLRID IS NOT NULL
                    AND A.CPDM IN (SELECT CPDM FROM PIF.TPIF_ZGCPYSLR) ';
    END IF;
  
    --收益凭证
    V_PROCESS_STATUS := '''[';
    IF I_PROD_TYPE = 4 THEN
    
      V_SQL := ' SELECT A.CPID   AS PROD_ID,
                          A.CPDM   AS PROD_CODE,
                          A.CPMC   AS PROD_NAME, 
                          NULL AS PROD_TYPE,
                          (SELECT JGMC FROM PIF.TPIF_JGDM WHERE ID=A.CPGLRID) AS PROD_RISK_LEVEL,
                          ';
      --拼接 {"ID": "1","STATUS": "2"},         
      FOR CUR_LC IN (SELECT A.LCID, A.JB, B.YXXPDLJ, B.LCFQ_URL, B.LCGZ_URL
                       FROM TPIF_CPLCPZ A, TPIF_LCDJ B
                      WHERE A.LCID = B.ID
                        AND INSTR(';' || A.CPXL || ';', ';' || I_PROD_TYPE || ';') > 0
                      ORDER BY A.JB ASC) LOOP
      
        --判断流程进度
        --#CPID表示产品ID 、#CPDM表示产品代码、 #GLR 表示管理人、#CPXL 表示产品系列 、#SYSDATE 表示当前日期
        SELECT REPLACE(REPLACE(REPLACE(REPLACE(CUR_LC.YXXPDLJ, '#CPID', 'A.CPID'), '#CPDM', 'A.CPDM'), '#GLR', 'A.CPGLRID'), '#CPXL', 'A.CPXL')
          INTO V_STATUS
          FROM DUAL;
      
        ---SELECT NVL(MAX(SHZT),0) FROM PIF.LCJRCPDXPJLC WHERE CPID = #CPID
        IF CUR_LC.LCGZ_URL IS NOT NULL THEN
        
          SELECT REPLACE(CUR_LC.LCGZ_URL, '#LCID', '''||(SELECT MAX(ID)  ' ||
                          SUBSTR(V_STATUS, INSTR(V_STATUS, 'FROM')) ||
                          ')||''')
            INTO V_LCGZ_URL
            FROM DUAL;
        
        ELSE
        
          V_LCGZ_URL := '';
        
        END IF;
      
        V_PROCESS_STATUS := V_PROCESS_STATUS || '{"ID":"' || CUR_LC.LCID ||
                            '","STATUS":"''||(' || V_STATUS ||
                            ')||''","PROCESS_TRACKING_URL":"' || V_LCGZ_URL ||
                            '","PROCESS_START_URL":"' || CUR_LC.LCFQ_URL ||
                            '"},';
      
      END LOOP;
    
      V_SQL := V_SQL || RTRIM(V_PROCESS_STATUS, ',') || ']' ||
               ''' AS SUBSCRIBE_ORIGIN, NULL AS REMARKS                
               FROM TPIF_CPDM A
                 WHERE INSTR('';' || I_PROD_TYPE ||
               ';'', '';'' || A.CPXL || '';'') > 0 
                    AND A.CPXL > 0 
                    AND A.CPGLRID IS NOT NULL
                    AND A.CPDM IN(SELECT CPDM FROM PIF.TPIF_SYPZ_DMSQ)  ';
    END IF;
  */

  --产品管理人ID
  IF I_PROD_MANAGER IS NOT NULL THEN
  
    V_SQL := V_SQL || '  AND  A.CPGLRID = ' || I_PROD_MANAGER;
  
  END IF;

  --产品代码、名称
  IF I_PROD_NAME IS NOT NULL THEN
  
    V_SQL := V_SQL || '  AND (  A.CPMC LIKE ''%' || I_PROD_NAME || '%''
    OR A.CPJC LIKE ''%' || I_PROD_NAME || '%''
    OR A.CPDM LIKE ''%' || I_PROD_NAME || '%'' )';
  
  END IF;

  DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
  
END;
/

