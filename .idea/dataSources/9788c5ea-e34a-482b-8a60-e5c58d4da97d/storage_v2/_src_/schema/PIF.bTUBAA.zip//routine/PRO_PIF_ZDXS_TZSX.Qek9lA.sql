create PROCEDURE PRO_PIF_ZDXS_TZSX(O_CODE  OUT NUMBER, --返回值
                                              O_NOTE  OUT VARCHAR2, --返回消息
                                              I_TYPE  IN INTEGER, --操作类型 1|产品库，2|产品
                                              I_CPKID IN INTEGER --产品库id
                                              ) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：重点销售产品管理-调整顺序
      语法信息：
           输入参数：I_CPKID IN INTEGER --产品库id
  
           输出参数：O_CODE OUT NUMBER, --返回值
                     O_NOTE OUT VARCHAR2, --返回消息
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-06-15     1.0.1     HQN                新增
          2021-08-24     1.0.2     HQN                增加产品库排序
  ***********************************************************************/
  V_COUNT  INTEGER; --计数变量
  V_COUNT1 INTEGER; --计数变量1
  V_CPKID  INTEGER; --产品库id
  V_QXBZ   INTEGER; --权限标识
  V_ID     INTEGER;
  V_ZHID   INTEGER; --置换id
  V_ZHSX   INTEGER; --置换顺序
  V_ZSSX   INTEGER := 1; --显示排序
  V_ZDSX   INTEGER := 1; --置顶顺序
  V_OBJ    TPIF_CPBQMX%ROWTYPE; --表单记录
  V_SFZD   INTEGER; --是否置顶
  V_CZSM   VARCHAR2(2000); --日志操作明细
BEGIN
  --INIT
  O_CODE := 1;
  O_NOTE := '';
  
  --调整产品顺序
  IF I_TYPE=1 THEN
    FOR CUR_CPK IN (SELECT *
                       FROM TPIF_ZDXS_CPK T
                      WHERE ZT=1
                        AND INSTR(T.QD,'1')>0
                      ORDER BY ZSSX) LOOP
        UPDATE TPIF_ZDXS_CPK SET ZSSX = V_ZSSX WHERE ID = CUR_CPK.ID;
        V_ZSSX := V_ZSSX + 1;
    END LOOP;
    UPDATE TPIF_ZDXS_CPK SET ZSSX=NULL WHERE INSTR(QD,'1')=0 OR ZT=0; --非鑫财富产品库无顺序
  END IF;
  
  --调整产品顺序
  IF I_TYPE = 2 THEN
    --CHECK
    IF I_CPKID IS NULL THEN
      O_NOTE := '产品库ID不能为空!';
      RETURN;
    END IF;
    --START
    O_NOTE := '操作成功';
  
    --获取是否置顶，置顶顺序，展示顺序和产品库
    SELECT COUNT(1)
      INTO V_COUNT
      FROM TPIF_ZDXS_CP
     WHERE CPKID = I_CPKID
       AND SFZD = 1
       AND SFSC = 0;
  
    --重置置顶顺序
    IF V_COUNT > 0 THEN
      FOR CUR_ZD IN (SELECT *
                       FROM TPIF_ZDXS_CP
                      WHERE CPKID = I_CPKID
                        AND SFSC = 0
                        AND SFZD = 1
                      ORDER BY ZDSX) LOOP
        UPDATE TPIF_ZDXS_CP SET ZDSX = V_ZDSX WHERE ID = CUR_ZD.ID;
        V_ZDSX := V_ZDSX + 1;
      END LOOP;
    END IF;
  
    SELECT COUNT(1)
      INTO V_COUNT1
      FROM TPIF_ZDXS_CP
     WHERE CPKID = I_CPKID
       AND SFSC = 0;
  
    --重置展示顺序
    IF V_COUNT1 > 0 THEN
      FOR CUR IN (SELECT *
                    FROM TPIF_ZDXS_CP
                   WHERE CPKID = I_CPKID
                     AND SFSC = 0
                   ORDER BY ZSSX) LOOP
        UPDATE TPIF_ZDXS_CP SET ZSSX = V_ZSSX WHERE ID = CUR.ID;
        V_ZSSX := V_ZSSX + 1;
      END LOOP;
    END IF;
  
  END IF;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_ZDXS_TZSX;
/

