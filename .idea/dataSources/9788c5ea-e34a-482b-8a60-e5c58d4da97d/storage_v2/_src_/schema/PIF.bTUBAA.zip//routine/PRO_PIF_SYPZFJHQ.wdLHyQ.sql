create PROCEDURE PRO_PIF_SYPZFJHQ(I_LCID IN NUMBER --流程ID
                                             ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品代销评价 分数保存
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-08-09     1.0       洪国力              创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_RQ    VARCHAR2(20) := TO_CHAR(SYSDATE, 'YYYY-MM-DD');
BEGIN
  --INIT
  --O_CODE := -1;
  --O_NOTE := '';
  SELECT COUNT(*) INTO V_COUNT FROM LCSYPZFXSP A WHERE A.ID = I_LCID;

  IF V_COUNT > 0 THEN

    UPDATE LCSYPZFXSP A
       SET A.FJ = '{"items":[["0","SYPZ' || V_RQ || '.zip"]],"nextId":1}'
     WHERE A.ID = I_LCID;

  END IF;

  COMMIT;
  --O_CODE := 1;
  --O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --O_CODE := -1;
  /* O_NOTE := (CASE
    WHEN O_NOTE IS NULL THEN
     '未知错误'
    ELSE
     O_NOTE || ' 时出现异常'
  END) || ':' || SQLERRM;*/
END;
/

