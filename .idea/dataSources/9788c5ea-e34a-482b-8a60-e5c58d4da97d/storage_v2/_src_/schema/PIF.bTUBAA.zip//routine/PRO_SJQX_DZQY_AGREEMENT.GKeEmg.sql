create PROCEDURE pro_sjqx_dzqy_agreement
(
    O_CODE OUT NUMBER, --返回值
    O_NOTE OUT VARCHAR2 --返回消息
) IS

    /******************************************************************
        所属用户：PIF
        功能说明：电子签约项目表 pif.dzqy_project 数据清洗逻辑
        语法信息：
             输入参数：   无
             输出参数：   O_CODE  返回值
                          O_NOTE  返回消息
        逻辑说明：

        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2022-1-5       1.0       HANQN              创建

    ***********************************************************************/

BEGIN
    O_CODE := -1;
    O_NOTE := '';

      MERGE INTO DSC_STAT.TPIF_YYCZXX B
      USING(
    SELECT CLIENT_ID      AS KHH,
           PROD_CODE      AS CPDM,
           FUND_ACCOUNT   AS ZJZH,
           E.ID AS SSYYB,
           CURRENT_AMOUNT AS DQSL,
           UPDATE_TIME
    FROM   (SELECT A.* ,
           ROW_NUMBER() OVER(PARTITION BY FUND_ACCOUNT, PROD_CODE ORDER BY UPDATE_TIME DESC) RN
    FROM   SRC_PIF.DWD_AST_ACC_PRODVALUE_DI_SPEC A ) T
    LEFT JOIN SRC_PIF.DIM_BRANCH_INFO D  ON    T.BRANCH_NO = D.BRANCH_ID
    LEFT JOIN  LIVEBOS.LBORGANIZATION E  ON D.NEW_BRANCH_ID = E.BRANCH_ID
WHERE RN=1) C
ON (B.KHH=C.KHH AND B.CPDM =C.CPDM AND B.ZJZH = C.ZJZH)
WHEN MATCHED THEN
        UPDATE
        SET
               B.SSYYB = C.SSYYB,
               B.DQSL = C.DQSL,
              B.UPDATE_TIME = C.UPDATE_TIME
WHEN NOT MATCHED THEN
        INSERT (B.KHH,
             B.ZJZH,
             B.SSYYB,
             B.DQSL,
             B.CPDM,
             B.UPDATE_TIME

             )
        VALUES
            (C.KHH,
             C.ZJZH,
             C.SSYYB,
             C.DQSL,
             C.CPDM,
             C.UPDATE_TIME);

    COMMIT;
    O_CODE := 1;
    O_NOTE := 'DSC_STAT.TPIF_YYCZXX  表清洗成功';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        O_CODE := -1;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       'DSC_STAT.TPIF_YYCZXX  表清洗,未知错误'
                      ELSE
                       'DSC_STAT.TPIF_YYCZXX ,在 ' || O_NOTE ||
                       ' 时出现异常'
                  END) || ':' || SQLERRM;
END;
/

