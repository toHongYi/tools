create PROCEDURE PCX_JGHX_DBCPSYXX(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              I_USERID IN NUMBER, --用户ID
                                              I_ORGID  IN NUMBER --机构ID
                                              ) AS
  /******************************************************************
  项目名称：财通证券运营展业平台-H5机构画像
  所属用户：PIF
  概要说明：代表产品收益信息查询
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回结果集
       输入参数：
          见参数定义部分
  
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/12/17     1.0.0.1   GAOKUN            新增.
  ********************************************************************/
  V_FUND_ID   NUMBER; --记录该机构的代表产品ID
  V_FUND_NAME VARCHAR2(200); --代表产品名称
  V_ZXJZRQ    NUMBER; --最新净值日期
  V_ZXDWJZ    NUMBER; --最新单位净值

  V_ZDF    NUMBER; --单位净值涨跌幅（较上一净值数据）
  V_NHSYL  NUMBER; --年化收益率(今年以来)
  V_J1YSYL NUMBER; --近一月收益率
  V_J3YSYL NUMBER;
  V_J6YSYL NUMBER;
  V_J1NSYL NUMBER; --近一年收益率
  V_J3NSYL NUMBER;
  V_JNYL   NUMBER; --今年以来收益率

  V_TS            NUMBER; --区间天数
  V_END_ADDED_NAV NUMBER; --结束累计净值
  V_1YQ           DATE;
  V_3YQ           DATE;
  V_6YQ           DATE;
  V_1NQ           DATE;
  V_3NQ           DATE;
  V_COUNT         NUMBER;

BEGIN
  O_CODE := 1;
  O_NOTE := '成功！';

  IF I_ORGID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '机构ID不允许为空！';
    RETURN;
  END IF;

  --根据机构ID获取代表产品ID和代表产品名称
  SELECT COUNT(*)
    INTO V_COUNT
    FROM SRC_PIF.T_FUND_ORG
   WHERE ORG_ID = I_ORGID;

  IF V_COUNT = 0 THEN
  
    O_CODE := 99;
    O_NOTE := '该机构代表产品为空！';
    RETURN;
  
  ELSE
        
      SELECT REPRESENTATIVE_FUND_ID, REPRESENTATIVE_FUND
        INTO V_FUND_ID, V_FUND_NAME
        FROM SRC_PIF.T_FUND_ORG
       WHERE ORG_ID = I_ORGID;
  
    SELECT COUNT(*)
      INTO V_COUNT
      FROM SRC_PIF.T_FUND_NV_DATA_ZYYX
     WHERE FUND_ID = V_FUND_ID;
  
    IF V_COUNT = 0 THEN
    
      O_CODE := 99;
      O_NOTE := '该机构代表产品无净值数据！';
      RETURN;
    
    ELSE

    
      --最新净值日期、最新单位净值
      SELECT TO_NUMBER(TO_CHAR(STATISTIC_DATE, 'YYYYMMDD')), NAV, ADDED_NAV
        INTO V_ZXJZRQ, V_ZXDWJZ, V_END_ADDED_NAV
        FROM SRC_PIF.T_FUND_NV_DATA_ZYYX
       WHERE FUND_ID = V_FUND_ID
         AND ROWNUM = 1
       ORDER BY STATISTIC_DATE DESC;
    
      --根据当前最新净值日期获取之前的日期
      SELECT ADD_MONTHS(TO_DATE(TO_CHAR(V_ZXJZRQ), 'YYYYMMDD'), -1),
             ADD_MONTHS(TO_DATE(TO_CHAR(V_ZXJZRQ), 'YYYYMMDD'), -3),
             ADD_MONTHS(TO_DATE(TO_CHAR(V_ZXJZRQ), 'YYYYMMDD'), -6),
             ADD_MONTHS(TO_DATE(TO_CHAR(V_ZXJZRQ), 'YYYYMMDD'), -12),
             ADD_MONTHS(TO_DATE(TO_CHAR(V_ZXJZRQ), 'YYYYMMDD'), -36)
        INTO V_1YQ, V_3YQ, V_6YQ, V_1NQ, V_3NQ
        FROM DUAL;
    
      --获取区间天数
      SELECT COUNT(*)
        INTO V_TS
        FROM LIVEBOS.TXTJYR
       WHERE ZRR >= SUBSTR(V_ZXJZRQ, 1, 4) || '0101'
         AND ZRR <= V_ZXJZRQ;
    
      --单位净值涨跌幅
      BEGIN
      
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_ZDF
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MAX(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE TO_NUMBER(TO_CHAR(B.STATISTIC_DATE, 'YYYYMMDD')) <
                       V_ZXJZRQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          V_ZDF := NULL;
        
      END;
    
      --当年年化收益=365*（累计净值涨跌幅/产品区间天数）
      BEGIN
      
        SELECT (CASE
                 WHEN NVL(ADDED_NAV, 0) = 0 THEN
                  0
                 ELSE
                  360 * ((NVL(V_END_ADDED_NAV, 0) - NVL(ADDED_NAV, 0)) /
                  NVL(ADDED_NAV, 0)) / NVL(V_TS, 9999999999)
               END)
          INTO V_NHSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.FUND_ID = V_FUND_ID
                   AND SUBSTR(TO_CHAR(B.STATISTIC_DATE, 'YYYYMMDD'), 1, 4) =
                       SUBSTR(V_ZXJZRQ, 1, 4))
           AND A.FUND_ID = V_FUND_ID;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          V_NHSYL := NULL;
        
      END;
    
      BEGIN
      
        --今年以来单位净值收益率
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_JNYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE TO_CHAR(B.STATISTIC_DATE, 'YYYYMMDD') >
                       SUBSTR(V_ZXJZRQ, 1, 4) || '0101'
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
        --近1月
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_J1YSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.STATISTIC_DATE >= V_1YQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
        --近3月
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_J3YSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.STATISTIC_DATE >= V_3YQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
        --近6月
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_J6YSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.STATISTIC_DATE >= V_6YQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
        --近1年
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_J1NSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.STATISTIC_DATE >= V_1NQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
        --近3年
        SELECT (CASE
                 WHEN A.NAV = 0 THEN
                  0
                 ELSE
                  (V_ZXDWJZ - A.NAV) / A.NAV
               END)
          INTO V_J3NSYL
          FROM SRC_PIF.T_FUND_NV_DATA_ZYYX A
         WHERE A.STATISTIC_DATE =
               (SELECT MIN(B.STATISTIC_DATE)
                  FROM SRC_PIF.T_FUND_NV_DATA_ZYYX B
                 WHERE B.STATISTIC_DATE >= V_3NQ
                   AND B.FUND_ID = V_FUND_ID)
           AND A.FUND_ID = V_FUND_ID;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          V_JNYL   := NULL;
          V_J1YSYL := NULL;
          V_J3YSYL := NULL;
          V_J6YSYL := NULL;
          V_J1NSYL := NULL;
          V_J3NSYL := NULL;
        
      END;
    
      OPEN O_RESULT FOR
        SELECT DECODE(V_FUND_ID, '999', NULL, V_FUND_ID) AS FUND_ID,
               V_FUND_NAME AS FUND_NAME,
               TO_CHAR(V_ZXDWJZ, 'FM990.0000') AS UNIT_NAV,
               V_ZXJZRQ AS NAV_DATE,
               TO_CHAR(V_ZDF*100, 'FM990.00') AS UNIT_NAV_CHG,
               TO_CHAR(V_NHSYL*100, 'FM990.00') AS ANNUALIZED_RETURN,
               TO_CHAR(V_J1YSYL*100, 'FM990.00') AS YIELD_RATE_MONTH,
               TO_CHAR(V_J3YSYL*100, 'FM990.00') AS YIELD_RATE_QUARTER,
               TO_CHAR(V_J6YSYL*100, 'FM990.00') AS YIELD_RATE_HALFYEAR,
               TO_CHAR(V_J1NSYL*100, 'FM990.00') AS YIELD_RATE_ONE_YEAR,
               TO_CHAR(V_J3NSYL*100, 'FM990.00') AS YIELD_RATE_THREE_YEAR,
               TO_CHAR(V_JNYL*100, 'FM990.00') AS YIELD_RATE_THIS_YEAR
          FROM DUAL;
    
    END IF;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
  
    O_CODE := 99;
    O_NOTE := '查询失败：' || SQLERRM;
END;
/

