create PROCEDURE PCX_PIF_CPJM_CPDBJGLB(O_CODE             OUT NUMBER,
                                                  O_NOTE             OUT VARCHAR2,
                                                  O_RESULT           OUT SYS_REFCURSOR,
                                                  I_PROD_IDS         IN VARCHAR2, --产品ID串
                                                  I_STATISTIC_PERIOD IN VARCHAR2 --维度
                                                  ) AS
  /******************************************************************
  项目名称：产品中心-产品列表-产品对比结果列表
  所属用户：PIF
  概要说明：查询产品对比结果列表
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合
  
  功能修订：
      简要说明：
        查询产品对比结果列表.
        
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/05/08     1.0.0    TUMENG                  新增
      2021/09/09     1.0.1    GAOKUN                  修改
  *********************************************************************************************************************/
  V_SQL VARCHAR2(32767);
  --V_RQ       NUMBER(8);
  V_PROD_IDS VARCHAR2(1000) := I_PROD_IDS;
BEGIN

  --初始化
  O_CODE := -1;
  O_NOTE := '';

  --条件检验
  IF I_PROD_IDS IS NULL THEN
    O_NOTE := '入参 I_PROD_IDS 不能为空！';
    RETURN;
  END IF;

  IF I_STATISTIC_PERIOD IS NULL THEN
    O_NOTE := '入参 I_STATISTIC_PERIOD 不能为空！';
    RETURN;
  END IF;

  V_SQL := ' SELECT T1.CPID AS PROD_ID,--产品ID
                    T1.CPDM AS PROD_CODE,--产品代码
                    T1.CPMC AS PROD_FULLNAME,--产品名称
                    (SELECT P.NOTE FROM LIVEBOS.TXTDM P WHERE P.FLDM = ''PIF_JZJYCPZT'' AND P.IBM = T1.CPJYZT) AS PROD_STATUS,--产品交易状态
                    T1.MJKSRQ AS SUBSCRIBE_BEGIN_DATE,--募集开始日期
                    TO_CHAR(TO_DATE(T1.CLRQ,''YYYYMMDD''),''YYYY-MM-DD'') AS ESTABLISH_DAY,--成立日期
                    T1.DQRQ AS EXPIRE_DATE,--到期日期
                    T1.CPQX AS PROD_TERM,--产品期限
                    (SELECT P.NOTE FROM LIVEBOS.TXTDM P WHERE P.FLDM =  ''PIF_CPTZLB'' AND P.IBM = T1.TZLB) AS INVEST_VARIETY,--产品投资类别
                    (SELECT P.NOTE FROM LIVEBOS.TXTDM P WHERE P.FLDM =  ''PIF_CPFXDJ_CPZX'' AND P.IBM = T1.CPFXDJ) AS PROD_RISK_LEVEL,--产品风险等级
                    TO_CHAR(T1.CPJZ,''FM9990.0000'') AS UNIT_NAV,--单位净值
                    TO_CHAR(TO_DATE(T1.JZRQ,''YYYYMMDD''),''YYYY-MM-DD'') AS NAV_DATE,--净值日期
                    TO_CHAR(T1.LJJZ,''FM9990.0000'') AS ADDEDNAV,--累计净值
                    A.PRODSCALEAMOUNT AS prodScaleAmount,--公募基金规模,私募数据基本无
                    ';

  IF I_STATISTIC_PERIOD = 1 THEN
    --近一年
    V_SQL := V_SQL ||
             'CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(G.XPBL_1N,''FM9990.0000'')
                      ELSE NVL(TO_CHAR(C.XPBL_1N,''FM9990.0000''),TO_CHAR(D.Y1_SHARP,''FM9990.0000'')) END AS sharpe,--夏普比率
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_1N IS NULL THEN NULL
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_1N IS NOT NULL THEN TO_CHAR(I.QJNHSYL_1N,''FM9990.00'')||''%''
                             WHEN D.Y1_RETURN_A IS NULL THEN NULL 
                             ELSE TO_CHAR(D.Y1_RETURN_A*100,''FM9990.00'')||''%'' END) AS annualRatio,--年化收益,公募没有近一年年化收益
                       TO_CHAR(C.ALPHA_1N,''FM9990.00000000'') AS alpha,--阿尔法系数,私募没有阿尔法系数
                       NVL(TO_CHAR(F.BETA_1N,''FM9990.0000''),TO_CHAR(E.Y1_BETA,''FM9990.0000'')) AS beta,--贝塔系数
                       NVL(TO_CHAR(C.XXBL_1N,''FM9990.0000''),TO_CHAR(E.Y1_INFO_RATIO,''FM9990.0000'')) AS infoRatio,--信息比率
                       CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(H.NHBDL_1N/SQRT(243)/100,''FM9990.0000'')
                            ELSE NVL(TO_CHAR(F.SYBZC_1N,''FM9990.0000''),TO_CHAR(D.Y1_STDEV,''FM9990.0000'')) END AS profitLabelDif,--收益标准差
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_1N IS NULL THEN NULL 
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_1N IS NOT NULL THEN TO_CHAR(H.NHBDL_1N,''FM9990.00'')||''%''
                             WHEN NVL(TO_CHAR(F.BDL_1N,''FM9990.00''),TO_CHAR(D.Y1_STDEV_A*100,''FM9990.00'')) IS NULL THEN NULL 
                             ELSE NVL(TO_CHAR(F.BDL_1N,''FM9990.00''),TO_CHAR(D.Y1_STDEV_A*100,''FM9990.00''))||''%'' END) AS volatility--波动率';
  
  ELSIF I_STATISTIC_PERIOD = 2 THEN
    --近三年         
    V_SQL := V_SQL ||
             'CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(G.XPBL_3N,''FM9990.0000'')
                      ELSE NVL(TO_CHAR(C.XPBL_3N,''FM9990.0000''),TO_CHAR(D.Y3_SHARP,''FM9990.0000'')) END AS sharpe,--夏普比率,
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_3N IS NULL THEN NULL 
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_3N IS NOT NULL THEN TO_CHAR(I.QJNHSYL_3N,''FM9990.00'')||''%''
                             WHEN NVL(TO_CHAR(B.ANNUALIZEDRRINTHREEYEAR,''FM9990.00''),TO_CHAR(D.Y3_RETURN_A*100,''FM9990.00'')) IS NULL THEN NULL 
                             ELSE NVL(TO_CHAR(B.ANNUALIZEDRRINTHREEYEAR,''FM9990.00''),TO_CHAR(D.Y3_RETURN_A*100,''FM9990.00''))||''%'' END)AS annualRatio,          
                       TO_CHAR(C.ALPHA_3N,''FM9990.00000000'') AS alpha,
                       NVL(TO_CHAR(F.BETA_3N,''FM9990.0000''),TO_CHAR(E.Y3_BETA,''FM9990.0000'')) AS beta,
                       NVL(TO_CHAR(C.XXBL_3N,''FM9990.0000''),TO_CHAR(E.Y3_INFO_RATIO,''FM9990.0000'')) AS infoRatio,
                       CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(H.NHBDL_3N/SQRT(243)/100,''FM9990.0000'')
                            ELSE NVL(TO_CHAR(F.SYBZC_3N,''FM9990.0000''),TO_CHAR(D.Y3_STDEV,''FM9990.0000'')) END AS profitLabelDif,
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_3N IS NULL THEN NULL 
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_3N IS NOT NULL THEN TO_CHAR(H.NHBDL_3N,''FM9990.00'')||''%''
                             WHEN NVL(TO_CHAR(F.BDL_3N,''FM9990.00''),TO_CHAR(D.Y3_STDEV_A*100,''FM9990.00'')) IS NULL THEN NULL 
                             ELSE NVL(TO_CHAR(F.BDL_3N,''FM9990.00''),TO_CHAR(D.Y3_STDEV_A*100,''FM9990.00''))||''%'' END) AS volatility';
  
  ELSIF I_STATISTIC_PERIOD = 3 THEN
    --近五年      
    V_SQL := V_SQL ||
             'CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(G.XPBL_5N,''FM9990.0000'')
                      ELSE NVL(TO_CHAR(C.XPBL_5N,''FM9990.0000''),TO_CHAR(D.Y5_SHARP,''FM9990.0000'')) END AS sharpe,--夏普比率,
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_5N IS NULL THEN NULL 
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND I.QJNHSYL_5N IS NOT NULL THEN TO_CHAR(I.QJNHSYL_5N,''FM9990.00'')||''%''
                             WHEN NVL(TO_CHAR(B.ANNUALIZEDRRINFIVEYEAR,''FM9990.00''),TO_CHAR(D.Y5_RETURN_A*100,''FM9990.00'')) IS NULL THEN NULL 
                             ELSE NVL(TO_CHAR(B.ANNUALIZEDRRINFIVEYEAR,''FM9990.00''),TO_CHAR(D.Y5_RETURN_A*100,''FM9990.00''))||''%'' END)AS annualRatio,
                       TO_CHAR(C.ALPHA_5N,''FM9990.00000000'') AS alpha,
                       NVL(TO_CHAR(F.BETA_5N,''FM9990.0000''),TO_CHAR(E.Y5_BETA,''FM9990.0000'')) AS beta,
                       NVL(TO_CHAR(C.XXBL_5N,''FM9990.0000''),TO_CHAR(E.Y5_INFO_RATIO,''FM9990.0000'')) AS infoRatio,
                       CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) THEN TO_CHAR(H.NHBDL_1N/SQRT(243)/100,''FM9990.0000'')
                            ELSE NVL(TO_CHAR(F.SYBZC_5N,''FM9990.0000''),TO_CHAR(D.Y5_STDEV,''FM9990.0000'')) END AS profitLabelDif,
                       (CASE WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_5N IS NULL THEN NULL 
                             WHEN (T1.SJLY!=1 OR T1.SJLY IS NULL) AND (INSTR(T1.SCLX,1)>0) AND H.NHBDL_5N IS NOT NULL THEN TO_CHAR(H.NHBDL_5N,''FM9990.00'')||''%'' 
                             WHEN NVL(TO_CHAR(F.BDL_5N,''FM9990.00''),TO_CHAR(D.Y5_STDEV_A*100,''FM9990.00'')) IS NULL THEN NULL 
                             ELSE NVL(TO_CHAR(F.BDL_5N,''FM9990.00''),TO_CHAR(D.Y5_STDEV_A*100,''FM9990.00''))||''%'' END) AS volatility';
  
  END IF;

  V_SQL := V_SQL || '                                    
               FROM PIF.TPIF_CPDM T1
               LEFT JOIN INFO.TINFO_JJGK A --基金概况，取公募基金规模
                      ON T1.CPDM=A.SECUCODE
                     AND A.REPORTDATE>=ADD_MONTHS(TRUNC(SYSDATE),-3)
               LEFT JOIN INFO.TINFO_JJJZZXBX B--基金净值最新表现，取年化收益
                      ON T1.CPDM=B.SECUCODE 
                     AND B.TRADINGDAY>=ADD_MONTHS(TRUNC(SYSDATE),-3)--三个月以内  
               LEFT JOIN PIF.TPIF_GMJJSYYGM C--公募基金收益与规模，取夏普比率、信息比率、阿尔法系数
                      ON T1.CPID=C.CPID
               LEFT JOIN INFO.T_FUND_ADJUSTED_PERFORMANCE D--私募基金自适应基础业绩表，取夏普比率、标准差、波动率、年化收益
                      ON T1.CPDM=D.REG_CODE
                     AND D.STATISTIC_DATE>=ADD_MONTHS(TRUNC(SYSDATE),-3)
               LEFT JOIN INFO.T_FUND_ADJUSTED_RISK E--私募基金自适应风险指标表，取信息比率、贝塔系数
                      ON T1.CPDM=E.REG_CODE  
                     AND E.STATISTIC_DATE>=ADD_MONTHS(TRUNC(SYSDATE),-3) 
               LEFT JOIN PIF.TPIF_GMJJFXPJ F--公募基金风险评价,取贝塔系数、收益标准差、波动率
                      ON T1.CPID=F.CPID
               LEFT JOIN DSC_STAT.TPIF_STAT_CP_FXTZHSY_CPZX G
                      ON T1.CPID=G.CPID
               LEFT JOIN DSC_STAT.TPIF_STAT_CP_FXTZ_CPZX H
                      ON T1.CPID=H.CPID
               LEFT JOIN DSC_STAT.TPIF_STAT_CP_SYTZ_CPZX I
                      ON T1.CPID=I.CPID                       
               WHERE INSTR('';''||''' || V_PROD_IDS ||
           '''||'';'','';''||T1.ID||'';'')>0';

  --DBMS_OUTPUT.PUT_LINE(V_SQL);

  OPEN O_RESULT FOR V_SQL;
  
  
  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT '异常信息：' || O_NOTE FROM DUAL;
  
  
END PCX_PIF_CPJM_CPDBJGLB;
/

