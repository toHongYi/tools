create procedure pcx_pif_cpqj_cpqjmx_out(o_code    out number,
                                                o_note    out varchar2,
                                                o_result  out sys_refcursor,
                                                i_user_id in number, --用户ID
                                                i_ip           in varchar2,--IP
                                                i_mbid    in number, --模版ID
                                                i_prod_id in number --产品 ID
                                                ) as
  /******************************************************************
  项目名称：产品中心-产品全景-产品详细信息
  所属用户：PIF
  概要说明：查询产品概要信息.
               i_Paging      --是否分页 1表示分页,0表示不分页.但即使不分页的情况下,也会计算i_totalrows.
                               并不是什么是否都需要分页,看情形而言.
               i_PageNo      --页码
               i_PageLength  --页长
               i_Totalrows   --总行数 -1,未知,表示需要计算总长.是In,Out参数.如果i_totalrows>=0,则不再计算这个指,
                               在翻页的时候,可以提高效率.
               i_Sort        --排序字段
               i_prod_id         IN NUMBER  --产品ID
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Hasrecordset  In,Out参数.整型,返回1,表示有返回o_result,否则没有o_result(为空值)
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.

  数据准备：

  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品详细信息.

        1.查询产品详细信息.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
  *********************************************************************************************************************/
  v_sql       varchar2(32767);
  v_colist    varchar2(32767);
  v_sort      varchar2(2000);
  v_errmsg    varchar2(300); --错误信息
  v_count     number(12);
  v_type      number(12);
  v_cpsx      varchar2(241); --产品属性
  v_refcode   varchar2(2000); --关联对象名称/字典的FLDM
  v_cxzd      varchar2(5000); --查询字段
  v_tablename varchar2(2000);
  v_zdsx      varchar2(241); --字段属性
  v_fzid      number(10); --分组ID
  v_fzmc      varchar(200); --分组名称
  v_nbdxids   varchar(1000); --内部对象IDs

begin
  o_code := 0;
  o_note := '成功';

  if i_mbid is null then
    o_code := -1801;
    o_note := '请输入必填参数【模版ID】';
    return;
  end if;
  if i_prod_id is null then
    o_code := -1801;
    o_note := '请输入必填参数【产品ID】';
    return;
  end if;
  if i_IP is null then
    o_code := -1000;
    o_note := '操作IP为空';
    return;
  end if;

  --验证是否存在通用模版
  select count(1)
    into v_count
    from tpif_cpqjmbdy mb
   where mb.id = i_mbid
     and mb.mbzt = 1;

  if v_count = 0 then
    o_code := -2;
    o_note := '错误：没有此全景模版！';
    return;
  end if;

  execute immediate 'TRUNCATE TABLE TEMPDATA_BIG';

  --根据模版得到展示字段
  for v2 in (select t.id,
                    t.fz,
                    t.xsmc,
                    t.xssx,
                    t.ywdx,
                    t.cpsx,
                    t.ms,
                    t.idbz,
                    t.sfdhxs
               from pif.tpif_qjfzxszd t
              where t.qjmb = i_mbid
                and t.zt = 1
              order by xssx asc) loop

    select t1.type, t1.name, t1.refcode, t1.tablename
      into v_type, v_cpsx, v_refcode, v_tablename
      from pif.tpif_field t1
     where t1.tablename = v2.ywdx
       and t1.id = v2.cpsx;

    --取分组相关
    select t.id, t.fzmc
      into v_fzid, v_fzmc
      from tpif_qjyqxsfz t
     where t.id = v2.fz;

    --时间类型，进行格式化
    begin
    if v_type = 13 then
      v_sql := 'select TO_CHAR(TO_DATE(' || v2.cpsx ||
               ',''YYYYMMDD''),''YYYY-MM-DD'') from ' || v_tablename ||
               ' where prod_id = ' || i_prod_id;
      execute immediate v_sql
        into v_zdsx;
      dbms_output.put_line(v_sql);
    elsif v_type = 3 then
      v_sql := 'select TO_CHAR(' || v2.cpsx || ',''YYYY-MM-DD'')  from ' ||
               v_tablename || ' where prod_id = ' || i_prod_id;
      execute immediate v_sql
        into v_zdsx;
      dbms_output.put_line(v_sql);
      --内部对象
    elsif v_type = 6 then
      v_sql := 'SELECT ' || v2.ms || ' FROM PIF.' || v_refcode || ' WHERE ' ||
               v2.idbz || ' = (select ' || v2.cpsx || ' from ' ||
               v_tablename || ' where prod_id = ' || i_prod_id || ')';
      execute immediate v_sql
        into v_zdsx;
      dbms_output.put_line(v_sql);
    elsif v_type = 16 then
      v_sql := 'select ' || v2.cpsx || ' from ' || v_tablename ||
               ' where prod_id = ' || i_prod_id;
      execute immediate v_sql
        into v_nbdxids;
      dbms_output.put_line(v_sql);
      v_sql := 'SELECT WM_CONCAT(' || v2.ms || ') FROM PIF.' || v_tablename ||
               '  WHERE INSTR('';''||' || v_nbdxids || '||'';'','';''||' ||
               v2.idbz || '||'';'') >0';
      execute immediate v_sql
        into v_zdsx;
      dbms_output.put_line(v_sql);
      --字典型
    elsif v_type = 7 then
      v_sql := 'select ' || v2.cpsx || ' from ' || v_tablename ||
               ' where prod_id = ' || i_prod_id;
      execute immediate v_sql
        into v_nbdxids;
      v_sql := 'SELECT  NOTE  FROM livebos.TXTDM T WHERE T.FLDM = ''' ||
               v_refcode || ''' AND T.IBM = ' || v_nbdxids;
      execute immediate v_sql
        into v_zdsx;
    elsif v_type = 15 then
      v_sql := 'select ' || v2.cpsx || ' from ' || v_tablename ||
               ' where prod_id = ' || i_prod_id;
      execute immediate v_sql
        into v_nbdxids;
      v_sql := 'SELECT  WM_CONCAT(NOTE)  FROM livebos.TXTDM T WHERE T.FLDM = ''' ||
               v_refcode || ''' AND INSTR('';''||' || v_nbdxids ||
               '||'';'','';''||T.IBM||'';'') >0 ';
      execute immediate v_sql
        into v_zdsx;
    else
        v_sql := 'select ' || v2.cpsx || ' from ' || v_tablename ||
                 ' where prod_id = ' || i_prod_id;
        execute immediate v_sql
          into v_zdsx;
    end if;
    exception when others then
          v_zdsx := '';
    end;
    insert into tempdata_big
      (n1, c1, c2, n2, c3, n3)
      select v2.xssx, v_zdsx, v2.xsmc, v_fzid, v_fzmc, v2.sfdhxs from dual;
  end loop;

  -- 4 组装查询sql
  v_sql := 'select N2 group_id,
                     C3 group_name,
                     C2 display_name,
                     C1 display_value,
                     N3 Is_single_row
              from TEMPDATA_BIG order by N1';
  open o_result for v_sql;

  -- 5.==============调用分页查询过程，返回游标==============
  --5.1 初始化分页查询入参
  --列表

  --是否返回结果集
  commit;
  --5.2.调用分页查询过程

  /*PCX_TYCX(O_CODE,
            O_NOTE,
            O_HASRECORDSET,
            O_RESULT,
            I_PAGING,
            I_PAGENO,
            I_PAGELENGTH,
            I_TOTALROWS,
            SQLS           => V_SQL,
            COLLIST        => V_COLIST,
            HASWHERE       => TRUE,
            GROUPISLAST    => TRUE,
            I_SORT         => V_SORT, --至多一条，强制不排序
  I_HASWITH      => FALSE);*/

exception
  when others then
    o_code   := -1;
    o_note   := '查询失败';
    v_errmsg := sqlerrm;
    open o_result for
      select '异常信息：' || v_errmsg from dual;

end pcx_pif_cpqj_cpqjmx_out;
/

