create PROCEDURE PRO_PIF_CPJZZJ(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2 --返回消息
                                               ) IS
    /******************************************************************
        项目名称：产品中心
        所属用户：PIF
        功能说明：产品净值质检
        语法信息：
             输入参数：
             输出参数：O_CODE OUT NUMBER, --返回值
                       O_NOTE OUT VARCHAR2, --返回消息
        逻辑说明：
             1、
        修订记录：
            修订日期       版本号    修订人             修改内容简要说明
            2021-05-19     1.0.1     HQN                新增
    ***********************************************************************/
    V_COUNT INTEGER; --计数变量

BEGIN
    --INIT
    O_CODE := 1;
    O_NOTE := '';

    --清空表
    DELETE FROM TPIF_ZJJG_CPJZ;
    
    --单位净值异常
    MERGE INTO TPIF_ZJJG_CPJZ T1
     USING(SELECT CPID,
                  JZRQ,
                  COUNT(1) AS DWJZSL
             FROM (SELECT A.CPID,A.JZRQ,A.DWJZ FROM TPIF_CPJZ A GROUP BY A.CPID,A.JZRQ,A.DWJZ)
           HAVING COUNT(1)>1
           GROUP BY CPID,JZRQ
           )T2
        ON (T1.CPID=T2.CPID AND T1.JZRQ=T2.JZRQ)
     WHEN MATCHED THEN
       UPDATE SET T1.DWJZSL=T2.DWJZSL,
                  T1.DWJZZT=2
     WHEN NOT MATCHED THEN
       INSERT (T1.ID,
               T1.CPID,
               T1.CPDM,
               T1.CPMC,
               T1.JZRQ,
               T1.DWJZZT,
               T1.DWJZSL,
               T1.LJJZZT,
               T1.LJJZSL
               )
       VALUES (LIVEBOS.FUNC_NEXTID('TPIF_ZJJG_CPJZ'),
               T2.CPID,
               (SELECT CPDM FROM TPIF_CPDM WHERE CPID=T2.CPID),
               (SELECT CPMC FROM TPIF_CPDM WHERE CPID=T2.CPID),
               T2.JZRQ,
               2,
               T2.DWJZSL,
               1,
               1
              );

     --累计净值异常
     MERGE INTO TPIF_ZJJG_CPJZ T1
     USING(SELECT CPID,
                  JZRQ,
                  COUNT(1) AS LJJZSL
             FROM (SELECT A.CPID,A.JZRQ,A.LJJZ FROM TPIF_CPJZ A GROUP BY A.CPID,A.JZRQ,A.LJJZ)
           HAVING COUNT(1)>1
           GROUP BY CPID,JZRQ
           )T2
     ON (T1.CPID=T2.CPID AND T1.JZRQ=T2.JZRQ)
     WHEN MATCHED THEN
       UPDATE SET T1.LJJZSL=T2.LJJZSL,
                  T1.LJJZZT=2
     WHEN NOT MATCHED THEN
       INSERT (T1.ID,
               T1.CPID,
               T1.CPDM,
               T1.CPMC,
               T1.JZRQ,
               T1.DWJZZT,
               T1.DWJZSL,
               T1.LJJZZT,
               T1.LJJZSL
               )
       VALUES (LIVEBOS.FUNC_NEXTID('TPIF_ZJJG_CPJZ'),
               T2.CPID,
               (SELECT CPDM FROM TPIF_CPDM WHERE CPID=T2.CPID),
               (SELECT CPMC FROM TPIF_CPDM WHERE CPID=T2.CPID),
               T2.JZRQ,
               1,
               1,
               2,
               T2.LJJZSL
              );

      O_NOTE :='产品净值质检TPIF_ZJJG_CPJZ清洗成功！';

      COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPJZZJ;
/

