create PROCEDURE pro_pif_ygxszc_xxfs(O_CODE   OUT NUMBER, --返回值
                                                O_NOTE   OUT VARCHAR2, --返回消息
                                                I_USERID IN NUMBER,
                                                I_ID     IN INTEGER, --路演ID
                                                i_msg    in varchar2 --消息内容
                                                ) IS
  /*
  **功能说明：产品对比配置
  **创建人：涂孟
  **创建日期：2020-05-08
  **************************************************************************
  **修改记录
  **************************************************************************
  **修改者     版本号    修改日期     说明
  **涂孟       1.0.0     2020-07-16   创建
  */
 -- V_COUNT  NUMBER;
  V_BT     varchar2(300);
  v_userid number(16);
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  --CHECK
  IF I_USERID IS NULL THEN
    O_NOTE := '系统异常:入参 i_userid 为空!';
    RETURN;
  END IF;

  IF I_ID IS NULL THEN
    O_NOTE := '系统异常:记录ID为空!';
    RETURN;
  END IF;

  IF i_msg IS NULL THEN
    O_NOTE := '系统异常:消息内容为空!';
    RETURN;
  END IF;
  --START
  O_NOTE := '业务处理';
  select SJMC, ZJR
    into V_BT, v_userid
    from TPIF_XSZC_LYJPXAPWH
   where id = i_id;

  insert into livebos.LBMESSAGE(  id, 
                                  f_owner,   --所有者
                                  f_sender,  --发送者
                                  f_receiver, --接收者
                                  f_message, --内容
                                  f_folder,   --0|收件箱;1|发件箱
                                  f_date,     --发送时间
                                  is_read  --是否已阅
                                 
                             )
                             values( livebos.func_nextid('LBMESSAGE'),
                                     v_userid,
                                     I_USERID,
                                     v_userid,
                                     '路演提示：' || V_BT||',请做好准备！',
                                     0,
                                     sysdate,
                                     0
                             );
  
  
  
 /* 
    (ID, RECEIVER, TITLE, MESSAGE, "DATE", SENDER,F_OWNER,IS_READ)
  VALUES
    (LIVEBOS.FUNC_NEXTID('lbMessageSender'),
     V_USERID,
     '路演提示：' || V_BT,
     I_MSG,
     SYSDATE,
     I_USERID,
     V_USERID,0);*/

  --RETURN
  COMMIT;
  O_note :='消息发送成功！';
  O_CODE := 1;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END pro_pif_ygxszc_xxfs;
/

