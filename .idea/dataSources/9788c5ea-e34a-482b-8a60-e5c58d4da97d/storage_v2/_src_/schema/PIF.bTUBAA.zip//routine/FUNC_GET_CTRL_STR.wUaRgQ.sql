create FUNCTION FUNC_GET_CTRL_STR(I_INPUT IN VARCHAR2)
  RETURN VARCHAR2 AS

  /******************************************************************
          项目名称：产品中心
          所属用户：PIF
          功能说明：根据输入生成产品控制串
          语法信息：
               输入参数：    I_INPUT IN NUMBER --输入格式  18;19;52
                      
               
               输出参数：   产品控制串 255位
               
          逻辑说明：将多选的控制串(数据字典格式)，转换为对应的255位控制串
          
          输入18;19;52，则将第18、19、52位的数字0改为1
          
          修订记录：
              修订日期       版本号    修订人             修改内容简要说明
              2021-09-27     1.0.0     高昆                创建
  ***********************************************************************/

  V_CTRL_STR VARCHAR2(255) := '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
  V_INPUT    VARCHAR2(1000) := I_INPUT;
  V_POSITION NUMBER(8); -- ';'第一分号所在位置，有分号则不止一个数字
  V_NOW      NUMBER; --当前处理位置
  V_REST     VARCHAR2(1000); --剩余待处理内容
BEGIN

  IF V_INPUT IS NULL THEN
    RETURN V_CTRL_STR;
  END IF;

  --第一个分号位置
  SELECT INSTR(V_INPUT, ';', 1, 1) INTO V_POSITION FROM DUAL;

  --如果入参是单一数据，比如 1，则 V_POSITION =0，直接处理
  IF V_POSITION = 0 THEN
  
    V_NOW  := V_INPUT;
    V_REST := NULL;
  
  ELSE
    --要处理的位置
    SELECT TO_NUMBER(SUBSTR(V_INPUT, 1, V_POSITION - 1))
      INTO V_NOW
      FROM DUAL;
  
    --剩余待处理内容
    SELECT SUBSTR(V_INPUT, V_POSITION + 1) INTO V_REST FROM DUAL;
  END IF;

  WHILE V_NOW IS NOT NULL LOOP
    SELECT SUBSTR(V_CTRL_STR, 1, V_NOW - 1) || '1' ||
           SUBSTR(V_CTRL_STR, V_NOW + 1)
      INTO V_CTRL_STR
      FROM DUAL; --更新控制串
  
    --第一个分号位置
    SELECT INSTR(V_REST, ';', 1, 1) INTO V_POSITION FROM DUAL;
  
    --如果没有分号了，则说明只剩下一个待处理的位置
    IF V_POSITION = 0 THEN
      SELECT TO_NUMBER(V_REST) INTO V_NOW FROM DUAL;
      V_REST := NULL;
    ELSE
      --要处理的CPID
      SELECT TO_NUMBER(SUBSTR(V_REST, 1, V_POSITION - 1))
        INTO V_NOW
        FROM DUAL;
    
      --剩余CPIDS
      SELECT SUBSTR(V_REST, V_POSITION + 1) INTO V_REST FROM DUAL;
    END IF;
  END LOOP;

  RETURN V_CTRL_STR;
END;
/

