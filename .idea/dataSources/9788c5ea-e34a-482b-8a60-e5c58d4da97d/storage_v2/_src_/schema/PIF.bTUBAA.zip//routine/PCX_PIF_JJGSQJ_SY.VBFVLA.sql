create procedure pcx_pif_jjgsqj_sy(o_code      out number,
                                              o_note      out varchar2,
                                              o_result    out sys_refcursor,
                                              i_userid    in number,
                                              i_org_id    in number, --机构id
                                              i_fund_type in number --基金类型，1101-股票型，1103-混合型，1105-债券型，1107-保本型，1109-货币型，1110-QDII，1199-其他型
                                              ) as
  /******************************************************************
  项目名称：产品中心-基金公司全景-收益
  所属用户：PIF
  概要说明：查询基金公司收益.
  
  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
          o_Result        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询收益.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/08/05     1.0.0.1   陈云昊             新增.
  *********************************************************************************************************************/
  --v_sql   varchar2(32767);
  v_hs_6y varchar(30);
  v_hs_1n varchar(30);
  v_hs_3n varchar(30);
  v_hs_5n varchar(30);
begin

  --初始化
  o_code := -1;
  o_note := '';
  --条件检验
  if i_userid is null then
    o_note := ' 用户ID不允许为空！';
    return;
  end if;
  if i_org_id is null then
    o_note := '机构ID不允许为空！';
    return;
  end if;
  if i_fund_type is null then
    o_note := '基金类型不允许为空！';
    return;
  end if;
  begin
    select to_char(ZDF_6Y),
           to_char(ZDF_1N),
           to_char(ZDF_3N),
           to_char(ZDF_5N)
      into v_hs_6y, v_hs_1n, v_hs_3n, v_hs_5n
      from DSC_STAT.tpif_stat_zs_hqbx
     where ZSID = 3145;
  exception
    when others then
      null;
  end;

  open o_result for
       select '本公司平均' ave_type,
       decode(TJZQ,1,'近6月',2,'近1年',3,'近3年',4,'近5年') time_slot,
       to_char(JJGMPJ, 'fm99999999999999990.099999999') ave_value
        from DSC_STAT.tpif_stat_jjgs_jjsy t
           where t.JJGSID = i_org_id
             and t.jjlb = i_fund_type
       union
       select '同类平均',
       decode(TJZQ,1,'近6月',2,'近1年',3,'近3年',4,'近5年'),
       to_char(JJGMPM, 'fm99999999999999990.099999999')
        from DSC_STAT.tpif_stat_jjgs_jjsy t
           where t.JJGSID = i_org_id
             and t.jjlb = i_fund_type
        union
        select '沪深300',
        '近6月',
        v_hs_6y from dual
        union
        select '沪深300',
        '近1年',
        v_hs_1n from dual
        union
        select '沪深300',
        '近3年',
        v_hs_3n from dual
        union
        select '沪深300',
        '近5年',
        v_hs_5n from dual;

  --dbms_output.put_line(v_sql);
  -- open o_result for v_sql;

  o_code := 1;
  o_note := '成功';

exception
  when others then
    o_code := -1;
    o_note := '查询失败:' || sqlerrm;
    open o_result for
      select '异常信息：' || o_note from dual;
  
end pcx_pif_jjgsqj_sy;
/

