create PROCEDURE PRO_PIF_SJWDZJ(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2 --返回消息
                                           ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：走上架流程的产品数据质检
      数据文档质检
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5      1.0      liutx                   创建
  ***********************************************************************/
  V_CWJG  VARCHAR2(1000) := '';
  V_COUNT NUMBER;
  V_ID    NUMBER;
  --CUR_SMCP TPIF_SMCP%ROWTYPE;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  SELECT ID INTO V_ID FROM PIF.TPIF_JHGZ WHERE GZDM = 'GZ00003';

  FOR CUR IN (SELECT * FROM PIF.LCCPSJ WHERE SHZT = 2) LOOP
  
    /*质检上架产品是否缺少必填文档*/
    SELECT COUNT(DISTINCT WDFL)
      INTO V_COUNT
      FROM PIF.TPIF_CPWDK
     WHERE TRIM(GLID) =
           (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
       AND WDFL IN (6, 13, 303, 302, 301, 300, 175, 143, 900013);
    IF V_COUNT = 9 THEN
      UPDATE TPIF_ZJJG
         SET ZJJG = 1, CWJG = ''
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM);
    ELSE
      V_CWJG := '产品文档库中，';
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 6;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品合同 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 13;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品尽职调查报告 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 303;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品价值分析报告 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 302;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品风险等级评价表 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 301;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '表决书 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 300;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '代销产品洗钱风险评估表 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 175;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品代销补充协议 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 143;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品宣传材料 没有上传,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPWDK
       WHERE TRIM(GLID) =
             (SELECT CPID FROM TPIF_CPDM WHERE TRIM(CPDM) = TRIM(CUR.CPDM))
         AND WDFL = 900013;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '普通营销方案 没有上传,';
      END IF;
    
      MERGE INTO PIF.TPIF_ZJJG M
      USING (SELECT CUR.CPDM CPDM, V_CWJG CWJG, V_ID ID FROM DUAL) N
      ON (M.CPDM = N.CPDM AND M.ZJGZ = N.ID)
      WHEN MATCHED THEN
        UPDATE SET M.CWJG = V_CWJG, M.ZJJG = 0
      WHEN NOT MATCHED THEN
        INSERT
          (ID, RQ, ZJGZ, ZJJG, CWJG, CPDM)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_ZJJG'),
           SYSDATE,
           N.ID,
           0,
           N.CWJG,
           CUR.CPDM);
    
    END IF;
    COMMIT;
  END LOOP;

  O_CODE := 1;
  O_NOTE := 'TPIF_ZJJG 表清洗成功';
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_ZJJG 表清洗,未知错误'
                ELSE
                 'TPIF_ZJJG 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

