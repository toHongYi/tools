create procedure     PRO_CPYY_YYBCSH( O_CODE OUT NUMBER,   --返回值
                                                   O_NOTE OUT VARCHAR2, --返回消息
                                                   I_CPGLID   IN  NUMBER,   --产品预约管理ID
                                                   I_CZR IN NUMBER --操作人
                                                   )IS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：     I_CPGLID  产品预约管理ID
                                 I_CZR   操作人
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                              
      逻辑说明：   预约产品新增后，默认该产品对所有营业部可见，且额度为0(无限制)                             
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WEIWENHAO        营业部初始化
  ***********************************************************************/
 V_CZR NUMBER; --操作人
 V_CPGLID  NUMBER; --产品管理ID
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';
  V_CPGLID:=I_CPGLID;
  V_CZR:=I_CZR;

 O_NOTE :='插入数据';

  FOR CUR IN(SELECT ID,NAME FROM LIVEBOS.LBORGANIZATION  WHERE BRANCH_ID IS NOT NULL AND LX =1 )
    LOOP
  INSERT INTO TPIF_YYBXE(ID,YYBID,ZKYED,ZKYRS,CPGLID,YYRS,YYJE,CZR,CZSJ,YYBMC,CCKHYYJE,CCKHYYSL) VALUES(LIVEBOS.FUNC_NEXTID('TPIF_YYBXE'),CUR.ID,0,0,V_CPGLID,0,0,V_CZR,SYSDATE,CUR.NAME,0,0);
  END LOOP;


COMMIT;

    EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
ROLLBACK;
END;
/

