create PROCEDURE PRO_PIF_CPYSLR(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2, --返回消息
                                           I_USER IN INTEGER, --操作人
                                           I_IP   IN VARCHAR2, --操作IP
                                           I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|提交复核;4|复核确认
                                           I_ID   IN INTEGER, --操作ID
                                           I_IDS  IN VARCHAR2 --批量操作ID串
                                           ) IS
  /******************************************************************
      项目名称：收益凭证产品要素录入后台处理逻辑
      所属用户：PIF
      功能说明：产品要素录入相关操作
      语法信息：
           输入参数：   I_USER  操作人
                        I_IP    操作IP
                        I_OPER  操作类型0|新增;1|修改;2|删除;3|提交复核;4|复核确认
                        I_ID    操作ID
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-08-22     1.0.1    洪国力                创建
          2020-08-06     1.0.2    高昆                  修改
  ***********************************************************************/

  V_IDS VARCHAR2(2000);
  V_ROW NUMBER;
  
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_OPER IS NULL THEN
    O_NOTE := '系统异常:操作类型标识为空!';
    RETURN;
  END IF;
  
  --ID初始化
  IF I_OPER IN (3, 4) THEN
    IF I_IDS IS NULL THEN
      O_NOTE := '请选择待复核产品!';
      RETURN;
    END IF;

    SELECT REPLACE(REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''),
                           ']',
                           ''),
                   ',',
                   ';')
      INTO V_IDS
      FROM DUAL;
  END IF;
  
  --提交处理
  IF I_OPER = 3 THEN       
    UPDATE TPIF_CPYSLR
       SET FHZT = 0 --待复核
     WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0;

  --复核确认
  ELSIF I_OPER = 4 THEN
    
    INSERT INTO PIF.TPIF_CPDM
      (ID, --产品ID
       CPID, --产品标识
       CPDM, --产品代码
       CPjc, --产品名称
       CPMC, --产品全称
       MJKSRQ, --认购起始日期
  
       CPQX, --产品期限
       YQSYL, --预期收益率
       CPNBZT, --产品内部状态
       HBZL, --货币种类
       MFMZ, --每份面值
       CPZDMJJE, --产品规模下限
       CPZGMJJE, --产品规模上限
       JRCPFL, --金融产品分类
       CPXL, --产品系列

       CPFXDJ, --风险等级

       TZLB, --投资品种
       CPTZQX, --投资期限

       CPGLRID, --产品管理人
       CPTAMC, --注册登记机构

       CPJL, --产品经理
       CPZGBM, --供给部门 多值对象选择
       TZFZR, --投资负责人

       XSSC, --销售市场

       SFXYHF, --是否有回访期
       SFYLJQ, --是否有冷静期
       SFZDXS, --是否重点代销

       CPZED, --发行额度

       RGRSSX, --最大购买人数
       PT, --交易柜台

       QTJE, --起投金额

       RKSJ, --入库时间
       RKCZR --入库操作人
       )

      SELECT livebos.FUNC_NEXTID('TPIF_CPDM'),
             null,             
             CPDM,  --产品代码
             CPMC,  --产品名称
             CPQC,  --产品全称
             RGQSRQ,

             CPQX,
             YQSYL,
             1,         --已入库
             HBZL,
             MFMZ,
             CPGMXX,
             CPGMSX,
             JRCPFL,
             4,         --收益凭证
             CPFL_FXDJ,
             CPFL_TZPZ,
             CPFL_TZQX,
             
	           CPGLR,
             ZCDJJG,

             CPJL,
             GJBM,
             TZFZR,

             XSSC,

             SFYHFQ,
             SFYLJQ,
             SFZDDX,

             FXED,
             ZDGMRS,
             JYGT,

             QTJE,
             SYSDATE,
             I_USER
        FROM TPIF_CPYSLR C
       WHERE INSTR(';' || V_IDS || ';', ';' || C.ID || ';') > 0
         AND NOT EXISTS
       (SELECT 1 FROM TPIF_CPDM B WHERE B.CPDM = C.CPDM);
       
    V_ROW := SQL%ROWCOUNT;

     UPDATE TPIF_CPDM A
       SET A.CPID = A.ID
     WHERE trunc(RKSJ) =  trunc(SYSDATE) -- 入库时间
       AND RKCZR = I_USER
       AND A.CPID  is null ;

    UPDATE TPIF_CPYSLR
       SET FHZT = 1 --已复核
     WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0;

    UPDATE TPIF_SYPZ_DMSQ
       SET RKZT = 1 --已入库
     WHERE CPDM in
           (SELECT CPDM
              FROM TPIF_CPYSLR
             WHERE INSTR(';' || V_IDS || ';', ';' || ID || ';') > 0);
     
    O_NOTE := '复核成功,共入库 ' || V_ROW || ' 只产品';
  END IF;
  
  O_CODE := 1;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -99;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 '未知错误'
                ELSE
                 '在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END PRO_PIF_CPYSLR;
/

