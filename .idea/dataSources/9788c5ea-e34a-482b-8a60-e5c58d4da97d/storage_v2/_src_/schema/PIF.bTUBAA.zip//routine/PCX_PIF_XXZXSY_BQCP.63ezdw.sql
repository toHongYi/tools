create PROCEDURE PCX_PIF_XXZXSY_BQCP( O_CODE   OUT NUMBER,
                                                 O_NOTE   OUT VARCHAR2,
                                                 O_RESULT OUT SYS_REFCURSOR,
                                                 I_USERID IN NUMBER --登陆用户ID
                                                ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 信息中心首页-标签产品列表查询
  
  
      语法信息：
           输入参数：   I_USERID       IN NUMBER, --登陆用户ID
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-07    1.0       WUJINFENG              新增
  ***********************************************************************/
  --V_SQL VARCHAR2(5000);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  /*  LABEL_NAME  标签名称
      PROD_ID 产品ID
      PROD_CODE 产品代码
      PROD_NAME 产品名称
      PROD_TYPE 产品类型
      PROD_RISK_LEVEL 产品风险等级
      SUBSCRIBE_ORIGIN  认购起点(元)
      UNIT_NAV  最新净值
      D7_ANNUAL_YIELD_RATE  七日年化收益率
  */
  OPEN O_RESULT FOR
    SELECT c.ID AS LABEL_ID,
           C.MC AS LABEL_NAME,
           A.CPID AS PROD_ID,
           A.CPDM AS PROD_CODE,
           A.CPMC AS PROD_NAME,
           (CASE
             WHEN A.CPXL = 1 THEN
              (SELECT (SELECT NOTE
                         FROM LIVEBOS.TXTDM
                        WHERE FLDM = 'PIF_JJLB_CPZX'
                          AND IBM = M.JJLX)
                 FROM TPIF_CPDM_N_GMJJ M
                WHERE M.CPID = A.ID)
             ELSE
              (SELECT NOTE
                 FROM LIVEBOS.TXTDM
                WHERE FLDM = 'PIF_CPXL_CPZX'
                  AND IBM = A.CPXL)
           END) AS PROD_TYPE, --产品类型
           (SELECT NOTE
              FROM LIVEBOS.TXTDM
             WHERE FLDM = 'PIF_CPFXDJ_CPZX'
               AND IBM = A.CPFXDJ) AS PROD_RISK_LEVEL,
           (case when nvl(A.QTJE,0)=0 then 100 else A.QTJE end)||'元' AS SUBSCRIBE_ORIGIN,
           to_char(ROUND(A.CPJZ,3),'FM9999990.0009') AS UNIT_NAV,
           to_char(ROUND(A.QRNHSYL*100,3),'FM9999990.0009') AS D7_ANNUAL_YIELD_RATE
      FROM TPIF_CPDM A, TPIF_CPBQMX B, TPIF_CPBQ C
     WHERE A.ID = B.CPID
       AND B.CPBQ = C.ID
       AND C.BQLX = 3
       and c.zt=1
       AND A.CPXL > 0;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

