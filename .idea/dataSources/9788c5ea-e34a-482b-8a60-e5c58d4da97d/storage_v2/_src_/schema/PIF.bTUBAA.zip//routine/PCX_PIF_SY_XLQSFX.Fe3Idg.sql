create PROCEDURE PCX_PIF_SY_XLQSFX(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              --I_TYPE          IN NUMBER, --类型:1:销量，2：收入
                                              I_TIME_INTERVAL IN NUMBER --统计周期: 1：近1年
                                              ) AS

  /*--------------------------------------------------------------------------------------------
  项目名称：产品中心
  
         功能说明：产品首页-产品销量趋势分析 
             参数说明：
                  入参：
                        I_TIME_INTERVAL  IN NUMBER --统计周期: 1：近1年
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        WUJINFENG  1.0    2020/05/07                   新增
  
  -----------------------------------------------------------------------------------------------*/
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_TIME_INTERVAL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TIME_INTERVAL不能为空!';
    RETURN;
  END IF;

  --近1年
  IF I_TIME_INTERVAL = 1 THEN
  
    --stat_date 统计日期    String    
    --stat_date_desc  统计日期描述    String    
    --prod_amount 产品销量    String    单位：万元
    --csi300_index  沪深300指数   String    
    OPEN O_RESULT FOR
      SELECT YF AS STAT_DATE,
             SUBSTR(YF, 1, 4) || '年' || SUBSTR(YF, 5, 2) || '月' AS STAT_DATE_DESC,
             ROUND(SUM(XSL) / 10000, 2) AS PROD_AMOUNT,
             
             (SELECT A.ZSPJ
                FROM DSC_STAT.TPIF_STAT_ZSHQ A
               where A.ZSDM = '000300.SH'
                 AND a.SJRQ = (SELECT MAX(B.SJRQ)
                                 FROM DSC_STAT.TPIF_STAT_ZSHQ B
                                where B.ZSDM = '000300.SH'
                                     --    AND SUBSTR(B.SJRQ,1,4) = M.YF )
                                  AND SUBSTR(B.SJRQ, 1, 6) = M.YF)) CSI300_INDEX
        FROM DSC_STAT.TPIF_STAT_CPDXYB_HZTJ M
       WHERE YF >= TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'yyyymm')
       GROUP BY YF
       ORDER BY STAT_DATE ASC;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

