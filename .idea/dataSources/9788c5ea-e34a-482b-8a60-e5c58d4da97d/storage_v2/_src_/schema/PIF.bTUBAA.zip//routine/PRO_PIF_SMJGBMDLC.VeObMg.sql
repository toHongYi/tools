create PROCEDURE PRO_PIF_SMJGBMDLC( O_CODE     OUT NUMBER,   --返回值
                                               O_NOTE     OUT VARCHAR2, --返回消息

                                               I_OPER     IN INTEGER,   -- 1: 提交校验，2：发起申请   3：审核完成
                                               I_ID       IN VARCHAR2,    --对象ID或id串
                                               I_INSTID   IN NUMBER,
                                               I_USER     IN NUMBER
) IS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：私募机构白名单流程后台处理逻辑
      语法信息：


      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    陈勇军                创建
  ***********************************************************************/
  V_COUNT NUMBER;
  V_IDS varchar2(2000);

BEGIN

  IF I_OPER IS NULL THEN
    O_CODE := -1;
    O_NOTE := 'i_OPER不能为空!';
    RETURN;
  END IF;
  --1:提交校验
  IF I_OPER = 1 THEN

     V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_ID, ' ', ''), '[', ''), ']', ''), ',', ';');

     SELECT COUNT(*) INTO V_COUNT FROM TPIF_SMJGNSC WHERE INSTR(';'||V_IDS||';',';'||ID||';') > 0  AND ZT <> 1;

     IF V_COUNT > 0  THEN
       O_CODE := -1;
       O_NOTE := '只能勾选记待上会机构，请检查!';
       RETURN;
     END IF;


  --2：发起申请
  ELSif I_OPER = 2 THEN

    V_IDS := REPLACE(REPLACE(REPLACE(REPLACE(I_ID, ' ', ''), '[', ''), ']', ''), ',', ';');

    INSERT INTO lc_SMJGBMDLC_JGLB(id,
                                 jgid,
                                 xgid,
                                 fjmc,
                                 lc_smjgbmdlc_id
                                 )

    SELECT LIVEBOS.FUNC_NEXTID('lc_SMJGBMDLC_JGLB'),
           A.JGID,
           A.XGID,
           A.FJMC,
           I_INSTID
      FROM TPIF_SMJGNSC A
      WHERE INSTR(';'||V_IDS||';',';'||ID||';') > 0 ;


      ---更新状态为 2 上会中

      update TPIF_SMJGNSC A
        set A.ZT=2
      WHERE INSTR(';'||V_IDS||';',';'||ID||';') > 0 ;


  --3：审核完成  I_INSTID    IN NUMBER
  ELSE

     FOR CUR_IN IN( SELECT * FROM lc_SMJGBMDLC_JGLB A WHERE A.LC_SMJGBMDLC_ID = I_INSTID) LOOP


        INSERT INTO TPIF_SMJGBMDC(
                                    ID,
                                    JGID,
                                   -- JGMC,
                                   -- JGJC,
                                   -- CLRQ,
                                  --  DJBH,
                                   -- DJSJ,
                                  --  ZCZB,
                                    LX,
                                    RCRY,
                                    RCSJ
                                 )
         SELECT LIVEBOS.FUNC_NEXTID('TPIF_SMJGBMDC'),
                CUR_IN.JGID,
               -- B.JGMC,
               -- B.JGJC,
               -- B.CLRQ,
               -- B.DJBH,
               -- B.DJSJ,
               -- B.ZCZB,
                CUR_IN.LX,
                I_USER,
                SYSDATE
          FROM DUAL;

          --更新状态为 3 已通过
          update TPIF_SMJGNSC A
            set A.ZT=3
          WHERE A.JGID = CUR_IN.JGID
            AND A.ZT=2 ;

     END LOOP;

     UPDATE lc_SMJGBMDLC A SET A.SHZT = 2 ,A.WCRQ=TO_CHAR(SYSDATE,'YYYYMMDD') WHERE A.ID = I_INSTID ;





  END IF;

  COMMIT;

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := SQLERRM;
    ROLLBACK;
END;
/

