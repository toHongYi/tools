create PROCEDURE P_TRAN_CPDM(O_CODE OUT NUMBER, --返回值
                                        O_NOTE OUT VARCHAR2 --返回消息
                                        ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品代码表 TPIF_CPDM 数据清洗逻辑
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-03-15     1.0       韩乔楠              创建
          2021-11-15     1.1       LTX                调整，风险等级大于0，ADD_DATE>=20210101,TRIM(PRODCODE_TYPE) IS NOT NULL
          2021-12-20     1.2      GAOKUN              公募基金(SJLY=1)不更新成立日期、募集开始/结束日期
  ***********************************************************************/
BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  --将柜台数据更新或插入到产品代码表中
  MERGE INTO PIF.TPIF_CPDM M
  USING (SELECT PRODTA_NO, --  TA代码
                PRODCODE_TYPE, --恒生柜台-产品代码类型
                PROD_CODE, --  产品代码
                PROD_NAME, --  产品名称
                PRODALIAS_NAME,
                PRODSPELL_CODE, --  拼音代码
                IPO_BEGIN_DATE, --  募集开始日期
                IPO_END_DATE, --  募集结束日期
                PROD_BEGIN_DATE, --  产品成立日期
                PROD_END_DATE, --  产品结束日期
                PROM_BEGIN_DATE, --  推介开始日期
                PROM_END_DATE, --  推介结束日期
                PROD_TERM, --  产品期限
                PROD_STATUS, --  产品交易状态
                MONEY_TYPE, --   币种类别
                ISSUE_PRICE, --  发行价格
                PAR_VALUE, --  每份面值
                TRIM(CHARGE_TYPE) AS CHARGE_TYPE, --  基金收费方式
                TRIM(DIVIDEND_WAY) AS DIVIDEND_WAY, --  基金分红方式
                --       TO_NUMBER(MIN_SHARE) AS MIN_SHARE, --  个人最低认购金额
                PROD_MIN_BALA, --  产品最低募集金额
                PROD_MAX_BALA, --  产品最高募集金额
                PROD_REAL_BALA, --  产品实际募集金额
                YEAR_DAYS, --  产品年化天数
                PRODPRE_RATIO, --  产品预期年收益率
                PROD_RATIO_STR, --  产品预期年收益率文字描述
                
                --PRODCOMPANY_NAME, --  产品注册登记机构名称
                PROD_MANAGER, --  产品管理人
                PROD_TRUSTEE, --  产品托管人
                
                TRIM(INVEST_TYPE) AS INVEST_TYPE, -- 产品投资类别
                TRIM(INCOME_TYPE) AS INCOME_TYPE, -- 产品收益类型
                TRIM(PROD_INVEST_TERM) AS PROD_INVEST_TERM, -- 产品投资期限
                TRIM(PRODRISK_LEVEL) AS PRODRISK_LEVEL, -- 产品风险等级
                TRIM(ASSESS_LEVEL) AS ASSESS_LEVEL, -- 产品评估等级
                TRIM(LOW_CORP_RISK_LEVEL) AS LOW_CORP_RISK_LEVEL, -- 最低风险等级
                TRIM(MIN_ASSET_NEED) AS MIN_ASSET_NEED, -- 投资者最低资产要求
                TRIM(EN_PROF_FLAG) AS EN_PROF_FLAG, -- 允许专业投资者类型
                
                CURRENT_AMOUNT_LOW, --持仓量的最低值
                MAX_SUBSCRIBE_NUM, --认购人数上限
                MIN_SWITCH_IN_BALANCE, --最低转换金额
                TRANS_LIMITSHARE, --最少转换份额
                SWITCH_UNIT, --转换单位
                REDEEM_LIMITSHARE, --赎回最低份额
                REDEMPTION_UNIT, --赎回最小单位
                TRIM(REDEEM_USE_FLAG) AS REDEEM_USE_FLAG, --赎回资金可用标志
                TRIM(MAX_ALLOTRATIO) AS MAX_ALLOTRATIO, --每次最大可申购比例
                ADD_DATE
           FROM SRC_PIF.DWD_PRD_PRODCODE_DD
          WHERE TRIM(PRODCODE_TYPE) IS NOT NULL) N
  ON (TRIM(M.CPDM) = TRIM(N.PROD_CODE))
  WHEN MATCHED THEN
    UPDATE
       SET M.DXCPDM = N.PROD_CODE,
           M.CPTA   = N.PRODTA_NO,
           M.CPMC   = N.PROD_NAME,
           M.CPJC  =
           (CASE
             WHEN M.SJLY = 1 THEN
              M.CPJC
             WHEN N.ADD_DATE > 20210101 THEN
              NVL(TRIM(N.PRODALIAS_NAME), N.PROD_NAME)
             ELSE
               M.CPJC
           END),
           M.PYDM   = N.PRODSPELL_CODE,
           M.MJKSRQ =
           (CASE
             WHEN M.SJLY = 1 THEN
              M.MJKSRQ
             WHEN N.IPO_BEGIN_DATE >= 20991230 THEN
              M.MJKSRQ
             ELSE
              N.IPO_BEGIN_DATE
           END),
           M.MJJSRQ =
           (CASE
             WHEN M.SJLY = 1 THEN
              M.MJJSRQ
             WHEN N.IPO_END_DATE >= 20991230 THEN
              M.MJJSRQ
             ELSE
              N.IPO_END_DATE
           END),
           M.CLRQ  =
           (CASE
             WHEN M.SJLY = 1 THEN
              M.CLRQ
             WHEN N.PROD_BEGIN_DATE >= 20210101 THEN -- 李良ADD，成立日期大于2021年的产品才更新
              N.PROD_BEGIN_DATE
             ELSE
              M.CLRQ
           END),
           M.DQRQ   = N.PROD_END_DATE,
           M.TJQSRQ = N.PROM_BEGIN_DATE,
           M.TJZZRQ = N.PROM_END_DATE,
           M.CPQX   = N.PROD_TERM,
           M.CPJYZT = N.PROD_STATUS,
           M.HBZL   = N.MONEY_TYPE,
           M.FXJG   = N.ISSUE_PRICE,
           M.MFMZ   = N.PAR_VALUE,
           M.SFFS   = N.CHARGE_TYPE,
           M.FHFS   = N.DIVIDEND_WAY,
           --    M.QTJE   = N.MIN_SHARE,
           
           M.CPZDMJJE = N.PROD_MIN_BALA, --  产品最低募集金额
           M.CPZGMJJE = N.PROD_MAX_BALA, --  产品最高募集金额
           M.CPSJMJJE = N.PROD_REAL_BALA, --  产品实际募集金额
           
           M.NHTS    = N.YEAR_DAYS,
           M.YQSYL   = N.PRODPRE_RATIO,
           M.YQSYLMS = N.PROD_RATIO_STR,
           --  M.CPTAMC  = N.PRODCOMPANY_NAME,
           M.CPGLRID = NVL(M.CPGLRID,
                           (SELECT ID
                              FROM TPIF_JGDM A
                             WHERE (A.JGMC = N.PROD_MANAGER OR
                                   A.JGJC = N.PROD_MANAGER)
                               AND ROWNUM = 1)),
           M.CPTGR   = NVL(M.CPTGR,
                           (SELECT ID
                              FROM TPIF_JGDM A
                             WHERE (A.JGJC = N.PROD_TRUSTEE OR
                                   A.JGMC = N.PROD_TRUSTEE)
                               AND ROWNUM = 1)),
           
           M.TZLB      = N.INVEST_TYPE,
           M.SYLX      = TO_NUMBER(REPLACE(N.INCOME_TYPE, ',', '')),
           M.CPTZQX    = N.PROD_INVEST_TERM,
           M.CPFXDJ    = N.PRODRISK_LEVEL,
           M.CPPGDJ    = N.ASSESS_LEVEL,
           M.ZDFXDJ    = N.LOW_CORP_RISK_LEVEL,
           M.ZDZCYQ    = N.MIN_ASSET_NEED,
           M.YXZYTZZLX = N.EN_PROF_FLAG,
           
           M.CCLDZDZ   = N.CURRENT_AMOUNT_LOW, --持仓量的最低值
           M.RGRSSX    = MAX_SUBSCRIBE_NUM, --认购人数上限
           M.ZDZHJE    = N.MIN_SWITCH_IN_BALANCE, --最低转换金额
           M.ZSZHFE    = N.TRANS_LIMITSHARE, --最少转换份额
           M.ZHDW      = N.SWITCH_UNIT, --转换单位
           M.SHZDZ     = N.REDEEM_LIMITSHARE, --赎回最低份额
           M.SHZXDW    = N.REDEMPTION_UNIT, --赎回最小单位
           M.SHZJKYBZ  = N.REDEEM_USE_FLAG, --赎回资金可用标志
           M.MCZDKSGBL = N.MAX_ALLOTRATIO, --每次最大可申购比例
           
           M.ZHXGSJ = SYSDATE, --最后修改时间
           M.YRRQ   = N.ADD_DATE; --引入日期

  /*LTX 20211115调整，将MERGE 的插入语句拆分成单独语句*/

  --WHEN NOT MATCHED THEN 
  INSERT INTO PIF.TPIF_CPDM
    (ID, --  ID
     CPID, --CPID
     CPXL, -- 产品系列
     CPNBZT, -- 产品内部状态
     CPTA, --TA代码
     CPDM, --产品代码
     DXCPDM, --代销产品代码
     CPMC,
     CPJC, --产品简称
     PYDM, --拼音代码
     MJKSRQ, --  募集开始日期
     MJJSRQ, --  募集结束日期
     CLRQ, --  产品成立日期
     DQRQ, --  产品结束日期
     TJQSRQ, --  推介开始日期
     TJZZRQ, --  推介结束日期
     CPQX, --  产品期限
     CPJYZT, --  产品交易状态
     HBZL, --   币种类别
     FXJG, --  发行价格
     MFMZ, --  每份面值
     SFFS, --  基金收费方式
     FHFS, --  基金分红方式
     --  QTJE, --  起投金额
     CPZDMJJE, --  产品最低募集金额
     CPZGMJJE, --  产品最高募集金额
     CPSJMJJE, --  产品实际募集金额
     NHTS, --  产品年化天数
     YQSYL, --  产品预期年收益率
     YQSYLMS, --  产品预期年收益率文字描述
     CPTAMC, --  产品注册登记机构名称
     
     CPTGR, --  产品托管人
     
     TZLB, -- 产品投资类别
     SYLX, -- 产品收益类型
     CPTZQX, -- 产品投资期限
     CPFXDJ, -- 产品风险等级
     CPPGDJ, -- 产品评估等级
     ZDFXDJ, -- 最低风险等级
     ZDZCYQ, -- 投资者最低资产要求
     YXZYTZZLX, -- 允许专业投资者类型
     CCLDZDZ, --持仓量的最低值
     RGRSSX, --认购人数上限
     ZDZHJE, --最低转换金额
     ZSZHFE, --最少转换份额
     ZHDW, --转换单位
     SHZDZ, --赎回最低份额
     SHZXDW, --赎回最小单位
     SHZJKYBZ, --赎回资金可用标志
     MCZDKSGBL, --每次最大可申购比例
     
     SJSJ, --上架时间，理解为该产品进入产品代码表的时间
     ZHXGSJ, --最后修改时间
     ZHXGR, --最后修改人
     
     CPGLRID, --产品管理人ID
     YRRQ --引入日期
     )
    SELECT LIVEBOS.FUNC_NEXTID('TPIF_CPDM'),
           NULL,
           DECODE(N.PRODCODE_TYPE,
                  '1',
                  1,
                  '2',
                  1,
                  '3',
                  1,
                  '4',
                  1,
                  '5',
                  1,
                  '6',
                  1,
                  '7',
                  1,
                  '8',
                  1,
                  '9',
                  1,
                  'a',
                  1,
                  'b',
                  1,
                  'c',
                  3,
                  'm',
                  1,
                  'n',
                  13,
                  's',
                  13,
                  'r',
                  1,
                  'i',
                  4,
                  'j',
                  2,
                  'r',
                  1,
                  'z',
                  13,
                  NULL),
           8, --产品内部状态   8-已上架
           N.PRODTA_NO, --  产品TA
           N.PROD_CODE, --  产品代码
           N.PROD_CODE, --  代销产品代码
           N.PROD_NAME, --  产品名称
           NVL(TRIM(N.PRODALIAS_NAME), N.PROD_NAME), --  产品名称
           N.PRODSPELL_CODE, --  拼音代码
           N.IPO_BEGIN_DATE, --  募集开始日期
           N.IPO_END_DATE, --  募集结束日期
           N.PROD_BEGIN_DATE, --  产品成立日期
           N.PROD_END_DATE, --  产品结束日期
           N.PROM_BEGIN_DATE, --  推介开始日期
           N.PROM_END_DATE, --  推介结束日期
           N.PROD_TERM, --  产品期限
           N.PROD_STATUS, --  产品交易状态
           N.MONEY_TYPE, --   币种类别
           N.ISSUE_PRICE, --  发行价格
           N.PAR_VALUE, --  每份面值
           N.CHARGE_TYPE, --  基金收费方式
           N.DIVIDEND_WAY, --  基金分红方式
           --   N.MIN_SHARE, --  个人最低认购金额
           N.PROD_MIN_BALA, --  产品最低募集金额
           N.PROD_MAX_BALA, --  产品最高募集金额
           N.PROD_REAL_BALA, --  产品实际募集金额
           N.YEAR_DAYS, --  产品年化天数
           N.PRODPRE_RATIO, --  产品预期年收益率
           N.PROD_RATIO_STR, --  产品预期年收益率文字描述
           (SELECT A.TAMC FROM TPIF_TADM A WHERE A.TABM = N.PRODTA_NO), --根据TA编号获取对应TA名称
           
           (SELECT ID
              FROM TPIF_JGDM A
             WHERE (A.JGJC = N.PROD_TRUSTEE OR A.JGMC = N.PROD_TRUSTEE)
               AND A.BASFYX = 1), --  产品托管人
           
           NVL(TRIM(N.INVEST_TYPE), 5), -- 产品投资类别
           TO_NUMBER(REPLACE(N.INCOME_TYPE, ',', '')), -- 产品收益类型
           N.PROD_INVEST_TERM, -- 产品投资期限
           N.PRODRISK_LEVEL, -- 产品风险等级
           N.ASSESS_LEVEL, -- 产品评估等级
           N.LOW_CORP_RISK_LEVEL, -- 最低风险等级
           N.MIN_ASSET_NEED, -- 投资者最低资产要求
           N.EN_PROF_FLAG, -- 允许专业投资者类型
           N.CURRENT_AMOUNT_LOW, --持仓量的最低值
           N.MAX_SUBSCRIBE_NUM, --认购人数上限
           N.MIN_SWITCH_IN_BALANCE, --最低转换金额
           N.TRANS_LIMITSHARE, --最少转换份额
           N.SWITCH_UNIT, --转换单位
           N.REDEEM_LIMITSHARE, --赎回最低份额
           N.REDEMPTION_UNIT, --赎回最小单位
           NVL(TRIM(N.REDEEM_USE_FLAG), 0), --赎回资金可用标志
           N.MAX_ALLOTRATIO, --每次最大可申购比例
           
           SYSDATE,
           SYSDATE,
           0,
           (SELECT ID
              FROM TPIF_JGDM A
             WHERE (A.JGMC = N.PROD_MANAGER OR A.JGJC = N.PROD_MANAGER)
               AND A.BASFYX = 1), --产品管理人ID
           N.ADD_DATE --引入日期
      FROM SRC_PIF.DWD_PRD_PRODCODE_DD N
     WHERE TRIM(N.PRODCODE_TYPE) IS NOT NULL
       AND N.ADD_DATE >= 20210101
       AND TRIM(N.PRODRISK_LEVEL) > 0
       AND NOT EXISTS
     (SELECT 1 FROM TPIF_CPDM M WHERE TRIM(M.CPDM) = TRIM(N.PROD_CODE));

  UPDATE PIF.TPIF_CPDM SET CPID = ID WHERE CPID IS NULL;

  --CPMC处理
  --公募基金（SJLY=1）CPMC由聚源的全称更新
  --私募基金 (SJLY=2) CPMC由朝阳永续的全称更新
  UPDATE PIF.TPIF_CPDM T SET T.CPMC = T.CPJC WHERE T.CPMC IS NULL;

  --日期处理
  UPDATE TPIF_CPDM A
     SET A.MJKSRQ = (CASE
                      WHEN A.MJKSRQ = 0 THEN
                       NULL
                      ELSE
                       A.MJKSRQ
                    END),
         A.MJJSRQ = (CASE
                      WHEN A.MJJSRQ = 0 THEN
                       NULL
                      ELSE
                       A.MJJSRQ
                    END),
         A.CLRQ = (CASE
                    WHEN A.CLRQ = 0 THEN
                     NULL
                    ELSE
                     A.CLRQ
                  END),
         A.DQRQ = (CASE
                    WHEN A.DQRQ = 0 THEN
                     NULL
                    ELSE
                     A.DQRQ
                  END),
         A.TJQSRQ = (CASE
                      WHEN A.TJQSRQ = 0 THEN
                       NULL
                      ELSE
                       A.TJQSRQ
                    END),
         A.TJZZRQ = (CASE
                      WHEN A.TJZZRQ = 0 THEN
                       NULL
                      ELSE
                       A.TJZZRQ
                    END);
  --    WHERE A.CPXL = 1;

  --适当性 ，适合投资者类型
  UPDATE TPIF_CPDM A
     SET A.SHTZZLX = (CASE
                       WHEN A.CPFXDJ = 0 THEN
                        '1;2;3;4;5'
                       WHEN A.CPFXDJ = 1 THEN
                        '2;3;4;5'
                       WHEN A.CPFXDJ = 2 THEN
                        '3;4;5'
                       WHEN A.CPFXDJ = 3 THEN
                        '4;5'
                       WHEN A.CPFXDJ = 4 THEN
                        '5'
                     END)
   WHERE A.CPFXDJ IS NOT NULL;

  UPDATE TPIF_CPDM T --更新产品管理人名称
     SET T.CPGLRMC =
         (SELECT JGMC FROM TPIF_JGDM WHERE ID = T.CPGLRID)
   WHERE T.CPGLRMC IS NULL;

  UPDATE TPIF_CPDM T --更新产品托管人名称
     SET T.CPTGRMC =
         (SELECT JGMC FROM TPIF_JGDM WHERE ID = T.CPTGR)
   WHERE T.CPTGRMC IS NULL;

  UPDATE PIF.TPIF_CPDM_ZDXS A --更新优选产品和新发产品的产品交易状态
     SET A.CPJYZT =
         (SELECT B.CPJYZT FROM TPIF_CPDM B WHERE B.CPDM = A.CPDM)
   WHERE A.ZT = 1;

  --产品阶段处理
  --产品阶段：1预售期 2募集期 3 存续期 4 清盘期 5 结束期

  /*产品交易状态：
  1  开放期
  2  认购期
  3  预约认购期
  4  产品成立
  5  产品终止
  6  停止交易
  7  停止申购
  8  停止赎回*/

  UPDATE TPIF_CPDM A
     SET A.CPJD = DECODE(A.CPJYZT, 1, 3, 2, 2, 4, 3, 5, 5, 3)
   WHERE A.CPJYZT IS NOT NULL
     AND A.SJLY IS NULL; --数据来源为空的更新，
  --数据来源为1的（聚源公募） 根据聚源基金概况更新产品阶段
  --数据来源为2的（朝阳永续私募） 根据朝阳永续市场私募基金信息更新产品阶段

  COMMIT;

  O_CODE := 1;
  O_NOTE := 'TPIF_CPDM 表清洗成功';
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1; --运行失败
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPDM 表清洗,未知错误'
                ELSE
                 'TPIF_CPDM 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
    ROLLBACK;
END P_TRAN_CPDM;
/

