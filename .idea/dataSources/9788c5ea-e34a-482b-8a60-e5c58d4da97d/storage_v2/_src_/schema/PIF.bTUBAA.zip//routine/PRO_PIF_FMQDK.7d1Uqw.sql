create PROCEDURE PRO_PIF_FMQDK(O_CODE OUT NUMBER,
                                          O_NOTE OUT VARCHAR2,
                                          I_OPER IN NUMBER, --1|调入申请，2 |调出申请
                                          I_IDS  IN VARCHAR2, --勾选待审核记录
                                          I_LCID IN NUMBER --发起流程ID
                                          ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：负面清单库审批【1|调入，2 |调出】逻辑
      语法信息：
           输入参数：
           输出参数：
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人         修改内容简要说明
          2019-08-15     1.0       WUJINFENG              新增
  ***********************************************************************/
  V_COUNT NUMBER;
  V_IDS   VARCHAR2(500);

BEGIN
  O_CODE := 1;
  O_NOTE := '成功';

  --1|调入申请
  IF I_OPER = 1 THEN

    SELECT REPLACE(REPLACE(REPLACE(REPLACE(I_IDS, ' ', ''), '[', ''),
                           ']',
                           ''),
                   ',',
                   ';')
      INTO V_IDS
      FROM DUAL;

    DELETE FROM  PIF.LCFMQDDRSPLC_FMQD A WHERE INSTR(';' || V_IDS || ';', ';' || A.ID || ';') > 0;
    INSERT INTO PIF.LCFMQDDRSPLC_FMQD
      (LCFMQDDRSPLC_ID, ID, JGMC, TZJL, FMXX, WTYY, JYCS)
      SELECT I_LCID, A.ID, A.JGMC, A.TZJL, A.FMXX, A.WTYY, A.JYCS
        FROM PIF.TPIF_FMQDK A
       WHERE INSTR(';' || V_IDS || ';', ';' || A.ID || ';') > 0;

    UPDATE PIF.TPIF_FMQDK A SET  A.ZT = 2 WHERE INSTR(';' || V_IDS || ';', ';' || A.ID || ';') > 0;


  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := O_NOTE || SQLERRM;

END;
/

