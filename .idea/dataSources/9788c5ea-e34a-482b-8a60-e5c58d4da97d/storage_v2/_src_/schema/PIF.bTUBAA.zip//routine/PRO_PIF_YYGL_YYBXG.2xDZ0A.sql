create PROCEDURE     PRO_PIF_YYGL_YYBXG(O_CODE OUT NUMBER,
                                              O_NOTE OUT VARCHAR2,
                                              I_ID IN VARCHAR2, --营业部ID
                                              I_KYRS IN NUMBER,
                                              I_KYJE IN NUMBER,
                                              I_CPGLID IN NUMBER --产品管理ID

                                              ) AS
 /******************************************************************
      所属用户：PIF
      功能说明：
      语法信息：
           输入参数：     I_ID  营业部ID
                                 I_KYRS   可约人数
                                 I_KYJE   可约额度
                                 I_CPGLID 产品管理ID
           输出参数：   O_CODE  返回值
                               O_NOTE      返回消息
                              
      逻辑说明：   判断产品剩余额度，营业部修改额度要小于剩余额度                         
      修订记录：
          修订日期       版本号     修订人             修改内容简要说明
         2021-09-28     1.0.0     WEIWENHAO        营业部修改
  ***********************************************************************/

V_GLCPID NUMBER(10); --产品关联ID
V_CPGLID NUMBER(10);--产品管理ID
SUM_ZKYED NUMBER(16,2);--所有关联产品的营业部独属额度
SUM_ZKYRS NUMBER(16);--所有关联产品的营业部独属人数
V_DQYYED NUMBER(16,2);--营业部当前预约额度
V_DQYYRS NUMBER(10); --营业部当前预约人数
V_YYBID NUMBER(10); --营业部ID
V_CPYYED NUMBER(16,2);--产品预约额度
V_CPYYRS NUMBER(10); --产品预约人数
V_YYED NUMBER(16,2); --修改预约额度
V_YYRS NUMBER(10);--修改预约人数
V_COUNT NUMBER(10);

BEGIN
  V_CPGLID:=I_CPGLID;
  V_YYED:=I_KYJE;
  V_YYRS:=I_KYRS;
  V_YYBID:=I_ID;
  
--判断该产品是否关联其他产品或者被其他产品关联
SELECT GLCPID,YYZED,YYZRS INTO V_GLCPID,V_CPYYED,V_CPYYRS    FROM TPIF_YYCPGL WHERE ID =  V_CPGLID;
SELECT ZKYRS,ZKYED INTO V_DQYYRS,V_DQYYED FROM TPIF_YYBXE   WHERE YYBID =  V_YYBID AND CPGLID = V_CPGLID;
SELECT COUNT(1)  INTO  V_COUNT FROM TPIF_YYCPGL WHERE GLCPID = V_CPGLID;
--产品有关联
IF ((V_GLCPID IS NOT NULL ) OR (V_COUNT >0) )THEN
  IF V_COUNT >0 THEN
  --产品被关联
 SELECT SUM(ZKYED),SUM(ZKYRS) INTO SUM_ZKYED, SUM_ZKYRS FROM  PIF.TPIF_YYBXE WHERE CPGLID IN (SELECT ID FROM PIF.TPIF_YYCPGL WHERE (ID =V_CPGLID OR GLCPID = V_CPGLID) );

  --产品关联其他产品
  ELSIF V_GLCPID IS NOT NULL  THEN
     SELECT SUM(ZKYED),SUM(ZKYRS) INTO SUM_ZKYED, SUM_ZKYRS FROM  PIF.TPIF_YYBXE WHERE CPGLID IN (SELECT ID FROM PIF.TPIF_YYCPGL WHERE (ID =V_GLCPID OR GLCPID = V_GLCPID) );
END IF;
  --判断剩余额度
IF V_CPYYED <>0 THEN  
  IF (V_CPYYED - SUM_ZKYED +V_DQYYED-V_YYED)<0 THEN     
  O_CODE:=-1;
  O_NOTE:='营业部预约额度超出关联产品最大预约额度!';
  RETURN;
     END IF;
END IF;
     
  IF (V_CPYYRS - SUM_ZKYRS +V_DQYYRS-V_YYRS)<0 THEN
     O_CODE:=-1;
     O_NOTE:='营业部预约人数超出关联产品最大预约人数!';
     RETURN;
     END IF;
     
UPDATE TPIF_YYBXE SET ZKYED=V_YYED  , ZKYRS =V_YYRS  WHERE YYBID =V_YYBID  AND CPGLID = V_CPGLID ;



--产品无关联
ELSE

   SELECT SUM(ZKYED),SUM(ZKYRS) INTO SUM_ZKYED, SUM_ZKYRS FROM  PIF.TPIF_YYBXE WHERE CPGLID =V_CPGLID AND YYBID <>V_YYBID;
   IF SUM_ZKYED IS NULL THEN
     SUM_ZKYED:=0;
     END IF;
   IF SUM_ZKYRS IS NULL THEN
     SUM_ZKYRS:=0;
     END IF;
IF V_CPYYED<>0 THEN     
   IF (V_CPYYED - SUM_ZKYED-V_YYED)<0 THEN
    
      O_CODE:=-1;
      O_NOTE:='营业部预约额度超出最大预约额度!';
      RETURN;
      END IF;
END IF;

  IF  (V_CPYYRS - SUM_ZKYRS -V_YYRS)<0 THEN
     O_CODE:=-1;
     O_NOTE:='营业部预约人数超出最大预约人数!';
     RETURN;
     END IF;
     
       UPDATE TPIF_YYBXE SET ZKYED=V_YYED  , ZKYRS =V_YYRS  WHERE YYBID =V_YYBID  AND CPGLID = V_CPGLID ;

 

END IF;
 O_CODE:= 199;
O_NOTE := '修改成功!';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
           ROLLBACK;
END;
/

