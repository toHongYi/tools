create PROCEDURE PCX_PIF_BYLMXCX(O_RESULT OUT SYS_REFCURSOR,
                                            I_TYPE   IN NUMBER, --类型 1 ：产品 2：营业部产品
                                            I_CPDM   IN VARCHAR2, --产品代码/名称
                                            I_YYB    IN NUMBER --营业部id
                                            ) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 产品评价明细查询
  
      语法信息：
           输入参数：    I_TYPE   IN NUMBER --类型 1 ：产品 2：管理人
           输出参数：   O_RESULT
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-12-28    1.0       liutx              新增
  ***********************************************************************/
  V_NOTE VARCHAR2(1000); --报错信息输出
  V_CPDM VARCHAR2(200);
  V_YYB  NUMBER(8);

BEGIN

  IF I_CPDM IS NULL THEN
    V_CPDM := '-1';
  ELSE
    V_CPDM := I_CPDM;
  END IF;

  IF I_YYB IS NULL THEN
    V_YYB := -1;
  ELSE
    V_YYB := I_YYB;
  END IF;

  IF I_TYPE = 1 THEN
    OPEN O_RESULT FOR
      SELECT ROWNUM ID, A.*
        FROM (SELECT CL,
                     GLR,
                     TZJL,
                     CPDM,
                     CPJC,
                     XSQJ,
                     CPJZ,
                     CPMC,
                     SUM(BYFE) BYFE
                FROM PIF.TPIF_SSCC T
               WHERE V_CPDM = '-1'
                  OR CPDM LIKE '%' || V_CPDM || '%'
                  OR CPMC LIKE '%' || V_CPDM || '%'
                  OR CPJC LIKE '%' || V_CPDM || '%'
               GROUP BY CL, GLR, TZJL, CPDM, CPJC, XSQJ, CPJZ, CPMC
               ORDER BY CPDM) A;
  ELSIF I_TYPE = 2 THEN
    OPEN O_RESULT FOR
      SELECT ROWNUM ID, A.*
        FROM (SELECT YYB,
                     CL,
                     GLR,
                     TZJL,
                     CPDM,
                     CPJC,
                     XSQJ,
                     CPJZ,
                     CPMC,
                     SUM(BYFE) BYFE
                FROM PIF.TPIF_SSCC T
               WHERE (V_CPDM = '-1' OR CPDM LIKE '%' || V_CPDM || '%' OR
                     CPMC LIKE '%' || V_CPDM || '%' OR
                     CPJC LIKE '%' || V_CPDM || '%')
                 AND (V_YYB = -1 OR V_YYB = YYB)
               GROUP BY YYB, CL, GLR, TZJL, CPDM, CPJC, XSQJ, CPJZ, CPMC
               ORDER BY CPDM, YYB) A;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NOTE := SQLERRM;
    OPEN O_RESULT FOR
      SELECT -1 CODE, V_NOTE NOTE FROM DUAL;
  
END;
/

