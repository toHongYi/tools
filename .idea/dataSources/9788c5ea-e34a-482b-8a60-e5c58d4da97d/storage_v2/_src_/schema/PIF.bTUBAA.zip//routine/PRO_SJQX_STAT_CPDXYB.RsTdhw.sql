create PROCEDURE PRO_SJQX_STAT_CPDXYB(O_CODE OUT NUMBER,
                                                 O_NOTE OUT VARCHAR2,
                                                 I_YF   IN NUMBER) AS
  /******************************************************************
      所属用户：PIF
      功能说明：产品代销月表   DSC_STAT.TPIF_STAT_CPDXYB 清洗逻辑
      这个表作为中间表，先将产品打上标签更新到该表中，
      然后根据该表汇总结果到DSC_STAT.TPIF_STAT_CPDXYB_HZTJ
  
      接口查数据直接从DSC_STAT.TPIF_STAT_CPDXYB_HZTJ查询
      
      语法信息：
           输入参数：   I_YF 月份
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2021-04-12     1.0      GAOKUN             创建
          2021-04-21     1.1      GAOKUN             修改，源表-->中间表-->最终表
          2021-11-26     1.2      GAOKUN             修改收益类型取值来源，不从标签表取
  ***********************************************************************/
  V_YF    NUMBER;
  V_COUNT NUMBER;

BEGIN
  O_CODE := -1;
  O_NOTE := '';
  --默认清洗当月数据
  IF I_YF IS NULL THEN
    SELECT TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymm')) INTO V_YF FROM DUAL;
  ELSE
    V_YF := I_YF;
  END IF;
  --判断该表是否有数据，第一次采集全量，执行此过程也是全部MERG，后面每天增量采集当月
  --的数据，清洗也就执行ELSE部分，MERGE当月数据
  SELECT COUNT(1) INTO V_COUNT FROM DSC_STAT.TPIF_STAT_CPDXYB;

  IF V_COUNT = 0 THEN
    MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB M
    USING (SELECT INIT_MONTH, --月份
                  PROD_CODE, --产品代码
                  PROD_NAME, --产品名称
                  BRANCH_CODE, --营业部ID
                  PARENT_BRANCH_CODE, --分公司ID
                  SELL_BALANCE, --销售量
                  TOTAL_INVENTORY_BALANCE, --保有量
                  PROD_KIND --产品分类
             FROM SRC_PIF.ADS_INF_PRODUCT_CON_MONTHLY_DD
            WHERE TRIM(PROD_KIND) = '场外产品') N
    ON (M.YF = N.INIT_MONTH AND M.CPDM = N.PROD_CODE AND M.YYBID = N.BRANCH_CODE)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPMC  = N.PROD_NAME,
             M.FGSID = N.PARENT_BRANCH_CODE,
             M.XSL   = N.SELL_BALANCE,
             M.NBYL  = N.TOTAL_INVENTORY_BALANCE,
             M.CPFL  = N.PROD_KIND
    WHEN NOT MATCHED THEN
      INSERT
        (M.YF, M.CPDM, M.CPMC, M.YYBID, M.FGSID, M.XSL, M.NBYL, M.CPFL)
      VALUES
        (N.INIT_MONTH,
         N.PROD_CODE,
         N.PROD_NAME,
         N.BRANCH_CODE,
         N.PARENT_BRANCH_CODE,
         N.SELL_BALANCE,
         N.TOTAL_INVENTORY_BALANCE,
         N.PROD_KIND);
  ELSE
    MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB M
    USING (SELECT INIT_MONTH,
                  PROD_CODE,
                  PROD_NAME,
                  BRANCH_CODE,
                  PARENT_BRANCH_CODE,
                  SELL_BALANCE,
                  TOTAL_INVENTORY_BALANCE,
                  PROD_KIND
             FROM SRC_PIF.ADS_INF_PRODUCT_CON_MONTHLY_DD
            WHERE INIT_MONTH = V_YF --月份
              AND TRIM(PROD_KIND) = '场外产品') N
    ON (M.YF = N.INIT_MONTH AND M.CPDM = N.PROD_CODE AND M.YYBID = N.BRANCH_CODE AND M.YF = V_YF)
    WHEN MATCHED THEN
      UPDATE
         SET M.CPMC  = N.PROD_NAME,
             M.FGSID = N.PARENT_BRANCH_CODE,
             M.XSL   = N.SELL_BALANCE,
             M.NBYL  = N.TOTAL_INVENTORY_BALANCE,
             M.CPFL  = N.PROD_KIND
    WHEN NOT MATCHED THEN
      INSERT
        (M.YF, M.CPDM, M.CPMC, M.YYBID, M.FGSID, M.XSL, M.NBYL, M.CPFL)
      VALUES
        (N.INIT_MONTH,
         N.PROD_CODE,
         N.PROD_NAME,
         N.BRANCH_CODE,
         N.PARENT_BRANCH_CODE,
         N.SELL_BALANCE,
         N.TOTAL_INVENTORY_BALANCE,
         N.PROD_KIND);
  END IF;

  --更新 产品收益类型（2固收、1权益、3货币）和销售产品系列（1公募、2私募...）
  /*  SELECT COUNT(1)
   INTO V_COUNT
   FROM DSC_STAT.TPIF_STAT_CPDXYB
  WHERE BQLXID IS NOT NULL;*/

  --IF V_COUNT = 0 THEN
  MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB M
  USING (SELECT A.CPDM,
                B.PROD_INCOME_TYPE AS BQLXMC, --标签类型名称
                (CASE
                  WHEN B.PROD_INCOME_TYPE_CODE = 1 THEN
                   900013
                  WHEN B.PROD_INCOME_TYPE_CODE = 2 THEN
                   900012
                  WHEN B.PROD_INCOME_TYPE_CODE = 3 THEN
                   900014
                END) AS BQLXID, --标签类型ID
                (CASE
                  WHEN B.PROD_TYPE_CODE = 1 THEN
                   1
                  WHEN B.PROD_TYPE_CODE IN (2, 3, 8) THEN
                   2
                  WHEN B.PROD_TYPE_CODE = 4 THEN
                   4
                  WHEN B.PROD_TYPE_CODE = 5 THEN
                   5
                END) AS XSCPXL --销售产品系列
           FROM TPIF_CPDM A, TPIF_SALE_PROD_TYPE_INFO B
          WHERE A.CPDM = B.PROD_CODE
            AND B.PROD_INCOME_TYPE_CODE IS NOT NULL --收益类型不为空
            AND B.PROD_TYPE_CODE IS NOT NULL --产品类型不为空
         ) N
  ON (TRIM(M.CPDM) = TRIM(N.CPDM))
  WHEN MATCHED THEN
    UPDATE
       SET M.BQLXID = N.BQLXID, M.BQLXMC = N.BQLXMC, M.XSCPXL = N.XSCPXL;
  /*ELSE
    MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB M
    USING (SELECT A.CPDM,
                  B.PROD_INCOME_TYPE AS BQLXMC, --标签类型名称
                  (CASE
                    WHEN B.PROD_INCOME_TYPE_CODE = 1 THEN
                     900013
                    WHEN B.PROD_INCOME_TYPE_CODE = 2 THEN
                     900012
                    WHEN B.PROD_INCOME_TYPE_CODE = 3 THEN
                     900014
                  END) AS BQLXID, --标签类型ID
                  (CASE
                    WHEN B.PROD_TYPE_CODE = 1 THEN
                     1
                    WHEN B.PROD_TYPE_CODE IN (2, 3, 8) THEN
                     2
                    WHEN B.PROD_TYPE_CODE = 4 THEN
                     4
                    WHEN B.PROD_TYPE_CODE = 5 THEN
                     5
                  END) AS XSCPXL --销售产品系列
             FROM TPIF_CPDM A, TPIF_SALE_PROD_TYPE_INFO B
            WHERE A.CPDM = B.PROD_CODE
              AND B.PROD_INCOME_TYPE_CODE IS NOT NULL --收益类型不为空
              AND B.PROD_TYPE_CODE IS NOT NULL --产品类型不为空
           ) N
    ON (TRIM(M.CPDM) = TRIM(N.CPDM) AND M.YF = V_YF) --月份
    WHEN MATCHED THEN
      UPDATE
         SET M.BQLXID = N.BQLXID, M.BQLXMC = N.BQLXMC, M.XSCPXL = N.XSCPXL;
  END IF;*/

  --更新 产品代销月表_汇总统计
  DELETE FROM DSC_STAT.TPIF_STAT_CPDXYB_HZTJ WHERE 1 = 1;
  SELECT COUNT(1) INTO V_COUNT FROM DSC_STAT.TPIF_STAT_CPDXYB_HZTJ;

  IF V_COUNT = 0 THEN
    MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB_HZTJ M
    USING (SELECT YF,
                  YYBID,
                  ROUND(SUM(XSL) / 10000, 2) AS XSL,
                  ROUND(SUM(NBYL) / 10000, 2) AS NBYL,
                  BQLXID,
                  BQLXMC,
                  XSCPXL
             FROM DSC_STAT.TPIF_STAT_CPDXYB
            WHERE BQLXID IS NOT NULL
              AND XSCPXL IS NOT NULL
            GROUP BY YF, YYBID, BQLXID, BQLXMC, XSCPXL) N
    ON (M.YF = N.YF AND M.YYBID = N.YYBID AND M.BQLXID = N.BQLXID AND M.XSCPXL = N.XSCPXL)
    WHEN MATCHED THEN
      UPDATE SET M.XSL = N.XSL, M.NBYL = N.NBYL, M.BQLXMC = N.BQLXMC
    WHEN NOT MATCHED THEN
      INSERT
        (M.YF, M.YYBID, M.XSL, M.NBYL, M.BQLXID, M.BQLXMC, M.XSCPXL)
      VALUES
        (N.YF, N.YYBID, N.XSL, N.NBYL, N.BQLXID, N.BQLXMC, N.XSCPXL);
  ELSE
    MERGE INTO DSC_STAT.TPIF_STAT_CPDXYB_HZTJ M
    USING (SELECT YF,
                  YYBID,
                  ROUND(SUM(XSL) / 10000, 2) AS XSL,
                  ROUND(SUM(NBYL) / 10000, 2) AS NBYL,
                  BQLXID,
                  BQLXMC,
                  XSCPXL
             FROM DSC_STAT.TPIF_STAT_CPDXYB
            WHERE YF = V_YF --月份
              AND BQLXID IS NOT NULL
              AND XSCPXL IS NOT NULL
            GROUP BY YF, YYBID, BQLXID, BQLXMC, XSCPXL) N
    ON (M.YF = N.YF AND M.YYBID = N.YYBID AND M.BQLXID = N.BQLXID AND M.XSCPXL = N.XSCPXL AND M.YF = V_YF)
    WHEN MATCHED THEN
      UPDATE SET M.XSL = N.XSL, M.NBYL = N.NBYL, M.BQLXMC = N.BQLXMC
    WHEN NOT MATCHED THEN
      INSERT
        (M.YF, M.YYBID, M.XSL, M.NBYL, M.BQLXID, M.BQLXMC, M.XSCPXL)
      VALUES
        (N.YF, N.YYBID, N.XSL, N.NBYL, N.BQLXID, N.BQLXMC, N.XSCPXL);
  END IF;

  COMMIT;
  O_CODE := 1;
  O_NOTE := 'DSC_STAT.TPIF_STAT_CPDXYB相关表清洗成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1; --运行失败
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'DSC_STAT.TPIF_STAT_CPDXYB相关表清洗,未知错误'
                ELSE
                 'DSC_STAT.TPIF_STAT_CPDXYB相关表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
    ROLLBACK;
  
END;
/

