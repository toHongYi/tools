create PROCEDURE PCX_PIF_YYGL_YYRWLB(O_CODE            OUT NUMBER,
                                                O_NOTE            OUT VARCHAR2,
                                                O_RESULT          OUT SYS_REFCURSOR,
                                                I_CURRENT         IN NUMBER, --页码   
                                                I_PAGESIZE        IN NUMBER, --页长 
                                                I_PAGING          IN NUMBER, --是否分页 
                                                I_SORT            IN STRING, --排序规模 
                                                I_TOTAL           IN OUT NUMBER, --记录总数 
                                                I_QUERY_TYPE      IN VARCHAR2, --查询类型 1|执行人；2|管理人
                                                I_USERID          IN NUMBER, --任务执行人ID
                                                I_PROD_ID         IN NUMBER, --产品ID
                                                I_PROD_EVENT_TYPE IN NUMBER, --产品事件类型
                                                I_IMPORTANT_LEVEL IN NUMBER, --重要程度
                                                I_TASK_CONTENT    IN VARCHAR2, --任务内容
                                                I_BEGIN_DATE      IN NUMBER, --开始日期
                                                I_END_DATE        IN NUMBER, --结束日期
                                                I_EXEC_STATUS     IN NUMBER, --执行状态
                                                I_IS_OVERDUE      IN NUMBER --是否超期   0|否；1|是
                                                
                                                ) AS

  /*--------------------------------------------------------------------------------------------
  
  项目名称：海通证券产品中心
  
         功能说明：运营任务列表
             参数说明：
                  入参：
                        I_PAGING       IN NUMBER,
                        I_PAGENO       IN NUMBER,
                        I_PAGELENGTH   IN NUMBER,
                        I_TOTALROWS    IN OUT NUMBER,
                        I_SORT         IN VARCHAR2,
                        I_QUERY_TYPE         IN VARCHAR2, --1|执行人；2|管理人
                        I_USERID       IN NUMBER,   --任务执行人ID
                        I_PROD_ID         IN NUMBER,   --产品ID
                        I_PROD_EVENT_TYPE       IN NUMBER,   --产品事件类型
                        I_IMPORTANT_LEVEL         IN NUMBER,   --重要程度
                        I_TASK_CONTENT         IN VARCHAR2, --任务内容
                        I_BEGIN_DATE         IN NUMBER,    --开始日期
                        I_END_DATE         IN NUMBER ,   --结束日期
                        I_EXEC_STATUS         IN NUMBER,    --执行状态
                        I_IS_OVERDUE         IN NUMBER     --是否超期
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
  
  
  
        ----------------------------------------------------------
        操作人   版本号     时间                         操作
        刘浪浪   1.0.1     2014/11/15                  新增
        刘浪浪   1.0.2     2014/11/20                  根据USERID是否为运营管理岗来进行数据筛选
        刘浪浪   1.0.3     2014/11/24                  增加产品事件类型查询参数
        刘浪浪   1.0.4     2015/01/26                  增加产品代码返回值
  
  -------------------------------------------------------------------------------------------------*/
  V_SQL          VARCHAR2(8000);
  V_SORT         VARCHAR2(200);
  V_COLLIST      VARCHAR2(500);
  V_HASRECORDSET NUMBER;
BEGIN
  O_CODE         := 1;
  O_NOTE         := '成功!';
  V_HASRECORDSET := 1;
  I_TOTAL        := -1;
  V_SORT         := I_SORT;
  IF I_QUERY_TYPE IS NULL OR I_USERID IS NULL THEN
    O_CODE := -1;
    O_NOTE := '查询类型或用户不能为空!';
    RETURN;
  END IF;


  V_SQL := 'SELECT A.ID AS ID,
                   A.ZYCD IMPORTANT_LEVEL,
                   (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_ZYCD'' AND IBM=A.ZYCD)  AS IMPORTANT_LEVEL_DESC,
                   A.CPID PROD_ID,
                   B.CPDM         PROD_CODE,
                   B.CPMC     PROD_NAME,
                   (SELECT LXMC FROM TPIF_CPSJLX WHERE ID=A.CPSJLX)     EVENT_TYPE,
                   (SELECT LXMC FROM TPIF_CPYYRWLX WHERE ID=A.YYRWLX)   OPERATE_TASK_TYPE,
                   REPLACE(A.ZXRY,'';'','','') EXEC_PERSON_ID,
                   (SELECT WM_CONCAT(NAME) FROM LIVEBOS.TUSER WHERE INSTR('';''||A.ZXRY || '';'','';''|| ID || '';'')>0) EXEC_PERSON,
                   (SELECT EMAIL FROM LIVEBOS.TUSER WHERE INSTR('';''||A.ZXRY || '';'','';''|| ID || '';'')>0) EXEC_PERSON_EMAIL,   
                   A.RWNR  TASK_CONTENT,
                   A.ZXZT EXEC_STATUS,
                   (SELECT NOTE FROM LIVEBOS.TXTDM WHERE FLDM=''PIF_ZXZT'' AND IBM=A.ZXZT)  EXEC_STATUS_DESC,
                   CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDDHH24MISS''))-TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))<=0 THEN ''+'' ELSE ''-'' END TIMEOUT_MARK,
                   CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDD''))-TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDD''))=0 THEN
                   DECODE(ABS(TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDDHH24''))-TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24''))),0,1,ABS(TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDDHH24''))-TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24''))))
                   ELSE ABS(ROUND(SYSDATE-A.YJZXWCSJ,0)) END AS TIME,
                   CASE WHEN TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDD''))-TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDD''))=0 THEN ''小时'' ELSE ''天'' END AS UNIT,
                   TO_CHAR(A.YJZXKSSJ,''YYYY/MM/DD'') EXEC_FINISH_DATE,
                   TO_CHAR(A.YJZXWCSJ,''YYYY/MM/DD'') EXPECTED_FINISH_DATE
                   FROM TPIF_CPYYRW A,TPIF_CPDM B
                   WHERE A.CPID=B.ID ';

  IF I_SORT IS NULL THEN
    --排序
    V_SORT := 'EXEC_FINISH_DATE DESC,EXPECTED_FINISH_DATE DESC';
  
  END IF;

  IF I_PROD_ID IS NOT NULL THEN
    --按照产品搜索
    V_SQL := V_SQL || ' AND A.CPID=' || I_PROD_ID;
  END IF;

  IF I_PROD_EVENT_TYPE IS NOT NULL THEN
    --产品事件类型
    V_SQL := V_SQL || ' AND A.CPSJLX=' || I_PROD_EVENT_TYPE;
  END IF;

  IF I_IMPORTANT_LEVEL IS NOT NULL THEN
    --按照事件重要程度搜索
    V_SQL := V_SQL || ' AND A.ZYCD=' || I_IMPORTANT_LEVEL;
  END IF;

  --IF I_QUERY_TYPE = 1 THEN
    --任务执行人
    V_SQL := V_SQL || ' AND INSTR('';''||A.ZXRY||'';'','';' || I_USERID ||
             ';'')>0';
  --END IF;

  IF I_TASK_CONTENT IS NOT NULL THEN
    --任务内容模糊搜索
    V_SQL := V_SQL || ' AND A.RWNR LIKE ''%' || I_TASK_CONTENT || '%''';
  END IF;

  IF I_BEGIN_DATE IS NOT NULL THEN
    V_SQL := V_SQL || ' AND TO_NUMBER(TO_CHAR(A.YJZXKSSJ,''YYYYMMDD''))>=' ||
             I_BEGIN_DATE;
  END IF;

  IF I_END_DATE IS NOT NULL THEN
    V_SQL := V_SQL || ' AND TO_NUMBER(TO_CHAR(A.YJZXKSSJ,''YYYYMMDD''))<=' ||
             I_END_DATE;
  END IF;

  IF I_EXEC_STATUS IS NOT NULL THEN
    V_SQL := V_SQL || ' AND A.ZXZT=' || I_EXEC_STATUS;
  END IF;

  IF I_IS_OVERDUE IS NOT NULL THEN
    --是否超期
    IF I_IS_OVERDUE = 0 THEN
      V_SQL := V_SQL || '
                     AND ((A.ZXZT=0 AND TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))>=TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDDHH24MISS'')))
                             OR (A.ZXZT=1 AND TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))>=TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))))';
    ELSE
      V_SQL := V_SQL || '
                     AND ((A.ZXZT=0 AND TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))<TO_NUMBER(TO_CHAR(SYSDATE,''YYYYMMDDHH24MISS'')))
                             OR (A.ZXZT=1 AND TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))<TO_NUMBER(TO_CHAR(A.YJZXWCSJ,''YYYYMMDDHH24MISS''))))';
    END IF;
  END IF;

  DBMS_OUTPUT.PUT_LINE(V_SQL);

  --V_COLLIST := 'ID,ZYCD,CPID,产品代码,产品名称,事件类型,运营任务类型,执行人员,任务内容,ZXZT,执行状态,CSBZ,SJ,DW,执行开始日期,预计完成日期';
  V_COLLIST := 'ID,IMPORTANT_LEVEL,IMPORTANT_LEVEL_DESC,PROD_ID,PROD_CODE,PROD_NAME,EVENT_TYPE,OPERATE_TASK_TYPE,EXEC_PERSON_ID,EXEC_PERSON,EXEC_PERSON_EMAIL,TASK_CONTENT,EXEC_STATUS,EXEC_STATUS_DESC,TIMEOUT_MARK,TIME,UNIT,EXEC_FINISH_DATE,EXPECTED_FINISH_DATE';
  PCX_TYCX(O_CODE,
           O_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           I_PAGING,
           I_CURRENT,
           I_PAGESIZE,
           I_TOTAL,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => FALSE,
           I_SORT         => V_SORT,
           I_HASWITH      => FALSE);

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
END PCX_PIF_YYGL_YYRWLB;
/

