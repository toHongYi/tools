create PROCEDURE PCX_APP_QXGL_YHCDQX(O_CODE   OUT NUMBER,
                                                O_NOTE   OUT VARCHAR2,
                                                O_RESULT OUT SYS_REFCURSOR,
                                                I_USERID IN NUMBER) AS
  /******************************************************************
  项目名称：财通运营展业平台
  所属用户：PIF
  概要说明：APP-权限管理-菜单权限控制
            I_USERID VARCHAR2  用户登录账号
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      20201216      1.0.0      gaokun                   新增
  *****************************************************************************************************************/
  V_ERRMSG VARCHAR2(3000);
  V_COUNT  NUMBER;
  V_ORGID  NUMBER;
  V_ROLEID NUMBER;
BEGIN
  O_CODE := 1;
  O_NOTE := '成功！';

  IF I_USERID IS NULL THEN
    O_CODE := 99;
    O_NOTE := '登录账号不能为空！';
    RETURN;
  END IF;

  SELECT COUNT(1) INTO V_COUNT FROM LIVEBOS.TUSER WHERE ID = I_USERID;
  IF V_COUNT = 0 THEN
    O_CODE := 99;
    O_NOTE := '登录账号未注册！';
    RETURN;
  END IF;

  IF I_USERID = 0 THEN
    --如果是ADMIN用户
    OPEN O_RESULT FOR
      SELECT I_USERID AS USERID, N.ID, N.NAME, N.DESCRIBE, M.MOBILE_MENU
        FROM LIVEBOS.LBFUNDEFINITION N,
             (SELECT FUNNAME, OBJECT AS MOBILE_MENU
                FROM LIVEBOS.LBFUNFACTOR
               WHERE FUNNAME LIKE 'APP%') M
       WHERE N.NAME = M.FUNNAME;
  
  ELSE
    --查询该用户所属组织机构
    SELECT ORGID INTO V_ORGID FROM LIVEBOS.TUSER WHERE ID = I_USERID; 
    --查询该用户是否属于某个角色
    SELECT COUNT(1)
      INTO V_ROLEID
      FROM LIVEBOS.LBMEMBER
     WHERE USERID = I_USERID
       AND ROLEID IS NOT NULL; --所属角色
    
    --如果属于某个角色 或者 组织机构   
    IF V_ROLEID > 0 OR V_ORGID IS NOT NULL THEN
      OPEN O_RESULT FOR
        SELECT I_USERID USERID, C.ID, C.NAME, C.DESCRIBE, C.MOBILE_MENU
          FROM (SELECT B.ID,
                       B.NAME,
                       B.DESCRIBE,
                       A.OBJECT AS MOBILE_MENU,
                       LIVEBOS.FUNC_GETAUTH(I_USERID, B.NAME) RIGHT
                  FROM LIVEBOS.LBFUNFACTOR A, LIVEBOS.LBFUNDEFINITION B
                 WHERE A.FUNNAME LIKE 'APP%'
                   AND A.FUNNAME = B.NAME) C
         WHERE C.RIGHT = '1';
    
    
    END IF;
  
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      V_ERRMSG := SQLERRM;
      O_CODE   := 99;
      O_NOTE   := '查询出错 ! 错误:' || V_ERRMSG;
    END;
END;
/

