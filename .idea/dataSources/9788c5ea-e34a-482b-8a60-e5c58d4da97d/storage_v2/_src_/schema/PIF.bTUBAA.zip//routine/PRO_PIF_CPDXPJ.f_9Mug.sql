create PROCEDURE PRO_PIF_CPDXPJ(I_CPID         IN NUMBER, --CPID
                                           I_CPZLJTZFG    IN NUMBER, -- 产品种类及投资风格
                                           I_JJJLTZNL     IN NUMBER, -- 基金经理投资能力
                                           I_CPYJPJ       IN NUMBER, --产品业绩评级
                                           I_KHDJJCPLXPHD IN NUMBER, --客户对基金产品类型偏好度
                                           I_KHDJJGLRPHD  IN NUMBER, --客户对基金管理人偏好度
                                           I_ZF           IN NUMBER, --总分
                                           I_USERID       IN NUMBER --
                                           ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：产品代销评价分数保存
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：

      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2019-08-09     1.0       吴金锋              创建
  ***********************************************************************/
  V_COUNT NUMBER;
BEGIN
  --INIT
  --O_CODE := -1;
  --O_NOTE := '';
  SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPDXPJ A WHERE A.CPID = I_CPID;

  IF V_COUNT > 0 THEN

    UPDATE TPIF_CPDXPJ A
       SET A.CPZLJTZFG = I_CPZLJTZFG,  -- 产品种类及投资风格
           A.JJJLTZNL  = I_JJJLTZNL,   -- 基金经理投资能力
           A.CPYJPJ  = I_CPYJPJ,       --产品业绩评级
           A.KHDJJCPLXPHD  = I_KHDJJCPLXPHD,       --客户对基金产品类型偏好度
           A.KHDJJGLRPHD  = I_KHDJJGLRPHD,       --客户对基金管理人偏好度
           A.ZF        = I_ZF,
           A.PJR       = I_USERID,
           A.PJSJ      = SYSDATE
     WHERE A.CPID = I_CPID;

  ELSE
    INSERT INTO TPIF_CPDXPJ
      (id,
       cpid,
       cpzljtzfg,
       jjjltznl,
       cpyjpj,
       khdjjcplxphd,
       khdjjglrphd,
       zf,
       pjr,
       pjsj)
    values
      (I_CPID,
       I_CPID,
       I_CPZLJTZFG,
       i_jjjltznl,
       i_cpyjpj,
       i_khdjjcplxphd,
       i_khdjjglrphd,
       i_zf,
       I_USERID,
       SYSDATE);

  END IF;

  COMMIT;
  --O_CODE := 1;
  --O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --O_CODE := -1;
  /* O_NOTE := (CASE
    WHEN O_NOTE IS NULL THEN
     '未知错误'
    ELSE
     O_NOTE || ' 时出现异常'
  END) || ':' || SQLERRM;*/
END;
/

