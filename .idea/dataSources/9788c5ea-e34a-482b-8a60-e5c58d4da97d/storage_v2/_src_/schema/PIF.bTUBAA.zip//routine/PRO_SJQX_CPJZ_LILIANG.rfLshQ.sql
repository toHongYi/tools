create PROCEDURE PRO_SJQX_CPJZ_LILIANG(O_CODE      OUT NUMBER, --返回值
                                                  O_NOTE      OUT VARCHAR2, --返回消息
                                                  I_CPID      IN NUMBER,
                                                  I_INIT_DATE IN NUMBER) IS
  V_COUNT      NUMBER;
  V_COUNT_CPJZ NUMBER;
  V_INIT_DATE  NUMBER DEFAULT I_INIT_DATE;
  V_CPID       NUMBER DEFAULT I_CPID;
BEGIN

  O_CODE := -1;
  O_NOTE := '';
  /************一、柜台净值导入 ********************************************/
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPJZ_LILIANG; --判断净值表是否有数据

  IF V_COUNT = 0 THEN
    --没有则全部插入
    INSERT INTO TPIF_CPJZ_LILIANG
      (ID,
       CPID, --产品ID
       JYRQ, --交易日期
       JZRQ, --净值日期
       DWJZ, --单位净值
       LJJZ, --累计净值
       SJLY, --5 集中柜台
       QRZT, --1 有效
       CZSJ) --操作时间
      SELECT SEQ_TPIF_CPJZ_LILIANG.NEXTVAL,
             B.CPID,
             TO_NUMBER(TRIM(M.INIT_DATE)),
             TO_NUMBER(TRIM(M.NAV_DATE)),
             TO_NUMBER(TRIM(M.NET_VALUE)),
             TO_NUMBER(TRIM(M.NAV_TOTAL)),
             5,
             1,
             SYSDATE
        FROM SRC_PIF.DWD_PRD_PRODPRICE_DD M, --柜台净值表
             PIF.TPIF_CPDM                B --产品代码表
       WHERE M.PROD_CODE = B.CPDM
         AND B.JYNM IS NULL;
  ELSE
    IF I_INIT_DATE = 0 OR I_INIT_DATE IS NULL THEN
      -- 默认取上5交易日
      SELECT MAX(JYR)
        INTO V_INIT_DATE
        FROM LIVEBOS.TXTJYR A
       WHERE A.JYR < TO_CHAR(SYSDATE - 5, 'YYYYMMDD');
    END IF;
  
    IF I_CPID IS NULL THEN
      V_CPID := 0;
    END IF;
    MERGE INTO PIF.TPIF_CPJZ_LILIANG M
    USING (SELECT B.CPID,
                  TO_NUMBER(TRIM(M.INIT_DATE)) AS INIT_DATE,
                  TO_NUMBER(TRIM(M.NAV_DATE)) AS NAV_DATE,
                  TO_NUMBER(TRIM(M.NET_VALUE)) AS NET_VALUE,
                  TO_NUMBER(TRIM(M.NAV_TOTAL)) AS NAV_TOTAL
             FROM SRC_PIF.DWD_PRD_PRODPRICE_DD M, --柜台净值表
                  PIF.TPIF_CPDM                B --产品代码表
            WHERE M.PROD_CODE = B.CPDM
              AND B.JYNM IS NULL
              AND (V_CPID = 0 OR B.CPID = V_CPID)
              AND M.INIT_DATE >= V_INIT_DATE) N
    ON (M.CPID = N.CPID AND M.JYRQ = N.INIT_DATE)
    WHEN MATCHED THEN
      UPDATE
         SET M.DWJZ = N.NET_VALUE, --单位净值
             M.LJJZ = N.NAV_TOTAL
    WHEN NOT MATCHED THEN
      INSERT
        (ID,
         CPID, --产品ID
         JYRQ, --交易日期
         JZRQ, --净值日期
         DWJZ, --单位净值
         LJJZ, --累计净值
         SJLY, --5 柜台
         QRZT) --1 有效
      VALUES
        (SEQ_TPIF_CPJZ.NEXTVAL,
         N.CPID,
         N.INIT_DATE,
         N.NAV_DATE,
         N.NET_VALUE,
         N.NAV_TOTAL,
         5,
         1);
    V_COUNT_CPJZ := SQL%ROWCOUNT;
  END IF;

  /**************四丶产品最新净值表清空并重新插入最新数据**************************/

  -- todo 最新净值，就直接mergeinto，不用删了

  /**************五丶更新TPIF_CPDM表净值信息***************************************/
  MERGE INTO PIF.TPIF_CPDM M --1S
  USING (SELECT CPID, JZRQ, DWJZ, LJJZ, NHSYL_D7, WFSYL
           FROM TPIF_CPZXJZ_LILIANG
          WHERE (V_CPID = 0 OR CPID = V_CPID)) N
  ON (M.CPID = N.CPID)
  WHEN MATCHED THEN
    UPDATE
       SET M.JZRQ    = N.JZRQ,
           M.CPJZ    = N.DWJZ,
           M.LJJZ    = N.LJJZ,
           M.QRNHSYL = N.NHSYL_D7,
           M.WFSYL   = N.WFSYL;

  COMMIT;

  -- 第一次全量
  IF V_COUNT = 0 THEN
    INSERT INTO TPIF_CPJZXX_CPZX_LILIANG
      (CPID, JZRQ, ZCJZ, DWJZ, LJJZ, FQJZ, JYRQ)
      SELECT CPID, JZRQ, ZCJZ, DWJZ, LJJZ, FQJZ, JYRQ
        FROM (SELECT CPID,
                     JZRQ,
                     ZCJZ,
                     DWJZ,
                     LJJZ,
                     FQJZ,
                     JYRQ,
                     ROW_NUMBER() OVER(PARTITION BY CPID, JZRQ ORDER BY JYRQ DESC) AS RN
                FROM TPIF_CPJZ_LILIANG)
       WHERE RN = 1; --同一净值日期，如果存在不同净值信息，则取交易日期最大的那一天的数据
  ELSE
    MERGE INTO TPIF_CPJZXX_CPZX_LILIANG M
    USING (SELECT CPID, JZRQ, ZCJZ, DWJZ, LJJZ, FQJZ, JYRQ
             FROM (SELECT CPID,
                          JZRQ,
                          ZCJZ,
                          DWJZ,
                          LJJZ,
                          FQJZ,
                          JYRQ,
                          ROW_NUMBER() OVER(PARTITION BY CPID, JZRQ ORDER BY JYRQ DESC) AS RN
                     FROM TPIF_CPJZ_LILIANG
                    WHERE JYRQ >= V_INIT_DATE
                      AND (V_CPID = 0 OR CPID = V_CPID))
            WHERE RN = 1) N
    ON (M.JZRQ = N.JZRQ AND M.CPID = N.CPID)
    WHEN MATCHED THEN
      UPDATE
         SET M.JYRQ = N.JYRQ,
             M.ZCJZ = N.ZCJZ,
             M.DWJZ = N.DWJZ,
             M.LJJZ = N.LJJZ,
             M.FQJZ = N.FQJZ
    WHEN NOT MATCHED THEN
      INSERT
        (CPID, JZRQ, ZCJZ, DWJZ, LJJZ, FQJZ, JYRQ)
      VALUES
        (N.CPID, N.JZRQ, N.ZCJZ, N.DWJZ, N.LJJZ, N.FQJZ, N.JYRQ);
  END IF;

  COMMIT;

  O_CODE := 1;
  O_NOTE := 'TPIF_CPJZ 表清洗成功,产品净值数量：' || V_COUNT_CPJZ;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_CPJZ 表清洗,未知错误'
                ELSE
                 'TPIF_CPJZ 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

