create PROCEDURE PRO_PIF_CPQJMBDY(O_CODE OUT NUMBER, --返回值
                                                 O_NOTE OUT VARCHAR2, --返回消息
                                                 I_USER IN INTEGER, --操作人
                                                 I_IP   IN VARCHAR2, --操作IP
                                                 I_OPER IN INTEGER, --操作类型0|新增;1|修改;2|删除;3|启用;4|禁用;8|校验有效性;9|复制;
                                                 I_ID   IN INTEGER, --操作ID
                                                 I_OP   IN VARCHAR2 := '' --其他
                                                 ) IS
    /*
    **功能说明：全景模版定义管理
    **创建人：戴文生
    **创建日期：2014-12-01
    **************************************************************************
    **修改记录
    **************************************************************************
    **修改者     版本号    修改日期     说明
    **戴文生              2014-12-01    创建
    */
    V_COUNT INTEGER; --计数变量
    V_ID    INTEGER;
    V_YQID  INTEGER;
    V_FZID  INTEGER;
    V_ZDID  INTEGER;
    V_OBJ   TPIF_CPQJMBDY%ROWTYPE; --表单记录
    V_NOTE  VARCHAR2(2000); --描述信息
BEGIN
    --INIT
    O_CODE := -1;
    O_NOTE := '';
    BEGIN
        SELECT * INTO V_OBJ FROM TPIF_CPQJMBDY WHERE ID = I_ID;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    --check
    IF I_OPER IS NULL THEN
        O_NOTE := '系统异常:操作类型标识为空!';
        RETURN;
    END IF;
    --START
    O_NOTE := '业务处理';
    IF I_OPER = 0 THEN
        --//:新增-----------------------------------------------------------------------
        IF V_OBJ.MBBM IS NULL THEN
            O_NOTE := '[模版编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.MBMC IS NULL THEN
            O_NOTE := '[模版名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[产品集合]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPQJMBDY_SYFW
         WHERE TPIF_CPQJMBDY_ID = I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '[适用范围]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBBM = V_OBJ.MBBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[模版编码]--' || V_OBJ.MBBM || '!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBMC = V_OBJ.MBMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[模版名称]--' || V_OBJ.MBMC || '!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 1 THEN
        --修改-----------------------------------------------------------------------
        IF V_OBJ.MBZT = 1 THEN
            O_NOTE := '当前模版已启用,不允许执行[修改]操作!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        IF V_OBJ.MBBM IS NULL THEN
            O_NOTE := '[模版编码]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.MBMC IS NULL THEN
            O_NOTE := '[模版名称]不允许为空!';
            RETURN;
        END IF;
        IF V_OBJ.CPJH IS NULL THEN
            O_NOTE := '[产品集合]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_CPQJMBDY_SYFW
         WHERE TPIF_CPQJMBDY_ID = I_ID;
        IF V_COUNT = 0 THEN
            O_NOTE := '[适用范围]不允许为空!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBBM = V_OBJ.MBBM;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[模版编码]--' || V_OBJ.MBBM || '!';
            RETURN;
        END IF;
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBMC = V_OBJ.MBMC;
        IF V_COUNT > 1 THEN
            O_NOTE := '不允许存在重复的[模版名称]--' || V_OBJ.MBMC || '!';
            RETURN;
        END IF;
    END IF;
    IF I_OPER = 2 THEN
        --删除-----------------------------------------------------------------------
        IF V_OBJ.MBZT = 1 THEN
            O_NOTE := '当前模版已[启用]!';
            RETURN;
        END IF;
        SELECT FUNC_PIF_JYSFYY('TPIF_CPQJMBDY', I_ID) INTO V_COUNT FROM DUAL;
        IF V_COUNT = 1 THEN
            O_NOTE := '当前模版已存在引用记录!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        DELETE TPIF_CPQJMBDY WHERE ID = I_ID;
    END IF;
    IF I_OPER = 3 THEN
        --启用-----------------------------------------------------------------
        IF V_OBJ.MBZT = 1 THEN
            O_NOTE := '当前模版已[启用]!';
            RETURN;
        END IF;
            FOR CUR_S IN (SELECT ID, FZMC
                            FROM TPIF_QJYQXSFZ
                           WHERE QJMB = I_ID
                             AND ZT = 1) LOOP
                SELECT COUNT(1)
                  INTO V_COUNT
                  FROM TPIF_QJFZXSZD
                 WHERE QJMB = I_ID
                   AND FZ = CUR_S.ID
                   AND ZT = 1;
                IF V_COUNT = 0 THEN
                    O_NOTE := '分组[' || CUR_S.FZMC || ']无启用的显示配置!';
                    RETURN;
                END IF;
            END LOOP;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        UPDATE TPIF_CPQJMBDY SET MBZT = 1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 4 THEN
        --禁用-----------------------------------------------------------------
        IF V_OBJ.MBZT = -1 THEN
            O_NOTE := '当前模版已[禁用]!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        UPDATE TPIF_CPQJMBDY SET MBZT = -1 WHERE ID = I_ID;
    END IF;
    IF I_OPER = 8 THEN
        --校验有效性-------------------------------------------------------------------
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPQJMBDY WHERE MBZT = 1;
        IF V_COUNT = 0 THEN
            V_NOTE := V_NOTE || '当前无[启用]模版;';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM (SELECT 1 FROM TPIF_CPQJMBDY GROUP BY MBBM HAVING COUNT(MBBM) > 1);
        IF V_COUNT > 0 THEN
            V_NOTE := V_NOTE || '当前存在重复的[模版编码];';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM (SELECT 1 FROM TPIF_CPQJMBDY GROUP BY MBMC HAVING COUNT(MBMC) > 1);
        IF V_COUNT > 0 THEN
            V_NOTE := V_NOTE || '当前存在重复的[模版名称];';
        END IF;
        SELECT COUNT(1)
          INTO V_COUNT
          FROM TPIF_TYMBDY A
         WHERE A.MBZT = 1
           AND EXISTS (SELECT 1
                  FROM TPIF_CPQJMBDY_SYFW B
                 WHERE B.TPIF_CPQJMBDY_ID = A.ID
                   AND B.FWLX = 0);
        IF V_COUNT = 0 THEN
            V_NOTE := V_NOTE || '当前无适用于[所有用户]的启用模板;';
        END IF;
        LIVEBOS.PNEXTID('TPIF_XJRZ', V_ID);
        IF V_NOTE IS NULL THEN
            V_NOTE := '巡检正常!';
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_007'
                           AND ROWNUM = 1),
                       '<font color=green>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        ELSE
            V_NOTE := '巡检异常:' || V_NOTE;
            INSERT INTO TPIF_XJRZ
                (ID, XJLX, XJJG, XJR, XJRQ, XJIP)
                SELECT V_ID,
                       (SELECT ID
                          FROM TPIF_XJLX
                         WHERE BM = 'XJ_007'
                           AND ROWNUM = 1),
                       '<font color=red>' || V_NOTE || '</font>',
                       I_USER,
                       SYSDATE,
                       I_IP
                  FROM DUAL;
        END IF;
    END IF;
/*    IF I_OPER = 9 THEN
        --复制-----------------------------------------------------------------
        IF V_OBJ.MBZT = 1 THEN
            O_NOTE := '当前模板模版已[启用]!';
            RETURN;
        END IF;
        IF I_IP = '[check]' THEN
            O_CODE := 1;
            O_NOTE := '';
            RETURN;
        END IF;
        --
        DELETE TPIF_QJYQXSFZ WHERE QJMB = I_ID;
        DELETE TPIF_QJFZXSZD WHERE QJMB = I_ID;
        FOR CUR_YQ IN (SELECT * FROM TPIF_CPQJYQDY WHERE QJMB = I_OP) LOOP
            LIVEBOS.PNEXTID('TPIF_CPQJYQDY', V_YQID);
            INSERT INTO TPIF_CPQJYQDY
                (ID, QJMB, YQBM, YQMC, XSPX, YQLB, XSTJ, URL, ZT, BZ)
            VALUES
                (V_YQID,
                 I_ID,
                 CUR_YQ.YQBM,
                 CUR_YQ.YQMC,
                 CUR_YQ.XSPX,
                 CUR_YQ.YQLB,
                 CUR_YQ.XSTJ,
                 CUR_YQ.URL,
                 CUR_YQ.ZT,
                 CUR_YQ.BZ);
            FOR CUR_FZ IN (SELECT *
                             FROM TPIF_QJYQXSFZ
                            WHERE QJMB = I_OP
                              AND QJYQ = CUR_YQ.ID) LOOP
                LIVEBOS.PNEXTID('TPIF_QJYQXSFZ', V_FZID);
                INSERT INTO TPIF_QJYQXSFZ
                    (ID, QJMB, QJYQ, FZBM, FZMC, XSPX, XSLS, XSTJ, ZT, BZ)
                VALUES
                    (V_FZID,
                     I_ID,
                     V_YQID,
                     CUR_FZ.FZBM,
                     CUR_FZ.FZMC,
                     CUR_FZ.XSPX,
                     CUR_FZ.XSLS,
                     CUR_FZ.XSTJ,
                     CUR_FZ.ZT,
                     CUR_FZ.BZ);
                FOR CUR_ZD IN (SELECT *
                                 FROM TPIF_QJFZXSZD
                                WHERE QJMB = I_OP
                                  AND YQ = CUR_YQ.ID
                                  AND FZ = CUR_FZ.ID) LOOP
                    LIVEBOS.PNEXTID('TPIF_QJFZXSZD', V_ZDID);
                    INSERT INTO TPIF_QJFZXSZD
                        (ID, QJMB, YQ, FZ, XSMC, XSSX, YWDX, CPSX, MS, IDBZ, ZT, BZ)
                    VALUES
                        (V_ZDID,
                         I_ID,
                         V_YQID,
                         V_FZID,
                         CUR_ZD.XSMC,
                         CUR_ZD.XSSX,
                         CUR_ZD.YWDX,
                         CUR_ZD.CPSX,
                         CUR_ZD.MS,
                         CUR_ZD.IDBZ,
                         CUR_ZD.ZT,
                         CUR_ZD.BZ);
                END LOOP;
            END LOOP;
        END LOOP;
        UPDATE LIVEBOS.TSEQUENCE
           SET ID =
               (SELECT NVL(MAX(ID), 0) FROM TPIF_QJYQXSFZ)
         WHERE NAME = 'TPIF_QJYQXSFZ';
        UPDATE LIVEBOS.TSEQUENCE
           SET ID =
               (SELECT NVL(MAX(ID), 0) FROM TPIF_QJFZXSZD)
         WHERE NAME = 'TPIF_QJFZXSZD';
    END IF;*/
    --RETURN
    O_CODE := 199;
    SELECT '执行[' || DECODE(I_OPER,
                           0,
                           '新增',
                           1,
                           '修改',
                           2,
                           '删除',
                           3,
                           '启用',
                           4,
                           '禁用',
                           8,
                           '校验有效性',
                           '复制') || ']成功!'
      INTO O_NOTE
      FROM DUAL;
    IF I_OPER = 8 THEN
        O_NOTE := O_NOTE || V_NOTE;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        O_CODE := -99;
        O_NOTE := (CASE
                      WHEN O_NOTE IS NULL THEN
                       '未知错误'
                      ELSE
                       '在 ' || O_NOTE || ' 时出现异常'
                  END) || ':' || SQLERRM;
END PRO_PIF_CPQJMBDY;

/

