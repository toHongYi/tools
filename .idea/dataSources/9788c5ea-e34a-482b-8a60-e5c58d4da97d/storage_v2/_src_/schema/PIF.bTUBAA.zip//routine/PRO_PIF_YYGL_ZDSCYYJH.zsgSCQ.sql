create PROCEDURE PRO_PIF_YYGL_ZDSCYYJH( O_CODE OUT NUMBER,
                                                   O_NOTE OUT VARCHAR2
                                               /*  I_CZR  IN NUMBER, --操作人
                                                   I_IP   IN VARCHAR2, --操作IP
                                                   I_CPID IN VARCHAR2, --产品ID串,不同产品ID用分号隔开
                                                   I_MBBM IN VARCHAR2  --运营计划模板*/
                                                  ) AS

    /*--------------------------------------------------------------------------------------------

    项目名称：方正证券产品中心

           功能说明：自动批量生成运营计划
               参数说明：PRO_PIF_YYGL_ZDSCYYJH

                    出参：
                          O_CODE   OUT   NUMBER,
                          O_NOTE   OUT   VARCHAR2,



          ----------------------------------------------------------
          操作人        版本号        时间                      操作
          wujinfeng        1.0    2017/08/27                   新增

    -------------------------------------------------------------------------------------------------*/
    V_MBBM  VARCHAR2(100);
    V_COUNT NUMBER;

BEGIN

    O_CODE := 1;
    O_NOTE := '成功';
    --公募、私募、资管、收益凭证、银行理财
    FOR CUR_CPXX IN(SELECT CPID,
                           CPDM,
                           CPMC,
                           JRCPFL AS CPX
                      FROM TPIF_CPDM A
                     WHERE A.Cpnbzt = 8
                       AND JRCPFL IS NOT NULL

                       AND NOT EXISTS (SELECT 1 FROM TPIF_CPYYJH B WHERE B.CPID=A.CPID ) ) LOOP--只要有一次初始化即可

        --生成产品运营计划 OTCPT,YHTPT
        SELECT COUNT(*) INTO V_COUNT FROM TPIF_CPYYJHMB WHERE  CPFL = CUR_CPXX.CPX AND SFQY = 1;
        IF V_COUNT >0 THEN
          SELECT MAX(MBBM) INTO V_MBBM FROM TPIF_CPYYJHMB WHERE  CPFL = CUR_CPXX.CPX AND SFQY = 1;

          PRO_PIF_YYGL_SCYYJH_ZDSJ(O_CODE, O_NOTE, 0, '127.0.0.1', CUR_CPXX.CPID, V_MBBM);
          IF O_CODE > 0  THEN
              --设置运营计划生效
              UPDATE PIF.TPIF_CPYYJH SET SFSX = 1 WHERE INSTR(';'||CUR_CPXX.CPID||';',';'||CPID||';')>0;
          END IF;

        END IF;

    END LOOP;
    COMMIT ;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK ;
        O_CODE := -1;
        O_NOTE := '失败!' || SQLERRM;

END ;
/

