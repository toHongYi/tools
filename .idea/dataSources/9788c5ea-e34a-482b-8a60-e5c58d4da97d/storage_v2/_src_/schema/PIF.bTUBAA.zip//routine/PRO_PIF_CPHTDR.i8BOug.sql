create PROCEDURE PRO_PIF_CPHTDR(O_CODE OUT NUMBER,
                                           O_NOTE OUT VARCHAR2,
                                           I_USER IN NUMBER) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：产品合同导入
      语法信息：
           输入参数：
           输出参数：
      逻辑说明：
           1、
      修订记录：
          修订日期       版本号    修订人         修改内容简要说明
          2021-11-18     1.0       HANQIAONAN     新增
  ***********************************************************************/
  V_YZDHTID NUMBER; --原合同最大ID
  V_COUNT   NUMBER;
  V_COUNT_Y INTEGER := 0; --成功数
  V_COUNT_N INTEGER := 0; --失败数
  V_SBHTBHS VARCHAR2(32767); --失败的合同编号
  V_CODE    NUMBER;
  V_NOTE    VARCHAR2(32767);

BEGIN
  SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPHT;
  --获取原最大合同ID
  IF V_COUNT = 0 THEN
    V_YZDHTID := 0;
  ELSE
    SELECT MAX(ID) INTO V_YZDHTID FROM TPIF_CPHT;
  END IF;

  FOR CUR IN (SELECT * FROM PIF.TPIF_CPHTDR A) LOOP
    --含有空格不导入
    IF INSTR(cur.htbh, ' ') > 0 THEN
      V_COUNT_N := V_COUNT_N + 1;
      V_SBHTBHS := V_SBHTBHS || cur.htbh || ';';
      CONTINUE;
    END IF;
  
    --编号重复校验
    SELECT COUNT(1)
      INTO v_count
      FROM tpif_cpht
     WHERE htbh = CUR.htbh
       AND sfsc = 0;
    IF V_COUNT > 0 THEN
      V_COUNT_N := V_COUNT_N + 1;
      V_SBHTBHS := V_SBHTBHS || cur.htbh || ';';
      CONTINUE;
    END IF;
  
    --产品代码验证
    SELECT COUNT(1) INTO v_count FROM TPIF_CPDM WHERE CPDM = CUR.CPDM;
    IF V_COUNT = 0 THEN
      V_COUNT_N := V_COUNT_N + 1;
      V_SBHTBHS := V_SBHTBHS || cur.htbh || ';';
      CONTINUE;
    END IF;
  
    --导入产品合同表
  
    INSERT INTO TPIF_CPHT
      (id, cpid, cpdm, htbh, zt, czr, czsj, sfsc)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_CPHT'),
       (SELECT CPID FROM TPIF_CPDM WHERE CPDM = CUR.CPDM),
       CUR.CPDM,
       CUR.HTBH,
       1,
       I_USER,
       SYSDATE,
       0);
  
    V_COUNT_Y := V_COUNT_Y + 1;
  
  END LOOP;

  --导入合同流水

  MERGE INTO TPIF_HTLSCX T1
  USING (SELECT ID, CPID, CPDM, HTBH, '导入产品合同' AS SQLC
           FROM TPIF_CPHT
          WHERE ID > V_YZDHTID) T2
  ON (T1.CPID = T2.CPID AND T1.HTID = T2.ID AND T1.SQLC = T2.SQLC)
  WHEN NOT MATCHED THEN
    INSERT
      (T1.ID, T1.CPID, T1.CPDM, T1.HTID, T1.SQLC, T1.CZSJ, T1.HTZT)
    VALUES
      (LIVEBOS.FUNC_NEXTID('TPIF_HTLSCX'),
       T2.CPID,
       T2.CPDM,
       T2.ID,
       T2.SQLC,
       SYSDATE,
       1);

  --清除临时表数据
  DELETE FROM PIF.TPIF_CPHTDR;

  O_CODE := 199;
  IF V_COUNT_N = 0 THEN
    O_NOTE := '成功导入' || V_COUNT_Y || '条数据';
  ELSE
    O_NOTE := '成功导入' || V_COUNT_Y || '条数据,' || V_COUNT_N || '条失败,失败的合同编号:' ||
              V_SBHTBHS;
  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := O_NOTE || SQLERRM;
  
END;
/

