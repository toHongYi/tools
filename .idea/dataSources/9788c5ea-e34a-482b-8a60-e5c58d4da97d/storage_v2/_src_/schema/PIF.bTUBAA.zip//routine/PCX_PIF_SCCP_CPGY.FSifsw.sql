create PROCEDURE PCX_PIF_SCCP_CPGY(O_CODE   OUT NUMBER,
                                              O_NOTE   OUT VARCHAR2,
                                              O_RESULT OUT SYS_REFCURSOR,
                                              I_USERID IN NUMBER) AS
  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明： 市场产品-产品概要 
  
  
      语法信息：
           输入参数：   I_USERID   IN NUMBER , --登录用户ID
           输出参数：   O_RESULT
      逻辑说明：
           
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2020-07-14    1.0       WUJINFENG              新增
          2021-08-31    1.1        GAOKUN            初步修改避免报错，后续根据实
                                                     际需求修改优化
  ***********************************************************************/
  --V_SQL VARCHAR2(2000);

BEGIN

  --INIT
  O_CODE := -1;
  O_NOTE := '';

  IF I_USERID IS NULL THEN
    O_NOTE := '入参 I_USERID 不允许为空！';
    RETURN;
  END IF;

  OPEN O_RESULT FOR
    SELECT 1 AS PROD_TYPE, -- 产品类型
           '公募基金' AS PROD_TYPE_DESC, -- 产品类型
           COUNT(1) AS PROD_NUM, -- 产品类型
           'INFO.TINFO_JJGK' AS REMARKS -- 产品类型,表名
      FROM INFO.TINFO_JJGK
     WHERE LISTEDSTATE != 5
    UNION ALL
    SELECT 2 AS PROD_TYPE,
           '私募基金' AS PROD_TYPE_DESC,
           COUNT(1) AS PROD_NUM,
           'PIF.TPIF_SCSMJJXX' AS REMARKS
      FROM PIF.TPIF_SCSMJJXX
     WHERE FUND_STATUS = 1;


  /*  --迁移招商市场产品池，后期根据实情情况调整
  
  OPEN O_RESULT FOR
  
    SELECT 1 AS PROD_TYPE, -- 产品类型
           '公募基金' AS PROD_TYPE_DESC, -- 产品类型
           COUNT(*) AS PROD_NUM, -- 产品类型
           'INFO.VINFO_JJGK' AS REMARKS -- 产品类型
      FROM INFO.VINFO_JJGK
    
    UNION ALL
    
    SELECT 2 AS PROD_TYPE, -- 产品类型
           '私募基金' AS PROD_TYPE_DESC, --  产品类型描述
           COUNT(*) AS PROD_NUM, --产品数量
           'INFO.TINFO_SMJJZXXX' AS REMARKS --备注
      FROM INFO.TINFO_SMJJZXXX
    
    UNION ALL
    
    SELECT 3 AS PROD_TYPE, -- 产品类型
           '券商理财' AS PROD_TYPE_DESC, --  券商理财基础信息
           COUNT(*) AS PROD_NUM, --产品数量
           'INFO.TINFO_QSLCJCXX' AS REMARKS --备注
      FROM INFO.TINFO_QSLCJCXX
    
    UNION ALL
    
    SELECT 4 AS PROD_TYPE, -- 产品类型
           '银行理财' AS PROD_TYPE_DESC, --  银行理财基本信息
           COUNT(*) AS PROD_NUM, --产品数量
           'INFO.TINFO_YHLCCPJBJL' AS REMARKS --备注
      FROM INFO.TINFO_YHLCCPJBJL
    
    UNION ALL
    
    SELECT 5 AS PROD_TYPE, -- 产品类型
           '信托理财' AS PROD_TYPE_DESC, --  信托理财基本信息
           COUNT(*) AS PROD_NUM, --产品数量
           'INFO.TINFO_XTLCJBXXB' AS REMARKS --备注
      FROM INFO.TINFO_XTLCJBXXB
    
    UNION ALL
    
    SELECT 6 AS PROD_TYPE, -- 产品类型
           '保险理财' AS PROD_TYPE_DESC, --  保险理财基本信息
           COUNT(*) AS PROD_NUM, --产品数量
           'INFO.TINFO_BXLCJBXX' AS REMARKS --备注
      FROM INFO.TINFO_BXLCJBXX;*/

  O_CODE := 1;
  O_NOTE := '成功';

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败:' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
  
END;
/

