create FUNCTION FUNC_PIF_JYRL_JYRCDJJRCL(I_DATE  IN DATE, --要判断的日期
                                                    I_JJRGZ IN NUMBER --节假日规则
                                                    ) RETURN DATE AS
  /******************************************************************
  项目名称：银河产品中心
  所属用户：PIF
  概要说明：节假日规则处理(已由过程FUNC_PIF_JYRL_QJGGZR取代，暂时作废)

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2016-06-27     V1.0      谢莉莉             创建
      2016-10-18     V2.0      王大一             移植并修改
  *********************************************************************************************************************/

  V_DATE  DATE; --返回日期
  V_JJRGZ NUMBER; --节假日规则

BEGIN
  V_DATE := I_DATE;
  IF (I_JJRGZ = 1) THEN
    V_JJRGZ := -1;
  ELSIF (I_JJRGZ = 2) THEN
    V_JJRGZ := 1;
    --ELSE
    --    V_JJRGZ := I_JJRGZ;
  END IF;
  while (FUNC_PIF_JYRL_JJRPD(V_DATE) > 0) loop
    V_DATE := V_DATE + V_JJRGZ;
  end loop;
  RETURN V_DATE;
END FUNC_PIF_JYRL_JYRCDJJRCL;
/

