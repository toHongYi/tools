create PROCEDURE PCX_PIF_CPYQ(O_RESULT     OUT SYS_REFCURSOR,
                                         I_PAGENO     IN NUMBER, --页码
                                         I_PAGELENGTH IN NUMBER, --分页长度
                                         I_TOTALROWS  IN OUT NUMBER, --总记录数
                                         I_USEID      IN INTEGER, --操作用户
                                         I_CPMC       IN VARCHAR2,
                                         I_QSRQ       IN NUMBER,
                                         I_JSRQ       IN NUMBER) AS
  /******************************************************************
  项目名称：产品中心-舆情库-产品舆情
  所属用户：PIF
  概要说明：查询产品对比已选产品.
  
  语法信息：
       输出参数：
          O_CODE          返回值
          O_NOTE          返回信息
          O_RESULT        返回的数据集合,不一定会有,但通常用于返回结果集合.
  数据准备：
  
  运行原理：
        参见：简要说明
  功能修订：
      简要说明：
        查询产品对比已选产品.
  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/07/16     1.0.     WUJINFENG             新增.
  *********************************************************************************************************************/
  V_SQL          VARCHAR2(32767);
  V_SUB_SQL      VARCHAR2(10000);
  V_ERR          VARCHAR2(500);
  V_NUM          NUMBER;
  VN_CODE        NUMBER(8);
  VS_NOTE        VARCHAR2(300);
  V_COLLIST      VARCHAR2(1000);
  V_SORT         VARCHAR2(300);
  V_HASRECORDSET NUMBER(8);
BEGIN

  --/*+parallel(t,10) (b,10)*/

  V_SQL := ' SELECT/*+PARALLEL(A,8)*/ A.ID,A.CPDM,A.CPMC,A.CPJC, ';
  --V_SQL := ' SELECT  A.ID,A.CPDM,A.CPMC,A.CPJC, ';
  --1. 股票舆情
  V_SUB_SQL := '';
  V_NUM := 1 ;
  FOR CUR_YQ IN(SELECT * FROM TPIF_CPYQFLMX WHERE CPYQ =1 ) LOOP
    
     IF V_NUM > 1  THEN 
       
        V_SUB_SQL := V_SUB_SQL ||'||''<br/>''||' ;
        
     END IF ;

     --V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||N.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true"><font color=blue size=2>'|| CUR_YQ.LXMC ||' :(''|| COUNT(*)||'')条</font></a></u>'' 
      V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="javascrip:void(0)" onclick="window.open(''''/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||A.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true'''','''''''',''''height=650, width=1200, top=265,left=645, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no'''')" ><font color=blue size=2>'|| CUR_YQ.LXMC ||': ''|| COUNT(*)||'' 条</font></a></u>''                           
                                        FROM '||CUR_YQ.BDM|| ' M,';
      
      --1|基金;2|债券;3|股票;4|管理人;5|基金经理                              
      IF CUR_YQ.GLLX = 3 THEN 
                                        
         V_SUB_SQL := V_SUB_SQL 
                     || ' PIF.VPIF_CPDM_GL_JJZCGP N ,
                          INFO.TINFO_ZXZX_GPJBXX P 
                     WHERE N.GPDM=P.TRD_CODE 
                       AND P.ID=M.'||CUR_YQ.GLZD||' 
                       AND N.CPID = A.CPID  
                       AND ('||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0)' ;
      END IF;
      
      
      IF CUR_YQ.GLLX = 1 THEN 
                                        
         V_SUB_SQL := V_SUB_SQL 
                     || ' INFO.TINFO_ZXZX_JJJBXX P 
                     WHERE P.ID=M.'||CUR_YQ.GLZD||' 
                       AND P.TRD_CODE = A.CPDM  
                       AND ('||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0)' ;
      END IF;                                 
                                           

     V_NUM := V_NUM + 1;
  END LOOP ;

  V_SQL := V_SQL || '('||V_SUB_SQL||') AS GPYQ,' ;

    --债券舆情
  V_SUB_SQL := '';
  V_NUM := 1 ;
  FOR CUR_YQ IN(SELECT * FROM TPIF_CPYQFLMX WHERE CPYQ = 2) LOOP
    
     IF V_NUM > 1  THEN 
       
        V_SUB_SQL := V_SUB_SQL ||'||''<br/>''||' ;
        
     END IF ;
 
     --V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||N.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true"><font color=blue size=2>'|| CUR_YQ.LXMC ||' :(''|| COUNT(*)||'')条</font></a></u>'' 
     V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="javascrip:void(0)" onclick="window.open(''''/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||A.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true'''','''''''',''''height=650, width=1200, top=265,left=645, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no'''')" ><font color=blue size=2>'|| CUR_YQ.LXMC ||': ''|| COUNT(*)||'' 条</font></a></u>'' 
                                         
                                         FROM '||CUR_YQ.BDM|| ' M,
                                              PIF.VPIF_CPDM_GL_JJZQZH N ,
                                              INFO.TINFO_ZXZX_ZQJBXX P 
                                         WHERE N.ZQDM=P.TRD_CODE 
                                           AND P.ID=M.'||CUR_YQ.GLZD||' 
                                           AND N.CPID = A.CPID   
                                           AND ('||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0)' ;
                                           

     V_NUM := V_NUM + 1;
  END LOOP ;

  V_SQL := V_SQL || '('||V_SUB_SQL||') as ZQYQ,' ;
  
  
  --管理人
  V_SUB_SQL := '';
  V_NUM := 1 ;
  FOR CUR_YQ IN(SELECT * FROM TPIF_CPYQFLMX WHERE CPYQ =3 ) LOOP
    
     IF V_NUM > 1  THEN 
       
        V_SUB_SQL := V_SUB_SQL ||'||''<br/>''||' ;
        
     END IF ;

     --V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||N.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true"><font color=blue size=2>'|| CUR_YQ.LXMC ||' :(''|| COUNT(*)||'')条</font></a></u>'' 
      V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="javascrip:void(0)" onclick="window.open(''''/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||A.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true'''','''''''',''''height=650, width=1200, top=265,left=645, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no'''')" ><font color=blue size=2>'|| CUR_YQ.LXMC ||': ''|| COUNT(*)||'' 条</font></a></u>''                           
                                        FROM '||CUR_YQ.BDM|| ' M,';
      
      --1|基金;2|债券;3|股票;4|管理人;5|基金经理                              
      IF CUR_YQ.GLLX = 1 THEN 
                                        
         V_SUB_SQL := V_SUB_SQL 
                     || ' INFO.TINFO_ZXZX_JJJBXX P 
                     WHERE P.ID=M.'||CUR_YQ.GLZD||' 
                       AND P.TRD_CODE = A.CPDM  
                       AND ('||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0)' ;
      END IF;                                 
                                           

     V_NUM := V_NUM + 1;
  END LOOP ;

  V_SQL := V_SQL || '('||V_SUB_SQL||') AS GLRYQ,' ;
  
  
   --基金经理
  V_SUB_SQL := '';
  V_NUM := 1 ;
  FOR CUR_YQ IN(SELECT * FROM TPIF_CPYQFLMX WHERE CPYQ =4 ) LOOP
    
     IF V_NUM > 1  THEN 
       
        V_SUB_SQL := V_SUB_SQL ||'||''<br/>''||' ;
        
     END IF ;

     --V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||N.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true"><font color=blue size=2>'|| CUR_YQ.LXMC ||' :(''|| COUNT(*)||'')条</font></a></u>'' 
      V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="javascrip:void(0)" onclick="window.open(''''/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||A.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true'''','''''''',''''height=650, width=1200, top=265,left=645, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no'''')" ><font color=blue size=2>'|| CUR_YQ.LXMC ||': ''|| COUNT(*)||'' 条</font></a></u>''                           
                                        FROM '||CUR_YQ.BDM|| ' M,';
      
      --1|基金;2|债券;3|股票;4|管理人;5|基金经理                              
      IF CUR_YQ.GLLX = 1 THEN 
                                        
         V_SUB_SQL := V_SUB_SQL 
                     || ' INFO.TINFO_ZXZX_JJJBXX P 
                     WHERE P.ID=M.'||CUR_YQ.GLZD||' 
                       AND P.TRD_CODE = A.CPDM  
                       AND ('||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0) ' ;
      END IF;                                 
                                           

     V_NUM := V_NUM + 1;
  END LOOP ;

  V_SQL := V_SQL || '('||V_SUB_SQL||') AS JJJLYQ, ' ;
  
  --申赎情况
  V_SUB_SQL := '';
  V_NUM := 1 ;
  FOR CUR_YQ IN(SELECT * FROM TPIF_CPYQFLMX WHERE CPYQ =5 ) LOOP
    
     IF V_NUM > 1  THEN 
       
        V_SUB_SQL := V_SUB_SQL ||'||''<br/>''||' ;
        
     END IF ;

     --V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||N.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true"><font color=blue size=2>'|| CUR_YQ.LXMC ||' :(''|| COUNT(*)||'')条</font></a></u>'' 
      V_SUB_SQL := V_SUB_SQL || '(SELECT ''<u><a href="javascrip:void(0)" onclick="window.open(''''/livebos/UIProcessor?Table='||CUR_YQ.URL||'&CPID=''||A.CPID||''&QSRQ='||I_QSRQ||'&JSRQ='||I_JSRQ||'&ParamAction=true'''','''''''',''''height=650, width=1200, top=265,left=645, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no'''')" ><font color=blue size=2>'|| CUR_YQ.LXMC ||': ''|| COUNT(*)||'' 条</font></a></u>''                           
                                        FROM '||CUR_YQ.BDM|| ' M,';
      
      --1|基金;2|债券;3|股票;4|管理人;5|基金经理                              
      IF CUR_YQ.GLLX = 1 THEN 
                                        
         V_SUB_SQL := V_SUB_SQL 
                     || ' INFO.TINFO_ZXZX_JJJBXX P 
                     WHERE P.ID=M.'||CUR_YQ.GLZD||' 
                       AND P.TRD_CODE = A.CPDM  
                       AND (M.'||CUR_YQ.RQZD||' BETWEEN '||I_QSRQ||' AND '||I_JSRQ||') having count(*)>0) ' ;
      END IF;                                 
                                           

     V_NUM := V_NUM + 1;
  END LOOP ;

  V_SQL := V_SQL || '('||V_SUB_SQL||') AS SSQKYQ ' ;
  
  --条件过滤
  V_SQL := V_SQL ||' FROM TPIF_CPDM A WHERE A.CPXL=1 AND A.CPNBZT = 8  AND A.CLRQ >0 AND DQRQ> TO_CHAR(SYSDATE,''YYYYMMDD'') AND A.CLRQ>=20150101';
  --I_CPMC 
  IF I_CPMC IS NOT NULL THEN
    
      V_SQL := V_SQL || ' AND ( LOWER(A.CPDM) LIKE ''%' || LOWER(I_CPMC) || '%'' OR LOWER(A.CPMC) LIKE ''%' || LOWER(I_CPMC) || '%'')'; 
  
  END IF ;
  
  --后面根据实际情况需要调整
  V_SQL := 'SELECT * FROM ( '||V_SQL||') WHERE (REPLACE(GPYQ,''<br/>'','''') IS NOT NULL 
                                             OR REPLACE(ZQYQ,''<br/>'','''') IS NOT NULL
                                             OR REPLACE(GLRYQ,''<br/>'','''') IS NOT NULL
                                             OR REPLACE(JJJLYQ,''<br/>'','''') IS NOT NULL
                                             OR REPLACE(SSQKYQ,''<br/>'','''') IS NOT NULL )';
  
  --OPEN O_RESULT FOR V_SQL ;
 
  --后面根据实际情况需要调整
  V_COLLIST := 'ID,CPDM,CPMC,CPJC,GPYQ,ZQYQ,GLRYQ,JJJLYQ,SSQKYQ ';
  V_SORT := '';
  V_HASRECORDSET := 1;
  I_TOTALROWS := -1 ;
  
  DBMS_OUTPUT.PUT_LINE(V_SQL);

  PCX_TYCX(VN_CODE,
           VS_NOTE,
           V_HASRECORDSET,
           O_RESULT,
           1,
           I_PAGENO,
           I_PAGELENGTH,
           I_TOTALROWS,
           SQLS           => V_SQL,
           COLLIST        => V_COLLIST,
           HASWHERE       => TRUE,
           GROUPISLAST    => TRUE,
           I_SORT         => V_SORT, --至多一条，强制不排序
           I_HASWITH      => FALSE);


EXCEPTION WHEN OTHERS THEN
    V_ERR := SQLERRM ;
    OPEN O_RESULT FOR
SELECT '异常信息：' || V_ERR FROM DUAL;

END ;
/

