create PROCEDURE PRO_PIF_YYGL_MAIN_YYRWSC(O_CODE OUT NUMBER,
                                                         O_NOTE OUT VARCHAR2,
                                                         I_RQ   NUMBER DEFAULT NULL, --日期
                                                         I_SJLX IN NUMBER DEFAULT NULL) AS
    /******************************************************************
    项目名称：PIF  产品中心-运营管理
    所属用户：PIF
    概要说明：运营任务生成调度主过程
          I_RQ    --日期
    语法信息：
         输出参数：
            O_CODE  成功返回 成功，失败返回-1
            O_NOTE     成功返回操作成功，失败返回错误信息
    数据准备：
         关联调度
    运行原理：
          1.入参校验
         2.获取事件类型。
           2.1获取事件产品运营计划。
           2.2生成产品运营任务。
    功能修订：
        简要说明：
          运营任务生成调度主过程
    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2014/11/14     1.0.1     林嵩              运营任务生成调度主过程。
        2014/12/10     1.0.2     刘浪浪            取有效的事件来生成任务
        2015/01/27     1.0.3     刘浪浪            日期入参由VARCHAR2改为NUMBER
        2015/02/27     1.0.4     刘浪浪            运营任务内容改为产品事件类型名称+运营任务类型名称+产品代码
    *********************************************************************************************************************/
    V_RQ NUMBER(8) DEFAULT I_RQ; --当前日期
BEGIN
    O_CODE := 1;
    O_NOTE := '成功';
    --1.***************************入参校验 ***************************
    --当前变量赋值
    IF V_RQ IS NULL THEN
        V_RQ := TO_NUMBER(TO_CHAR(SYSDATE, 'yyyymmdd'));
    END IF;
    --2.***************************获取事件类型，执行事件调度。***************************
    --2.1.***************************执行调度过程。***************************
    --生成运营任务
    INSERT INTO TPIF_CPYYRW
        (ID,
         CPID,
         CPSJ,
         CPSJLX,
         YYRWLX,
         ZXRY,
         YJZXKSSJ,
         YJZXWCSJ,
         ZYCD,
         RWNR,
         ZXZT,
         RWFSRQ,
         SJWCSJ,
         RWFSSJ)
        SELECT SEQ_TPIF_CPYYRW.NEXTVAL,
               A.CPID,
               B.ID,
               A.CPSJLX,
               A.YYRWLX,
               A.ZXRY,
               B.SJKSSJ - ABS(A.ZXSC),
               B.SJKSSJ - ABS(A.ZXSC) - 1 + A.WCSC + 0.75,
               A.ZYCD,
               /*(SELECT LXMC FROM TPIF_CPSJLX WHERE ID = B.CPSJLX) || '-' ||
               (SELECT LXMC FROM TPIF_CPYYRWLX WHERE ID = A.YYRWLX) || '【' ||
               (SELECT CPDM || '(' ||  CPMC ||  ')'  FROM TPIF_CPDM WHERE ID = B.CPID) || '】'*/
               b.SJMS,
               0,
               V_RQ,
               NULL,
               SYSDATE
          FROM TPIF_CPYYJH A,
               (SELECT A.ID, A.CPID, A.CPSJLX, A.SJKSSJ,SJMS
                  FROM TPIF_CPSJ A
                 WHERE A.SJSCRQ = V_RQ
                   AND A.SFSX = 1) B
         WHERE A.CPSJLX = B.CPSJLX
           AND A.CPID = B.CPID
           AND A.SFSX = 1
           AND A.ZXQK < 3
           AND A.CPSJLX = NVL(I_SJLX, A.CPSJLX);
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        BEGIN
            ROLLBACK;
            O_CODE := -1;
            O_NOTE := '错误：' || SQLERRM;
            RETURN;
        END;
END PRO_PIF_YYGL_MAIN_YYRWSC;
/

