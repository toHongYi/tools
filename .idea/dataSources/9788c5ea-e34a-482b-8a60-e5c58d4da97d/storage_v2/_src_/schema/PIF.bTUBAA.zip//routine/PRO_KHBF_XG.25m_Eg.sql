create PROCEDURE PRO_KHBF_XG(O_CODE OUT NUMBER,    --错误代码
                                        O_NOTE OUT VARCHAR2,  --错误消息
                                        I_USERID IN NUMBER,   --登陆用户ID      Y
                                        I_VISITID IN NUMBER,  --拜访记录ID      Y
                                        I_JLRQ IN NUMBER,     --交流日期
                                        I_JLDXLX IN VARCHAR2,   --交流对象类型
                                        I_JLDX IN VARCHAR2,   --交流对象
                                        I_DYJLXS IN NUMBER,   --调研交流形式
                                        I_JGID IN NUMBER,     --拜访机构ID
                                        I_JGMC IN VARCHAR2,   --机构名称
                                        I_JGXZ IN NUMBER,     --机构性质
                                        I_GSZJGLGM IN NUMBER,  --公司资金管理规模
                                        I_GSHXTYRY IN VARCHAR2,  --公司核心投研人员
                                        I_JGHXCL IN VARCHAR2,    --机构核心策略
                                        I_QTQKSM IN VARCHAR2,    --其他情况说明
                                        I_XQMC IN VARCHAR2,      --需求名称
                                        I_XQLX IN VARCHAR2,        --需求类型
                                        I_FBRQ IN NUMBER,        --发布日期
                                        I_JZRQ IN NUMBER,        --截止日期
                                        I_XQZT IN NUMBER,        --需求状态
                                        I_SJYWDY IN VARCHAR2,    --涉及业务单元
                                        I_YWXQSM IN VARCHAR2,    --业务需求说明
                                        I_XQMZQK IN VARCHAR2,    --公司对机构需求满足情况
                                        I_JGGDFX IN VARCHAR2,  --机构观点分享
                                        I_HYZXFX IN VARCHAR2,     --行业资讯分享
                                        
                                        I_IS_CORE_PROPERTY IN VARCHAR2, --是否核心资产
                                        I_ARTICLE_LINK IN VARCHAR2, --文章链接
                                        I_SKIP_TYPE IN VARCHAR2 --上传类型
                                        ) AS 

/******************************************************************
  项目名称：财通证券运营展业平台-客户拜访
  所属用户：PIF
  概要说明：客户拜访记录修改

  语法信息：
       输出参数：
          o_Code          返回值
          o_Note          返回信息
       输入参数：
          见参数定义部分   

  修订记录：
      修订日期       版本号    修订人             修改内容简要说明
      2020/11/19     1.0.0.1   gaokun            新增.
  ********************************************************************/

V_JGMC VARCHAR2(1000);   --根据机构ID获取机构名称

BEGIN
  O_CODE :=1;
  O_NOTE :='成功！';

  IF I_USERID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='登录用户ID不能为空！';
    RETURN;
  END IF;

  IF I_VISITID IS NULL THEN
    O_CODE :=-1;
    O_NOTE :='拜访记录ID不能为空！';
    RETURN;
  END IF;
  
  SELECT JGMC INTO V_JGMC FROM PIF.TPIF_JGDM WHERE ID=I_JGID;
  
  UPDATE PIF.TPIF_XQXX A
     SET A.XQMC   = NVL(I_XQMC,A.XQMC),
         A.JGMC   = V_JGMC,
         A.FBRQ   = NVL(I_FBRQ,A.FBRQ),
    --     A.JZRQ   = NVL(I_JZRQ,A.JZRQ),
    --     A.XQZT   = NVL(I_XQZT,A.XQZT),
         A.YWXQSM = NVL(I_YWXQSM,A.YWXQSM),
         A.XQMZQK = NVL(I_XQMZQK,A.XQMZQK)
   WHERE A.ID =
         (SELECT B.YWXQ FROM PIF.TPIF_BFJL B WHERE B.ID = I_VISITID);
   
   IF I_XQLX IS NOT NULL THEN    --判断是否需要修改 需求类型
     UPDATE PIF.TPIF_XQXX A
     SET A.XQLX = 
         (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.ID)), ',', ';')     --输入 '5;4;1;3;2'
          FROM TPIF_XQLX B                                      --改为 '1;2;3;4;5'
         WHERE INSTR(';' || I_XQLX || ';', ';' || B.BM || ';') > 0)
     WHERE A.ID =
         (SELECT B.YWXQ FROM PIF.TPIF_BFJL B WHERE B.ID = I_VISITID);    
   END IF;  
   
   IF I_SJYWDY IS NOT NULL THEN  --判断是否需要修改 涉及业务类型
     UPDATE PIF.TPIF_XQXX A
     SET A.SJYWDY = 
         (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.IBM)), ',', ';')     --输入 '5;4;1;3;2'
          FROM LIVEBOS.TXTDM B                                    --改为 '1;2;3;4;5'
         WHERE B.FLDM = 'PIF_SJYWDY'
           AND INSTR(';' || I_SJYWDY || ';', ';' || B.IBM || ';') > 0)
     WHERE A.ID =
         (SELECT B.YWXQ FROM PIF.TPIF_BFJL B WHERE B.ID = I_VISITID);      
   END IF;      
         
  UPDATE PIF.TPIF_BFJL A
     SET A.JLRQ     = NVL(I_JLRQ,A.JLRQ),
         A.JLDX     = NVL(I_JLDX,A.JLDX),
         A.DYJLXS   = NVL(I_DYJLXS,A.DYJLXS),
         A.JGID     = NVL(I_JGID,A.JGID),
         A.JGMC     = V_JGMC,
         A.JGXZ     = NVL(I_JGXZ,A.JGXZ),
         A.GSZJGLGM = NVL(I_GSZJGLGM,A.GSZJGLGM),
         A.GSHXTYTD = NVL(I_GSHXTYRY,A.GSHXTYTD),
         A.JGHXCL   = NVL(I_JGHXCL,A.JGHXCL),
         A.JGGDFX   = NVL(I_JGGDFX,A.JGGDFX),
         A.QTQKSM   = NVL(I_QTQKSM,A.QTQKSM),
    --     A.HYZXFX   = NVL(I_HYZXFX,A.HYZXFX)
         A.SFHXZC   = NVL(I_IS_CORE_PROPERTY,A.SFHXZC),
         A.WZLJ     = NVL(I_ARTICLE_LINK,A.WZLJ),
         A.SCLX     = NVL(I_SKIP_TYPE,A.SCLX)
   WHERE A.ID = I_VISITID;

   IF I_JLDXLX IS NOT NULL THEN    --判断是否需要修改交流对象类型
     UPDATE PIF.TPIF_BFJL A
     SET A.JLDXLX = 
         (SELECT REPLACE(TO_CHAR(WM_CONCAT(B.IBM)), ',', ';')     --输入 '5;4;1;3;2'
          FROM LIVEBOS.TXTDM B                                    --改为 '1;2;3;4;5'
         WHERE B.FLDM = 'PIF_JLDXLX'
           AND INSTR(';' || I_JLDXLX || ';', ';' || B.IBM || ';') > 0)
     WHERE A.ID = I_VISITID; 
   END IF; 
 
  COMMIT;
--  DBMS_OUTPUT.PUT_LINE('拜访记录修改成功！');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_CODE := -1;
    O_NOTE := '查询失败:' || SQLERRM;

END;
/

