create PROCEDURE PCX_PIF_SY_SMGPQSFX(O_CODE          OUT NUMBER,
                                                O_NOTE          OUT VARCHAR2,
                                                O_RESULT        OUT SYS_REFCURSOR,
                                                I_TYPE          IN NUMBER, --类型:1:日均资 2:交易量
                                                I_TIME_INTERVAL IN NUMBER --统计周期: 1：近1年
                                                ) AS

  /*--------------------------------------------------------------------------------------------
  项目名称：产品中心
  
         功能说明：产品首页-私募首页高频日均资产趋势、高频交易量趋势
             参数说明：
                  入参：
                        I_TIME_INTERVAL  IN NUMBER --统计周期: 1：近1年
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作        
        liutx      1.0    2021/12/21                   新增
  -----------------------------------------------------------------------------------------------*/
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_TIME_INTERVAL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TIME_INTERVAL不能为空!';
    RETURN;
  END IF;

  --近1年
  IF I_TIME_INTERVAL = 1 THEN
  
    IF I_TYPE = 1 THEN
    
      OPEN O_RESULT FOR
        SELECT SUBSTR(INIT_DATE, 1, 6) AS STAT_DATE,
               SUBSTR(SUBSTR(INIT_DATE, 1, 6), 1, 4) || '年' ||
               SUBSTR(SUBSTR(INIT_DATE, 1, 6), 5, 2) || '月' AS STAT_DATE_DESC,
               to_char(avg(asset) / 100000000, 'fm990.99') AS AMOUNT
          FROM SRC_PIF.QUICK_TRADE_DAILY
         WHERE SUBSTR(INIT_DATE, 1, 6) >=
               TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'yyyymm')
         GROUP BY SUBSTR(INIT_DATE, 1, 6)
         ORDER BY STAT_DATE ASC;
    
    ELSIF I_TYPE = 2 THEN
    
      OPEN O_RESULT FOR
        SELECT SUBSTR(INIT_DATE, 1, 6) AS STAT_DATE,
               SUBSTR(SUBSTR(INIT_DATE, 1, 6), 1, 4) || '年' ||
               SUBSTR(SUBSTR(INIT_DATE, 1, 6), 5, 2) || '月' AS STAT_DATE_DESC,
               ROUND(sum(business_balance) / 100000000, 2) AS AMOUNT
          FROM SRC_PIF.QUICK_TRADE_DAILY
         WHERE SUBSTR(INIT_DATE, 1, 6) >=
               TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'yyyymm')
         GROUP BY SUBSTR(INIT_DATE, 1, 6)
         ORDER BY STAT_DATE ASC;
    
    END IF;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

