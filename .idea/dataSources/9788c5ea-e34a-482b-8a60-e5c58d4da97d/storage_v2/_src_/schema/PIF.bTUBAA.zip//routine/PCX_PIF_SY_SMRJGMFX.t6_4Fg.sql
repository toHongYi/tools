create PROCEDURE PCX_PIF_SY_SMRJGMFX(O_CODE          OUT NUMBER,
                                                O_NOTE          OUT VARCHAR2,
                                                O_RESULT        OUT SYS_REFCURSOR,
                                                I_TIME_INTERVAL IN NUMBER --统计周期: 1：近1年
                                                ) AS

  /*--------------------------------------------------------------------------------------------
  项目名称：产品中心
  
         功能说明：产品首页-私募日均资产规模趋势
             参数说明：
                  入参：
                        I_TIME_INTERVAL  IN NUMBER --统计周期: 1：近1年
  
                  出参：
                        O_CODE   OUT   NUMBER,
                        O_NOTE   OUT   VARCHAR2,
                        O_RESULT OUT   SYS_REFCURSOR,
                      
  
        ----------------------------------------------------------
        操作人    版本号      时间                      操作
        liutx    1.0    2021/12/10                    新增
  
  -----------------------------------------------------------------------------------------------*/
BEGIN

  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_TIME_INTERVAL IS NULL THEN
    O_CODE := -1;
    O_NOTE := '入参I_TIME_INTERVAL不能为空!';
    RETURN;
  END IF;

  --近1年
  IF I_TIME_INTERVAL = 1 THEN
  
    --stat_date 统计日期    String    
    --stat_date_desc  统计日期描述    String    
    --prod_amount 日均资产    String    单位：亿元
    --csi300_index  沪深300指数   String    
    OPEN O_RESULT FOR
      SELECT TJYF AS STAT_DATE,
             SUBSTR(TJYF, 1, 4) || '年' || SUBSTR(TJYF, 5, 2) || '月' AS STAT_DATE_DESC,
             ROUND(SUM(NRJZC) / 10000, 2) AS PROD_AMOUNT,
             
             (SELECT A.ZSPJ
                FROM DSC_STAT.TPIF_STAT_ZSHQ A
               where A.ZSDM = '000300.SH'
                 AND a.SJRQ =
                     (SELECT MAX(B.SJRQ)
                        FROM DSC_STAT.TPIF_STAT_ZSHQ B
                       where B.ZSDM = '000300.SH'
                            --    AND SUBSTR(B.SJRQ,1,4) = M.YF )
                         AND SUBSTR(B.SJRQ, 1, 6) = M.TJYF)) CSI300_INDEX
        FROM DSC_STAT.TPIF_STAT_ZC M
       WHERE FZJGDM = 0
         AND TJYF >= TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'yyyymm')
       GROUP BY TJYF
       ORDER BY STAT_DATE ASC;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END;
/

