create PROCEDURE PRO_PIF_JYRL_QJZJYR(O_CODE   OUT NUMBER, --返回值
                                                    O_NOTE   OUT VARCHAR2, --返回消息
                                                    O_QJQSMC OUT VARCHAR2, --区间起始名称
                                                    O_QJQSRQ OUT NUMBER, --区间起始日期(数值型)
                                                    O_QJJSMC OUT VARCHAR2, --区间结束名称
                                                    O_QJJSRQ OUT NUMBER, --区间结束日期(数值型)
                                                    O_CPMC   OUT VARCHAR2, --产品名称
                                                    I_CPID   IN NUMBER, --产品ID
                                                    I_SCQJ   IN NUMBER --生成区间
                                                    ) AS
    /******************************************************************
    项目名称：银河产品中心
    所属用户：PIF
    概要说明：取基准交易日

    修订记录：
        修订日期       版本号    修订人             修改内容简要说明
        2016-07-21     V1.0      谢莉莉             创建
        2016-10-20     V2.0      王大一             托管系统迁移改造接入产品中心
    *********************************************************************************************************************/

    V_COUNT  NUMBER; --判断
    V_QJBH   VARCHAR2(30); --区间编号
    V_QJMS   VARCHAR2(300); --区间描述
    V_QSRQDM VARCHAR2(30); --起始日期代码
    V_ZZRQDM VARCHAR2(30); --起始日期代码
    V_SQL    VARCHAR2(32767);

BEGIN
    --默认值
    O_QJQSRQ := '';
    O_QJJSRQ := '';
    O_CODE   := 1;
    O_NOTE   := '操作成功！';

    --判断CPID是否有效
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_CPDM WHERE ID = I_CPID;
    IF (V_COUNT = 0) THEN
        O_CODE := -1;
        O_NOTE := 'ID为【' || I_CPID || '】的产品不存在！';
        RETURN;
    ELSE
        --取得产品名称
        SELECT CPMC INTO O_CPMC FROM TPIF_CPDM WHERE ID = I_CPID;
    END IF;
    --判断SCQJ是否有效
    SELECT COUNT(1) INTO V_COUNT FROM TPIF_JYRL_SCQJ WHERE ID = I_SCQJ;
    IF (V_COUNT = 0) THEN
        O_CODE := -1;
        O_NOTE := 'ID为【' || I_SCQJ || '】的区间不存在！';
        RETURN;
    ELSE
        --取得区间名称
        SELECT MS INTO V_QJMS FROM TPIF_JYRL_SCQJ WHERE ID = I_SCQJ;
    END IF;

    --取得区间编号
    SELECT BH INTO V_QJBH FROM TPIF_JYRL_SCQJ WHERE ID = I_SCQJ;
    IF (V_QJBH = 'Pz') THEN
        RETURN;
    ELSE
        --该产品是否配置基准交易日
        SELECT COUNT(1) INTO V_COUNT FROM TPIF_JYRL_JZJYR WHERE CPID = I_CPID;
        IF (V_COUNT = 0) THEN
            O_CODE := -1;
            O_NOTE := '产品【' || O_CPMC || '】没有配置基准交易日！';
            RETURN;
        ELSE
            --判断区间的起始日/终止日是否有配置
            V_SQL := 'SELECT QSR,ZZR FROM TPIF_JYRL_SCQJ WHERE ID = ' || I_SCQJ;
            DBMS_OUTPUT.PUT_LINE(V_SQL);
            EXECUTE IMMEDIATE V_SQL
                INTO O_QJQSMC, O_QJJSMC;
            IF (O_QJQSMC IS NULL) THEN
                O_CODE := -1;
                O_NOTE := '区间【' || V_QJMS || '】没有配置起始日！';
                RETURN;
            ELSIF (O_QJJSMC IS NULL) THEN
                O_CODE := -1;
                O_NOTE := '区间【' || V_QJMS || '】没有配置终止日！';
                RETURN;
            ELSE
                --判断生成区间的配置和基准交易日是否一致
                V_SQL := 'SELECT COUNT(NAME) FROM LIVEBOS.TTABLEOBJ WHERE TABLENAME = ''TPIF_JYRL_JZJYR'' AND DESCRIBE = ''' ||
                         O_QJQSMC || '''';
                DBMS_OUTPUT.PUT_LINE(V_SQL);
                EXECUTE IMMEDIATE V_SQL
                    INTO V_COUNT;
                IF (V_COUNT = 0) THEN
                    O_CODE := -1;
                    O_NOTE := '区间【' || V_QJMS || '】的起始日配置与基准交易日表不一致！';
                    RETURN;
                ELSE
                    V_SQL := 'SELECT COUNT(NAME) FROM LIVEBOS.TTABLEOBJ WHERE TABLENAME = ''TPIF_JYRL_JZJYR'' AND DESCRIBE = ''' ||
                             O_QJJSMC || '''';
                    DBMS_OUTPUT.PUT_LINE(V_SQL);
                    EXECUTE IMMEDIATE V_SQL
                        INTO V_COUNT;
                    IF (V_COUNT = 0) THEN
                        O_CODE := -1;
                        O_NOTE := '区间【' || V_QJMS || '】的终止日配置与基准交易日表不一致！';
                        RETURN;
                    END IF;
                    --取得起始日期代码
                    V_SQL := 'SELECT NAME FROM LIVEBOS.TTABLEOBJ WHERE TABLENAME = ''TPIF_JYRL_JZJYR'' AND DESCRIBE = ''' ||
                             O_QJQSMC || '''';
                    DBMS_OUTPUT.PUT_LINE(V_SQL);
                    EXECUTE IMMEDIATE V_SQL
                        INTO V_QSRQDM;
                    --取得终止日期代码
                    V_SQL := 'SELECT NAME FROM LIVEBOS.TTABLEOBJ WHERE TABLENAME = ''TPIF_JYRL_JZJYR'' AND DESCRIBE = ''' ||
                             O_QJJSMC || '''';
                    DBMS_OUTPUT.PUT_LINE(V_SQL);
                    EXECUTE IMMEDIATE V_SQL
                        INTO V_ZZRQDM;
                    --取得基准交易日
                    V_SQL := 'SELECT ' || V_QSRQDM || ',' || V_ZZRQDM ||
                             ' FROM TPIF_JYRL_JZJYR WHERE CPID = ' || I_CPID;
                    DBMS_OUTPUT.PUT_LINE(V_SQL);
                    EXECUTE IMMEDIATE V_SQL
                        INTO O_QJQSRQ, O_QJJSRQ;
                    --编号为P3做特殊处理，日期为基准交易日表中日期+1天
                    IF (V_QJBH = 'P3') THEN
                        O_QJQSRQ := TO_NUMBER(TO_CHAR(TO_DATE(TO_CHAR(O_QJQSRQ),
                                                              'YYYYMMDD') + 1,
                                                      'YYYYMMDD'));
                    END IF;
                END IF;
            END IF;
        END IF;
    END IF;
END PRO_PIF_JYRL_QJZJYR;
/

