create PROCEDURE PRO_PIF_SJCPZJ(O_CODE OUT NUMBER, --返回值
                                           O_NOTE OUT VARCHAR2 --返回消息
                                           ) IS
  /******************************************************************
      所属用户：PIF
      功能说明：走上架流程的产品数据质检
      数据产品质检
      语法信息：
           输入参数：   无
           输出参数：   O_CODE  返回值
                        O_NOTE  返回消息
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2022-1-5      1.0      liutx                   创建
  ***********************************************************************/
  V_CWJG  VARCHAR2(1000) := '';
  V_COUNT NUMBER;
  V_ID    NUMBER;
  --CUR_SMCP TPIF_SMCP%ROWTYPE;

BEGIN
  --INIT
  O_CODE := -1;
  O_NOTE := '';

  SELECT ID INTO V_ID FROM PIF.TPIF_JHGZ WHERE GZDM = 'GZ00001';

  FOR CUR IN (SELECT * FROM PIF.LCCPSJ WHERE SHZT = 2) LOOP
    /*质检产品代码中是否缺少必填信息*/
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PIF.TPIF_CPDM
     WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
       AND CPDM IS NOT NULL
       AND JRCPFL IS NOT NULL
       AND CPFXDJ IS NOT NULL
       AND TZFZR IS NOT NULL
       AND CPGLRID IS NOT NULL
       AND CPTGR IS NOT NULL
       AND CPTA IS NOT NULL
       AND CPTZQX IS NOT NULL
       AND CPQX IS NOT NULL
       AND NHTS IS NOT NULL
       AND MFMZ IS NOT NULL
       AND CPJZ IS NOT NULL
       AND SCLX IS NOT NULL;
    IF V_COUNT > 0 THEN
      UPDATE TPIF_ZJJG
         SET ZJJG = 1, CWJG = ''
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM);
    ELSE
      V_CWJG := '产品代码表中，';
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND JRCPFL IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品一级分类(jrcpfl)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(tzfzr) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '基金经理(tzfzr)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND cpglrid IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品管理人(cpglrid)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND cptgr IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品托管人(cptgr)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND cpta IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品TA编号(cpta)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(cptzqx) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品期限(天)(cptzqx)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND cpqx IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '产品服务期限(cpqx)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(nhts) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '年化天数(nhts)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(mfmz) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '面值(mfmz)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(cpjz) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '净值(cpjz)字段为空,';
      END IF;
    
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PIF.TPIF_CPDM
       WHERE TRIM(CPDM) = TRIM(CUR.CPDM)
         AND TRIM(SCLX) IS NOT NULL;
      IF V_COUNT = 0 THEN
        V_CWJG := V_CWJG || '市场类型(SCLX)字段为空.';
      END IF;
    
      MERGE INTO PIF.TPIF_ZJJG M
      USING (SELECT CUR.CPDM CPDM, V_CWJG CWJG, V_ID ID FROM DUAL) N
      ON (M.CPDM = N.CPDM AND M.ZJGZ = N.ID)
      WHEN MATCHED THEN
        UPDATE SET M.CWJG = V_CWJG, M.ZJJG = 0
      WHEN NOT MATCHED THEN
        INSERT
          (ID, RQ, ZJGZ, ZJJG, CWJG, CPDM)
        VALUES
          (LIVEBOS.FUNC_NEXTID('TPIF_ZJJG'),
           SYSDATE,
           N.ID,
           0,
           N.CWJG,
           CUR.CPDM);
    
    END IF;
    COMMIT;
  
  END LOOP;

  O_CODE := 1;
  O_NOTE := 'TPIF_ZJJG 表清洗成功';
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    O_CODE := -1;
    O_NOTE := (CASE
                WHEN O_NOTE IS NULL THEN
                 'TPIF_ZJJG 表清洗,未知错误'
                ELSE
                 'TPIF_ZJJG 表清洗,在 ' || O_NOTE || ' 时出现异常'
              END) || ':' || SQLERRM;
END;
/

