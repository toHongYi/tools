create FUNCTION FUNC_PIF_GET_ZJKFRQJ( I_CPID IN NUMBER --产品ID
                                                   ) RETURN VARCHAR2 IS
  ------------------------------------------------------------------------------
  /*项目名称：产品中心
    功能说明：计算最近开放日区间

      ----------------------------------------------------------
        操作人   版本号       时间                      操作
        韩乔楠   1.0.0    2021/09/17                新增
  --------------------------------------------------------------------------------*/
  V_COUNT    INTEGER;--计数
  V_COUNT_SG INTEGER;
  V_COUNT_RG INTEGER;
  V_COUNT_SH INTEGER;
  V_SG       VARCHAR2(500);--申购
  V_RG       VARCHAR2(500);--认购
  V_SH       VARCHAR2(500);--赎回
  V_begin    VARCHAR2(500);--开始
  V_end      VARCHAR2(500);--结束
  V_RESULT   VARCHAR2(500);
  V_BEGINDATE DATE;
  V_ENDDATE   DATE;

BEGIN
  --6认购,7申购,8赎回
  

  --是否有申购
  V_ENDDATE:=SYSDATE-1;
  SELECT COUNT(1) INTO V_COUNT_SG
    FROM TPIF_JYRL_HB
    WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=7;
    
     WHILE (V_COUNT_SG>0) LOOP 
      
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD') INTO V_begin FROM TPIF_JYRL_HB T WHERE T.CPID=I_CPID AND T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=7;
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD'),MIN(RQ)
      INTO V_end,V_ENDDATE
      FROM tPIF_JYRL_HB T
     WHERE T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30)
       AND T.cpid = I_CPID AND T.YWLX=7
       AND NOT EXISTS (SELECT 1
              FROM tPIF_JYRL_HB
             WHERE cpid = t.cpid
               AND rq = t.rq + 1);
    IF V_begin=V_end THEN
      V_SG:=V_SG||V_begin||',';
    ELSE 
      V_SG:=V_SG||V_begin||'至'||V_end||',';
    END IF;
     SELECT COUNT(1) INTO V_COUNT_SG
       FROM TPIF_JYRL_HB
      WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=7;
      
    END LOOP;
    IF V_SG IS NOT NULL THEN
      V_RESULT:='申购:'||V_SG;
    END IF;
    
   --是否有赎回
   V_ENDDATE:=SYSDATE-1;
   V_ENDDATE:=SYSDATE-1;
  SELECT COUNT(1) INTO V_COUNT_SH
    FROM TPIF_JYRL_HB
    WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=8;
    
    WHILE (V_COUNT_SH>0) LOOP 
      
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD') INTO V_begin FROM TPIF_JYRL_HB T WHERE T.CPID=I_CPID AND T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=8;
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD'),MIN(RQ)
      INTO V_end,V_ENDDATE
      FROM tPIF_JYRL_HB T
     WHERE T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30)
       AND T.cpid = I_CPID AND T.YWLX=8
       AND NOT EXISTS (SELECT 1
              FROM tPIF_JYRL_HB
             WHERE cpid = t.cpid
               AND rq = t.rq + 1);
    IF V_begin=V_end THEN
      V_SH:=V_SH||V_begin||',';
    ELSE 
      V_SH:=V_SH||V_begin||'至'||V_end||',';
    END IF;
     SELECT COUNT(1) INTO V_COUNT_SH
       FROM TPIF_JYRL_HB
      WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=7;
      
    END LOOP;
    IF V_SG IS NOT NULL THEN
      V_RESULT:=V_RESULT||'赎回:'||V_SH;
    END IF;
    
   --是否有认购
   V_ENDDATE:=SYSDATE-1;
  SELECT COUNT(1) INTO V_COUNT_RG
    FROM TPIF_JYRL_HB
    WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=6;
    
    WHILE (V_COUNT_RG>0) LOOP 
      
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD') INTO V_begin FROM TPIF_JYRL_HB T WHERE T.CPID=I_CPID AND T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=6;
    SELECT TO_CHAR(MIN(RQ),'YYYY-MM-DD'),MIN(RQ)
      INTO V_end,V_ENDDATE
      FROM tPIF_JYRL_HB T
     WHERE T.RQ>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30)
       AND T.cpid = I_CPID AND T.YWLX=6
       AND NOT EXISTS (SELECT 1
              FROM tPIF_JYRL_HB
             WHERE cpid = t.cpid
               AND rq = t.rq + 1);
    IF V_begin=V_end THEN
      V_RG:=V_RG||V_begin||',';
    ELSE 
      V_RG:=V_RG||V_begin||'至'||V_end||',';
    END IF;
     SELECT COUNT(1) INTO V_COUNT_RG
       FROM TPIF_JYRL_HB
      WHERE CPID=I_CPID AND rq>V_ENDDATE AND RQ<=TRUNC(SYSDATE+30) AND YWLX=6;
      
    END LOOP;
    IF V_RG IS NOT NULL THEN
      V_RESULT:=V_RESULT||'认购:'||V_RG||';';
    END IF;
  RETURN V_RESULT;

EXCEPTION
  WHEN OTHERS THEN
    RETURN - 999;
END;
/

