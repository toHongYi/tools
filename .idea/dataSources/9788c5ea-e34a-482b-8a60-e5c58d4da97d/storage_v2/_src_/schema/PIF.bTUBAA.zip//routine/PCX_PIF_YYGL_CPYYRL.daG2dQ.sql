create PROCEDURE PCX_PIF_YYGL_CPYYRL(O_CODE          OUT NUMBER,
                                                O_NOTE          OUT VARCHAR2,
                                                O_RESULT        OUT SYS_REFCURSOR,
                                                I_CALENDAR_TYPE IN NUMBER, --1|销售日历;2|运营日历;3|产品中心登入
                                                I_QUERY_MONTH IN NUMBER,
                                                --I_BEGIN_DATE    IN NUMBER, --开始日期
                                                --I_END_DATE      IN NUMBER, --结束日期
                                                I_USERID        IN NUMBER := '', --登陆用户ID
                                                I_PROD_CLASS    IN VARCHAR2 := '' --产品分类
                                                ) AS

  /******************************************************************
      项目名称：产品中心
      所属用户：PIF
      功能说明：运营管理产品日历
      语法信息：
           输入参数：   
           输出参数：   O_RESULT  返回结果
      逻辑说明：
  
      修订记录：
          修订日期       版本号    修订人             修改内容简要说明
          2017-05-25     1.0.1    徐阳                创建
  ***********************************************************************/
  V_SQL VARCHAR2(4000);
BEGIN
  O_CODE := 1;
  O_NOTE := '成功!';

  IF I_QUERY_MONTH IS NULL  THEN
    O_CODE := -1;
    O_NOTE := '查询月份不能为空!';
    RETURN;
  END IF;

  IF I_CALENDAR_TYPE IS NULL THEN
    O_CODE := -1;
    O_NOTE := '日历类型不能为空!';
    RETURN;
  END IF;

  V_SQL := 'SELECT A.CPSJLX AS PROD_EVENT_TYPE,
                   (SELECT LXMC FROM TPIF_CPSJLX WHERE ID=A.CPSJLX) EVENT_TYPE_NAME,
                   (SELECT ZSYS FROM TPIF_CPSJLX WHERE ID=A.CPSJLX) DISPLAY_STYLE,
                   B.ZRR   EVENT_DATE,
                   C.ZSSX DISPLAY_ORDER,
                   COUNT(A.CPSJLX) CNT
                   FROM TPIF_CPSJ A,
                   LIVEBOS.TXTJYR B,
                   TPIF_CPSJLX_RLZS C
                   WHERE TO_NUMBER(TO_CHAR(A.SJKSSJ,''YYYYMMDD''))=B.ZRR
                   AND A.CPSJLX=C.CPSJLX
                   AND B.NY=  ' || I_QUERY_MONTH || '
                   AND A.SFSX=1
                   AND C.RLLX=' || I_CALENDAR_TYPE;

  IF I_PROD_CLASS IS NOT NULL THEN
    V_SQL := V_SQL ||
             ' AND EXISTS (SELECT 1 FROM TPIF_CPDM T WHERE T.ID=A.CPID AND T.JRCPFL=''' ||
             I_PROD_CLASS || ''')';
  END IF;

  V_SQL := V_SQL || ' GROUP BY A.CPSJLX,B.ZRR,C.ZSSX
                   ORDER BY C.ZSSX';

  OPEN O_RESULT FOR V_SQL;

EXCEPTION
  WHEN OTHERS THEN
    O_CODE := -1;
    O_NOTE := '失败!' || SQLERRM;
    OPEN O_RESULT FOR
      SELECT O_NOTE FROM DUAL;
  
END PCX_PIF_YYGL_CPYYRL;
/

